# -*- coding: utf-8 -*-
"""PSV Engine deployment verification. Run after start.bat installs dependencies."""
import os, sys, sqlite3, tempfile, importlib, pathlib, py_compile, re

ROOT = pathlib.Path(__file__).resolve().parent
required = [
    'run_webui.py', '启动PSV.bat', 'start.bat', 'start_chrome_debug.bat', 'requirements.txt',
    'core/runtime/contracts.py', 'core/runtime/graph.py', 'core/runtime/nodes.py', 'core/runtime/postflow.py',
    'core/trade_graph/customs_node_pipeline.py', 'core/trade_graph/trade_node.py',
    'core/intelligence/account_intelligence_center.py',
    'core/intelligence/waterfall.py', 'core/intelligence/ai_router.py',
    'core/business_execution/execution_center.py', 'core/webui/app.py', 'core/runtime/scheduler.py',
    'core/webui/static/intelligence.html', 'core/webui/static/graph.html', 'core/webui/static/business.html',
    'data/industry_configs/candle.json', 'data/industry_configs/enamel_pot.json', 'data/industry_configs/felt.json',
]
missing=[p for p in required if not (ROOT/p).exists()]
if missing:
    print('[FAIL] missing files:', *missing, sep='\n  '); raise SystemExit(2)

for p in ROOT.rglob('*.py'):
    py_compile.compile(str(p), doraise=True)
print('[OK] Python compilation')

os.environ['DATABASE_PATH'] = str(ROOT/'data'/'_verify_temp.db')
try:
    from core.memory.db import DB
    db=DB()
    count=db.c().execute("select count(*) from sqlite_master where type='table'").fetchone()[0]
    print('[OK] SQLite init:', count, 'tables')
    from core.config.industry import load_industry
    cfg=load_industry('enamel_pot')
    assert cfg.get('keywords') and cfg.get('search_terms')
    print('[OK] enamel_pot config')
    from core.trade_graph.visualization import TradeGraphVisualization
    assert TradeGraphVisualization(db).get_graph(depth=2)['node_count'] == 0
    print('[OK] trade graph service')
except Exception as e:
    print('[FAIL] core verification:', e); raise
finally:
    try: (ROOT/'data'/'_verify_temp.db').unlink()
    except FileNotFoundError: pass

# These must not remain as active dependencies in the merged build.
text='\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in (ROOT/'core').rglob('*.py'))
for bad in ('from core.runtime.development import run_sequence', "fetch('/api/enrich'", 'NetworkExpansionEngine', 'from core.intelligence.network_expansion'):
    if bad in text:
        print('[FAIL] stale reference:', bad); raise SystemExit(3)
print('[OK] stale reference scan')
# Canonical package must not contain obsolete packaged versions/backup artifacts.
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    n=p.name.lower()
    if any(tag in n for tag in ('backup','\u590d\u5236','\u62f7\u8d1d','\u65e7版')) or re.search(r'v45\.[0-8](?:\D|$)', p.name, re.I):
        print('[FAIL] obsolete artifact:', p.relative_to(ROOT)); raise SystemExit(4)
print('[OK] obsolete artifact scan')

canonical=(ROOT/'VERSION.txt').read_text(encoding='utf-8').strip()
if canonical != 'PSV Engine v45.10':
    print('[FAIL] canonical version mismatch:', canonical); raise SystemExit(5)
print('[OK] canonical version:', canonical)
print('PSV deployment verification passed.')
