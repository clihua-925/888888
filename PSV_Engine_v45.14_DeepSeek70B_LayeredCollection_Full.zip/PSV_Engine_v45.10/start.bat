@echo off
setlocal EnableExtensions
cd /d %~dp0
set "PYBIN=%~dp0venv\Scripts\python.exe"
if not exist "%PYBIN%" (
  echo [setup] Creating project-local virtual environment...
  where py >nul 2>&1
  if not errorlevel 1 (py -3 -m venv "%~dp0venv") else (python -m venv "%~dp0venv")
  if not exist "%PYBIN%" (
    echo [X] Python 3 is required. Install Python 3.10+ and rerun.
    pause
    exit /b 1
  )
)
"%PYBIN%" -m pip install -q --upgrade pip || goto :pipfail
"%PYBIN%" -m pip install -q -r requirements.txt || goto :pipfail
"%PYBIN%" -m playwright install chromium >nul 2>&1
rem Do not silently attach to an unrelated/stale Flask process on port 8090.
rem A deployment must start the copy of PSV located in this folder.
netstat -ano | findstr :8090 | findstr LISTENING >nul
if not errorlevel 1 (
  echo [!] Port 8090 is already in use.
  echo     Close the existing PSV/Flask process, then run this start.bat again.
  echo     This prevents accidentally opening an older installation.
  pause
  exit /b 2
)
netstat -ano | findstr :9222 | findstr LISTENING >nul
if errorlevel 1 call "%~dp0start_chrome_debug.bat"
start "PSV Engine" /D "%~dp0" "%PYBIN%" run_webui.py
timeout /t 3 >nul
start "" http://127.0.0.1:8090/
exit /b 0
:pipfail
echo [X] Dependency installation failed.
pause
exit /b 1
