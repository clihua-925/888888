@echo off
setlocal
cd /d %~dp0
set "PROFILE=%~dp0chrome_profile"
set "EXE="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined EXE if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined EXE if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined EXE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined EXE if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined EXE (
  echo [X] Chrome or Edge not found.
  pause
  exit /b 1
)
netstat -ano | findstr :9222 | findstr LISTENING >nul
if errorlevel 1 start "PSV Browser" "%EXE%" --remote-debugging-port=9222 --user-data-dir="%PROFILE%" --no-first-run --no-default-browser-check "https://www.importyeti.com/"
