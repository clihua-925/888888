# -*- coding: utf-8 -*-
"""PSV Engine v45 - Unified Database Layer (FULL AUDITED)

Core principles:
1. One entity = one entity_id + multiple roles/relations/evidence/category links
2. Intelligence/Graph/Business share unified entities table
3. No duplicate company data across modules
4. All post-collection tables have category_id field (3-category isolation)
5. First collection chain 100% frozen (customs_raw/buyers_90d read-only)
6. Old tables leads/trade_nodes/relationships deprecated, no new writes
"""
import sqlite3, time, json, uuid, re
from typing import Dict, List, Any, Optional
from core.config import settings


class DB:
    def __init__(self, path=None):
        self.path = path or settings.DATABASE_PATH
        self.init()

    def c(self):
        return sqlite3.connect(self.path, timeout=10, check_same_thread=False)

    def init(self):
        with self.c() as x:
            # ========== First Collection Chain (100% FROZEN, READ-ONLY) ==========
            x.executescript("""
            CREATE TABLE IF NOT EXISTS customs_raw(
                id INTEGER PRIMARY KEY AUTOINCREMENT, row_hash TEXT UNIQUE,
                bol TEXT, ts REAL, importer TEXT, importer_norm TEXT,
                shipper TEXT, notify TEXT, hs TEXT, descr TEXT, qty REAL,
                weight REAL, teu REAL, origin TEXT, port_load TEXT,
                port_discharge TEXT, source_file TEXT,
                direct_importer INT, created_at REAL
            );
            CREATE TABLE IF NOT EXISTS buyers_90d(
                importer_norm TEXT PRIMARY KEY, importer TEXT,
                first_seen REAL, last_seen REAL, shipments INT,
                total_weight REAL, total_qty REAL, total_teu REAL,
                supplier_count INT, origins TEXT, ports TEXT,
                sample_desc TEXT, score REAL, reasons TEXT, updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS suppliers(
                supplier_norm TEXT PRIMARY KEY, name TEXT, slug TEXT,
                shipments INT, first_seen REAL, last_seen REAL,
                harvested_at REAL, bol_fetched INT, updated_at REAL
            );
            """)

            # ========== Post-Collection Unified Schema ==========
            x.executescript("""
            CREATE TABLE IF NOT EXISTS entities(
                entity_id TEXT PRIMARY KEY,
                norm TEXT UNIQUE NOT NULL,
                name TEXT,
                original_name TEXT,
                country TEXT,
                address TEXT,
                website TEXT,
                phone TEXT,
                enterprise_type TEXT,
                industry TEXT,
                product_categories TEXT,
                brand TEXT,
                entity_status TEXT DEFAULT 'active',
                data_source TEXT,
                info_completeness REAL DEFAULT 0,
                value_score_total REAL DEFAULT 0,
                dev_qualified INT DEFAULT 0,
                created_at REAL,
                updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS entity_roles(
                entity_id TEXT,
                role TEXT CHECK(role IN ('customer','supplier','dual')),
                assigned_at REAL,
                PRIMARY KEY(entity_id, role)
            );
            CREATE TABLE IF NOT EXISTS entity_categories(
                entity_id TEXT,
                category_id TEXT,
                assigned_at REAL,
                PRIMARY KEY(entity_id, category_id)
            );
            CREATE TABLE IF NOT EXISTS trade_edges(
                edge_id TEXT PRIMARY KEY,
                from_entity_id TEXT,
                from_norm TEXT,
                to_entity_id TEXT,
                to_norm TEXT,
                relation TEXT CHECK(relation IN ('supplier_of','customer_of','trades_with')),
                product TEXT,
                hs_code TEXT,
                shipment_count INT DEFAULT 0,
                first_trade REAL,
                last_trade REAL,
                evidence TEXT,
                source_type TEXT,
                confidence REAL DEFAULT 0,
                category_id TEXT,
                created_at REAL,
                updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS evidence(
                evidence_id TEXT PRIMARY KEY,
                entity_id TEXT,
                source_type TEXT,
                source TEXT,
                evidence TEXT,
                confidence REAL DEFAULT 0,
                priority INT DEFAULT 0,
                discovered_at REAL,
                verified_at REAL
            );
            CREATE TABLE IF NOT EXISTS contacts(
                contact_id TEXT PRIMARY KEY,
                entity_id TEXT,
                name TEXT,
                title TEXT,
                email TEXT,
                phone TEXT,
                linkedin TEXT,
                verified INT DEFAULT 0,
                source TEXT,
                discovered_at REAL
            );
            CREATE TABLE IF NOT EXISTS entity_data_claims(
                claim_id TEXT PRIMARY KEY,
                entity_id TEXT,
                norm TEXT,
                field TEXT,
                value TEXT,
                normalized_value TEXT,
                source TEXT,
                source_url TEXT,
                status TEXT DEFAULT 'candidate',
                confidence REAL DEFAULT 0,
                expert_review TEXT,
                metadata TEXT,
                created_at REAL,
                last_seen REAL
            );
            CREATE INDEX IF NOT EXISTS idx_entity_claims_norm_field ON entity_data_claims(norm,field);
            CREATE TABLE IF NOT EXISTS lifecycle_history(
                history_id TEXT PRIMARY KEY,
                entity_id TEXT,
                from_state TEXT,
                to_state TEXT,
                reason TEXT,
                actor TEXT,
                transitioned_at REAL
            );
            CREATE TABLE IF NOT EXISTS tasks(
                task_id TEXT PRIMARY KEY,
                task_name TEXT,
                task_type TEXT,
                category_id TEXT,
                parent_task_id TEXT,
                run_status TEXT DEFAULT 'pending',
                current_stage TEXT,
                current_node TEXT,
                progress_pct REAL DEFAULT 0,
                discovered_customers INT DEFAULT 0,
                discovered_suppliers INT DEFAULT 0,
                new_edges INT DEFAULT 0,
                new_evidence INT DEFAULT 0,
                enrichment_count INT DEFAULT 0,
                development_count INT DEFAULT 0,
                failure_reason TEXT,
                created_at REAL,
                updated_at REAL,
                completed_at REAL
            );
            CREATE TABLE IF NOT EXISTS scheduled_tasks(
                schedule_id TEXT PRIMARY KEY,
                task_name TEXT NOT NULL,
                request TEXT,
                market TEXT NOT NULL,
                industry TEXT NOT NULL,
                quantity INT DEFAULT 20,
                run_at REAL NOT NULL,
                status TEXT DEFAULT 'pending',
                task_id TEXT,
                failure_reason TEXT,
                created_at REAL,
                updated_at REAL,
                started_at REAL,
                completed_at REAL
            );
            CREATE INDEX IF NOT EXISTS idx_scheduled_due ON scheduled_tasks(status, run_at);
            CREATE TABLE IF NOT EXISTS task_logs(
                log_id TEXT PRIMARY KEY,
                task_id TEXT,
                actor TEXT,
                message TEXT,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS info_gain(
                gain_id TEXT PRIMARY KEY,
                task_id TEXT,
                round_num INT,
                strategy TEXT,
                new_customers INT DEFAULT 0,
                new_suppliers INT DEFAULT 0,
                new_edges INT DEFAULT 0,
                new_evidence INT DEFAULT 0,
                new_contacts INT DEFAULT 0,
                new_emails INT DEFAULT 0,
                total_gain INT DEFAULT 0,
                recorded_at REAL
            );
            CREATE TABLE IF NOT EXISTS expansion_logs(
                log_id TEXT PRIMARY KEY,
                task_id TEXT,
                round_num INT,
                strategy TEXT,
                discovered_entity_id TEXT,
                discovered_norm TEXT,
                discovered_name TEXT,
                discovered_role TEXT,
                relation_type TEXT,
                from_entity_id TEXT,
                evidence TEXT,
                confidence REAL,
                category_id TEXT,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS customer_pool(
                pool_id TEXT PRIMARY KEY,
                norm TEXT,
                name TEXT,
                category_id TEXT,
                source TEXT,
                source_task_id TEXT,
                entity_id TEXT,
                added_at REAL
            );
            CREATE TABLE IF NOT EXISTS supplier_pool(
                pool_id TEXT PRIMARY KEY,
                norm TEXT,
                name TEXT,
                category_id TEXT,
                source TEXT,
                source_task_id TEXT,
                entity_id TEXT,
                added_at REAL
            );
            CREATE TABLE IF NOT EXISTS execution_records(
                record_id TEXT PRIMARY KEY,
                entity_id TEXT,
                execution_type TEXT,
                task_id TEXT,
                draft_subject TEXT,
                draft_body TEXT,
                personalized_content TEXT,
                recipient_email TEXT,
                used_intelligence TEXT,
                used_evidence TEXT,
                used_ai_model TEXT,
                send_status TEXT DEFAULT 'DRAFT',
                sent_at REAL,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS enrichment_queue(
                queue_id TEXT PRIMARY KEY,
                norm TEXT,
                category_id TEXT,
                source_task_id TEXT,
                status TEXT DEFAULT 'pending',
                priority INT DEFAULT 5,
                created_at REAL,
                started_at REAL,
                completed_at REAL
            );
            CREATE TABLE IF NOT EXISTS business_queue(
                queue_id TEXT PRIMARY KEY,
                norm TEXT,
                category_id TEXT,
                mode TEXT DEFAULT 'draft',
                our_product TEXT,
                our_company TEXT,
                status TEXT DEFAULT 'pending',
                priority INT DEFAULT 5,
                created_at REAL,
                started_at REAL,
                completed_at REAL,
                task_id TEXT,
                last_error TEXT
            );
            CREATE TABLE IF NOT EXISTS messages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id TEXT,
                lead_norm TEXT,
                direction TEXT,
                channel TEXT,
                content TEXT,
                draft INT,
                ts REAL
            );
            """)

            x.executescript("""
            CREATE INDEX IF NOT EXISTS idx_entities_norm ON entities(norm);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_from ON trade_edges(from_entity_id, category_id);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_to ON trade_edges(to_entity_id, category_id);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_norms ON trade_edges(from_norm, to_norm);
            CREATE INDEX IF NOT EXISTS idx_evidence_entity ON evidence(entity_id, priority DESC);
            CREATE INDEX IF NOT EXISTS idx_contacts_entity ON contacts(entity_id);
            CREATE INDEX IF NOT EXISTS idx_lifecycle_entity ON lifecycle_history(entity_id, transitioned_at DESC);
            CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(run_status, task_type);
            CREATE INDEX IF NOT EXISTS idx_tasks_parent ON tasks(parent_task_id);
            CREATE INDEX IF NOT EXISTS idx_business_queue_status ON business_queue(status, priority, created_at);
            CREATE INDEX IF NOT EXISTS idx_info_gain_task ON info_gain(task_id, round_num);
            CREATE INDEX IF NOT EXISTS idx_expansion_task ON expansion_logs(task_id, round_num);
            CREATE INDEX IF NOT EXISTS idx_pool_norm ON customer_pool(norm, category_id);
            CREATE INDEX IF NOT EXISTS idx_supplier_pool_norm ON supplier_pool(norm, category_id);
            CREATE INDEX IF NOT EXISTS idx_customs_importer ON customs_raw(importer_norm, ts DESC);
            CREATE INDEX IF NOT EXISTS idx_customs_shipper ON customs_raw(shipper, ts DESC);
            """ )
            x.executescript("""
            CREATE TABLE IF NOT EXISTS raw_sources(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT,query TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS clean_batches(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,stage TEXT,raw_count INT,clean_count INT,noise_count INT,duplicate_count INT,identity_only_count INT,hard_evidence_count INT,noise_ratio REAL,clean_ratio REAL,created_at REAL);
            CREATE TABLE IF NOT EXISTS expansion_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,depth INT,buyers_scanned INT,suppliers_scanned INT,new_customers INT,max_new INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS expansion_frontier(norm TEXT PRIMARY KEY,depth INT,source_task TEXT,status TEXT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS search_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,project_key TEXT,market TEXT,industry TEXT,limit_n INT,result_count INT,used_sources TEXT,source_errors TEXT,gate TEXT,evolved INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS project_evolution(project_key TEXT PRIMARY KEY,run_count INT,evolved INT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS source_quota(source TEXT,day TEXT,count INT,UNIQUE(source,day));
            CREATE TABLE IF NOT EXISTS source_checkpoints(source TEXT,project_key TEXT,run_count INT DEFAULT 0,cursor INT DEFAULT 0,watermark REAL DEFAULT 0,last_count INT DEFAULT 0,last_fingerprint TEXT,updated_at REAL,PRIMARY KEY(source,project_key));
            CREATE TABLE IF NOT EXISTS company_state(norm TEXT PRIMARY KEY,name TEXT,first_seen REAL,last_seen REAL,runs_seen INT,profiled INT,source TEXT);
            CREATE TABLE IF NOT EXISTS harvest_log(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,slug TEXT,supplier TEXT,mode TEXT,status TEXT,items INT,note TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS iy_nodes(norm TEXT,kind TEXT,slug TEXT,url TEXT,shipments INT,first_seen REAL,last_visit REAL,visits INT,run_id TEXT,PRIMARY KEY(norm,kind));
            CREATE TABLE IF NOT EXISTS trade_nodes(norm TEXT PRIMARY KEY,name TEXT,role TEXT,url TEXT,shipments INT,products TEXT,hs TEXT,depth INT,via TEXT,source TEXT,first_seen REAL,last_seen REAL,runs_seen INT,raw TEXT,country TEXT,entity_status TEXT,product_domain TEXT);
            CREATE TABLE IF NOT EXISTS relationships(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,from_norm TEXT,from_name TEXT,from_type TEXT,to_norm TEXT,to_name TEXT,to_type TEXT,relation TEXT,evidence TEXT,source TEXT,confidence REAL,depth INT,created_at REAL,shipment_count INT,hs TEXT,product TEXT,first_seen REAL,last_seen REAL,evidence_level TEXT,discovered_via TEXT,parent_node TEXT,expansion_path TEXT,product_domain TEXT,UNIQUE(task_id,from_norm,to_norm,relation));
            CREATE TABLE IF NOT EXISTS evidence_events(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,norm TEXT,kind TEXT,source TEXT,content TEXT,weight REAL,created_at REAL);
            CREATE TABLE IF NOT EXISTS query_stats(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,product_domain TEXT,query TEXT,query_type TEXT,expected_role TEXT,expected_product_relation TEXT,result_count INT,usable_trade_nodes INT,usable_trade_edges INT,precision_estimate REAL,recall_contribution REAL,runs_zero INT DEFAULT 0,status TEXT DEFAULT 'active',created_at REAL,updated_at REAL,UNIQUE(product_domain,query));
            CREATE TABLE IF NOT EXISTS product_intel_terms(id INTEGER PRIMARY KEY AUTOINCREMENT,product_domain TEXT,term TEXT,kind TEXT,hits INT DEFAULT 0,status TEXT DEFAULT 'learned',first_seen REAL,last_seen REAL,UNIQUE(product_domain,term));
            CREATE TABLE IF NOT EXISTS usitc_cache(id INTEGER PRIMARY KEY AUTOINCREMENT,hs TEXT,kind TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS leads(norm TEXT PRIMARY KEY,name TEXT,country TEXT,kind TEXT,hs_code TEXT,shipments INT,last_shipment TEXT,tags TEXT,segment TEXT,desc_sample TEXT,source TEXT,first_seen REAL,last_seen REAL,status TEXT,category TEXT,website TEXT,emails TEXT,phones TEXT,address TEXT,contact_person TEXT,score REAL,grade TEXT,profile TEXT,zone TEXT,touch_status TEXT,last_touch REAL,audit TEXT,opportunity_score REAL,demand_window TEXT,demand_confidence REAL,opportunity TEXT,development_status TEXT,expansion_count INTEGER DEFAULT 0,last_expansion REAL,expansion_status TEXT,lifecycle TEXT,product_domain TEXT,icp_score REAL,icp_tier TEXT,icp_reasons TEXT,email_verified TEXT,intro TEXT,linkedin TEXT);
            CREATE TABLE IF NOT EXISTS expansion_tasks(task_id TEXT PRIMARY KEY,root TEXT,params TEXT,strategies TEXT,rounds TEXT,gained INT DEFAULT 0,status TEXT,stopped_by TEXT,created_at REAL,updated_at REAL);
            """)

            # Backward-compatible schema migration for databases from earlier builds.
            # Compatibility fix: existing leads are updated with linkedin; older
            # databases did not contain this column, producing `no such column: linkedIn`.
            migration_columns = {
                'tasks': {'resume_state':'TEXT'},
                'leads': {'linkedin':'TEXT','first_pass_verified':'INTEGER DEFAULT 0','first_pass_ready':'INTEGER DEFAULT 0','first_pass_review':'TEXT','identity_status':"TEXT DEFAULT 'pending'",'identity_confidence':'REAL DEFAULT 0','identity_canonical_name':'TEXT','identity_aliases':'TEXT','identity_review':'TEXT'},
            }
            for table, cols in migration_columns.items():
                existing_cols={r[1] for r in x.execute(f"PRAGMA table_info({table})").fetchall()}
                for col, decl in cols.items():
                    if col not in existing_cols:
                        x.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")
            # Compatibility table used by the Business Center to derive active outreach state.
            # Creating it when absent is schema repair only; it does not alter collection logic.
            x.execute("""
                CREATE TABLE IF NOT EXISTS development_runs(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    lead_norm TEXT, status TEXT DEFAULT 'pending', task_id TEXT,
                    created_at REAL, started_at REAL, completed_at REAL, failure_reason TEXT
                )
            """)
            x.execute("CREATE INDEX IF NOT EXISTS idx_development_runs_lead_status ON development_runs(lead_norm, status, id DESC)")
            x.commit()

    # ========== Entity Operations ==========
    def get_entity(self, norm: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM entities WHERE norm=?", (norm,)).fetchone()
            return dict(row) if row else None

    def get_entity_by_id(self, entity_id: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM entities WHERE entity_id=?", (entity_id,)).fetchone()
            return dict(row) if row else None

    def get_or_create_entity(self, norm: str, name: str = None, **kwargs) -> Dict:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            existing = x.execute("SELECT * FROM entities WHERE norm=?", (norm,)).fetchone()
            if existing:
                return dict(existing)
            entity_id = f"ent-{uuid.uuid4().hex[:12]}"
            now = time.time()
            x.execute("""
                INSERT INTO entities (entity_id, norm, name, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
            """, (entity_id, norm, name or norm, now, now))
            x.execute("""
                INSERT INTO lifecycle_history (history_id, entity_id, from_state, to_state, reason, actor, transitioned_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (f"lh-{uuid.uuid4().hex[:8]}", entity_id, "", "DISCOVERED", "Entity created", "db_layer", now))
            x.commit()
            return self.get_entity(norm)

    def update_entity(self, norm: str, **fields) -> bool:
        if not fields:
            return False
        allowed = {'name','original_name','country','address','website','phone',
                   'enterprise_type','industry','product_categories','brand',
                   'entity_status','data_source','info_completeness','value_score_total',
                   'dev_qualified'}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        sets = ", ".join([f"{k}=?" for k in updates])
        vals = list(updates.values()) + [time.time(), norm]
        with self.c() as x:
            x.execute(f"UPDATE entities SET {sets}, updated_at=? WHERE norm=?", vals)
            x.commit()
        return True

    def set_entity_role(self, entity_id: str, role: str):
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO entity_roles (entity_id, role, assigned_at)
                VALUES (?, ?, ?)
            """, (entity_id, role, time.time()))
            x.commit()

    def get_entity_roles(self, entity_id: str) -> List[str]:
        with self.c() as x:
            rows = x.execute("SELECT role FROM entity_roles WHERE entity_id=?", (entity_id,)).fetchall()
            return [r[0] for r in rows]

    def set_entity_category(self, entity_id: str, category_id: str):
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO entity_categories (entity_id, category_id, assigned_at)
                VALUES (?, ?, ?)
            """, (entity_id, category_id, time.time()))
            x.commit()

    def get_entity_categories(self, entity_id: str) -> List[str]:
        with self.c() as x:
            rows = x.execute("SELECT category_id FROM entity_categories WHERE entity_id=?", (entity_id,)).fetchall()
            return [r[0] for r in rows]

    # ========== Trade Edge Operations ==========
    def save_trade_edge(self, from_norm: str, to_norm: str, relation: str,
                        product: str = None, hs_code: str = None,
                        shipment_count: int = 0, evidence: str = None,
                        source_type: str = None, confidence: float = 0,
                        category_id: str = None, first_trade: float = None, last_trade: float = None) -> str:
        from_ent = self.get_or_create_entity(from_norm, from_norm)
        to_ent = self.get_or_create_entity(to_norm, to_norm)
        edge_id = f"edge-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self.c() as x:
            existing=x.execute("""SELECT edge_id,shipment_count,confidence,evidence,first_trade,last_trade
                FROM trade_edges WHERE from_norm=? AND to_norm=? AND relation=?
                AND COALESCE(product,'')=COALESCE(?,'') AND COALESCE(category_id,'')=COALESCE(?,'')
                ORDER BY updated_at DESC LIMIT 1""",
                (from_norm,to_norm,relation,product,category_id)).fetchone()
            if existing:
                edge_id=existing[0]
                old_ship=int(existing[1] or 0); old_conf=float(existing[2] or 0)
                merged_evidence = evidence or existing[3]
                ft=float(first_trade) if first_trade is not None else None
                lt=float(last_trade) if last_trade is not None else None
                x.execute("""UPDATE trade_edges SET from_entity_id=?,to_entity_id=?,shipment_count=?,
                    evidence=?,source_type=COALESCE(?,source_type),confidence=?,
                    first_trade=CASE WHEN ? IS NULL THEN first_trade WHEN first_trade IS NULL THEN ? ELSE MIN(first_trade,?) END,
                    last_trade=CASE WHEN ? IS NULL THEN last_trade WHEN last_trade IS NULL THEN ? ELSE MAX(last_trade,?) END,updated_at=? WHERE edge_id=?""",
                    (from_ent['entity_id'],to_ent['entity_id'],max(old_ship,int(shipment_count or 0)),merged_evidence,
                     source_type,max(old_conf,float(confidence or 0)),ft,ft,ft,lt,lt,lt,now,edge_id))
            else:
                x.execute("""INSERT INTO trade_edges
                    (edge_id,from_entity_id,from_norm,to_entity_id,to_norm,relation,product,hs_code,shipment_count,first_trade,last_trade,evidence,
                     source_type,confidence,category_id,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (edge_id,from_ent['entity_id'],from_norm,to_ent['entity_id'],to_norm,relation,product,hs_code,
                     shipment_count,first_trade if first_trade is not None else now,last_trade if last_trade is not None else now,
                     evidence,source_type,confidence,category_id,now,now))
            x.commit()
        return edge_id

    def list_trade_edges(self, entity_id: str = None, norm: str = None,
                         category_id: str = None) -> List[Dict]:
        """Unified trade edges with optional product-domain isolation."""
        with self.c() as x:
            x.row_factory = sqlite3.Row
            where=[]; params=[]
            if entity_id:
                where.append('(from_entity_id=? OR to_entity_id=?)'); params.extend([entity_id,entity_id])
            elif norm:
                where.append('(from_norm=? OR to_norm=?)'); params.extend([norm,norm])
            if category_id:
                where.append('category_id=?'); params.append(category_id)
            clause=' WHERE '+ ' AND '.join(where) if where else ''
            rows=x.execute(f'SELECT * FROM trade_edges{clause} ORDER BY confidence DESC, updated_at DESC LIMIT 2000',params).fetchall()
            return [dict(r) for r in rows]

    def get_customers_of(self, norm: str, category_id: str = None) -> List[Dict]:
        """Return customer->supplier edges for a supplier node."""
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if category_id:
                rows=x.execute("""
                    SELECT * FROM trade_edges
                    WHERE ((to_norm=? AND relation='supplier_of') OR
                           (to_norm=? AND relation='customer_of') OR
                           (from_norm=? AND relation='customer_of'))
                      AND category_id=? ORDER BY confidence DESC
                """,(norm,norm,norm,category_id)).fetchall()
            else:
                rows=x.execute("""
                    SELECT * FROM trade_edges
                    WHERE (to_norm=? AND relation='supplier_of') OR
                          (to_norm=? AND relation='customer_of') OR
                          (from_norm=? AND relation='customer_of')
                    ORDER BY confidence DESC
                """,(norm,norm,norm)).fetchall()
            return [dict(r) for r in rows]

    # ========== Evidence Operations ==========
    def save_evidence(self, entity_id: str, source_type: str, source: str,
                      evidence: str, confidence: float = 0) -> str:
        ev_id = f"ev-{uuid.uuid4().hex[:12]}"
        priority = settings.EVIDENCE_PRIORITY.get(source_type, 0)
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO evidence (evidence_id, entity_id, source_type, source,
                                      evidence, confidence, priority, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (ev_id, entity_id, source_type, source, evidence, confidence, priority, now))
            x.commit()
        return ev_id

    def list_evidence(self, entity_id: str, min_priority: int = 0) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM evidence WHERE entity_id=? AND priority>=?
                ORDER BY priority DESC, discovered_at DESC
            """, (entity_id, min_priority)).fetchall()
            return [dict(r) for r in rows]

    # ========== Data Claim Operations ==========
    def save_data_claim(self, norm: str, field: str, value, source: str = '',
                        source_url: str = '', status: str = 'candidate',
                        confidence: float = 0, expert_review=None, metadata=None) -> str:
        """保存字段级事实主张；不同来源/不同值并存，不覆盖历史主张。"""
        value_s = str(value or '').strip()
        if not norm or not field or not value_s:
            return ''
        claim_id = f"cl-{uuid.uuid4().hex[:12]}"
        now = time.time()
        normalized = self._norm(value_s) if field not in ('email','phone','website') else value_s.lower().strip()
        review = json.dumps(expert_review, ensure_ascii=False) if isinstance(expert_review, (dict,list)) else str(expert_review or '')
        meta = json.dumps(metadata, ensure_ascii=False) if isinstance(metadata, (dict,list)) else str(metadata or '')
        entity = self.get_entity(norm)
        entity_id = entity.get('entity_id') if entity else None
        with self.c() as x:
            # 同一实体/字段/规范值/来源只更新最后看到时间，避免无限重复；不同值仍保留。
            old = x.execute("SELECT claim_id FROM entity_data_claims WHERE norm=? AND field=? AND normalized_value=? AND source=? LIMIT 1",
                            (norm,field,normalized,str(source or ''))).fetchone()
            if old:
                x.execute("UPDATE entity_data_claims SET last_seen=?, status=?, confidence=MAX(COALESCE(confidence,0),?), expert_review=COALESCE(NULLIF(?,''),expert_review), metadata=COALESCE(NULLIF(?,''),metadata), source_url=COALESCE(NULLIF(?,''),source_url) WHERE claim_id=?",
                          (now,str(status or 'candidate'),float(confidence or 0),review,meta,str(source_url or ''),old[0]))
                x.commit(); return old[0]
            x.execute("""INSERT INTO entity_data_claims
                (claim_id,entity_id,norm,field,value,normalized_value,source,source_url,status,confidence,expert_review,metadata,created_at,last_seen)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (claim_id,entity_id,norm,field,value_s,normalized,str(source or ''),str(source_url or ''),str(status or 'candidate'),float(confidence or 0),review,meta,now,now))
            x.commit()
        return claim_id

    def list_data_claims(self, norm: str, field: str = None, limit: int = 200) -> List[Dict]:
        sql='SELECT * FROM entity_data_claims WHERE norm=?'; args=[norm]
        if field:
            sql+=' AND field=?'; args.append(field)
        sql+=' ORDER BY last_seen DESC, confidence DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]

    def update_data_claim(self, claim_id: str, status: str = None, confidence: float = None,
                          expert_review=None) -> bool:
        updates=[]; vals=[]
        if status is not None: updates.append('status=?'); vals.append(str(status))
        if confidence is not None: updates.append('confidence=?'); vals.append(float(confidence))
        if expert_review is not None:
            updates.append('expert_review=?'); vals.append(json.dumps(expert_review,ensure_ascii=False) if isinstance(expert_review,(dict,list)) else str(expert_review))
        if not updates: return False
        vals.append(claim_id)
        with self.c() as x:
            cur=x.execute('UPDATE entity_data_claims SET '+','.join(updates)+' WHERE claim_id=?',vals); x.commit()
            return cur.rowcount>0

    # ========== Contact Operations ==========
    def save_contact(self, entity_id: str, name: str = None, title: str = None,
                     email: str = None, phone: str = None, linkedin: str = None,
                     source: str = None, verified: int = 0) -> str:
        """Insert/update a contact without duplicating the same email."""
        now=time.time(); email_norm=(email or '').strip().lower()
        with self.c() as x:
            x.row_factory=sqlite3.Row
            if email_norm:
                existing=x.execute('SELECT * FROM contacts WHERE entity_id=? AND lower(email)=?',(entity_id,email_norm)).fetchone()
                if existing:
                    cid=existing['contact_id']
                    x.execute("""UPDATE contacts SET name=COALESCE(?,name), title=COALESCE(?,title),
                                 phone=COALESCE(?,phone), linkedin=COALESCE(?,linkedin),
                                 source=COALESCE(?,source), verified=MAX(verified,?), discovered_at=?
                                 WHERE contact_id=?""",(name,title,phone,linkedin,source,int(verified or 0),now,cid))
                    x.commit(); return cid
            contact_id=f"ct-{uuid.uuid4().hex[:12]}"
            x.execute("""INSERT INTO contacts (contact_id, entity_id, name, title, email, phone, linkedin, source, verified, discovered_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",(contact_id,entity_id,name,title,email,phone,linkedin,source,verified,now))
            x.commit(); return contact_id

    def list_entity_contacts(self, entity_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("SELECT * FROM contacts WHERE entity_id=?", (entity_id,)).fetchall()
            return [dict(r) for r in rows]

    # ========== Lifecycle Operations ==========
    def get_current_lifecycle_state(self, entity_id: str) -> str:
        with self.c() as x:
            row = x.execute("""
                SELECT to_state FROM lifecycle_history
                WHERE entity_id=? ORDER BY transitioned_at DESC LIMIT 1
            """, (entity_id,)).fetchone()
            return row[0] if row else "DISCOVERED"

    def transition_lifecycle(self, entity_id: str, from_state: str, to_state: str,
                             reason: str, actor: str) -> str:
        hist_id = f"lh-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO lifecycle_history (history_id, entity_id, from_state, to_state,
                                               reason, actor, transitioned_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (hist_id, entity_id, from_state, to_state, reason, actor, now))
            x.commit()
        return hist_id

    def get_lifecycle_history(self, entity_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM lifecycle_history WHERE entity_id=?
                ORDER BY transitioned_at DESC
            """, (entity_id,)).fetchall()
            return [dict(r) for r in rows]

    # ========== Task Operations ==========
    def create_task(self, task_id: str, task_name: str, task_type: str,
                    category_id: str = None, parent_task_id: str = None) -> str:
        now = time.time()
        with self.c() as x:
            existing=x.execute("SELECT task_id FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            if existing:
                x.execute("UPDATE tasks SET task_name=?,task_type=?,category_id=COALESCE(?,category_id),parent_task_id=COALESCE(?,parent_task_id),updated_at=? WHERE task_id=?",
                          (task_name,task_type,category_id,parent_task_id,now,task_id))
            else:
                x.execute("""INSERT INTO tasks
                    (task_id, task_name, task_type, category_id, parent_task_id,run_status,created_at,updated_at)
                    VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)""",
                    (task_id,task_name,task_type,category_id,parent_task_id,now,now))
            x.commit()
        return task_id

    def get_task(self, task_id: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            return dict(row) if row else None

    def update_task(self, task_id: str, **fields) -> bool:
        allowed = {'run_status','current_stage','current_node','progress_pct',
                   'discovered_customers','discovered_suppliers','new_edges',
                   'new_evidence','enrichment_count','development_count',
                   'failure_reason','completed_at','resume_state'}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        sets = ", ".join([f"{k}=?" for k in updates])
        vals = list(updates.values()) + [time.time(), task_id]
        with self.c() as x:
            x.execute(f"UPDATE tasks SET {sets}, updated_at=? WHERE task_id=?", vals)
            x.commit()
        return True

    def list_tasks(self, status: str = None, task_type: str = None,
                   category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            conditions = []
            params = []
            if status:
                conditions.append("run_status=?")
                params.append(status)
            if task_type:
                conditions.append("task_type=?")
                params.append(task_type)
            if category_id:
                conditions.append("category_id=?")
                params.append(category_id)
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = x.execute(f"SELECT * FROM tasks {where} ORDER BY created_at DESC", params).fetchall()
            return [dict(r) for r in rows]

    def pause_task(self, task_id: str) -> bool:
        return self.update_task(task_id, run_status='paused')

    def resume_task(self, task_id: str) -> bool:
        return self.update_task(task_id, run_status='running')

    # ========== One-shot Scheduler Operations ==========
    def create_scheduled_task(self, schedule_id: str, task_name: str, request: str, market: str, industry: str, quantity: int, run_at: float) -> Dict:
        now=time.time()
        with self.c() as x:
            x.execute("INSERT INTO scheduled_tasks(schedule_id,task_name,request,market,industry,quantity,run_at,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'pending',?,?)",
                      (schedule_id,task_name,request or '',market,industry,int(quantity or 20),float(run_at),now,now))
            x.commit()
        return self.get_scheduled_task(schedule_id)

    def get_scheduled_task(self, schedule_id: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute("SELECT * FROM scheduled_tasks WHERE schedule_id=?",(str(schedule_id),)).fetchone()
            return dict(r) if r else None

    def list_scheduled_tasks(self, status: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory=sqlite3.Row
            if status:
                rows=x.execute("SELECT * FROM scheduled_tasks WHERE status=? ORDER BY run_at ASC",(status,)).fetchall()
            else:
                rows=x.execute("SELECT * FROM scheduled_tasks ORDER BY run_at ASC").fetchall()
            return [dict(r) for r in rows]

    def delete_scheduled_task(self, schedule_id: str) -> bool:
        with self.c() as x:
            cur=x.execute("DELETE FROM scheduled_tasks WHERE schedule_id=? AND status='pending'",(str(schedule_id),))
            x.commit()
            return cur.rowcount > 0

    def claim_due_scheduled_tasks(self, now: float, limit: int = 10) -> List[Dict]:
        claimed=[]
        with self.c() as x:
            x.row_factory=sqlite3.Row
            rows=x.execute("SELECT * FROM scheduled_tasks WHERE status='pending' AND run_at<=? ORDER BY run_at ASC LIMIT ?",(float(now),int(limit))).fetchall()
            for r in rows:
                sid=str(r['schedule_id']); task_id='col-'+uuid.uuid4().hex[:8]
                cur=x.execute("UPDATE scheduled_tasks SET status='running',task_id=?,started_at=?,updated_at=? WHERE schedule_id=? AND status='pending'",(task_id,float(now),float(now),sid))
                if cur.rowcount:
                    d=dict(r); d['task_id']=task_id; d['status']='running'; claimed.append(d)
            x.commit()
        return claimed

    def update_scheduled_task(self, schedule_id: str, **fields) -> bool:
        allowed={'status','task_id','failure_reason','started_at','completed_at'}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates: return False
        updates['updated_at']=time.time()
        sets=', '.join(f'{k}=?' for k in updates)
        vals=list(updates.values())+[str(schedule_id)]
        with self.c() as x:
            cur=x.execute(f"UPDATE scheduled_tasks SET {sets} WHERE schedule_id=?",vals); x.commit()
            return cur.rowcount>0

    def save_task_log(self, task_id: str, actor: str, message: str) -> str:
        log_id = f"log-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO task_logs (log_id, task_id, actor, message, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (log_id, task_id, actor, message, now))
            x.commit()
        return log_id

    def get_task_logs(self, task_id: str, limit: int = 100) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM task_logs WHERE task_id=? ORDER BY created_at DESC LIMIT ?
            """, (task_id, limit)).fetchall()
            return [dict(r) for r in rows]

    # ========== Info Gain Operations ==========
    def record_info_gain(self, task_id: str, round_num: int, strategy: str,
                         new_customers: int = 0, new_suppliers: int = 0,
                         new_edges: int = 0, new_evidence: int = 0,
                         new_contacts: int = 0, new_emails: int = 0,
                         total_gain: int = 0) -> str:
        gain_id = f"gain-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO info_gain (gain_id, task_id, round_num, strategy,
                                       new_customers, new_suppliers, new_edges,
                                       new_evidence, new_contacts, new_emails,
                                       total_gain, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (gain_id, task_id, round_num, strategy, new_customers, new_suppliers,
                  new_edges, new_evidence, new_contacts, new_emails, total_gain, now))
            x.commit()
        return gain_id

    def get_info_gain_curve(self, task_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM info_gain WHERE task_id=? ORDER BY round_num ASC
            """, (task_id,)).fetchall()
            return [dict(r) for r in rows]

    def get_latest_info_gain(self, task_id: str, n_rounds: int = 3) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM info_gain WHERE task_id=? ORDER BY round_num DESC LIMIT ?
            """, (task_id, n_rounds)).fetchall()
            return [dict(r) for r in rows]

    # ========== Pool Operations ==========
    def add_to_customer_pool(self, norm: str, name: str, category_id: str,
                             source: str, task_id: str):
        pool_id = f"cp-{uuid.uuid4().hex[:8]}"
        entity = self.get_entity(norm)
        entity_id = entity.get('entity_id') if entity else None
        with self.c() as x:
            existing=x.execute("SELECT pool_id FROM customer_pool WHERE norm=? AND COALESCE(category_id,'')=COALESCE(?,'') LIMIT 1",(norm,category_id)).fetchone()
            if existing:
                x.execute("UPDATE customer_pool SET name=?,source=COALESCE(?,source),source_task_id=COALESCE(?,source_task_id),entity_id=COALESCE(?,entity_id) WHERE pool_id=?",(name or norm,source,task_id,entity_id,existing[0]))
            else:
                x.execute("INSERT INTO customer_pool (pool_id,norm,name,category_id,source,source_task_id,entity_id,added_at) VALUES (?,?,?,?,?,?,?,?)",(pool_id,norm,name or norm,category_id,source,task_id,entity_id,time.time()))
            x.commit()

    def add_to_supplier_pool(self, norm: str, name: str, category_id: str,
                             source: str, task_id: str):
        pool_id = f"sp-{uuid.uuid4().hex[:8]}"
        entity = self.get_entity(norm)
        entity_id = entity.get('entity_id') if entity else None
        with self.c() as x:
            existing=x.execute("SELECT pool_id FROM supplier_pool WHERE norm=? AND COALESCE(category_id,'')=COALESCE(?,'') LIMIT 1",(norm,category_id)).fetchone()
            if existing:
                x.execute("UPDATE supplier_pool SET name=?,source=COALESCE(?,source),source_task_id=COALESCE(?,source_task_id),entity_id=COALESCE(?,entity_id) WHERE pool_id=?",(name or norm,source,task_id,entity_id,existing[0]))
            else:
                x.execute("INSERT INTO supplier_pool (pool_id,norm,name,category_id,source,source_task_id,entity_id,added_at) VALUES (?,?,?,?,?,?,?,?)",(pool_id,norm,name or norm,category_id,source,task_id,entity_id,time.time()))
            x.commit()

    def list_customer_pool(self, category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if category_id:
                rows = x.execute("SELECT * FROM customer_pool WHERE category_id=? ORDER BY added_at DESC", (category_id,)).fetchall()
            else:
                rows = x.execute("SELECT * FROM customer_pool ORDER BY added_at DESC").fetchall()
            return [dict(r) for r in rows]

    def list_supplier_pool(self, category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if category_id:
                rows = x.execute("SELECT * FROM supplier_pool WHERE category_id=? ORDER BY added_at DESC", (category_id,)).fetchall()
            else:
                rows = x.execute("SELECT * FROM supplier_pool ORDER BY added_at DESC").fetchall()
            return [dict(r) for r in rows]

    # ========== Expansion Log Operations ==========
    def log_expansion(self, task_id: str, round_num: int, strategy: str,
                      discovered_entity_id: str, discovered_norm: str,
                      discovered_name: str, discovered_role: str,
                      relation_type: str, from_entity_id: str = None,
                      evidence: str = None, confidence: float = 0,
                      category_id: str = None):
        log_id = f"el-{uuid.uuid4().hex[:8]}"
        with self.c() as x:
            x.execute("""
                INSERT INTO expansion_logs
                (log_id, task_id, round_num, strategy, discovered_entity_id,
                 discovered_norm, discovered_name, discovered_role, relation_type,
                 from_entity_id, evidence, confidence, category_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (log_id, task_id, round_num, strategy, discovered_entity_id,
                  discovered_norm, discovered_name, discovered_role, relation_type,
                  from_entity_id, evidence, confidence, category_id, time.time()))
            x.commit()

    def get_expansion_logs(self, task_id: str, limit: int = 500) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM expansion_logs WHERE task_id=?
                ORDER BY round_num, created_at DESC LIMIT ?
            """, (task_id, limit)).fetchall()
            return [dict(r) for r in rows]

    # ========== Execution Record Operations ==========
    def create_execution_record(self, entity_id: str, execution_type: str,
                                task_id: str, draft_subject: str = None,
                                draft_body: str = None, personalized_content: str = None,
                                recipient_email: str = None, used_intelligence: Any = None,
                                used_evidence: Any = None, used_ai_model: str = None) -> str:
        record_id = f"ex-{uuid.uuid4().hex[:12]}"
        with self.c() as x:
            x.execute("""
                INSERT INTO execution_records
                (record_id, entity_id, execution_type, task_id, draft_subject,
                 draft_body, personalized_content, recipient_email, used_intelligence,
                 used_evidence, used_ai_model, send_status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?)
            """, (record_id, entity_id, execution_type, task_id, draft_subject,
                  draft_body, personalized_content, recipient_email,
                  json.dumps(used_intelligence) if used_intelligence else None,
                  json.dumps(used_evidence) if used_evidence else None,
                  used_ai_model, time.time()))
            x.commit()
        return record_id

    def update_execution_status(self, record_id: str, status: str, sent_at: float = None):
        with self.c() as x:
            if sent_at:
                x.execute("UPDATE execution_records SET send_status=?, sent_at=? WHERE record_id=?",
                         (status, sent_at, record_id))
            else:
                x.execute("UPDATE execution_records SET send_status=? WHERE record_id=?",
                         (status, record_id))
            x.commit()

    def get_execution_records(self, entity_id: str = None, status: str = None,
                              record_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            conditions = []
            params = []
            if entity_id:
                conditions.append("entity_id=?")
                params.append(entity_id)
            if status:
                conditions.append("send_status=?")
                params.append(status)
            if record_id:
                conditions.append("record_id=?")
                params.append(record_id)
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = x.execute(f"SELECT * FROM execution_records {where} ORDER BY created_at DESC", params).fetchall()
            return [dict(r) for r in rows]

    def list_business_customers(self, category_id=None, q=None, status=None, limit=500):
        """统一客户资产列表：优先消费共享客户池，再回填 leads/entity。

        网络扩张和第一采集链都可能先写 customer_pool；业务中心不能因为 leads 的角色/
        品类状态尚未同步就把真实客户显示成“暂无客户”。所有字段仍来自统一实体事实层。
        """
        limit=int(limit or 500)
        pool=self.list_customer_pool(category_id=category_id) if category_id else self.list_customer_pool()
        seed=[]; seen=set()
        for r in pool:
            n=str(r.get('norm') or '').strip()
            if n and n not in seen:
                seen.add(n); seed.append(n)
        lead_rows=self.list_leads(kind='customer', limit=max(limit,5000), domain=None, category_id=category_id)
        for r in lead_rows:
            n=str(r.get('norm') or '').strip()
            if n and n not in seen:
                seen.add(n); seed.append(n)
        out=[]
        for n in seed:
            r=self.get_lead(n) or {}
            ent=self.get_entity(n) or {}
            if not r and not ent: continue
            if category_id and ent:
                cats=self.get_entity_categories(ent.get('entity_id'))
                if cats and category_id not in cats: continue
            name=r.get('name') or ent.get('name') or n
            if q and str(q).lower() not in str(name).lower(): continue
            item=dict(r)
            item.update({k:v for k,v in ent.items() if v and not item.get(k)})
            item['norm']=n; item['name']=name
            item['identity_status']=str(item.get('identity_status') or ('confirmed' if item.get('first_pass_verified') else ('pending_expert' if item.get('first_pass_ready') else 'pending')))
            item['identity_status_label']={'confirmed':'身份已确认','probable':'身份可用','pending_expert':'待专家复核','uncertain':'身份待确认','rejected':'身份冲突'}.get(item['identity_status'],item['identity_status'])
            item['outreach_state']='sent' if self._has_message(n,draft=0) else ('draft' if self._has_message(n,draft=1) else 'not_started')
            item['development_status']=item.get('development_status') or 'not_started'
            try:
                er=x.execute("SELECT status FROM enrichment_queue WHERE norm=? AND COALESCE(category_id,'')=COALESCE(?,'') ORDER BY created_at DESC LIMIT 1",(n,category_id or item.get('product_domain') or '')).fetchone()
                item['enrichment_state']=str(er[0]) if er else 'not_queued'
            except Exception:
                item['enrichment_state']='not_queued'
            rels=self.list_relationships(norm=n,limit=5000,domain=category_id or item.get('product_domain') or None)
            item['rel_count']=len({(x.get('from_norm'),x.get('to_norm')) for x in rels if x.get('from_norm') and x.get('to_norm')})
            item['sup_count']=len({x.get('from_norm') for x in rels if x.get('to_norm')==n and x.get('from_type')=='supplier'})
            item['completeness']=round(sum(1 for f in ('website','intro','emails','phones','contact_person','linkedin','address','country') if item.get(f))/8.0,2)
            item['ai_status']='已验证' if item.get('audit') else '待验证'
            item['business_status'],item['business_status_label']=DB.business_status(item)
            if status and item['business_status']!=status and item.get('development_status')!=status: continue
            out.append(item)
            if len(out)>=limit: break
        return out

    def _has_message(self, norm, draft=0):
        with self.c() as x:
            return bool(x.execute("SELECT 1 FROM messages WHERE lead_norm=? AND direction='out' AND draft=? LIMIT 1",(norm,int(draft))).fetchone())

    def set_identity_review(self, norm, status='pending', confidence=0.0, canonical_name='', aliases=None, review=None):
        payload=json.dumps(review, ensure_ascii=False) if isinstance(review,dict) else str(review or '')
        alias_payload=json.dumps(aliases or [], ensure_ascii=False)
        with self.c() as x:
            x.execute("UPDATE leads SET identity_status=?, identity_confidence=?, identity_canonical_name=?, identity_aliases=?, identity_review=? WHERE norm=?",
                      (str(status or 'pending'),float(confidence or 0),str(canonical_name or ''),alias_payload,payload,norm))
            x.commit()
        # canonical name is a reviewed display value; the original customs norm/name remains untouched.
        if canonical_name and status in ('confirmed','probable'):
            try: self.update_entity(norm, name=str(canonical_name)[:300], original_name=self.get_entity(norm).get('original_name') or (self.get_lead(norm) or {}).get('name') or norm)
            except Exception: pass

    def set_first_pass_review(self, norm, verified, review, ready=None):
        """保存首次身份确认结果。ready 表示已具备贸易事实门禁；verified 仅表示专家确认通过。"""
        with self.c() as x:
            payload=json.dumps(review, ensure_ascii=False) if isinstance(review,dict) else str(review or '')
            if ready is None:
                x.execute("UPDATE leads SET first_pass_verified=?, first_pass_review=?, audit=? WHERE norm=?",
                          (1 if verified else 0, payload, payload, norm))
            else:
                x.execute("UPDATE leads SET first_pass_verified=?, first_pass_ready=?, first_pass_review=?, audit=? WHERE norm=?",
                          (1 if verified else 0, 1 if ready else 0, payload, payload, norm))
            x.commit()

    # ========== Intelligence Aggregation ==========
    def get_intelligence(self, norm: str) -> Dict:
        entity = self.get_entity(norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found'}
        entity_id = entity['entity_id']
        roles = self.get_entity_roles(entity_id)
        categories = self.get_entity_categories(entity_id)
        edges = self.list_trade_edges(entity_id=entity_id)
        contacts = self.list_entity_contacts(entity_id)
        evidence = self.list_evidence(entity_id)
        history = self.get_lifecycle_history(entity_id)

        base_fields = ['name', 'country', 'address', 'website', 'phone',
                       'enterprise_type', 'industry', 'product_categories', 'brand']
        base_filled = sum(1 for f in base_fields if entity.get(f))
        base_pct = round(base_filled / len(base_fields) * 100, 1)

        trade_pct = min(100, len(edges) * 20)
        product_pct = min(100, len(set(e.get('product') for e in edges if e.get('product'))) * 25)
        contact_pct = min(100, len(contacts) * 25)
        email_pct = min(100, sum(1 for c in contacts if c.get('email')) * 50)
        website_pct = 100 if entity.get('website') else 0
        overall = round((base_pct + trade_pct + product_pct + contact_pct + email_pct + website_pct) / 6, 1)

        gaps = []
        if not entity.get('website'): gaps.append('website')
        if not entity.get('phone'): gaps.append('phone')
        if not contacts: gaps.append('contacts')
        if not any(c.get('email') for c in contacts): gaps.append('emails')
        if len(edges) < 2: gaps.append('trade_relations')

        next_steps = []
        if 'website' in gaps: next_steps.append('Search company website')
        if 'contacts' in gaps: next_steps.append('Find contacts via LinkedIn/web')
        if 'emails' in gaps: next_steps.append('Verify email addresses')
        if 'trade_relations' in gaps: next_steps.append('Expand trade network')

        return {
            'ok': True,
            'data': {
                'entity': entity,
                'roles': roles,
                'categories': categories,
                'trade_edges': edges,
                'contacts': contacts,
                'evidence': evidence,
                'lifecycle_history': history,
                'completeness': {
                    'base_info': base_pct,
                    'trade_info': trade_pct,
                    'product_info': product_pct,
                    'contact_info': contact_pct,
                    'email_info': email_pct,
                    'website_info': website_pct,
                    'overall': overall,
                },
                'gaps': gaps,
                'next_steps': next_steps,
            }
        }


    # ========== First Collection Chain Compatibility Layer (FROZEN) ==========
    @staticmethod
    def _norm(n): return re.sub(r'[^a-z0-9]+','',str(n or '').lower())
    @staticmethod

    def _db_value(v, max_len=None):
        # SQLite 不接受 list/dict 直接绑定；贸易数据里的 hs/emails/products 等字段经常是数组。
        if isinstance(v, (list, tuple, set)):
            v = ', '.join(str(x) for x in v if x is not None)
        elif isinstance(v, dict):
            v = json.dumps(v, ensure_ascii=False)
        if v is None: v=''
        v=str(v) if not isinstance(v,(int,float)) else v
        return v[:max_len] if max_len and isinstance(v,str) else v
    @staticmethod

    def _merge_text(old, new, sep=', '):
        vals=[]
        for v in (old, new):
            if isinstance(v,(list,tuple,set)): vals.extend(str(x).strip() for x in v if x is not None and str(x).strip())
            elif v is not None and str(v).strip(): vals.extend(x.strip() for x in str(v).replace(';',',').split(',') if x.strip())
        out=[]; seen=set()
        for v in vals:
            k=v.lower()
            if k not in seen: seen.add(k); out.append(v)
        return sep.join(out)

    @staticmethod

    def _merge_last_seen(old, new):
        if old in (None,''): return new or ''
        if new in (None,''): return old
        try:
            return new if float(new) >= float(old) else old
        except Exception:
            return new if str(new) > str(old) else old


    def upsert_leads(self,items):
        now=time.time()
        with self.c() as x:
            for c in items or []:
                nm=(c.get('name') or '').strip()
                if len(nm)<3: continue
                from core.trade_graph.trade_node import is_non_company_name
                if is_non_company_name(nm): continue  # v35 伪实体最终闸：绝不成为 leads 实体
                norm=self._norm(nm)
                old=x.execute('SELECT * FROM leads WHERE norm=?',(norm,)).fetchone()
                if old:
                    names=[d[0] for d in x.execute('PRAGMA table_info(leads)').fetchall()]
                    o=dict(zip(names,old))
                    old_tags=o.get('tags') or ''
                    tags=self._merge_text(old_tags,c.get('tags') or [],',')
                    hs=self._merge_text(o.get('hs_code') or '',c.get('hs_code') or '',', ')
                    desc=self._merge_text(o.get('desc_sample') or '',c.get('desc_sample') or '', ' | ')[:500]
                    src='+'.join(dict.fromkeys([v for part in (str(o.get('source') or ''),str(c.get('source') or '')) for v in part.split('+') if v]))
                    ship=max(int(o.get('shipments') or 0),int(c.get('shipments') or 0))
                    vals={
                        'name': nm or o.get('name') or '',
                        'country': c.get('country') or o.get('country') or '',
                        'kind': c.get('kind') or o.get('kind') or 'customer',
                        'hs_code': hs, 'shipments': ship,
                        'last_shipment': self._merge_last_seen(o.get('last_shipment'),c.get('last_shipment')),
                        'tags': tags, 'segment': c.get('segment') or o.get('segment') or '',
                        'category': c.get('category') or c.get('industry') or o.get('category') or '',
                        'desc_sample': desc, 'source': src, 'last_seen': now,
                        'status': c.get('status') or o.get('status') or 'new'
                    }
                    # 画像/联系方式只补空，不覆盖已有可信字段。
                    for col in ('website','emails','phones','address','linkedin','contact_person','profile'):
                        nv=c.get(col)
                        if nv:
                            vals[col]=self._db_value(nv)
                        else:
                            vals[col]=o.get(col) or ''
                    # 区域、开发状态、触达状态属于业务状态，增量采集绝不重置。
                    sets=','.join(k+'=?' for k in vals)
                    x.execute('UPDATE leads SET '+sets+' WHERE norm=?',tuple(self._db_value(v) for v in vals.values())+(norm,))
                else:
                    tags=self._db_value(c.get('tags') or [])
                    x.execute('INSERT INTO leads(norm,name,country,kind,hs_code,shipments,last_shipment,tags,segment,category,desc_sample,source,first_seen,last_seen,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        (norm,nm,self._db_value(c.get('country','')),self._db_value(c.get('kind','customer')),self._db_value(c.get('hs_code','')),int(c.get('shipments') or 0),self._db_value(c.get('last_shipment','')),tags,self._db_value(c.get('segment','')),self._db_value(c.get('category') or c.get('industry') or ''),self._db_value(c.get('desc_sample',''),500),self._db_value(c.get('source','')),now,now,self._db_value(c.get('status') or 'new')))
                # 每次看到该实体都更新增量状态，但不改变业务分区。
                x.execute("INSERT INTO company_state(norm,name,first_seen,last_seen,runs_seen,profiled,source) VALUES(?,?,?,?,?,?,?) ON CONFLICT(norm) DO UPDATE SET name=excluded.name,last_seen=excluded.last_seen,runs_seen=company_state.runs_seen+1,source=CASE WHEN company_state.source='' THEN excluded.source ELSE company_state.source || '+' || excluded.source END",
                          (norm,nm,now,now,1,0,self._db_value(c.get('source',''))))


    def get_lead(self,norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM leads WHERE norm=?',(norm,)).fetchone()
            return dict(r) if r else None

    def lead_update(self,norm,**kw):
        if not kw: return 0
        sql='UPDATE leads SET '+','.join(k+'=?' for k in kw)+' WHERE norm=?'
        with self.c() as x:
            vals=tuple(self._db_value(v) for v in kw.values())+(norm,)
            cur=x.execute(sql,vals)
            return cur.rowcount


    def list_leads(self,kind=None,segment=None,q=None,zone=None,limit=500,domain=None,category_id=None):
        sql='SELECT * FROM leads WHERE 1=1'; args=[]
        # v33.0：双角色实体（kind='both'）在客户视图与供应商视图中都可见
        if kind=='customer': sql+=" AND kind IN ('customer','both')"
        elif kind=='supplier': sql+=" AND kind IN ('supplier','both')"
        elif kind: sql+=' AND kind=?'; args.append(kind)
        if segment: sql+=' AND segment=?'; args.append(segment)
        if zone: sql+=' AND zone=?'; args.append(zone)
        if domain: sql+=' AND product_domain=?'; args.append(domain)
        if q: sql+=' AND name LIKE ?'; args.append('%'+q+'%')
        sql+=' ORDER BY COALESCE(score,0) DESC,shipments DESC,last_seen DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            rows=[dict(r) for r in x.execute(sql,args).fetchall()]
            # 通信界面需要直接知道：开发流程是否运行、是否生成过草稿、是否已经发送。
            for r in rows:
                n=r.get('norm') or ''
                sent=x.execute("SELECT 1 FROM messages WHERE lead_norm=? AND direction='out' AND draft=0 LIMIT 1",(n,)).fetchone()
                draft=x.execute("SELECT 1 FROM messages WHERE lead_norm=? AND direction='out' AND draft=1 LIMIT 1",(n,)).fetchone()
                running=x.execute("SELECT 1 FROM development_runs WHERE lead_norm=? AND status='running' ORDER BY id DESC LIMIT 1",(n,)).fetchone()
                r['outreach_state']='sent' if sent else ('draft' if draft else 'not_started')
                if running: r['development_status']='running'
                elif not r.get('development_status'): r['development_status']='not_started'
                # v38 业务状态机（派生，不落库——单一事实源是 zone/audit/icp/messages/development_runs）
                r['business_status'],r['business_status_label']=DB.business_status(r)
            # v40 数据库UI对齐：列表行直接携带 关系数/供应商数/信息完整度/AI验证状态（真实聚合，不造假）
            relc={};supc={}
            for fr,tn,ft,tt in x.execute('SELECT from_norm,to_norm,from_type,to_type FROM relationships'):
                # 去重口径：按"对手方实体"计数（同一对实体多任务证据行只算 1 个关系/1 个供应商）
                if fr and tn:
                    relc.setdefault(fr,set()).add(tn); relc.setdefault(tn,set()).add(fr)
                    if ft=='supplier': supc.setdefault(tn,set()).add(fr)
                    if tt=='supplier': supc.setdefault(fr,set()).add(tn)
            for r in rows:
                n=r.get('norm') or ''
                r['rel_count']=len(relc.get(n) or ()); r['sup_count']=len(supc.get(n) or ())
                filled=sum(1 for f in ('website','intro','emails','phones','contact_person','linkedin','address','country') if r.get(f))
                r['completeness']=round(filled/8.0,2)
                r['ai_status']='已验证' if r.get('audit') else '待验证'
                try:
                    er=x.execute("SELECT status FROM enrichment_queue WHERE norm=? AND COALESCE(category_id,'')=COALESCE(?,'') ORDER BY created_at DESC LIMIT 1",(n,category_id or domain)).fetchone()
                    r['enrichment_state']=str(er[0]) if er else 'not_queued'
                except Exception:
                    r['enrichment_state']='not_queued'
            return rows
    @staticmethod

    def business_status(lead):
        """v38 客户业务状态机（派生状态，绝不另存一份）：
        已成交>维护中>已剔除>已联系>开发中>可开发>已验证>信息补全中>新发现。"""
        zone=str(lead.get('zone') or 'pool')
        if zone=='won': return ('won','已成交')
        if zone=='maint': return ('maint','维护中')
        if zone=='discard': return ('discard','已剔除')
        if lead.get('outreach_state')=='sent': return ('contacted','已联系')
        if str(lead.get('development_status') or '')=='running' or lead.get('outreach_state')=='draft':
            return ('developing','开发中')
        if str(lead.get('icp_tier') or '') in ('A','B') and lead.get('emails'): return ('developable','可开发')
        if lead.get('audit'): return ('verified','已验证')
        if zone=='dev': return ('enriching','信息补全中')
        return ('new','新发现')

    def add_evidence_event(self,task_id,norm,kind,source,content,weight=1.0):
        with self.c() as x:
            x.execute('INSERT INTO evidence_events(task_id,norm,kind,source,content,weight,created_at) VALUES(?,?,?,?,?,?,?)',(task_id,norm,kind,source,str(content or '')[:2000],float(weight or 0),time.time()))

    def add_relationship(self,task_id,from_name,from_type,to_name,to_type,relation,evidence,source,confidence=0.0,depth=1,evidence_level='',
                         discovered_via='',parent_node='',expansion_path='',product_domain=''):
        """v30.8：边携带真实列（shipment_count/hs/product/first_seen/last_seen）。
        v33.0：标准边字段补齐 evidence_level（STRONG/MEDIUM/WEAK/UNVERIFIED）。
        v36：边携带完整可追溯性（discovered_via/parent_node/expansion_path）+ product_domain 域隔离——
        数据库必须能回答“C 是通过 B 发现的”。
        同一对实体的边再次出现时累加证据（票数取大、last_seen 更新），不静默丢弃。"""
        fn=self._norm(from_name); tn=self._norm(to_name)
        if not fn or not tn: return
        e=evidence or {}
        hs=e.get('hs'); hs_s=', '.join(str(h) for h in hs) if isinstance(hs,(list,tuple)) else str(hs or '')
        ship=int(e.get('shipments') or 0); prod=str(e.get('products') or e.get('product_text') or '')[:300]
        lvl=str(evidence_level or e.get('evidence_level') or '')
        dvia=str(discovered_via or '')[:200]; pnode=str(parent_node or '')[:200]; epath=str(expansion_path or '')[:600]; pdom=str(product_domain or '')[:80]
        now=time.time()
        sql="INSERT OR IGNORE INTO relationships(task_id,from_norm,from_name,from_type,to_norm,to_name,to_type,relation,evidence,source,confidence,depth,created_at,shipment_count,hs,product,first_seen,last_seen,evidence_level,discovered_via,parent_node,expansion_path,product_domain) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        with self.c() as x:
            cur=x.execute(sql,(task_id,fn,from_name,from_type,tn,to_name,to_type,relation,json.dumps(e,ensure_ascii=False),source,float(confidence or 0),int(depth or 1),now,ship,hs_s,prod,now,now,lvl,dvia,pnode,epath,pdom))
            if cur.rowcount==0:
                # 已存在的边：累加证据而非忽略（追溯字段只补缺，不覆盖既有事实）
                x.execute("""UPDATE relationships SET shipment_count=MAX(COALESCE(shipment_count,0),?),
                    last_seen=?, confidence=MAX(COALESCE(confidence,0),?),
                    hs=CASE WHEN hs IS NULL OR hs='' THEN ? ELSE hs END,
                    product=CASE WHEN product IS NULL OR product='' THEN ? ELSE product END,
                    evidence_level=CASE WHEN COALESCE(evidence_level,'')='' THEN ? ELSE evidence_level END,
                    discovered_via=CASE WHEN COALESCE(discovered_via,'')='' THEN ? ELSE discovered_via END,
                    parent_node=CASE WHEN COALESCE(parent_node,'')='' THEN ? ELSE parent_node END,
                    expansion_path=CASE WHEN COALESCE(expansion_path,'')='' THEN ? ELSE expansion_path END,
                    product_domain=CASE WHEN COALESCE(product_domain,'')='' THEN ? ELSE product_domain END
                    WHERE task_id=? AND from_norm=? AND to_norm=? AND relation=?""",
                    (ship,now,float(confidence or 0),hs_s,prod,lvl,dvia,pnode,epath,pdom,task_id,fn,tn,relation))

    def commit_discovery_lead(self, company, zone='dev', kind=None):
        """增量入库：新实体才进入开发池；已存在实体只合并新海关证据，不重置区域/开发状态。
        v30.6：kind 感知——供应商节点以 kind='supplier' 入库，不再被硬编码误判成进口商。"""
        nm=(company.get('name') or '').strip()
        if not nm: return {'ok':False,'norm':'','created':False,'changed':False}
        n=self._norm(nm); before=self.get_lead(n)
        e=company.get('evidence') or {}
        kind=kind or ('supplier' if (company.get('type')=='supplier' or company.get('node_role')=='supplier') else 'customer')
        self.upsert_leads([{'name':nm,'country':company.get('country') or '','kind':kind,'shipments':e.get('shipments') or 0,
                            'last_shipment':e.get('last_shipment') or '','hs_code':e.get('hs') or '',
                            'segment':company.get('segment') or '','category':company.get('industry') or '',
                            'desc_sample':e.get('products') or '','tags':[],'source':company.get('source') or '',
                            'website':company.get('website') or '','emails':company.get('emails') or '',
                            'phones':company.get('phones') or '','address':company.get('address') or ''}])
        after=self.get_lead(n)
        if not after: return {'ok':False,'norm':n,'created':False,'changed':False}
        # v31.0：资源分类产物随实体落库——生命周期与产品域（已有实体只补空，不覆盖既有分类）
        lc=company.get('lifecycle'); pd=company.get('product_domain')
        fill={}
        if lc and not after.get('lifecycle'): fill['lifecycle']=lc
        if pd and not after.get('product_domain'): fill['product_domain']=pd
        if fill: self.lead_update(n,**fill)
        if before:
            return {'ok':True,'norm':n,'created':False,'updated':True,'zone':after.get('zone'),'changed':after!=before}
        self.lead_update(n,zone=zone,status='new',development_status='not_started')
        try: self.log_lead_event(n,'',zone,actor='database_commit',reason='首次入库分区')
        except Exception: pass
        return {'ok':True,'norm':n,'created':True,'updated':False,'zone':zone,'changed':True}


    def commit_network_entity(self, name, kind, evidence=None, source='', zone_new='dev', extra=None, product_domain=''):
        """v30.6 交叉去重入库原语（二次开发专用）：
        客户开发挖到的供应商 / 供应商开发挖到的客户，都经此入库——
        已存在只合并证据与来源（绝不重置区域/开发状态），新实体才落到 zone_new。
        返回 {'norm','created','zone'}。"""
        nm=(name or '').strip()
        if len(nm)<3: return {'ok':False,'norm':'','created':False}
        n=self._norm(nm); e=evidence or {}; ex=extra or {}
        before=self.get_lead(n)
        item={'name':nm,'country':ex.get('country') or '','kind':'supplier' if kind=='supplier' else 'customer',
              'shipments':e.get('shipments') or 0,'last_shipment':e.get('last_shipment') or '',
              'hs_code':e.get('hs') or '','desc_sample':(e.get('products') or '')[:300],
              'source':source or '','website':ex.get('website') or '','emails':ex.get('emails') or '',
              'phones':ex.get('phones') or '','address':ex.get('address') or ''}
        self.upsert_leads([item])
        # Network discovery is a shared-state handoff: every discovered entity must
        # exist in the unified entities layer before downstream intelligence/business nodes read it.
        entity=self.get_or_create_entity(n,nm)
        if not entity.get('name') or entity.get('name')==n:
            self.update_entity(n,name=nm)
        self.set_entity_role(entity['entity_id'],'supplier' if kind=='supplier' else 'customer')
        if product_domain:
            self.set_entity_category(entity['entity_id'],str(product_domain)[:80])
        if e:
            self.save_evidence(entity['entity_id'],'trade_record',str(source or 'network'),json.dumps(e,ensure_ascii=False,default=str)[:2000],float(e.get('confidence') or 0.8))
        if before:
            return {'ok':True,'norm':n,'created':False,'zone':(before or {}).get('zone')}
        self.lead_update(n,zone=zone_new,status='new',development_status='not_started')
        if product_domain: self.lead_update(n,product_domain=str(product_domain)[:80])
        return {'ok':True,'norm':n,'created':True,'zone':zone_new}


    def list_relationships(self,task_id=None,norm=None,limit=500,domain=None):
        sql='SELECT * FROM relationships WHERE 1=1'; args=[]
        if task_id: sql+=' AND task_id=?'; args.append(task_id)
        if norm: sql+=' AND (from_norm=? OR to_norm=?)'; args += [norm,norm]
        if domain: sql+=' AND product_domain=?'; args.append(str(domain))
        sql+=' ORDER BY confidence DESC,created_at DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]

    def save_query_stat(self, task_id, product_domain, item):
        """v33.0 逐查询计量：每条查询词的产出全程留痕。
        动态淘汰规则（不过度过滤）：仅当一条查询【连续两轮】result_count=0 且
        usable_trade_nodes=0 才标记 retired（下轮规划降权，不删除记录）；
        有任何产出立即回活。retire 是排序信号，不是数据删除。"""
        q=str(item.get('query') or '').strip()
        if not q: return
        dom=str(product_domain or ''); now=time.time()
        rc=int(item.get('result_count') or 0); un=int(item.get('usable_trade_nodes') or 0)
        ue=int(item.get('usable_trade_edges') or 0)
        pe=item.get('precision_estimate'); rc2=item.get('recall_contribution')
        with self.c() as x:
            old=x.execute('SELECT runs_zero,status FROM query_stats WHERE product_domain=? AND query=?',(dom,q)).fetchone()
            zero=((old[0] if old else 0)+1) if (rc==0 and un==0) else 0
            status='retired' if zero>=2 else 'active'
            x.execute('''INSERT INTO query_stats(task_id,product_domain,query,query_type,expected_role,expected_product_relation,
                result_count,usable_trade_nodes,usable_trade_edges,precision_estimate,recall_contribution,runs_zero,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(product_domain,query) DO UPDATE SET task_id=excluded.task_id,query_type=excluded.query_type,
                expected_role=excluded.expected_role,expected_product_relation=excluded.expected_product_relation,
                result_count=excluded.result_count,usable_trade_nodes=excluded.usable_trade_nodes,
                usable_trade_edges=excluded.usable_trade_edges,precision_estimate=excluded.precision_estimate,
                recall_contribution=excluded.recall_contribution,runs_zero=excluded.runs_zero,status=excluded.status,updated_at=excluded.updated_at''',
                (str(task_id or ''),dom,q,str(item.get('query_type') or ''),str(item.get('expected_role') or ''),
                 str(item.get('expected_product_relation') or ''),rc,un,ue,
                 float(pe) if pe is not None else None,float(rc2) if rc2 is not None else None,zero,status,now,now))

    def upsert_trade_node(self, name, role='', url='', shipments=0, products='', hs=None,
                          depth=0, via='', source='', raw=None, country='', entity_status='',
                          product_domain=''):
        """v30.7 贸易节点数据池：每一个被发现的真实贸易实体（含物流/货代等不能成为
        客户的节点）都登记在此。它是四大基础——组建图谱（节点）、验证客户（实体曾真实
        出现在海关数据里）、证明关系（配合 relationships 边）、反向收割（未展开节点清单）。
        v33.0：entity_status 标记 RESOLVED / UNRESOLVED_TRADE_NODE（解析状态不足≠删除）。
        重复出现只累加证据，不覆盖。"""
        nm=(name or '').strip()
        if len(nm)<3: return ''
        from core.trade_graph.trade_node import is_non_company_name
        if is_non_company_name(nm): return ''  # v35 伪实体最终闸：国家/城市/港口/地址不进图谱库
        n=self._norm(nm); now=time.time()
        hs_s=', '.join(str(h) for h in hs) if isinstance(hs,(list,tuple)) else str(hs or '')
        raw_s=json.dumps(raw,ensure_ascii=False)[:3000] if raw else ''
        with self.c() as x:
            old=x.execute('SELECT * FROM trade_nodes WHERE norm=?',(n,)).fetchone()
            if old:
                names=[d[0] for d in x.execute('PRAGMA table_info(trade_nodes)').fetchall()]
                o=dict(zip(names,old))
                x.execute('''UPDATE trade_nodes SET name=?, role=CASE WHEN role='' THEN ? ELSE role END,
                    url=CASE WHEN url='' THEN ? ELSE url END,
                    shipments=MAX(COALESCE(shipments,0),?), products=CASE WHEN products='' THEN ? ELSE products END,
                    hs=CASE WHEN hs='' THEN ? ELSE hs END, depth=MIN(COALESCE(depth,9),?),
                    via=CASE WHEN via='' THEN ? ELSE via END,
                    source=CASE WHEN source='' THEN ? ELSE source||'+'||? END,
                    last_seen=?, runs_seen=runs_seen+1,
                    country=CASE WHEN COALESCE(country,'')='' THEN ? ELSE country END,
                    entity_status=CASE WHEN COALESCE(entity_status,'')='' THEN ? ELSE entity_status END,
                    product_domain=CASE WHEN COALESCE(product_domain,'')='' THEN ? ELSE product_domain END,
                    raw=CASE WHEN raw='' THEN ? ELSE raw END WHERE norm=?''',
                    (nm,role,url,int(shipments or 0),str(products or '')[:300],hs_s,int(depth or 0),str(via or '')[:200],
                     str(source or '')[:120],str(source or '')[:120],now,str(country or ''),str(entity_status or ''),str(product_domain or '')[:80],raw_s,n))
            else:
                x.execute('INSERT INTO trade_nodes(norm,name,role,url,shipments,products,hs,depth,via,source,first_seen,last_seen,runs_seen,raw,country,entity_status,product_domain) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)',
                    (n,nm,role,str(url or '')[:300],int(shipments or 0),str(products or '')[:300],hs_s,int(depth or 0),str(via or '')[:200],str(source or '')[:120],now,now,raw_s,str(country or ''),str(entity_status or ''),str(product_domain or '')[:80]))
        return n


    def add_expansion_run(self,task_id,depth,buyers_scanned,suppliers_scanned,new_customers,max_new):
        with self.c() as x:
            x.execute('INSERT INTO expansion_runs(task_id,depth,buyers_scanned,suppliers_scanned,new_customers,max_new,created_at) VALUES(?,?,?,?,?,?,?)',(task_id,int(depth),int(buyers_scanned),int(suppliers_scanned),int(new_customers),int(max_new),time.time()))

    def get_expansion_task(self, task_id):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM expansion_tasks WHERE task_id=?',(str(task_id),)).fetchone()
            if not r: return None
            d=dict(r); d['params']=json.loads(d.get('params') or '{}'); d['strategies']=json.loads(d.get('strategies') or '[]'); d['rounds']=json.loads(d.get('rounds') or '[]')
            return d

    def get_frontier(self,limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute("SELECT * FROM expansion_frontier WHERE status='pending' ORDER BY depth,updated_at LIMIT ?",(int(limit),)).fetchall()]

    def mark_frontier(self,norm,status,depth=None,task_id=None):
        with self.c() as x:
            x.execute('INSERT INTO expansion_frontier(norm,depth,source_task,status,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(norm) DO UPDATE SET depth=excluded.depth,source_task=excluded.source_task,status=excluded.status,updated_at=excluded.updated_at',(norm,int(depth or 0),task_id or '',status,time.time()))

    def save_expansion_task(self, task_id, root, params, strategies):
        now=time.time()
        with self.c() as x:
            x.execute('''INSERT INTO expansion_tasks(task_id,root,params,strategies,rounds,gained,status,stopped_by,created_at,updated_at)
                VALUES(?,?,?,?,?,0,'running','',?,?)
                ON CONFLICT(task_id) DO UPDATE SET status='running',updated_at=excluded.updated_at''',
                (str(task_id),str(root or ''),json.dumps(params or {},ensure_ascii=False),
                 json.dumps(list(strategies or []),ensure_ascii=False),'[]',now,now))

    def update_expansion_task(self, task_id, rounds=None, gained=None, status=None, stopped_by=None):
        with self.c() as x:
            row=x.execute('SELECT rounds,gained FROM expansion_tasks WHERE task_id=?',(str(task_id),)).fetchone()
            if not row: return
            r=json.loads(row[0] or '[]'); g=int(row[1] or 0)
            if rounds: r.extend(rounds)
            if gained is not None: g=int(gained)
            x.execute('UPDATE expansion_tasks SET rounds=?,gained=?,status=COALESCE(?,status),stopped_by=COALESCE(?,stopped_by),updated_at=? WHERE task_id=?',
                      (json.dumps(r,ensure_ascii=False),g,status,stopped_by,time.time(),str(task_id)))

    def save_raw_source(self,source,query,payload):
        with self.c() as x:
            x.execute('INSERT INTO raw_sources(source,query,payload,created_at) VALUES(?,?,?,?)',(str(source),str(query or ''),json.dumps(payload,ensure_ascii=False)[:50000],time.time()))

    def get_source_checkpoint(self,source,project_key):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM source_checkpoints WHERE source=? AND project_key=?',(str(source),str(project_key))).fetchone()
            return dict(r) if r else {'source':source,'project_key':project_key,'run_count':0,'cursor':0,'watermark':0,'last_count':0,'last_fingerprint':''}


    def update_source_checkpoint(self,source,project_key,**kw):
        cur=self.get_source_checkpoint(source,project_key); cur.update(kw); cur['updated_at']=time.time()
        with self.c() as x:
            x.execute('INSERT INTO source_checkpoints(source,project_key,run_count,cursor,watermark,last_count,last_fingerprint,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source,project_key) DO UPDATE SET run_count=excluded.run_count,cursor=excluded.cursor,watermark=excluded.watermark,last_count=excluded.last_count,last_fingerprint=excluded.last_fingerprint,updated_at=excluded.updated_at',
                      (source,project_key,int(cur.get('run_count') or 0),int(cur.get('cursor') or 0),float(cur.get('watermark') or 0),int(cur.get('last_count') or 0),str(cur.get('last_fingerprint') or ''),cur['updated_at']))


    def save_intel_terms(self, product_domain, terms, kind='customs_descr'):
        """v36 产品情报记忆：真实海关描述词反哺（幂等累加命中数，不覆盖）。"""
        dom=str(product_domain or ''); now=time.time(); n=0
        with self.c() as x:
            for t,hits in (terms or {}).items():
                t=str(t or '').strip()[:120]
                if not t: continue
                x.execute('''INSERT INTO product_intel_terms(product_domain,term,kind,hits,status,first_seen,last_seen)
                    VALUES(?,?,?,?, 'learned', ?,?)
                    ON CONFLICT(product_domain,term) DO UPDATE SET hits=hits+excluded.hits,last_seen=excluded.last_seen''',
                    (dom,t,str(kind),int(hits or 0),now,now))
                n+=1
        return n

    def list_intel_terms(self, product_domain, status='learned', min_hits=2, limit=50):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM product_intel_terms WHERE product_domain=? AND status=? AND hits>=? ORDER BY hits DESC LIMIT ?',
                                               (str(product_domain or ''),str(status),int(min_hits),int(limit))).fetchall()]

