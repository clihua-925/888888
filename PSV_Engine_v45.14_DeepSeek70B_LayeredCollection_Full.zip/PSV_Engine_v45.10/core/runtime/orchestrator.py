# -*- coding: utf-8 -*-
"""v14 编排入口：组装初始状态 → 跑状态图 → 每节点快照 → 终态落库。结果结构与 v13 兼容，前端无需大改。"""
import time,uuid,json
from core.memory.db import DB
from core.runtime import graph
class Orchestrator:
    def __init__(self): self.db=DB()
    def run(self,request,market='USA',industry='birthday candles',quantity=20,task_id=None):
        tid=task_id or uuid.uuid4().hex[:8]; t0=time.time()
        state={'task_id':tid,'request':request,'market':market,'industry':industry,
               'quantity':int(quantity or 20),'nodes':[],'companies':[],
               'success':False,
               'node_reports':{},'strategy':{},'query_override':None,
               'current_node':'INIT','node_status':{},'handoffs':{},'retry_history':[],'plans':[],
               'diagnostics':[],'mission_decisions':[],'funnel':[], '_persist_runtime': None}
        last_observed = {'marker': None}
        def persist(st):
            # Observation/checkpoint only: the nine node implementations and graph topology
            # are untouched. Persist enough runtime state for the UI to reconstruct the
            # exact node-by-node progress after navigation/refresh/reopen.
            category_id = st.get('category_id') or {'birthday candles':'candle','candle':'candle','enamel pot':'enamel_pot','felt':'felt'}.get(str(industry).lower())
            if not self.db.get_task(tid):
                self.db.create_task(tid, request, 'collection', category_id, None)
            order = graph.ORDER
            raw_statuses = dict(st.get('node_status') or {})
            # UI/持久化快照使用 canonical 字符串状态；运行时 node_status 内部仍可保留 attempt/error 等元数据。
            statuses = {n: (v.get('status') if isinstance(v, dict) else str(v)) for n, v in raw_statuses.items()}
            done_count = sum(1 for n in order if statuses.get(n) in ('SUCCESS','SKIPPED'))
            current = st.get('current_node') or 'MISSION_DIRECTOR'
            idx = order.index(current) if current in order else (len(order) if current == 'END' else 0)
            progress = 100 if current == 'END' else round(min(99, max(done_count * 100 / len(order), idx * 100 / len(order))), 1)
            snapshot = {
                'order': order,
                'current_node': current,
                'node_status': statuses,
                'nodes': list(st.get('nodes') or [])[-20:],
                'handoffs': dict(st.get('handoffs') or {}),
                'retry_history': list(st.get('retry_history') or [])[-20:],
                'failure_history': list(st.get('failure_history') or [])[-20:],
                'mission_decisions': list(st.get('mission_decisions') or [])[-10:],
                'funnel': list(st.get('funnel') or [])[-10:],
                'ai_queue': dict(st.get('ai_queue') or {}),
                'updated_at': time.time(),
            }
            self.db.update_task(tid, current_node=current, current_stage=current, progress_pct=progress,
                                resume_state=json.dumps(snapshot, ensure_ascii=False, separators=(',', ':')))
            marker = (current, tuple(sorted(statuses.items())))
            if marker != last_observed['marker']:
                self.db.save_task_log(tid, 'collection_observer', f'节点状态：{current}；完成 {done_count}/{len(order)}；进度 {progress}%')
                last_observed['marker'] = marker
        state['_persist_runtime'] = persist
        persist(state)
        state=graph.run_graph(state,persist)
        abort=state.get('abort')
        status={'failed':'failed','failed_gate':'failed_gate','done_degraded':'done_degraded','error':'error'}.get(abort,'done')
        state['success']=status in ('done','done_degraded')
        state['duration_sec']=round(time.time()-t0,2)
        res={k:v for k,v in state.items() if k!='traceback'}
        if not self.db.get_task(tid): self.db.create_task(tid, request, 'collection', None, None)
        self.db.update_task(tid, run_status=status, current_node=state.get('current_node'), completed_at=time.time())
        return res

    def run_development(self, lead_norm, task_id=None, start_node=None,
                        our_product=None, our_company=None):
        """Compatibility entry for the post-collection business flow.

        The former runtime.development module was removed during the merged build.
        Keep this public entry point, but route it through the canonical Business
        Execution Center instead of importing a deleted legacy module.
        """
        from core.business_execution.execution_center import BusinessExecutionCenter
        tid = task_id or ('dev-' + uuid.uuid4().hex[:8])
        t0 = time.time()
        executor = BusinessExecutionCenter(self.db)
        self.db.create_task(tid, f'Development sequence: {lead_norm}', 'development', None, None)
        self.db.update_task(tid, run_status='running', current_stage='qualification', current_node='BUSINESS_QUALIFICATION')
        self.db.save_task_log(tid, 'orchestrator', f'Starting business execution for {lead_norm}')
        try:
            qualification = executor.qualify_for_development(lead_norm)
            if not qualification.get('qualified'):
                result = {'ok': False, 'stage': 'qualification_failed',
                          'reason': qualification.get('reason'),
                          'checks': qualification.get('checks', {}), 'qualification': qualification}
                self.db.update_task(tid, run_status='completed', current_stage='qualification_failed', completed_at=time.time())
                return result
            self.db.update_task(tid, current_stage='letter_generation', current_node='DEVELOPMENT_LETTER')
            letter = executor.generate_development_letter(lead_norm, our_product=our_product, our_company=our_company)
            ok = bool(letter.get('ok'))
            status = 'completed' if ok else 'failed'
            self.db.update_task(tid, run_status=status, current_stage='letter_generated' if ok else 'letter_failed', completed_at=time.time())
            result = {'ok': ok, 'stage': 'letter_generated' if ok else 'letter_failed',
                      'qualification': qualification, 'letter': letter, 'task_id': tid,
                      'duration_sec': round(time.time() - t0, 2)}
            self.db.save_task_log(tid, 'orchestrator', f'Business execution {status} for {lead_norm}')
            return result
        except Exception as e:
            self.db.update_task(tid, run_status='failed', failure_reason=str(e)[:500], completed_at=time.time())
            self.db.save_task_log(tid, 'orchestrator', f'Business execution failed: {e}')
            return {'ok': False, 'stage': 'failed', 'error': str(e)[:500], 'task_id': tid,
                    'duration_sec': round(time.time() - t0, 2)}
