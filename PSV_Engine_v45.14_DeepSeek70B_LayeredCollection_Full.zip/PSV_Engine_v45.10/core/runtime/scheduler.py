# -*- coding: utf-8 -*-
"""Persistent one-shot scheduler for PSV.

Schedules are stored in SQLite, survive page navigation/reload and support multiple
independent one-time collection jobs. The scheduler never modifies the frozen
nine-node collection topology; it only calls its existing public entry point.
"""
import threading, time, uuid
from core.config import settings

class OneShotScheduler:
    def __init__(self, system):
        self.system=system
        self.db=system.db
        self.enabled=bool(getattr(settings,'SCHEDULER_ENABLED',True))
        self.poll_seconds=max(1,int(getattr(settings,'SCHEDULER_POLL_SECONDS',10)))
        self._stop=threading.Event()
        self._thread=None
        self._executor=system._executor

    def start(self):
        if not self.enabled or (self._thread and self._thread.is_alive()): return
        self._thread=threading.Thread(target=self._loop,name='psv-one-shot-scheduler',daemon=True)
        self._thread.start()
        self.db.save_task_log('scheduler','scheduler','一次性定时任务调度器已启动')

    def stop(self):
        self._stop.set()

    def add(self, task_name, request, market, industry, quantity, run_at):
        sid='sch-'+uuid.uuid4().hex[:10]
        return self.db.create_scheduled_task(sid,task_name,request,market,industry,quantity,run_at)

    def _loop(self):
        while not self._stop.wait(self.poll_seconds):
            try:
                due=self.db.claim_due_scheduled_tasks(time.time(),limit=10)
                for item in due:
                    self._executor.submit(self._run_one,item)
            except Exception:
                # Scheduler must not kill the WebUI because of a single polling error.
                pass

    def _run_one(self,item):
        sid=item['schedule_id']; tid=item['task_id']
        try:
            self.db.save_task_log(tid,'scheduler',f"定时任务触发：{item['task_name']}")
            result=self.system.run_collection(item.get('request') or item.get('task_name') or '',
                                               market=item.get('market') or 'USA',
                                               industry=item.get('industry') or 'candle',
                                               quantity=int(item.get('quantity') or 20),
                                               task_id=tid)
            status=str(result.get('status') or '').lower()
            if status in ('done','done_degraded') or result.get('success'):
                self.db.update_scheduled_task(sid,status='completed',completed_at=time.time())
                self.db.save_task_log(tid,'scheduler','一次性定时任务已完成')
            else:
                reason=result.get('error') or result.get('abort') or '第一采集链未成功完成'
                self.db.update_scheduled_task(sid,status='failed',failure_reason=str(reason)[:500],completed_at=time.time())
                self.db.save_task_log(tid,'scheduler',f'一次性定时任务失败：{str(reason)[:300]}')
        except Exception as e:
            self.db.update_scheduled_task(sid,status='failed',failure_reason=str(e)[:500],completed_at=time.time())
            self.db.save_task_log(tid,'scheduler',f'一次性定时任务异常：{str(e)[:300]}')
