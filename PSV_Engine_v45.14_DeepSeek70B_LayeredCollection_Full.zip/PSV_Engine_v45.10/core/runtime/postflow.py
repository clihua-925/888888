# -*- coding: utf-8 -*-
"""Post-collection orchestration primitives.

The frozen nine-node collection graph keeps its own contract system.  Long-running
post-collection queues use this smaller runtime contract so they still get the
same useful orchestration properties: shared state, explicit handoffs, conditional
routing, checkpoints and resumability, without adding nodes to the frozen chain.
"""
import hashlib
import json
import time
from typing import Any, Dict, Iterable, Optional

CONTRACT_VERSION = "v45.10-postflow"


class PostFlowTracker:
    def __init__(self, db, task_id: str, flow: str, nodes: Iterable[str]):
        self.db = db
        self.task_id = str(task_id)
        self.flow = str(flow)
        self.nodes = list(nodes)
        self.state: Dict[str, Any] = {
            "contract_version": CONTRACT_VERSION,
            "flow": self.flow,
            "task_id": self.task_id,
            "current_node": None,
            "node_status": {n: "PENDING" for n in self.nodes},
            "handoffs": [],
            "condition_edges": [],
            "shared_data": {},
            "updated_at": time.time(),
        }

    @staticmethod
    def _checksum(payload: Any) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def checkpoint(self, node: str, status: str, progress: float, *, shared_data: Optional[Dict[str, Any]] = None,
                   message: str = "", condition: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        status = str(status).upper()
        if node in self.state["node_status"]:
            self.state["node_status"][node] = status
        self.state["current_node"] = node
        if shared_data:
            self.state["shared_data"].update(shared_data)
        if condition:
            self.state["condition_edges"].append(dict(condition, at=time.time()))
        self.state["updated_at"] = time.time()
        self.db.update_task(
            self.task_id,
            current_stage=node,
            current_node=node,
            progress_pct=float(max(0, min(100, progress))),
            resume_state=json.dumps(self.state, ensure_ascii=False, default=str, separators=(",", ":")),
        )
        if message:
            self.db.save_task_log(self.task_id, node.lower(), message)
        return dict(self.state)

    def handoff(self, from_node: str, to_node: str, payload: Optional[Dict[str, Any]] = None,
                payload_keys: Optional[Iterable[str]] = None, *, condition: Optional[Dict[str, Any]] = None,
                message: str = "") -> Dict[str, Any]:
        payload = payload or {}
        keys = list(payload_keys or payload.keys())
        checksum = self._checksum(payload)
        item = {
            "from_node": str(from_node),
            "to_node": str(to_node),
            "contract_version": CONTRACT_VERSION,
            "payload_keys": keys,
            "payload_checksum": checksum,
            "condition": condition or {},
            "created_at": time.time(),
        }
        self.state["handoffs"].append(item)
        self.state["updated_at"] = time.time()
        self.db.update_task(self.task_id, resume_state=json.dumps(self.state, ensure_ascii=False, default=str, separators=(",", ":")))
        if message:
            self.db.save_task_log(self.task_id, "handoff", message)
        return item

    def finish(self, progress: float = 100, message: str = ""):
        for n in self.nodes:
            if self.state["node_status"].get(n) in ("PENDING", "RUNNING"):
                self.state["node_status"][n] = "SUCCESS"
        self.state["current_node"] = "COMPLETED"
        self.state["updated_at"] = time.time()
        self.db.update_task(
            self.task_id,
            current_stage="COMPLETED",
            current_node="COMPLETED",
            progress_pct=float(progress),
            resume_state=json.dumps(self.state, ensure_ascii=False, default=str, separators=(",", ":")),
        )
        if message:
            self.db.save_task_log(self.task_id, "postflow", message)
