# -*- coding: utf-8 -*-
"""PSV System Orchestrator (FULL AUDITED & HARDENED)

Fixes:
1. Unified network expansion entry: expand_network_batch()
3. Unified enrichment entry: enrich_entity()
4. Unified business entry: start_development()
5. Orchestrator has full flow control
6. Task state management and failure recovery
7. Parallel task scheduling
8. Failure handling: classify error -> select strategy -> record summary
9. Auto-schedule enrichment after expansion

当前加固：
- 处理 stop_condition 的 switch_strategy 信号
- 自动注入未尝试策略
- 新增 _get_round_stats / _get_tried_strategies / _inject_strategies 辅助方法
"""
import json, time, uuid, re, threading
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from core.memory.db import DB
from core.intelligence.account_intelligence_center import AccountIntelligenceCenter
from core.intelligence.waterfall import WaterfallEnrichmentEngine
from core.business_execution.execution_center import BusinessExecutionCenter
from core.trade_graph.visualization import TradeGraphVisualization
from core.runtime.orchestrator import Orchestrator as CollectionOrchestrator
from core.runtime.postflow import PostFlowTracker


class PSVSystem:
    """Main Orchestrator. Controls entire post-collection flow."""

    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.intelligence_center = AccountIntelligenceCenter(self.db)
        self.waterfall_engine = WaterfallEnrichmentEngine(self.db)
        self.execution_center = BusinessExecutionCenter(self.db)
        self.trade_graph = TradeGraphVisualization(self.db)
        self.collection_orchestrator = CollectionOrchestrator()
        self._executor = ThreadPoolExecutor(max_workers=4)
        # 网页 DeepSeek 只能由一个后台 worker 串行使用同一 CDP 会话，避免多个客户同时抢一个页面。
        self._enrichment_executor = ThreadPoolExecutor(max_workers=1)
        self._enrichment_worker_lock = threading.Lock()
        self._enrichment_worker_running = False
        # 业务执行同样采用单队列串行循环：每个客户先完成信息补全，再跑业务节点，最后处理 Outlook。
        self._business_executor = ThreadPoolExecutor(max_workers=1)
        self._business_worker_lock = threading.Lock()
        self._business_worker_running = False
        self._recover_stale_queues()
        from core.runtime.scheduler import OneShotScheduler
        self.scheduler = OneShotScheduler(self)
        self.scheduler.start()


    # ========== First Collection Chain (FROZEN / SINGLE ENTRY) ==========
    def run_collection(self, request: str, market: str = 'USA', industry: str = 'enamel pot',
                       quantity: int = 20, task_id: str = None, auto_expand: bool = False) -> Dict[str, Any]:
        """Run the original nine-node customs/trade collection chain unchanged.
        The nine nodes end at DATABASE_COMMIT. Post-collection enrichment/network work is
        scheduled only after that boundary and never blocks the frozen chain.
        """
        result = self.collection_orchestrator.run(request=request, market=market, industry=industry,
                                                  quantity=quantity, task_id=task_id)
        try:
            category_id={'birthday candles':'candle','candle':'candle','enamel pot':'enamel_pot','felt':'felt'}.get(str(industry).lower(),str(industry))
            self._sync_collection_assets(result, market=market, industry=industry, task_id=result.get('task_id'))
            self._enqueue_collection_customers(category_id, result.get('task_id') or task_id)
            if auto_expand and str(result.get('status') or '').lower() in ('done','completed','success'):
                self.expand_network_batch(category_id=category_id, parent_task_id=result.get('task_id') or task_id)
                result['post_collection_network']='scheduled'
        except Exception as e:
            result.setdefault('warnings', []).append('post_collection_schedule_failed: '+str(e)[:300])
        return result

    def _sync_collection_assets(self, result: Dict[str, Any], market: str, industry: str, task_id: str = None):
        """Post-collection adapter only: sync this collection task's shared assets.

        The frozen chain remains untouched.  We deliberately scope the sync to the
        current task's customer/supplier pools and relationship rows so one product
        run cannot accidentally relabel entities from another product domain.
        """
        category_id = next((k for k,v in {'candle':'蜡烛','enamel_pot':'珐琅锅','felt':'毛毡'}.items() if v==industry), industry if industry in {'candle','enamel_pot','felt'} else 'enamel_pot')
        task_id=str(task_id or '')
        norms=[]
        try:
            with self.db.c() as x:
                x.row_factory=__import__('sqlite3').Row
                if task_id:
                    rows=x.execute("SELECT norm FROM customer_pool WHERE category_id=? AND source_task_id=? UNION SELECT norm FROM supplier_pool WHERE category_id=? AND source_task_id=?",(category_id,task_id,category_id,task_id)).fetchall()
                    norms=[str(r['norm']) for r in rows if r['norm']]
                if not norms and task_id:
                    rows=x.execute("SELECT DISTINCT from_norm AS norm FROM relationships WHERE task_id=? UNION SELECT DISTINCT to_norm AS norm FROM relationships WHERE task_id=?",(task_id,task_id)).fetchall()
                    norms.extend(str(r['norm']) for r in rows if r['norm'])
                norms=list(dict.fromkeys(norms))
                leads={r['norm']:dict(r) for r in x.execute("SELECT * FROM leads WHERE norm IN (%s)" % ','.join('?' for _ in norms),norms).fetchall()} if norms else {}
        except Exception:
            leads={}; norms=[]
        for norm,row in leads.items():
            ent=self.db.get_or_create_entity(norm,row.get('name') or norm)
            fields={k:row.get(k) for k in ('name','country','address','website','phone','industry','product_categories','brand') if row.get(k)}
            if row.get('product_domain') and not fields.get('product_categories'): fields['product_categories']=row.get('product_domain')
            if row.get('source'): fields['data_source']=row.get('source')
            if row.get('score') is not None: fields['value_score_total']=float(row.get('score') or 0)
            if fields: self.db.update_entity(norm,**fields)
            role='supplier' if row.get('kind')=='supplier' else 'customer'
            self.db.set_entity_role(ent['entity_id'],role); self.db.set_entity_category(ent['entity_id'],category_id)
            if role=='supplier': self.db.add_to_supplier_pool(norm,row.get('name') or norm,category_id,row.get('source') or 'customs',task_id)
            else: self.db.add_to_customer_pool(norm,row.get('name') or norm,category_id,row.get('source') or 'customs',task_id)
        # Relationship rows from this task are the only legacy edge records imported.
        if task_id:
            with self.db.c() as x:
                x.row_factory=__import__('sqlite3').Row
                rels=[dict(r) for r in x.execute('SELECT * FROM relationships WHERE task_id=?',(task_id,)).fetchall()]
            for r in rels:
                fn,tn=r.get('from_norm'),r.get('to_norm')
                if not fn or not tn: continue
                fe=self.db.get_or_create_entity(fn,r.get('from_name') or fn); te=self.db.get_or_create_entity(tn,r.get('to_name') or tn)
                ft=str(r.get('from_type') or '').lower(); tt=str(r.get('to_type') or '').lower()
                if ft in ('customer','importer','buyer'): self.db.set_entity_role(fe['entity_id'],'customer')
                elif ft in ('supplier','shipper','exporter'): self.db.set_entity_role(fe['entity_id'],'supplier')
                if tt in ('customer','importer','buyer'): self.db.set_entity_role(te['entity_id'],'customer')
                elif tt in ('supplier','shipper','exporter'): self.db.set_entity_role(te['entity_id'],'supplier')
                self.db.set_entity_category(fe['entity_id'],category_id); self.db.set_entity_category(te['entity_id'],category_id)
                raw_relation=r.get('relation') or 'trades_with'
                relation_map={'buyer_to_supplier':'supplier_of','supplier_to_buyer':'customer_of','supplier_to_customer':'customer_of','customer_to_supplier':'supplier_of'}
                relation=relation_map.get(raw_relation,raw_relation if raw_relation in {'supplier_of','customer_of','trades_with'} else 'trades_with')
                ev=r.get('evidence'); ev=json.dumps(ev,ensure_ascii=False) if isinstance(ev,dict) else ev
                self.db.save_trade_edge(fn,tn,relation,product=r.get('product'),hs_code=r.get('hs'),shipment_count=int(r.get('shipment_count') or 0),evidence=ev,source_type=r.get('source') or 'customs_raw',confidence=float(r.get('confidence') or 0),category_id=category_id)

    # ========== Network Expansion (Single Entry) ==========

    def expand_network_batch(self, seed_norms=None, category_id: str = None,
                             buyers_per: int = None, suppliers_per: int = None,
                             customers_per: int = None, max_new: int = None,
                             root_domain: str = None, parent_task_id: str = None) -> Dict[str, Any]:
        """第二核心链：两轮完整裂变。共享数据库承担实体唯一化，重复发现留痕。"""
        task_id=f"net2-{uuid.uuid4().hex[:8]}"
        from core.tools.expand import run_network_two_rounds
        self.db.create_task(task_id=task_id,task_name='网络扩张 · 共享实体两轮海关贸易裂变',
                            task_type='network_expansion_batch',category_id=category_id,parent_task_id=parent_task_id)
        self.db.update_task(task_id,run_status='running',current_stage='INPUT_CUSTOMERS',current_node='INPUT_CUSTOMERS',progress_pct=0)
        self._executor.submit(self._run_network_batch, task_id, seed_norms, category_id,
                              buyers_per, suppliers_per, customers_per, max_new, root_domain)
        return {'task_id':task_id,'status':'running','accepted':True,'rounds':2,
                'model':'customer→supplier→customer × 2','enrichment_decoupled':True}

    def _run_network_batch(self, task_id, seed_norms, category_id, buyers_per, suppliers_per, customers_per, max_new, root_domain):
        try:
            from core.tools.expand import run_network_two_rounds
            result=run_network_two_rounds(task_id=task_id, seed_norms=seed_norms, category_id=category_id,
                                          buyers_per=buyers_per, suppliers_per=suppliers_per,
                                          customers_per=customers_per, max_new=max_new, root_domain=root_domain or '')
            if result.get('status')=='completed':
                queued=0
                for norm in result.get('discovered_customer_norms',[]) or []:
                    if norm and self._add_to_enrichment_queue(norm, category_id, task_id): queued += 1
                self.db.save_task_log(task_id,'orchestrator',
                                      f"网络扩张完成：新增客户={result.get('new_customers',0)}，新增供应商={result.get('new_suppliers',0)}，贸易边={result.get('new_edges',0)}，信息补全入队={queued}（等待信息补全中心启动）")
            else:
                self.db.save_task_log(task_id,'orchestrator',f"网络扩张未完成：{result.get('errors') or result.get('status')}")
        except Exception as e:
            self.db.update_task(task_id,run_status='failed',failure_reason=str(e)[:500],current_stage='FAILED',current_node='FAILED')
            self.db.save_task_log(task_id,'orchestrator',f'网络扩张异常：{str(e)[:400]}')

    def _enqueue_collection_customers(self, category_id: str, source_task_id: str = None):
        """第一采集链 END 后把客户资产放入独立信息补全队列；不改变九节点结果。"""
        rows=[]
        try:
            with self.db.c() as x:
                if source_task_id:
                    rows=x.execute("SELECT norm FROM customer_pool WHERE category_id=? AND source_task_id=?",(category_id,source_task_id)).fetchall()
                if not rows:
                    rows=x.execute("SELECT norm FROM customer_pool WHERE category_id=? ORDER BY added_at DESC LIMIT 10000",(category_id,)).fetchall()
        except Exception: rows=[]
        queued=0
        for r in rows:
            n=str(r[0] or '').strip()
            if n and self._add_to_enrichment_queue(n,category_id,source_task_id or 'collection'): queued+=1
        if source_task_id: self.db.save_task_log(source_task_id,'post_collection',f'九节点结束：客户进入独立信息补全队列 {queued} 家；等待信息补全中心手动启动')
        return queued

    def _recover_stale_queues(self, stale_seconds: int = 3600):
        """Recover queue rows left RUNNING by a crashed/restarted process."""
        cutoff=time.time()-int(stale_seconds)
        with self.db.c() as x:
            x.execute("UPDATE enrichment_queue SET status='pending', started_at=NULL WHERE status='running' AND COALESCE(started_at,0)<?",(cutoff,))
            x.execute("UPDATE business_queue SET status='pending', started_at=NULL WHERE status='running' AND COALESCE(started_at,0)<?",(cutoff,))
            x.execute("UPDATE tasks SET run_status='pending', current_stage='QUEUED', current_node='QUEUED', progress_pct=0, failure_reason='Recovered stale queue task after worker restart' WHERE run_status='running' AND COALESCE(updated_at,0)<? AND task_type IN ('information_enrichment','business_queue')",(cutoff,))
            x.commit()

    def _add_to_enrichment_queue(self, norm: str, category_id: str, source_task_id: str):
        queue_id = f"q-{uuid.uuid4().hex[:8]}"
        with self.db.c() as x:
            existing=x.execute("SELECT queue_id FROM enrichment_queue WHERE norm=? AND COALESCE(category_id,'')=COALESCE(?,'') AND status IN ('pending','running','waiting_expert','completed','completed_degraded') LIMIT 1",(norm,category_id)).fetchone()
            if existing: return False
            x.execute("INSERT INTO enrichment_queue (queue_id,norm,category_id,source_task_id,status,priority,created_at) VALUES (?,?,?,?, 'pending',5,?)",
                       (queue_id,norm,category_id,source_task_id,time.time()))
            x.commit()
        self.db.create_task(queue_id,f'信息补全 · {norm}','information_enrichment',category_id,source_task_id)
        self.db.update_task(queue_id,run_status='pending',current_stage='QUEUED',current_node='QUEUED',progress_pct=0)
        return True

    def _kick_enrichment_worker(self):
        with self._enrichment_worker_lock:
            if self._enrichment_worker_running: return
            self._enrichment_worker_running=True
            self._enrichment_executor.submit(self._run_enrichment_worker_loop)

    @staticmethod
    def _valid_email(value):
        return bool(re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]{2,}$',str(value or '').strip()))

    @staticmethod
    def _valid_phone(value):
        v=str(value or '').strip()
        digits=re.sub(r'\D','',v)
        if len(digits)<7 or len(digits)>15: return False
        return len(set(digits))>1

    def _enrichment_subject(self,norm):
        ent=self.db.get_entity(norm) or {}; lead=self.db.get_lead(norm) or {}
        contacts=self.db.list_entity_contacts(ent.get('entity_id')) if ent.get('entity_id') else []
        all_claims=self.db.list_data_claims(norm,limit=120)
        priority={'invalid','suspect','candidate','not_found'}
        claims=[c for c in all_claims if str(c.get('status') or '').lower() in priority][:10]
        # 仅给专家最近三条贸易事实 + 当前缺口；不把整份客户档案塞进一次模型调用。
        customs=[]
        try:
            with self.db.c() as x:
                x.row_factory=__import__('sqlite3').Row
                customs=[dict(r) for r in x.execute("""SELECT importer,shipper,notify,hs,descr,ts FROM customs_raw
                    WHERE importer_norm=? OR notify=? ORDER BY ts DESC LIMIT 2""",(norm,norm)).fetchall()]
        except Exception: pass
        return {'entity':{k:ent.get(k,'') for k in ('name','original_name','country','address','website','phone','enterprise_type','industry','product_categories','brand')},
                'lead':{k:lead.get(k,'') for k in ('name','country','website','emails','phones','address','contact_person','linkedin')},
                'contacts':contacts[:3],'claims':claims,'customs_records':customs}

    def _apply_expert_review(self,norm,review):
        ent=self.db.get_entity(norm) or {}; entity_id=ent.get('entity_id')
        identity=str(review.get('identity') or 'suspect')
        conf=float(review.get('confidence') or 0)
        status={'confirmed':'confirmed','rejected':'rejected','suspect':'pending_expert','degraded':'pending_expert'}.get(identity,'pending_expert')
        reason=review.get('reason') or ''
        self.db.set_identity_review(norm,status=status,confidence=conf,canonical_name=review.get('canonical_name') or '',
                                    aliases=[],review=review)
        # 字段级结果全部留痕；verified 才能提升该 claim 的可信度，invalid 只标记，不删除。
        for c in review.get('fields') or []:
            if not isinstance(c,dict): continue
            field=str(c.get('field') or '').strip(); value=str(c.get('value') or '').strip()
            if not field or not value: continue
            st=str(c.get('status') or 'suspect').lower()
            claim=self.db.save_data_claim(norm,field,value,source='deepseek_web',source_url=c.get('source') or '',
                                          status=st,confidence=conf,expert_review=c)
            if claim: self.db.update_data_claim(claim,status=st,confidence=conf,expert_review=c)
            # 同值候选来自不同来源时也同步专家结论；不同值继续并存。
            for old_claim in self.db.list_data_claims(norm,field=field,limit=200):
                if str(old_claim.get('value') or '').strip().lower()==value.lower():
                    self.db.update_data_claim(old_claim.get('claim_id'),status=st,confidence=max(conf,float(old_claim.get('confidence') or 0)),expert_review=c)
            # 只有空字段才自动成为主字段；冲突值继续并存，不覆盖旧值。
            if st=='verified' and field in ('website','address','phone') and not ent.get(field):
                self.db.update_entity(norm,**{field:value})
        for c in review.get('contacts') or []:
            if not isinstance(c,dict): continue
            name=str(c.get('name') or '').strip(); email=str(c.get('email') or '').strip(); phone=str(c.get('phone') or '').strip()
            verified=1 if str(c.get('status') or '').lower()=='verified' else 0
            if entity_id and (name or email or phone):
                self.db.save_contact(entity_id,name=name or 'Unknown Contact',title=c.get('title') or '',email=email or None,phone=phone or None,source=c.get('source') or 'deepseek_web',verified=verified)
            if email: self.db.save_data_claim(norm,'email',email,source='deepseek_web',source_url=c.get('source') or '',status='verified' if verified else 'suspect',confidence=conf,expert_review=c)
            if phone: self.db.save_data_claim(norm,'phone',phone,source='deepseek_web',source_url=c.get('source') or '',status='verified' if verified else 'suspect',confidence=conf,expert_review=c)
            if name: self.db.save_data_claim(norm,'contact_person',name,source='deepseek_web',source_url=c.get('source') or '',status='verified' if verified else 'suspect',confidence=conf,expert_review=c)
        return status

    def _process_enrichment_item(self, queue_row, webai=None, preflight=None):
        qid,norm,category_id=queue_row['queue_id'],queue_row['norm'],queue_row['category_id']
        flow=PostFlowTracker(self.db,qid,'information_enrichment',['SHARED_INPUT','WATERFALL_CANDIDATES','WEB_EXPERT_VERIFY','COMPLETED'])
        flow.checkpoint('SHARED_INPUT','RUNNING',5,shared_data={'source_task_id':queue_row.get('source_task_id'),'shared_tables':['entities','entity_data_claims','contacts','trade_edges','customer_pool']},message=f'读取共享节点数据：{norm}')
        self.db.update_task(qid,run_status='running',current_stage='COLLECT_MISSING',current_node='COLLECT_MISSING',progress_pct=15)
        flow.checkpoint('WATERFALL_CANDIDATES','RUNNING',15,shared_data={'candidate_scope':'missing_fields + source claims'},message=f'确定性补全开始：{norm}')
        try:
            result=self.intelligence_center.enrich(norm,category_id=category_id,force=False)
        except Exception as e:
            result={'ok':False,'error':str(e)[:300]}
        self.db.update_task(qid,current_stage='WEB_EXPERT_VERIFY',current_node='WEB_EXPERT_VERIFY',progress_pct=55)
        subject=self._enrichment_subject(norm)
        flow.handoff('WATERFALL_CANDIDATES','WEB_EXPERT_VERIFY',{'norm':norm,'candidate_claims':len(subject.get('claims',[])),'customs_records':len(subject.get('customs_records',[]))},['norm','candidate_claims','customs_records'],message='候选资料交接给网页专家：只核验，不改变贸易事实')
        # 先做确定性明显错误筛查，不删除；把错误候选标为 invalid，供专家看到。
        for c in subject.get('claims',[]):
            if c.get('field')=='email' and not self._valid_email(c.get('value')):
                self.db.update_data_claim(c.get('claim_id'),'invalid',0.95,{'rule':'email_syntax'})
            if c.get('field')=='phone' and not self._valid_phone(c.get('value')):
                self.db.update_data_claim(c.get('claim_id'),'invalid',0.95,{'rule':'phone_length_or_repeat'})
        expert=None
        if webai and preflight and preflight.get('ok'):
            try: expert=webai.verify_claims(self._enrichment_subject(norm),timeout=getattr(__import__('core.config',fromlist=['settings']).settings,'WEBAI_TIMEOUT',150))
            except Exception as e: expert={'identity':'degraded','confidence':0,'reason':str(e)[:180],'fields':[],'contacts':[],'degraded':True}
        if expert and expert.get('identity')!='degraded':
            status=self._apply_expert_review(norm,expert)
            final='completed' if status in ('confirmed','pending_expert','rejected') else 'completed_degraded'
            note=f"网页专家={expert.get('identity')}；字段核验 {len(expert.get('fields') or [])} 项；联系人 {len(expert.get('contacts') or [])} 个"
        else:
            # WebAI 暂不可用时不伪造“已完成”：瀑布资料可以保留，但任务进入 waiting_expert，
            # worker 释放浏览器资源后可由下一次启动继续处理。这样业务质量不会被“降级完成”掩盖。
            final='waiting_expert'
            note='网页 DeepSeek 暂不可用/未返回可靠结果；确定性资料已保存，任务等待专家复核后继续'
        terminal=final in ('completed','completed_degraded')
        flow.checkpoint('WEB_EXPERT_VERIFY','SUCCESS' if terminal else 'BLOCKED',70 if terminal else 70,shared_data={'expert_status':final,'deterministic_result':bool(result.get('ok'))},condition={'edge':'expert_available','taken':bool(expert and expert.get('identity')!='degraded')},message=note)
        if terminal: flow.finish(100)
        self.db.update_task(qid,run_status=final,current_stage='COMPLETED' if terminal else 'WAIT_EXPERT',
                            current_node='COMPLETED' if terminal else 'WAIT_EXPERT',progress_pct=100 if terminal else 70,
                            completed_at=time.time() if terminal else None,
                            failure_reason='' if terminal else str(result.get('error') or 'DeepSeek expert unavailable'))
        self.db.save_task_log(qid,'enrichment_worker',note)
        with self.db.c() as x:
            x.execute("UPDATE enrichment_queue SET status=?,started_at=COALESCE(started_at,?),completed_at=? WHERE queue_id=?",
                      ('completed' if final=='completed' else ('completed_degraded' if final=='completed_degraded' else 'waiting_expert'),time.time(),time.time() if terminal else None,qid)); x.commit()
        return final

    def _run_enrichment_worker_loop(self):
        webai=None; preflight={}
        try:
            try:
                from core.tools import web_ai
                if getattr(__import__('core.config',fromlist=['settings']).settings,'WEBAI_ENABLED',True):
                    webai=web_ai.WebAI(); preflight=webai.preflight('deepseek')
                    self.db.save_task_log('system','enrichment_worker',f'DeepSeek预检：{preflight.get("stage")} / {preflight.get("error") or "ready"}')
            except Exception as e:
                preflight={'ok':False,'stage':'launch','error':str(e)[:180]}
            # WebAI is the authenticity gate for this queue. If the expert channel is
            # unavailable, stop before spending network time on dozens of customers;
            # the rows remain pending and can be resumed after CDP/login recovery.
            if not preflight.get('ok'):
                try:
                    with self.db.c() as x:
                        x.row_factory=__import__('sqlite3').Row
                        rows=x.execute("SELECT queue_id FROM enrichment_queue WHERE status='pending' LIMIT 20").fetchall()
                    for r in rows:
                        self.db.save_task_log(r['queue_id'],'enrichment_worker',f"网页专家预检未通过：{preflight.get('stage')} / {preflight.get('error') or ''}；保留待处理状态，修复CDP后再启动")
                except Exception: pass
                return
            while True:
                with self.db.c() as x:
                    x.row_factory=__import__('sqlite3').Row
                    row=x.execute("SELECT * FROM enrichment_queue WHERE status='pending' ORDER BY priority ASC,created_at ASC LIMIT 1").fetchone()
                    if not row: break
                    x.execute("UPDATE enrichment_queue SET status='running',started_at=? WHERE queue_id=? AND status='pending'",(time.time(),row['queue_id'])); x.commit()
                try: self._process_enrichment_item(dict(row),webai,preflight)
                except Exception as e:
                    self.db.save_task_log(row['queue_id'],'enrichment_worker',f'处理异常：{str(e)[:250]}')
                    self.db.update_task(row['queue_id'],run_status='failed',current_stage='FAILED',current_node='FAILED',failure_reason=str(e)[:500],completed_at=time.time())
                    with self.db.c() as x:
                        x.execute("UPDATE enrichment_queue SET status='failed',completed_at=? WHERE queue_id=?",(time.time(),row['queue_id'])); x.commit()
        finally:
            if webai:
                try: webai.close()
                except Exception: pass
            with self._enrichment_worker_lock: self._enrichment_worker_running=False
            # 新任务可能恰好在 worker 退出瞬间入队，再次触发一次即可。
            with self.db.c() as x: pending=x.execute("SELECT 1 FROM enrichment_queue WHERE status='pending' LIMIT 1").fetchone()
            if pending: self._kick_enrichment_worker()

    def enrichment_queue(self, category_id=None, limit=100):
        sql='SELECT q.*, t.run_status AS task_run_status, t.current_stage AS task_stage, t.current_node AS task_node, t.progress_pct AS task_progress, t.failure_reason AS task_failure, t.resume_state AS task_state FROM enrichment_queue q LEFT JOIN tasks t ON t.task_id=q.queue_id WHERE 1=1'; args=[]
        if category_id: sql+=' AND q.category_id=?'; args.append(category_id)
        sql+=" ORDER BY CASE q.status WHEN 'running' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END, q.created_at DESC LIMIT ?"; args.append(int(limit))
        with self.db.c() as x:
            x.row_factory=__import__('sqlite3').Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]

    def queue_enrichment(self, norms=None, category_id=None, limit=100):
        if norms is None:
            rows=self.db.list_customer_pool(category_id=category_id)
            norms=[r.get('norm') for r in rows if r.get('norm')][:int(limit)]
        norms=list(dict.fromkeys(str(n).strip() for n in (norms or []) if str(n).strip()))[:int(limit)]
        queued=sum(1 for n in norms if self._add_to_enrichment_queue(n,category_id,'manual'))
        return {'ok':True,'requested':len(norms),'queued':queued,'worker':'not_started'}

    def start_enrichment_worker(self, category_id=None):
        """显式启动信息补全队列；网络扩张/第一采集链只负责入队。
        waiting_expert 是可恢复状态；用户再次点击启动时才重新尝试网页专家。
        """
        with self._enrichment_worker_lock:
            with self.db.c() as x:
                if category_id:
                    x.execute("UPDATE enrichment_queue SET status='pending', completed_at=NULL WHERE status='waiting_expert' AND category_id=?",(category_id,))
                    x.execute("UPDATE tasks SET run_status='pending', current_stage='QUEUED', current_node='QUEUED', progress_pct=0, failure_reason=NULL, completed_at=NULL WHERE task_id IN (SELECT queue_id FROM enrichment_queue WHERE status='pending' AND category_id=?)",(category_id,))
                    pending=x.execute("SELECT COUNT(*) FROM enrichment_queue WHERE status='pending' AND category_id=?",(category_id,)).fetchone()[0]
                else:
                    x.execute("UPDATE enrichment_queue SET status='pending', completed_at=NULL WHERE status='waiting_expert'")
                    x.execute("UPDATE tasks SET run_status='pending', current_stage='QUEUED', current_node='QUEUED', progress_pct=0, failure_reason=NULL, completed_at=NULL WHERE task_id IN (SELECT queue_id FROM enrichment_queue WHERE status='pending')")
                    pending=x.execute("SELECT COUNT(*) FROM enrichment_queue WHERE status='pending'").fetchone()[0]
                x.commit()
            if pending <= 0:
                return {'ok':True,'started':False,'pending':0,'message':'没有待处理的补全任务'}
            # Explicit start performs the same small WebAI preflight as the worker,
            # so a missing CDP/login is reported immediately instead of after a long queue run.
            try:
                from core.tools import web_ai
                if getattr(__import__('core.config',fromlist=['settings']).settings,'WEBAI_ENABLED',True):
                    probe=web_ai.WebAI()
                    try: preflight=probe.preflight('deepseek')
                    finally: probe.close()
                    if not preflight.get('ok'):
                        return {'ok':False,'started':False,'pending':int(pending),'message':f"网页专家预检失败：{preflight.get('stage')} / {preflight.get('error') or ''}",'preflight':preflight}
            except Exception as e:
                return {'ok':False,'started':False,'pending':int(pending),'message':f'网页专家预检异常：{str(e)[:200]}','preflight':{'ok':False,'stage':'exception','error':str(e)[:200]}}
            if self._enrichment_worker_running:
                return {'ok':True,'started':False,'pending':int(pending),'message':'信息补全队列正在执行'}
            self._enrichment_worker_running=True
            self._enrichment_executor.submit(self._run_enrichment_worker_loop)
            return {'ok':True,'started':True,'pending':int(pending),'message':'信息补全队列已启动'}

    def _enrichment_status_counts(self, category_id=None):
        sql="SELECT status,COUNT(*) n FROM enrichment_queue WHERE 1=1"; args=[]
        if category_id: sql+=" AND category_id=?"; args.append(category_id)
        sql+=" GROUP BY status"
        with self.db.c() as x:
            return {str(r[0]):int(r[1]) for r in x.execute(sql,args).fetchall()}

    # ========== Enrichment (Single Entry) ==========
    def enrich_entity(self, norm: str, category_id: str = None,
                      force: bool = False) -> Dict[str, Any]:
        self.db.save_task_log(f"enrich-{norm}", 'orchestrator', f"Starting enrichment for {norm}")
        try:
            result = self.waterfall_engine.enrich_entity(norm, category_id=category_id, force=force)
            entity = self.db.get_entity(norm)
            if entity:
                self.db.transition_lifecycle(
                    entity_id=entity['entity_id'],
                    from_state=self.db.get_current_lifecycle_state(entity['entity_id']),
                    to_state='ENRICHED',
                    reason=f"Waterfall enrichment completed. Completeness: {result.get('completeness', 0)}%",
                    actor='orchestrator'
                )
            return result
        except Exception as e:
            return {'norm': norm, 'error': str(e), 'completeness': 0}

    def batch_enrich(self, norms: List[str], category_id: str = None) -> List[Dict]:
        results = []
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = {executor.submit(self.enrich_entity, n, category_id): n for n in norms}
            for future in as_completed(futures):
                norm = futures[future]
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    results.append({'norm': norm, 'error': str(e)})
        return results

    def _add_to_business_queue(self, norm, category_id, mode='draft', our_product=None, our_company=None, priority=5):
        qid=f"bq-{uuid.uuid4().hex[:10]}"
        with self.db.c() as x:
            existing=x.execute("SELECT queue_id FROM business_queue WHERE norm=? AND COALESCE(category_id,'')=COALESCE(?,'') AND status IN ('pending','running','waiting_enrichment') LIMIT 1",(norm,category_id)).fetchone()
            if existing: return False,existing[0]
            x.execute("INSERT INTO business_queue(queue_id,norm,category_id,mode,our_product,our_company,status,priority,created_at) VALUES(?,?,?,?,?,?, 'pending',?,?)",
                       (qid,norm,category_id,mode,our_product or '',our_company or '',int(priority),time.time()))
            x.commit()
        self.db.create_task(qid,f'业务执行队列 · {norm}','business_queue',category_id,None)
        self.db.update_task(qid,run_status='pending',current_stage='QUEUED',current_node='QUEUED',progress_pct=0)
        return True,qid

    def queue_business(self, norms=None, category_id=None, mode='draft', our_product=None, our_company=None, limit=100):
        if norms is None:
            rows=self.db.list_business_customers(category_id=category_id,limit=int(limit))
            norms=[r.get('norm') for r in rows if r.get('norm')]
        norms=list(dict.fromkeys(str(n).strip() for n in (norms or []) if str(n).strip()))[:int(limit)]
        queued=[]
        for n in norms:
            ok,qid=self._add_to_business_queue(n,category_id,mode,our_product,our_company)
            if ok: queued.append(qid)
        return {'ok':True,'requested':len(norms),'queued':len(queued),'queue_ids':queued,'worker':'not_started'}

    def business_queue(self, category_id=None, limit=200):
        sql="SELECT b.*, t.run_status AS task_run_status, t.current_stage AS task_stage, t.current_node AS task_node, t.progress_pct AS task_progress, t.failure_reason AS task_failure, t.resume_state AS task_state FROM business_queue b LEFT JOIN tasks t ON t.task_id=b.queue_id WHERE 1=1"; args=[]
        if category_id: sql+=" AND b.category_id=?"; args.append(category_id)
        sql+=" ORDER BY CASE b.status WHEN 'running' THEN 0 WHEN 'waiting_enrichment' THEN 1 WHEN 'pending' THEN 2 ELSE 3 END, b.created_at DESC LIMIT ?"; args.append(int(limit))
        with self.db.c() as x:
            x.row_factory=__import__('sqlite3').Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]

    def start_business_worker(self, category_id=None):
        with self._business_worker_lock:
            with self.db.c() as x:
                if category_id:
                    pending=x.execute("SELECT COUNT(*) FROM business_queue WHERE category_id=? AND status IN ('pending','waiting_enrichment')",(category_id,)).fetchone()[0]
                else:
                    pending=x.execute("SELECT COUNT(*) FROM business_queue WHERE status IN ('pending','waiting_enrichment')").fetchone()[0]
            if pending<=0: return {'ok':True,'started':False,'pending':0,'message':'没有待处理业务任务'}
            if self._business_worker_running: return {'ok':True,'started':False,'pending':int(pending),'message':'业务队列正在执行'}
            self._business_worker_running=True
            self._business_executor.submit(self._run_business_worker_loop, category_id)
            return {'ok':True,'started':True,'pending':int(pending),'message':'业务执行队列已启动'}

    def _business_wait_enrichment(self, norm, category_id, task_id, timeout=1800):
        """每个客户业务循环前确保其独立补全任务已终态；不在业务线程内直接跑瀑布。"""
        self._add_to_enrichment_queue(norm,category_id,task_id)
        self._kick_enrichment_worker()
        deadline=time.time()+timeout
        while time.time()<deadline:
            with self.db.c() as x:
                row=x.execute("SELECT status FROM enrichment_queue WHERE norm=? AND COALESCE(category_id,'')=COALESCE(?,'') ORDER BY created_at DESC LIMIT 1",(norm,category_id)).fetchone()
            status=str(row[0]) if row else 'pending'
            self.db.update_task(task_id,current_stage='WAIT_ENRICHMENT',current_node='WAIT_ENRICHMENT',progress_pct=15)
            if status in ('completed','completed_degraded','failed','waiting_expert'):
                return status
            time.sleep(2)
        return 'timeout'

    def _run_business_worker_loop(self, category_id=None):
        try:
            while True:
                with self.db.c() as x:
                    x.row_factory=__import__('sqlite3').Row
                    # waiting_enrichment 不是可立即执行的任务：优先拿真正 pending 的客户，
                    # 避免同一个等待任务在 worker 内形成空转循环。
                    if category_id:
                        row=x.execute("SELECT * FROM business_queue WHERE category_id=? AND status='pending' ORDER BY priority ASC,created_at ASC LIMIT 1",(category_id,)).fetchone()
                    else:
                        row=x.execute("SELECT * FROM business_queue WHERE status='pending' ORDER BY priority ASC,created_at ASC LIMIT 1").fetchone()
                    if not row:
                        if category_id:
                            row=x.execute("SELECT * FROM business_queue WHERE category_id=? AND status='waiting_enrichment' ORDER BY priority ASC,created_at ASC LIMIT 1",(category_id,)).fetchone()
                        else:
                            row=x.execute("SELECT * FROM business_queue WHERE status='waiting_enrichment' ORDER BY priority ASC,created_at ASC LIMIT 1").fetchone()
                    if not row: break
                    q=dict(row)
                    x.execute("UPDATE business_queue SET status='running',started_at=? WHERE queue_id=? AND status IN ('pending','waiting_enrichment')",(time.time(),q['queue_id'])); x.commit()
                qid=q['queue_id']; norm=q['norm']; cat=q['category_id']; mode=q['mode'] or 'draft'
                queue_flow=PostFlowTracker(self.db,qid,'business_execution_queue',['WAIT_ENRICHMENT','BUSINESS_FLOW'])
                queue_flow.checkpoint('WAIT_ENRICHMENT','RUNNING',5,shared_data={'norm':norm,'category_id':cat,'mode':mode,'shared_tables':['entities','entity_data_claims','contacts','trade_edges']},message=f'业务队列领取客户：{norm}')
                self.db.update_task(qid,run_status='running',current_stage='WAIT_ENRICHMENT',current_node='WAIT_ENRICHMENT',progress_pct=10)
                self.db.save_task_log(qid,'business_queue','业务客户循环开始：先完成独立信息补全，再执行业务流程节点')
                est=self._business_wait_enrichment(norm,cat,qid)
                if est=='timeout':
                    result={'ok':False,'stage':'enrichment_timeout','error':'信息补全等待超过30分钟'}
                    queue_flow.checkpoint('WAIT_ENRICHMENT','FAILED',60,shared_data={'enrichment_status':est,'error':result['error']},condition={'edge':'enrichment_terminal','taken':False},message=result['error'])
                elif est=='waiting_expert':
                    result={'ok':False,'stage':'waiting_expert','error':'信息补全已完成确定性资料，但网页 DeepSeek 尚未完成专家核验','action_required':'WAIT_ENRICHMENT'}
                    queue_flow.checkpoint('WAIT_ENRICHMENT','BLOCKED',60,shared_data={'enrichment_status':est},condition={'edge':'expert_ready','taken':False},message=result['error'])
                else:
                    queue_flow.handoff('WAIT_ENRICHMENT','BUSINESS_FLOW',{'norm':norm,'enrichment_status':est},['norm','enrichment_status'],condition={'edge':'enrichment_terminal','taken':True},message=f'信息补全→业务流程：{est}')
                    # BusinessExecutionCenter owns the detailed node contract/checkpoint state from this point onward.
                    result=self.execution_center.execute_business_flow(norm,category_id=cat,our_product=q.get('our_product'),our_company=q.get('our_company'),mode=mode,allow_inline_enrichment=False,task_id=qid)
                final='done' if result.get('ok') else ('waiting_enrichment' if result.get('action_required')=='WAIT_ENRICHMENT' else 'failed')
                self.db.update_task(qid,run_status=final,current_stage='COMPLETED' if final=='done' else str(result.get('stage') or 'FAILED').upper(),current_node='COMPLETED' if final=='done' else str(result.get('stage') or 'FAILED').upper(),progress_pct=100 if final=='done' else 60,failure_reason='' if final=='done' else str(result.get('error') or result.get('reason') or ''),completed_at=time.time() if final in ('done','failed') else None)
                with self.db.c() as x:
                    x.execute("UPDATE business_queue SET status=?,completed_at=?,last_error=?,task_id=? WHERE queue_id=?",(final,time.time() if final in ('done','failed') else None,str(result.get('error') or result.get('reason') or ''),result.get('task_id') or qid,qid)); x.commit()
                self.db.save_task_log(qid,'business_queue',f"客户业务循环结束：{final}；{result.get('stage') or ''}")
        finally:
            with self._business_worker_lock: self._business_worker_running=False

    def execute_business_flow(self, lead_norm: str, category_id: str = None,
                             our_product: str = None, our_company: str = None,
                             mode: str = 'draft', allow_inline_enrichment: bool = True) -> Dict[str, Any]:
        """业务中心统一执行入口：资料审核→详细画像→补全→资格→开发信→草稿/发送。"""
        return self.execution_center.execute_business_flow(
            lead_norm, category_id=category_id, our_product=our_product,
            our_company=our_company, mode=mode, allow_inline_enrichment=allow_inline_enrichment
        )

    # ========== Business Development (Single Entry) ==========
    def start_development(self, lead_norm: str, our_product: str = None,
                          our_company: str = None) -> Dict[str, Any]:
        qualification = self.execution_center.qualify_for_development(lead_norm)
        if not qualification['qualified']:
            return {
                'ok': False,
                'stage': 'qualification_failed',
                'reason': qualification['reason'],
                'checks': qualification['checks']
            }

        letter = self.execution_center.generate_development_letter(
            lead_norm, our_product=our_product, our_company=our_company
        )
        if not letter.get('ok'):
            return {'ok':False,'stage':'letter_generation_failed','qualification':qualification,'letter':letter}
        # Outlook is a browser-only transport in this deployment. When enabled,
        # generation is immediately followed by opening the persistent Outlook
        # session and clicking Send; there is no artificial manual review gate.
        if getattr(__import__('core.config',fromlist=['settings']).settings,'OUTLOOK_AUTO_SEND',True):
            send=self.execution_center.open_outlook_and_send(letter['record_id'])
            letter['send_status']=send.get('status')
            letter['send_result']=send
            if not send.get('ok'):
                letter['error']=send.get('error')
        return {'ok':True,'stage':'outreach_executed' if letter.get('send_status')=='SENT' else 'letter_generated',
                'qualification':qualification,'letter':letter}

    # ========== Task Management ==========
    def get_task_status(self, task_id: str) -> Optional[Dict]:
        return self.db.get_task(task_id)

    # ========== Helper Methods for Stop Condition ==========
    def _get_round_stats(self, task_id: str, current_round: int) -> Dict:
        """获取最近轮次的信息增益统计"""
        with self.db.c() as x:
            rows = x.execute("""
                SELECT round_num, strategy, total_gain 
                FROM info_gain 
                WHERE task_id=? AND round_num > ?
                ORDER BY round_num DESC LIMIT 10
            """, (task_id, current_round - 10)).fetchall()
        return {
            'recent_rounds': [
                {'round_num': r[0], 'strategy': r[1], 'total_gain': r[2]} 
                for r in rows
            ]
        }

    def pause_task(self, task_id: str) -> bool:
        self.db.pause_task(task_id)
        self.db.save_task_log(task_id, 'orchestrator', f"Task {task_id} paused by user")
        return True

    def resume_task(self, task_id: str) -> bool:
        self.db.resume_task(task_id)
        self.db.save_task_log(task_id, 'orchestrator', f"Task {task_id} resumed by user")
        return True
