# -*- coding: utf-8 -*-
"""行业品类配置加载模块"""
import json
from pathlib import Path
from core.config import settings

CONFIG_DIR = Path(settings.PROJECT_ROOT) / "data" / "industry_configs"

def load_industry(key=None):
    key = key or getattr(settings, 'INDUSTRY', 'candle')
    path = CONFIG_DIR / f"{key}.json"
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "key": key,
        "name": key,
        "name_en": key,
        "search_terms": [key],
        "hs_codes": [],
        "keywords": [key],
        "pitch_facts": [f"We specialize in {key}."],
        "industry_context": key,
    }

def list_industries():
    out = []
    for fp in CONFIG_DIR.glob("*.json"):
        with open(fp, "r", encoding="utf-8") as f:
            out.append(json.load(f))
    return out

def save_industry(config):
    """新增/更新品类配置；更新已有品类时保留未提交的高级字段。"""
    key=str(config.get('key') or '').strip().lower().replace(' ','_')
    if not key or not key.replace('_','').isalnum(): return False
    CONFIG_DIR.mkdir(parents=True,exist_ok=True)
    path=CONFIG_DIR/f'{key}.json'
    existing={}
    if path.exists():
        try: existing=json.loads(path.read_text(encoding='utf-8'))
        except Exception: existing={}
    def _lst(v):
        if isinstance(v,(list,tuple)): return [str(x).strip() for x in v if str(x).strip()]
        return [x.strip() for x in str(v or '').split(',') if x.strip()]
    base=dict(existing)
    base.update({'key':key,
                 'name':str(config.get('name') or existing.get('name') or key).strip(),
                 'name_en':str(config.get('name_en') or existing.get('name_en') or key).strip()})
    if 'search_terms' in config: base['search_terms']=_lst(config.get('search_terms'))
    elif 'search_terms' not in base: base['search_terms']=[key]
    if 'keywords' in config: base['keywords']=_lst(config.get('keywords'))
    elif 'keywords' not in base: base['keywords']=[key]
    if 'hs_codes' in config: base['hs_codes']=_lst(config.get('hs_codes'))
    elif 'hs_codes' not in base: base['hs_codes']=[]
    if 'exclusions' in config: base['exclusions']=_lst(config.get('exclusions'))
    if 'materials' in config: base['materials']=_lst(config.get('materials'))
    if 'applications' in config: base['applications']=_lst(config.get('applications'))
    if 'pitch_facts' in config: base['pitch_facts']=_lst(config.get('pitch_facts'))
    if 'industry_context' in config: base['industry_context']=str(config.get('industry_context') or base.get('name') or key).strip()
    elif 'industry_context' not in base: base['industry_context']=base.get('name') or key
    path.write_text(json.dumps(base,ensure_ascii=False,indent=2),encoding='utf-8')
    return True

def delete_industry(key):
    path=CONFIG_DIR/f'{str(key).strip()}.json'
    if not path.exists(): return False
    path.unlink(); return True
