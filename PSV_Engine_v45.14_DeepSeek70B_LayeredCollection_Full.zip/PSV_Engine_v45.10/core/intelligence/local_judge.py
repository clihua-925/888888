# -*- coding: utf-8 -*-
"""Local DeepSeek 70B semantic/business judge.

Rules remain hard boundaries. This module only supplies semantic judgments to the
existing nine-node pipeline; it never writes the database and never controls flow.
"""
import json
import time
from typing import Any, Dict, List

from core.utils.jsonutil import jl

from core.config import settings
from core.model.reasoning import ReasoningEngine


_engine = None


def _eng():
    global _engine
    if _engine is None:
        _engine = ReasoningEngine()
    return _engine


def _clean(value, default=''):
    if value is None:
        return default
    return str(value).strip()


def _ask(prompt: str, system: str) -> Dict[str, Any]:
    if not getattr(settings, 'AI_JUDGE_ENABLED', True):
        return {'success': False, 'reason': 'AI_JUDGE_ENABLED=false'}
    try:
        result = _eng().review(prompt, system=system)
        if isinstance(result, dict):
            result.setdefault('_ai_model', getattr(settings, 'LLM_MODEL', 'local'))
            result['_ai_success'] = True
            return result
    except Exception as exc:
        return {'success': False, 'reason': str(exc)[:300]}
    return {'success': False, 'reason': 'local model returned no structured JSON'}


def _queue_update(progress_hook, queue):
    """Emit a small, JSON-safe queue snapshot after every item.
    The node remains the owner of execution; the hook is observation/checkpoint only.
    """
    if not progress_hook:
        return
    try:
        progress_hook({
            'stage': queue.get('stage'),
            'total': int(queue.get('total') or 0),
            'completed': int(queue.get('completed') or 0),
            'failed': int(queue.get('failed') or 0),
            'retried': int(queue.get('retried') or 0),
            'current_index': queue.get('current_index'),
            'current_name': queue.get('current_name') or '',
            'started_at': queue.get('started_at'),
            'updated_at': time.time(),
            'items': list(queue.get('items') or [])[-500:],
        })
    except Exception:
        pass


def _queue(candidates, stage, single_fn, progress_hook=None):
    """Quality-first serial AI queue.

    One candidate -> one DeepSeek 70B request. This intentionally favors semantic
    quality over throughput. Each item is independently retryable, observable,
    and observable through the existing node checkpoint. No batch prompt is used, so one difficult
    record cannot dilute the context of another record.
    """
    items=list(candidates or [])
    queue={
        'stage': stage, 'total': len(items), 'completed': 0, 'failed': 0,
        'retried': 0, 'current_index': None, 'current_name': '',
        'started_at': time.time(), 'updated_at': time.time(), 'items': []
    }
    _queue_update(progress_hook, queue)
    max_retry=max(0, int(getattr(settings, 'AI_JUDGE_QUEUE_RETRIES', 2)))
    out=[None]*len(items)
    for i,c in enumerate(items):
        name=_clean(c.get('name') or c.get('from_name') or c.get('to_name') or f'item-{i+1}')
        queue['current_index']=i
        queue['current_name']=name
        item={'index':i,'name':name,'status':'RUNNING','attempt':0}
        queue['items'].append(item)
        _queue_update(progress_hook, queue)
        result=None
        for attempt in range(1,max_retry+2):
            item['attempt']=attempt
            try:
                result=single_fn(c)
            except Exception as exc:
                result={'_ai_success':False,'reason':str(exc)[:300]}
            ok=isinstance(result,dict) and bool(result.get('_ai_success'))
            # _ask returns structured data but historically did not mark failure
            # consistently; a semantic payload with the expected fields is success.
            if isinstance(result,dict) and not result.get('_ai_success'):
                semantic_keys={'entity_type','trade_support','entity_role','expand','role'}
                if any(k in result for k in semantic_keys) and not result.get('success') is False:
                    result['_ai_success']=True; ok=True
            if ok:
                break
            if attempt <= max_retry:
                queue['retried'] += 1
                item['status']='RETRY'
                item['reason']=str((result or {}).get('reason') or '模型未返回有效结构化判断')[:200]
                _queue_update(progress_hook, queue)
        out[i]=result
        if isinstance(result,dict) and result.get('_ai_success'):
            item['status']='SUCCESS'
            queue['completed'] += 1
        else:
            item['status']='FAILED'
            item['reason']=str((result or {}).get('reason') or 'local model judgment failed')[:200]
            queue['failed'] += 1
        item['duration_sec']=round(time.time()-queue['started_at'],2)
        _queue_update(progress_hook, queue)
    queue['current_index']=None; queue['current_name']=''; queue['updated_at']=time.time()
    _queue_update(progress_hook, queue)
    return out


def _hook_from_state(state):
    return state.get('_persist_runtime') if isinstance(state,dict) else None


def judge_trade_nodes_batch(candidates, product_domain, market, progress_hook=None):
    """Backward-compatible name; implementation is now a serial quality-first queue."""
    def one(c): return judge_trade_node(c,product_domain,market)
    return _queue(candidates,'CUSTOMS_NODE_COLLECTION',one,progress_hook)


def judge_edges_batch(edges, product_domain, progress_hook=None):
    """Backward-compatible name; one edge receives one full DeepSeek judgment."""
    return _queue(edges,'EVIDENCE_VERIFY',lambda e: judge_edge(e,product_domain),progress_hook)


def resolve_entities_batch(candidates, product_domain, market, progress_hook=None):
    """Backward-compatible name; one entity receives one full DeepSeek judgment."""
    return _queue(candidates,'ENTITY_RESOLUTION',lambda c: resolve_entity(c,product_domain,market),progress_hook)


def classify_resources_batch(candidates, product_domain, market, progress_hook=None):
    """Backward-compatible name; one resource receives one full DeepSeek judgment."""
    return _queue(candidates,'RESOURCE_CLASSIFICATION',lambda c: classify_resource(c,product_domain,market),progress_hook)


def expansion_batch(candidates, product_domain, depth, progress_hook=None):
    """Backward-compatible name; one expansion candidate receives one full judgment."""
    return _queue(candidates,'GRAPH_EXPANSION',lambda c: judge_expansion(c,product_domain,depth),progress_hook)

def judge_trade_node(candidate: Dict[str, Any], product_domain: str, market: str) -> Dict[str, Any]:
    """Judge what a raw customs/IY row means. Never delete the raw fact."""
    e = candidate.get('evidence') or {}
    prompt = f'''产品域: {product_domain}
目标市场: {market}

这是第三节点第二层深判。第一层已经放行“直接产品命中 + 真实贸易证据”的确定项；你只会收到第一层无法直接确定的剩余资料。
请判断这条海关/贸易节点残片的商业含义。第一采集链强调高召回：即使业务相关性不确定，也不要否认它是贸易事实；你的任务是识别“它是什么”“证据支持什么”和“是否值得继续进入企业候选链”。

名称: {_clean(candidate.get('name'))}
原始类型: {_clean(candidate.get('type') or candidate.get('kind'))}
来源: {_clean(candidate.get('source'))}
URL: {_clean(e.get('url') or candidate.get('website'))}
地点: {_clean(candidate.get('country'))} / {_clean(e.get('location'))}
产品描述: {_clean(e.get('products') or e.get('descr'))[:1200]}
HS: {json.dumps(e.get('hs') or [], ensure_ascii=False)}
出货票数: {e.get('shipments') or 0}
关系: {_clean(e.get('supplier_relation') or e.get('customer_relation'))}

只输出JSON，不要输出解释文本：
{{
  "entity_type":"company|brand|location|country|logistics|government|person|unknown",
  "trade_role":"importer|supplier|manufacturer|exporter|shipper|consignee|notify_party|unknown",
  "product_relevance":"core|adjacent|unrelated|unknown",
  "business_value":"high|medium|low|unknown",
  "keep_in_trade_graph":true,
  "keep_in_company_pipeline":true,
  "reason":"一句话说明判断依据",
  "confidence":0.0
}}
边界：location/country/government/person/logistics 不得作为公司实体；但只要存在贸易关系事实，必须 keep_in_trade_graph=true。拿不准时 entity_type=unknown、keep_in_company_pipeline=true。'''
    return _ask(prompt, '你是外贸海关贸易节点语义专家。以事实字段为依据，不编造公司身份；高召回优先，业务语义判断优先于关键词规则。')


def judge_edge(edge: Dict[str, Any], product_domain: str) -> Dict[str, Any]:
    e = edge.get('evidence') or {}
    prompt = f'''产品域: {product_domain}
请判断下面一条贸易关系证据“实际支持到什么程度”，重点区分“确实发生贸易”与“确实是当前产品的目标贸易”。不要删除关系。

from: {_clean(edge.get('from_name'))} ({_clean(edge.get('from_type'))})
to: {_clean(edge.get('to_name'))} ({_clean(edge.get('to_type'))})
relation: {_clean(edge.get('relation'))}
source: {_clean(edge.get('source'))}
shipments: {e.get('shipments') or edge.get('shipment_count') or 0}
HS: {json.dumps(e.get('hs') or edge.get('hs_code') or [], ensure_ascii=False)}
products: {_clean(e.get('products') or edge.get('product_text'))[:1600]}
URL: {_clean(e.get('url'))}

只输出JSON：
{{"trade_support":"strong|medium|weak|none","product_relevance":"core|adjacent|unrelated|unknown","relation_valid":"yes|uncertain|no","recommended_level":"STRONG|MEDIUM|WEAK|UNVERIFIED","reason":"一句话","confidence":0.0}}'''
    return _ask(prompt, '你是贸易证据核验专家。只根据提供的证据判断支持范围；不能把“有提单”自动等同于“目标产品强证据”。')


def resolve_entity(candidate: Dict[str, Any], product_domain: str, market: str) -> Dict[str, Any]:
    e = candidate.get('evidence') or {}
    prompt = f'''产品域: {product_domain}; 目标市场: {market}
判断这个贸易节点是否代表一个可识别的商业企业实体。允许保留 UNKNOWN，不要强行合并。

name: {_clean(candidate.get('name'))}
type: {_clean(candidate.get('type') or candidate.get('node_role'))}
country: {_clean(candidate.get('country'))}
url: {_clean(e.get('url') or candidate.get('website'))}
products: {_clean(e.get('products'))[:1200]}
hs: {json.dumps(e.get('hs') or [], ensure_ascii=False)}
shipments: {e.get('shipments') or 0}
AI初判: {json.dumps(e.get('ai_judgment') or {}, ensure_ascii=False)}

只输出JSON：
{{"entity_type":"company|brand|location|country|logistics|government|person|unknown","canonical_name":"","role":"CUSTOMER|SUPPLIER|CUSTOMER_AND_SUPPLIER|UNKNOWN","same_entity_confidence":0.0,"merge_safe":"yes|no|unknown","reason":"一句话","confidence":0.0}}'''
    return _ask(prompt, '你是企业实体解析专家。宁可 UNKNOWN，也不能因为名称相似就错误合并；法律实体、地点、品牌、物流必须区分。')


def classify_resource(candidate: Dict[str, Any], product_domain: str, market: str) -> Dict[str, Any]:
    e = candidate.get('evidence') or {}
    prompt = f'''产品域: {product_domain}; 目标市场: {market}
对下面已经过贸易节点和实体解析的候选做最终业务资源判断。不要删除真实贸易事实；这里只决定它在客户/供应商开发体系里的角色与优先级。

name: {_clean(candidate.get('name'))}
role_hint: {_clean(candidate.get('type') or candidate.get('entity_role'))}
country: {_clean(candidate.get('country'))}
products: {_clean(e.get('products'))[:1500]}
hs: {json.dumps(e.get('hs') or [], ensure_ascii=False)}
shipments: {e.get('shipments') or 0}
source: {_clean(candidate.get('source'))}
trade_status_hint: {_clean(candidate.get('trade_status'))}
entity_judgment: {json.dumps(candidate.get('entity_ai_judgment') or {}, ensure_ascii=False)}
evidence_judgment: {json.dumps(e.get('ai_evidence_judgment') or {}, ensure_ascii=False)}

只输出JSON：
{{"entity_role":"CUSTOMER|SUPPLIER|CUSTOMER_AND_SUPPLIER|UNKNOWN","business_relevance":"core|adjacent|unrelated|unknown","development_status":"DEVELOPMENT_POOL|DISCOVERED_POOL|UNASSIGNED","priority":"high|medium|low|none","reason":"一句话","confidence":0.0}}'''
    return _ask(prompt, '你是B2B外贸资源分类专家。产品相关性和企业角色要根据证据语义判断，不要仅凭HS或公司名称关键词拍板。')


def judge_expansion(candidate: Dict[str, Any], product_domain: str, depth: int) -> Dict[str, Any]:
    e = candidate.get('evidence') or {}
    prompt = f'''产品域: {product_domain}; 当前扩张深度: {depth}
判断是否值得把这个贸易节点作为下一轮网络扩张种子。高价值节点可以继续深挖，低价值节点可以停止；停止只影响探索，不删除已有事实。

name: {_clean(candidate.get('name'))}
role: {_clean(candidate.get('entity_role') or candidate.get('type'))}
products: {_clean(e.get('products'))[:1200]}
hs: {json.dumps(e.get('hs') or [], ensure_ascii=False)}
shipments: {e.get('shipments') or 0}
source: {_clean(candidate.get('source'))}
product_relevance: {_clean(candidate.get('product_relevance') or e.get('product_relevance'))}
trade_status: {_clean(candidate.get('trade_status'))}

只输出JSON：
{{"expand":"yes|maybe|no","expected_value":"high|medium|low","direction":"customer_to_supplier|supplier_to_customer|both|none","reason":"一句话","confidence":0.0}}'''
    return _ask(prompt, '你是贸易网络扩张策略专家。只决定探索优先级，不改变事实、不删除节点；在不确定时选择maybe。')
