# -*- coding: utf-8 -*-
"""Account Intelligence Center v45 (FULL)

客户/供应商情报中心。
负责：
- 构建完整情报档案
- 信息完整度评估
- 客户价值评分
- 开发资格判断
- 显示【已经知道什么】【缺什么】【下一步可以挖什么】
"""
import json, time
from typing import Dict, List, Any, Optional
from core.memory.db import DB
from core.intelligence.waterfall import WaterfallEnrichmentEngine
from core.intelligence.ai_router import ai_route, ai_route_structured


class AccountIntelligenceCenter:
    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.waterfall = WaterfallEnrichmentEngine(db)

    def get_intelligence(self, norm: str) -> Dict[str, Any]:
        """获取完整情报档案。"""
        entity = self.db.get_entity(norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found'}

        entity_id = entity['entity_id']
        completeness = self._calculate_completeness(entity_id)
        completeness_detail = self._get_completeness_detail(entity_id)
        value_score = self._calculate_value_score(entity_id)

        # 生成"缺什么"和"下一步挖什么"分析
        gaps = self._find_gaps(completeness_detail)
        next_steps = self._suggest_next_steps(gaps, value_score)

        intelligence = {
            'entity_id': entity_id,
            'norm': norm,
            'basic_identity': self._get_basic_identity(entity),
            'trade_identity': self._get_trade_identity(entity_id),
            'purchase_behavior': self._get_purchase_behavior(entity_id),
            'info_completeness': completeness,
            'info_completeness_detail': completeness_detail,
            'gaps': gaps,
            'next_steps': next_steps,
            'value_score': value_score,
            'contacts': self.db.list_entity_contacts(entity_id),
            'claims': self.db.list_data_claims(norm,limit=120),
            'evidence': self.db.list_evidence(entity_id),
            'lifecycle': self.db.get_lifecycle_history(entity_id),
            'dev_qualified': self._check_development_qualification(entity_id),
            'dev_qualification_reason': self._get_qualification_reason(entity_id),
            'trade_network': self._get_trade_network(entity_id),
        }

        return {'ok': True, 'data': intelligence}

    def enrich(self, norm: str, category_id: str = None,
               force: bool = False) -> Dict[str, Any]:
        """触发情报补全。"""
        entity = self.db.get_or_create_entity(norm=norm, name=norm)
        entity_id = entity.get('entity_id')

        # Lifecycle: mark enrichment start before source calls, then close the
        # transition after all waterfall sources finish.
        current_state = self.db.get_current_lifecycle_state(entity_id)
        if current_state in ('DISCOVERED', 'TRADE_CONFIRMED'):
            self.db.transition_lifecycle(entity_id, current_state, 'ENRICHING',
                                         'Waterfall enrichment started', 'account_intelligence_center')

        # 执行瀑布补全
        result = self.waterfall.enrich_entity(norm, category_id=category_id, force=force)

        # Persist the profile on the unified entities table. The previous code
        # referenced a non-existent secondary profile method and could return
        # HTTP 500 after the waterfall had already completed.
        score=self._calculate_value_score(entity_id).get('total_score',0)
        self.db.update_entity(norm,info_completeness=result.get('completeness',0),value_score_total=score,dev_qualified=1 if self._check_development_qualification(entity_id) else 0)

        # 记录生命周期：本次补全完成后立即落到 ENRICHED，避免第一次补全
        # 永远停留在 ENRICHING。
        current_state = self.db.get_current_lifecycle_state(entity_id)
        if current_state == 'ENRICHING':
            self.db.transition_lifecycle(entity_id, 'ENRICHING', 'ENRICHED',
                                         'Waterfall enrichment completed', 'account_intelligence_center')

        return {'ok': True, 'enriched': result}

    def _get_basic_identity(self, entity: Dict) -> Dict:
        return {
            'standard_name': entity.get('name', ''),
            'original_name': entity.get('original_name', ''),
            'country': entity.get('country', ''),
            'address': entity.get('address', ''),
            'website': entity.get('website', ''),
            'phone': entity.get('phone', ''),
            'enterprise_type': entity.get('enterprise_type', ''),
            'industry': entity.get('industry', ''),
            'product_categories': entity.get('product_categories', ''),
            'brand': entity.get('brand', ''),
            'entity_status': entity.get('entity_status', 'active'),
            'data_source': entity.get('data_source', ''),
        }

    def _get_trade_identity(self, entity_id: str) -> Dict:
        roles = self.db.get_entity_roles(entity_id)
        edges = self.db.list_trade_edges(entity_id=entity_id)
        return {
            'roles': roles,
            'role_display': ' / '.join(roles) if roles else 'unknown',
            'trade_count': len(edges),
            'suppliers': [e for e in edges if e.get('relation') == 'supplier_of'],
            'customers': [e for e in edges if e.get('relation') == 'customer_of'],
            'products': list(set([e.get('product', '') for e in edges if e.get('product')])),
        }

    def _get_purchase_behavior(self, entity_id: str) -> Dict:
        edges = self.db.list_trade_edges(entity_id=entity_id)
        if not edges:
            return {'activity': 'unknown', 'frequency': 'unknown'}
        shipment_counts = [e.get('shipment_count', 0) for e in edges]
        total_shipments = sum(shipment_counts)
        return {
            'total_shipments': total_shipments,
            'supplier_count': len([e for e in edges if e.get('relation') == 'supplier_of']),
            'customer_count': len([e for e in edges if e.get('relation') == 'customer_of']),
            'products': list(set([e.get('product', '') for e in edges if e.get('product')])),
            'activity': 'high' if total_shipments > 10 else 'medium' if total_shipments > 3 else 'low',
        }

    def _calculate_completeness(self, entity_id: str) -> float:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return 0.0
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories']
        filled = sum(1 for f in fields if entity.get(f))
        return round(filled / len(fields) * 100, 1)

    def _get_completeness_detail(self, entity_id: str) -> Dict:
        entity=self.db.get_entity_by_id(entity_id)
        if not entity: return {}
        contacts=self.db.list_entity_contacts(entity_id); edges=self.db.list_trade_edges(entity_id=entity_id)
        return {'basic_info':self._calculate_completeness(entity_id),'trade_info':min(100,len(edges)*20),
                'product_info':100 if entity.get('product_categories') else 0,'contact_info':min(100,len(contacts)*25),
                'email_info':min(100,sum(1 for c in contacts if c.get('email'))*50),
                'verified_email_info':min(100,sum(1 for c in contacts if c.get('email') and c.get('verified'))*100),
                'website_info':100 if entity.get('website') else 0,'evidence_info':min(100,len(self.db.list_evidence(entity_id))*10)}

    def _find_gaps(self, detail: Dict) -> List[Dict]:
        labels={'basic_info':'基础企业信息','trade_info':'贸易关系','product_info':'产品需求','contact_info':'联系人',
                'email_info':'工作邮箱','verified_email_info':'已验证邮箱','website_info':'企业官网','evidence_info':'证据链'}
        gaps=[]
        for field,score in detail.items():
            if score<50: gaps.append({'field':field,'label':labels.get(field,field),'current_score':score,'missing':f'{100-score:.0f}%','priority':'high' if score<20 else 'medium'})
        return sorted(gaps,key=lambda x:(0 if x['priority']=='high' else 1,x['current_score']))

    def _suggest_next_steps(self, gaps: List[Dict], value_score: Dict) -> List[str]:
        """基于缺口建议下一步行动"""
        steps = []
        gap_names = [g['field'] for g in gaps]
        if 'contact_info' in gap_names or 'email_info' in gap_names:
            steps.append("查找并验证联系人及工作邮箱")
        if 'website_info' in gap_names:
            steps.append("访问企业官网获取基础信息")
        if 'product_info' in gap_names:
            steps.append("分析贸易记录推导产品类别")
        if 'trade_info' in gap_names:
            steps.append("扩张贸易网络以积累更多贸易边")
        if value_score.get('total_score', 0) < 50:
            steps.append("继续补全基础信息以提升价值评分")
        if not steps:
            steps.append("信息已较完整，建议评估开发资格")
        return steps

    def _calculate_value_score(self, entity_id: str) -> Dict:
        entity = self.db.get_entity_by_id(entity_id)
        edges = self.db.list_trade_edges(entity_id=entity_id)
        contacts = self.db.list_entity_contacts(entity_id)

        trade_realness = min(100, len(edges) * 25)
        product_match = 70
        recent_activity = 80 if edges and any((e.get('last_trade') or 0) > time.time() - 90*86400 for e in edges) else 40
        purchase_strength = min(100, sum(int(e.get('shipment_count') or 0) for e in edges) * 5)
        info_completeness = self._calculate_completeness(entity_id)
        contact_availability = min(100, len(contacts) * 50)
        icp_match = 60  # 可由外部配置调整
        network_value = min(100, len(edges) * 10)

        total = (trade_realness * 0.15 + product_match * 0.1 + recent_activity * 0.1 +
                purchase_strength * 0.1 + info_completeness * 0.1 + contact_availability * 0.15 +
                icp_match * 0.15 + network_value * 0.15)

        return {
            'trade_realness': trade_realness,
            'product_match': product_match,
            'recent_activity': recent_activity,
            'purchase_strength': purchase_strength,
            'info_completeness': info_completeness,
            'contact_availability': contact_availability,
            'icp_match': icp_match,
            'network_value': network_value,
            'total_score': round(total, 1),
            'priority': 'high' if total >= 70 else 'medium' if total >= 40 else 'low'
        }

    def _check_development_qualification(self, entity_id: str) -> bool:
        score = self._calculate_value_score(entity_id)
        contacts = self.db.list_entity_contacts(entity_id)
        has_email = any(c.get('email') for c in contacts)
        current_state = self.db.get_current_lifecycle_state(entity_id)

        return (score.get('total_score', 0) >= 50 and
                score.get('trade_realness', 0) >= 40 and
                has_email and
                current_state not in ('QUARANTINED', 'INVALID', 'DO_NOT_CONTACT'))

    def _get_qualification_reason(self, entity_id: str) -> str:
        if self._check_development_qualification(entity_id):
            return 'Meets all development criteria'
        reasons = []
        score = self._calculate_value_score(entity_id)
        if score.get('total_score', 0) < 50:
            reasons.append('Value score too low')
        if score.get('trade_realness', 0) < 40:
            reasons.append('Insufficient trade evidence')
        contacts = self.db.list_entity_contacts(entity_id)
        if not any(c.get('email') for c in contacts):
            reasons.append('No valid contact email')
        current_state = self.db.get_current_lifecycle_state(entity_id)
        if current_state in ('QUARANTINED', 'INVALID', 'DO_NOT_CONTACT'):
            reasons.append(f'Entity state is {current_state}')
        return '; '.join(reasons) if reasons else 'Not qualified'

    def _get_trade_network(self, entity_id: str) -> Dict:
        edges = self.db.list_trade_edges(entity_id=entity_id)
        return {
            'direct_connections': len(edges),
            'suppliers': len([e for e in edges if e.get('relation') == 'supplier_of']),
            'customers': len([e for e in edges if e.get('relation') == 'customer_of']),
            'network_depth': 1,
        }

    def ai_validate(self, norm: str) -> Dict[str, Any]:
        """AI 验证中心：返回自然语言结论 + 结构化字段"""
        intelligence = self.get_intelligence(norm)
        if not intelligence['ok']:
            return intelligence

        data = intelligence['data']
        prompt = f"""请基于以下企业情报，给出验证结论：

企业: {norm}
基础信息: {json.dumps(data['basic_identity'], ensure_ascii=False)}
贸易身份: {json.dumps(data['trade_identity'], ensure_ascii=False)}
采购行为: {json.dumps(data['purchase_behavior'], ensure_ascii=False)}
价值评分: {json.dumps(data['value_score'], ensure_ascii=False)}

请用自然语言回答以下问题：
1. 该企业是否可能是目标产品的真实采购客户？
2. 判断依据是什么？
3. 综合置信度（Strong/Medium/Weak）？
4. 建议下一步行动？

要求：先给出自然语言结论，再给出结构化 JSON。"""

        result = ai_route_structured(prompt, model_preference=['deepseek', 'qwen', 'gpt'])
        return {
            'ok': result['success'],
            'natural_language': result['content'],
            'parsed': result.get('parsed_json'),
            'model_used': result.get('provider'),
            'error': result.get('error', '')
        }
