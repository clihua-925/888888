"""Stub business nodes for Stage 1c orchestration skeleton validation.

Every stub keeps the real node's signature and contract. No LLM calls, no
external data sources, no routing/retry/checkpoint/timeout decisions — those
remain orchestration-only. DATABASE_COMMIT writes one real-schema row per
table so verify_install's three-table check succeeds unchanged.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from core.orchestration.runtime import get_database
from core.orchestration.state import TaskState

REPORT_STATUS_COMMITTED = "committed"

STUB_MARK = "stub"


def PRODUCT_DEFINITION(state: TaskState) -> TaskState:
    """Stub: product definition orchestration stub."""
    result = deepcopy(state)
    product_definition = dict(result.get("product_definition", {}))
    product_definition.update({
        "name": "Stub Product",
        "category": "Stub Category",
        "stub": True,
    })
    result["product_definition"] = product_definition
    trade_nodes = list(result.get("trade_nodes", []))
    trade_nodes.append({"node_id": "stub_product_node", "stub": True})
    result["trade_nodes"] = trade_nodes
    decisions = list(result.get("decisions", []))
    decisions.append({
        "decision_type": "product_definition",
        "confidence": 1.0,
        "rationale": "stub decision",
        "decision": {"name": "Stub Product"},
        "metadata": {"stub": True},
    })
    result["decisions"] = decisions
    reports = dict(result.get("node_reports", {}))
    reports["PRODUCT_DEFINITION"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def TRADE_STRATEGY(state: TaskState) -> TaskState:
    """Stub: trade strategy orchestration stub."""
    result = deepcopy(state)
    mission = dict(result.get("mission", {}))
    mission["strategy"] = "stub_strategy"
    result["mission"] = mission
    fragments = list(result.get("fragments", []))
    fragments.append({"fragment_id": "stub_fragment_1", "stub": True})
    result["fragments"] = fragments
    reports = dict(result.get("node_reports", {}))
    reports["TRADE_STRATEGY"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def CUSTOMS_NODE_COLLECTION(state: TaskState) -> TaskState:
    """Stub: customs node collection orchestration stub."""
    result = deepcopy(state)
    trade_nodes = list(result.get("trade_nodes", []))
    trade_nodes.append({"node_id": "stub_customs_node", "stub": True})
    result["trade_nodes"] = trade_nodes
    reports = dict(result.get("node_reports", {}))
    reports["CUSTOMS_NODE_COLLECTION"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def TRADE_EDGE_BUILD(state: TaskState) -> TaskState:
    """Stub: trade edge build orchestration stub."""
    result = deepcopy(state)
    relationships = list(result.get("relationships", []))
    relationships.append({
        "source": "stub_product_node",
        "target": "stub_customs_node",
        "edge_type": "stub_supply",
        "stub": True,
    })
    result["relationships"] = relationships
    reports = dict(result.get("node_reports", {}))
    reports["TRADE_EDGE_BUILD"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def EVIDENCE_VERIFY(state: TaskState) -> TaskState:
    """Stub: evidence verification orchestration stub.

    Emits one verified evidence item so the orchestration-level verified
    evidence gate routes to ENTITY_RESOLUTION.
    """
    result = deepcopy(state)
    evidence_pool = list(result.get("evidence_pool", []))
    for index in range(1, 4):
        evidence_pool.append({
            "evidence_id": f"stub_evidence_{index}",
            "verified": True,
            "source": "stub",
        })
    result["evidence_pool"] = evidence_pool
    reports = dict(result.get("node_reports", {}))
    reports["EVIDENCE_VERIFY"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def ENTITY_RESOLUTION(state: TaskState) -> TaskState:
    """Stub: entity resolution orchestration stub."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    entities.append({
        "entity_id": "stub_entity_1",
        "name": "Stub Entity",
        "entity_type": "product",
        "stub": True,
    })
    result["entities"] = entities
    reports = dict(result.get("node_reports", {}))
    reports["ENTITY_RESOLUTION"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def GRAPH_EXPANSION(state: TaskState) -> TaskState:
    """Stub: graph expansion orchestration stub."""
    result = deepcopy(state)
    trade_nodes = list(result.get("trade_nodes", []))
    trade_nodes.append({"node_id": "stub_expansion_node", "stub": True})
    result["trade_nodes"] = trade_nodes
    reports = dict(result.get("node_reports", {}))
    reports["GRAPH_EXPANSION"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def RESOURCE_CLASSIFICATION(state: TaskState) -> TaskState:
    """Stub: resource classification orchestration stub."""
    result = deepcopy(state)
    fragments = list(result.get("fragments", []))
    fragments.append({"fragment_id": "stub_fragment_2", "classified": True, "stub": True})
    result["fragments"] = fragments
    reports = dict(result.get("node_reports", {}))
    reports["RESOURCE_CLASSIFICATION"] = {"status": STUB_MARK}
    result["node_reports"] = reports
    return result


def DATABASE_COMMIT(state: TaskState) -> TaskState:
    """Stub: commit one real-schema stub row per table through Database."""
    result = deepcopy(state)
    database = get_database()
    if not callable(getattr(database, "commit_trade_data", None)):
        raise RuntimeError("DATABASE_COMMIT runtime database gateway is invalid")

    task_id = str(result.get("task_id", "")).strip()
    if not task_id:
        raise ValueError("DATABASE_COMMIT requires state['task_id']")

    stub_entity = {
        "entity_id": "stub_entity_commit",
        "name": "Stub Entity",
        "entity_type": "product",
        "stub": True,
    }
    stub_edge = {
        "source": "stub_product_node",
        "target": "stub_customs_node",
        "edge_type": "stub_supply",
        "stub": True,
    }
    stub_evidence = {
        "evidence_id": "stub_evidence_commit",
        "verified": True,
        "source": "stub",
    }

    counts = database.commit_trade_data(
        task_id=task_id,
        trade_entities=[stub_entity],
        trade_edges=[stub_edge],
        evidence=[stub_evidence],
    )

    reports = dict(result.get("node_reports", {}))
    reports["DATABASE_COMMIT"] = {
        "status": REPORT_STATUS_COMMITTED,
        "entity_count": counts.get("trade_entities", 1),
        "relationship_count": counts.get("trade_edges", 1),
        "evidence_count": counts.get("evidence", 1),
    }
    result["node_reports"] = reports
    return result


NODE_FUNCTIONS = {
    "PRODUCT_DEFINITION": PRODUCT_DEFINITION,
    "TRADE_STRATEGY": TRADE_STRATEGY,
    "CUSTOMS_NODE_COLLECTION": CUSTOMS_NODE_COLLECTION,
    "TRADE_EDGE_BUILD": TRADE_EDGE_BUILD,
    "EVIDENCE_VERIFY": EVIDENCE_VERIFY,
    "ENTITY_RESOLUTION": ENTITY_RESOLUTION,
    "GRAPH_EXPANSION": GRAPH_EXPANSION,
    "RESOURCE_CLASSIFICATION": RESOURCE_CLASSIFICATION,
    "DATABASE_COMMIT": DATABASE_COMMIT,
}


def get_node_function(node_id: str):
    """Return a registered business node callable."""
    try:
        return NODE_FUNCTIONS[node_id]
    except KeyError as exc:
        raise KeyError(f"Unknown business node: {node_id}") from exc
