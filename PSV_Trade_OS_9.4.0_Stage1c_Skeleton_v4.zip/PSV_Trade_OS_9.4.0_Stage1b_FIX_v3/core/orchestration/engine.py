"""LangGraph workflow execution engine for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
import threading
import time
import types
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

from core.config.settings import Settings
from core.memory.db import Database

from .conditions import ConditionEdgeEngine
from .contracts import ContractRegistry
from .decision import DecisionLayer
from .plan import ExecutionPlan, OrchestrationPlanGenerator
from .policies import DEFAULT_POLICY, Policy
from .recovery import RecoveryManager
from .registry import RegisteredWorkflow, WorkflowRegistry
from .runtime import pop_engine_context, push_engine_context
from .state import (
    STATUS_COMPLETED, STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING, STATUS_TIMEOUT,
    TaskState,
)

LOGGER = logging.getLogger(__name__)


class _TaskDeadlineExceeded(Exception):
    """Raised at node boundaries when the hard task deadline has elapsed."""


class _CheckpointAuditBridge:
    """Attach audit events to a real SqliteSaver without replacing the checkpointer."""

    @staticmethod
    def attach(checkpointer: SqliteSaver, database: Database, task_id: str, resume: bool) -> None:
        original_put = checkpointer.put
        original_get_tuple = checkpointer.get_tuple

        def audited_put(*args: Any, **kwargs: Any) -> Any:
            result = original_put(*args, **kwargs)
            configurable = result.get("configurable", {}) if isinstance(result, Mapping) else {}
            database.add_event(
                task_id,
                "CHECKPOINT",
                status=STATUS_RUNNING,
                payload={
                    "action": "created",
                    "thread_id": configurable.get("thread_id", task_id),
                    "checkpoint_id": configurable.get("checkpoint_id"),
                },
            )
            return result

        def audited_get_tuple(*args: Any, **kwargs: Any) -> Any:
            result = original_get_tuple(*args, **kwargs)
            if resume and result is not None:
                result_config = getattr(result, "config", {})
                configurable = result_config.get("configurable", {}) if isinstance(result_config, Mapping) else {}
                database.add_event(
                    task_id,
                    "CHECKPOINT",
                    status=STATUS_RUNNING,
                    payload={
                        "action": "restored",
                        "thread_id": configurable.get("thread_id", task_id),
                        "checkpoint_id": configurable.get("checkpoint_id"),
                    },
                )
            return result

        checkpointer.put = types.MethodType(lambda _self, *args, **kwargs: audited_put(*args, **kwargs), checkpointer)
        checkpointer.get_tuple = types.MethodType(
            lambda _self, *args, **kwargs: audited_get_tuple(*args, **kwargs), checkpointer
        )


class WorkflowEngine:
    """Build and execute LangGraph workflows with orchestration-only controls."""

    def __init__(
        self,
        registry: WorkflowRegistry,
        condition_engine: ConditionEdgeEngine,
        recovery_manager: RecoveryManager,
        policy: Policy = DEFAULT_POLICY,
        database: Database | None = None,
        settings: Settings | None = None,
    ) -> None:
        self.registry = registry
        self.condition_engine = condition_engine
        self.recovery_manager = recovery_manager
        self.policy = policy
        self.settings = settings if settings is not None else Settings()
        self.database = database if database is not None else Database(self.settings.database_path)
        self.contract_registry = ContractRegistry()
        self.decision_layer = DecisionLayer()
        # Hard task deadline for the currently executing task. Set by run() before
        # the worker thread starts; checked cooperatively at every node boundary.
        # Single-flight by design: one engine instance executes one task at a time.
        self._task_deadline: float | None = None

    def run(
        self,
        state: Mapping[str, Any],
        workflow: RegisteredWorkflow,
        resume: bool = False,
        timeout_seconds: int | None = None,
    ) -> TaskState:
        """Execute a workflow in-process with a hard wall-clock timeout."""
        initial_state = deepcopy(dict(state))
        task_id = str(initial_state.get("task_id", "")).strip()
        if not task_id:
            raise ValueError("state['task_id'] is required")
        initial_state["workflow_id"] = workflow.workflow_id
        initial_state["workflow_version"] = workflow.version
        initial_state.setdefault("status", STATUS_PENDING)
        if not resume:
            initial_state["status"] = STATUS_RUNNING
        self.database.update_task(task_id, initial_state, str(initial_state["status"]))
        effective_timeout = self.policy.max_task_seconds if timeout_seconds is None else max(0, int(timeout_seconds))

        result_box: dict[str, Any] = {}

        def _worker() -> None:
            try:
                output = self._run_graph_direct(initial_state, workflow, resume=resume)
                result_box["ok"] = True
                result_box["state"] = dict(output)
            except Exception as exc:
                LOGGER.exception("Workflow execution failed: task_id=%s", task_id)
                failed_state = deepcopy(initial_state)
                failed_state["status"] = STATUS_FAILED
                failed_state["error"] = {"code": "ENGINE_PROCESS_ERROR", "message": str(exc)}
                result_box["ok"] = False
                result_box["state"] = failed_state

        self._task_deadline = time.monotonic() + effective_timeout
        try:
            worker = threading.Thread(
                target=_worker,
                name=f"psv-task-{task_id}",
                daemon=True,
            )
            worker.start()
            worker.join(effective_timeout)
            if worker.is_alive():
                # Hard timeout. The worker thread cannot be force-killed on
                # CPython; it drains on its own because every node boundary
                # raises _TaskDeadlineExceeded and the router terminates the
                # graph on terminal status. The authoritative result is the
                # timeout state returned here.
                timeout_state = deepcopy(initial_state)
                timeout_state["status"] = STATUS_TIMEOUT
                timeout_state["error"] = {
                    "code": "MAX_TASK_SECONDS",
                    "message": f"Task exceeded {effective_timeout} seconds",
                }
                orchestration = dict(timeout_state.get("orchestration", {}))
                orchestration["recovery_action"] = "TIMEOUT"
                timeout_state["orchestration"] = orchestration
                self.database.update_task(task_id, timeout_state, STATUS_TIMEOUT)
                self.database.add_event(
                    task_id, "TASK_TIMEOUT", status=STATUS_TIMEOUT,
                    payload=timeout_state["error"],
                )
                LOGGER.error("Hard task timeout: task_id=%s timeout=%ss", task_id, effective_timeout)
                return timeout_state
        finally:
            self._task_deadline = None

        output = dict(result_box["state"])
        status = str(output.get("status", STATUS_FAILED))
        self.database.update_task(task_id, output, status)
        if not result_box.get("ok", False):
            self.database.add_event(
                task_id, "ENGINE_FAILURE", status=STATUS_FAILED, payload=output.get("error", {}),
            )
        return output

    def has_checkpoint(self, task_id: str) -> bool:
        """Return whether a durable LangGraph checkpoint exists for a task."""
        normalized = str(task_id).strip()
        if not normalized:
            return False
        checkpoint_path = Path(self.settings.checkpoint_path)
        if not checkpoint_path.exists():
            return False
        try:
            with SqliteSaver.from_conn_string(str(checkpoint_path)) as checkpointer:
                return checkpointer.get_tuple({"configurable": {"thread_id": normalized}}) is not None
        except Exception:
            LOGGER.exception("Checkpoint probe failed: task_id=%s", normalized)
            return False

    def _check_deadline(self) -> None:
        """Raise _TaskDeadlineExceeded when the hard task deadline has elapsed."""
        deadline = self._task_deadline
        if deadline is not None and time.monotonic() >= deadline:
            raise _TaskDeadlineExceeded("hard task deadline exceeded")

    def _run_graph_direct(
        self,
        state: Mapping[str, Any],
        workflow: RegisteredWorkflow,
        resume: bool = False,
    ) -> TaskState:
        """Execute the compiled graph in the current process."""
        plan = OrchestrationPlanGenerator(self.registry).plan_for(workflow.workflow_id)
        self._register_workflow_contracts(workflow)
        graph = self._build_graph(workflow, plan)
        checkpoint_path = Path(self.settings.checkpoint_path)
        checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        task_id = str(state.get("task_id", "")).strip()
        if not task_id:
            raise ValueError("state['task_id'] is required")
        config = {"configurable": {"thread_id": task_id}}
        with SqliteSaver.from_conn_string(str(checkpoint_path)) as checkpointer:
            _CheckpointAuditBridge.attach(checkpointer, self.database, task_id, resume)
            compiled = graph.compile(checkpointer=checkpointer)
            if resume:
                resumed = compiled.invoke(None, config)
                return dict(resumed)
            output = compiled.invoke(dict(state), config)
            return dict(output)

    def _register_workflow_contracts(self, workflow: RegisteredWorkflow) -> None:
        """Register and verify the workflow contracts used by runtime validation."""
        for contract in workflow.contracts:
            existing = self.contract_registry.contracts.get(contract.node_id)
            if existing is None:
                self.contract_registry.register(contract)
                continue
            if existing != contract:
                raise ValueError(
                    f"Contract mismatch for node {contract.node_id}: "
                    "the same node_id is registered with a different contract"
                )

    def _build_graph(
        self,
        workflow: RegisteredWorkflow,
        plan: ExecutionPlan,
    ) -> StateGraph:
        """Build a real StateGraph using registry-provided node callables."""
        graph = StateGraph(state_schema=TaskState)
        node_functions = self.registry.node_functions(workflow)
        for node_id in workflow.node_ids:
            graph.add_node(
                node_id,
                self._wrap_node(node_id, node_functions[node_id], plan),
            )
        if plan.order:
            graph.add_edge(START, plan.order[0])
        for node_id in plan.order:
            graph.add_conditional_edges(
                node_id,
                self._route_function(node_id, plan),
                self._route_targets(plan),
            )
        return graph

    def _wrap_node(
        self,
        node_id: str,
        node_function: Any,
        plan: ExecutionPlan,
    ) -> Any:
        """Wrap a business node with generic policy, progress, event, and recovery controls."""
        def wrapped(state: TaskState) -> TaskState:
            current = deepcopy(dict(state))
            while True:
                self._check_deadline()
                step_count = self._step_count(current)
                if step_count >= self.policy.max_steps:
                    current["status"] = STATUS_TIMEOUT
                    current["error"] = {
                        "code": "MAX_STEPS_REACHED",
                        "message": f"Maximum step count {self.policy.max_steps} reached before node execution",
                    }
                    self._set_recovery_action(current, "TIMEOUT")
                    self.database.update_task(str(current["task_id"]), current, STATUS_TIMEOUT)
                    self.database.add_event(
                        str(current["task_id"]), "MAX_STEPS_REACHED", node_id=node_id,
                        status=STATUS_TIMEOUT, payload=current["error"],
                    )
                    return current
                before_signature = self._state_signature(current)
                self._increment_steps(current)
                self.database.add_event(
                    str(current["task_id"]), "NODE_START", node_id=node_id,
                    status=STATUS_RUNNING, payload={"step": self._step_count(current)},
                )
                failure_type = "node_failure"
                decision_count_before = len(current.get("decisions", [])) if isinstance(current.get("decisions", []), list) else 0
                token = push_engine_context(self.decision_layer, self.database)
                try:
                    failure_type = "contract_input_failure"
                    self.contract_registry.validate_input(node_id, current)
                    result = node_function(current)
                    clean_result = dict(result)
                    self._record_new_ai_decisions(
                        clean_result, node_id, decision_count_before
                    )
                    failure_type = "contract_output_failure"
                    self.contract_registry.validate_output(node_id, clean_result)
                    next_state = deepcopy(clean_result)
                    next_state["status"] = STATUS_RUNNING
                    after_signature = self._state_signature(next_state)
                    if before_signature == after_signature:
                        no_progress = self._no_progress_count(next_state) + 1
                    else:
                        no_progress = 0
                    self._set_no_progress_count(next_state, no_progress)
                    if plan.order and node_id == plan.order[-1]:
                        next_state["status"] = STATUS_COMPLETED
                    if no_progress >= self.policy.no_progress_limit:
                        next_state["status"] = STATUS_FAILED
                        next_state["error"] = {
                            "code": "NO_INFORMATION_GAIN",
                            "message": f"State signature remained unchanged for {no_progress} consecutive node executions",
                        }
                        failure_type = "no_information_gain"
                        recovery = self.recovery_manager.prepare_retry(
                            next_state,
                            node_id,
                            next_state["error"]["message"],
                            failure_type,
                        )
                        self._set_recovery_action(next_state, str(recovery.get("action", "FAIL")))
                        self.database.update_task(str(next_state["task_id"]), next_state, STATUS_FAILED)
                        self.database.add_event(
                            str(next_state["task_id"]), "NO_INFORMATION_GAIN", node_id=node_id,
                            status=STATUS_FAILED, payload={**next_state["error"], "failure_type": failure_type},
                        )
                        self.database.add_event(
                            str(next_state["task_id"]), "RECOVERY", node_id=node_id,
                            status=STATUS_FAILED,
                            payload={"decision": recovery.get("action", "FAIL"), "reason": next_state["error"]["message"], "failure_type": failure_type},
                        )
                        return next_state
                    self.database.add_event(
                        str(next_state["task_id"]), "NODE_COMPLETE", node_id=node_id,
                        status=STATUS_RUNNING, payload={"step": self._step_count(next_state)},
                    )
                    self._record_database_commit(next_state, node_id)
                    return next_state
                except _TaskDeadlineExceeded:
                    current["status"] = STATUS_TIMEOUT
                    current["error"] = {
                        "code": "MAX_TASK_SECONDS",
                        "message": "Hard task deadline exceeded at node boundary",
                    }
                    self._set_recovery_action(current, "TIMEOUT")
                    self.database.update_task(str(current["task_id"]), current, STATUS_TIMEOUT)
                    self.database.add_event(
                        str(current["task_id"]), "TASK_TIMEOUT", node_id=node_id,
                        status=STATUS_TIMEOUT, payload=current["error"],
                    )
                    return current
                except Exception as exc:
                    self._record_new_ai_decisions(current, node_id, decision_count_before)
                    recovery = self.recovery_manager.prepare_retry(current, node_id, exc, failure_type)
                    task_id = str(current["task_id"])
                    recovery_action = str(recovery.get("action", "FAIL"))
                    recovery_reason = str(
                        recovery.get("reason")
                        or recovery.get("error", {}).get("message")
                        or current.get("error", {}).get("message")
                        or str(exc)
                    )
                    self.database.add_event(
                        task_id, "NODE_FAILURE", node_id=node_id,
                        status=str(current.get("status", STATUS_FAILED)), payload=recovery,
                    )
                    self.database.add_event(
                        task_id, "RECOVERY", node_id=node_id,
                        status=str(current.get("status", STATUS_FAILED)),
                        payload={"decision": recovery_action, "reason": recovery_reason, "failure_type": failure_type},
                    )
                    if recovery_action == "RETRY":
                        self.database.add_event(
                            task_id, "RETRY", node_id=node_id,
                            status=STATUS_RUNNING,
                            payload={
                                "node_id": node_id,
                                "attempt": recovery.get("attempt"),
                                "reason": recovery_reason,
                                "failure_type": failure_type,
                            },
                        )
                    if recovery_action != "RETRY":
                        current["status"] = STATUS_FAILED
                        self.database.update_task(str(current["task_id"]), current, STATUS_FAILED)
                        return current
                    current["status"] = STATUS_RUNNING
                finally:
                    pop_engine_context(token)

        return wrapped

    def _record_new_ai_decisions(
        self, state: Mapping[str, Any], node_id: str, previous_count: int
    ) -> None:
        """Persist every new DecisionLayer record produced by one business node."""
        decisions = state.get("decisions", [])
        if not isinstance(decisions, list):
            return
        task_id = str(state.get("task_id", "")).strip()
        if not task_id:
            return
        for record in decisions[previous_count:]:
            if not isinstance(record, Mapping):
                continue
            self.database.add_event(
                task_id,
                "AI_DECISION",
                node_id=node_id,
                status=str(state.get("status", STATUS_RUNNING)),
                payload={
                    "decision_type": record.get("decision_type"),
                    "node_id": node_id,
                    "confidence": record.get("confidence"),
                    "rationale": record.get("rationale"),
                    "decision": record.get("decision"),
                    "metadata": record.get("metadata", {}),
                },
            )

    def _record_database_commit(self, state: Mapping[str, Any], node_id: str) -> None:
        """Audit a successful database-write-authority contract without naming business nodes."""
        contract = self.contract_registry.get(node_id)
        if not contract.database_write_authority:
            return
        report = state.get("node_reports", {}).get(node_id, {})
        if not isinstance(report, Mapping) or report.get("status") != "committed":
            return
        counts = {
            "entity_count": int(report.get("entity_count", 0)),
            "relationship_count": int(report.get("relationship_count", 0)),
            "evidence_count": int(report.get("evidence_count", 0)),
        }
        self.database.add_event(
            str(state["task_id"]),
            "DATABASE_COMMIT",
            node_id=node_id,
            status=str(state.get("status", STATUS_RUNNING)),
            payload=counts,
        )

    def _route_function(self, current: str, plan: ExecutionPlan) -> Any:
        """Create the single conditional router for one graph node."""
        def route(state: TaskState) -> str:
            outcome = self.condition_engine.choose(plan, state, current)
            if outcome.target is None:
                self._record_route_event(state, current, outcome.reason, outcome.outcome)
                return END
            self._record_route_event(state, current, outcome.reason, outcome.outcome)
            return outcome.target
        return route

    @staticmethod
    def _route_targets(plan: ExecutionPlan) -> dict[str, str]:
        """Return the graph's dynamic route target map without business-node knowledge."""
        targets = {node_id: node_id for node_id in plan.order}
        targets[END] = END
        return targets

    def _record_route_event(
        self, state: Mapping[str, Any], current: str, reason: str, outcome: Mapping[str, Any],
    ) -> None:
        task_id = str(state.get("task_id", "")).strip()
        if task_id:
            self.database.add_event(
                task_id, "ROUTE_DECISION", node_id=current,
                status=str(state.get("status", STATUS_RUNNING)),
                payload={"reason": reason, **dict(outcome)},
            )

    @staticmethod
    def _state_signature(state: Mapping[str, Any]) -> tuple[Any, ...]:
        """Build a stable signature over the defined information-bearing shared-state fields."""
        keys = ("trade_nodes", "evidence_pool", "entities", "relationships", "fragments")
        return tuple(WorkflowEngine._freeze(state.get(key, [])) for key in keys)

    @staticmethod
    def _freeze(value: Any) -> Any:
        """Convert nested state values into a deterministic comparable structure."""
        if isinstance(value, Mapping):
            return tuple(sorted((str(key), WorkflowEngine._freeze(item)) for key, item in value.items()))
        if isinstance(value, (list, tuple)):
            return tuple(WorkflowEngine._freeze(item) for item in value)
        if isinstance(value, set):
            return tuple(sorted(WorkflowEngine._freeze(item) for item in value))
        return value

    @staticmethod
    def _step_count(state: Mapping[str, Any]) -> int:
        orchestration = state.get("orchestration", {})
        if not isinstance(orchestration, Mapping):
            return 0
        try:
            return max(0, int(orchestration.get("step_count", 0)))
        except (TypeError, ValueError) as exc:
            raise ValueError("state orchestration step_count must be an integer") from exc

    @staticmethod
    def _increment_steps(state: TaskState) -> None:
        orchestration = state.setdefault("orchestration", {})
        if not isinstance(orchestration, dict):
            raise TypeError("state['orchestration'] must be a dictionary")
        orchestration["step_count"] = WorkflowEngine._step_count(state) + 1

    @staticmethod
    def _no_progress_count(state: Mapping[str, Any]) -> int:
        orchestration = state.get("orchestration", {})
        if not isinstance(orchestration, Mapping):
            return 0
        try:
            return max(0, int(orchestration.get("no_progress_count", 0)))
        except (TypeError, ValueError) as exc:
            raise ValueError("state orchestration no_progress_count must be an integer") from exc

    @staticmethod
    def _set_no_progress_count(state: TaskState, value: int) -> None:
        orchestration = state.setdefault("orchestration", {})
        if not isinstance(orchestration, dict):
            raise TypeError("state['orchestration'] must be a dictionary")
        orchestration["no_progress_count"] = value

    @staticmethod
    def _set_recovery_action(state: TaskState, action: str) -> None:
        orchestration = state.setdefault("orchestration", {})
        if not isinstance(orchestration, dict):
            raise TypeError("state['orchestration'] must be a dictionary")
        orchestration["recovery_action"] = action
