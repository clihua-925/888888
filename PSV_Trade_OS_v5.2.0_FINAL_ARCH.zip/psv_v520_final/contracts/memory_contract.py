# -*- coding: utf-8 -*-
"""记忆契约 - 记忆存储统一格式"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class MemoryEntry(BaseModel):
    memory_id: Optional[str] = None
    memory_type: str = Field(..., description="short_term / long_term / industry / market / product / execution")
    task_id: Optional[str] = None
    key: str = Field(..., min_length=1)
    value: str = Field(..., min_length=1)
    embedding: Optional[List[float]] = None
    importance: float = Field(0.5, ge=0.0, le=1.0)
    tags: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None

    @validator('memory_type')
    def validate_type(cls, v):
        valid = ['short_term', 'long_term', 'industry', 'market', 'product', 'execution', 'customer']
        if v not in valid:
            raise ValueError(f"无效的记忆类型: {v}")
        return v
