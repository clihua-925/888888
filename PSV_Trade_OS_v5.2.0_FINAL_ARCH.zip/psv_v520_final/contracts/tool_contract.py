# -*- coding: utf-8 -*-
"""工具契约 - 所有工具调用的统一格式"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class ToolRequest(BaseModel):
    tool_name: str = Field(..., description="工具名称")
    parameters: Dict[str, Any] = Field(..., description="工具参数")
    timeout_sec: int = Field(60, ge=1, le=300)
    retry_count: int = Field(3, ge=0, le=10)

class ToolResponse(BaseModel):
    tool_name: str = Field(...)
    success: bool = Field(...)
    result: Any = Field(None)
    error: Optional[str] = None
    duration_sec: float = Field(0.0, ge=0.0)
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ToolRegistry:
    """工具注册表"""
    _tools: Dict[str, Any] = {}

    @classmethod
    def register(cls, name: str, handler: Any):
        cls._tools[name] = handler

    @classmethod
    def get(cls, name: str) -> Any:
        return cls._tools.get(name)

    @classmethod
    def list_tools(cls) -> List[str]:
        return list(cls._tools.keys())
