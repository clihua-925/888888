# -*- coding: utf-8 -*-
"""事件契约 - 系统事件统一格式"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class EventContract(BaseModel):
    event_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    event_type: str = Field(..., description="事件类型")
    source: str = Field(..., description="事件来源模块")
    task_id: Optional[str] = None
    workflow_id: Optional[str] = None
    agent_id: Optional[str] = None
    payload: Dict[str, Any] = Field(default_factory=dict)
    priority: int = Field(5, ge=1, le=10)
    timestamp: datetime = Field(default_factory=datetime.now)

    class Config:
        json_schema_extra = {
            "example": {
                "event_type": "agent.completed",
                "source": "company_discovery_agent",
                "task_id": "task_123",
                "payload": {"companies_found": 15}
            }
        }
