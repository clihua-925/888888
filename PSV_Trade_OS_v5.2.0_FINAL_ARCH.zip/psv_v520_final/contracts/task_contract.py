# -*- coding: utf-8 -*-
"""任务契约 - 统一任务格式"""
from pydantic import BaseModel, Field, validator
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class TaskContract(BaseModel):
    task_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16], description="任务唯一标识")
    objective: str = Field(..., min_length=1, description="任务目标，如'开发美国生日蜡烛进口商'")
    product: str = Field(..., description="目标产品")
    market: str = Field(..., description="目标市场，如'USA'")
    target_customer: Optional[str] = Field(None, description="目标客户类型，如'进口商/经销商'")
    constraints: Dict[str, Any] = Field(default_factory=dict, description="约束条件")
    workflow: Optional[List[Dict[str, Any]]] = Field(None, description="执行计划步骤")
    category_id: Optional[str] = Field(None, description="行业分类ID")
    created_at: datetime = Field(default_factory=datetime.now)

    @validator('market')
    def validate_market(cls, v):
        from shared.config import MARKETS
        if v and v not in MARKETS:
            raise ValueError(f"不支持的市场: {v}，支持的市场: {list(MARKETS.keys())}")
        return v

    @validator('product')
    def validate_product(cls, v):
        if not v or len(v.strip()) < 2:
            raise ValueError("产品名称至少2个字符")
        return v.strip()

    class Config:
        json_schema_extra = {
            "example": {
                "objective": "开发美国生日蜡烛进口商",
                "product": "birthday candles",
                "market": "USA",
                "target_customer": "importer",
                "constraints": {"max_results": 50, "min_shipments": 3}
            }
        }

class TaskResult(BaseModel):
    task_id: str
    status: str = Field(..., pattern="^(completed|failed|paused|cancelled)$")
    progress_pct: float = Field(0.0, ge=0.0, le=100.0)
    companies_found: int = Field(0, ge=0)
    companies_enriched: int = Field(0, ge=0)
    leads_scored: int = Field(0, ge=0)
    report_path: Optional[str] = None
    summary: str = ""
    error: Optional[str] = None
    duration_sec: float = 0.0
    completed_at: Optional[datetime] = None
