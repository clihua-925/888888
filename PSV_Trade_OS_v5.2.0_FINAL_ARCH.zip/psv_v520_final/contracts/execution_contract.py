# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import Any, Dict

class ExecutionContract(BaseModel):
    workflow_id: str
    agent_id: str
    status: str
    input_data: Dict[str, Any] = {}
    output_data: Dict[str, Any] = {}
