from pydantic import BaseModel, Field
from typing import Dict, Any, List
class WorkflowContract(BaseModel):
    workflow_id:str
    task_id:str
    objective:str
    state:Dict[str,Any]={}
    steps:List[str]=[]
