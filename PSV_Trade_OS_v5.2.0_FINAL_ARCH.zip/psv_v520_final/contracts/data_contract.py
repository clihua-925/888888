# -*- coding: utf-8 -*-
"""数据契约 - 统一数据交换格式"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class CompanyProfile(BaseModel):
    entity_id: Optional[str] = None
    name: str = Field(..., min_length=1)
    name_norm: Optional[str] = None
    country: Optional[str] = None
    website: Optional[str] = None
    industry: Optional[str] = None
    main_products: List[str] = Field(default_factory=list)
    purchase_direction: List[str] = Field(default_factory=list)
    company_size: Optional[str] = None
    supply_chain_role: Optional[str] = None
    contacts: List[Dict[str, Any]] = Field(default_factory=list)
    credibility_score: float = Field(0.0, ge=0.0, le=100.0)
    purchase_probability: float = Field(0.0, ge=0.0, le=100.0)
    match_score: float = Field(0.0, ge=0.0, le=100.0)
    deal_probability: float = Field(0.0, ge=0.0, le=100.0)
    evidence: List[Dict[str, Any]] = Field(default_factory=list)
    source: Optional[str] = None
    created_at: Optional[datetime] = None

class ContactInfo(BaseModel):
    name: Optional[str] = None
    title: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    linkedin: Optional[str] = None
    is_decision_maker: bool = False
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    source: Optional[str] = None

class MarketAnalysis(BaseModel):
    market_id: Optional[str] = None
    country_code: str = Field(..., min_length=2)
    market_size: Optional[float] = None
    growth_rate: Optional[float] = None
    competition_level: Optional[str] = None
    entry_difficulty: Optional[str] = None
    key_trends: List[str] = Field(default_factory=list)
    major_players: List[Dict[str, Any]] = Field(default_factory=list)
    opportunities: List[str] = Field(default_factory=list)
    risks: List[str] = Field(default_factory=list)
    analysis_date: datetime = Field(default_factory=datetime.now)

class LeadScore(BaseModel):
    entity_id: str = Field(..., min_length=1)
    company_strength: float = Field(0.0, ge=0.0, le=100.0)
    purchase_likelihood: float = Field(0.0, ge=0.0, le=100.0)
    match_degree: float = Field(0.0, ge=0.0, le=100.0)
    deal_probability: float = Field(0.0, ge=0.0, le=100.0)
    overall_score: float = Field(0.0, ge=0.0, le=100.0)
    tier: str = Field('D', pattern="^[SABCD]$")
    reasoning: str = ""
    factors: Dict[str, float] = Field(default_factory=dict)
    scored_at: datetime = Field(default_factory=datetime.now)

class SalesStrategy(BaseModel):
    entity_id: str = Field(..., min_length=1)
    strategy_type: str = Field(..., description="策略类型: initial/follow_up/negotiation")
    approach: str = Field(..., description="开发策略概述")
    email_subject: Optional[str] = None
    email_body: Optional[str] = None
    follow_up_plan: List[Dict[str, Any]] = Field(default_factory=list)
    recommended_contacts: List[str] = Field(default_factory=list)
    talking_points: List[str] = Field(default_factory=list)
    objections_handling: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.now)
