# -*- coding: utf-8 -*-
"""智能体契约 - 所有Agent的输入输出统一格式"""
from pydantic import BaseModel, Field, validator
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class AgentRequest(BaseModel):
    request_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    task_id: str = Field(..., description="关联任务ID")
    agent_type: str = Field(..., description="Agent类型")
    input_data: Dict[str, Any] = Field(..., description="输入数据")
    context: Dict[str, Any] = Field(default_factory=dict, description="上下文信息")
    priority: int = Field(1, ge=1, le=10, description="优先级1-10")
    timeout_sec: int = Field(300, ge=10, le=3600, description="超时时间")

    @validator('agent_type')
    def validate_agent_type(cls, v):
        valid_types = [
            'trade_planner', 'market_research', 'company_discovery',
            'company_enrichment', 'contact_discovery', 'lead_scoring',
            'sales_strategy', 'report'
        ]
        if v not in valid_types:
            raise ValueError(f"未知Agent类型: {v}")
        return v

class AgentResponse(BaseModel):
    response_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    request_id: str = Field(..., description="对应请求ID")
    task_id: str = Field(..., description="关联任务ID")
    agent_type: str = Field(..., description="Agent类型")
    result: Dict[str, Any] = Field(..., description="执行结果")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="置信度0-1")
    evidence: List[Dict[str, Any]] = Field(default_factory=list, description="证据链")
    next_action: Optional[str] = Field(None, description="建议下一步动作")
    status: str = Field(..., pattern="^(success|partial|failed|skipped)$")
    error: Optional[str] = Field(None, description="错误信息")
    duration_sec: float = Field(0.0, ge=0.0)
    timestamp: datetime = Field(default_factory=datetime.now)
    tool_calls: List[Dict[str, Any]] = Field(default_factory=list, description="工具调用记录")

    @validator('confidence')
    def validate_confidence(cls, v):
        if v < 0.3 and cls.status == 'success':
            # 低置信度的成功需要标记
            pass
        return v
