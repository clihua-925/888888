from pydantic import BaseModel
from typing import Dict,Any
class BusinessResult(BaseModel):
    entity_type:str
    data:Dict[str,Any]
    confidence:float=0
    evidence:list=[]
