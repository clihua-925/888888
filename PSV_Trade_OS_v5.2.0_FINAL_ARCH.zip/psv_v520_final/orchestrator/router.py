# -*- coding: utf-8 -*-
"""路由决策"""
from typing import Dict, Any

class Router:
    """工作流路由决策器"""

    @staticmethod
    def route_after_execution(state: Dict[str, Any]) -> str:
        errors = state.get("errors", [])
        if len(errors) > 3:
            return "fail"
        if state.get("should_continue", False):
            return "continue"
        return "fail"

    @staticmethod
    def route_after_validation(state: Dict[str, Any]) -> str:
        errors = state.get("errors", [])
        if errors and "Low confidence" in str(errors[-1]):
            return "invalid"
        return "valid"

    @staticmethod
    def route_after_checkpoint(state: Dict[str, Any]) -> str:
        if state.get("should_continue", False):
            return "continue"
        return "complete"
