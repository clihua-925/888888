# -*- coding: utf-8 -*-
"""Workflow validator for PSV Trade Intelligence OS v5.1.1"""

class WorkflowValidator:
    def validate(self, state):
        errors=[]
        task=state.get("task", {})
        if not task.get("objective"):
            errors.append("missing objective")
        if not state.get("agent_outputs") and not state.get("plan"):
            errors.append("empty workflow execution")
        return {"valid": not errors, "errors": errors}
