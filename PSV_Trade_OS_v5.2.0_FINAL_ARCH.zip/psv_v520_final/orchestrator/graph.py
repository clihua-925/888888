# -*- coding: utf-8 -*-
"""LangGraph Orchestrator - 核心运行引擎

核心流程：
用户输入外贸目标 → Trade Planner Agent → 生成任务计划 → Supervisor Agent
→ 调用不同业务Agent → 执行任务 → 结果验证 → 数据入库 → 生成报告

支持：暂停/恢复/继续执行
"""
from langgraph.graph import StateGraph, END
from orchestrator.state import TradeGraphState
from orchestrator.planner import TradePlanner
from orchestrator.supervisor import Supervisor
from orchestrator.executor import AgentExecutor
from orchestrator.router import Router
from psv_platform.recovery.recovery_service import RecoveryService
from psv_platform.audit.audit_logger import AuditLogger
from shared.state.workflow_state import StateManager
import time

class TradeOrchestrator:
    def __init__(self):
        self.planner = TradePlanner()
        self.supervisor = Supervisor()
        self.executor = AgentExecutor()
        self.router = Router()
        self.recovery = RecoveryService()
        self.audit = AuditLogger()
        self.state_manager = StateManager()
        self.graph = self._build_graph()

    def _build_graph(self):
        workflow = StateGraph(TradeGraphState)

        workflow.add_node("planner", self._node_planner)
        workflow.add_node("supervisor", self._node_supervisor)
        workflow.add_node("execute_agent", self._node_execute)
        workflow.add_node("validate", self._node_validate)
        workflow.add_node("checkpoint", self._node_checkpoint)
        workflow.add_node("finalize", self._node_finalize)

        workflow.set_entry_point("planner")
        workflow.add_edge("planner", "supervisor")
        workflow.add_edge("supervisor", "execute_agent")
        workflow.add_conditional_edges(
            "execute_agent",
            self._router,
            {"continue": "validate", "retry": "supervisor", "fail": "checkpoint"}
        )
        workflow.add_conditional_edges(
            "validate",
            self._validate_router,
            {"valid": "checkpoint", "invalid": "supervisor"}
        )
        workflow.add_conditional_edges(
            "checkpoint",
            self._checkpoint_router,
            {"continue": "supervisor", "complete": "finalize"}
        )
        workflow.add_edge("finalize", END)

        return workflow.compile()

    def _node_planner(self, state: TradeGraphState):
        task = state.get("task", {})
        plan_result = self.planner.plan(
            objective=task.get("objective", ""),
            product=task.get("product", ""),
            market=task.get("market", ""),
            target_customer=task.get("target_customer", "")
        )
        state["plan"] = plan_result.get("plan", [])
        state["current_step"] = 0
        state["should_continue"] = True
        state["agent_outputs"] = []
        state["errors"] = []
        return state

    def _node_supervisor(self, state: TradeGraphState):
        return self.supervisor.supervise(state.get("task", {}), state)

    def _node_execute(self, state: TradeGraphState):
        current_step = state.get("current_step", 0)
        plan = state.get("plan", [])

        if current_step >= len(plan):
            state["should_continue"] = False
            return state

        step = plan[current_step]
        agent_type = step.get("agent")
        task_id = state["task"].get("task_id", "unknown")

        # 构建输入数据，处理前序步骤依赖
        input_data = step.get("input", {}).copy()
        outputs = state.get("agent_outputs", [])
        for key, val in list(input_data.items()):
            if val == "from_step_2" and len(outputs) >= 1:
                input_data[key] = outputs[0].get("result", {})
            elif val == "from_step_3" and len(outputs) >= 2:
                input_data[key] = outputs[1].get("result", {})
            elif val == "from_step_4" and len(outputs) >= 3:
                input_data[key] = outputs[2].get("result", {})
            elif val == "from_step_5" and len(outputs) >= 4:
                input_data[key] = outputs[3].get("result", {})
            elif val == "from_step_6" and len(outputs) >= 5:
                input_data[key] = outputs[4].get("result", {})
            elif val == "aggregated":
                aggregated = {}
                for out in outputs:
                    aggregated[out.get("agent_type", "unknown")] = out
                input_data[key] = aggregated

        try:
            response = self.executor.execute(
                agent_type=agent_type,
                task_id=task_id,
                input_data=input_data,
                context={"step": current_step, "plan": plan}
            )

            state["agent_outputs"] = state.get("agent_outputs", []) + [{
                "agent_type": agent_type,
                "result": response.result,
                "confidence": response.confidence,
                "status": response.status,
            }]
            state["current_step"] = current_step + 1

        except Exception as e:
            state["errors"] = state.get("errors", []) + [f"{agent_type}: {str(e)}"]

        return state

    def _node_validate(self, state: TradeGraphState):
        outputs = state.get("agent_outputs", [])
        if outputs:
            last = outputs[-1]
            if last.get("confidence", 0) < 0.3:
                state["errors"] = state.get("errors", []) + [f"Low confidence: {last.get('agent_type')}"]
        return state

    def _node_checkpoint(self, state: TradeGraphState):
        task_id = state["task"].get("task_id", "")
        current_step = state.get("current_step", 0)
        self.recovery.save_checkpoint(
            task_id=task_id,
            node_name=f"step_{current_step}",
            node_state=dict(state),
            agent_outputs=state.get("agent_outputs", [])
        )
        state["checkpoint_id"] = f"chk_{task_id}_{current_step}"
        return state

    def _node_finalize(self, state: TradeGraphState):
        state["should_continue"] = False
        outputs = state.get("agent_outputs", [])

        # 聚合所有结果
        all_results = {}
        for out in outputs:
            all_results[out["agent_type"]] = out

        # 调用Report Agent生成最终报告
        try:
            report_response = self.executor.execute(
                agent_type="report",
                task_id=state["task"].get("task_id", ""),
                input_data={
                    "all_previous_results": all_results,
                    "objective": state["task"].get("objective", "")
                }
            )
            state["final_report"] = report_response.result.get("report", "")
        except Exception as e:
            state["final_report"] = f"报告生成失败: {e}"

        return state

    def _router(self, state: TradeGraphState):
        return self.router.route_after_execution(state)

    def _validate_router(self, state: TradeGraphState):
        return self.router.route_after_validation(state)

    def _checkpoint_router(self, state: TradeGraphState):
        return self.router.route_after_checkpoint(state)

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """运行完整工作流"""
        initial_state = TradeGraphState(
            task=task,
            plan=[],
            current_step=0,
            agent_outputs=[],
            errors=[],
            should_continue=True,
            checkpoint_id=None,
            final_report=None,
            context={},
        )

        self.audit.log_task_start(
            task_id=task.get("task_id", ""),
            objective=task.get("objective", "")
        )

        t0 = time.time()
        result = self.graph.invoke(initial_state)
        duration = time.time() - t0

        self.audit.log_task_end(
            task_id=task.get("task_id", ""),
            status="completed" if not result.get("errors") else "partial",
            result_summary={"report_generated": bool(result.get("final_report"))},
            duration_sec=duration
        )

        return dict(result)
