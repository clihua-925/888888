# -*- coding: utf-8 -*-
"""Orchestrator级别的恢复协调"""
from psv_platform.recovery.recovery_service import RecoveryService

class RecoveryCoordinator:
    def __init__(self):
        self.service = RecoveryService()

    def attempt_resume(self, task_id: str) -> Dict[str, Any]:
        return self.service.resume_task(task_id)
