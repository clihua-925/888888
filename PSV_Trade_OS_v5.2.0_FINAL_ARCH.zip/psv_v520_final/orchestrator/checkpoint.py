# -*- coding: utf-8 -*-
"""检查点管理"""
import json
import time
from typing import Dict, Any

from psv_platform.recovery.recovery_service import RecoveryService

class CheckpointManager:
    def __init__(self):
        self.recovery = RecoveryService()

    def save(self, task_id: str, node_name: str, state: Dict[str, Any], agent_outputs: list):
        return self.recovery.save_checkpoint(task_id, node_name, state, agent_outputs)

    def load(self, task_id: str) -> Dict[str, Any]:
        return self.recovery.load_checkpoint(task_id)

    def can_resume(self, task_id: str) -> bool:
        return self.recovery.can_resume(task_id)
