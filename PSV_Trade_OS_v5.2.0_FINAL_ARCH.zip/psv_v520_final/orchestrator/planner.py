# -*- coding: utf-8 -*-
"""Trade Planner - 生成执行计划"""
from typing import Dict, List, Any
from agents.trade_planner import TradePlannerAgent
from contracts.agent_contract import AgentRequest

class TradePlanner:
    def __init__(self):
        self.agent = TradePlannerAgent()

    def plan(self, objective: str, product: str, market: str, target_customer: str = None) -> Dict[str, Any]:
        request = AgentRequest(
            task_id="planning",
            agent_type="trade_planner",
            input_data={
                "objective": objective,
                "product": product,
                "market": market,
                "target_customer": target_customer or "importer",
            }
        )
        response = self.agent.execute(request)
        return response.result
