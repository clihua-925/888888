# -*- coding: utf-8 -*-
"""执行器 - 调用具体Agent"""
from typing import Dict, List, Any
import time

from contracts.agent_contract import AgentRequest, AgentResponse
from agents.market_research import MarketResearchAgent
from agents.company_discovery import CompanyDiscoveryAgent
from agents.company_enrichment import CompanyEnrichmentAgent
from agents.contact_discovery import ContactDiscoveryAgent
from agents.lead_scoring import LeadScoringAgent
from agents.sales_strategy import SalesStrategyAgent
from agents.report import ReportAgent

class AgentExecutor:
    def __init__(self):
        self.agents = {
            "market_research": MarketResearchAgent(),
            "company_discovery": CompanyDiscoveryAgent(),
            "company_enrichment": CompanyEnrichmentAgent(),
            "contact_discovery": ContactDiscoveryAgent(),
            "lead_scoring": LeadScoringAgent(),
            "sales_strategy": SalesStrategyAgent(),
            "report": ReportAgent(),
        }

    def execute(self, agent_type: str, task_id: str, input_data: Dict[str, Any], context: Dict[str, Any] = None) -> AgentResponse:
        agent = self.agents.get(agent_type)
        if not agent:
            raise ValueError(f"未知Agent类型: {agent_type}")

        request = AgentRequest(
            task_id=task_id,
            agent_type=agent_type,
            input_data=input_data,
            context=context or {},
        )

        return agent.execute(request)
