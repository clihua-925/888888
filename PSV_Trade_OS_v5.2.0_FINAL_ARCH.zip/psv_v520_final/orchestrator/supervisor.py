# -*- coding: utf-8 -*-
"""Supervisor Agent - 监督执行"""
from typing import Dict, List, Any
from shared.state.workflow_state import StateManager

class Supervisor:
    def __init__(self):
        self.state_manager = StateManager()

    def supervise(self, task: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        current_step = state.get("current_step", 0)
        plan = state.get("plan", [])

        if current_step >= len(plan):
            state["should_continue"] = False
            return state

        step = plan[current_step]
        state["current_node"] = step.get("node", "unknown")
        state["current_agent"] = step.get("agent", "unknown")

        return state
