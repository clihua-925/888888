# -*- coding: utf-8 -*-
"""LangGraph 状态定义"""
from typing import Dict, List, Any, Optional, TypedDict

class TradeGraphState(TypedDict, total=False):
    task: Dict[str, Any]
    plan: List[Dict[str, Any]]
    current_step: int
    agent_outputs: List[Dict[str, Any]]
    errors: List[str]
    should_continue: bool
    checkpoint_id: Optional[str]
    final_report: Optional[str]
    context: Dict[str, Any]
