@echo off
chcp 65001 >nul
cd /d %~dp0

if not exist venv\Scripts\python.exe (
    echo Python environment missing. Running install...
    call install.bat
)

venv\Scripts\python.exe verify_startup.py
if errorlevel 1 pause & exit /b 1

venv\Scripts\python.exe run_webui.py
pause
