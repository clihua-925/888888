# -*- coding: utf-8 -*-
"""PSV Trade Intelligence OS - 统一数据库模型 (SQLAlchemy 2.0)

核心原则：
1. 所有表围绕外贸业务设计
2. 一个实体 = 一个 entity_id + 多角色/关系/证据
3. 智能体执行、审计、记忆全部持久化
4. 支持任务中断恢复（checkpoint持久化）
"""
from sqlalchemy import (
    create_engine, Column, Integer, String, Text, Float, 
    Boolean, DateTime, ForeignKey, JSON, Index, UniqueConstraint
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from sqlalchemy.sql import func
from datetime import datetime
import uuid
import json

from shared.config.settings import DATABASE_URL

Base = declarative_base()
engine = create_engine(DATABASE_URL, echo=False, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def generate_uuid():
    return uuid.uuid4().hex[:16]

# ========== 1. 贸易企业表 ==========
class TradeCompany(Base):
    __tablename__ = 'trade_company'

    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    name = Column(String(500), nullable=False, index=True)
    name_norm = Column(String(500), index=True)  # 归一化名称
    country = Column(String(100), index=True)
    website = Column(String(500))
    industry = Column(String(200), index=True)
    main_products = Column(JSON)  # 主营产品列表
    purchase_direction = Column(JSON)  # 采购方向
    company_size = Column(String(50))  # 企业规模
    supply_chain_role = Column(String(100))  # 供应链角色
    credibility_score = Column(Float, default=0.0)  # 可信度评分
    purchase_probability = Column(Float, default=0.0)  # 采购可能性
    match_score = Column(Float, default=0.0)  # 匹配程度
    deal_probability = Column(Float, default=0.0)  # 成交概率
    development_priority = Column(Integer, default=0)  # 开发优先级
    development_stage = Column(String(50), default='new')  # 开发阶段
    customer_tier = Column(String(10), default='D')  # 客户等级 S/A/B/C/D
    is_active = Column(Boolean, default=True)
    source = Column(String(200))  # 数据来源
    evidence = Column(JSON)  # 证据链
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    contacts = relationship("TradeContact", back_populates="company", cascade="all, delete-orphan")
    opportunities = relationship("TradeOpportunity", back_populates="company")
    audit_logs = relationship("AuditEvent", back_populates="company")

# ========== 2. 联系人表 ==========
class TradeContact(Base):
    __tablename__ = 'trade_contact'

    id = Column(Integer, primary_key=True, autoincrement=True)
    contact_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    name = Column(String(200))
    title = Column(String(200))  # 职位
    email = Column(String(300), index=True)
    phone = Column(String(100))
    linkedin = Column(String(500))
    is_decision_maker = Column(Boolean, default=False)
    confidence = Column(Float, default=0.0)
    source = Column(String(200))
    verified = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    company = relationship("TradeCompany", back_populates="contacts")

# ========== 3. 产品表 ==========
class TradeProduct(Base):
    __tablename__ = 'trade_product'

    id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    name = Column(String(300), nullable=False, index=True)
    hs_code = Column(String(50), index=True)
    category = Column(String(200), index=True)
    description = Column(Text)
    target_markets = Column(JSON)
    competitors = Column(JSON)
    price_range = Column(String(200))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

# ========== 4. 市场表 ==========
class TradeMarket(Base):
    __tablename__ = 'trade_market'

    id = Column(Integer, primary_key=True, autoincrement=True)
    market_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    country_code = Column(String(10), unique=True, index=True)
    country_name = Column(String(200))
    currency = Column(String(10))
    language = Column(String(50))
    customs_source = Column(String(200))
    market_size = Column(Float)
    growth_rate = Column(Float)
    competition_level = Column(String(50))
    entry_difficulty = Column(String(50))
    analysis_data = Column(JSON)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

# ========== 5. 客户池表 ==========
class TradeCustomerPool(Base):
    __tablename__ = 'trade_customer_pool'

    id = Column(Integer, primary_key=True, autoincrement=True)
    pool_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    product_id = Column(String(32), ForeignKey('trade_product.product_id'))
    market_id = Column(String(32), ForeignKey('trade_market.market_id'))
    customer_value = Column(Float, default=0.0)  # 客户价值
    match_score = Column(Float, default=0.0)  # 匹配程度
    deal_probability = Column(Float, default=0.0)  # 成交概率
    development_priority = Column(Integer, default=0)
    follow_up_status = Column(String(100), default='new')
    last_contact_date = Column(DateTime)
    next_action = Column(Text)
    notes = Column(Text)
    assigned_to = Column(String(200))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    company = relationship("TradeCompany")
    product = relationship("TradeProduct")
    market = relationship("TradeMarket")

# ========== 6. 商业机会表 ==========
class TradeOpportunity(Base):
    __tablename__ = 'trade_opportunity'

    id = Column(Integer, primary_key=True, autoincrement=True)
    opportunity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    title = Column(String(500))
    description = Column(Text)
    estimated_value = Column(Float, default=0.0)
    probability = Column(Float, default=0.0)
    expected_close_date = Column(DateTime)
    stage = Column(String(50), default='discovery')
    source_agent = Column(String(200))  # 发现该机会的Agent
    strategy_recommendation = Column(Text)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    company = relationship("TradeCompany", back_populates="opportunities")

# ========== 7. 任务表 ==========
class TradeTask(Base):
    __tablename__ = 'trade_task'

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    objective = Column(Text, nullable=False)  # 任务目标
    product = Column(String(300), index=True)
    market = Column(String(100), index=True)
    target_customer = Column(String(300))
    constraints = Column(JSON)
    workflow = Column(JSON)  # 执行计划
    status = Column(String(50), default='pending')  # pending/running/paused/completed/failed
    progress_pct = Column(Float, default=0.0)
    current_stage = Column(String(200))
    current_node = Column(String(200))
    resume_state = Column(Text)  # 恢复状态(JSON)
    result_summary = Column(Text)
    report_path = Column(String(500))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    completed_at = Column(DateTime)

# ========== 8. 工作流执行表 ==========
class TradeWorkflow(Base):
    __tablename__ = 'trade_workflow'

    id = Column(Integer, primary_key=True, autoincrement=True)
    workflow_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    task_id = Column(String(32), ForeignKey('trade_task.task_id'), index=True)
    workflow_type = Column(String(200))  # 工作流类型
    graph_state = Column(Text)  # LangGraph状态快照
    checkpoint_data = Column(Text)  # 检查点数据
    is_resumable = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

# ========== 9. 智能体执行日志表 ==========
class AgentExecutionLog(Base):
    __tablename__ = 'agent_execution_log'

    id = Column(Integer, primary_key=True, autoincrement=True)
    log_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    task_id = Column(String(32), ForeignKey('trade_task.task_id'), index=True)
    workflow_id = Column(String(32), ForeignKey('trade_workflow.workflow_id'))
    agent_type = Column(String(200), index=True)  # Agent类型
    agent_name = Column(String(200))
    input_data = Column(Text)  # 输入数据
    output_data = Column(Text)  # 输出数据
    confidence = Column(Float, default=0.0)
    evidence = Column(Text)
    duration_sec = Column(Float, default=0.0)
    status = Column(String(50), default='pending')
    error_message = Column(Text)
    tool_calls = Column(JSON)  # 工具调用记录
    created_at = Column(DateTime, default=func.now())

# ========== 10. 审计事件表 ==========
class AuditEvent(Base):
    __tablename__ = 'audit_event'

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    task_id = Column(String(32), index=True)
    workflow_id = Column(String(32), index=True)
    agent_id = Column(String(32), index=True)
    event_type = Column(String(100), index=True)  # task_start/agent_call/tool_call/data_write/checkpoint/error
    input_data = Column(Text)
    output_data = Column(Text)
    tool_call = Column(JSON)
    duration_sec = Column(Float, default=0.0)
    status = Column(String(50))
    error_details = Column(Text)
    ip_address = Column(String(100))
    user_agent = Column(String(500))
    timestamp = Column(DateTime, default=func.now(), index=True)

    company = relationship("TradeCompany", foreign_keys=[agent_id], primaryjoin="TradeCompany.entity_id==AuditEvent.agent_id")

# ========== 11. 记忆存储表 ==========
class MemoryStore(Base):
    __tablename__ = 'memory_store'

    id = Column(Integer, primary_key=True, autoincrement=True)
    memory_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    memory_type = Column(String(100), index=True)  # short_term / long_term / industry / market / product
    task_id = Column(String(32), index=True)
    key = Column(String(500), index=True)
    value = Column(Text)
    embedding = Column(Text)  # 向量嵌入(JSON)
    importance = Column(Float, default=0.5)
    access_count = Column(Integer, default=0)
    last_accessed = Column(DateTime, default=func.now())
    created_at = Column(DateTime, default=func.now())
    expires_at = Column(DateTime)

# ========== 12. 海关原始数据表（只读） ==========
class CustomsRaw(Base):
    __tablename__ = 'customs_raw'

    id = Column(Integer, primary_key=True, autoincrement=True)
    row_hash = Column(String(64), unique=True, index=True)
    bol = Column(String(100))  # 提单号
    ts = Column(Float)  # 时间戳
    importer = Column(String(500), index=True)
    importer_norm = Column(String(500), index=True)
    shipper = Column(String(500), index=True)
    notify = Column(String(500))
    hs = Column(String(50), index=True)
    descr = Column(Text)
    qty = Column(Float)
    weight = Column(Float)
    teu = Column(Float)
    origin = Column(String(200))
    port_load = Column(String(200))
    port_discharge = Column(String(200))
    source_file = Column(String(500))
    direct_importer = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())

# ========== 13. 贸易关系表 ==========
class TradeRelationship(Base):
    __tablename__ = 'trade_relationship'

    id = Column(Integer, primary_key=True, autoincrement=True)
    relationship_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    from_entity_id = Column(String(32), index=True)
    to_entity_id = Column(String(32), index=True)
    relation_type = Column(String(100), index=True)  # supplier/customer/competitor/partner
    evidence = Column(JSON)
    confidence = Column(Float, default=0.0)
    first_seen = Column(DateTime)
    last_seen = Column(DateTime)
    created_at = Column(DateTime, default=func.now())

    __table_args__ = (UniqueConstraint('from_entity_id', 'to_entity_id', 'relation_type', name='uq_relationship'),)

# ========== 初始化函数 ==========
def init_database():
    """创建所有表"""
    Base.metadata.create_all(bind=engine)
    print("✅ 数据库初始化完成，所有表已创建")

def drop_all_tables():
    """删除所有表（危险操作）"""
    Base.metadata.drop_all(bind=engine)
    print("⚠️ 所有表已删除")
