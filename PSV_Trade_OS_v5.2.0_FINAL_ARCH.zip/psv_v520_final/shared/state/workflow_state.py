# -*- coding: utf-8 -*-
"""工作流状态管理 - 支持暂停/恢复/继续执行"""
import json
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict

from database.models import TradeWorkflow, TradeTask, SessionLocal

@dataclass
class WorkflowState:
    """LangGraph 工作流状态"""
    task_id: str
    current_step: int = 0
    total_steps: int = 0
    plan: List[Dict[str, Any]] = None
    agent_outputs: List[Dict[str, Any]] = None
    errors: List[str] = None
    should_continue: bool = True
    checkpoint_id: Optional[str] = None
    final_report: Optional[str] = None
    context: Dict[str, Any] = None

    def __post_init__(self):
        if self.plan is None:
            self.plan = []
        if self.agent_outputs is None:
            self.agent_outputs = []
        if self.errors is None:
            self.errors = []
        if self.context is None:
            self.context = {}

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WorkflowState':
        return cls(**data)

class StateManager:
    """状态管理器：持久化工作流状态，支持中断恢复"""

    def __init__(self):
        self._db = SessionLocal()
        self._active_states: Dict[str, WorkflowState] = {}

    def create_state(self, task_id: str, plan: List[Dict[str, Any]]) -> WorkflowState:
        """创建新的工作流状态"""
        state = WorkflowState(
            task_id=task_id,
            total_steps=len(plan),
            plan=plan,
        )
        self._active_states[task_id] = state
        self._persist_state(task_id, state)
        return state

    def get_state(self, task_id: str) -> Optional[WorkflowState]:
        """获取当前状态（优先内存，其次数据库）"""
        if task_id in self._active_states:
            return self._active_states[task_id]

        # 从数据库恢复
        return self._load_state(task_id)

    def update_state(self, task_id: str, updates: Dict[str, Any]) -> WorkflowState:
        """更新状态"""
        state = self.get_state(task_id)
        if not state:
            raise ValueError(f"未找到任务状态: {task_id}")

        for key, value in updates.items():
            if hasattr(state, key):
                setattr(state, key, value)

        self._active_states[task_id] = state
        self._persist_state(task_id, state)
        return state

    def save_checkpoint(self, task_id: str, node_name: str, node_state: Dict[str, Any]) -> str:
        """保存检查点"""
        checkpoint_id = f"chk_{task_id}_{int(time.time())}"

        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id
        ).first()

        if not workflow:
            workflow = TradeWorkflow(
                task_id=task_id,
                workflow_type='trade_development',
                checkpoint_data=json.dumps({
                    'checkpoint_id': checkpoint_id,
                    'node_name': node_name,
                    'node_state': node_state,
                    'timestamp': time.time(),
                }),
                is_resumable=True,
            )
            self._db.add(workflow)
        else:
            workflow.checkpoint_data = json.dumps({
                'checkpoint_id': checkpoint_id,
                'node_name': node_name,
                'node_state': node_state,
                'timestamp': time.time(),
            })
            workflow.is_resumable = True

        self._db.commit()
        return checkpoint_id

    def load_checkpoint(self, task_id: str) -> Optional[Dict[str, Any]]:
        """加载最新检查点"""
        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id,
            TradeWorkflow.is_resumable == True
        ).order_by(TradeWorkflow.updated_at.desc()).first()

        if workflow and workflow.checkpoint_data:
            return json.loads(workflow.checkpoint_data)
        return None

    def _persist_state(self, task_id: str, state: WorkflowState):
        """持久化状态到数据库"""
        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id
        ).first()

        if workflow:
            workflow.graph_state = json.dumps(state.to_dict())
            workflow.updated_at = datetime.now()
        else:
            workflow = TradeWorkflow(
                task_id=task_id,
                workflow_type='trade_development',
                graph_state=json.dumps(state.to_dict()),
                is_resumable=True,
            )
            self._db.add(workflow)

        self._db.commit()

    def _load_state(self, task_id: str) -> Optional[WorkflowState]:
        """从数据库加载状态"""
        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id
        ).order_by(TradeWorkflow.updated_at.desc()).first()

        if workflow and workflow.graph_state:
            try:
                data = json.loads(workflow.graph_state)
                state = WorkflowState.from_dict(data)
                self._active_states[task_id] = state
                return state
            except Exception as e:
                print(f"⚠️ 状态加载失败: {e}")
        return None

    def clear_state(self, task_id: str):
        """清除状态"""
        if task_id in self._active_states:
            del self._active_states[task_id]

from datetime import datetime
