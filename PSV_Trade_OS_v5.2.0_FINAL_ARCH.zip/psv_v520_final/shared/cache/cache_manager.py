# -*- coding: utf-8 -*-
"""缓存管理器 - Redis + 本地磁盘缓存"""
import json
import hashlib
import time
from typing import Any, Optional
from pathlib import Path

from shared.config import BASE_DIR

class CacheManager:
    """统一缓存管理"""

    def __init__(self):
        self._memory_cache: dict = {}
        self._disk_cache_dir = Path(BASE_DIR) / 'data' / 'cache'
        self._disk_cache_dir.mkdir(parents=True, exist_ok=True)
        self._redis = None

        # 尝试连接Redis
        try:
            import redis
            self._redis = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)
            self._redis.ping()
            print("✅ Redis缓存已连接")
        except:
            print("⚠️ Redis未连接，使用内存+磁盘缓存")

    def _make_key(self, prefix: str, *args) -> str:
        """生成缓存键"""
        content = json.dumps(args, sort_keys=True, ensure_ascii=False)
        hash_val = hashlib.md5(content.encode()).hexdigest()[:16]
        return f"{prefix}:{hash_val}"

    def get(self, key: str, default=None) -> Any:
        """获取缓存"""
        # 1. 内存缓存
        if key in self._memory_cache:
            entry = self._memory_cache[key]
            if entry['expires'] > time.time():
                return entry['value']
            del self._memory_cache[key]

        # 2. Redis缓存
        if self._redis:
            try:
                val = self._redis.get(key)
                if val:
                    return json.loads(val)
            except:
                pass

        # 3. 磁盘缓存
        disk_path = self._disk_cache_dir / f"{key}.json"
        if disk_path.exists():
            try:
                with open(disk_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if data.get('expires', 0) > time.time():
                    return data['value']
                disk_path.unlink()
            except:
                pass

        return default

    def set(self, key: str, value: Any, ttl: int = 3600):
        """设置缓存"""
        expires = time.time() + ttl

        # 内存缓存
        self._memory_cache[key] = {'value': value, 'expires': expires}

        # Redis缓存
        if self._redis:
            try:
                self._redis.setex(key, ttl, json.dumps(value, ensure_ascii=False))
            except:
                pass

        # 磁盘缓存（大对象）
        if len(json.dumps(value)) > 10000:
            disk_path = self._disk_cache_dir / f"{key}.json"
            with open(disk_path, 'w', encoding='utf-8') as f:
                json.dump({'value': value, 'expires': expires}, f, ensure_ascii=False)

    def delete(self, key: str):
        """删除缓存"""
        if key in self._memory_cache:
            del self._memory_cache[key]
        if self._redis:
            try:
                self._redis.delete(key)
            except:
                pass
        disk_path = self._disk_cache_dir / f"{key}.json"
        if disk_path.exists():
            disk_path.unlink()

    def clear(self):
        """清空缓存"""
        self._memory_cache.clear()
        if self._redis:
            try:
                self._redis.flushdb()
            except:
                pass
        for f in self._disk_cache_dir.glob("*.json"):
            f.unlink()
