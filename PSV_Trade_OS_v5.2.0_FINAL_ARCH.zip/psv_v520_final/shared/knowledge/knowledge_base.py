# -*- coding: utf-8 -*-
"""知识库 - 行业知识、市场知识、产品知识、企业知识"""
import json
from typing import Dict, List, Any, Optional
from shared.memory.memory_manager import MemoryManager
from contracts.memory_contract import MemoryEntry

class KnowledgeBase:
    """统一知识库管理"""

    def __init__(self):
        self.memory = MemoryManager()
        self._industry_templates = self._load_industry_templates()

    def _load_industry_templates(self) -> Dict[str, Any]:
        """加载行业模板"""
        return {
            'candle': {
                'hs_codes': ['3406.00', '9505.10'],
                'keywords': ['birthday candle', 'party candle', 'decorative candle', 'scented candle'],
                'target_markets': ['USA', 'EU', 'UK', 'CA'],
                'seasonality': {'peak': ['Q3', 'Q4'], 'low': ['Q1', 'Q2']},
                'certifications': ['FDA', 'CE', 'REACH'],
            },
            'enamel_pot': {
                'hs_codes': ['7323.99', '7615.19'],
                'keywords': ['enamel cookware', 'cast iron pot', 'dutch oven', 'casserole'],
                'target_markets': ['USA', 'EU', 'JP'],
                'seasonality': {'peak': ['Q4'], 'low': ['Q2']},
                'certifications': ['FDA', 'LFGB', 'EU 10/2011'],
            },
            'felt': {
                'hs_codes': ['5601.22', '5602.10'],
                'keywords': ['felt pad', 'felt sheet', 'industrial felt', 'wool felt'],
                'target_markets': ['USA', 'EU', 'AU'],
                'seasonality': {'peak': ['Q1', 'Q2'], 'low': ['Q3', 'Q4']},
                'certifications': ['OEKO-TEX', 'REACH'],
            },
        }

    def get_industry_profile(self, industry: str) -> Dict[str, Any]:
        """获取行业画像"""
        category = industry.lower().strip()
        from shared.config import INDUSTRY_MAP
        mapped = INDUSTRY_MAP.get(category, category)

        template = self._industry_templates.get(mapped, {})

        # 从长期记忆补充
        memories = self.memory.get_industry_knowledge(mapped)
        additional = {}
        for m in memories:
            try:
                data = json.loads(m.value)
                additional.update(data)
            except:
                pass

        return {**template, **additional, 'industry': mapped}

    def get_market_profile(self, market_code: str) -> Dict[str, Any]:
        """获取市场画像"""
        from shared.config import MARKETS
        base = MARKETS.get(market_code, {})

        memories = self.memory.get_market_knowledge(market_code)
        additional = {}
        for m in memories:
            try:
                data = json.loads(m.value)
                additional.update(data)
            except:
                pass

        return {**base, **additional, 'market_code': market_code}

    def get_product_profile(self, product: str) -> Dict[str, Any]:
        """获取产品画像"""
        from shared.config import INDUSTRY_MAP
        category = INDUSTRY_MAP.get(product.lower().strip(), product.lower().strip())
        industry = self.get_industry_profile(category)

        memories = self.memory.get_product_knowledge(product)
        additional = {}
        for m in memories:
            try:
                data = json.loads(m.value)
                additional.update(data)
            except:
                pass

        return {
            'product': product,
            'category': category,
            'hs_codes': industry.get('hs_codes', []),
            'keywords': industry.get('keywords', []),
            'target_markets': industry.get('target_markets', []),
            **additional,
        }

    def add_knowledge(self, knowledge_type: str, key: str, value: Dict[str, Any], 
                      task_id: Optional[str] = None):
        """添加知识"""
        entry = MemoryEntry(
            memory_type=knowledge_type,
            task_id=task_id,
            key=key,
            value=json.dumps(value, ensure_ascii=False),
            importance=0.7,
        )
        self.memory.store(entry)

    def search_knowledge(self, query: str, knowledge_type: Optional[str] = None, 
                         top_k: int = 10) -> List[Dict[str, Any]]:
        """搜索知识"""
        return self.memory.search_similar(query, knowledge_type, top_k)
