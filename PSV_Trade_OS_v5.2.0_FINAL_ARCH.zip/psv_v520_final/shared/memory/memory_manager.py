# -*- coding: utf-8 -*-
"""记忆管理器 - 短期记忆 + 长期记忆 + 向量检索"""
import json
import time
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import numpy as np

from contracts.memory_contract import MemoryEntry

class MemoryManager:
    """统一记忆管理：
    - 短期记忆：当前任务状态（内存 + 数据库）
    - 长期记忆：历史任务、行业知识、客户数据、执行经验（向量数据库）
    """

    def __init__(self):
        self._short_term: Dict[str, Any] = {}  # 内存级短期记忆
        self._db = None
        self._vector_store = None
        try:
            import chromadb
            from shared.config import VECTOR_DB_PATH
            self._chroma = chromadb.PersistentClient(path=VECTOR_DB_PATH)
            self._collection = self._chroma.get_or_create_collection("psv_memory")
            self._vector_store = True
        except Exception as e:
            print(f"⚠️ 向量数据库未初始化（使用纯文本模式）: {e}")
            self._vector_store = None

    def _get_db(self):
        """Lazy database access to prevent import cycles."""
        if self._db is None:
            from database.models import SessionLocal
            self._db = SessionLocal()
        return self._db

    # ========== 短期记忆 ==========
    def set_short_term(self, task_id: str, key: str, value: Any):
        """设置短期记忆"""
        if task_id not in self._short_term:
            self._short_term[task_id] = {}
        self._short_term[task_id][key] = {
            'value': value,
            'timestamp': time.time(),
        }

    def get_short_term(self, task_id: str, key: str, default=None) -> Any:
        """获取短期记忆"""
        if task_id in self._short_term and key in self._short_term[task_id]:
            return self._short_term[task_id][key]['value']
        return default

    def get_all_short_term(self, task_id: str) -> Dict[str, Any]:
        """获取任务全部短期记忆"""
        result = {}
        if task_id in self._short_term:
            for k, v in self._short_term[task_id].items():
                result[k] = v['value']
        return result

    def clear_short_term(self, task_id: str):
        """清除任务短期记忆"""
        if task_id in self._short_term:
            del self._short_term[task_id]

    # ========== 长期记忆（数据库） ==========
    def store(self, entry: MemoryEntry) -> str:
        """存储记忆到数据库"""
        db_entry = MemoryStore(
            memory_type=entry.memory_type,
            task_id=entry.task_id,
            key=entry.key,
            value=entry.value,
            embedding=json.dumps(entry.embedding) if entry.embedding else None,
            importance=entry.importance,
            expires_at=entry.expires_at,
        )
        self._db.add(db_entry)
        self._db.commit()
        self._db.refresh(db_entry)

        # 同时存入向量数据库
        if self._vector_store and entry.embedding:
            self._collection.add(
                ids=[db_entry.memory_id],
                embeddings=[entry.embedding],
                metadatas=[{
                    'type': entry.memory_type,
                    'task_id': entry.task_id or '',
                    'key': entry.key,
                    'importance': entry.importance,
                }],
                documents=[entry.value]
            )

        return db_entry.memory_id

    def retrieve(self, memory_type: str, task_id: Optional[str] = None, 
                 key_pattern: Optional[str] = None, limit: int = 50) -> List[MemoryEntry]:
        """检索记忆"""
        query = self._db.query(MemoryStore).filter(MemoryStore.memory_type == memory_type)
        if task_id:
            query = query.filter(MemoryStore.task_id == task_id)
        if key_pattern:
            query = query.filter(MemoryStore.key.like(f"%{key_pattern}%"))

        results = query.order_by(MemoryStore.importance.desc()).limit(limit).all()

        return [MemoryEntry(
            memory_id=r.memory_id,
            memory_type=r.memory_type,
            task_id=r.task_id,
            key=r.key,
            value=r.value,
            embedding=json.loads(r.embedding) if r.embedding else None,
            importance=r.importance,
        ) for r in results]

    def search_similar(self, query_text: str, memory_type: Optional[str] = None, 
                       top_k: int = 10) -> List[Dict[str, Any]]:
        """语义相似度搜索（需要向量数据库）"""
        if not self._vector_store:
            # 回退到关键词搜索
            return self._keyword_search(query_text, memory_type, top_k)

        try:
            from langchain_openai import OpenAIEmbeddings
            embeddings = OpenAIEmbeddings()
            query_embedding = embeddings.embed_query(query_text)

            where_filter = {"type": memory_type} if memory_type else None
            results = self._collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                where=where_filter
            )

            return [{
                'id': results['ids'][0][i],
                'content': results['documents'][0][i],
                'metadata': results['metadatas'][0][i],
                'distance': results['distances'][0][i] if 'distances' in results else None,
            } for i in range(len(results['ids'][0]))]
        except Exception as e:
            print(f"⚠️ 向量搜索失败，回退到关键词搜索: {e}")
            return self._keyword_search(query_text, memory_type, top_k)

    def _keyword_search(self, query_text: str, memory_type: Optional[str] = None, 
                        top_k: int = 10) -> List[Dict[str, Any]]:
        """关键词搜索回退"""
        query = self._db.query(MemoryStore)
        if memory_type:
            query = query.filter(MemoryStore.memory_type == memory_type)
        query = query.filter(MemoryStore.value.contains(query_text))
        results = query.limit(top_k).all()

        return [{
            'id': r.memory_id,
            'content': r.value,
            'metadata': {'type': r.memory_type, 'key': r.key, 'importance': r.importance},
            'distance': None,
        } for r in results]

    def get_industry_knowledge(self, industry: str) -> List[MemoryEntry]:
        """获取行业知识"""
        return self.retrieve('industry', key_pattern=industry)

    def get_market_knowledge(self, market: str) -> List[MemoryEntry]:
        """获取市场知识"""
        return self.retrieve('market', key_pattern=market)

    def get_product_knowledge(self, product: str) -> List[MemoryEntry]:
        """获取产品知识"""
        return self.retrieve('product', key_pattern=product)

    def get_execution_experience(self, task_type: str) -> List[MemoryEntry]:
        """获取执行经验"""
        return self.retrieve('execution', key_pattern=task_type)

    def cleanup_expired(self):
        """清理过期记忆"""
        now = datetime.now()
        expired = self._db.query(MemoryStore).filter(
            MemoryStore.expires_at < now
        ).all()
        for e in expired:
            self._db.delete(e)
        self._db.commit()
        return len(expired)
