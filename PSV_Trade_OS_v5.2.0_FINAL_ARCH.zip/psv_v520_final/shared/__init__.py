"""Shared services package.

Keep imports lazy to avoid database/shared circular dependencies.
"""

__all__ = []
