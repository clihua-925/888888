# -*- coding: utf-8 -*-
"""PSV Trade Intelligence OS - 统一配置中心"""
import os
from pathlib import Path
from typing import Dict, List, Any

# 项目根目录
BASE_DIR = Path(__file__).resolve().parent.parent.parent

# 数据库
DATABASE_PATH = os.getenv('PSV_DB_PATH', str(BASE_DIR / 'data' / 'psv_trade.db'))
DATABASE_URL = f"sqlite:///{DATABASE_PATH}"

# 向量数据库
VECTOR_DB_PATH = os.getenv('PSV_VECTOR_DB_PATH', str(BASE_DIR / 'data' / 'vector_db'))

# AI 配置
AI_CONFIG = {
    'primary': {
        'provider': os.getenv('PSV_AI_PROVIDER', 'deepseek'),
        'model': os.getenv('PSV_AI_MODEL', 'deepseek-chat'),
        'api_key': os.getenv('PSV_AI_API_KEY', ''),
        'base_url': os.getenv('PSV_AI_BASE_URL', 'https://api.deepseek.com/v1'),
        'temperature': 0.3,
        'max_tokens': 4096,
    },
    'fallback': {
        'provider': os.getenv('PSV_AI_FALLBACK', 'openai'),
        'model': os.getenv('PSV_AI_FALLBACK_MODEL', 'gpt-4o-mini'),
        'api_key': os.getenv('PSV_OPENAI_API_KEY', ''),
        'base_url': os.getenv('PSV_OPENAI_BASE_URL', 'https://api.openai.com/v1'),
    }
}

# 网页AI兜底（CDP浏览器）
WEBAI_CONFIG = {
    'enabled': os.getenv('PSV_WEBAI_ENABLED', 'true').lower() == 'true',
    'daily_max': int(os.getenv('PSV_WEBAI_DAILY_MAX', '50')),
    'min_interval': int(os.getenv('PSV_WEBAI_MIN_INTERVAL', '30')),
    'engines': ['deepseek', 'chatgpt'],
}

# 采集配置
COLLECTION_CONFIG = {
    'max_workers': int(os.getenv('PSV_MAX_WORKERS', '4')),
    'enrichment_workers': int(os.getenv('PSV_ENRICHMENT_WORKERS', '1')),
    'page_budget': int(os.getenv('PSV_PAGE_BUDGET', '25')),
    'request_timeout': int(os.getenv('PSV_REQUEST_TIMEOUT', '30')),
    'retry_times': int(os.getenv('PSV_RETRY_TIMES', '3')),
    'user_agents': [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    ],
}

# 行业配置映射
INDUSTRY_MAP = {
    'birthday candles': 'candle',
    'candle': 'candle',
    'enamel pot': 'enamel_pot',
    'felt': 'felt',
    'felt pad': 'felt',
}

# 市场配置
MARKETS = {
    'USA': {'name': '美国', 'currency': 'USD', 'language': 'en', 'customs_source': 'importyeti'},
    'EU': {'name': '欧盟', 'currency': 'EUR', 'language': 'en', 'customs_source': 'importgenius'},
    'UK': {'name': '英国', 'currency': 'GBP', 'language': 'en', 'customs_source': 'panjiva'},
    'CA': {'name': '加拿大', 'currency': 'CAD', 'language': 'en', 'customs_source': 'importyeti'},
    'AU': {'name': '澳大利亚', 'currency': 'AUD', 'language': 'en', 'customs_source': 'panjiva'},
    'JP': {'name': '日本', 'currency': 'JPY', 'language': 'ja', 'customs_source': 'japan_customs'},
}

# 节点状态机
NODE_STATUS = {
    'PENDING': '等待执行',
    'RUNNING': '执行中',
    'SUCCESS': '成功完成',
    'FAILED': '执行失败',
    'BLOCKED': '被阻塞',
    'SKIPPED': '已跳过',
    'CANCELLED': '已取消',
    'RECOVERING': '恢复中',
}

# 客户等级
CUSTOMER_TIERS = {
    'S': {'label': '战略客户', 'score_min': 90, 'color': '#FF4444'},
    'A': {'label': '高价值客户', 'score_min': 75, 'color': '#FF8800'},
    'B': {'label': '潜力客户', 'score_min': 60, 'color': '#FFAA00'},
    'C': {'label': '普通客户', 'score_min': 45, 'color': '#44AA44'},
    'D': {'label': '观察客户', 'score_min': 0, 'color': '#888888'},
}

# 开发阶段
DEVELOPMENT_STAGES = [
    'new', 'researching', 'contacted', 'quoted', 'negotiating', 
    'sample_sent', 'trial_order', 'regular_order', 'lost'
]

# 审计配置
AUDIT_CONFIG = {
    'enabled': True,
    'retention_days': 365,
    'batch_size': 100,
}

# 恢复配置
RECOVERY_CONFIG = {
    'checkpoint_interval': 30,  # 秒
    'max_retries': 3,
    'retry_delay': 5,
}

# 贸易角色
TRADE_ROLES = ('importer', 'exporter', 'supplier', 'manufacturer', 
               'shipper', 'consignee', 'notify_party', 'buyer', 'distributor')

# 证据等级
EVIDENCE_LEVELS = {
    'customs_record': 5,      # 海关记录（最强）
    'importyeti': 4,          # ImportYeti数据
    'official_registry': 3,   # 官方注册
    'company_website': 2,     # 公司官网
    'search_result': 1,       # 搜索结果
    'inferred': 0,            # 推断
}
