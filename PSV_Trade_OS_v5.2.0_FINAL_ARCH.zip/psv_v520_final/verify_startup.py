# -*- coding: utf-8 -*-
from pathlib import Path
import sys
checks=["app","agents","orchestrator","contracts","shared","database","webui"]
print("PSV Trade OS startup verification")
base=Path(__file__).parent
failed=[]
for c in checks:
    if not (base/c).exists():
        failed.append(c)
    else:
        print("OK", c)
if failed:
    print("FAILED:", failed); sys.exit(1)
print("Startup structure OK")
