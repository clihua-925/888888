# -*- coding: utf-8 -*-
"""编排器测试"""
import unittest
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from contracts.task_contract import TaskContract
from orchestrator.graph import TradeOrchestrator
from database.models import init_database

class TestOrchestrator(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_database()

    def test_task_contract_validation(self):
        task = TaskContract(
            objective="测试任务",
            product="test product",
            market="USA"
        )
        self.assertEqual(task.market, "USA")
        self.assertIsNotNone(task.task_id)

    def test_planner_agent(self):
        from agents.trade_planner import TradePlannerAgent
        from contracts.agent_contract import AgentRequest
        agent = TradePlannerAgent()
        request = AgentRequest(
            task_id="test_001",
            agent_type="trade_planner",
            input_data={
                "objective": "开发美国生日蜡烛进口商",
                "product": "birthday candles",
                "market": "USA",
            }
        )
        response = agent.execute(request)
        self.assertEqual(response.status, "success")
        self.assertIn("plan", response.result)

    def test_orchestrator_build(self):
        orchestrator = TradeOrchestrator()
        self.assertIsNotNone(orchestrator.graph)

if __name__ == "__main__":
    unittest.main()
