# -*- coding: utf-8 -*-
from app.main import main
import sys
if __name__ == "__main__":
    sys.argv.append("--webui")
    main()
