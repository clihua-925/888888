# Production Checklist

- LangGraph orchestration
- Agent contracts
- Workflow persistence
- Audit trace
- Recovery checkpoint
- Trade business modules
