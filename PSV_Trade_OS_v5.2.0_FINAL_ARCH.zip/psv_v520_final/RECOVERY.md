生产恢复要求：checkpoint保存workflow state，失败任务支持resume。
