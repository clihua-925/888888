# -*- coding: utf-8 -*-
"""Report Agent

负责：输出最终外贸开发报告
"""
import os
from datetime import datetime
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse

class ReportAgent(BaseAgent):
    def __init__(self):
        super().__init__("report", "Report Generator")

    def _run(self, request: AgentRequest) -> AgentResponse:
        all_results = request.input_data.get("all_previous_results", {})
        objective = request.input_data.get("objective", "")
        task_id = request.task_id

        market_analysis = all_results.get("market_research", {})
        companies = all_results.get("company_discovery", {})
        enriched = all_results.get("company_enrichment", {})
        contacts = all_results.get("contact_discovery", {})
        scored = all_results.get("lead_scoring", {})
        strategies = all_results.get("sales_strategy", {})

        report = self._generate_report(
            task_id, objective, market_analysis, companies,
            enriched, contacts, scored, strategies
        )

        # 保存报告
        report_path = f"reports/report_{task_id}.md"
        os.makedirs("reports", exist_ok=True)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report)

        result = {
            "report": report,
            "report_path": report_path,
            "summary": self._generate_summary(scored),
            "key_metrics": {
                "companies_found": companies.get("companies_found", 0),
                "enriched_count": enriched.get("total", 0),
                "contacts_found": contacts.get("total_contacts", 0),
                "s_a_leads": scored.get("tier_distribution", {}).get("S", 0) + scored.get("tier_distribution", {}).get("A", 0),
            },
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=0.9,
            status="success",
        )

    def _generate_report(self, task_id, objective, market, companies, enriched, contacts, scored, strategies):
        sections = []
        sections.append(f"# PSV 外贸智能开发报告\n")
        sections.append(f"**任务ID**: {task_id}\n")
        sections.append(f"**任务目标**: {objective}\n")
        sections.append(f"**生成时间**: {datetime.now().strftime("%Y-%m-%d %H:%M")}\n\n")

        sections.append("## 一、市场分析\n")
        ma = market.get("result", {}).get("market_analysis", {}) if isinstance(market, dict) else {}
        sections.append(f"- **目标市场**: {ma.get("country_code", "N/A")}\n")
        sections.append(f"- **竞争程度**: {ma.get("competition_level", "N/A")}\n")
        sections.append(f"- **市场机会**: {", ".join(ma.get("key_opportunities", []))}\n\n")

        sections.append("## 二、企业发现\n")
        sections.append(f"- **发现企业总数**: {companies.get("companies_found", 0)}\n")
        sections.append(f"- **海关数据企业**: {companies.get("by_evidence_level", {}).get("customs", 0)}\n")
        sections.append(f"- **搜索引擎补充**: {companies.get("by_evidence_level", {}).get("search", 0)}\n\n")

        sections.append("## 三、企业画像补全\n")
        sections.append(f"- **补全企业数**: {enriched.get("total", 0)}\n")
        sections.append(f"- **有官网**: {enriched.get("with_website", 0)}\n")
        sections.append(f"- **有联系人**: {enriched.get("with_contacts", 0)}\n\n")

        sections.append("## 四、联系人发现\n")
        sections.append(f"- **发现联系人**: {contacts.get("total_contacts", 0)}\n")
        sections.append(f"- **决策人**: {contacts.get("decision_makers", 0)}\n\n")

        sections.append("## 五、客户评分\n")
        tier_dist = scored.get("tier_distribution", {})
        for tier, count in tier_dist.items():
            sections.append(f"- **{tier}级客户**: {count} 家\n")
        sections.append("\n")

        sections.append("## 六、开发策略\n")
        for s in strategies.get("strategies", [])[:5]:
            sections.append(f"### {s.get("entity_id", "")}\n")
            sections.append(f"- **策略**: {s.get("approach", "")}\n")
            sections.append(f"- **切入点**: {", ".join(s.get("talking_points", [])[:2])}\n\n")

        return "\n".join(sections)

    def _generate_summary(self, scored):
        total = scored.get("total_scored", 0)
        s_count = scored.get("tier_distribution", {}).get("S", 0)
        a_count = scored.get("tier_distribution", {}).get("A", 0)
        return f"本次共评估{total}家企业，发现战略级(S)客户{s_count}家，高价值(A)客户{a_count}家，建议优先跟进S/A级客户。"
