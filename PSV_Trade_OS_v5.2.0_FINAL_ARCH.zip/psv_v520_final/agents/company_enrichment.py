# -*- coding: utf-8 -*-
"""Company Enrichment Agent

负责：企业信息补全
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from business.profiling.profiler import CompanyProfiler
from contracts.data_contract import CompanyProfile

class CompanyEnrichmentAgent(BaseAgent):
    """企业补全Agent"""

    def __init__(self):
        super().__init__('company_enrichment', 'Company Enrichment')
        self.profiler = CompanyProfiler()

    def _run(self, request: AgentRequest) -> AgentResponse:
        companies_data = request.input_data.get('companies', [])
        force = request.input_data.get('force', False)

        enriched = []
        for company_data in companies_data:
            company = CompanyProfile(**company_data)
            enriched_company = self.profiler.enrich_profile(company, force=force)
            enriched.append(enriched_company.dict())

        # 统计补全情况
        with_website = sum(1 for c in enriched if c.get('website'))
        with_contacts = sum(1 for c in enriched if c.get('contacts'))
        with_industry = sum(1 for c in enriched if c.get('industry'))

        result = {
            'total': len(enriched),
            'enriched': enriched,
            'with_website': with_website,
            'with_contacts': with_contacts,
            'with_industry': with_industry,
            'completion_rate': (with_website + with_contacts + with_industry) / (len(enriched) * 3) if enriched else 0,
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=0.8,
            next_action='contact_discovery',
            status='success',
        )
