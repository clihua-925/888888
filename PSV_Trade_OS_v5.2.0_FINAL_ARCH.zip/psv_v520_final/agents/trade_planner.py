# -*- coding: utf-8 -*-
"""Trade Planner Agent

职责：
- 理解外贸目标
- 生成任务目标、执行计划、Agent调用顺序
"""
import json
from typing import Dict, List, Any

from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from shared.knowledge.knowledge_base import KnowledgeBase

class TradePlannerAgent(BaseAgent):
    """贸易规划Agent"""

    def __init__(self):
        super().__init__('trade_planner', 'Trade Planner')
        self.kb = KnowledgeBase()

    def _run(self, request: AgentRequest) -> AgentResponse:
        objective = request.input_data.get('objective', '')
        product = request.input_data.get('product', '')
        market = request.input_data.get('market', '')
        target_customer = request.input_data.get('target_customer', 'importer')
        constraints = request.input_data.get('constraints', {})

        # 获取产品画像
        product_profile = self.kb.get_product_profile(product)
        market_profile = self.kb.get_market_profile(market)

        # 生成执行计划
        plan = self._generate_plan(objective, product, market, target_customer, constraints)

        result = {
            'objective': objective,
            'product': product,
            'market': market,
            'target_customer': target_customer,
            'product_profile': product_profile,
            'market_profile': market_profile,
            'plan': plan,
            'estimated_duration': self._estimate_duration(plan),
            'success_criteria': self._define_success_criteria(plan),
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=0.85,
            evidence=[{'source': 'knowledge_base', 'product_profile': bool(product_profile)}],
            next_action='market_research',
            status='success',
        )

    def _generate_plan(self, objective: str, product: str, market: str,
                       target_customer: str, constraints: Dict[str, Any]) -> List[Dict[str, Any]]:
        """生成执行计划"""
        max_results = constraints.get('max_results', 50)

        plan = [
            {
                'step': 1,
                'node': 'market_research',
                'agent': 'market_research',
                'description': f'分析{market}市场{product}行业趋势',
                'input': {'market': market, 'product': product},
                'output_expected': 'market_analysis',
            },
            {
                'step': 2,
                'node': 'company_discovery',
                'agent': 'company_discovery',
                'description': f'发现{market}市场的{target_customer}',
                'input': {'product': product, 'market': market, 'customer_type': target_customer, 'max_results': max_results},
                'output_expected': 'company_list',
            },
            {
                'step': 3,
                'node': 'company_enrichment',
                'agent': 'company_enrichment',
                'description': '补全企业画像信息',
                'input': {'companies': 'from_step_2'},
                'output_expected': 'enriched_profiles',
            },
            {
                'step': 4,
                'node': 'contact_discovery',
                'agent': 'contact_discovery',
                'description': '寻找关键联系人',
                'input': {'companies': 'from_step_3'},
                'output_expected': 'contact_list',
            },
            {
                'step': 5,
                'node': 'lead_scoring',
                'agent': 'lead_scoring',
                'description': '客户评分和分级',
                'input': {'companies': 'from_step_4'},
                'output_expected': 'scored_leads',
            },
            {
                'step': 6,
                'node': 'sales_strategy',
                'agent': 'sales_strategy',
                'description': '生成开发策略',
                'input': {'leads': 'from_step_5'},
                'output_expected': 'strategies',
            },
            {
                'step': 7,
                'node': 'report',
                'agent': 'report',
                'description': '生成外贸开发报告',
                'input': {'all_previous_results': 'aggregated'},
                'output_expected': 'final_report',
            },
        ]

        return plan

    def _estimate_duration(self, plan: List[Dict[str, Any]]) -> int:
        """估算执行时间（秒）"""
        base_time = 30  # 基础时间
        for step in plan:
            if step['agent'] == 'company_discovery':
                base_time += 120
            elif step['agent'] == 'company_enrichment':
                base_time += 180
            elif step['agent'] == 'contact_discovery':
                base_time += 90
            else:
                base_time += 30
        return base_time

    def _define_success_criteria(self, plan: List[Dict[str, Any]]) -> List[str]:
        """定义成功标准"""
        return [
            '发现至少20家目标企业',
            '企业画像完整度>60%',
            '至少50%企业有联系人信息',
            '生成S/A级客户至少5家',
            '输出完整开发报告',
        ]
