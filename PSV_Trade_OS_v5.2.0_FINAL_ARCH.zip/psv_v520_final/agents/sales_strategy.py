# -*- coding: utf-8 -*-
"""Sales Strategy Agent

负责：生成开发策略、邮件方向、跟进建议
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from contracts.data_contract import SalesStrategy
from business.analysis.analyzer import TradeAnalyzer

class SalesStrategyAgent(BaseAgent):
    def __init__(self):
        super().__init__("sales_strategy", "Sales Strategy")
        self.analyzer = TradeAnalyzer()

    def _run(self, request: AgentRequest) -> AgentResponse:
        leads = request.input_data.get("leads", [])
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")

        strategies = []
        for lead in leads:
            if lead.get("tier") in ["S", "A", "B"]:
                strategy = self._generate_strategy(lead, product, market)
                strategies.append(strategy.dict())

        result = {
            "total_strategies": len(strategies),
            "strategies": strategies,
            "priority_order": sorted(strategies, key=lambda x: x.get("overall_score", 0), reverse=True),
            "email_templates": self._generate_email_templates(product, market),
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=0.78,
            next_action="report",
            status="success",
        )

    def _generate_strategy(self, lead: dict, product: str, market: str) -> SalesStrategy:
        entity_id = lead.get("entity_id", "")
        company_name = lead.get("name", "Valued Partner")

        approach = f"针对{company_name}的{product}开发策略"
        talking_points = [
            f"我们是专业的{product}制造商",
            f"我们的产品已通过{market}市场相关认证",
            f"我们可以提供有竞争力的价格和高品质保证",
        ]

        if lead.get("tier") == "S":
            approach += "（战略级客户，建议高层直接对接）"
            talking_points.append("建议安排视频会议，展示工厂实力")
        elif lead.get("tier") == "A":
            approach += "（高价值客户，建议快速跟进）"
            talking_points.append("建议在一周内发送样品目录")

        objections = [
            "价格太高 → 强调性价比和长期合作优惠",
            "已有供应商 → 强调差异化产品和更优服务",
            "质量担忧 → 提供认证文件和样品测试",
        ]

        return SalesStrategy(
            entity_id=entity_id,
            strategy_type="initial",
            approach=approach,
            email_subject=f"Professional {product.title()} Supplier - Cooperation Proposal",
            email_body=f"Dear {company_name} Team,\n\nWe are a leading manufacturer of {product}...",
            follow_up_plan=[
                {"day": 1, "action": "发送开发信"},
                {"day": 3, "action": "LinkedIn添加关键人"},
                {"day": 7, "action": "电话跟进"},
                {"day": 14, "action": "发送产品目录"},
            ],
            talking_points=talking_points,
            objections_handling=objections,
        )

    def _generate_email_templates(self, product: str, market: str) -> dict:
        return {
            "initial": f"Subject: {product.title()} Supply Opportunity\n\nDear Sir/Madam...",
            "follow_up": f"Subject: Follow-up: {product.title()}\n\nDear...",
            "sample": f"Subject: Free Sample - {product.title()}\n\nDear...",
        }
