from typing import Dict, Any

class AgentRegistry:
    def __init__(self):
        self._agents: Dict[str, Any] = {}
    def register(self, name, agent):
        self._agents[name]=agent
    def get(self,name):
        return self._agents[name]
    def list(self):
        return list(self._agents.keys())
