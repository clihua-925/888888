# -*- coding: utf-8 -*-
"""Contact Discovery Agent

负责：
- 寻找联系人、职位、邮箱、销售入口
"""
import re
import requests
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from contracts.data_contract import ContactInfo

class ContactDiscoveryAgent(BaseAgent):
    """联系人发现Agent"""

    def __init__(self):
        super().__init__('contact_discovery', 'Contact Discovery')
        self.session = requests.Session()

    def _run(self, request: AgentRequest) -> AgentResponse:
        companies = request.input_data.get('companies', [])

        all_contacts = []
        for company in companies:
            contacts = self._find_contacts(company)
            company['contacts'] = [c.dict() for c in contacts]
            all_contacts.extend(contacts)

        result = {
            'companies': companies,
            'total_contacts': len(all_contacts),
            'decision_makers': sum(1 for c in all_contacts if c.is_decision_maker),
            'with_email': sum(1 for c in all_contacts if c.email),
            'with_phone': sum(1 for c in all_contacts if c.phone),
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=0.7,
            next_action='lead_scoring',
            status='success',
        )

    def _find_contacts(self, company: dict) -> list:
        """为单个企业发现联系人"""
        contacts = []
        website = company.get('website', '')

        if website:
            try:
                url = website if website.startswith('http') else f'https://{website}'
                resp = self.session.get(url, timeout=10, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })

                # 提取邮箱
                emails = re.findall(r'[\w.+-]+@[\w-]+\.[\w.]+', resp.text)
                for email in set(emails)[:3]:
                    # 判断是否是决策人邮箱
                    is_dm = any(kw in email.lower() for kw in ['ceo', 'director', 'manager', 'purchase', 'buyer'])
                    contacts.append(ContactInfo(
                        email=email,
                        source='website',
                        is_decision_maker=is_dm,
                        confidence=0.8 if is_dm else 0.6,
                    ))

                # 尝试联系页面
                resp2 = self.session.get(f"{url}/contact", timeout=10)
                emails2 = re.findall(r'[\w.+-]+@[\w-]+\.[\w.]+', resp2.text)
                for email in set(emails2):
                    if not any(c.email == email for c in contacts):
                        contacts.append(ContactInfo(
                            email=email,
                            source='contact_page',
                            confidence=0.7,
                        ))
            except:
                pass

        return contacts
