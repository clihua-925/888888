# -*- coding: utf-8 -*-
"""Company Discovery Agent

负责：
- 寻找进口商、买家、经销商、渠道商
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from business.collection.collector import TradeCollector

class CompanyDiscoveryAgent(BaseAgent):
    """企业发现Agent"""

    def __init__(self):
        super().__init__('company_discovery', 'Company Discovery')
        self.collector = TradeCollector()

    def _run(self, request: AgentRequest) -> AgentResponse:
        product = request.input_data.get('product', '')
        market = request.input_data.get('market', '')
        customer_type = request.input_data.get('customer_type', 'importer')
        max_results = request.input_data.get('max_results', 50)
        min_shipments = request.input_data.get('min_shipments', 3)

        # 执行企业发现
        companies = self.collector.discover_companies(
            product=product,
            market=market,
            customer_type=customer_type,
            max_results=max_results,
            min_shipments=min_shipments,
        )

        # 转换为字典列表
        company_dicts = [c.dict() for c in companies]

        result = {
            'product': product,
            'market': market,
            'customer_type': customer_type,
            'companies_found': len(companies),
            'companies': company_dicts,
            'by_evidence_level': self._group_by_evidence(companies),
            'top_candidates': company_dicts[:10],
        }

        confidence = min(0.95, 0.5 + len(companies) * 0.01)

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=confidence,
            evidence=[{'source': 'customs', 'count': len([c for c in companies if c.source == 'customs'])}],
            next_action='company_enrichment',
            status='success' if len(companies) > 0 else 'partial',
        )

    def _group_by_evidence(self, companies):
        """按证据等级分组"""
        groups = {'customs': 0, 'search': 0, 'other': 0}
        for c in companies:
            if c.source == 'customs':
                groups['customs'] += 1
            elif c.source == 'search':
                groups['search'] += 1
            else:
                groups['other'] += 1
        return groups
