# -*- coding: utf-8 -*-
"""Agent基类 - 所有Agent的抽象基类"""
import time
import json
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from datetime import datetime

from contracts.agent_contract import AgentRequest, AgentResponse
from psv_platform.audit.audit_logger import AuditLogger

class BaseAgent(ABC):
    """智能体基类"""

    def __init__(self, agent_type: str, agent_name: str):
        self.agent_type = agent_type
        self.agent_name = agent_name
        self.audit = AuditLogger()

    def execute(self, request: AgentRequest) -> AgentResponse:
        """执行Agent（统一入口）"""
        start_time = time.time()
        task_id = request.task_id

        # 记录调用
        self.audit.log_agent_call(
            task_id=task_id,
            agent_type=self.agent_type,
            agent_name=self.agent_name,
            input_data=request.input_data,
            context=request.context,
        )

        try:
            # 执行具体逻辑
            result = self._run(request)
            duration = time.time() - start_time

            # 记录结果
            self.audit.log_agent_result(
                task_id=task_id,
                agent_type=self.agent_type,
                output_data=result.result,
                confidence=result.confidence,
                duration_sec=duration,
                status=result.status,
            )

            result.duration_sec = duration
            return result

        except Exception as e:
            duration = time.time() - start_time
            error_msg = str(e)

            self.audit.log_error(
                task_id=task_id,
                agent_type=self.agent_type,
                error=error_msg,
            )

            return AgentResponse(
                request_id=request.request_id,
                task_id=task_id,
                agent_type=self.agent_type,
                result={},
                confidence=0.0,
                status='failed',
                error=error_msg,
                duration_sec=duration,
            )

    @abstractmethod
    def _run(self, request: AgentRequest) -> AgentResponse:
        """子类必须实现的执行逻辑"""
        pass

    def _call_tool(self, task_id: str, tool_name: str, 
                   parameters: Dict[str, Any], timeout: int = 60) -> Any:
        """调用工具（带审计）"""
        from contracts.tool_contract import ToolRegistry

        start = time.time()
        handler = ToolRegistry.get(tool_name)

        if not handler:
            raise ValueError(f"未注册的工具: {tool_name}")

        try:
            result = handler(**parameters)
            duration = time.time() - start

            self.audit.log_tool_call(
                task_id=task_id,
                agent_type=self.agent_type,
                tool_name=tool_name,
                parameters=parameters,
                result=result,
                duration_sec=duration,
                success=True,
            )

            return result
        except Exception as e:
            duration = time.time() - start
            self.audit.log_tool_call(
                task_id=task_id,
                agent_type=self.agent_type,
                tool_name=tool_name,
                parameters=parameters,
                result=None,
                duration_sec=duration,
                success=False,
            )
            raise
