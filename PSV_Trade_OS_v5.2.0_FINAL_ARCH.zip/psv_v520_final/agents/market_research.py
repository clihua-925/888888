# -*- coding: utf-8 -*-
"""Market Research Agent

负责：
- 国家市场分析
- 产品趋势
- 行业分析
- 市场机会
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from business.analysis.analyzer import TradeAnalyzer

class MarketResearchAgent(BaseAgent):
    """市场研究Agent"""

    def __init__(self):
        super().__init__('market_research', 'Market Research')
        self.analyzer = TradeAnalyzer()

    def _run(self, request: AgentRequest) -> AgentResponse:
        market = request.input_data.get('market', '')
        product = request.input_data.get('product', '')

        # 执行市场分析
        analysis = self.analyzer.analyze_market(market, product)
        competition = self.analyzer.analyze_competition(product, market)
        trends = self.analyzer.analyze_purchase_trends(product, market)

        result = {
            'market': market,
            'product': product,
            'market_analysis': analysis.dict(),
            'competition_analysis': competition,
            'purchase_trends': trends,
            'market_size_estimate': analysis.market_size,
            'competition_level': analysis.competition_level,
            'key_opportunities': analysis.opportunities,
            'key_risks': analysis.risks,
            'recommended_approach': self._recommend_approach(analysis, competition),
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=0.75,
            evidence=[{'source': 'database', 'records': trends.get('total_records', 0)}],
            next_action='company_discovery',
            status='success',
        )

    def _recommend_approach(self, analysis, competition) -> str:
        """推荐开发策略"""
        if analysis.competition_level == 'low':
            return '该市场竞争度低，建议快速进入，优先联系头部企业'
        elif analysis.competition_level == 'medium':
            return '该市场竞争适中，建议差异化定位，关注细分市场'
        else:
            return '该市场竞争激烈，建议寻找利基市场或通过经销商切入'
