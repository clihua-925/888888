# -*- coding: utf-8 -*-
"""Lead Scoring Agent

负责：客户评分
评分：企业实力、采购可能、匹配程度、成交概率
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from contracts.data_contract import LeadScore
from business.customer_pool.pool_manager import CustomerPoolManager

class LeadScoringAgent(BaseAgent):
    def __init__(self):
        super().__init__("lead_scoring", "Lead Scoring")
        self.pool = CustomerPoolManager()

    def _run(self, request: AgentRequest) -> AgentResponse:
        companies = request.input_data.get("companies", [])
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")

        scored_leads = []
        for company in companies:
            score = self._calculate_score(company, product, market)
            scored_leads.append(score.dict())
            # 加入客户池
            from contracts.data_contract import CompanyProfile
            cp = CompanyProfile(**company)
            self.pool.add_to_pool(company=cp, lead_score=score)

        tier_dist = {"S": 0, "A": 0, "B": 0, "C": 0, "D": 0}
        for s in scored_leads:
            tier_dist[s["tier"]] = tier_dist.get(s["tier"], 0) + 1

        result = {
            "total_scored": len(scored_leads),
            "scored_leads": scored_leads,
            "tier_distribution": tier_dist,
            "high_value_leads": [s for s in scored_leads if s["tier"] in ["S", "A"]],
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result=result,
            confidence=0.82,
            next_action="sales_strategy",
            status="success",
        )

    def _calculate_score(self, company: dict, product: str, market: str) -> LeadScore:
        entity_id = company.get("entity_id", company.get("name_norm", ""))

        # 企业实力 (0-100)
        company_strength = company.get("credibility_score", 0)
        if company.get("website"):
            company_strength += 10
        if company.get("contacts"):
            company_strength += min(15, len(company["contacts"]) * 5)
        company_strength = min(100, company_strength)

        # 采购可能性 (0-100)
        purchase_likelihood = company.get("purchase_probability", 0)
        if company.get("source") == "customs":
            purchase_likelihood += 20
        purchase_likelihood = min(100, purchase_likelihood)

        # 匹配程度 (0-100)
        match_degree = 50
        main_products = company.get("main_products", [])
        if any(product.lower() in str(p).lower() for p in main_products):
            match_degree += 30
        if company.get("supply_chain_role") in ["importer", "buyer", "distributor"]:
            match_degree += 20
        match_degree = min(100, match_degree)

        # 成交概率 (0-100)
        deal_probability = (company_strength * 0.3 + purchase_likelihood * 0.4 + match_degree * 0.3)
        deal_probability = min(100, deal_probability)

        # 综合评分
        overall = (company_strength + purchase_likelihood + match_degree + deal_probability) / 4

        # 分级
        if overall >= 90:
            tier = "S"
        elif overall >= 75:
            tier = "A"
        elif overall >= 60:
            tier = "B"
        elif overall >= 45:
            tier = "C"
        else:
            tier = "D"

        return LeadScore(
            entity_id=entity_id,
            company_strength=company_strength,
            purchase_likelihood=purchase_likelihood,
            match_degree=match_degree,
            deal_probability=deal_probability,
            overall_score=overall,
            tier=tier,
            reasoning=f"企业实力{company_strength:.0f}, 采购可能{purchase_likelihood:.0f}, 匹配{match_degree:.0f}, 成交{deal_probability:.0f}",
            factors={
                "company_strength": company_strength,
                "purchase_likelihood": purchase_likelihood,
                "match_degree": match_degree,
                "deal_probability": deal_probability,
            },
        )
