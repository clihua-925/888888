# -*- coding: utf-8 -*-
"""恢复服务 - 任务中断恢复机制

核心能力：
- 执行到任意节点时电脑关闭
- 重新启动后读取checkpoint
- 恢复workflow state
- 继续执行（不重新开始整个任务）
"""
import json
import time
from typing import Dict, List, Any, Optional

from database.models import TradeTask, TradeWorkflow, SessionLocal
from shared.state.workflow_state import StateManager
from shared.config import RECOVERY_CONFIG

class RecoveryService:
    """任务恢复服务"""

    def __init__(self):
        self._db = SessionLocal()
        self._state_manager = StateManager()

    def save_checkpoint(self, task_id: str, node_name: str, 
                        node_state: Dict[str, Any], agent_outputs: List[Dict[str, Any]]):
        """保存检查点"""
        checkpoint_id = f"chk_{task_id}_{node_name}_{int(time.time())}"

        checkpoint_data = {
            'checkpoint_id': checkpoint_id,
            'task_id': task_id,
            'node_name': node_name,
            'node_state': node_state,
            'agent_outputs': agent_outputs,
            'timestamp': time.time(),
            'version': '5.0.0',
        }

        # 更新任务状态
        task = self._db.query(TradeTask).filter(TradeTask.task_id == task_id).first()
        if task:
            task.status = 'paused'
            task.current_node = node_name
            task.resume_state = json.dumps(checkpoint_data, ensure_ascii=False)
            task.updated_at = datetime.now()

        # 保存工作流检查点
        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id
        ).first()

        if workflow:
            workflow.checkpoint_data = json.dumps(checkpoint_data, ensure_ascii=False)
            workflow.is_resumable = True
            workflow.updated_at = datetime.now()
        else:
            workflow = TradeWorkflow(
                task_id=task_id,
                workflow_type='trade_development',
                checkpoint_data=json.dumps(checkpoint_data, ensure_ascii=False),
                is_resumable=True,
            )
            self._db.add(workflow)

        self._db.commit()
        return checkpoint_id

    def can_resume(self, task_id: str) -> bool:
        """检查任务是否可以恢复"""
        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id,
            TradeWorkflow.is_resumable == True
        ).first()

        if not workflow or not workflow.checkpoint_data:
            return False

        try:
            checkpoint = json.loads(workflow.checkpoint_data)
            # 检查检查点是否过期（默认7天）
            checkpoint_time = checkpoint.get('timestamp', 0)
            if time.time() - checkpoint_time > 7 * 24 * 3600:
                return False
            return True
        except:
            return False

    def resume_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """恢复任务

        返回：
            {
                'can_resume': bool,
                'checkpoint': dict,
                'next_node': str,
                'agent_outputs': list,
                'remaining_plan': list,
            }
        """
        if not self.can_resume(task_id):
            return None

        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id
        ).first()

        if not workflow or not workflow.checkpoint_data:
            return None

        try:
            checkpoint = json.loads(workflow.checkpoint_data)

            # 恢复任务状态
            task = self._db.query(TradeTask).filter(TradeTask.task_id == task_id).first()
            if task:
                task.status = 'running'
                task.updated_at = datetime.now()
                self._db.commit()

            # 恢复工作流状态
            if workflow.graph_state:
                state_data = json.loads(workflow.graph_state)
                self._state_manager._active_states[task_id] = self._state_manager.WorkflowState.from_dict(state_data)

            # 计算剩余计划
            current_node = checkpoint.get('node_name', '')
            plan = task.workflow if task and task.workflow else []
            remaining = []
            found = False
            for step in plan:
                if found:
                    remaining.append(step)
                if step.get('node') == current_node:
                    found = True

            return {
                'can_resume': True,
                'checkpoint': checkpoint,
                'next_node': current_node,
                'agent_outputs': checkpoint.get('agent_outputs', []),
                'remaining_plan': remaining,
                'resumed_at': time.time(),
            }

        except Exception as e:
            print(f"⚠️ 任务恢复失败: {e}")
            return None

    def list_recoverable_tasks(self) -> List[Dict[str, Any]]:
        """列出所有可恢复的任务"""
        workflows = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.is_resumable == True
        ).all()

        result = []
        for w in workflows:
            task = self._db.query(TradeTask).filter(TradeTask.task_id == w.task_id).first()
            if task and self.can_resume(w.task_id):
                result.append({
                    'task_id': w.task_id,
                    'objective': task.objective,
                    'current_node': task.current_node,
                    'status': task.status,
                    'progress_pct': task.progress_pct,
                    'updated_at': task.updated_at.isoformat() if task.updated_at else None,
                })

        return result

    def mark_completed(self, task_id: str):
        """标记任务完成，清除恢复标记"""
        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id
        ).first()

        if workflow:
            workflow.is_resumable = False
            workflow.checkpoint_data = None
            self._db.commit()

    def get_recovery_report(self, task_id: str) -> Dict[str, Any]:
        """获取恢复报告"""
        workflow = self._db.query(TradeWorkflow).filter(
            TradeWorkflow.task_id == task_id
        ).first()

        if not workflow or not workflow.checkpoint_data:
            return {'has_checkpoint': False}

        checkpoint = json.loads(workflow.checkpoint_data)
        return {
            'has_checkpoint': True,
            'checkpoint_id': checkpoint.get('checkpoint_id'),
            'last_node': checkpoint.get('node_name'),
            'checkpoint_time': datetime.fromtimestamp(checkpoint.get('timestamp', 0)).isoformat(),
            'agent_outputs_count': len(checkpoint.get('agent_outputs', [])),
            'is_resumable': workflow.is_resumable,
        }

from datetime import datetime
