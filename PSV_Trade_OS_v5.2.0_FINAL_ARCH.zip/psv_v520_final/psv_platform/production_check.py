import os

def health_check():
    required=['agents','orchestrator','contracts','business','database','webui']
    return {x:os.path.exists(x) for x in required}
