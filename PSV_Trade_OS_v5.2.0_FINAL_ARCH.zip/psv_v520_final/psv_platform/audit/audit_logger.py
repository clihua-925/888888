# -*- coding: utf-8 -*-
"""审计日志系统 - 所有智能行为必须可追踪

必须能够回答：
- 哪个Agent执行？
- 为什么执行？
- 调用什么工具？
- 产生什么结果？
- 哪里失败？
"""
import json
import time
from typing import Dict, List, Any, Optional
from datetime import datetime

from database.models import AuditEvent, SessionLocal, AgentExecutionLog
from shared.config import AUDIT_CONFIG

class AuditLogger:
    """统一审计日志记录器"""

    def __init__(self):
        self._db = SessionLocal()
        self._buffer: List[Dict[str, Any]] = []
        self._buffer_size = AUDIT_CONFIG.get('batch_size', 100)

    def log_task_start(self, task_id: str, objective: str, 
                       user_id: Optional[str] = None, ip: Optional[str] = None):
        """记录任务开始"""
        self._log({
            'event_type': 'task_start',
            'task_id': task_id,
            'input_data': json.dumps({'objective': objective, 'user_id': user_id}, ensure_ascii=False),
            'status': 'started',
            'ip_address': ip,
        })

    def log_agent_call(self, task_id: str, agent_type: str, agent_name: str,
                       input_data: Dict[str, Any], context: Dict[str, Any]):
        """记录Agent调用"""
        self._log({
            'event_type': 'agent_call',
            'task_id': task_id,
            'agent_id': f"{agent_type}_{int(time.time())}",
            'input_data': json.dumps({'input': input_data, 'context': context}, ensure_ascii=False),
            'status': 'running',
        })

    def log_agent_result(self, task_id: str, agent_type: str, 
                         output_data: Dict[str, Any], confidence: float,
                         duration_sec: float, status: str = 'success'):
        """记录Agent执行结果"""
        self._log({
            'event_type': 'agent_result',
            'task_id': task_id,
            'agent_id': f"{agent_type}_{int(time.time())}",
            'output_data': json.dumps(output_data, ensure_ascii=False),
            'status': status,
            'duration_sec': duration_sec,
        })

    def log_tool_call(self, task_id: str, agent_type: str, tool_name: str,
                      parameters: Dict[str, Any], result: Any, 
                      duration_sec: float, success: bool = True):
        """记录工具调用"""
        self._log({
            'event_type': 'tool_call',
            'task_id': task_id,
            'agent_id': agent_type,
            'tool_call': json.dumps({
                'tool_name': tool_name,
                'parameters': parameters,
                'result': result,
                'success': success,
            }, ensure_ascii=False),
            'status': 'success' if success else 'failed',
            'duration_sec': duration_sec,
        })

    def log_data_write(self, task_id: str, table_name: str, 
                       record_id: str, operation: str, data: Dict[str, Any]):
        """记录数据写入"""
        self._log({
            'event_type': 'data_write',
            'task_id': task_id,
            'input_data': json.dumps({
                'table': table_name,
                'record_id': record_id,
                'operation': operation,
                'data': data,
            }, ensure_ascii=False),
            'status': 'completed',
        })

    def log_checkpoint(self, task_id: str, checkpoint_id: str, 
                       node_name: str, state_summary: Dict[str, Any]):
        """记录检查点"""
        self._log({
            'event_type': 'checkpoint',
            'task_id': task_id,
            'input_data': json.dumps({
                'checkpoint_id': checkpoint_id,
                'node_name': node_name,
                'state': state_summary,
            }, ensure_ascii=False),
            'status': 'saved',
        })

    def log_error(self, task_id: str, agent_type: Optional[str], 
                  error: str, traceback: Optional[str] = None):
        """记录错误"""
        self._log({
            'event_type': 'error',
            'task_id': task_id,
            'agent_id': agent_type,
            'error_details': json.dumps({
                'error': error,
                'traceback': traceback,
            }, ensure_ascii=False),
            'status': 'failed',
        })

    def log_task_end(self, task_id: str, status: str, 
                     result_summary: Dict[str, Any], duration_sec: float):
        """记录任务结束"""
        self._log({
            'event_type': 'task_end',
            'task_id': task_id,
            'output_data': json.dumps(result_summary, ensure_ascii=False),
            'status': status,
            'duration_sec': duration_sec,
        })
        self._flush()  # 任务结束时强制刷新

    def _log(self, data: Dict[str, Any]):
        """内部记录方法"""
        self._buffer.append(data)
        if len(self._buffer) >= self._buffer_size:
            self._flush()

    def _flush(self):
        """刷新缓冲区到数据库"""
        if not self._buffer:
            return

        try:
            for data in self._buffer:
                event = AuditEvent(**data)
                self._db.add(event)
            self._db.commit()
            self._buffer.clear()
        except Exception as e:
            self._db.rollback()
            print(f"⚠️ 审计日志写入失败: {e}")

    def get_task_audit(self, task_id: str) -> List[Dict[str, Any]]:
        """获取任务的完整审计链"""
        self._flush()  # 先刷新缓冲区
        events = self._db.query(AuditEvent).filter(
            AuditEvent.task_id == task_id
        ).order_by(AuditEvent.timestamp.asc()).all()

        return [{
            'event_id': e.event_id,
            'event_type': e.event_type,
            'agent_id': e.agent_id,
            'status': e.status,
            'duration_sec': e.duration_sec,
            'timestamp': e.timestamp.isoformat(),
            'input': e.input_data,
            'output': e.output_data,
            'tool_call': e.tool_call,
            'error': e.error_details,
        } for e in events]

    def get_agent_execution_log(self, task_id: str) -> List[Dict[str, Any]]:
        """获取Agent执行日志"""
        logs = self._db.query(AgentExecutionLog).filter(
            AgentExecutionLog.task_id == task_id
        ).order_by(AgentExecutionLog.created_at.asc()).all()

        return [{
            'log_id': l.log_id,
            'agent_type': l.agent_type,
            'agent_name': l.agent_name,
            'status': l.status,
            'confidence': l.confidence,
            'duration_sec': l.duration_sec,
            'error': l.error_message,
            'tool_calls': l.tool_calls,
            'created_at': l.created_at.isoformat(),
        } for l in logs]

    def get_error_analysis(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取错误分析"""
        self._flush()
        errors = self._db.query(AuditEvent).filter(
            AuditEvent.task_id == task_id,
            AuditEvent.event_type == 'error'
        ).all()

        if not errors:
            return None

        return {
            'total_errors': len(errors),
            'error_types': list(set(e.error_details for e in errors if e.error_details)),
            'affected_agents': list(set(e.agent_id for e in errors if e.agent_id)),
            'first_error_time': errors[0].timestamp.isoformat(),
            'last_error_time': errors[-1].timestamp.isoformat(),
        }

    def __del__(self):
        self._flush()
