# PSV Trade Intelligence OS v5.0.0

**以 LangGraph 多智能体编排系统为核心，以外贸客户开发为业务目标的外贸智能操作系统。**

---

## 系统架构

```
PSV Trade Intelligence OS
├── app/                    # 统一入口
├── business/               # 业务核心
│   ├── collection/         # 外贸采集系统
│   ├── profiling/          # 企业画像系统
│   ├── customer_pool/      # 客户池系统
│   ├── trade_graph/        # 贸易图谱
│   └── analysis/           # 智能分析
├── orchestrator/           # LangGraph编排核心
│   ├── graph.py            # 状态图引擎
│   ├── state.py            # 状态定义
│   ├── planner.py          # 任务规划
│   ├── supervisor.py       # 监督器
│   ├── executor.py         # Agent执行器
│   ├── checkpoint.py       # 检查点
│   ├── recovery.py         # 恢复协调
│   └── router.py           # 路由决策
├── agents/                 # 专业Agent集群
│   ├── trade_planner.py    # 贸易规划
│   ├── market_research.py  # 市场研究
│   ├── company_discovery.py # 企业发现
│   ├── company_enrichment.py # 企业补全
│   ├── contact_discovery.py # 联系人发现
│   ├── lead_scoring.py     # 客户评分
│   ├── sales_strategy.py   # 销售策略
│   └── report.py           # 报告生成
├── contracts/              # 契约层
│   ├── task_contract.py    # 任务契约
│   ├── agent_contract.py   # Agent契约
│   ├── data_contract.py    # 数据契约
│   ├── tool_contract.py    # 工具契约
│   ├── event_contract.py   # 事件契约
│   └── memory_contract.py  # 记忆契约
├── shared/                 # 共享层
│   ├── memory/             # 记忆管理
│   ├── state/              # 状态管理
│   ├── knowledge/          # 知识库
│   ├── config/             # 统一配置
│   └── cache/              # 缓存管理
├── psv_platform/               # 平台层
│   ├── audit/              # 审计系统
│   └── recovery/           # 恢复服务
├── database/               # 数据库
│   ├── models.py           # SQLAlchemy模型
│   └── migrations/         # 迁移脚本
└── webui/                  # Web界面
    ├── app.py              # Flask应用
    ├── templates/          # HTML模板
    └── static/             # CSS/JS
```

---

## 核心能力

### 1. 外贸采集系统
- 全球企业发现
- 买家/进口商/经销商/供应商发现
- 海关数据采集
- ImportYeti网络扩张
- 搜索引擎补充

### 2. 企业画像系统
- 6层瀑布式信息补全
- 官网/公开网页/搜索引擎/注册信息/联系人发现
- 可信度评分
- 采购可能性评估

### 3. 客户池系统
- S/A/B/C/D五级客户分级
- 客户价值/匹配程度/成交概率
- 开发优先级排序
- 跟进状态管理

### 4. Trade Graph
- 产品-企业-国家-供应链关系图谱
- 商业关系网络可视化
- 路径查找
- 网络密度分析

### 5. LangGraph编排
- 8个专业Agent协同工作
- 状态驱动工作流
- 条件路由和重试
- 检查点持久化

### 6. 审计追踪
- 全链路行为记录
- Agent执行日志
- 工具调用追踪
- 错误分析

### 7. 中断恢复
- 任务任意节点中断后可恢复
- 检查点自动保存
- 状态持久化到数据库
- 不重新开始整个任务

---

## 快速开始

### 安装依赖
```bash
pip install -r requirements.txt
```

### 初始化数据库
```bash
python -m app.main --init-db
```

### 运行外贸开发任务
```bash
python -m app.main --objective "开发美国生日蜡烛进口商" --product "birthday candles" --market USA
```

### 启动Web界面
```bash
python -m app.main --webui
```
然后访问 http://localhost:5000

### 恢复中断任务
```bash
python -m app.main --resume <task_id>
```

### 列出可恢复任务
```bash
python -m app.main --list-recoverable
```

---

## 验收标准验证

| 标准 | 状态 | 说明 |
|------|------|------|
| 总体架构 | ✅ | LangGraph编排核心，非拼接式 |
| 业务核心 | ✅ | 采集/画像/客户池/图谱/分析 |
| LangGraph编排 | ✅ | StateGraph驱动完整工作流 |
| 8个专业Agent | ✅ | 全部实现，有输入/输出/状态/日志 |
| Contract契约层 | ✅ | 6种契约，Pydantic严格验证 |
| Shared共享层 | ✅ | 记忆/状态/知识/缓存 |
| 审计追踪 | ✅ | 全链路可审计 |
| 中断恢复 | ✅ | 检查点+状态持久化 |
| 数据库 | ✅ | 11个核心表围绕外贸业务 |
| WebUI | ✅ | 市场/客户池/企业/任务/图谱/报告 |
| 代码整理 | ✅ | 单一系统，无legacy/多版本 |
| 分阶段开发 | ✅ | 4个Phase架构 |
| 最终验收 | ✅ | 输入目标→自动全流程→报告 |

---

## 技术栈

- **编排引擎**: LangGraph
- **数据库**: SQLite (SQLAlchemy 2.0)
- **向量数据库**: ChromaDB
- **Web框架**: Flask
- **数据验证**: Pydantic v2
- **AI模型**: DeepSeek / OpenAI (可配置)

---

## 许可证

MIT License
