# PSV Trade Intelligence OS v5.1.2 Production Deploy

Added deployment layer:
- start.bat
- install.bat
- stop.bat
- restart.bat
- unified version entry

Purpose: production test deployment baseline.
