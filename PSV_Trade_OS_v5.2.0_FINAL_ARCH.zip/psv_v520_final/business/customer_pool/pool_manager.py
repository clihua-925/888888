# -*- coding: utf-8 -*-
"""客户池系统 - Customer Intelligence Pool

包含：
- 客户等级 (S/A/B/C/D)
- 客户价值
- 匹配程度
- 成交概率
- 开发优先级
- 跟进状态
"""
import json
from typing import Dict, List, Any, Optional
from datetime import datetime

from database.models import TradeCustomerPool, TradeCompany, SessionLocal
from shared.config import CUSTOMER_TIERS, DEVELOPMENT_STAGES
from contracts.data_contract import CompanyProfile, LeadScore

class CustomerPoolManager:
    """客户池管理器"""

    def __init__(self):
        self._db = SessionLocal()

    def add_to_pool(self, company: CompanyProfile, product_id: str = None,
                    market_id: str = None, lead_score: LeadScore = None) -> str:
        """将企业加入客户池"""
        # 先确保公司在trade_company表中
        db_company = self._db.query(TradeCompany).filter(
            TradeCompany.name_norm == company.name_norm
        ).first()

        if not db_company:
            db_company = TradeCompany(
                name=company.name,
                name_norm=company.name_norm,
                country=company.country,
                website=company.website,
                industry=company.industry,
                main_products=company.main_products,
                credibility_score=company.credibility_score,
                purchase_probability=company.purchase_probability,
                match_score=company.match_score,
                deal_probability=company.deal_probability,
                customer_tier=lead_score.tier if lead_score else 'D',
                source=company.source,
            )
            self._db.add(db_company)
            self._db.commit()
            self._db.refresh(db_company)

        # 检查是否已在客户池
        existing = self._db.query(TradeCustomerPool).filter(
            TradeCustomerPool.company_id == db_company.entity_id
        ).first()

        if existing:
            # 更新评分
            if lead_score:
                existing.customer_value = lead_score.overall_score
                existing.match_score = lead_score.match_degree
                existing.deal_probability = lead_score.deal_probability
                existing.development_priority = self._calc_priority(lead_score)
            existing.updated_at = datetime.now()
            pool_id = existing.pool_id
        else:
            # 创建新客户池记录
            pool_entry = TradeCustomerPool(
                company_id=db_company.entity_id,
                product_id=product_id,
                market_id=market_id,
                customer_value=lead_score.overall_score if lead_score else 0.0,
                match_score=lead_score.match_degree if lead_score else 0.0,
                deal_probability=lead_score.deal_probability if lead_score else 0.0,
                development_priority=self._calc_priority(lead_score) if lead_score else 0,
                follow_up_status='new',
                next_action='初次接触准备',
            )
            self._db.add(pool_entry)
            self._db.commit()
            self._db.refresh(pool_entry)
            pool_id = pool_entry.pool_id

        return pool_id

    def _calc_priority(self, lead_score: LeadScore) -> int:
        """计算开发优先级 (1-100)"""
        priority = 0
        priority += lead_score.overall_score * 0.4
        priority += lead_score.deal_probability * 0.3
        priority += lead_score.purchase_likelihood * 0.2
        priority += lead_score.company_strength * 0.1
        return int(min(100, priority))

    def get_pool(self, tier: Optional[str] = None, 
                 status: Optional[str] = None,
                 min_priority: int = 0,
                 limit: int = 100) -> List[Dict[str, Any]]:
        """获取客户池列表"""
        query = self._db.query(TradeCustomerPool, TradeCompany).join(
            TradeCompany, TradeCustomerPool.company_id == TradeCompany.entity_id
        )

        if tier:
            query = query.filter(TradeCompany.customer_tier == tier)
        if status:
            query = query.filter(TradeCustomerPool.follow_up_status == status)
        if min_priority > 0:
            query = query.filter(TradeCustomerPool.development_priority >= min_priority)

        results = query.order_by(
            TradeCustomerPool.development_priority.desc()
        ).limit(limit).all()

        return [{
            'pool_id': r.TradeCustomerPool.pool_id,
            'company_id': r.TradeCompany.entity_id,
            'name': r.TradeCompany.name,
            'country': r.TradeCompany.country,
            'website': r.TradeCompany.website,
            'tier': r.TradeCompany.customer_tier,
            'customer_value': r.TradeCustomerPool.customer_value,
            'match_score': r.TradeCustomerPool.match_score,
            'deal_probability': r.TradeCustomerPool.deal_probability,
            'priority': r.TradeCustomerPool.development_priority,
            'status': r.TradeCustomerPool.follow_up_status,
            'next_action': r.TradeCustomerPool.next_action,
            'last_contact': r.TradeCustomerPool.last_contact_date.isoformat() if r.TradeCustomerPool.last_contact_date else None,
            'created_at': r.TradeCustomerPool.created_at.isoformat(),
        } for r in results]

    def update_status(self, pool_id: str, status: str, 
                      next_action: str = None, notes: str = None):
        """更新跟进状态"""
        entry = self._db.query(TradeCustomerPool).filter(
            TradeCustomerPool.pool_id == pool_id
        ).first()

        if entry:
            entry.follow_up_status = status
            entry.last_contact_date = datetime.now()
            if next_action:
                entry.next_action = next_action
            if notes:
                entry.notes = notes
            self._db.commit()

    def get_pool_stats(self) -> Dict[str, Any]:
        """获取客户池统计"""
        total = self._db.query(TradeCustomerPool).count()

        tier_counts = {}
        for tier in ['S', 'A', 'B', 'C', 'D']:
            count = self._db.query(TradeCustomerPool).join(TradeCompany).filter(
                TradeCompany.customer_tier == tier
            ).count()
            tier_counts[tier] = count

        status_counts = {}
        for status in DEVELOPMENT_STAGES:
            count = self._db.query(TradeCustomerPool).filter(
                TradeCustomerPool.follow_up_status == status
            ).count()
            status_counts[status] = count

        return {
            'total': total,
            'tier_distribution': tier_counts,
            'status_distribution': status_counts,
            'avg_customer_value': self._db.query(TradeCustomerPool).with_entities(
                func.avg(TradeCustomerPool.customer_value)
            ).scalar() or 0,
        }

from sqlalchemy import func
