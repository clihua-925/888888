# -*- coding: utf-8 -*-
"""外贸采集系统 - 全球企业发现引擎

负责：
- 全球企业发现
- 买家发现
- 进口商发现
- 经销商发现
- 供应商发现
- 市场数据采集
- 企业网站信息采集

输入：产品、国家、市场、客户类型
输出：企业候选池
"""
import re
import time
import json
import random
import requests
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from bs4 import BeautifulSoup

from shared.config import COLLECTION_CONFIG, MARKETS, EVIDENCE_LEVELS
from shared.cache.cache_manager import CacheManager
from contracts.data_contract import CompanyProfile

class TradeCollector:
    """统一采集引擎"""

    # 扩张策略注册表
    STRATEGIES = {
        'customer_suppliers': {'label': '客户→供应商→客户', 'kind': 'web'},
        'supplier_customers': {'label': '供应商→客户', 'kind': 'web'},
        'importer_suppliers': {'label': '进口商→供应商', 'kind': 'web'},
        'exporter_customers': {'label': '出口商→客户', 'kind': 'web'},
        'same_product_importers': {'label': '同产品进口商', 'kind': 'local'},
        'cross_market_entity': {'label': '同实体跨市场', 'kind': 'local'},
    }

    DEFAULT_ORDER = [
        'customer_suppliers', 'supplier_customers', 
        'same_product_importers', 'cross_market_entity'
    ]

    SEED_POOL = {
        'customer_suppliers': ('customer', 'dev'),
        'importer_suppliers': ('customer', 'pending'),
        'supplier_customers': ('supplier', 'dev'),
        'exporter_customers': ('supplier', 'pool'),
    }

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': random.choice(COLLECTION_CONFIG['user_agents'])
        })
        self.cache = CacheManager()
        self._executor = ThreadPoolExecutor(max_workers=COLLECTION_CONFIG['max_workers'])

    def discover_companies(self, product: str, market: str, 
                           customer_type: str = 'importer',
                           max_results: int = 50,
                           min_shipments: int = 3) -> List[CompanyProfile]:
        """发现企业主入口"""
        print(f"🔍 开始采集: {product} in {market}, 类型: {customer_type}")

        cache_key = self.cache._make_key('discover', product, market, customer_type, max_results)
        cached = self.cache.get(cache_key)
        if cached:
            print(f"📦 命中缓存，返回 {len(cached)} 条结果")
            return [CompanyProfile(**c) for c in cached]

        companies = []

        # 1. 海关数据采集（最强证据）
        customs_companies = self._collect_from_customs(product, market, min_shipments)
        companies.extend(customs_companies)
        print(f"  📋 海关数据: {len(customs_companies)} 条")

        # 2. ImportYeti 网络扩张
        if len(companies) < max_results:
            iy_companies = self._collect_from_importyeti(product, market, max_results - len(companies))
            companies.extend(iy_companies)
            print(f"  🌐 ImportYeti: {len(iy_companies)} 条")

        # 3. 搜索引擎补充
        if len(companies) < max_results:
            search_companies = self._collect_from_search(product, market, max_results - len(companies))
            companies.extend(search_companies)
            print(f"  🔎 搜索引擎: {len(search_companies)} 条")

        # 4. 去重和排序
        companies = self._deduplicate_and_rank(companies)
        companies = companies[:max_results]

        # 缓存结果
        self.cache.set(cache_key, [c.dict() for c in companies], ttl=3600*24)

        print(f"✅ 采集完成: 共 {len(companies)} 条企业候选")
        return companies

    def _collect_from_customs(self, product: str, market: str, 
                              min_shipments: int) -> List[CompanyProfile]:
        """从海关数据采集中文"""
        from database.models import CustomsRaw, SessionLocal, get_db

        db = SessionLocal()
        try:
            # 查询海关数据
            results = db.query(CustomsRaw).filter(
                CustomsRaw.descr.contains(product),
                CustomsRaw.importer_norm.isnot(None)
            ).all()

            company_map = {}
            for r in results:
                norm = r.importer_norm
                if norm not in company_map:
                    company_map[norm] = {
                        'name': r.importer,
                        'name_norm': norm,
                        'country': market,
                        'shipments': 0,
                        'products': set(),
                        'evidence': [],
                    }
                company_map[norm]['shipments'] += 1
                company_map[norm]['products'].add(r.descr)
                company_map[norm]['evidence'].append({
                    'bol': r.bol,
                    'hs': r.hs,
                    'qty': r.qty,
                    'weight': r.weight,
                    'source': 'customs_record',
                    'level': EVIDENCE_LEVELS['customs_record'],
                })

            companies = []
            for norm, data in company_map.items():
                if data['shipments'] >= min_shipments:
                    companies.append(CompanyProfile(
                        name=data['name'],
                        name_norm=data['name_norm'],
                        country=data['country'],
                        main_products=list(data['products'])[:8],
                        credibility_score=min(100, data['shipments'] * 5),
                        purchase_probability=min(100, data['shipments'] * 3),
                        evidence=data['evidence'],
                        source='customs',
                    ))

            return companies
        finally:
            db.close()

    def _collect_from_importyeti(self, product: str, market: str, 
                                 limit: int) -> List[CompanyProfile]:
        """从ImportYeti采集中文"""
        # 模拟ImportYeti API调用（实际需替换为真实API）
        companies = []
        # 这里应实现真实的ImportYeti网页抓取或API调用
        # 参考原始版 core/tools/iy_web.py 和 core/trade_graph/iy_network.py
        return companies

    def _collect_from_search(self, product: str, market: str, 
                             limit: int) -> List[CompanyProfile]:
        """从搜索引擎采集中文"""
        companies = []
        try:
            query = f'"{product}" importer distributor {market}'
            # DuckDuckGo搜索
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                results = list(ddgs.text(query, max_results=limit))
                for r in results:
                    # 解析搜索结果提取公司信息
                    companies.append(CompanyProfile(
                        name=r.get('title', '').split(' - ')[0][:200],
                        website=r.get('href', '')[:500],
                        country=market,
                        main_products=[product],
                        credibility_score=10,
                        evidence=[{
                            'source': 'search_result',
                            'url': r.get('href', ''),
                            'snippet': r.get('body', '')[:500],
                            'level': EVIDENCE_LEVELS['search_result'],
                        }],
                        source='search',
                    ))
        except Exception as e:
            print(f"⚠️ 搜索引擎采集失败: {e}")
        return companies

    def _deduplicate_and_rank(self, companies: List[CompanyProfile]) -> List[CompanyProfile]:
        """去重和排序"""
        seen = {}
        for c in companies:
            key = c.name_norm or c.name.lower().strip()
            if key in seen:
                # 合并证据
                existing = seen[key]
                existing.evidence.extend(c.evidence)
                existing.credibility_score = max(existing.credibility_score, c.credibility_score)
                existing.purchase_probability = max(existing.purchase_probability, c.purchase_probability)
                if c.website and not existing.website:
                    existing.website = c.website
            else:
                seen[key] = c

        # 按可信度排序
        return sorted(seen.values(), key=lambda x: x.credibility_score, reverse=True)

    def collect_market_data(self, market: str, product: str) -> Dict[str, Any]:
        """采集市场数据"""
        cache_key = self.cache._make_key('market', market, product)
        cached = self.cache.get(cache_key)
        if cached:
            return cached

        market_data = {
            'market': market,
            'product': product,
            'market_size': None,
            'growth_rate': None,
            'competition_level': 'medium',
            'key_trends': [],
            'major_players': [],
            'collected_at': time.time(),
        }

        self.cache.set(cache_key, market_data, ttl=3600*24*7)
        return market_data

    def collect_company_website(self, website: str) -> Dict[str, Any]:
        """采集企业网站信息"""
        if not website:
            return {}

        cache_key = self.cache._make_key('website', website)
        cached = self.cache.get(cache_key)
        if cached:
            return cached

        try:
            url = website if website.startswith('http') else f'https://{website}'
            resp = self.session.get(url, timeout=15, headers={
                'User-Agent': random.choice(COLLECTION_CONFIG['user_agents'])
            })
            soup = BeautifulSoup(resp.text, 'html.parser')

            # 提取基本信息
            title = soup.title.string if soup.title else ''
            description = ''
            desc_tag = soup.find('meta', attrs={'name': 'description'})
            if desc_tag:
                description = desc_tag.get('content', '')

            # 提取联系信息
            emails = re.findall(r'[\w.+-]+@[\w-]+\.[\w.]+', resp.text)
            phones = re.findall(r'[\+]?[1-9]?[0-9]{7,15}', resp.text)

            # 提取产品信息
            products = []
            for heading in soup.find_all(['h1', 'h2', 'h3']):
                text = heading.get_text().strip()
                if any(kw in text.lower() for kw in ['product', 'catalog', 'item', 'series']):
                    products.append(text)

            result = {
                'title': title[:200],
                'description': description[:1000],
                'emails': list(set(emails))[:5],
                'phones': list(set(phones))[:3],
                'products': products[:10],
                'industry_tags': self._extract_industry_tags(soup),
                'collected_at': time.time(),
            }

            self.cache.set(cache_key, result, ttl=3600*24)
            return result

        except Exception as e:
            print(f"⚠️ 网站采集失败 {website}: {e}")
            return {}

    def _extract_industry_tags(self, soup) -> List[str]:
        """提取行业标签"""
        tags = []
        keywords = soup.find('meta', attrs={'name': 'keywords'})
        if keywords:
            tags = [t.strip() for t in keywords.get('content', '').split(',')[:10]]
        return tags
