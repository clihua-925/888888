# -*- coding: utf-8 -*-
"""外贸智能分析系统

包括：
- 市场分析
- 竞争分析
- 采购趋势
- 客户分析
- 销售策略
- 开发建议
"""
import json
from typing import Dict, List, Any, Optional
from datetime import datetime

from database.models import TradeCompany, TradeCustomerPool, TradeOpportunity, SessionLocal
from shared.knowledge.knowledge_base import KnowledgeBase
from contracts.data_contract import MarketAnalysis

class TradeAnalyzer:
    """外贸智能分析引擎"""

    def __init__(self):
        self._db = SessionLocal()
        self.kb = KnowledgeBase()

    def analyze_market(self, market: str, product: str) -> MarketAnalysis:
        """市场分析"""
        market_profile = self.kb.get_market_profile(market)

        # 统计该市场该产品相关的企业
        companies = self._db.query(TradeCompany).filter(
            TradeCompany.country == market,
            TradeCompany.main_products.contains(product)
        ).all()

        # 统计客户池
        pool_entries = self._db.query(TradeCustomerPool).join(TradeCompany).filter(
            TradeCompany.country == market
        ).all()

        # 计算竞争度
        total = len(companies)
        high_score = sum(1 for c in companies if c.credibility_score > 60)
        competition = 'high' if total > 50 else 'medium' if total > 20 else 'low'

        analysis = MarketAnalysis(
            country_code=market,
            market_size=total * 1000000 if total else None,  # 估算
            competition_level=competition,
            key_trends=self._extract_trends(companies),
            major_players=[{
                'name': c.name,
                'score': c.credibility_score,
                'role': c.supply_chain_role,
            } for c in sorted(companies, key=lambda x: x.credibility_score, reverse=True)[:10]],
            opportunities=self._find_opportunities(market, product, companies),
            risks=self._assess_risks(market, product),
        )

        return analysis

    def analyze_competition(self, product: str, market: str) -> Dict[str, Any]:
        """竞争分析"""
        companies = self._db.query(TradeCompany).filter(
            TradeCompany.country == market
        ).all()

        # 按角色分组
        by_role = {}
        for c in companies:
            role = c.supply_chain_role or 'unknown'
            if role not in by_role:
                by_role[role] = []
            by_role[role].append({
                'name': c.name,
                'score': c.credibility_score,
                'tier': c.customer_tier,
            })

        # 评分分布
        score_dist = {'high': 0, 'medium': 0, 'low': 0}
        for c in companies:
            if c.credibility_score >= 60:
                score_dist['high'] += 1
            elif c.credibility_score >= 30:
                score_dist['medium'] += 1
            else:
                score_dist['low'] += 1

        return {
            'total_competitors': len(companies),
            'by_role': by_role,
            'score_distribution': score_dist,
            'top_competitors': sorted(
                [{'name': c.name, 'score': c.credibility_score} for c in companies],
                key=lambda x: x['score'], reverse=True
            )[:10],
            'market_saturation': len(companies) / 100,  # 简化计算
        }

    def analyze_purchase_trends(self, product: str, market: str) -> Dict[str, Any]:
        """采购趋势分析"""
        from database.models import CustomsRaw

        records = self._db.query(CustomsRaw).filter(
            CustomsRaw.descr.contains(product)
        ).all()

        monthly = {}
        for r in records:
            if r.ts:
                from datetime import datetime
                month = datetime.fromtimestamp(r.ts).strftime('%Y-%m')
                if month not in monthly:
                    monthly[month] = {'shipments': 0, 'weight': 0, 'qty': 0}
                monthly[month]['shipments'] += 1
                monthly[month]['weight'] += r.weight or 0
                monthly[month]['qty'] += r.qty or 0

        return {
            'product': product,
            'market': market,
            'total_records': len(records),
            'monthly_trend': monthly,
            'peak_months': sorted(monthly.keys())[-3:] if monthly else [],
            'avg_shipment_weight': sum(r.weight or 0 for r in records) / len(records) if records else 0,
        }

    def analyze_customer_segment(self, tier: str = None) -> Dict[str, Any]:
        """客户细分分析"""
        query = self._db.query(TradeCustomerPool, TradeCompany).join(TradeCompany)
        if tier:
            query = query.filter(TradeCompany.customer_tier == tier)

        results = query.all()

        segments = {}
        for r in results:
            country = r.TradeCompany.country or 'Unknown'
            if country not in segments:
                segments[country] = []
            segments[country].append({
                'name': r.TradeCompany.name,
                'value': r.TradeCustomerPool.customer_value,
                'probability': r.TradeCustomerPool.deal_probability,
                'status': r.TradeCustomerPool.follow_up_status,
            })

        return {
            'total_segmented': len(results),
            'by_country': segments,
            'avg_value': sum(r.TradeCustomerPool.customer_value for r in results) / len(results) if results else 0,
            'high_value_count': sum(1 for r in results if r.TradeCustomerPool.customer_value > 70),
        }

    def generate_development_suggestions(self, pool_id: str) -> List[str]:
        """生成开发建议"""
        entry = self._db.query(TradeCustomerPool, TradeCompany).join(TradeCompany).filter(
            TradeCustomerPool.pool_id == pool_id
        ).first()

        if not entry:
            return []

        suggestions = []
        company = entry.TradeCompany
        pool = entry.TradeCustomerPool

        if pool.deal_probability > 70:
            suggestions.append(f"{company.name} 成交概率高({pool.deal_probability:.0f}%)，建议优先跟进")

        if company.website and not company.contacts:
            suggestions.append(f"{company.name} 有官网但缺少联系人，建议通过官网挖掘决策人")

        if company.supply_chain_role == 'importer':
            suggestions.append(f"{company.name} 是进口商，建议强调产品质量和认证")

        if company.country in ['USA', 'EU']:
            suggestions.append(f"{company.name} 在{company.country}，建议准备FDA/CE认证资料")

        if pool.match_score < 50:
            suggestions.append(f"{company.name} 匹配度较低({pool.match_score:.0f}%)，建议重新评估产品适配性")

        return suggestions

    def _extract_trends(self, companies: List[Any]) -> List[str]:
        """提取趋势"""
        trends = []
        if len(companies) > 50:
            trends.append("该市场参与者众多，竞争激烈")
        if any(c.supply_chain_role == 'distributor' for c in companies):
            trends.append("存在活跃经销商网络，可考虑渠道合作")
        return trends

    def _find_opportunities(self, market: str, product: str, 
                            companies: List[Any]) -> List[str]:
        """发现机会"""
        opportunities = []
        high_score_count = sum(1 for c in companies if c.credibility_score > 60)
        if high_score_count < 10:
            opportunities.append(f"{market}市场高质量竞争者较少，存在进入机会")
        opportunities.append(f"{product}在{market}有{len(companies)}家相关企业，市场规模可观")
        return opportunities

    def _assess_risks(self, market: str, product: str) -> List[str]:
        """评估风险"""
        risks = []
        if market in ['USA']:
            risks.append("美国市场关税政策变化风险")
        if 'candle' in product.lower():
            risks.append("蜡烛产品需关注消防安全法规")
        return risks
