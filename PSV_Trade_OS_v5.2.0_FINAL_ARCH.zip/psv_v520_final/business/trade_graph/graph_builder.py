# -*- coding: utf-8 -*-
"""Trade Graph - 商业关系图谱

形成：产品、企业、国家、供应链、市场、客户关系
"""
import json
from typing import Dict, List, Any, Optional
from datetime import datetime

from database.models import TradeCompany, TradeRelationship, SessionLocal
from shared.config import TRADE_ROLES

class TradeGraphBuilder:
    """贸易图谱构建器"""

    def __init__(self):
        self._db = SessionLocal()

    def add_node(self, entity_id: str, name: str, role: str, 
                 country: str = None, metadata: Dict[str, Any] = None):
        """添加图谱节点"""
        # 节点即企业，已在TradeCompany表中
        company = self._db.query(TradeCompany).filter(
            TradeCompany.entity_id == entity_id
        ).first()

        if company:
            company.supply_chain_role = role
            if metadata:
                company.evidence = (company.evidence or []) + [metadata]
            self._db.commit()

    def add_edge(self, from_id: str, to_id: str, relation_type: str,
                 evidence: Dict[str, Any] = None, confidence: float = 0.5):
        """添加关系边"""
        # 检查是否已存在
        existing = self._db.query(TradeRelationship).filter(
            TradeRelationship.from_entity_id == from_id,
            TradeRelationship.to_entity_id == to_id,
            TradeRelationship.relation_type == relation_type
        ).first()

        if existing:
            # 更新证据和置信度
            existing.evidence = (existing.evidence or []) + [evidence] if evidence else existing.evidence
            existing.confidence = max(existing.confidence, confidence)
            existing.last_seen = datetime.now()
        else:
            edge = TradeRelationship(
                from_entity_id=from_id,
                to_entity_id=to_id,
                relation_type=relation_type,
                evidence=[evidence] if evidence else [],
                confidence=confidence,
                first_seen=datetime.now(),
                last_seen=datetime.now(),
            )
            self._db.add(edge)

        self._db.commit()

    def build_supply_chain(self, entity_id: str, depth: int = 2) -> Dict[str, Any]:
        """构建供应链子图"""
        nodes = {}
        edges = []
        visited = set()

        def _build(node_id: str, current_depth: int):
            if current_depth > depth or node_id in visited:
                return
            visited.add(node_id)

            company = self._db.query(TradeCompany).filter(
                TradeCompany.entity_id == node_id
            ).first()

            if company:
                nodes[node_id] = {
                    'id': node_id,
                    'name': company.name,
                    'country': company.country,
                    'role': company.supply_chain_role,
                    'tier': company.customer_tier,
                }

            # 获取上下游关系
            relations = self._db.query(TradeRelationship).filter(
                (TradeRelationship.from_entity_id == node_id) |
                (TradeRelationship.to_entity_id == node_id)
            ).all()

            for rel in relations:
                edges.append({
                    'from': rel.from_entity_id,
                    'to': rel.to_entity_id,
                    'type': rel.relation_type,
                    'confidence': rel.confidence,
                })

                next_id = rel.to_entity_id if rel.from_entity_id == node_id else rel.from_entity_id
                _build(next_id, current_depth + 1)

        _build(entity_id, 0)

        return {
            'center_node': entity_id,
            'nodes': list(nodes.values()),
            'edges': edges,
            'depth': depth,
        }

    def get_network_stats(self) -> Dict[str, Any]:
        """获取网络统计"""
        node_count = self._db.query(TradeCompany).count()
        edge_count = self._db.query(TradeRelationship).count()

        role_dist = {}
        for role in TRADE_ROLES:
            count = self._db.query(TradeCompany).filter(
                TradeCompany.supply_chain_role == role
            ).count()
            if count > 0:
                role_dist[role] = count

        relation_dist = {}
        for rel_type in ['supplier', 'customer', 'competitor', 'partner']:
            count = self._db.query(TradeRelationship).filter(
                TradeRelationship.relation_type == rel_type
            ).count()
            relation_dist[rel_type] = count

        return {
            'total_nodes': node_count,
            'total_edges': edge_count,
            'role_distribution': role_dist,
            'relation_distribution': relation_dist,
            'network_density': edge_count / (node_count * (node_count - 1)) if node_count > 1 else 0,
        }

    def find_path(self, from_id: str, to_id: str, max_depth: int = 3) -> Optional[List[Dict[str, Any]]]:
        """查找两个实体间的路径"""
        # BFS
        from collections import deque

        queue = deque([(from_id, [])])
        visited = {from_id}

        while queue:
            current, path = queue.popleft()

            if current == to_id:
                return path

            if len(path) >= max_depth:
                continue

            relations = self._db.query(TradeRelationship).filter(
                TradeRelationship.from_entity_id == current
            ).all()

            for rel in relations:
                if rel.to_entity_id not in visited:
                    visited.add(rel.to_entity_id)
                    queue.append((rel.to_entity_id, path + [{
                        'from': current,
                        'to': rel.to_entity_id,
                        'type': rel.relation_type,
                        'confidence': rel.confidence,
                    }]))

        return None
