# -*- coding: utf-8 -*-
"""企业画像系统 - 每家公司形成完整 Company Profile

必须包含：
- 公司名称、国家、官网
- 行业、主营产品、采购方向
- 企业规模、供应链关系
- 联系人、联系方式
- 可信度评分、采购可能性
"""
import json
import time
import re
import requests
from typing import Dict, List, Any, Optional
from bs4 import BeautifulSoup

from shared.config import COLLECTION_CONFIG
from shared.cache.cache_manager import CacheManager
from contracts.data_contract import CompanyProfile, ContactInfo
from database.models import TradeCompany, TradeContact, SessionLocal

class CompanyProfiler:
    """企业画像引擎 - 6层瀑布式补全"""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.cache = CacheManager()

    def enrich_profile(self, company: CompanyProfile, 
                       force: bool = False) -> CompanyProfile:
        """补全企业画像（6层瀑布）"""
        cache_key = self.cache._make_key('profile', company.name_norm or company.name)
        if not force:
            cached = self.cache.get(cache_key)
            if cached:
                return CompanyProfile(**cached)

        print(f"🔍 补全企业画像: {company.name}")

        # 第1层：数据库已有信息
        self._source_database(company)

        # 第2层：公司官网
        if company.website:
            self._source_company_website(company)

        # 第3层：公开网页
        self._source_public_webpage(company)

        # 第4层：搜索引擎
        self._source_search_engine(company)

        # 第5层：公开注册信息
        self._source_public_registry(company)

        # 第6层：联系人发现
        self._source_contact_finder(company)

        # 计算综合评分
        self._calculate_scores(company)

        # 缓存结果
        self.cache.set(cache_key, company.dict(), ttl=3600*24*7)

        # 持久化到数据库
        self._persist_to_db(company)

        print(f"✅ 画像补全完成: {company.name} (可信度: {company.credibility_score:.1f})")
        return company

    def _source_database(self, company: CompanyProfile):
        """从数据库补充信息"""
        db = SessionLocal()
        try:
            existing = db.query(TradeCompany).filter(
                TradeCompany.name_norm == company.name_norm
            ).first()

            if existing:
                if existing.website and not company.website:
                    company.website = existing.website
                if existing.industry and not company.industry:
                    company.industry = existing.industry
                if existing.company_size and not company.company_size:
                    company.company_size = existing.company_size
                if existing.main_products and not company.main_products:
                    company.main_products = existing.main_products
                if existing.evidence:
                    company.evidence.extend(existing.evidence if isinstance(existing.evidence, list) else [])
        finally:
            db.close()

    def _source_company_website(self, company: CompanyProfile):
        """从公司官网补充信息"""
        try:
            url = company.website if company.website.startswith('http') else f'https://{company.website}'
            resp = self.session.get(url, timeout=15)
            soup = BeautifulSoup(resp.text, 'html.parser')

            # 提取行业信息
            if not company.industry:
                keywords = soup.find('meta', attrs={'name': 'keywords'})
                if keywords:
                    company.industry = keywords.get('content', '')[:200]

            # 提取联系信息
            emails = re.findall(r'[\w.+-]+@[\w-]+\.[\w.]+', resp.text)
            phones = re.findall(r'[\+]?[1-9]?[0-9]{7,15}', resp.text)

            for email in set(emails)[:3]:
                company.contacts.append(ContactInfo(
                    email=email,
                    source='company_website',
                    confidence=0.8,
                ).dict())

            # 提取产品信息
            if not company.main_products:
                products = []
                for h in soup.find_all(['h1', 'h2', 'h3']):
                    text = h.get_text().strip()
                    if len(text) > 3 and len(text) < 100:
                        products.append(text)
                company.main_products = products[:8]

            company.evidence.append({
                'source': 'company_website',
                'url': company.website,
                'level': 2,
            })

        except Exception as e:
            print(f"  ⚠️ 官网采集失败: {e}")

    def _source_public_webpage(self, company: CompanyProfile):
        """从公开网页补充信息"""
        pass  # 可扩展LinkedIn、Crunchbase等

    def _source_search_engine(self, company: CompanyProfile):
        """从搜索引擎补充信息"""
        try:
            query = f'"{company.name}" company profile importer'
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                results = list(ddgs.text(query, max_results=5))
                for r in results:
                    body = r.get('body', '')
                    # 提取规模信息
                    if not company.company_size:
                        size_patterns = [
                            r'(\d+)\s+employees',
                            r'(\d+)\s+staff',
                            r'annual revenue\s+\$?([\d,]+)',
                        ]
                        for pattern in size_patterns:
                            match = re.search(pattern, body, re.I)
                            if match:
                                company.company_size = match.group(0)[:50]
                                break
        except Exception as e:
            print(f"  ⚠️ 搜索引擎补全失败: {e}")

    def _source_public_registry(self, company: CompanyProfile):
        """从公开注册信息补充"""
        pass  # 可扩展OpenCorporates等

    def _source_contact_finder(self, company: CompanyProfile):
        """联系人发现"""
        if company.website:
            try:
                url = company.website if company.website.startswith('http') else f'https://{company.website}'
                resp = self.session.get(f"{url}/contact", timeout=10)
                emails = re.findall(r'[\w.+-]+@[\w-]+\.[\w.]+', resp.text)
                for email in set(emails):
                    if not any(c.get('email') == email for c in company.contacts):
                        company.contacts.append(ContactInfo(
                            email=email,
                            source='contact_page',
                            confidence=0.7,
                        ).dict())
            except:
                pass

    def _calculate_scores(self, company: CompanyProfile):
        """计算综合评分"""
        # 基础分
        base_score = 0

        # 有官网 +20
        if company.website:
            base_score += 20

        # 有联系人 +15
        if company.contacts:
            base_score += min(15, len(company.contacts) * 5)

        # 有产品信息 +15
        if company.main_products:
            base_score += 15

        # 有海关证据 +30
        customs_evidence = [e for e in company.evidence if e.get('source') == 'customs_record']
        if customs_evidence:
            base_score += min(30, len(customs_evidence) * 5)

        # 有行业信息 +10
        if company.industry:
            base_score += 10

        # 有规模信息 +10
        if company.company_size:
            base_score += 10

        company.credibility_score = min(100, base_score)

        # 采购可能性 = 海关证据权重高
        if customs_evidence:
            company.purchase_probability = min(100, 40 + len(customs_evidence) * 8)
        else:
            company.purchase_probability = min(100, base_score * 0.6)

    def _persist_to_db(self, company: CompanyProfile):
        """持久化到数据库"""
        db = SessionLocal()
        try:
            # 检查是否已存在
            existing = db.query(TradeCompany).filter(
                TradeCompany.name_norm == company.name_norm
            ).first()

            if existing:
                # 更新现有记录
                existing.website = company.website or existing.website
                existing.industry = company.industry or existing.industry
                existing.main_products = company.main_products or existing.main_products
                existing.company_size = company.company_size or existing.company_size
                existing.credibility_score = max(existing.credibility_score, company.credibility_score)
                existing.purchase_probability = max(existing.purchase_probability, company.purchase_probability)
                existing.updated_at = datetime.now()
            else:
                # 创建新记录
                db_company = TradeCompany(
                    name=company.name,
                    name_norm=company.name_norm,
                    country=company.country,
                    website=company.website,
                    industry=company.industry,
                    main_products=company.main_products,
                    company_size=company.company_size,
                    credibility_score=company.credibility_score,
                    purchase_probability=company.purchase_probability,
                    evidence=company.evidence,
                    source=company.source,
                )
                db.add(db_company)
                db.commit()
                db.refresh(db_company)

                # 保存联系人
                for contact_data in company.contacts:
                    contact = ContactInfo(**contact_data)
                    db_contact = TradeContact(
                        company_id=db_company.entity_id,
                        name=contact.name,
                        title=contact.title,
                        email=contact.email,
                        phone=contact.phone,
                        is_decision_maker=contact.is_decision_maker,
                        confidence=contact.confidence,
                        source=contact.source,
                    )
                    db.add(db_contact)

            db.commit()
        finally:
            db.close()

from datetime import datetime
