# -*- coding: utf-8 -*-
"""WebUI - 外贸业务界面

展示内容：
- 市场分析
- 客户池
- 企业画像
- 开发任务
- 商业机会
- 供应链关系
- 智能报告

禁止展示：Node1, Node2, Runtime, Queue
"""
from flask import Flask, render_template, request, jsonify
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.models import init_database, SessionLocal, get_db
from database.models import TradeCompany, TradeCustomerPool, TradeTask, TradeOpportunity, TradeRelationship
from business.customer_pool.pool_manager import CustomerPoolManager
from business.trade_graph.graph_builder import TradeGraphBuilder
from business.analysis.analyzer import TradeAnalyzer
from psv_platform.recovery.recovery_service import RecoveryService


def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    init_database()

    @app.route("/")
    def dashboard():
        db = SessionLocal()
        stats = {
            "total_companies": db.query(TradeCompany).count(),
            "total_pool": db.query(TradeCustomerPool).count(),
            "active_tasks": db.query(TradeTask).filter(TradeTask.status == "running").count(),
            "completed_tasks": db.query(TradeTask).filter(TradeTask.status == "completed").count(),
            "total_opportunities": db.query(TradeOpportunity).count(),
            "s_tier_customers": db.query(TradeCustomerPool).join(TradeCompany).filter(
                TradeCompany.customer_tier == "S"
            ).count(),
        }
        db.close()
        return render_template("dashboard.html", stats=stats)

    @app.route("/customer_pool")
    def customer_pool_page():
        return render_template("customer_pool.html")

    @app.route("/tasks")
    def tasks_page():
        return render_template("tasks.html")

    @app.route("/trade_graph")
    def trade_graph_page():
        return render_template("trade_graph.html")

    @app.route("/reports")
    def reports_page():
        return render_template("reports.html")

    # API端点
    @app.route("/api/customer_pool")
    def api_customer_pool():
        manager = CustomerPoolManager()
        tier = request.args.get("tier")
        status = request.args.get("status")
        min_priority = int(request.args.get("min_priority", 0))
        limit = int(request.args.get("limit", 100))
        data = manager.get_pool(tier=tier, status=status, min_priority=min_priority, limit=limit)
        return jsonify(data)

    @app.route("/api/trade_graph/<entity_id>")
    def api_trade_graph(entity_id):
        depth = int(request.args.get("depth", 2))
        builder = TradeGraphBuilder()
        data = builder.build_supply_chain(entity_id, depth=depth)
        return jsonify(data)

    @app.route("/api/network_stats")
    def api_network_stats():
        builder = TradeGraphBuilder()
        return jsonify(builder.get_network_stats())

    @app.route("/api/tasks")
    def api_tasks():
        db = SessionLocal()
        tasks = db.query(TradeTask).order_by(TradeTask.created_at.desc()).limit(20).all()
        db.close()
        return jsonify([{
            "task_id": t.task_id,
            "objective": t.objective,
            "product": t.product,
            "market": t.market,
            "status": t.status,
            "progress": t.progress_pct,
            "current_node": t.current_node,
            "created_at": t.created_at.isoformat() if t.created_at else None,
        } for t in tasks])

    @app.route("/api/company/<entity_id>")
    def api_company_detail(entity_id):
        db = SessionLocal()
        company = db.query(TradeCompany).filter(TradeCompany.entity_id == entity_id).first()
        if not company:
            db.close()
            return jsonify({"error": "Company not found"}), 404

        result = {
            "entity_id": company.entity_id,
            "name": company.name,
            "country": company.country,
            "website": company.website,
            "industry": company.industry,
            "main_products": company.main_products,
            "company_size": company.company_size,
            "supply_chain_role": company.supply_chain_role,
            "credibility_score": company.credibility_score,
            "purchase_probability": company.purchase_probability,
            "match_score": company.match_score,
            "deal_probability": company.deal_probability,
            "customer_tier": company.customer_tier,
            "development_stage": company.development_stage,
            "evidence": company.evidence,
            "created_at": company.created_at.isoformat() if company.created_at else None,
        }
        db.close()
        return jsonify(result)

    @app.route("/api/market_analysis/<market>/<product>")
    def api_market_analysis(market, product):
        analyzer = TradeAnalyzer()
        analysis = analyzer.analyze_market(market, product)
        return jsonify(analysis.dict())

    @app.route("/api/recoverable_tasks")
    def api_recoverable_tasks():
        recovery = RecoveryService()
        return jsonify(recovery.list_recoverable_tasks())

    @app.route("/api/pool_stats")
    def api_pool_stats():
        manager = CustomerPoolManager()
        return jsonify(manager.get_pool_stats())

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5000)
