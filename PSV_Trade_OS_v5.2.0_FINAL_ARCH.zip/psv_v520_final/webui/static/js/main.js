// PSV Trade Intelligence OS - Frontend JS
document.addEventListener('DOMContentLoaded', function() {
    loadCustomerPool();
    loadTasks();
    loadNetworkStats();
});

function loadCustomerPool(tier) {
    const url = tier ? `/api/customer_pool?tier=${tier}` : '/api/customer_pool';
    fetch(url).then(r => r.json()).then(data => {
        let html = '<table><thead><tr><th>企业</th><th>国家</th><th>等级</th><th>客户价值</th><th>匹配度</th><th>成交概率</th><th>优先级</th><th>状态</th><th>下一步</th></tr></thead><tbody>';
        data.forEach(item => {
            html += `<tr>
                <td><strong>${escapeHtml(item.name)}</strong></td>
                <td>${escapeHtml(item.country || '-')}</td>
                <td><span class="tier-${item.tier}">${item.tier}</span></td>
                <td>${item.customer_value.toFixed(1)}</td>
                <td>${item.match_score.toFixed(1)}</td>
                <td>${item.deal_probability.toFixed(1)}%</td>
                <td>${item.priority}</td>
                <td><span class="status-badge status-${item.status}">${item.status}</span></td>
                <td>${escapeHtml(item.next_action || '-')}</td>
            </tr>`;
        });
        html += '</tbody></table>';
        const el = document.getElementById('customer-pool');
        if (el) el.innerHTML = html;
    });
}

function loadTasks() {
    fetch('/api/tasks').then(r => r.json()).then(data => {
        let html = '<table><thead><tr><th>任务ID</th><th>目标</th><th>产品</th><th>市场</th><th>状态</th><th>进度</th><th>当前节点</th><th>创建时间</th></tr></thead><tbody>';
        data.forEach(t => {
            html += `<tr>
                <td><code>${t.task_id}</code></td>
                <td>${escapeHtml(t.objective)}</td>
                <td>${escapeHtml(t.product || '-')}</td>
                <td>${escapeHtml(t.market || '-')}</td>
                <td><span class="status-badge status-${t.status}">${t.status}</span></td>
                <td><div class="progress-bar"><div class="progress-fill" style="width:${t.progress}%"></div></div> ${t.progress.toFixed(1)}%</td>
                <td>${escapeHtml(t.current_node || '-')}</td>
                <td>${formatDate(t.created_at)}</td>
            </tr>`;
        });
        html += '</tbody></table>';
        const el = document.getElementById('recent-tasks');
        if (el) el.innerHTML = html;
    });
}

function loadNetworkStats() {
    fetch('/api/network_stats').then(r => r.json()).then(data => {
        const el = document.getElementById('network-stats');
        if (el) {
            el.innerHTML = `
                <div class="stats-grid">
                    <div class="stat-card"><div class="stat-value">${data.total_nodes}</div><div class="stat-label">图谱节点</div></div>
                    <div class="stat-card"><div class="stat-value">${data.total_edges}</div><div class="stat-label">关系边</div></div>
                    <div class="stat-card"><div class="stat-value">${(data.network_density * 100).toFixed(2)}%</div><div class="stat-label">网络密度</div></div>
                </div>
            `;
        }
    });
}

function escapeHtml(text) {
    if (!text) return '-';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(iso) {
    if (!iso) return '-';
    const d = new Date(iso);
    return d.toLocaleString('zh-CN');
}
