# -*- coding: utf-8 -*-
"""PSV Trade Intelligence OS - 统一入口

用法：
  python -m app.main --init-db                    # 初始化数据库
  python -m app.main --objective "xxx" --product "yyy" --market USA   # 运行任务
  python -m app.main --resume <task_id>           # 恢复任务
  python -m app.main --webui                      # 启动Web界面
"""
import os
import sys
import argparse
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.models import init_database
from orchestrator.graph import TradeOrchestrator
from contracts.task_contract import TaskContract
from psv_platform.recovery.recovery_service import RecoveryService


def main():
    parser = argparse.ArgumentParser(description="PSV Trade Intelligence OS v5.0.0")
    parser.add_argument("--init-db", action="store_true", help="初始化数据库")
    parser.add_argument("--objective", type=str, help="外贸目标，如'开发美国生日蜡烛进口商'")
    parser.add_argument("--product", type=str, help="产品名称")
    parser.add_argument("--market", type=str, default="USA", help="目标市场")
    parser.add_argument("--target-customer", type=str, default="importer", help="目标客户类型")
    parser.add_argument("--max-results", type=int, default=50, help="最大结果数")
    parser.add_argument("--resume", type=str, help="恢复任务ID")
    parser.add_argument("--webui", action="store_true", help="启动Web界面")
    parser.add_argument("--list-recoverable", action="store_true", help="列出可恢复任务")

    args = parser.parse_args()

    if args.init_db:
        print("🗄️  初始化数据库...")
        init_database()
        print("✅ 数据库初始化完成")
        return

    if args.webui:
        print("🌐 启动Web界面...")
        from webui.app import create_app
        app = create_app()
        app.run(host="0.0.0.0", port=5000, debug=True)
        return

    if args.list_recoverable:
        recovery = RecoveryService()
        tasks = recovery.list_recoverable_tasks()
        print(f"\n📋 可恢复任务 ({len(tasks)}个):")
        for t in tasks:
            print(f"  {t['task_id']} | {t['objective'][:40]}... | {t['current_node']} | {t['progress_pct']:.1f}%")
        return

    if args.resume:
        recovery = RecoveryService()
        result = recovery.resume_task(args.resume)
        if result and result.get("can_resume"):
            print(f"🔄 恢复任务 {args.resume}，从 {result['next_node']} 继续...")
            # 重建工作流状态并继续
            orchestrator = TradeOrchestrator()
            # 这里需要实现从检查点恢复并继续执行的逻辑
            print("⚠️ 恢复执行功能需要进一步实现状态重建")
        else:
            print(f"❌ 任务 {args.resume} 无法恢复")
        return

    if not args.objective or not args.product:
        print("❌ 请提供 --objective 和 --product 参数")
        parser.print_help()
        return

    # 初始化
    init_database()

    # 创建任务
    task = TaskContract(
        objective=args.objective,
        product=args.product,
        market=args.market,
        target_customer=args.target_customer,
        constraints={"max_results": args.max_results}
    )

    print(f"\n{'='*60}")
    print(f"🚀 PSV Trade Intelligence OS v5.0.0")
    print(f"{'='*60}")
    print(f"目标: {args.objective}")
    print(f"产品: {args.product}")
    print(f"市场: {args.market}")
    print(f"客户类型: {args.target_customer}")
    print(f"{'='*60}\n")

    # 运行编排器
    orchestrator = TradeOrchestrator()
    result = orchestrator.run(task=dict(task))

    print(f"\n{'='*60}")
    print("✅ 任务执行完成")
    print(f"{'='*60}")

    if result.get("final_report"):
        print("\n📋 执行报告摘要:")
        print(result["final_report"][:2000])
        print("\n[完整报告已保存到 reports/ 目录]")

    # 输出关键指标
    outputs = result.get("agent_outputs", [])
    print(f"\n📊 Agent执行结果:")
    for out in outputs:
        print(f"  • {out['agent_type']}: confidence={out['confidence']:.2f}, status={out['status']}")

    print(f"\n💾 所有数据已持久化到数据库")
    print(f"🔍 审计日志已记录，可通过审计系统追踪")


if __name__ == "__main__":
    main()
