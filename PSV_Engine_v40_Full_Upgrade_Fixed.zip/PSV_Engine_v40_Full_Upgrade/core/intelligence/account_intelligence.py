# -*- coding: utf-8 -*-
"""Account Intelligence Center v40
核心职责：把第一采集链发现的客户/供应商，加工为完整商业情报。
流程：贸易节点 → 信息补全 → AI验证 → 价值评分 → 开发资格判断 → 进入业务执行
"""

import json, time
from typing import Dict, List, Optional
from core.memory.db import DB
from core.intelligence.ai_router import ai_route
from core.intelligence import waterfall, contacts as contacts_mod

COMPLETENESS_FIELDS = {
    'company_info': ['name', 'website', 'address', 'country', 'company_type', 
                     'product_categories', 'brand_info', 'company_size'],
    'trade_info': ['product', 'hs_code', 'trade_direction', 'shipment_count',
                   'last_trade_at', 'current_suppliers', 'current_customers',
                   'trade_strength', 'evidence_source'],
    'contact_info': ['contact_name', 'title', 'email', 'phone', 'linkedin']
}

class AccountIntelligenceCenter:
    def __init__(self):
        self.db = DB()

    def process_lead(self, norm: str) -> dict:
        lead = self.db.get_lead(norm)
        if not lead:
            return {'ok': False, 'error': 'lead not found', 'norm': norm}

        enriched = self._enrich_account(norm, lead)
        completeness = self._calc_completeness(enriched)
        verification = self._ai_verify(norm, enriched, completeness)
        scoring = self._value_scoring(norm, enriched, verification)
        qualification = self._dev_qualification(norm, enriched, completeness, verification, scoring)

        intelligence = {
            'norm': norm,
            'name': enriched.get('name'),
            'website': enriched.get('website'),
            'address': enriched.get('address'),
            'country': enriched.get('country'),
            'company_type': enriched.get('company_type'),
            'product_categories': enriched.get('product_categories', []),
            'brand_info': enriched.get('brand_info', []),
            'company_size': enriched.get('company_size'),
            'contact_info': {
                'contacts': enriched.get('contacts', []),
                'primary_email': enriched.get('primary_email'),
                'primary_phone': enriched.get('primary_phone')
            },
            'trades': enriched.get('trades', []),
            'info_completeness': completeness['score'],
            'info_completeness_detail': completeness['detail'],
            'ai_verified': verification.get('passed', False),
            'ai_verification_result': verification,
            'value_score': scoring['total_score'],
            'value_grade': scoring['grade'],
            'dev_qualified': qualification['qualified'],
            'dev_qualification_reason': qualification['reason']
        }

        self.db.save_account_intelligence(norm, intelligence)

        for trade in enriched.get('trades', []):
            self.db.save_trade_intelligence(norm, trade)

        for contact in enriched.get('contacts', []):
            self.db.save_contact_intelligence(norm, contact)

        return {
            'ok': True,
            'intelligence': intelligence,
            'completeness': completeness,
            'verification': verification,
            'scoring': scoring,
            'qualification': qualification,
            'note': f"情报中心处理完成：完整度{completeness['score']}%，价值评分{scoring['grade']}，开发资格{'通过' if qualification['qualified'] else '未通过'}"
        }

    def _enrich_account(self, norm: str, lead: dict) -> dict:
        wf_result = waterfall.enrich_lead(norm)
        trade_history = self._get_trade_history(norm, lead)
        contact_result = contacts_mod.find_contacts(norm)

        enriched = dict(lead)
        enriched.update(wf_result.get('filled', {}))
        enriched['trades'] = trade_history.get('trades', [])
        enriched['contacts'] = contact_result.get('contacts', [])
        enriched['primary_email'] = (contact_result.get('recommended') or {}).get('email')
        enriched['primary_phone'] = (contact_result.get('recommended') or {}).get('phone')
        enriched['contact_person'] = contact_result.get('contact_person')

        if not enriched.get('company_type') or not enriched.get('company_size'):
            web_info = self._web_enrich(norm, enriched.get('name'), enriched.get('website'))
            if web_info:
                for k in ['company_type', 'company_size', 'product_categories', 'brand_info']:
                    if not enriched.get(k) and web_info.get(k):
                        enriched[k] = web_info[k]

        return enriched

    def _get_trade_history(self, norm: str, lead: dict) -> dict:
        from core.runtime.development import _trade_history as dev_trade_history
        trade = dev_trade_history(self.db, lead)

        trades = []
        if trade.get('shipments', 0) > 0:
            trades.append({
                'product': lead.get('industry') or lead.get('category') or 'unknown',
                'hs_code': lead.get('hs_code', ''),
                'trade_direction': 'import' if lead.get('kind') == 'customer' else 'export',
                'shipment_count': trade.get('shipments', 0),
                'last_trade_at': trade.get('last_seen'),
                'current_suppliers': trade.get('supplier_names', []),
                'current_customers': [],
                'trade_strength': min(100, trade.get('shipments', 0) * 2),
                'evidence_source': trade.get('source', 'lead_summary')
            })
        return {'trades': trades}

    def _web_enrich(self, norm: str, name: str, website: str) -> Optional[dict]:
        if not name:
            return None
        prompt = f"""根据以下企业信息，推断并补全企业档案：
企业名称：{name}
官网：{website or '未知'}
国家：{norm.split('_')[-1] if '_' in norm else '未知'}

请输出JSON格式：
{{
  "company_type": "制造商/贸易商/零售商/其他",
  "company_size": "大型/中型/小型/微型",
  "product_categories": ["产品类别1", "产品类别2"],
  "brand_info": ["品牌1", "品牌2"],
  "confidence": "Strong/Moderate/Weak",
  "reasoning": "推理过程"
}}

如果信息不足，请明确说明，不要猜测。"""

        result = ai_route(
            prompt=prompt,
            system="你是企业情报分析师，只基于已有信息进行推断，不确定时明确标注。",
            schema={
                "type": "object",
                "required": ["company_type", "company_size", "product_categories", "brand_info"],
                "properties": {
                    "company_type": {"type": "string"},
                    "company_size": {"type": "string"},
                    "product_categories": {"type": "array", "items": {"type": "string"}},
                    "brand_info": {"type": "array", "items": {"type": "string"}},
                    "confidence": {"type": "string"},
                    "reasoning": {"type": "string"}
                }
            }
        )

        if result['ok'] and result['structured']:
            return result['structured']
        return None

    def _calc_completeness(self, enriched: dict) -> dict:
        detail = {}
        total_fields = 0
        filled_fields = 0

        for category, fields in COMPLETENESS_FIELDS.items():
            cat_total = len(fields)
            cat_filled = 0
            cat_detail = {}

            for field in fields:
                total_fields += 1
                val = enriched.get(field)
                has_value = False
                if val is not None and val != '' and val != [] and val != {}:
                    if isinstance(val, list) and len(val) == 0:
                        has_value = False
                    elif isinstance(val, dict) and len(val) == 0:
                        has_value = False
                    else:
                        has_value = True

                if has_value:
                    cat_filled += 1
                    filled_fields += 1
                    cat_detail[field] = True
                else:
                    cat_detail[field] = False

            detail[category] = {
                'score': round(cat_filled / cat_total * 100, 1) if cat_total > 0 else 0,
                'filled': cat_filled,
                'total': cat_total,
                'fields': cat_detail
            }

        overall_score = round(filled_fields / total_fields * 100, 1) if total_fields > 0 else 0

        return {
            'score': overall_score,
            'filled': filled_fields,
            'total': total_fields,
            'detail': detail,
            'missing': [f for f in detail.get('contact_info', {}).get('fields', {}) 
                       if not detail['contact_info']['fields'][f]] if 'contact_info' in detail else []
        }

    def _ai_verify(self, norm: str, enriched: dict, completeness: dict) -> dict:
        trade = enriched.get('trades', [{}])[0] if enriched.get('trades') else {}

        prompt = f"""请验证以下企业的真实性和贸易活跃度：

企业名称：{enriched.get('name', '未知')}
国家：{enriched.get('country', '未知')}
官网：{enriched.get('website', '无')}
贸易记录数：{trade.get('shipment_count', 0)}
最近交易：{trade.get('last_trade_at', '无')}
供应商数量：{len(trade.get('current_suppliers', []))}
信息完整度：{completeness['score']}%

请判断：
1. 该企业是否真实存在？
2. 是否有真实贸易记录？
3. 产品是否匹配？
4. 最近是否有采购行为？

输出JSON：
{{
  "is_real": true/false,
  "has_trade_evidence": true/false,
  "product_match": true/false,
  "recent_activity": true/false,
  "confidence": "Strong/Moderate/Weak",
  "reasoning": "详细推理"
}}"""

        result = ai_route(
            prompt=prompt,
            system="你是企业验证专家，必须基于证据判断，不能猜测。",
            schema={
                "type": "object",
                "required": ["is_real", "has_trade_evidence", "product_match", "recent_activity", "confidence"],
                "properties": {
                    "is_real": {"type": "boolean"},
                    "has_trade_evidence": {"type": "boolean"},
                    "product_match": {"type": "boolean"},
                    "recent_activity": {"type": "boolean"},
                    "confidence": {"type": "string"},
                    "reasoning": {"type": "string"}
                }
            }
        )

        if not result['ok']:
            return {
                'passed': False,
                'confidence': 'Weak',
                'reasoning': result.get('error', 'AI验证失败'),
                'natural_language': ''
            }

        structured = result['structured'] or {}
        passed = (
            structured.get('is_real', False) and 
            structured.get('has_trade_evidence', False) and
            structured.get('product_match', False)
        )

        return {
            'passed': passed,
            'confidence': structured.get('confidence', result['confidence']),
            'reasoning': structured.get('reasoning', result['natural_language']),
            'natural_language': result['natural_language'],
            'details': structured
        }

    def _value_scoring(self, norm: str, enriched: dict, verification: dict) -> dict:
        score = 0.0
        reasons = []
        evidence = []

        if verification.get('passed'):
            score += 20
            reasons.append('AI验证通过：企业真实存在且有贸易证据')
            evidence.append('ai_verification')

        trade = enriched.get('trades', [{}])[0] if enriched.get('trades') else {}
        shipments = trade.get('shipment_count', 0)
        if shipments > 50:
            score += 25; reasons.append(f'高度活跃：{shipments}票贸易记录')
        elif shipments > 20:
            score += 20; reasons.append(f'活跃：{shipments}票贸易记录')
        elif shipments > 5:
            score += 10; reasons.append(f'有贸易：{shipments}票记录')
        else:
            score += 5; reasons.append(f'少量贸易：{shipments}票')
        evidence.append('trade_volume')

        days = None
        last_seen = trade.get('last_trade_at')
        if last_seen:
            try:
                from datetime import datetime, date
                days = (date.today() - datetime.strptime(str(last_seen)[:10], '%Y-%m-%d').date()).days
                if days <= 45:
                    score += 25; reasons.append('最近45天内有交易')
                elif days <= 120:
                    score += 20; reasons.append('最近120天内有交易')
                elif days <= 240:
                    score += 10; reasons.append('最近240天内有交易')
                else:
                    score += 5; reasons.append('超过240天无交易')
                evidence.append('recency')
            except:
                pass

        suppliers = trade.get('current_suppliers', [])
        if len(suppliers) >= 5:
            score += 15; reasons.append(f'供应商来源多样({len(suppliers)}个)，存在替代空间')
        elif len(suppliers) >= 2:
            score += 10; reasons.append(f'多个供应商({len(suppliers)}个)')
        evidence.append('supplier_diversity')

        completeness_score = enriched.get('info_completeness', 0)
        if completeness_score >= 80:
            score += 15; reasons.append('信息完整度高，便于精准开发')
        elif completeness_score >= 50:
            score += 8; reasons.append('信息完整度中等')
        evidence.append('completeness')

        contacts = enriched.get('contacts', [])
        verified_emails = [c for c in contacts if c.get('email_verified')]
        if len(verified_emails) > 0:
            score += 10; reasons.append(f'有验证通过的联系人邮箱')
            evidence.append('verified_contacts')

        grade = 'D'
        if score >= 85: grade = 'A'
        elif score >= 70: grade = 'B'
        elif score >= 50: grade = 'C'

        return {
            'total_score': round(score, 1),
            'grade': grade,
            'reasons': reasons,
            'evidence': evidence,
            'breakdown': {
                'verification': 20 if verification.get('passed') else 0,
                'trade_volume': min(25, shipments),
                'recency': 25 if days and days <= 45 else (20 if days and days <= 120 else (10 if days and days <= 240 else 5)),
                'supplier_diversity': 15 if len(suppliers) >= 5 else (10 if len(suppliers) >= 2 else 0),
                'completeness': 15 if completeness_score >= 80 else (8 if completeness_score >= 50 else 0),
                'contacts': 10 if len(verified_emails) > 0 else 0
            }
        }

    def _dev_qualification(self, norm: str, enriched: dict, completeness: dict,
                           verification: dict, scoring: dict) -> dict:
        reasons = []
        qualified = True

        if not verification.get('passed'):
            qualified = False
            reasons.append('AI验证未通过：企业真实性存疑')

        trade = enriched.get('trades', [{}])[0] if enriched.get('trades') else {}
        if trade.get('shipment_count', 0) == 0:
            qualified = False
            reasons.append('无贸易记录')

        if completeness['score'] < 50:
            qualified = False
            reasons.append(f"信息完整度不足：{completeness['score']}% < 50%")

        contacts = enriched.get('contacts', [])
        verified_emails = [c for c in contacts if c.get('email_verified')]
        if len(verified_emails) == 0:
            if scoring['grade'] in ('A', 'B'):
                reasons.append('联系人待补全，但价值评分高，可优先补全')
            else:
                qualified = False
                reasons.append('无验证通过的联系人邮箱')

        if scoring['grade'] == 'D':
            qualified = False
            reasons.append('价值评分过低(D级)')

        if qualified and not reasons:
            reasons.append('满足所有开发资格门槛')

        new_status = 'dev_ready' if qualified else 'pending_enrichment'
        self.db.lead_update(norm, status=new_status, score=scoring['total_score'], grade=scoring['grade'])

        return {
            'qualified': qualified,
            'status': new_status,
            'reason': '；'.join(reasons),
            'thresholds': {
                'ai_verified': verification.get('passed'),
                'has_trade': trade.get('shipment_count', 0) > 0,
                'min_completeness': completeness['score'] >= 50,
                'has_verified_contact': len(verified_emails) > 0,
                'min_grade': scoring['grade'] != 'D'
            }
        }

    def get_intelligence(self, norm: str) -> Optional[dict]:
        return self.db.get_account_intelligence(norm)

    def list_intelligences(self, **kwargs) -> List[dict]:
        return self.db.list_account_intelligence(**kwargs)

    def batch_process(self, norms: List[str]) -> List[dict]:
        results = []
        for norm in norms:
            results.append(self.process_lead(norm))
        return results


_center = None

def get_center() -> AccountIntelligenceCenter:
    global _center
    if _center is None:
        _center = AccountIntelligenceCenter()
    return _center

def process(norm: str) -> dict:
    return get_center().process_lead(norm)

def get(norm: str) -> Optional[dict]:
    return get_center().get_intelligence(norm)

def list_all(**kwargs) -> List[dict]:
    return get_center().list_intelligences(**kwargs)
