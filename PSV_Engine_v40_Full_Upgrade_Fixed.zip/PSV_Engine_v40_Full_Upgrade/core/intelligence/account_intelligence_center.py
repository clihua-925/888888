# -*- coding: utf-8 -*-
"""ACCOUNT_INTELLIGENCE_CENTER v41：客户情报中心（后半段核心入口）。

职责：把第一采集链发现的客户/供应商，加工为完整商业情报资产。
禁止：重复第一采集链的采集逻辑；禁止修改采集流程。
"""
import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from core.memory.db import DB
from core.intelligence import ai_gateway, icp, contacts, waterfall
from core.tools import expand

# ========== 数据契约 ==========

@dataclass
class EnterpriseInfo:
    name: str = ""
    website: str = ""
    address: str = ""
    country: str = ""
    enterprise_type: str = ""      # 制造商/贸易商/批发商/零售商
    product_category: str = ""
    brand_info: str = ""
    enterprise_scale: str = ""     # 员工数/营收规模
    contact_methods: Dict[str, str] = None  # phone, fax, etc

    def __post_init__(self):
        if self.contact_methods is None:
            self.contact_methods = {}

@dataclass
class TradeInfo:
    products: List[str] = None
    hs_codes: List[str] = None
    import_records: int = 0
    export_records: int = 0
    transaction_count: int = 0
    last_transaction_date: str = ""
    current_suppliers: List[str] = None
    current_customers: List[str] = None
    trade_intensity: str = ""      # high/medium/low
    evidence_source: str = ""

    def __post_init__(self):
        if self.products is None: self.products = []
        if self.hs_codes is None: self.hs_codes = []
        if self.current_suppliers is None: self.current_suppliers = []
        if self.current_customers is None: self.current_customers = []

@dataclass
class ContactPerson:
    name: str = ""
    title: str = ""
    email: str = ""
    phone: str = ""
    linkedin: str = ""
    is_verified: bool = False
    email_verified: bool = False
    confidence: str = "low"        # high/medium/low

@dataclass
class AccountProfile:
    norm: str = ""
    enterprise: EnterpriseInfo = None
    trade: TradeInfo = None
    contacts: List[ContactPerson] = None
    completeness_score: float = 0.0
    info_status: Dict[str, Any] = None
    icp_score: Dict[str, Any] = None
    development_eligible: bool = False
    development_blockers: List[str] = None
    trade_network: Dict[str, Any] = None
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        if self.enterprise is None: self.enterprise = EnterpriseInfo()
        if self.trade is None: self.trade = TradeInfo()
        if self.contacts is None: self.contacts = []
        if self.info_status is None: self.info_status = {}
        if self.icp_score is None: self.icp_score = {}
        if self.development_blockers is None: self.development_blockers = []
        if self.trade_network is None: self.trade_network = {}


# ========== 字段定义与权重 ==========

FIELD_DEFINITIONS = {
    # 企业信息 (权重 35%)
    'name':           {'category': 'enterprise', 'weight': 0.05, 'label': '公司名称'},
    'website':        {'category': 'enterprise', 'weight': 0.05, 'label': '官网'},
    'address':        {'category': 'enterprise', 'weight': 0.03, 'label': '地址'},
    'country':        {'category': 'enterprise', 'weight': 0.03, 'label': '国家地区'},
    'enterprise_type':{'category': 'enterprise', 'weight': 0.03, 'label': '企业类型'},
    'product_category':{'category': 'enterprise', 'weight': 0.03, 'label': '产品类别'},
    'brand_info':     {'category': 'enterprise', 'weight': 0.03, 'label': '品牌信息'},
    'enterprise_scale':{'category': 'enterprise', 'weight': 0.03, 'label': '企业规模'},
    'contact_methods':{'category': 'enterprise', 'weight': 0.03, 'label': '联系方式'},
    # 贸易信息 (权重 35%)
    'products':       {'category': 'trade', 'weight': 0.05, 'label': '产品'},
    'hs_codes':       {'category': 'trade', 'weight': 0.04, 'label': 'HS编码'},
    'import_records': {'category': 'trade', 'weight': 0.04, 'label': '进口记录'},
    'export_records': {'category': 'trade', 'weight': 0.04, 'label': '出口记录'},
    'transaction_count':{'category': 'trade', 'weight': 0.04, 'label': '交易次数'},
    'last_transaction_date':{'category': 'trade', 'weight': 0.04, 'label': '最近交易'},
    'current_suppliers':{'category': 'trade', 'weight': 0.03, 'label': '当前供应商'},
    'current_customers':{'category': 'trade', 'weight': 0.03, 'label': '当前客户'},
    'trade_intensity':{'category': 'trade', 'weight': 0.02, 'label': '贸易强度'},
    'evidence_source':{'category': 'trade', 'weight': 0.02, 'label': '证据来源'},
    # 联系人信息 (权重 30%)
    'contact_name':   {'category': 'contact', 'weight': 0.06, 'label': '联系人'},
    'contact_title':  {'category': 'contact', 'weight': 0.04, 'label': '职位'},
    'contact_email':  {'category': 'contact', 'weight': 0.08, 'label': '邮箱'},
    'contact_phone':  {'category': 'contact', 'weight': 0.04, 'label': '电话'},
    'contact_linkedin':{'category': 'contact', 'weight': 0.04, 'label': 'LinkedIn'},
    'email_verified': {'category': 'contact', 'weight': 0.04, 'label': '邮箱验证'},
}

# 开发资格门槛
DEVELOPMENT_THRESHOLD = {
    'min_completeness': 0.60,
    'require_trade_evidence': True,
    'require_contact': True,
    'require_email_verified': True,
    'min_icp_tier': 'C',   # A/B/C 可开发，D不可
}


# ========== 核心引擎 ==========

class AccountIntelligenceCenter:
    """客户情报中心：单一入口，禁止外部直接操作 leads 表做情报聚合。"""

    def __init__(self):
        self.db = DB()

    # ---------- 1. 档案构建 ----------

    def build_profile(self, norm: str) -> AccountProfile:
        """从数据库所有事实源构建完整档案。"""
        lead = self.db.get_lead(norm) or {}
        rels = self.db.list_relationships(norm=norm, limit=200)
        events = self.db.list_evidence_events(norm, limit=100)
        db_contacts = self.db.list_contacts(norm)
        enrichment = self.db.list_enrichment_events(norm, limit=50)
        customs_raw = self._fetch_customs_raw(norm)

        profile = AccountProfile(norm=norm)

        # --- 企业信息补全 ---
        profile.enterprise = EnterpriseInfo(
            name=lead.get('name') or '',
            website=lead.get('website') or '',
            address=lead.get('address') or '',
            country=lead.get('country') or '',
            enterprise_type=lead.get('enterprise_type') or lead.get('segment') or '',
            product_category=lead.get('category') or '',
            brand_info=lead.get('brand_info') or '',
            enterprise_scale=lead.get('enterprise_scale') or '',
            contact_methods={'phone': lead.get('phones') or '', 'fax': lead.get('fax') or ''}
        )

        # --- 贸易信息补全 ---
        profile.trade = self._build_trade_info(lead, rels, customs_raw)

        # --- 联系人信息补全 ---
        profile.contacts = self._build_contacts(db_contacts, enrichment)

        # --- ICP 评分 ---
        profile.icp_score = self._compute_icp(lead, rels, profile.contacts)

        # --- 完整度评分 ---
        profile.completeness_score, profile.info_status = self._compute_completeness(profile)

        # --- 开发资格判断 ---
        profile.development_eligible, profile.development_blockers = self._check_development_eligible(profile)

        # --- 贸易网络快照 ---
        profile.trade_network = self._build_trade_network_snapshot(norm, rels)

        return profile

    def _fetch_customs_raw(self, norm: str) -> List[Dict]:
        try:
            with self.db.c() as c:
                c.row_factory = __import__('sqlite3').Row
                rows = c.execute(
                    'SELECT ts, shipper, hs, descr, qty, weight, teu, origin, port_load, port_discharge '
                    'FROM customs_raw WHERE importer_norm=? ORDER BY ts DESC LIMIT 500',
                    (norm,)
                ).fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []

    def _build_trade_info(self, lead, rels, customs_raw) -> TradeInfo:
        ti = TradeInfo()
        ti.products = list(set(filter(None, [
            lead.get('category'), lead.get('product'), lead.get('desc_sample')
        ])))
        ti.hs_codes = list(set(filter(None, [
            lead.get('hs_code'), lead.get('hs')
        ])))

        # 从海关原始记录统计
        shippers = set()
        for r in customs_raw:
            if r.get('shipper'):
                shippers.add(str(r['shipper']).strip())
            if r.get('hs') and r['hs'] not in ti.hs_codes:
                ti.hs_codes.append(r['hs'])
            if r.get('descr') and r['descr'] not in ti.products:
                ti.products.append(r['descr'][:80])

        ti.import_records = int(lead.get('shipments') or 0)
        ti.transaction_count = len(customs_raw) if customs_raw else ti.import_records
        ti.last_transaction_date = str(lead.get('last_shipment') or '')
        ti.current_suppliers = list(shippers)[:20]
        ti.trade_intensity = self._classify_trade_intensity(ti.import_records, ti.last_transaction_date)
        ti.evidence_source = lead.get('source') or 'customs'

        # 从关系表找客户
        customers = []
        for r in rels:
            if str(r.get('relation','')).lower() in ('customer', 'buyer', 'importer'):
                name = r.get('from_name') if r.get('to_norm') == lead.get('norm') else r.get('to_name')
                if name: customers.append(name)
        ti.current_customers = list(set(customers))[:20]

        return ti

    def _classify_trade_intensity(self, shipments: int, last_date: str) -> str:
        if shipments >= 50: return 'high'
        if shipments >= 10: return 'medium'
        return 'low'

    def _build_contacts(self, db_contacts, enrichment) -> List[ContactPerson]:
        result = []
        for c in db_contacts:
            cp = ContactPerson(
                name=c.get('name') or c.get('contact_person') or '',
                title=c.get('title') or '',
                email=c.get('email') or '',
                phone=c.get('phone') or '',
                linkedin=c.get('linkedin') or '',
                is_verified=bool(c.get('verified')),
                email_verified=bool(c.get('email_verified') or c.get('mx_ok')),
                confidence=c.get('confidence') or 'low'
            )
            result.append(cp)
        return result

    # ---------- 2. 完整度评分 ----------

    def _compute_completeness(self, profile: AccountProfile) -> (float, Dict):
        status = {'completed': [], 'missing': []}
        score = 0.0

        # 企业信息检查
        e = profile.enterprise
        enterprise_fields = {
            'name': e.name, 'website': e.website, 'address': e.address,
            'country': e.country, 'enterprise_type': e.enterprise_type,
            'product_category': e.product_category, 'brand_info': e.brand_info,
            'enterprise_scale': e.enterprise_scale, 'contact_methods': e.contact_methods.get('phone')
        }
        for field, value in enterprise_fields.items():
            meta = FIELD_DEFINITIONS.get(field)
            if meta:
                if value:
                    score += meta['weight']
                    status['completed'].append({'field': field, 'label': meta['label'], 'category': 'enterprise'})
                else:
                    status['missing'].append({'field': field, 'label': meta['label'], 'category': 'enterprise'})

        # 贸易信息检查
        t = profile.trade
        trade_fields = {
            'products': t.products, 'hs_codes': t.hs_codes,
            'import_records': t.import_records > 0,
            'transaction_count': t.transaction_count > 0,
            'last_transaction_date': t.last_transaction_date,
            'current_suppliers': t.current_suppliers,
            'current_customers': t.current_customers,
            'trade_intensity': t.trade_intensity,
            'evidence_source': t.evidence_source
        }
        for field, value in trade_fields.items():
            meta = FIELD_DEFINITIONS.get(field)
            if meta:
                if value:
                    score += meta['weight']
                    status['completed'].append({'field': field, 'label': meta['label'], 'category': 'trade'})
                else:
                    status['missing'].append({'field': field, 'label': meta['label'], 'category': 'trade'})

        # 联系人信息检查
        if profile.contacts:
            best = profile.contacts[0] if profile.contacts else ContactPerson()
            contact_fields = {
                'contact_name': best.name, 'contact_title': best.title,
                'contact_email': best.email, 'contact_phone': best.phone,
                'contact_linkedin': best.linkedin, 'email_verified': best.email_verified
            }
            for field, value in contact_fields.items():
                meta = FIELD_DEFINITIONS.get(field)
                if meta:
                    if value:
                        score += meta['weight']
                        status['completed'].append({'field': field, 'label': meta['label'], 'category': 'contact'})
                    else:
                        status['missing'].append({'field': field, 'label': meta['label'], 'category': 'contact'})
        else:
            for field in ['contact_name','contact_title','contact_email','contact_phone','contact_linkedin','email_verified']:
                meta = FIELD_DEFINITIONS.get(field)
                status['missing'].append({'field': field, 'label': meta['label'], 'category': 'contact'})

        return round(min(score, 1.0), 2), status

    # ---------- 3. ICP 评分 ----------

    def _compute_icp(self, lead, rels, contacts) -> Dict:
        if lead.get('icp_tier'):
            return {
                'score': lead.get('icp_score', 0),
                'tier': lead.get('icp_tier'),
                'reasons': json.loads(lead.get('icp_reasons') or '[]')
            }
        from core.intelligence import icp as icp_mod
        return icp_mod.score_lead(lead, rels, contacts)

    # ---------- 4. 开发资格判断 ----------

    def _check_development_eligible(self, profile: AccountProfile) -> (bool, List[str]):
        blockers = []
        th = DEVELOPMENT_THRESHOLD

        if profile.completeness_score < th['min_completeness']:
            blockers.append(f"信息完整度 {profile.completeness_score*100:.0f}% < 门槛 {th['min_completeness']*100:.0f}%")

        if th['require_trade_evidence']:
            if profile.trade.import_records == 0 and profile.trade.transaction_count == 0:
                blockers.append("无贸易证据")

        if th['require_contact']:
            if not profile.contacts:
                blockers.append("无联系人")

        if th['require_email_verified']:
            verified_emails = [c for c in profile.contacts if c.email_verified]
            if not verified_emails:
                blockers.append("无验证通过的邮箱")

        tier = str(profile.icp_score.get('tier') or 'D')
        if tier == 'D':
            blockers.append(f"ICP 评级为 D（{'; '.join(profile.icp_score.get('reasons') or ['证据不足'])}）")

        return len(blockers) == 0, blockers

    # ---------- 5. 贸易网络快照 ----------

    def _build_trade_network_snapshot(self, norm: str, rels: List[Dict]) -> Dict:
        suppliers = []
        customers = []
        related = []
        for r in rels:
            rel_type = str(r.get('relation','')).lower()
            if rel_type in ('supplier', 'shipper', 'vendor'):
                suppliers.append({
                    'name': r.get('from_name') or r.get('to_name'),
                    'confidence': r.get('confidence'),
                    'evidence': r.get('evidence')
                })
            elif rel_type in ('customer', 'buyer', 'importer'):
                customers.append({
                    'name': r.get('from_name') or r.get('to_name'),
                    'confidence': r.get('confidence'),
                    'evidence': r.get('evidence')
                })
            else:
                related.append({
                    'name': r.get('from_name') or r.get('to_name'),
                    'relation': rel_type,
                    'confidence': r.get('confidence')
                })
        return {
            'supplier_count': len(suppliers),
            'customer_count': len(customers),
            'related_count': len(related),
            'suppliers': suppliers[:20],
            'customers': customers[:20],
            'related': related[:20]
        }

    # ---------- 6. 信息补全入口 ----------

    def enrich(self, norm: str, target_fields: List[str] = None) -> Dict:
        """触发字段级 waterfall 补全。"""
        result = waterfall.enrich_lead(norm, target_fields=target_fields)
        # 补全后刷新档案
        profile = self.build_profile(norm)
        return {
            'ok': result.get('ok', False),
            'enrichment_result': result,
            'profile': self._profile_to_dict(profile),
            'message': f"补全完成，当前完整度 {profile.completeness_score*100:.0f}%"
        }

    # ---------- 7. 网络扩张入口 ----------

    def expand_network(self, norm: str, directions: List[str] = None) -> Dict:
        """从客户情报中心触发网络扩张，结果自动入库。"""
        if directions is None:
            directions = ['supplier_to_customer', 'customer_to_supplier', 'product', 'enterprise']

        profile = self.build_profile(norm)
        all_new_leads = []
        all_new_edges = []

        for direction in directions:
            result = expand.expand_from_lead(norm, direction=direction, profile=profile)
            new_leads = result.get('new_leads', [])
            new_edges = result.get('new_edges', [])
            all_new_leads.extend(new_leads)
            all_new_edges.extend(new_edges)

        # 去重并入库
        seen_norms = set()
        unique_leads = []
        for l in all_new_leads:
            n = l.get('norm')
            if n and n not in seen_norms:
                seen_norms.add(n)
                unique_leads.append(l)
                self.db.upsert_lead(l)

        for e in all_new_edges:
            self.db.upsert_relationship(e)

        # 同步更新贸易图谱
        self._sync_trade_graph(unique_leads, all_new_edges)

        return {
            'ok': True,
            'directions': directions,
            'new_leads_count': len(unique_leads),
            'new_edges_count': len(all_new_edges),
            'new_leads': unique_leads[:50],
            'profile': self._profile_to_dict(profile)
        }

    def _sync_trade_graph(self, leads, edges):
        """将扩张结果同步到贸易图谱数据层（只写关系，不做可视化）。"""
        try:
            with self.db.c() as c:
                for lead in leads:
                    c.execute('''
                        INSERT OR IGNORE INTO trade_graph_nodes (norm, name, type, source, created_at)
                        VALUES (?, ?, ?, ?, datetime('now'))
                    ''', (lead.get('norm'), lead.get('name'), lead.get('type', 'unknown'), lead.get('source', 'expansion')))
                for edge in edges:
                    c.execute('''
                        INSERT OR IGNORE INTO trade_graph_edges (from_norm, to_norm, relation, evidence, source, created_at)
                        VALUES (?, ?, ?, ?, ?, datetime('now'))
                    ''', (edge.get('from_norm'), edge.get('to_norm'), edge.get('relation'),
                          json.dumps(edge.get('evidence', {})), edge.get('source', 'expansion')))
        except Exception as e:
            pass  # 图谱同步失败不阻断主流程

    # ---------- 8. 工具方法 ----------

    def _profile_to_dict(self, profile: AccountProfile) -> Dict:
        return {
            'norm': profile.norm,
            'enterprise': asdict(profile.enterprise),
            'trade': asdict(profile.trade),
            'contacts': [asdict(c) for c in profile.contacts],
            'completeness_score': profile.completeness_score,
            'info_status': profile.info_status,
            'icp_score': profile.icp_score,
            'development_eligible': profile.development_eligible,
            'development_blockers': profile.development_blockers,
            'trade_network': profile.trade_network
        }

    def list_all_profiles(self, limit: int = 100, offset: int = 0, eligible_only: bool = False) -> List[Dict]:
        """列出所有客户档案（供 UI 调用）。"""
        leads = self.db.list_leads(limit=limit, offset=offset)
        profiles = []
        for lead in leads:
            norm = lead.get('norm')
            if not norm: continue
            p = self.build_profile(norm)
            if eligible_only and not p.development_eligible:
                continue
            profiles.append(self._profile_to_dict(p))
        return profiles

    def get_profile(self, norm: str) -> Dict:
        """获取单个客户完整档案。"""
        p = self.build_profile(norm)
        return self._profile_to_dict(p)


# ---------- 便捷函数 ----------
def get_account_profile(norm: str) -> Dict:
    return AccountIntelligenceCenter().get_profile(norm)

def enrich_account(norm: str, fields: List[str] = None) -> Dict:
    return AccountIntelligenceCenter().enrich(norm, target_fields=fields)

def expand_account_network(norm: str, directions: List[str] = None) -> Dict:
    return AccountIntelligenceCenter().expand_network(norm, directions=directions)