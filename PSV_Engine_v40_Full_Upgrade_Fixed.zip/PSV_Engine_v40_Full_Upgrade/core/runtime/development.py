# -*- coding: utf-8 -*-
"""BUSINESS_EXECUTION_CENTER v41：业务执行中心（后半段最终环节）。

入口条件（硬性门槛，缺一不可）：
1. 客户真实存在（通过审计）
2. 有贸易证据（shipments > 0 或 customs_raw 有记录）
3. 信息补全达到要求（完整度 >= 60%）
4. 联系人存在
5. 邮箱验证通过

流程：
客户情报中心 → 开发资格客户 → 联系人 → 邮箱验证 → AI生成开发信 → Outlook草稿 → 用户点击发送 → 记录状态

禁止：自动发送邮件。
"""
import json, time, re
from core.memory.db import DB
from core.intelligence import ai_gateway, contacts as contacts_mod
from core.tools import pitch, outlook_send
from core.intelligence.account_intelligence_center import AccountIntelligenceCenter, DEVELOPMENT_THRESHOLD

# 业务执行节点顺序
EXECUTION_ORDER = [
    'QUALIFY',           # 资格门槛检查
    'CONTACT_VERIFY',    # 联系人验证
    'EMAIL_VALIDATE',    # 邮箱验证
    'PITCH_GENERATE',    # AI生成开发信
    'OUTLOOK_DRAFT',     # 生成Outlook草稿
    'USER_SEND',         # 用户发送（人工门）
    'STATUS_RECORD'      # 状态记录
]

EXECUTION_LABELS = {
    'QUALIFY': '开发资格检查',
    'CONTACT_VERIFY': '联系人验证',
    'EMAIL_VALIDATE': '邮箱验证',
    'PITCH_GENERATE': 'AI生成开发信',
    'OUTLOOK_DRAFT': 'Outlook草稿生成',
    'USER_SEND': '等待用户发送',
    'STATUS_RECORD': '状态归档'
}


class BusinessExecutionCenter:
    """业务执行中心：只有满足全部门槛的客户才能进入。"""

    def __init__(self):
        self.db = DB()
        self.aic = AccountIntelligenceCenter()

    def execute(self, norm: str, force: bool = False) -> Dict:
        """对指定客户执行业务开发流程。"""
        state = {'lead_norm': norm, 'history': [], 'current_step': None}

        for step in EXECUTION_ORDER:
            state['current_step'] = step
            handler = getattr(self, f'_step_{step.lower()}')
            result = handler(norm, state)

            state['history'].append({
                'step': step,
                'label': EXECUTION_LABELS[step],
                'success': result.get('success', False),
                'note': result.get('note', ''),
                'data': result.get('data', {})
            })

            if not result.get('success', False) and not force:
                return {
                    'ok': False,
                    'norm': norm,
                    'failed_at': step,
                    'history': state['history'],
                    'message': f"开发流程在 [{EXECUTION_LABELS[step]}] 终止: {result.get('note', '')}"
                }

        return {
            'ok': True,
            'norm': norm,
            'history': state['history'],
            'message': '开发流程完成，已生成Outlook草稿等待用户发送'
        }

    # ---------- Step 1: 资格门槛检查 ----------

    def _step_qualify(self, norm: str, state: Dict) -> Dict:
        """检查客户是否满足全部开发门槛。"""
        profile = self.aic.build_profile(norm)

        if profile.development_eligible:
            return {
                'success': True,
                'note': f"资格通过：完整度 {profile.completeness_score*100:.0f}%，ICP {profile.icp_score.get('tier', 'N/A')}",
                'data': {'completeness': profile.completeness_score, 'icp': profile.icp_score}
            }

        return {
            'success': False,
            'note': f"资格未通过：{'; '.join(profile.development_blockers)}",
            'data': {'blockers': profile.development_blockers}
        }

    # ---------- Step 2: 联系人验证 ----------

    def _step_contact_verify(self, norm: str, state: Dict) -> Dict:
        """确保有可用联系人。"""
        db_contacts = self.db.list_contacts(norm)

        if not db_contacts:
            # 尝试自动发现联系人
            result = contacts_mod.find_contacts(norm)
            if result.get('ok') and result.get('contacts'):
                return {
                    'success': True,
                    'note': f"自动发现 {len(result['contacts'])} 个联系人",
                    'data': {'contacts_found': len(result['contacts'])}
                }

            return {
                'success': False,
                'note': '无可用联系人，自动发现失败',
                'data': {}
            }

        return {
            'success': True,
            'note': f"已有 {len(db_contacts)} 个联系人",
            'data': {'contacts_count': len(db_contacts)}
        }

    # ---------- Step 3: 邮箱验证 ----------

    def _step_email_validate(self, norm: str, state: Dict) -> Dict:
        """确保至少有一个验证通过的邮箱。"""
        db_contacts = self.db.list_contacts(norm)
        verified = [c for c in db_contacts if c.get('email_verified') or c.get('mx_ok')]

        if not verified:
            return {
                'success': False,
                'note': '无验证通过的邮箱',
                'data': {}
            }

        return {
            'success': True,
            'note': f"{len(verified)} 个邮箱已验证",
            'data': {'verified_emails': [c.get('email') for c in verified]}
        }

    # ---------- Step 4: AI生成开发信 ----------

    def _step_pitch_generate(self, norm: str, state: Dict) -> Dict:
        """AI生成个性化开发信内容。"""
        lead = self.db.get_lead(norm)
        if not lead:
            return {'success': False, 'note': '客户不存在', 'data': {}}

        # 构建上下文
        profile = self.aic.build_profile(norm)
        context = {
            'company_name': profile.enterprise.name,
            'country': profile.enterprise.country,
            'product_category': profile.enterprise.product_category,
            'trade_products': profile.trade.products,
            'trade_hs': profile.trade.hs_codes,
            'current_suppliers': profile.trade.current_suppliers[:5],
            'contact_name': profile.contacts[0].name if profile.contacts else '',
            'contact_title': profile.contacts[0].title if profile.contacts else '',
            'website': profile.enterprise.website
        }

        # 调用 pitch 生成
        pitch_result = pitch.generate(norm, context)

        # 同时用 AI Gateway 做质量审核
        audit_prompt = f"""请审核以下开发信的质量，判断是否可以发送：

开发信标题：{pitch_result.get('subject', '')}
开发信正文：{pitch_result.get('body', '')[:800]}

判断结果：该企业高度可能是真实采购客户。
原因：
1. 存在真实贸易记录
2. 产品高度匹配
3. 最近存在采购行为

置信度：Strong

请输出：PASS / REVISE / REJECT 并说明理由。"""

        audit = ai_gateway.conclude(audit_prompt, task='pitch_audit')

        if audit.get('ok') and 'REJECT' in str(audit.get('text', '')).upper():
            return {
                'success': False,
                'note': f"开发信审核未通过：{audit.get('text', '')[:100]}",
                'data': {'pitch': pitch_result, 'audit': audit.get('text', '')}
            }

        return {
            'success': True,
            'note': '开发信生成并通过审核',
            'data': {
                'subject': pitch_result.get('subject'),
                'body': pitch_result.get('body'),
                'personalization': pitch_result.get('personalization'),
                'audit_result': audit.get('text', '') if audit.get('ok') else 'N/A'
            }
        }

    # ---------- Step 5: Outlook草稿生成 ----------

    def _step_outlook_draft(self, norm: str, state: Dict) -> Dict:
        """生成Outlook邮件草稿（绝不自动发送）。"""
        pitch_data = state['history'][-1]['data'] if state['history'] else {}
        subject = pitch_data.get('subject', 'Business Collaboration Opportunity')
        body = pitch_data.get('body', '')

        # 获取收件人
        db_contacts = self.db.list_contacts(norm)
        verified = [c for c in db_contacts if c.get('email_verified') or c.get('mx_ok')]
        if not verified:
            return {'success': False, 'note': '无验证邮箱，无法生成草稿', 'data': {}}

        recipient = verified[0].get('email')

        # 生成 Outlook 草稿（mailto 链接或 COM 接口）
        draft_result = outlook_send.create_draft(
            to=recipient,
            subject=subject,
            body=body,
            cc=''
        )

        # 记录到数据库
        self.db.save_message({
            'norm': norm,
            'direction': 'out',
            'to_email': recipient,
            'subject': subject,
            'body_preview': body[:200],
            'draft': True,
            'status': 'draft_created',
            'outlook_url': draft_result.get('url', ''),
            'created_at': time.time()
        })

        return {
            'success': True,
            'note': f"Outlook草稿已生成，收件人: {recipient}",
            'data': {
                'recipient': recipient,
                'subject': subject,
                'outlook_url': draft_result.get('url', ''),
                'draft_id': draft_result.get('draft_id', '')
            }
        }

    # ---------- Step 6: 用户发送（人工门） ----------

    def _step_user_send(self, norm: str, state: Dict) -> Dict:
        """等待用户手动点击发送——此步骤为人工门，系统自动通过并标记状态。"""
        # 更新消息状态为等待用户发送
        self.db.update_message_status(norm=norm, status='pending_user_send')

        return {
            'success': True,
            'note': '已生成草稿，等待用户在Outlook中点击发送',
            'data': {
                'action_required': 'user_click_send',
                'instruction': '请在Outlook中打开草稿邮件并点击发送按钮'
            }
        }

    # ---------- Step 7: 状态记录 ----------

    def _step_status_record(self, norm: str, state: Dict) -> Dict:
        """归档开发执行状态。"""
        self.db.lead_update(norm, outreach_state='draft_ready')

        # 保存执行历史到 development_blackboard
        self.db.save_development_blackboard(norm, {
            'execution_history': state['history'],
            'completed_at': time.time(),
            'status': 'draft_ready'
        })

        return {
            'success': True,
            'note': '开发执行状态已归档',
            'data': {'status': 'draft_ready'}
        }


# ---------- 便捷函数 ----------
def execute_development(norm: str, force: bool = False) -> Dict:
    return BusinessExecutionCenter().execute(norm, force)

def check_development_eligible(norm: str) -> Dict:
    profile = AccountIntelligenceCenter().build_profile(norm)
    return {
        'eligible': profile.development_eligible,
        'blockers': profile.development_blockers,
        'completeness': profile.completeness_score,
        'icp': profile.icp_score
    }