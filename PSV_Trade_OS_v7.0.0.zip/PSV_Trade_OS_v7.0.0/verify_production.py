#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生产环境验证 v7.0.0"""
import sys
import os
import ast

VERSION = "7.0.0"

def check():
    print(f"PSV Trade OS v{VERSION} - 生产环境验证")
    print("=" * 50)

    checks = []

    # 1. 目录结构
    checks.append(("目录结构", os.path.isdir("agents") and os.path.isdir("orchestrator")))

    # 2. 数据库解耦
    checks.append(("数据库解耦", not _has_import("database/models.py", "shared.") and not _has_import("database/models.py", "business.")))

    # 3. Audit独立
    checks.append(("Audit独立", not _has_import("audit/logger.py", "database.models")))

    # 4. 版本统一
    checks.append(("版本统一", _check_version()))

    # 5. Agent架构
    checks.append(("Agent架构", os.path.isdir("agents/trade_planner_agent") and os.path.exists("agents/trade_planner_agent/agent.py")))

    # 6. Contract完整
    checks.append(("Contract完整", os.path.exists("contracts/message_contract.py")))

    # 7. State分层
    checks.append(("State分层", os.path.exists("state/workflow_state.py") and os.path.exists("state/agent_state.py")))

    # 8. 循环依赖检查（基础）
    checks.append(("无循环依赖", _check_no_cycles()))

    # 9. Business层独立
    checks.append(("Business独立", not _has_import("business/collection/collector_service.py", "agents.")))

    # 10. Migration存在
    checks.append(("Migration配置", os.path.exists("database/migrations/env.py")))

    # 11. 测试覆盖
    test_files = [f for f in os.listdir("tests") if f.startswith("test_") and f.endswith(".py")] if os.path.isdir("tests") else []
    checks.append(("测试覆盖", len(test_files) >= 3))

    # 12. WebUI完整
    checks.append(("WebUI完整", os.path.exists("webui/app.py") and os.path.exists("webui/templates/dashboard.html")))

    # 13. 部署脚本
    checks.append(("部署脚本", all(os.path.exists(f) for f in ["install.bat", "start.bat", "stop.bat", "restart.bat"])))

    # 14. requirements.txt
    checks.append(("依赖声明", os.path.exists("requirements.txt") and "langgraph" in open("requirements.txt", encoding="utf-8").read()))

    passed = sum(1 for _, ok in checks if ok)
    for name, ok in checks:
        print(f"  [{'OK' if ok else 'FAIL'}] {name}")

    print(f"\n结果: {passed}/{len(checks)} 通过")
    return passed == len(checks)

def _has_import(filepath, pattern):
    if not os.path.exists(filepath):
        return False
    with open(filepath, 'r', encoding='utf-8') as f:
        return pattern in f.read()

def _check_version():
    version_files = ["VERSION.txt", "shared/config/settings.py", "orchestrator/graph.py", "verify_startup.py"]
    versions = []
    for f in version_files:
        if os.path.exists(f):
            with open(f, encoding='utf-8') as fh:
                content = fh.read()
                if VERSION in content:
                    versions.append(True)
    return len(versions) >= 3

def _check_no_cycles():
    """基础循环依赖检查：确保shared不导入上层"""
    shared_files = []
    for root, dirs, files in os.walk("shared"):
        for f in files:
            if f.endswith(".py"):
                shared_files.append(os.path.join(root, f))
    for sf in shared_files:
        with open(sf, 'r', encoding='utf-8') as f:
            content = f.read()
            for forbidden in ["from database", "from business", "from agents", "from orchestrator"]:
                if forbidden in content:
                    return False
    return True

if __name__ == "__main__":
    ok = check()
    sys.exit(0 if ok else 1)
