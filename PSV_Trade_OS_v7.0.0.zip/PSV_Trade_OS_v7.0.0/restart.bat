@echo off
call stop.bat
timeout /t 3 >nul
call start.bat
