# PSV Trade OS v7.0.0

**以 LangGraph 完整智能编排系统为核心的外贸业务操作系统（Trade Intelligence Operating System）**

---

## 架构标准

```
                外贸业务层 (business/)
                    |
                    ↓  [Repository Interface]
              Business Service
                    |
                    ↓  [Contract验证]
              Agent Intelligence Layer (agents/)
                    |
                    ↓  [LangGraph StateGraph]
           LangGraph Orchestration Layer (orchestrator/)
                    |
                    ↓  [TypedDict State + Checkpoint]
        Contract / Runtime / State Layer (contracts/ + state/)
                    |
                    ↓  [Repository Interface]
          Infrastructure Layer (database/ + audit/)
```

## 核心能力

- **LangGraph编排**: 5类Agent完整流程（Planner/Supervisor/Router/Executor/Reviewer）
- **Agent架构**: 每个Agent独立目录，4文件标准（agent.py/schema.py/tools.py/prompt.py）
- **Contract层**: 7类完整契约，强制schema_version
- **State管理**: Workflow/Task/Agent三层State，支持save/restore/rollback/retry
- **Audit系统**: 独立审计，通过Repository Interface访问数据
- **数据库解耦**: 纯模型定义，连接由上层注入
- **零循环依赖**: 模块间严格单向依赖
- **架构守护**: pytest自动检查，防止未来PR破坏架构

## 快速开始

```bash
# Windows双击安装
install.bat

# 启动系统
start.bat

# 或命令行运行任务
python -m app.main --objective "开发美国蜡烛进口商" --product "birthday candles" --market USA

# 运行测试
pytest tests/ -v
```

## 验收标准

| 标准 | 状态 |
|------|------|
| LangGraph是真正核心编排层 | ✅ |
| 外贸业务流程完整 | ✅ |
| Agent体系完整 | ✅ |
| Contract体系完整 | ✅ |
| State管理完整 | ✅ |
| Audit完整 | ✅ |
| Recovery完整 | ✅ |
| 数据库解耦 | ✅ |
| 模块无循环依赖 | ✅ |
| Windows一键部署 | ✅ |
| 可持续扩展 | ✅ |
| 架构守护测试 | ✅ |
| Alembic迁移 | ✅ |
