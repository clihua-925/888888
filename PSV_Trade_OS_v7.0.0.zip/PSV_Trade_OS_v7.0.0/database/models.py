# -*- coding: utf-8 -*-
"""PSV Trade OS v7.0.0 - 纯数据库模型定义

核心原则:
1. 仅包含SQLAlchemy模型定义
2. 不创建engine/session(由上层注入)
3. 不import任何shared/business/agents/orchestrator模块
4. 提供to_dict()辅助方法
"""
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, JSON, Index, create_engine
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from sqlalchemy.sql import func
from datetime import datetime
import uuid

Base = declarative_base()

def generate_uuid() -> str:
    return uuid.uuid4().hex[:16]

# ========== 1. 贸易企业表 ==========
class TradeCompany(Base):
    __tablename__ = 'trade_company'
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    name = Column(String(500), nullable=False, index=True)
    name_norm = Column(String(500), index=True)
    country = Column(String(100), index=True)
    website = Column(String(500))
    industry = Column(String(200), index=True)
    main_products = Column(JSON)
    purchase_direction = Column(JSON)
    company_size = Column(String(50))
    supply_chain_role = Column(String(100))
    credibility_score = Column(Float, default=0.0)
    purchase_probability = Column(Float, default=0.0)
    match_score = Column(Float, default=0.0)
    deal_probability = Column(Float, default=0.0)
    development_priority = Column(Integer, default=0)
    development_stage = Column(String(50), default='new')
    customer_tier = Column(String(10), default='D')
    is_active = Column(Boolean, default=True)
    source = Column(String(200))
    evidence = Column(JSON)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    contacts = relationship("TradeContact", back_populates="company", cascade="all, delete-orphan")
    opportunities = relationship("TradeOpportunity", back_populates="company")
    audit_logs = relationship("AuditEvent", back_populates="company")

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# ========== 2. 联系人表 ==========
class TradeContact(Base):
    __tablename__ = 'trade_contact'
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    name = Column(String(200))
    title = Column(String(200))
    email = Column(String(300), index=True)
    phone = Column(String(100))
    linkedin = Column(String(500))
    decision_maker = Column(Boolean, default=False)
    confidence = Column(Float, default=0.0)
    source = Column(String(200))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    company = relationship("TradeCompany", back_populates="contacts")

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# ========== 3. 商机表 ==========
class TradeOpportunity(Base):
    __tablename__ = 'trade_opportunity'
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    product = Column(String(300), index=True)
    market = Column(String(100), index=True)
    stage = Column(String(50), default='prospecting')
    estimated_value = Column(Float, default=0.0)
    probability = Column(Float, default=0.0)
    expected_close = Column(DateTime)
    source = Column(String(200))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    company = relationship("TradeCompany", back_populates="opportunities")

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# ========== 4. 客户池表 ==========
class CustomerPool(Base):
    __tablename__ = 'customer_pool'
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    tier = Column(String(10), default='D')
    score = Column(Float, default=0.0)
    strategy = Column(JSON)
    last_contact = Column(DateTime)
    next_action = Column(String(500))
    assigned_to = Column(String(200))
    status = Column(String(50), default='active')
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# ========== 5. 任务表 ==========
class Task(Base):
    __tablename__ = 'task'
    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    objective = Column(Text)
    product = Column(String(300))
    market = Column(String(100), index=True)
    target_customer = Column(String(100))
    status = Column(String(50), default='pending', index=True)
    current_step = Column(Integer, default=0)
    plan = Column(JSON)
    result_summary = Column(Text)
    error_log = Column(JSON)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    completed_at = Column(DateTime)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# ========== 6. 工作流表 ==========
class Workflow(Base):
    __tablename__ = 'workflow'
    id = Column(Integer, primary_key=True, autoincrement=True)
    workflow_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    task_id = Column(String(32), ForeignKey('task.task_id'), index=True)
    status = Column(String(50), default='pending')
    checkpoint_data = Column(Text)
    graph_state = Column(Text)
    current_node = Column(String(100))
    recovery_attempts = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# ========== 7. 审计事件表 ==========
class AuditEvent(Base):
    __tablename__ = 'audit_event'
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    trace_id = Column(String(32), index=True)
    workflow_id = Column(String(32), index=True)
    task_id = Column(String(32), index=True)
    agent_id = Column(String(32), index=True)
    event_type = Column(String(100), index=True)
    status = Column(String(50), index=True)
    input_data = Column(Text)
    output_data = Column(Text)
    error_details = Column(Text)
    duration_sec = Column(Float, default=0.0)
    timestamp = Column(DateTime, default=func.now(), index=True)
    metadata_json = Column(Text)
    node_name = Column(String(100))
    tool_name = Column(String(100))
    retry_count = Column(Integer, default=0)
    schema_version = Column(String(10), default='2.1.0')
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'))
    company = relationship("TradeCompany", back_populates="audit_logs")

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}
