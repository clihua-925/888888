# -*- coding: utf-8 -*-
"""Repository Interface - 数据库访问的唯一合法入口 v7.0.0

所有business/agent/audit模块必须通过Repository Interface访问数据.
禁止直接import database.models.
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Callable
from .session import get_session_factory

# ========== 公司Repository ==========
class ICompanyRepository(ABC):
    @abstractmethod
    def get_by_id(self, entity_id: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def get_by_name_norm(self, name_norm: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def list_by_country(self, country: str, limit: int = 100) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def save(self, data: Dict[str, Any]) -> str: ...
    @abstractmethod
    def update(self, entity_id: str, data: Dict[str, Any]) -> bool: ...
    @abstractmethod
    def list_all(self, limit: int = 1000) -> List[Dict[str, Any]]: ...

class CompanyRepository(ICompanyRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def get_by_id(self, entity_id: str) -> Optional[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            row = s.query(TradeCompany).filter(TradeCompany.entity_id == entity_id).first()
            return row.to_dict() if row else None
        finally:
            s.close()

    def get_by_name_norm(self, name_norm: str) -> Optional[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            row = s.query(TradeCompany).filter(TradeCompany.name_norm == name_norm).first()
            return row.to_dict() if row else None
        finally:
            s.close()

    def list_by_country(self, country: str, limit: int = 100) -> List[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            rows = s.query(TradeCompany).filter(TradeCompany.country == country).limit(limit).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

    def save(self, data: Dict[str, Any]) -> str:
        from .models import TradeCompany
        s = self._session()
        try:
            company = TradeCompany(**data)
            s.add(company)
            s.commit()
            return company.entity_id
        finally:
            s.close()

    def update(self, entity_id: str, data: Dict[str, Any]) -> bool:
        from .models import TradeCompany
        s = self._session()
        try:
            row = s.query(TradeCompany).filter(TradeCompany.entity_id == entity_id).first()
            if not row:
                return False
            for k, v in data.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            s.commit()
            return True
        finally:
            s.close()

    def list_all(self, limit: int = 1000) -> List[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            rows = s.query(TradeCompany).limit(limit).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

# ========== 任务Repository ==========
class ITaskRepository(ABC):
    @abstractmethod
    def get_by_id(self, task_id: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def save(self, data: Dict[str, Any]) -> str: ...
    @abstractmethod
    def update_status(self, task_id: str, status: str, current_step: int = None, error: str = None) -> bool: ...

class TaskRepository(ITaskRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def get_by_id(self, task_id: str) -> Optional[Dict[str, Any]]:
        from .models import Task
        s = self._session()
        try:
            row = s.query(Task).filter(Task.task_id == task_id).first()
            return row.to_dict() if row else None
        finally:
            s.close()

    def save(self, data: Dict[str, Any]) -> str:
        from .models import Task
        s = self._session()
        try:
            task = Task(**data)
            s.add(task)
            s.commit()
            return task.task_id
        finally:
            s.close()

    def update_status(self, task_id: str, status: str, current_step: int = None, error: str = None) -> bool:
        from .models import Task
        s = self._session()
        try:
            row = s.query(Task).filter(Task.task_id == task_id).first()
            if not row:
                return False
            row.status = status
            if current_step is not None:
                row.current_step = current_step
            if error:
                existing = row.error_log or []
                existing.append(error)
                row.error_log = existing
            s.commit()
            return True
        finally:
            s.close()

# ========== 工作流Repository ==========
class IWorkflowRepository(ABC):
    @abstractmethod
    def get_by_task(self, task_id: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def save_checkpoint(self, task_id: str, workflow_id: str, checkpoint_data: str, graph_state: str) -> bool: ...

class WorkflowRepository(IWorkflowRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def get_by_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        from .models import Workflow
        s = self._session()
        try:
            row = s.query(Workflow).filter(Workflow.task_id == task_id).order_by(Workflow.id.desc()).first()
            return row.to_dict() if row else None
        finally:
            s.close()

    def save_checkpoint(self, task_id: str, workflow_id: str, checkpoint_data: str, graph_state: str) -> bool:
        from .models import Workflow
        s = self._session()
        try:
            row = s.query(Workflow).filter(Workflow.task_id == task_id, Workflow.workflow_id == workflow_id).first()
            if row:
                row.checkpoint_data = checkpoint_data
                row.graph_state = graph_state
                row.updated_at = __import__('datetime').datetime.utcnow()
            else:
                row = Workflow(task_id=task_id, workflow_id=workflow_id, checkpoint_data=checkpoint_data, graph_state=graph_state)
                s.add(row)
            s.commit()
            return True
        finally:
            s.close()

# ========== 客户池Repository ==========
class ICustomerPoolRepository(ABC):
    @abstractmethod
    def save(self, data: Dict[str, Any]) -> str: ...
    @abstractmethod
    def list_by_tier(self, tier: str, limit: int = 100) -> List[Dict[str, Any]]: ...

class CustomerPoolRepository(ICustomerPoolRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def save(self, data: Dict[str, Any]) -> str:
        from .models import CustomerPool
        s = self._session()
        try:
            pool = CustomerPool(**data)
            s.add(pool)
            s.commit()
            return pool.entity_id
        finally:
            s.close()

    def list_by_tier(self, tier: str, limit: int = 100) -> List[Dict[str, Any]]:
        from .models import CustomerPool
        s = self._session()
        try:
            rows = s.query(CustomerPool).filter(CustomerPool.tier == tier).limit(limit).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

# ========== 审计Repository ==========
class IAuditRepository(ABC):
    @abstractmethod
    def save_event(self, event) -> str: ...
    @abstractmethod
    def get_by_trace(self, trace_id: str) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def get_by_workflow(self, workflow_id: str) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def get_by_task(self, task_id: str) -> List[Dict[str, Any]]: ...

class AuditRepository(IAuditRepository):
    """审计Repository实现 - 通过session_factory操作数据库"""

    def __init__(self, session_factory: Callable = None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def save_event(self, event) -> str:
        # 运行时动态import, 避免编译期依赖database.models
        from .models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            record = AuditEventModel(
                event_id=event.event_id,
                trace_id=event.trace_id,
                workflow_id=event.workflow_id,
                task_id=event.task_id,
                agent_id=event.agent_id,
                event_type=event.event_type,
                status=event.status,
                input_data=__import__("json").dumps(event.input_data, ensure_ascii=False) if event.input_data else None,
                output_data=__import__("json").dumps(event.output_data, ensure_ascii=False) if event.output_data else None,
                error_details=event.error_details,
                duration_sec=event.duration_sec,
                timestamp=event.timestamp,
                metadata_json=__import__("json").dumps(event.metadata, ensure_ascii=False) if event.metadata else None,
                node_name=event.node_name,
                tool_name=event.tool_name,
                retry_count=event.retry_count,
                schema_version=event.schema_version,
            )
            s.add(record)
            s.commit()
            return event.event_id
        finally:
            s.close()

    def get_by_trace(self, trace_id: str) -> List[Dict[str, Any]]:
        from .models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            rows = s.query(AuditEventModel).filter(AuditEventModel.trace_id == trace_id).order_by(AuditEventModel.timestamp.desc()).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

    def get_by_workflow(self, workflow_id: str) -> List[Dict[str, Any]]:
        from .models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            rows = s.query(AuditEventModel).filter(AuditEventModel.workflow_id == workflow_id).order_by(AuditEventModel.timestamp.desc()).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

    def get_by_task(self, task_id: str) -> List[Dict[str, Any]]:
        from .models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            rows = s.query(AuditEventModel).filter(AuditEventModel.task_id == task_id).order_by(AuditEventModel.timestamp.desc()).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()
