# -*- coding: utf-8 -*-
"""Database Session - 连接由上层注入, database不自行创建"""
from typing import Optional, Callable
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from .models import Base

_engine: Optional[object] = None
_SessionLocal: Optional[Callable[[], Session]] = None

def init_database(database_url: str, echo: bool = False):
    """由app/main.py在启动时调用, 注入配置"""
    global _engine, _SessionLocal
    _engine = create_engine(
        database_url,
        echo=echo,
        connect_args={"check_same_thread": False} if database_url.startswith("sqlite") else {}
    )
    _SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)
    Base.metadata.create_all(bind=_engine)

def get_session_factory() -> Callable[[], Session]:
    if _SessionLocal is None:
        raise RuntimeError("Database not initialized. Call init_database() first in app/main.py")
    return _SessionLocal

def get_engine():
    if _engine is None:
        raise RuntimeError("Database not initialized.")
    return _engine
