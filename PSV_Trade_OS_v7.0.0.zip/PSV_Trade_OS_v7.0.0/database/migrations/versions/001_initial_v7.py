"""Initial migration for PSV Trade OS v7.0.0"""

revision = '001'
down_revision = None
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade() -> None:
    # 所有表由Base.metadata.create_all()在init_database时创建
    # Alembic主要用于后续schema变更
    pass

def downgrade() -> None:
    pass
