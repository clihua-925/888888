# -*- coding: utf-8 -*-
"""Data Contract - 业务数据契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class CompanyProfile(BaseModel):
    entity_id: Optional[str] = None
    name: str
    name_norm: Optional[str] = None
    country: str
    website: Optional[str] = None
    industry: Optional[str] = None
    main_products: List[str] = []
    purchase_direction: List[str] = []
    company_size: Optional[str] = None
    supply_chain_role: Optional[str] = None
    credibility_score: float = 0.0
    purchase_probability: float = 0.0
    match_score: float = 0.0
    deal_probability: float = 0.0
    development_priority: int = 0
    development_stage: str = "new"
    customer_tier: str = "D"
    is_active: bool = True
    source: Optional[str] = None
    evidence: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    contacts: List[Dict[str, Any]] = []

class ContactInfo(BaseModel):
    entity_id: Optional[str] = None
    company_id: Optional[str] = None
    name: str
    title: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    linkedin: Optional[str] = None
    decision_maker: bool = False
    confidence: float = 0.0
    source: Optional[str] = None

class LeadScore(BaseModel):
    company_name: str
    overall_score: float = 0.0
    match_degree: float = 0.0
    deal_probability: float = 0.0
    purchase_likelihood: float = 0.0
    company_strength: float = 0.0
    tier: str = "D"
    priority: int = 0
    scored_at: datetime = Field(default_factory=datetime.utcnow)
