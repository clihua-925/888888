# -*- coding: utf-8 -*-
"""Workflow Contract - 工作流契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum

class WorkflowStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    RECOVERING = "recovering"

class WorkflowContract(BaseModel):
    workflow_id: str
    schema_version: str = "2.1.0"
    task_id: str
    status: WorkflowStatus = WorkflowStatus.PENDING
    current_node: str = "planner"
    current_step: int = 0
    total_steps: int = 0
    plan: List[Dict[str, Any]] = []
    agent_outputs: List[Dict[str, Any]] = []
    reviews: List[Dict[str, Any]] = []
    errors: List[str] = []
    checkpoints: List[str] = []
    trace_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    def validate_schema(self) -> bool:
        return self.schema_version == "2.1.0"
