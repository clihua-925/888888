# -*- coding: utf-8 -*-
"""Execution Contract - 执行记录契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class ExecutionRecord(BaseModel):
    execution_id: str = Field(default_factory=lambda: __import__('uuid').uuid4().hex[:16])
    workflow_id: str
    task_id: str
    agent_type: str
    agent_id: str
    node_name: str
    input_data: Dict[str, Any] = Field(default_factory=dict)
    output_data: Dict[str, Any] = Field(default_factory=dict)
    status: str = "running"
    error: Optional[str] = None
    duration_sec: float = 0.0
    retry_count: int = 0
    schema_version: str = "2.1.0"
    timestamp: datetime = Field(default_factory=datetime.utcnow)
