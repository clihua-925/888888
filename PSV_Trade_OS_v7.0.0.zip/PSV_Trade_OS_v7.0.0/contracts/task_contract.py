# -*- coding: utf-8 -*-
"""Task Contract - 任务契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class TaskPlanStep(BaseModel):
    step_number: int
    agent_type: str
    description: str
    input: Dict[str, Any] = Field(default_factory=dict)
    expected_output: Dict[str, Any] = Field(default_factory=dict)
    dependencies: List[int] = []
    retry_count: int = 0
    max_retries: int = 3

class TaskContract(BaseModel):
    task_id: str
    schema_version: str = "2.1.0"
    objective: str
    product: str
    market: str
    target_customer: str = "importer"
    status: str = "pending"
    current_step: int = 0
    plan: List[TaskPlanStep] = []
    result_summary: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    retry_count: int = 0
    max_retries: int = 3
    error_log: List[Dict[str, Any]] = []
