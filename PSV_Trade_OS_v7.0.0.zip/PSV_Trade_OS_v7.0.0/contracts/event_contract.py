# -*- coding: utf-8 -*-
"""Event Contract - 事件契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class EventRecord(BaseModel):
    event_id: str = Field(default_factory=lambda: __import__('uuid').uuid4().hex[:16])
    event_type: str
    source: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    trace_id: str
    workflow_id: Optional[str] = None
    task_id: Optional[str] = None
    schema_version: str = "2.1.0"
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    correlation_id: Optional[str] = None
