# -*- coding: utf-8 -*-
"""Tool Contract - 工具调用契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class ToolCallRecord(BaseModel):
    call_id: str = Field(default_factory=lambda: __import__('uuid').uuid4().hex[:16])
    tool_name: str
    agent_type: str
    agent_id: str
    input_params: Dict[str, Any] = Field(default_factory=dict)
    output_result: Dict[str, Any] = Field(default_factory=dict)
    status: str = "success"
    error: Optional[str] = None
    duration_sec: float = 0.0
    trace_id: str
    schema_version: str = "2.1.0"
    timestamp: datetime = Field(default_factory=datetime.utcnow)
