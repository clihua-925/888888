# -*- coding: utf-8 -*-
"""Agent Contract - Agent输入输出契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class AgentRequest(BaseModel):
    request_id: str = Field(default_factory=lambda: __import__('uuid').uuid4().hex[:16])
    task_id: str
    agent_type: str
    input_data: Dict[str, Any] = Field(default_factory=dict)
    context: Dict[str, Any] = Field(default_factory=dict)
    trace_id: str
    workflow_id: str
    schema_version: str = "2.1.0"
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class AgentResponse(BaseModel):
    request_id: str
    task_id: str
    agent_type: str
    result: Dict[str, Any] = Field(default_factory=dict)
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    status: str = "success"  # success / failed / degraded
    error: Optional[str] = None
    duration_sec: float = 0.0
    schema_version: str = "2.1.0"
    timestamp: datetime = Field(default_factory=datetime.utcnow)
