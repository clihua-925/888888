# -*- coding: utf-8 -*-
"""Message Contract - 消息信封契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class MessageEnvelope(BaseModel):
    message_id: str = Field(default_factory=lambda: __import__('uuid').uuid4().hex[:16])
    message_type: str  # command / event / query / response
    sender: str
    recipient: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    trace_id: str
    workflow_id: Optional[str] = None
    task_id: Optional[str] = None
    schema_version: str = "2.1.0"
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    priority: int = 5  # 1-10, 1=最高
    ttl_sec: int = 300
