# -*- coding: utf-8 -*-
"""Contracts Layer - 统一契约定义, 禁止导入业务逻辑"""
from .workflow_contract import WorkflowContract, WorkflowStatus
from .agent_contract import AgentRequest, AgentResponse
from .task_contract import TaskPlanStep, TaskContract
from .execution_contract import ExecutionRecord
from .data_contract import CompanyProfile, ContactInfo, LeadScore
from .message_contract import MessageEnvelope
from .event_contract import EventRecord
from .tool_contract import ToolCallRecord

__all__ = [
    "WorkflowContract", "WorkflowStatus",
    "AgentRequest", "AgentResponse",
    "TaskPlanStep", "TaskContract",
    "ExecutionRecord",
    "CompanyProfile", "ContactInfo", "LeadScore",
    "MessageEnvelope", "EventRecord", "ToolCallRecord",
]
