@echo off
chcp 65001 >nul
echo ==========================================
echo PSV Trade OS v7.0.0 - 安装脚本
echo ==========================================

REM 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python未安装，请先安装Python 3.10+
    exit /b 1
)

REM 创建虚拟环境
if not exist venv (
    echo [1/6] 创建虚拟环境...
    python -m venv venv
)

REM 激活虚拟环境
echo [2/6] 激活虚拟环境...
call venv\Scripts\activate.bat

REM 安装依赖
echo [3/6] 安装依赖...
pip install -r requirements.txt

REM 初始化数据库
echo [4/6] 初始化数据库...
python -m app.main --init-db

REM 运行Alembic迁移
echo [5/6] 数据库迁移...
if exist alembic.ini (
    alembic upgrade head
)

REM 验证安装
echo [6/6] 验证安装...
python verify_startup.py

echo.
echo ==========================================
echo 安装完成！运行 start.bat 启动系统
echo ==========================================
pause
