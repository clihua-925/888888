# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import Dict, Any

class ReportInput(BaseModel):
    aggregated: Dict[str, Any]

class ReportOutput(BaseModel):
    report: Dict[str, Any]
