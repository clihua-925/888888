# -*- coding: utf-8 -*-
"""报告生成Agent - Agent实现 v7.0.0"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import ReportInput, ReportOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class ReportAgent(BaseAgent):
    """报告生成Agent"""

    def __init__(self):
        super().__init__(
            agent_type="report",
            agent_name="报告生成Agent",
            system_prompt=SYSTEM_PROMPT,
        )

    def _run(self, request: AgentRequest) -> AgentResponse:
        aggregated = request.input_data.get("aggregated", {})
        report = {
            "title": "外贸开发报告",
            "summary": f"共执行 {len(aggregated)} 个步骤",
            "details": aggregated,
            "recommendations": ["优先跟进S级客户", "发送样品给A级客户"],
        }
        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"report": report},
            confidence=0.9,
            status="success",
        )
