# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import Dict, Any

class TradeplannerInput(BaseModel):
    objective: str
    product: str
    market: str

class TradeplannerOutput(BaseModel):
    plan_accepted: bool
