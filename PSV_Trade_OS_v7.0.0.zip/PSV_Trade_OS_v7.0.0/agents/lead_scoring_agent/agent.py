# -*- coding: utf-8 -*-
"""客户评分Agent - Agent实现 v7.0.0"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import LeadscoringInput, LeadscoringOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class LeadscoringAgent(BaseAgent):
    """客户评分Agent"""

    def __init__(self, scoring_service=None):
        super().__init__(
            agent_type="lead_scoring",
            agent_name="客户评分Agent",
            system_prompt=SYSTEM_PROMPT,
        )
        self.scoring_service = scoring_service

    def _run(self, request: AgentRequest) -> AgentResponse:
        companies = request.input_data.get("companies", [])
        contacts = request.input_data.get("contacts", [])

        if self.scoring_service:
            scores = self.scoring_service.batch_score(companies)
            confidence = 0.9
            status = "success"
        else:
            scores = []
            for c in companies:
                scores.append({
                    "company_name": c.get("name"),
                    "overall_score": 50.0,
                    "tier": "B",
                })
            confidence = 0.5
            status = "degraded"

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"scores": scores},
            confidence=confidence,
            status=status,
        )
