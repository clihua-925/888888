# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import List, Dict, Any

class LeadscoringInput(BaseModel):
    companies: List[Dict[str, Any]]
    contacts: List[Dict[str, Any]] = []

class LeadscoringOutput(BaseModel):
    scores: List[Dict[str, Any]]
