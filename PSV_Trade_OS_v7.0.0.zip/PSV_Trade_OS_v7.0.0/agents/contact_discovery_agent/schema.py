# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import List, Dict, Any

class ContactdiscoveryInput(BaseModel):
    companies: List[Dict[str, Any]]

class ContactdiscoveryOutput(BaseModel):
    contacts: List[Dict[str, Any]]
