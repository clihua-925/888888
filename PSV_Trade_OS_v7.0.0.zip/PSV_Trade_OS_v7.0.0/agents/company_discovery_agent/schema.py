# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import List, Dict, Any

class CompanydiscoveryInput(BaseModel):
    product: str
    market: str
    customer_type: str = "importer"
    max_results: int = 50

class CompanydiscoveryOutput(BaseModel):
    companies: List[Dict[str, Any]]
    total_found: int
