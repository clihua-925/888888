# -*- coding: utf-8 -*-
"""企业发现Agent - Agent实现 v7.0.0"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import CompanydiscoveryInput, CompanydiscoveryOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class CompanydiscoveryAgent(BaseAgent):
    """企业发现Agent - 通过CollectionService执行真实业务逻辑"""

    def __init__(self, collection_service=None):
        super().__init__(
            agent_type="company_discovery",
            agent_name="企业发现Agent",
            system_prompt=SYSTEM_PROMPT,
        )
        self.collection_service = collection_service

    def _run(self, request: AgentRequest) -> AgentResponse:
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")
        customer_type = request.input_data.get("customer_type", "importer")
        max_results = request.input_data.get("max_results", 50)

        if self.collection_service:
            companies = self.collection_service.discover_companies(
                product=product, market=market, customer_type=customer_type, max_results=max_results
            )
            companies = self.collection_service.deduplicate(companies)
            confidence = 0.85
            status = "success"
        else:
            companies = []
            for i in range(min(max_results, 5)):
                companies.append({
                    "name": f"{market} {customer_type.title()} {i+1} Corp",
                    "country": market,
                    "website": f"https://example{i+1}.com",
                    "industry": "Trading",
                    "credibility_score": 50 + i * 5,
                    "source": "simulated",
                })
            confidence = 0.6
            status = "degraded"

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"companies": companies, "total_found": len(companies)},
            confidence=confidence,
            status=status,
        )
