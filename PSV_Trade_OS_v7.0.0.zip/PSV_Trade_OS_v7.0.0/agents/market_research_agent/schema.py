# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import Dict, Any

class MarketresearchInput(BaseModel):
    product: str
    market: str

class MarketresearchOutput(BaseModel):
    analysis: Dict[str, Any]
