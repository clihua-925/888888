# -*- coding: utf-8 -*-
"""市场研究Agent - Agent实现 v7.0.0"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import MarketresearchInput, MarketresearchOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class MarketresearchAgent(BaseAgent):
    """市场研究Agent"""

    def __init__(self, market_service=None):
        super().__init__(
            agent_type="market_research",
            agent_name="市场研究Agent",
            system_prompt=SYSTEM_PROMPT,
        )
        self.market_service = market_service

    def _run(self, request: AgentRequest) -> AgentResponse:
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")

        if self.market_service:
            analysis = self.market_service.analyze_market(market=market, product=product)
            confidence = 0.85
            status = "success"
        else:
            analysis = {
                "country_code": market,
                "market_size": 1000000,
                "competition_level": "medium",
                "key_trends": [f"{product}需求增长", "数字化转型"],
                "major_players": [{"name": f"{market} Top Importer", "score": 85}],
            }
            confidence = 0.6
            status = "degraded"

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"analysis": analysis},
            confidence=confidence,
            status=status,
        )
