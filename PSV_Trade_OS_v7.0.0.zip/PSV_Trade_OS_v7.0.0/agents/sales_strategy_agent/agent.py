# -*- coding: utf-8 -*-
"""销售策略Agent - Agent实现 v7.0.0"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import SalesstrategyInput, SalesstrategyOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class SalesstrategyAgent(BaseAgent):
    """销售策略Agent"""

    def __init__(self, strategy_service=None):
        super().__init__(
            agent_type="sales_strategy",
            agent_name="销售策略Agent",
            system_prompt=SYSTEM_PROMPT,
        )
        self.strategy_service = strategy_service

    def _run(self, request: AgentRequest) -> AgentResponse:
        companies = request.input_data.get("companies", [])
        scores = request.input_data.get("scores", [])

        if self.strategy_service:
            strategies = self.strategy_service.batch_strategy(companies, scores)
            confidence = 0.85
            status = "success"
        else:
            strategies = []
            for c, s in zip(companies, scores):
                tier = s.get("tier", "D")
                strategies.append({
                    "company_name": c.get("name"),
                    "tier": tier,
                    "strategy": {"approach": "标准开发", "channel": "邮件", "frequency": "每月"},
                    "next_action": "发送开发信",
                })
            confidence = 0.6
            status = "degraded"

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"strategies": strategies},
            confidence=confidence,
            status=status,
        )
