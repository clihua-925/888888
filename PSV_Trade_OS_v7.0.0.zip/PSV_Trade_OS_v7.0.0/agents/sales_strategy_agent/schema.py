# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import List, Dict, Any

class SalesstrategyInput(BaseModel):
    companies: List[Dict[str, Any]]
    scores: List[Dict[str, Any]]

class SalesstrategyOutput(BaseModel):
    strategies: List[Dict[str, Any]]
