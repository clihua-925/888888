# -*- coding: utf-8 -*-
from pydantic import BaseModel
from typing import List, Dict, Any

class CompanyenrichmentInput(BaseModel):
    companies: List[Dict[str, Any]]

class CompanyenrichmentOutput(BaseModel):
    enriched_companies: List[Dict[str, Any]]
