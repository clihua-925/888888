# -*- coding: utf-8 -*-
"""企业补全Agent - Agent实现 v7.0.0"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import CompanyenrichmentInput, CompanyenrichmentOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class CompanyenrichmentAgent(BaseAgent):
    """企业补全Agent"""

    def __init__(self, customer_service=None):
        super().__init__(
            agent_type="company_enrichment",
            agent_name="企业补全Agent",
            system_prompt=SYSTEM_PROMPT,
        )
        self.customer_service = customer_service

    def _run(self, request: AgentRequest) -> AgentResponse:
        companies = request.input_data.get("companies", [])
        enriched = []
        for c in companies:
            enriched.append({
                **c,
                "match_score": 0.7,
                "deal_probability": 0.5,
                "purchase_direction": [c.get("industry", "general")],
            })
        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"enriched_companies": enriched},
            confidence=0.75,
            status="success",
        )
