# -*- coding: utf-8 -*-
"""Agent Registry - Agent注册中心

所有Agent必须通过Registry注册, 禁止直接实例化.
"""
from typing import Dict, List, Optional, Callable

class AgentRegistry:
    """Agent注册表"""

    _agents: Dict[str, Callable] = {}
    _instances: Dict[str, object] = {}

    @classmethod
    def register(cls, agent_type: str, factory: Callable):
        """注册Agent工厂函数"""
        cls._agents[agent_type] = factory

    @classmethod
    def get_agent(cls, agent_type: str) -> Optional[object]:
        """获取Agent实例(懒加载)"""
        if agent_type in cls._instances:
            return cls._instances[agent_type]

        factory = cls._agents.get(agent_type)
        if not factory:
            return None

        instance = factory()
        cls._instances[agent_type] = instance
        return instance

    @classmethod
    def list_agents(cls) -> List[str]:
        """列出所有已注册Agent"""
        return list(cls._agents.keys())

    @classmethod
    def clear(cls):
        """清空注册表"""
        cls._agents.clear()
        cls._instances.clear()
