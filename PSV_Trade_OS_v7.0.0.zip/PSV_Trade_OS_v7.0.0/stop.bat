@echo off
chcp 65001 >nul
echo [INFO] 停止PSV Trade OS...
taskkill /F /IM python.exe >nul 2>&1
echo [OK] 已停止
timeout /t 2 >nul
