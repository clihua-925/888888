document.getElementById('taskForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const resultDiv = document.getElementById('taskResult');
    resultDiv.innerHTML = '任务执行中...';
    
    const res = await fetch('/api/task', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            objective: document.getElementById('objective').value,
            product: document.getElementById('product').value,
            market: document.getElementById('market').value,
            target_customer: document.getElementById('target_customer').value,
        })
    });
    const data = await res.json();
    resultDiv.innerHTML = '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
});

async function checkStatus() {
    const wfId = document.getElementById('workflowId').value;
    const res = await fetch('/api/status/' + wfId);
    const data = await res.json();
    document.getElementById('statusResult').innerHTML = '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
}
