# -*- coding: utf-8 -*-
"""WebUI - Flask应用 v7.0.0"""
from flask import Flask, render_template, jsonify, request
from shared.config import settings

def create_app(psv_app):
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config["SECRET_KEY"] = settings.WEBUI_CONFIG["secret_key"]

    @app.route("/")
    def dashboard():
        return render_template("dashboard.html", version=settings.APP_VERSION)

    @app.route("/api/task", methods=["POST"])
    def create_task():
        data = request.get_json() or {}
        objective = data.get("objective", "")
        product = data.get("product", "")
        market = data.get("market", "")
        target = data.get("target_customer", "importer")

        if not all([objective, product, market]):
            return jsonify({"error": "缺少必要参数"}), 400

        result = psv_app.run_task(
            objective=objective,
            product=product,
            market=market,
            target_customer=target,
        )
        return jsonify(result)

    @app.route("/api/status/<workflow_id>")
    def get_status(workflow_id):
        return jsonify(psv_app.get_status(workflow_id))

    @app.route("/api/agents")
    def list_agents():
        from agents.registry import AgentRegistry
        return jsonify({"agents": AgentRegistry.list_agents()})

    return app
