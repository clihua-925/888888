#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""启动前验证 - 12项检查 v7.0.0"""
import sys
import os

VERSION = "7.0.0"
REQUIRED_CHECKS = 12

class StartupVerifier:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []

    def check(self, name, condition, error_msg):
        if condition:
            print(f"  [OK] {name}")
            self.passed += 1
        else:
            print(f"  [FAIL] {name}: {error_msg}")
            self.failed += 1
            self.errors.append(error_msg)
        return condition

    def run_all(self):
        print(f"PSV Trade OS v{VERSION} - 启动验证")
        print("=" * 50)

        # 1. Python版本
        self.check("Python版本", sys.version_info >= (3, 10), f"需要Python 3.10+, 当前{sys.version}")

        # 2. 虚拟环境
        in_venv = hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)
        self.check("虚拟环境", in_venv, "未检测到虚拟环境")

        # 3. 依赖检查
        required = ['langgraph', 'langchain', 'pydantic', 'sqlalchemy', 'flask', 'requests', 'alembic']
        missing = []
        for pkg in required:
            try:
                __import__(pkg)
            except ImportError:
                missing.append(pkg)
        self.check("核心依赖", len(missing) == 0, f"缺少依赖: {missing}")

        # 4. 目录结构
        required_dirs = ['agents', 'business', 'contracts', 'database', 'orchestrator', 'audit', 'state', 'shared', 'tests', 'webui']
        missing_dirs = [d for d in required_dirs if not os.path.isdir(d)]
        self.check("目录结构", len(missing_dirs) == 0, f"缺少目录: {missing_dirs}")

        # 5. 数据库文件
        db_file = os.path.join("data", "psv_trade_v7.db")
        self.check("数据库文件", os.path.exists(db_file), "数据库未初始化，运行 install.bat")

        # 6. LangGraph编译检查
        try:
            from orchestrator.graph import TradeOrchestrator
            orch = TradeOrchestrator()
            self.check("LangGraph编译", True, "")
        except Exception as e:
            self.check("LangGraph编译", False, str(e))

        # 7. Agent注册检查
        try:
            from agents.registry import AgentRegistry
            reg = AgentRegistry()
            agents = reg.list_agents()
            self.check("Agent注册", len(agents) >= 7, f"仅注册{len(agents)}个Agent")
        except Exception as e:
            self.check("Agent注册", False, str(e))

        # 8. Contract检查
        required_contracts = ['workflow_contract', 'agent_contract', 'task_contract', 'execution_contract', 'data_contract', 'message_contract']
        missing_contracts = [c for c in required_contracts if not os.path.exists(f"contracts/{c}.py")]
        self.check("Contract完整", len(missing_contracts) == 0, f"缺少: {missing_contracts}")

        # 9. State管理检查
        try:
            from state.manager import StateManager
            sm = StateManager()
            self.check("State管理", True, "")
        except Exception as e:
            self.check("State管理", False, str(e))

        # 10. Audit记录检查
        try:
            from audit.logger import AuditLogger
            from audit.repository import AuditRepository
            self.check("Audit系统", True, "")
        except Exception as e:
            self.check("Audit系统", False, str(e))

        # 11. Checkpoint恢复检查
        try:
            from orchestrator.checkpoint import CheckpointManager
            cm = CheckpointManager()
            self.check("Checkpoint系统", True, "")
        except Exception as e:
            self.check("Checkpoint系统", False, str(e))

        # 12. WebUI启动检查
        try:
            from webui.app import create_app
            self.check("WebUI模块", True, "")
        except Exception as e:
            self.check("WebUI模块", False, str(e))

        # 结果
        print("=" * 50)
        print(f"结果: {self.passed}/{REQUIRED_CHECKS} 通过")
        if self.failed > 0:
            print(f"错误:\n" + "\n".join(f"  - {e}" for e in self.errors))
            return False
        return True

if __name__ == "__main__":
    v = StartupVerifier()
    ok = v.run_all()
    sys.exit(0 if ok else 1)
