# -*- coding: utf-8 -*-
"""PSV Trade OS v7.0.0 - 统一入口

启动流程:
1. 加载配置
2. 初始化数据库(注入连接)
3. 初始化Repository
4. 初始化Business Service
5. 初始化审计系统
6. 初始化Agent注册表(注入Service)
7. 初始化LangGraph编排器
8. 启动WebUI(可选)
"""
import os
import sys
import argparse
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.config import settings
from database import init_database, get_session_factory
from database.repository import (
    CompanyRepository, TaskRepository, WorkflowRepository,
    AuditRepository, CustomerPoolRepository
)
from audit import AuditLogger
from agents.registry import AgentRegistry
from orchestrator import TradeOrchestrator
from state import StateManager

from business.collection.collector_service import CollectionService
from business.customer.discovery_service import CustomerDiscoveryService
from business.market.analysis_service import MarketAnalysisService
from business.scoring.lead_scorer import LeadScoringService
from business.strategy.development_strategy import DevelopmentStrategyService

class PSVTradeOS:
    """PSV Trade OS v7.0.0 主应用 - 完整依赖注入容器"""

    def __init__(self):
        self.orchestrator = None
        self.audit = None
        self.state_manager = StateManager()
        self._initialized = False
        self._repos = {}
        self._services = {}
        self._agents = {}

    def initialize(self):
        """初始化系统(按依赖顺序)"""
        if self._initialized:
            return

        print(f"初始化 {settings.APP_NAME} v{settings.APP_VERSION}")

        db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "psv_trade_v7.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        database_url = f"sqlite:///{db_path}"
        init_database(database_url, echo=settings.DEBUG)
        session_factory = get_session_factory()
        print(f"  [OK] 数据库初始化完成: {db_path}")

        company_repo = CompanyRepository(session_factory)
        task_repo = TaskRepository(session_factory)
        workflow_repo = WorkflowRepository(session_factory)
        audit_repo = AuditRepository(session_factory)
        pool_repo = CustomerPoolRepository(session_factory)
        self._repos = {
            "company": company_repo,
            "task": task_repo,
            "workflow": workflow_repo,
            "audit": audit_repo,
            "pool": pool_repo,
        }
        print("  [OK] Repository层初始化完成")

        collection_service = CollectionService(company_repo=company_repo)
        customer_service = CustomerDiscoveryService(company_repo=company_repo)
        market_service = MarketAnalysisService(company_repo=company_repo)
        scoring_service = LeadScoringService()
        strategy_service = DevelopmentStrategyService()
        self._services = {
            "collection": collection_service,
            "customer": customer_service,
            "market": market_service,
            "scoring": scoring_service,
            "strategy": strategy_service,
        }
        print("  [OK] Business Service层初始化完成")

        self.audit = AuditLogger(audit_repo, batch_size=settings.AUDIT_CONFIG["batch_size"])
        print("  [OK] 审计系统初始化完成")

        registry = AgentRegistry()
        from agents.company_discovery_agent.agent import CompanydiscoveryAgent
        from agents.market_research_agent.agent import MarketresearchAgent
        from agents.company_enrichment_agent.agent import CompanyenrichmentAgent
        from agents.contact_discovery_agent.agent import ContactdiscoveryAgent
        from agents.lead_scoring_agent.agent import LeadscoringAgent
        from agents.sales_strategy_agent.agent import SalesstrategyAgent
        from agents.report_agent.agent import ReportAgent
        from agents.trade_planner_agent.agent import TradePlannerAgent

        registry.register("company_discovery", lambda: CompanydiscoveryAgent(collection_service))
        registry.register("market_research", lambda: MarketresearchAgent(market_service))
        registry.register("company_enrichment", lambda: CompanyenrichmentAgent(customer_service))
        registry.register("contact_discovery", lambda: ContactdiscoveryAgent(customer_service))
        registry.register("lead_scoring", lambda: LeadscoringAgent(scoring_service))
        registry.register("sales_strategy", lambda: SalesstrategyAgent(strategy_service))
        registry.register("report", lambda: ReportAgent())
        registry.register("trade_planner", lambda: TradePlannerAgent())

        for agent_type in registry.list_agents():
            agent = registry.get_agent(agent_type)
            if agent and hasattr(agent, 'set_audit_logger'):
                agent.set_audit_logger(self.audit)

        print("  [OK] Agent注册表初始化完成(已注入Service)")

        self.orchestrator = TradeOrchestrator(
            checkpoint_manager=None,
            agent_registry=registry,
            checkpointer=None,
            audit_logger=self.audit,
            state_manager=self.state_manager,
        )
        print("  [OK] LangGraph编排器编译完成")

        self._initialized = True
        print(f"\n{settings.APP_NAME} v{settings.APP_VERSION} 就绪\n")

    def run_task(self, objective: str, product: str, market: str,
                 target_customer: str = "importer") -> Dict[str, Any]:
        """运行外贸任务"""
        if not self._initialized:
            self.initialize()

        from shared.utils import generate_id, now_iso
        task_id = generate_id("task_")
        task_data = {
            "task_id": task_id,
            "objective": objective,
            "product": product,
            "market": market,
            "target_customer": target_customer,
            "status": "running",
            "plan": [],
            "created_at": now_iso(),
            "updated_at": now_iso(),
        }
        self._repos["task"].save(task_data)

        final_state = self.orchestrator.run(
            task_id=task_id,
            objective=objective,
            product=product,
            market=market,
            target_customer=target_customer,
        )

        self._repos["task"].update_status(
            task_id=task_id,
            status=final_state.get("status", "completed"),
            current_step=final_state.get("current_step", 0),
        )

        return {
            "task_id": task_id,
            "workflow_id": final_state.get("workflow_id"),
            "status": final_state.get("status"),
            "result": final_state.get("final_report"),
            "agent_outputs": final_state.get("agent_outputs", []),
        }

    def get_status(self, workflow_id: str) -> Dict[str, Any]:
        """获取工作流状态"""
        state = self.state_manager.get(workflow_id)
        if not state:
            return {"error": "Workflow not found"}
        return {
            "workflow_id": workflow_id,
            "status": state.get("status"),
            "current_node": state.get("current_node"),
            "current_step": state.get("current_step"),
            "errors": state.get("errors", []),
        }

def main():
    parser = argparse.ArgumentParser(description="PSV Trade OS v7.0.0")
    parser.add_argument("--init-db", action="store_true", help="初始化数据库")
    parser.add_argument("--objective", type=str, help="任务目标")
    parser.add_argument("--product", type=str, help="产品名称")
    parser.add_argument("--market", type=str, help="目标市场")
    parser.add_argument("--target-customer", type=str, default="importer", help="客户类型")
    parser.add_argument("--webui", action="store_true", help="启动WebUI")
    parser.add_argument("--port", type=int, default=5000, help="WebUI端口")
    args = parser.parse_args()

    app = PSVTradeOS()

    if args.init_db:
        app.initialize()
        print("数据库初始化完成")
        return

    if args.objective and args.product and args.market:
        app.initialize()
        result = app.run_task(
            objective=args.objective,
            product=args.product,
            market=args.market,
            target_customer=args.target_customer,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.webui:
        app.initialize()
        from webui.app import create_app
        flask_app = create_app(app)
        flask_app.run(host="0.0.0.0", port=args.port, debug=settings.DEBUG)
        return

    parser.print_help()

if __name__ == "__main__":
    main()
