# -*- coding: utf-8 -*-
"""Audit Repository - 审计数据访问接口

注意: audit层不直接import database.models.
Repository实现由上层注入session_factory, 在运行时通过动态import访问模型.
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Callable
from .event import AuditEvent

class IAuditRepository(ABC):
    @abstractmethod
    def save_event(self, event: AuditEvent) -> str: ...
    @abstractmethod
    def get_by_trace(self, trace_id: str) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def get_by_workflow(self, workflow_id: str) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def get_by_task(self, task_id: str) -> List[Dict[str, Any]]: ...

class AuditRepository(IAuditRepository):
    """审计Repository实现 - 通过session_factory操作数据库"""

    def __init__(self, session_factory: Callable = None):
        self._session_factory = session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def save_event(self, event: AuditEvent) -> str:
        from database.models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            record = AuditEventModel(
                event_id=event.event_id,
                trace_id=event.trace_id,
                workflow_id=event.workflow_id,
                task_id=event.task_id,
                agent_id=event.agent_id,
                event_type=event.event_type,
                status=event.status,
                input_data=__import__("json").dumps(event.input_data, ensure_ascii=False) if event.input_data else None,
                output_data=__import__("json").dumps(event.output_data, ensure_ascii=False) if event.output_data else None,
                error_details=event.error_details,
                duration_sec=event.duration_sec,
                timestamp=event.timestamp,
                metadata_json=__import__("json").dumps(event.metadata, ensure_ascii=False) if event.metadata else None,
                node_name=event.node_name,
                tool_name=event.tool_name,
                retry_count=event.retry_count,
                schema_version=event.schema_version,
            )
            s.add(record)
            s.commit()
            return event.event_id
        finally:
            s.close()

    def get_by_trace(self, trace_id: str) -> List[Dict[str, Any]]:
        from database.models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            rows = s.query(AuditEventModel).filter(AuditEventModel.trace_id == trace_id).order_by(AuditEventModel.timestamp.desc()).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

    def get_by_workflow(self, workflow_id: str) -> List[Dict[str, Any]]:
        from database.models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            rows = s.query(AuditEventModel).filter(AuditEventModel.workflow_id == workflow_id).order_by(AuditEventModel.timestamp.desc()).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

    def get_by_task(self, task_id: str) -> List[Dict[str, Any]]:
        from database.models import AuditEvent as AuditEventModel
        s = self._session()
        try:
            rows = s.query(AuditEventModel).filter(AuditEventModel.task_id == task_id).order_by(AuditEventModel.timestamp.desc()).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()
