# -*- coding: utf-8 -*-
"""Audit Logger - 统一审计日志记录器

核心能力:
- workflow执行追踪
- agent执行日志
- 工具调用追踪
- 错误分析
- 批量flush
"""
import json
import time
from typing import Dict, List, Any, Optional
from datetime import datetime

from .event import AuditEvent
from .repository import IAuditRepository

class AuditLogger:
    """统一审计日志记录器 - 通过Repository Interface访问数据"""

    def __init__(self, repository: IAuditRepository, batch_size: int = 100):
        self._repository = repository
        self._batch_size = batch_size
        self._buffer: List[AuditEvent] = []

    def _flush(self, event: Optional[AuditEvent] = None):
        if event:
            self._buffer.append(event)
        if len(self._buffer) >= self._batch_size:
            self._save_all()

    def _save_all(self):
        for event in self._buffer:
            try:
                self._repository.save_event(event)
            except Exception as e:
                print(f"[Audit] Failed to save event {event.event_id}: {e}")
        self._buffer.clear()

    def flush(self):
        self._save_all()

    def log_workflow_start(self, trace_id: str, workflow_id: str, task_id: str, objective: str):
        event = AuditEvent(
            trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
            event_type="workflow_start", status="started",
            input_data={"objective": objective},
        )
        self._flush(event)

    def log_agent_call(self, trace_id: str, workflow_id: str, task_id: str,
                       agent_id: str, agent_type: str, input_data: Dict[str, Any], node_name: str = None):
        event = AuditEvent(
            trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
            agent_id=agent_id, event_type="agent_call", status="running",
            input_data=input_data, node_name=node_name,
        )
        self._flush(event)

    def log_agent_result(self, trace_id: str, workflow_id: str, task_id: str,
                         agent_id: str, agent_type: str, output_data: Dict[str, Any],
                         confidence: float, duration_sec: float, status: str):
        event = AuditEvent(
            trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
            agent_id=agent_id, event_type="agent_result", status=status,
            output_data=output_data, duration_sec=duration_sec,
            metadata={"confidence": confidence, "agent_type": agent_type},
        )
        self._flush(event)

    def log_checkpoint(self, trace_id: str, workflow_id: str, task_id: str,
                       checkpoint_id: str, node_name: str):
        event = AuditEvent(
            trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
            event_type="checkpoint", status="saved",
            input_data={"checkpoint_id": checkpoint_id, "node_name": node_name},
        )
        self._flush(event)

    def log_recovery(self, trace_id: str, workflow_id: str, task_id: str,
                     recovery_attempts: int, reason: str):
        event = AuditEvent(
            trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
            event_type="recovery", status="recovered",
            input_data={"recovery_attempts": recovery_attempts, "reason": reason},
        )
        self._flush(event)

    def log_error(self, trace_id: str, workflow_id: str, task_id: str,
                  agent_id: str, error: str, node_name: str = None):
        event = AuditEvent(
            trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
            agent_id=agent_id, event_type="error", status="failed",
            error_details=error, node_name=node_name,
        )
        self._flush(event)

    def log_workflow_complete(self, trace_id: str, workflow_id: str, task_id: str,
                              status: str, output_data: Dict[str, Any]):
        event = AuditEvent(
            trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
            event_type="task_complete", status=status,
            output_data=output_data,
        )
        self._flush(event)
        self.flush()
