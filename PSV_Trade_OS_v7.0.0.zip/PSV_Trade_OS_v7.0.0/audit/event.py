# -*- coding: utf-8 -*-
"""Audit Event - 审计事件定义"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class AuditEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    trace_id: str = Field(..., description="全链路追踪ID")
    workflow_id: str = Field(...)
    task_id: str = Field(...)
    agent_id: Optional[str] = None
    event_type: str = Field(..., description="workflow_start/agent_call/agent_result/tool_call/checkpoint/error/recovery/data_write/task_complete")
    status: str = Field(..., description="started/running/success/failed/completed/saved/recovered")
    input_data: Optional[Dict[str, Any]] = None
    output_data: Optional[Dict[str, Any]] = None
    error_details: Optional[str] = None
    duration_sec: float = Field(0.0, ge=0.0)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    node_name: Optional[str] = None
    tool_name: Optional[str] = None
    retry_count: int = Field(0, ge=0)
    schema_version: str = Field(default="2.1.0")
