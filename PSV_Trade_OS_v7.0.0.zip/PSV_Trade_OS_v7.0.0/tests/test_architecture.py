# -*- coding: utf-8 -*-
"""架构守护测试 - 防止循环依赖和违规导入 v7.0.0"""
import ast
import os
import pytest

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_all_py_files():
    py_files = []
    for root, dirs, files in os.walk(BASE_DIR):
        dirs[:] = [d for d in dirs if d not in ['venv', '__pycache__', '.git', 'data']]
        for f in files:
            if f.endswith('.py'):
                py_files.append(os.path.join(root, f))
    return py_files

def parse_imports(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ''
            imports.append(module)
    return imports

class TestArchitecture:
    """架构规范守护测试"""

    def test_database_no_upper_imports(self):
        """database层禁止导入business/agents/orchestrator/shared"""
        forbidden = ['business', 'agents', 'orchestrator', 'shared']
        db_dir = os.path.join(BASE_DIR, 'database')
        for root, _, files in os.walk(db_dir):
            for f in files:
                if not f.endswith('.py'):
                    continue
                filepath = os.path.join(root, f)
                imports = parse_imports(filepath)
                for imp in imports:
                    for fbd in forbidden:
                        if imp.startswith(fbd):
                            pytest.fail(f"database/{f} 违规导入: {imp}")

    def test_shared_no_upper_imports(self):
        """shared层禁止导入database/business/agents/orchestrator"""
        forbidden = ['database', 'business', 'agents', 'orchestrator', 'audit']
        shared_dir = os.path.join(BASE_DIR, 'shared')
        for root, _, files in os.walk(shared_dir):
            for f in files:
                if not f.endswith('.py'):
                    continue
                filepath = os.path.join(root, f)
                imports = parse_imports(filepath)
                for imp in imports:
                    for fbd in forbidden:
                        if imp.startswith(fbd):
                            pytest.fail(f"shared/{f} 违规导入: {imp}")

    def test_audit_no_direct_models(self):
        """audit层禁止在模块顶层导入database.models"""
        audit_dir = os.path.join(BASE_DIR, 'audit')
        for root, _, files in os.walk(audit_dir):
            for f in files:
                if not f.endswith('.py'):
                    continue
                filepath = os.path.join(root, f)
                with open(filepath, 'r', encoding='utf-8') as fh:
                    content = fh.read()
                if 'from database.models import' in content or 'import database.models' in content:
                    pytest.fail(f"audit/{f} 在顶层直接导入database.models")

    def test_contracts_purity(self):
        """contracts层应纯净, 不导入业务逻辑"""
        forbidden = ['business', 'agents', 'orchestrator', 'database', 'audit']
        contracts_dir = os.path.join(BASE_DIR, 'contracts')
        for root, _, files in os.walk(contracts_dir):
            for f in files:
                if not f.endswith('.py'):
                    continue
                filepath = os.path.join(root, f)
                imports = parse_imports(filepath)
                for imp in imports:
                    for fbd in forbidden:
                        if imp.startswith(fbd):
                            pytest.fail(f"contracts/{f} 违规导入: {imp}")

    def test_agent_structure(self):
        """每个Agent必须有agent.py/schema.py/tools.py/prompt.py"""
        agents_dir = os.path.join(BASE_DIR, 'agents')
        for agent_name in os.listdir(agents_dir):
            agent_path = os.path.join(agents_dir, agent_name)
            if not os.path.isdir(agent_path) or agent_name.startswith('_'):
                continue
            required = ['agent.py', 'schema.py', 'tools.py', 'prompt.py']
            for req in required:
                assert os.path.exists(os.path.join(agent_path, req)), f"{agent_name} 缺少 {req}"

    def test_langgraph_compile(self):
        """LangGraph必须能成功编译"""
        from orchestrator.graph import TradeOrchestrator
        orch = TradeOrchestrator()
        assert orch.graph is not None
