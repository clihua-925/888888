# -*- coding: utf-8 -*-
"""Orchestrator集成测试 v7.0.0"""
import pytest
from orchestrator.graph import TradeOrchestrator
from state import StateManager

class TestOrchestrator:
    def test_workflow_run(self):
        orch = TradeOrchestrator(state_manager=StateManager())
        result = orch.run(
            task_id="test_task_001",
            objective="测试任务",
            product="test product",
            market="USA",
        )
        assert result["workflow_id"].startswith("wf_")
        assert result["status"] in ["completed", "failed"]

    def test_workflow_state_persistence(self):
        sm = StateManager()
        orch = TradeOrchestrator(state_manager=sm)
        result = orch.run(
            task_id="test_task_002",
            objective="测试状态持久化",
            product="product",
            market="DE",
        )
        wf_id = result["workflow_id"]
        saved = sm.get(wf_id)
        assert saved is not None
        assert saved["task"]["task_id"] == "test_task_002"

    def test_checkpoint_save_and_rollback(self):
        sm = StateManager()
        orch = TradeOrchestrator(state_manager=sm)
        state = orch.state_manager.create_workflow("task_003", "obj", "prod", "CN")
        wf_id = state["workflow_id"]
        orch.state_manager.save_checkpoint(wf_id, "chk_1", {"current_step": 2, "agent_outputs": []})
        rolled = orch.state_manager.rollback_to(wf_id, "chk_1")
        assert rolled is not None
        assert rolled["last_checkpoint_id"] == "chk_1"
