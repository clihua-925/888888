# -*- coding: utf-8 -*-
"""Shared Layer - 仅提供公共能力, 禁止导入上层模块"""
from .config.settings import APP_NAME, APP_VERSION, SCHEMA_VERSION
from .utils.helpers import generate_id, now_iso

__all__ = ["APP_NAME", "APP_VERSION", "SCHEMA_VERSION", "generate_id", "now_iso"]
