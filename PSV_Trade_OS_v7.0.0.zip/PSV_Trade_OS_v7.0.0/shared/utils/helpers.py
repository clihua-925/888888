# -*- coding: utf-8 -*-
"""Shared Utilities - 纯工具函数"""
import uuid
import json
from datetime import datetime
from typing import Any

def generate_id(prefix: str = "id_") -> str:
    return f"{prefix}{uuid.uuid4().hex[:16]}"

def now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"

def safe_json_dumps(obj: Any) -> str:
    def _default(o):
        if isinstance(o, datetime):
            return o.isoformat()
        if hasattr(o, 'to_dict'):
            return o.to_dict()
        return str(o)
    return json.dumps(obj, ensure_ascii=False, default=_default)
