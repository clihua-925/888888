# -*- coding: utf-8 -*-
"""PSV Trade OS v7.0.0 - 全局配置"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent

APP_NAME = "PSV Trade OS"
APP_VERSION = "7.0.0"
SCHEMA_VERSION = "2.1.0"

DEBUG = os.getenv("PSV_DEBUG", "false").lower() == "true"

DATABASE_URL = os.getenv(
    "PSV_DATABASE_URL",
    f"sqlite:///{BASE_DIR / 'data' / 'psv_trade_v7.db'}"
)

AUDIT_CONFIG = {
    "batch_size": 100,
    "flush_interval_sec": 5,
}

LANGGRAPH_CONFIG = {
    "checkpoint_memory": True,
    "checkpoint_db": True,
    "max_recovery_attempts": 3,
    "retry_delay_sec": 2,
}

WEBUI_CONFIG = {
    "host": "0.0.0.0",
    "port": int(os.getenv("PSV_PORT", "5000")),
    "secret_key": os.getenv("PSV_SECRET_KEY", "psv-trade-os-v7-secret-key"),
}
