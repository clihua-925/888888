# -*- coding: utf-8 -*-
"""Shared Common Schema - 纯数据结构, 无业务逻辑"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class TraceContext(BaseModel):
    trace_id: str
    workflow_id: str
    task_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class PaginatedResult(BaseModel):
    items: List[Dict[str, Any]] = []
    total: int = 0
    page: int = 1
    page_size: int = 50

class ApiResponse(BaseModel):
    success: bool = True
    code: str = "OK"
    message: str = ""
    data: Optional[Dict[str, Any]] = None
    trace: Optional[TraceContext] = None
