# -*- coding: utf-8 -*-
"""Customer Discovery Service - 客户发现业务逻辑"""
from typing import Dict, List, Any, Optional
from database.repository import ICompanyRepository

class CustomerDiscoveryService:
    """客户发现服务"""

    def __init__(self, company_repo: ICompanyRepository = None):
        self.company_repo = company_repo

    def find_by_product(self, product: str, market: str, limit: int = 100) -> List[Dict[str, Any]]:
        """按产品查找客户"""
        if self.company_repo:
            all_companies = self.company_repo.list_all(limit=limit)
            return [c for c in all_companies if product.lower() in str(c.get("main_products", [])).lower()]
        return []

    def find_by_tier(self, tier: str, limit: int = 100) -> List[Dict[str, Any]]:
        """按等级查找客户"""
        if self.company_repo:
            all_companies = self.company_repo.list_all(limit=limit)
            return [c for c in all_companies if c.get("customer_tier") == tier]
        return []
