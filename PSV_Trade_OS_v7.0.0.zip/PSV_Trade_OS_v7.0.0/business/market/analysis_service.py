# -*- coding: utf-8 -*-
"""Market Analysis Service - 市场分析业务逻辑"""
from typing import Dict, List, Any
from database.repository import ICompanyRepository

class MarketAnalysisService:
    """市场分析服务"""

    def __init__(self, company_repo: ICompanyRepository = None):
        self.company_repo = company_repo

    def analyze_market(self, market: str, product: str) -> Dict[str, Any]:
        """分析市场"""
        companies = []
        if self.company_repo:
            companies = self.company_repo.list_by_country(market, limit=1000)

        total = len(companies)
        high_score = sum(1 for c in companies if c.get("credibility_score", 0) > 60)
        competition = "high" if total > 50 else "medium" if total > 20 else "low"

        return {
            "country_code": market,
            "market_size": total * 1000000 if total else 0,
            "competition_level": competition,
            "total_companies": total,
            "high_score_companies": high_score,
            "major_players": sorted(companies, key=lambda x: x.get("credibility_score", 0), reverse=True)[:10],
        }
