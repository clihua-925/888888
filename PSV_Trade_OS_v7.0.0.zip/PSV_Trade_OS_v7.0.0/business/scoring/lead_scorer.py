# -*- coding: utf-8 -*-
"""Lead Scoring Service - 客户评分业务逻辑"""
from typing import Dict, List, Any

class LeadScoringService:
    """客户评分服务"""

    def calculate_score(self, company: Dict[str, Any]) -> Dict[str, Any]:
        """计算客户评分"""
        credibility = company.get("credibility_score", 50)
        match = company.get("match_score", 0.5)
        deal = company.get("deal_probability", 0.4)

        overall = (credibility * 0.4 + match * 100 * 0.3 + deal * 100 * 0.3)

        if overall >= 80:
            tier = "S"
        elif overall >= 60:
            tier = "A"
        elif overall >= 40:
            tier = "B"
        elif overall >= 20:
            tier = "C"
        else:
            tier = "D"

        return {
            "company_name": company.get("name"),
            "overall_score": overall,
            "match_degree": match,
            "deal_probability": deal,
            "purchase_likelihood": 0.5,
            "company_strength": 0.6,
            "tier": tier,
            "priority": int(overall),
        }

    def batch_score(self, companies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """批量评分"""
        return [self.calculate_score(c) for c in companies]
