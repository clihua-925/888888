# -*- coding: utf-8 -*-
"""Development Strategy Service - 开发策略业务逻辑"""
from typing import Dict, List, Any

class DevelopmentStrategyService:
    """开发策略服务"""

    def generate_strategy(self, company: Dict[str, Any], score: Dict[str, Any]) -> Dict[str, Any]:
        """生成开发策略"""
        tier = score.get("tier", "D")

        strategies = {
            "S": {"approach": "VIP开发", "channel": "视频会议+样品", "frequency": "每周"},
            "A": {"approach": "重点开发", "channel": "邮件+电话", "frequency": "每两周"},
            "B": {"approach": "标准开发", "channel": "邮件", "frequency": "每月"},
            "C": {"approach": "批量开发", "channel": "邮件列表", "frequency": "每季度"},
            "D": {"approach": "观察", "channel": "自动化", "frequency": "每半年"},
        }

        return {
            "company_name": company.get("name"),
            "tier": tier,
            "strategy": strategies.get(tier, strategies["D"]),
            "next_action": "发送开发信" if tier in ["S", "A", "B"] else "加入 nurturing 序列",
        }

    def batch_strategy(self, companies: List[Dict[str, Any]], scores: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """批量生成策略"""
        return [self.generate_strategy(c, s) for c, s in zip(companies, scores)]
