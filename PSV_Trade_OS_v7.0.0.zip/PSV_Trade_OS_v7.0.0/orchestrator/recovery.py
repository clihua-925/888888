# -*- coding: utf-8 -*-
"""Recovery Coordinator - 恢复协调器 v7.0.0

支持:
- 任务任意节点中断后恢复
- 状态恢复
- 重试策略
- 失败降级
"""
from typing import Dict, Any, Optional

class RecoveryCoordinator:
    """恢复协调器"""

    def __init__(self, checkpoint_manager=None):
        self.checkpoint = checkpoint_manager
        self.max_recovery_attempts = 3

    def attempt_resume(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """尝试恢复任务"""
        task_id = state.get("task", {}).get("task_id", "")
        recovery_attempts = state.get("recovery_attempts", 0)

        if recovery_attempts >= self.max_recovery_attempts:
            state["status"] = "failed"
            state["should_continue"] = False
            state["current_node"] = "finalize"
            return state

        if self.checkpoint:
            checkpoint = self.checkpoint.load(task_id)
            if checkpoint:
                state["current_step"] = checkpoint.get("current_step", 0)
                state["agent_outputs"] = checkpoint.get("agent_outputs", [])
                state["reviews"] = checkpoint.get("reviews", [])
                state["errors"] = checkpoint.get("errors", [])
                state["recovery_attempts"] = recovery_attempts + 1
                state["should_continue"] = True
                state["current_node"] = "supervisor"
                state["last_checkpoint_id"] = checkpoint.get("checkpoint_id")
                return state

        state["recovery_attempts"] = recovery_attempts + 1
        state["should_continue"] = True
        state["current_node"] = "supervisor"
        return state

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return self.attempt_resume(state)
