# -*- coding: utf-8 -*-
"""Router Agent - 路由决策Agent v7.0.0

职责:
- 根据状态选择下一节点
- 智能路由决策
"""
from typing import Dict, Any

class RouterAgent:
    """Router Agent - 工作流路由决策器"""

    def __init__(self):
        self.agent_type = "router"

    def route(self, state: Dict[str, Any]) -> str:
        """根据当前状态返回下一节点名称"""
        errors = state.get("errors", [])
        current_step = state.get("current_step", 0)
        plan = state.get("plan", [])
        should_pause = state.get("should_pause", False)
        recovery_attempts = state.get("recovery_attempts", 0)

        if len(errors) > 3 and recovery_attempts < 3:
            return "recovery"

        if should_pause:
            return "checkpoint"

        if current_step >= len(plan):
            return "finalize"

        return "executor"

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        state["router_decision"] = self.route(state)
        return state
