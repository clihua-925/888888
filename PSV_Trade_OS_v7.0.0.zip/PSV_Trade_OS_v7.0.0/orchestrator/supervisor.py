# -*- coding: utf-8 -*-
"""Supervisor Agent - 监督执行Agent v7.0.0

职责:
- 任务理解
- Agent调度
- 流程控制
- 异常处理
"""
from typing import Dict, List, Any
from shared.utils import now_iso

class SupervisorAgent:
    """Supervisor Agent - 工作流监督器"""

    def __init__(self):
        self.agent_type = "supervisor"

    def supervise(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """监督当前状态, 决定下一步行动"""
        current_step = state.get("current_step", 0)
        plan = state.get("plan", [])
        errors = state.get("errors", [])

        if current_step >= len(plan):
            state["should_continue"] = False
            state["current_node"] = "finalize"
            return state

        if len(errors) > 3:
            state["should_continue"] = False
            state["status"] = "failed"
            state["current_node"] = "recovery"
            return state

        step = plan[current_step]
        state["current_node"] = step.get("agent", "unknown")
        state["current_agent"] = step.get("agent", "unknown")
        state["should_continue"] = True

        input_data = self._resolve_dependencies(step, state)
        state["current_input"] = input_data

        return state

    def _resolve_dependencies(self, step: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """解析步骤间的数据依赖"""
        input_data = step.get("input", {}).copy()
        outputs = state.get("agent_outputs", [])

        for key, val in list(input_data.items()):
            if val == "from_step_0" and len(outputs) >= 1:
                input_data[key] = outputs[0].get("result", {})
            elif val == "from_step_1" and len(outputs) >= 2:
                input_data[key] = outputs[1].get("result", {})
            elif val == "from_step_2" and len(outputs) >= 3:
                input_data[key] = outputs[2].get("result", {})
            elif val == "from_step_3" and len(outputs) >= 4:
                input_data[key] = outputs[3].get("result", {})
            elif val == "from_step_4" and len(outputs) >= 5:
                input_data[key] = outputs[4].get("result", {})
            elif val == "from_step_5" and len(outputs) >= 6:
                input_data[key] = outputs[5].get("result", {})
            elif val == "aggregated":
                aggregated = {}
                for i, out in enumerate(outputs):
                    aggregated[f"step_{i}"] = out
                input_data[key] = aggregated

        return input_data

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return self.supervise(state)
