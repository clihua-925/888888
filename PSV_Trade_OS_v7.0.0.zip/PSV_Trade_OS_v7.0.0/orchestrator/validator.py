# -*- coding: utf-8 -*-
"""Workflow Validator - 工作流校验器 v7.0.0"""
from typing import Dict, Any, List

class WorkflowValidator:
    """工作流校验器"""

    def validate_plan(self, plan: List[Dict[str, Any]]) -> bool:
        """校验执行计划"""
        if not plan:
            return False
        step_numbers = [p.get("step_number", -1) for p in plan]
        return step_numbers == list(range(len(plan)))

    def validate_state(self, state: Dict[str, Any]) -> bool:
        """校验状态完整性"""
        required_keys = ["workflow_id", "task", "plan", "current_step"]
        return all(k in state for k in required_keys)

    def validate_contract(self, state: Dict[str, Any]) -> bool:
        """校验契约版本"""
        return state.get("schema_version") == "2.1.0"
