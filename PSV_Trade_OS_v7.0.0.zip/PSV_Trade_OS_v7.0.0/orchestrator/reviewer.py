# -*- coding: utf-8 -*-
"""Reviewer Agent - 结果评审Agent v7.0.0

职责:
- 结果检查
- 质量评估
- 决定是否通过/重试/失败
"""
from typing import Dict, Any

class ReviewerAgent:
    """Reviewer Agent - 质量评审器"""

    def __init__(self):
        self.agent_type = "reviewer"
        self.quality_threshold = 0.5

    def review(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """评审最近一次Agent执行结果"""
        outputs = state.get("agent_outputs", [])
        if not outputs:
            state["reviews"] = state.get("reviews", []) + [{
                "quality_score": 1.0,
                "passed": True,
                "reason": "无输出需要评审",
                "retry_count": 0,
            }]
            return state

        last = outputs[-1]
        agent_type = last.get("agent_type", "unknown")
        confidence = last.get("confidence", 0.0)
        status = last.get("status", "failed")
        error = last.get("error")

        quality_score = 0.0
        passed = False
        reason = ""

        if status == "failed":
            quality_score = 0.0
            passed = False
            reason = f"Agent {agent_type} 执行失败: {error}"
        elif confidence < 0.3:
            quality_score = 0.2
            passed = False
            reason = f"Agent {agent_type} 置信度过低: {confidence}"
        elif confidence < 0.6:
            quality_score = 0.5
            passed = True
            reason = f"Agent {agent_type} 置信度中等, 勉强通过"
        else:
            quality_score = confidence
            passed = True
            reason = f"Agent {agent_type} 执行通过, 置信度: {confidence}"

        reviews = state.get("reviews", [])
        retry_count = sum(1 for r in reviews if r.get("agent_type") == agent_type and not r.get("passed", True))

        review_record = {
            "agent_type": agent_type,
            "quality_score": quality_score,
            "passed": passed,
            "reason": reason,
            "retry_count": retry_count,
            "confidence": confidence,
            "status": status,
        }

        state["reviews"] = reviews + [review_record]
        state["current_node"] = "reviewer"

        if not passed and retry_count < 3:
            state["should_retry"] = True
        else:
            state["should_retry"] = False

        return state

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return self.review(state)
