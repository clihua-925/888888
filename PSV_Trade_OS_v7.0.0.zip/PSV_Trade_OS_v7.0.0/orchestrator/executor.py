# -*- coding: utf-8 -*-
"""Executor Agent - 执行器Agent v7.0.0

职责:
- 调用具体业务Agent
- 管理Agent生命周期
- 注入AuditLogger
"""
from typing import Dict, Any
import time

from contracts.agent_contract import AgentRequest, AgentResponse
from agents.registry import AgentRegistry

class ExecutorAgent:
    """Executor Agent - Agent执行器"""

    def __init__(self, registry: AgentRegistry = None, audit=None):
        self.registry = registry or AgentRegistry()
        self.agent_type = "executor"
        self.audit = audit

    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """执行当前步骤的Agent"""
        current_step = state.get("current_step", 0)
        plan = state.get("plan", [])
        task = state.get("task", {})
        trace_id = state.get("trace_id", "")
        workflow_id = state.get("workflow_id", "")

        if current_step >= len(plan):
            state["should_continue"] = False
            return state

        step = plan[current_step]
        agent_type = step.get("agent")
        input_data = state.get("current_input", step.get("input", {}))
        task_id = task.get("task_id", "unknown")

        agent = self.registry.get_agent(agent_type)
        if not agent:
            error = f"未知Agent类型: {agent_type}"
            state["errors"] = state.get("errors", []) + [error]
            state["current_step"] = current_step + 1
            return state

        if self.audit and hasattr(agent, 'set_audit_logger'):
            agent.set_audit_logger(self.audit)

        request = AgentRequest(
            task_id=task_id,
            agent_type=agent_type,
            input_data=input_data,
            context={"step": current_step, "plan": plan, "workflow_id": workflow_id},
            trace_id=trace_id,
            workflow_id=workflow_id,
        )

        try:
            response = agent.execute(request)

            state["agent_outputs"] = state.get("agent_outputs", []) + [{
                "agent_type": agent_type,
                "result": response.result,
                "confidence": response.confidence,
                "status": response.status,
                "duration_sec": response.duration_sec,
                "error": response.error,
            }]
            state["current_step"] = current_step + 1
            state["current_node"] = "executor"

            if "task" in state:
                state["task"]["agent_outputs"] = state["agent_outputs"]

        except Exception as e:
            error = f"{agent_type}: {str(e)}"
            state["errors"] = state.get("errors", []) + [error]
            state["agent_outputs"] = state.get("agent_outputs", []) + [{
                "agent_type": agent_type,
                "result": {},
                "confidence": 0.0,
                "status": "failed",
                "error": str(e),
            }]

        return state

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return self.execute(state)
