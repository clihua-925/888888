# -*- coding: utf-8 -*-
"""Checkpoint Manager - 检查点管理 v7.0.0

支持:
- 保存
- 恢复
- 回滚
- 重试
"""
import json
import time
from typing import Dict, Any, Optional

from database.repository import IWorkflowRepository, ITaskRepository

class CheckpointManager:
    """检查点管理器"""

    def __init__(self, workflow_repo: IWorkflowRepository = None, task_repo: ITaskRepository = None):
        self.workflow_repo = workflow_repo
        self.task_repo = task_repo

    def save(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """保存检查点"""
        task_id = state.get("task", {}).get("task_id", "")
        workflow_id = state.get("workflow_id", "")
        current_step = state.get("current_step", 0)
        node_name = state.get("current_node", f"step_{current_step}")

        checkpoint_id = f"chk_{task_id}_{node_name}_{int(time.time())}"
        checkpoint_data = {
            "checkpoint_id": checkpoint_id,
            "task_id": task_id,
            "workflow_id": workflow_id,
            "node_name": node_name,
            "current_step": current_step,
            "agent_outputs": state.get("agent_outputs", []),
            "reviews": state.get("reviews", []),
            "errors": state.get("errors", []),
            "timestamp": time.time(),
            "version": "7.0.0",
        }

        if self.workflow_repo:
            try:
                self.workflow_repo.save_checkpoint(
                    task_id=task_id,
                    workflow_id=workflow_id,
                    checkpoint_data=json.dumps(checkpoint_data, ensure_ascii=False, default=str),
                    graph_state=json.dumps(state, ensure_ascii=False, default=str),
                )
            except Exception as e:
                print(f"[Checkpoint] Save failed: {e}")

        state["checkpoints"] = state.get("checkpoints", []) + [checkpoint_id]
        state["last_checkpoint_id"] = checkpoint_id
        state["current_node"] = "checkpoint"

        return state

    def load(self, task_id: str) -> Optional[Dict[str, Any]]:
        """加载检查点"""
        if not self.workflow_repo:
            return None
        try:
            workflow = self.workflow_repo.get_by_task(task_id)
            if workflow and workflow.get("checkpoint_data"):
                return json.loads(workflow["checkpoint_data"])
        except Exception as e:
            print(f"[Checkpoint] Load failed: {e}")
        return None

    def can_resume(self, task_id: str) -> bool:
        """检查是否可以恢复"""
        return self.load(task_id) is not None

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return self.save(state)
