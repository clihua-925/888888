# -*- coding: utf-8 -*-
"""LangGraph Orchestrator - 核心运行引擎 v7.0.0

完整流程:
User Intent -> Planner -> Supervisor -> Router -> Executor -> Reviewer -> Checkpoint -> (循环) -> Finalize

支持: 暂停/恢复/继续执行/失败恢复
"""
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from typing import Dict, Any

from .planner import PlannerAgent
from .supervisor import SupervisorAgent
from .router import RouterAgent
from .executor import ExecutorAgent
from .reviewer import ReviewerAgent
from .checkpoint import CheckpointManager
from .recovery import RecoveryCoordinator
from .validator import WorkflowValidator
from state import WorkflowState, create_initial_workflow_state

class TradeOrchestrator:
    """贸易智能编排器 - LangGraph核心 v7.0.0"""

    def __init__(self, checkpoint_manager=None, agent_registry=None, checkpointer=None,
                 audit_logger=None, state_manager=None):
        self.planner = PlannerAgent()
        self.supervisor = SupervisorAgent()
        self.router = RouterAgent()
        self.executor = ExecutorAgent(registry=agent_registry, audit=audit_logger)
        self.reviewer = ReviewerAgent()
        self.checkpoint = checkpoint_manager or CheckpointManager()
        self.recovery = RecoveryCoordinator(checkpoint_manager)
        self.validator = WorkflowValidator()
        self.checkpointer = checkpointer or MemorySaver()
        self.audit = audit_logger
        self.state_manager = state_manager
        self.graph = self._build_graph()

    def _build_graph(self):
        workflow = StateGraph(WorkflowState)

        workflow.add_node("planner", self._node_planner)
        workflow.add_node("supervisor", self._node_supervisor)
        workflow.add_node("router", self._node_router)
        workflow.add_node("executor", self._node_executor)
        workflow.add_node("reviewer", self._node_reviewer)
        workflow.add_node("checkpoint", self._node_checkpoint)
        workflow.add_node("finalize", self._node_finalize)
        workflow.add_node("recovery", self._node_recovery)

        workflow.set_entry_point("planner")
        workflow.add_edge("planner", "supervisor")
        workflow.add_edge("supervisor", "router")

        workflow.add_conditional_edges(
            "router",
            self._router_decision,
            {
                "executor": "executor",
                "checkpoint": "checkpoint",
                "recovery": "recovery",
                "finalize": "finalize",
            }
        )

        workflow.add_edge("executor", "reviewer")

        workflow.add_conditional_edges(
            "reviewer",
            self._review_decision,
            {
                "checkpoint": "checkpoint",
                "supervisor": "supervisor",
                "recovery": "recovery",
            }
        )

        workflow.add_conditional_edges(
            "checkpoint",
            self._checkpoint_decision,
            {
                "supervisor": "supervisor",
                "finalize": "finalize",
            }
        )

        workflow.add_edge("recovery", "supervisor")

        return workflow.compile(checkpointer=self.checkpointer)

    def _node_planner(self, state: WorkflowState) -> WorkflowState:
        result = self.planner(state)
        result["current_node"] = "planner"
        return result

    def _node_supervisor(self, state: WorkflowState) -> WorkflowState:
        result = self.supervisor(state)
        result["current_node"] = "supervisor"
        return result

    def _node_router(self, state: WorkflowState) -> WorkflowState:
        result = self.router(state)
        result["current_node"] = "router"
        return result

    def _node_executor(self, state: WorkflowState) -> WorkflowState:
        result = self.executor(state)
        result["current_node"] = "executor"
        return result

    def _node_reviewer(self, state: WorkflowState) -> WorkflowState:
        result = self.reviewer(state)
        result["current_node"] = "reviewer"
        return result

    def _node_checkpoint(self, state: WorkflowState) -> WorkflowState:
        result = self.checkpoint.save(state)
        result["current_node"] = "checkpoint"
        return result

    def _node_recovery(self, state: WorkflowState) -> WorkflowState:
        result = self.recovery(state)
        result["current_node"] = "recovery"
        return result

    def _node_finalize(self, state: WorkflowState) -> WorkflowState:
        state["status"] = "completed" if not state.get("errors") else "failed"
        state["should_continue"] = False
        state["current_node"] = "finalize"
        if self.state_manager and state.get("workflow_id"):
            self.state_manager.update(state["workflow_id"], state)
        if self.audit:
            self.audit.log_workflow_complete(
                trace_id=state.get("trace_id", ""),
                workflow_id=state.get("workflow_id", ""),
                task_id=state.get("task", {}).get("task_id", ""),
                status=state["status"],
                output_data={"final_report": state.get("final_report")},
            )
        return state

    def _router_decision(self, state: WorkflowState) -> str:
        if not state.get("should_continue", False):
            return "finalize"
        if state.get("should_pause", False):
            return "checkpoint"
        if len(state.get("errors", [])) > 3 and state.get("recovery_attempts", 0) < 3:
            return "recovery"
        return "executor"

    def _review_decision(self, state: WorkflowState) -> str:
        if state.get("should_retry", False) and state.get("recovery_attempts", 0) < 3:
            return "supervisor"
        if len(state.get("errors", [])) > 3:
            return "recovery"
        return "checkpoint"

    def _checkpoint_decision(self, state: WorkflowState) -> str:
        if not state.get("should_continue", False):
            return "finalize"
        return "supervisor"

    def run(self, task_id: str, objective: str, product: str, market: str,
            target_customer: str = "importer", config: Dict[str, Any] = None) -> WorkflowState:
        """运行完整工作流"""
        initial_state = create_initial_workflow_state(
            task_id=task_id, objective=objective, product=product,
            market=market, target_customer=target_customer
        )
        if self.state_manager:
            self.state_manager._memory[initial_state["workflow_id"]] = initial_state

        if self.audit:
            self.audit.log_workflow_start(
                trace_id=initial_state["trace_id"],
                workflow_id=initial_state["workflow_id"],
                task_id=task_id,
                objective=objective,
            )

        run_config = config or {}
        if "configurable" not in run_config:
            run_config["configurable"] = {}
        run_config["configurable"]["thread_id"] = initial_state["workflow_id"]

        final_state = self.graph.invoke(initial_state, config=run_config)
        return final_state

    def resume(self, workflow_id: str, config: Dict[str, Any] = None) -> WorkflowState:
        """恢复暂停的工作流"""
        state = self.state_manager.get(workflow_id) if self.state_manager else None
        if not state:
            raise ValueError(f"Workflow {workflow_id} not found")
        state["should_pause"] = False
        state["should_continue"] = True

        run_config = config or {}
        run_config["configurable"] = run_config.get("configurable", {})
        run_config["configurable"]["thread_id"] = workflow_id

        return self.graph.invoke(state, config=run_config)
