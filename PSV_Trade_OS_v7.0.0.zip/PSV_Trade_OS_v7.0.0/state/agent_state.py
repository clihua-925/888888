# -*- coding: utf-8 -*-
"""AgentState - Agent状态管理"""
from typing import Dict, List, Any, Optional
from datetime import datetime

class AgentStateManager:
    """Agent状态管理器"""

    @staticmethod
    def create(agent_type: str, agent_id: str = None) -> Dict[str, Any]:
        from shared.utils import generate_id, now_iso
        return {
            "agent_id": agent_id or generate_id("agent_"),
            "agent_type": agent_type,
            "status": "idle",
            "input": {},
            "output": {},
            "error": None,
            "retry_count": 0,
            "duration_sec": 0.0,
            "timestamp": now_iso(),
            "confidence": 0.0,
        }

    @staticmethod
    def update(state: Dict[str, Any], status: str, output: Dict[str, Any] = None, 
               error: str = None, duration: float = 0.0, confidence: float = 0.0) -> Dict[str, Any]:
        from shared.utils import now_iso
        state["status"] = status
        state["timestamp"] = now_iso()
        if output is not None:
            state["output"] = output
        if error:
            state["error"] = error
        if duration:
            state["duration_sec"] = duration
        if confidence:
            state["confidence"] = confidence
        return state
