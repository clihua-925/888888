# -*- coding: utf-8 -*-
"""TaskState - 任务状态管理"""
from typing import Dict, List, Any, Optional
from datetime import datetime

class TaskStateManager:
    """任务状态管理器"""

    @staticmethod
    def create_task(objective: str, product: str, market: str, 
                    target_customer: str = "importer") -> Dict[str, Any]:
        from shared.utils import generate_id, now_iso
        return {
            "task_id": generate_id("task_"),
            "objective": objective,
            "product": product,
            "market": market,
            "target_customer": target_customer,
            "status": "pending",
            "current_node": None,
            "plan": [],
            "result_summary": None,
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "retry_count": 0,
            "max_retries": 3,
        }

    @staticmethod
    def update_status(task: Dict[str, Any], status: str, node: str = None) -> Dict[str, Any]:
        from shared.utils import now_iso
        task["status"] = status
        task["updated_at"] = now_iso()
        if node:
            task["current_node"] = node
        if status in ["completed", "failed"]:
            task["completed_at"] = now_iso()
        return task

    @staticmethod
    def add_error(task: Dict[str, Any], error: str) -> Dict[str, Any]:
        if "errors" not in task:
            task["errors"] = []
        task["errors"].append({"error": error, "timestamp": datetime.utcnow().isoformat()})
        task["retry_count"] = task.get("retry_count", 0) + 1
        return task
