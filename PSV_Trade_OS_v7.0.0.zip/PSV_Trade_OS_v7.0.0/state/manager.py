# -*- coding: utf-8 -*-
"""State Manager - 统一状态管理器 v7.0.0"""
from typing import Dict, List, Any, Optional
import json
from .workflow_state import WorkflowState
from .task_state import TaskStateManager
from .agent_state import AgentStateManager

class StateManager:
    """状态管理器 - 支持save/restore/rollback"""

    def __init__(self):
        self._memory: Dict[str, WorkflowState] = {}
        self._checkpoints: Dict[str, Dict[str, Any]] = {}

    def create_workflow(self, task_id: str, objective: str, product: str, market: str,
                        target_customer: str = "importer") -> WorkflowState:
        from .workflow_state import create_initial_workflow_state
        state = create_initial_workflow_state(task_id, objective, product, market, target_customer)
        self._memory[state["workflow_id"]] = state
        return state

    def get(self, workflow_id: str) -> Optional[WorkflowState]:
        return self._memory.get(workflow_id)

    def update(self, workflow_id: str, updates: Dict[str, Any]) -> Optional[WorkflowState]:
        state = self._memory.get(workflow_id)
        if not state:
            return None
        state.update(updates)
        self._memory[workflow_id] = state
        return state

    def save_checkpoint(self, workflow_id: str, checkpoint_id: str, data: Dict[str, Any]):
        if workflow_id not in self._checkpoints:
            self._checkpoints[workflow_id] = {}
        self._checkpoints[workflow_id][checkpoint_id] = json.loads(json.dumps(data, default=str))

    def rollback_to(self, workflow_id: str, checkpoint_id: str) -> Optional[WorkflowState]:
        """回滚到指定检查点"""
        state = self._memory.get(workflow_id)
        if not state:
            return None
        checkpoints = self._checkpoints.get(workflow_id, {})
        if checkpoint_id not in checkpoints:
            return None
        checkpoint_data = checkpoints[checkpoint_id]
        for key in ["current_step", "agent_outputs", "reviews", "errors", "status"]:
            if key in checkpoint_data:
                state[key] = checkpoint_data[key]
        state["last_checkpoint_id"] = checkpoint_id
        state["recovery_attempts"] = state.get("recovery_attempts", 0) + 1
        self._memory[workflow_id] = state
        return state

    def list_checkpoints(self, workflow_id: str) -> List[str]:
        return list(self._checkpoints.get(workflow_id, {}).keys())
