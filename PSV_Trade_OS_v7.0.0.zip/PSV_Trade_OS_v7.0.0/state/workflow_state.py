# -*- coding: utf-8 -*-
"""WorkflowState - 工作流状态管理 v7.0.0"""
from typing import Dict, List, Any, Optional, TypedDict
from datetime import datetime
import json

class AgentState(TypedDict, total=False):
    agent_id: str
    agent_type: str
    status: str  # idle / running / completed / failed
    input: Dict[str, Any]
    output: Dict[str, Any]
    error: Optional[str]
    retry_count: int
    duration_sec: float
    timestamp: str
    confidence: float

class TaskState(TypedDict, total=False):
    task_id: str
    objective: str
    product: str
    market: str
    target_customer: str
    status: str
    current_step: int
    plan: List[Dict[str, Any]]
    agent_outputs: List[Dict[str, Any]]
    errors: List[str]
    created_at: str
    updated_at: str
    completed_at: Optional[str]
    retry_count: int

class WorkflowState(TypedDict, total=False):
    workflow_id: str
    schema_version: str
    task: TaskState
    agents: Dict[str, AgentState]
    reviews: List[Dict[str, Any]]
    checkpoints: List[str]
    should_continue: bool
    should_pause: bool
    recovery_attempts: int
    final_report: Optional[str]
    context: Dict[str, Any]
    trace_id: str
    status: str
    current_node: str
    error_log: List[str]
    metadata: Dict[str, Any]
    current_step: int
    current_input: Dict[str, Any]
    agent_outputs: List[Dict[str, Any]]
    errors: List[str]
    should_retry: bool
    last_checkpoint_id: Optional[str]

def create_initial_workflow_state(task_id: str, objective: str, product: str, market: str,
                                   target_customer: str = "importer", workflow_id: str = None,
                                   trace_id: str = None) -> WorkflowState:
    """创建初始工作流状态"""
    from shared.utils import generate_id, now_iso
    return {
        "workflow_id": workflow_id or generate_id("wf_"),
        "schema_version": "2.1.0",
        "task": {
            "task_id": task_id,
            "objective": objective,
            "product": product,
            "market": market,
            "target_customer": target_customer,
            "status": "pending",
            "current_step": 0,
            "plan": [],
            "agent_outputs": [],
            "errors": [],
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "retry_count": 0,
        },
        "agents": {},
        "reviews": [],
        "checkpoints": [],
        "should_continue": True,
        "should_pause": False,
        "recovery_attempts": 0,
        "final_report": None,
        "context": {},
        "trace_id": trace_id or generate_id("trace_"),
        "status": "pending",
        "current_node": "planner",
        "error_log": [],
        "metadata": {
            "version": "7.0.0",
            "created_by": "TradeOrchestrator",
        },
        "current_step": 0,
        "current_input": {},
        "agent_outputs": [],
        "errors": [],
        "should_retry": False,
        "last_checkpoint_id": None,
    }
