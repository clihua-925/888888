# -*- coding: utf-8 -*-
"""PSV Engine Web UI API v45 (FULL)

三个页面职责彻底分离：
- /intelligence/*  → 客户情报中心
- /graph/*         → 贸易图谱
- /business/*      → 业务中心

禁止新旧路由并存。
所有按钮必须有真实后台功能。
"""
import json, time
from flask import Flask, request, jsonify
from core.memory.db import DB
from core.system import PSVSystem

app = Flask(__name__)
system = PSVSystem()


# ========== 健康检查 ==========
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'version': 'v45-full', 'timestamp': time.time()})


# ========== 情报中心 API ==========
@app.route('/api/intelligence/<norm>', methods=['GET'])
def get_intelligence(norm):
    """获取完整情报档案"""
    result = system.intelligence_center.get_intelligence(norm)
    return jsonify(result)

@app.route('/api/intelligence/<norm>/enrich', methods=['POST'])
def enrich_intelligence(norm):
    """触发情报补全"""
    data = request.get_json() or {}
    category_id = data.get('category_id')
    force = data.get('force', False)
    result = system.intelligence_center.enrich(norm, category_id=category_id, force=force)
    return jsonify(result)

@app.route('/api/intelligence/<norm>/validate', methods=['POST'])
def validate_intelligence(norm):
    """AI 验证中心"""
    result = system.intelligence_center.ai_validate(norm)
    return jsonify(result)

@app.route('/api/intelligence/<norm>/gaps', methods=['GET'])
def get_gaps(norm):
    """获取信息缺口和下一步建议"""
    intel = system.intelligence_center.get_intelligence(norm)
    if not intel['ok']:
        return jsonify(intel)
    return jsonify({
        'ok': True,
        'gaps': intel['data'].get('gaps', []),
        'next_steps': intel['data'].get('next_steps', []),
    })


# ========== 贸易图谱 API ==========
@app.route('/api/graph', methods=['GET'])
def get_graph():
    """获取贸易图谱"""
    center = request.args.get('center')
    category_id = request.args.get('category_id')
    depth = int(request.args.get('depth', 1))
    result = system.trade_graph.get_graph(center_norm=center, category_id=category_id, depth=depth)
    return jsonify(result)

@app.route('/api/graph/node/<norm>', methods=['GET'])
def get_node_detail(norm):
    """节点详情"""
    result = system.trade_graph.get_node_detail(norm)
    return jsonify(result)

@app.route('/api/graph/edge/<edge_id>', methods=['GET'])
def get_edge_detail(edge_id):
    """边详情"""
    result = system.trade_graph.get_edge_detail(edge_id)
    return jsonify(result)

@app.route('/api/graph/expansion-path/<norm>', methods=['GET'])
def get_expansion_path(norm):
    """节点扩张路径"""
    task_id = request.args.get('task_id')
    result = system.trade_graph.get_expansion_path(norm, task_id=task_id)
    return jsonify(result)


# ========== 网络扩张 API ==========
@app.route('/api/network/expand', methods=['POST'])
def expand_network():
    """启动网络扩张（唯一入口）"""
    data = request.get_json() or {}
    seed = data.get('seed')
    category_id = data.get('category_id')
    max_depth = int(data.get('max_depth', 3))
    resume_from = data.get('resume_from')

    if not seed:
        return jsonify({'ok': False, 'error': 'seed is required'}), 400

    try:
        result = system.expand_network(
            seed_norm=seed,
            category_id=category_id,
            max_depth=max_depth,
            resume_from=resume_from
        )
        return jsonify({'ok': True, 'result': result})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500

@app.route('/api/network/expand/<task_id>/status', methods=['GET'])
def get_expansion_status(task_id):
    """获取扩张任务状态"""
    task = system.get_task_status(task_id)
    if not task:
        return jsonify({'ok': False, 'error': 'Task not found'}), 404
    logs = system.db.get_task_logs(task_id, limit=50)
    gain_curve = system.db.get_info_gain_curve(task_id)
    return jsonify({
        'ok': True,
        'task': task,
        'logs': logs,
        'info_gain_curve': gain_curve,
    })

@app.route('/api/network/expand/<task_id>/pause', methods=['POST'])
def pause_expansion(task_id):
    system.pause_task(task_id)
    return jsonify({'ok': True})

@app.route('/api/network/expand/<task_id>/resume', methods=['POST'])
def resume_expansion(task_id):
    system.resume_task(task_id)
    return jsonify({'ok': True})


# ========== 业务中心 API ==========
@app.route('/api/business/qualify', methods=['POST'])
def qualify_lead():
    """检查开发资格"""
    data = request.get_json() or {}
    norm = data.get('norm')
    if not norm:
        return jsonify({'ok': False, 'error': 'norm is required'}), 400
    result = system.execution_center.qualify_for_development(norm)
    return jsonify({'ok': True, 'result': result})

@app.route('/api/business/development-letter', methods=['POST'])
def generate_letter():
    """生成开发信"""
    data = request.get_json() or {}
    norm = data.get('norm')
    our_product = data.get('our_product')
    our_company = data.get('our_company')
    if not norm:
        return jsonify({'ok': False, 'error': 'norm is required'}), 400
    result = system.execution_center.generate_development_letter(
        norm, our_product=our_product, our_company=our_company
    )
    return jsonify(result)

@app.route('/api/business/send', methods=['POST'])
def send_email():
    """执行发送"""
    data = request.get_json() or {}
    record_id = data.get('record_id')
    if not record_id:
        return jsonify({'ok': False, 'error': 'record_id is required'}), 400
    result = system.execution_center.open_outlook_and_send(record_id)
    return jsonify(result)

@app.route('/api/business/records', methods=['GET'])
def list_records():
    """获取执行记录"""
    entity_id = request.args.get('entity_id')
    status = request.args.get('status')
    records = system.db.get_execution_records(entity_id=entity_id, status=status)
    return jsonify({'ok': True, 'records': records})


# ========== 资源池 API ==========
@app.route('/api/pools/customers', methods=['GET'])
def list_customer_pool():
    category_id = request.args.get('category_id')
    pool = system.db.list_customer_pool(category_id=category_id)
    return jsonify({'ok': True, 'pool': pool})

@app.route('/api/pools/suppliers', methods=['GET'])
def list_supplier_pool():
    category_id = request.args.get('category_id')
    pool = system.db.list_supplier_pool(category_id=category_id)
    return jsonify({'ok': True, 'pool': pool})


# ========== 任务面板 API ==========
@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    status = request.args.get('status')
    task_type = request.args.get('type')
    category_id = request.args.get('category_id')
    tasks = system.db.list_tasks(status=status, task_type=task_type, category_id=category_id)
    return jsonify({'ok': True, 'tasks': tasks})

@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    task = system.get_task_status(task_id)
    if not task:
        return jsonify({'ok': False, 'error': 'Task not found'}), 404
    logs = system.db.get_task_logs(task_id)
    return jsonify({'ok': True, 'task': task, 'logs': logs})

@app.route('/api/tasks/<task_id>/pause', methods=['POST'])
def pause_task(task_id):
    system.pause_task(task_id)
    return jsonify({'ok': True})

@app.route('/api/tasks/<task_id>/resume', methods=['POST'])
def resume_task(task_id):
    system.resume_task(task_id)
    return jsonify({'ok': True})


# ========== 信息增益 API ==========
@app.route('/api/info-gain/<task_id>', methods=['GET'])
def get_info_gain(task_id):
    curve = system.db.get_info_gain_curve(task_id)
    return jsonify({'ok': True, 'curve': curve})

@app.route('/api/info-gain/<task_id>/latest', methods=['GET'])
def get_latest_info_gain(task_id):
    n = int(request.args.get('n', 3))
    latest = system.db.get_latest_info_gain(task_id, n_rounds=n)
    return jsonify({'ok': True, 'latest': latest})


# ========== 启动 ==========
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
