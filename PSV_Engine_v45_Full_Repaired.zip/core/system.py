# -*- coding: utf-8 -*-
"""PSV System Orchestrator v45 (FULL REPAIRED)

修复内容：
1. 删除重复的 run_network/run_node/run_dev_node 旧方法
2. 统一网络扩张入口为 expand_network()
3. 统一情报补全入口为 enrich_entity()
4. 统一业务开发入口为 start_development()
5. 主编排智能体拥有完整流程控制权
6. 支持任务状态管理和失败恢复（断点续跑）
7. 支持并行任务调度
8. 失败处理：分类错误 → 选择策略 → 记录总结
9. 扩张完成后自动调度补全任务
"""
import json, time, uuid
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from core.memory.db import DB
from core.intelligence.network_expansion import NetworkExpansionEngine
from core.intelligence.account_intelligence_center import AccountIntelligenceCenter
from core.intelligence.waterfall import WaterfallEnrichmentEngine
from core.business_execution.execution_center import BusinessExecutionCenter
from core.trade_graph.visualization import TradeGraphVisualization


class PSVSystem:
    """
    主编排智能体 / Orchestrator。

    职责：
    - 统一控制整个后半程流程
    - 调度网络扩张、情报补全、业务开发等任务
    - 管理任务状态和失败恢复
    - 禁止节点自行创建独立任务编排
    """

    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.expansion_engine = NetworkExpansionEngine(self.db)
        self.intelligence_center = AccountIntelligenceCenter(self.db)
        self.waterfall_engine = WaterfallEnrichmentEngine(self.db)
        self.execution_center = BusinessExecutionCenter(self.db)
        self.trade_graph = TradeGraphVisualization(self.db)
        self._executor = ThreadPoolExecutor(max_workers=4)

    # ========== 网络扩张（唯一入口） ==========
    def expand_network(self, seed_norm: str, category_id: str = None,
                       max_depth: int = 3, parent_task_id: str = None,
                       resume_from: str = None) -> Dict[str, Any]:
        """
        启动网络扩张任务。
        这是网络扩张的唯一入口。所有网络扩张必须通过此方法启动。
        支持从失败任务恢复（resume_from）。
        """
        task_id = resume_from or f"net-{uuid.uuid4().hex[:8]}"

        self.db.create_task(
            task_id=task_id,
            task_name=f"Network Expansion: {seed_norm}",
            task_type='network_expansion',
            category_id=category_id,
            parent_task_id=parent_task_id
        )

        self.db.save_task_log(task_id, 'orchestrator',
                             f"Orchestrator starting network expansion for {seed_norm}")

        try:
            result = self.expansion_engine.expand(
                seed_norm=seed_norm,
                task_id=task_id,
                category_id=category_id,
                max_depth=max_depth,
                resume_from=resume_from
            )

            # 扩张完成后，Orchestrator 决定下一步：自动补全新发现的节点
            if result.get('status') == 'completed':
                self._schedule_post_expansion_tasks(task_id, result, category_id)
                self.db.update_task(task_id, run_status='completed')
                self.db.save_task_log(task_id, 'orchestrator', 'Network expansion completed')
            elif result.get('status') == 'failed' and result.get('can_resume'):
                self.db.update_task(task_id, run_status='failed', failure_reason=result.get('error'))
                self.db.save_task_log(task_id, 'orchestrator_error', result.get('error'))

            return result

        except Exception as e:
            self._handle_failure(task_id, e, 'network_expansion')
            raise

    def _schedule_post_expansion_tasks(self, task_id: str, expansion_result: Dict,
                                      category_id: str):
        """
        扩张完成后，Orchestrator 调度后续补全任务。
        关键修复：不是由网络扩张引擎自行启动补全，而是由 Orchestrator 统一调度。
        """
        discovered_nodes = expansion_result.get('discovered_nodes', [])
        self.db.save_task_log(task_id, 'orchestrator',
                             f"Scheduling enrichment for {len(discovered_nodes)} discovered nodes")

        for node in discovered_nodes:
            norm = node.get('norm')
            if not norm:
                continue
            enrich_task_id = self.db.queue_intelligence_task(
                norm=norm,
                category_id=category_id,
                source_task_id=task_id
            )
            self.db.save_task_log(task_id, 'orchestrator',
                                 f"Scheduled enrichment task {enrich_task_id} for {norm}")

    # ========== 情报补全（唯一入口） ==========
    def enrich_entity(self, norm: str, category_id: str = None,
                     parent_task_id: str = None) -> Dict[str, Any]:
        """触发实体情报补全。统一入口，由 Orchestrator 调度执行。"""
        task_id = f"enrich-{uuid.uuid4().hex[:8]}"

        self.db.create_task(
            task_id=task_id,
            task_name=f"Enrichment: {norm}",
            task_type='waterfall_enrichment',
            category_id=category_id,
            parent_task_id=parent_task_id
        )

        self.db.save_task_log(task_id, 'orchestrator',
                             f"Orchestrator starting enrichment for {norm}")

        try:
            result = self.intelligence_center.enrich(
                norm=norm,
                category_id=category_id
            )
            self.db.update_task(task_id, run_status='completed',
                               enrichment_count=1)
            return result
        except Exception as e:
            self._handle_failure(task_id, e, 'waterfall_enrichment')
            raise

    def batch_enrich(self, norms: List[str], category_id: str = None) -> List[Dict]:
        """并行补全多个实体"""
        results = []
        futures = {}
        for norm in norms:
            future = self._executor.submit(self.enrich_entity, norm, category_id)
            futures[future] = norm

        for future in as_completed(futures):
            norm = futures[future]
            try:
                result = future.result()
                results.append({'norm': norm, 'ok': True, 'result': result})
            except Exception as e:
                results.append({'norm': norm, 'ok': False, 'error': str(e)})
        return results

    # ========== 业务开发（唯一入口） ==========
    def start_development(self, lead_norm: str, **kwargs) -> Dict[str, Any]:
        """
        启动业务开发流程。
        统一入口，检查开发资格后生成开发信。
        """
        task_id = f"dev-{uuid.uuid4().hex[:8]}"

        self.db.create_task(
            task_id=task_id,
            task_name=f"Development: {lead_norm}",
            task_type='business_development'
        )

        self.db.save_task_log(task_id, 'orchestrator',
                             f"Orchestrator starting development for {lead_norm}")

        try:
            # 检查开发资格
            qualification = self.execution_center.qualify_for_development(lead_norm)
            if not qualification.get('qualified', False):
                self.db.update_task(task_id, run_status='completed')
                return {
                    'task_id': task_id,
                    'qualified': False,
                    'reason': qualification.get('reason', 'Not qualified')
                }

            # 生成开发信
            letter = self.execution_center.generate_development_letter(
                lead_norm,
                our_product=kwargs.get('our_product'),
                our_company=kwargs.get('our_company')
            )

            if not letter.get('ok'):
                self.db.update_task(task_id, run_status='failed',
                                   failure_reason=letter.get('error'))
                return {'task_id': task_id, 'qualified': False, 'reason': letter.get('error')}

            # 创建执行记录
            entity = self.db.get_entity(lead_norm)
            record_id = self.db.create_execution_record(
                entity_id=entity.get('entity_id') if entity else None,
                execution_type='development_letter',
                task_id=task_id,
                draft_subject=letter.get('subject', ''),
                draft_body=letter.get('body', ''),
                personalized_content=letter.get('personalized', ''),
                recipient_email=letter.get('recipient', ''),
                used_intelligence=letter.get('used_intelligence', {}),
                used_evidence=letter.get('used_evidence', []),
                used_ai_model=letter.get('used_model', '')
            )

            self.db.update_task(task_id, run_status='completed', development_count=1)

            return {
                'task_id': task_id,
                'qualified': True,
                'record_id': record_id,
                'letter': letter
            }

        except Exception as e:
            self._handle_failure(task_id, e, 'business_development')
            raise

    # ========== 失败处理（分类 → 策略 → 记录） ==========
    def _handle_failure(self, task_id: str, error: Exception, node_type: str):
        """结构化失败处理"""
        error_msg = str(error)
        error_type = self._classify_error(error_msg)

        self.db.save_task_log(task_id, 'orchestrator_error',
                             f"[{error_type}] {error_msg}")
        self.db.update_task(task_id, run_status='failed', failure_reason=error_msg)

        # 根据错误类型决定策略
        strategy = self._decide_recovery_strategy(error_type)
        self.db.save_task_log(task_id, 'orchestrator',
                             f"Failure classified as {error_type}, strategy: {strategy}")

    def _classify_error(self, error_msg: str) -> str:
        msg = error_msg.lower()
        if 'timeout' in msg or 'connection' in msg:
            return 'temporary_error'
        elif 'api key' in msg or 'unauthorized' in msg or 'quota' in msg:
            return 'ai_unavailable'
        elif 'no such table' in msg or 'syntax error' in msg:
            return 'database_error'
        elif 'json' in msg or 'parse' in msg:
            return 'data_error'
        elif 'permission' in msg or 'access' in msg:
            return 'permission_error'
        else:
            return 'unknown_error'

    def _decide_recovery_strategy(self, error_type: str) -> str:
        strategies = {
            'temporary_error': 'retry_with_backoff',
            'ai_unavailable': 'switch_ai_provider',
            'database_error': 'check_schema_and_restart',
            'data_error': 'skip_and_log',
            'permission_error': 'skip_current_source',
            'unknown_error': 'manual_review',
        }
        return strategies.get(error_type, 'manual_review')

    # ========== 任务管理 ==========
    def get_task_status(self, task_id: str) -> Optional[Dict]:
        return self.db.get_task(task_id)

    def list_active_tasks(self) -> List[Dict]:
        return self.db.list_tasks(status='running')

    def pause_task(self, task_id: str) -> bool:
        return self.db.pause_task(task_id)

    def resume_task(self, task_id: str) -> bool:
        return self.db.resume_task(task_id)

    def process_enrichment_queue(self, batch_size: int = 5) -> List[Dict]:
        """处理补全队列（由 Orchestrator 定期调度）"""
        pending = self.db.get_pending_enrichment_tasks(limit=batch_size)
        results = []
        for task in pending:
            norm = task['norm']
            category_id = task.get('category_id')
            try:
                self.db.mark_enrichment_started(task['queue_id'])
                result = self.enrich_entity(norm, category_id=category_id)
                self.db.mark_enrichment_completed(task['queue_id'])
                results.append({'norm': norm, 'ok': True, 'result': result})
            except Exception as e:
                results.append({'norm': norm, 'ok': False, 'error': str(e)})
        return results

    # ========== 已删除的旧方法 ==========
    # 以下旧方法已删除，避免重复入口：
    # - run_network(self, tid, params=None)
    # - run_node(self, tid, params=None)
    # - run_dev_node(self, tid, params=None)
    # - start_network_expansion(self, ...)
    #
    # 请统一使用：
    # - expand_network(seed_norm, ...) 替代 run_network / start_network_expansion
    # - enrich_entity(norm, ...) 替代 run_node
    # - start_development(lead_norm, ...) 替代 run_dev_node
    # - batch_enrich(norms, ...) 用于并行补全
