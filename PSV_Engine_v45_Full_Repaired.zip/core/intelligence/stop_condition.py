# -*- coding: utf-8 -*-
"""Dynamic Stop Condition v45 (FULL)

核心原则：信息增益优先于固定时间。
- 先看信息增益，再看时间
- 策略切换后再判断
- 连续多个策略均无法产生有价值新信息 → 达到收敛条件 → 正常结束
"""
import time
from typing import Dict, Tuple, Optional
from core.config import settings


class DynamicStopCondition:
    """
    动态停止条件判断器。

    判断维度：
    1. 信息增益曲线（最近 N 轮新增节点/边/证据数）
    2. 策略切换后是否仍无增益
    3. 最大安全时间（仅作为死循环保护）
    4. 最小执行时间（避免过早停止）
    """

    def __init__(self):
        self.min_time = settings.MIN_EXPANSION_TIME      # 120s
        self.max_time = settings.MAX_EXPANSION_TIME      # 1800s
        self.convergence_threshold = 3                   # 连续 N 轮低增益视为收敛
        self.gain_threshold = 2                          # 单轮少于 N 个有效增量视为低增益
        self.strategy_switch_threshold = 2               # 切换 N 次策略后仍低增益则停止

    def should_stop(self, task_id: str, current_round: int, execution_time: float,
                    info_gain_stats: Dict) -> Tuple[bool, str]:
        """
        判断是否应停止扩张。

        Returns:
            (should_stop: bool, reason: str)
        """
        # 1. 最小执行时间保护（避免过早停止）
        if execution_time < self.min_time:
            return False, f"Minimum execution time not reached ({int(execution_time)}s < {self.min_time}s)"

        # 2. 最大安全时间（防止死循环）
        if execution_time > self.max_time:
            return True, f"Maximum safety time reached ({int(execution_time)}s > {self.max_time}s)"

        # 3. 信息增益分析
        recent = info_gain_stats.get('recent_rounds', [])
        if len(recent) < self.convergence_threshold:
            return False, f"Insufficient rounds for convergence analysis ({len(recent)} < {self.convergence_threshold})"

        # 计算最近 N 轮的有效增益
        low_gain_rounds = 0
        for r in recent:
            total = r.get('total_gain', 0)
            if total < self.gain_threshold:
                low_gain_rounds += 1

        # 4. 连续低增益 → 建议切换策略
        if low_gain_rounds >= self.convergence_threshold:
            # 检查是否已经尝试过策略切换
            strategies_tried = len(set(r.get('strategy', '') for r in recent))
            if strategies_tried >= self.strategy_switch_threshold:
                return True, (
                    f"Convergence reached: {low_gain_rounds} consecutive low-gain rounds "
                    f"after trying {strategies_tried} strategies. "
                    f"Last gain: {recent[-1].get('total_gain', 0)}. "
                    f"Execution time: {int(execution_time)}s."
                )
            else:
                return False, (
                    f"Low gain detected ({low_gain_rounds} rounds), "
                    f"but only {strategies_tried} strategies tried. "
                    f"Recommend switching strategy before stopping."
                )

        # 5. 正常继续
        last_gain = recent[-1].get('total_gain', 0) if recent else 0
        return False, f"Information gain continues: {last_gain} new items in last round."

    def get_stop_summary(self, task_id: str, info_gain_curve: list) -> Dict:
        """生成停止原因总结"""
        if not info_gain_curve:
            return {'stop_reason': 'No data', 'last_round': 0, 'gain_curve': []}

        return {
            'stop_reason': 'Convergence or safety limit',
            'last_round': info_gain_curve[-1].get('round_num', 0),
            'gain_curve': info_gain_curve,
            'unprocessed_nodes': 0,  # 可由调用方填充
            'total_rounds': len(info_gain_curve),
            'peak_gain': max(r.get('total_gain', 0) for r in info_gain_curve) if info_gain_curve else 0,
        }
