# -*- coding: utf-8 -*-
"""Waterfall Enrichment Engine v45.1 (AUDITED & HARDENED)

7-layer waterfall:
1. database (customs_raw / buyers_90d / suppliers)
2. company_website (requests + BeautifulSoup)
3. public_webpage (search result analysis)
4. search_engine (DuckDuckGo) - 加固：重试+UA轮换+指数退避
5. public_registry (framework for OpenCorporates etc.)
6. contact_finder (email extraction from website)
7. ai_validation (AI inference, low confidence, strictly marked)

Principles:
- Skip existing info
- Record source for every field
- Record evidence for key fields
- Do not overwrite old info without tracking
- Continue to next source on failure
- Respect access restrictions
- Strictly separate trade evidence from web info

v45.1 加固：
- _quick_search 增加重试机制(3次)
- User-Agent 轮换
- 指数退避(1s, 2s, 4s)
- 降级结果标记 degraded=True
"""
import time, json, re
import requests
from bs4 import BeautifulSoup
from typing import Dict, List, Any, Optional
from urllib.parse import quote_plus, urlparse
from core.memory.db import DB
from core.intelligence.ai_router import ai_route_structured


class WaterfallEnrichmentEngine:
    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.sources = [
            ('database', self._source_database),
            ('company_website', self._source_company_website),
            ('public_webpage', self._source_public_webpage),
            ('search_engine', self._source_search_engine),
            ('public_registry', self._source_public_registry),
            ('contact_finder', self._source_contact_finder),
            ('ai_validation', self._source_ai_validation),
        ]
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

    def enrich_entity(self, norm: str, category_id: str = None,
                      force: bool = False) -> Dict[str, Any]:
        entity = self.db.get_or_create_entity(norm, norm)
        entity_id = entity['entity_id']
        baseline = self._calculate_completeness(entity_id)
        fields_before = self._get_filled_fields(entity_id)

        enriched_fields = []
        sources_used = []
        evidence_added = []
        errors = []

        for source_name, source_func in self.sources:
            try:
                result = source_func(norm, entity_id, category_id, force)
                if result and result.get('found'):
                    sources_used.append(source_name)
                    for field, value in result.get('fields', {}).items():
                        if value and (force or not fields_before.get(field)):
                            self._save_field(norm, field, value, source_name)
                            enriched_fields.append(field)
                            fields_before[field] = value
                    for ev in result.get('evidence', []):
                        ev_id = self.db.save_evidence(
                            entity_id=entity_id,
                            source_type=ev.get('source_type', source_name),
                            source=ev.get('source', source_name),
                            evidence=ev.get('evidence', ''),
                            confidence=ev.get('confidence', 0.5)
                        )
                        evidence_added.append(ev_id)
            except Exception as e:
                errors.append({'source': source_name, 'error': str(e), 'degraded': False})
                continue

        final_completeness = self._calculate_completeness(entity_id)
        detail = self._get_completeness_detail(entity_id)

        return {
            'norm': norm,
            'completeness': final_completeness,
            'detail': detail,
            'fields_enriched': enriched_fields,
            'sources_used': sources_used,
            'evidence_added': evidence_added,
            'errors': errors,
            'baseline': baseline,
            'improvement': final_completeness - baseline,
        }

    # ========== Source 1: Database ==========
    def _source_database(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        result = {'found': False, 'fields': {}, 'evidence': []}
        with self.db.c() as x:
            x.row_factory = None
            rows = x.execute("""
                SELECT importer, shipper, hs, descr, origin, port_load, port_discharge, ts
                FROM customs_raw
                WHERE importer_norm=? OR shipper=? OR notify=?
                ORDER BY ts DESC LIMIT 5
            """, (norm, norm, norm)).fetchall()

        if rows:
            result['found'] = True
            countries = set()
            products = set()
            hss = set()
            for r in rows:
                if r[4]: countries.add(r[4])
                if r[3]: products.add(r[3])
                if r[2]: hss.add(r[2])
            if countries:
                result['fields']['country'] = list(countries)[0]
            if products:
                result['fields']['product_categories'] = ', '.join(list(products)[:3])
            if hss:
                result['fields']['hs_code'] = list(hss)[0]
            result['evidence'].append({
                'source_type': 'trade_record',
                'source': 'customs_raw',
                'evidence': f"Found {len(rows)} customs records for {norm}",
                'confidence': 0.9
            })

        with self.db.c() as x:
            row = x.execute("SELECT * FROM buyers_90d WHERE importer_norm=?", (norm,)).fetchone()
        if row:
            result['found'] = True
            result['fields']['name'] = row[1] if row[1] else norm
            if row[9] and not result['fields'].get('country'):
                result['fields']['country'] = row[9].split(',')[0] if row[9] else ''
            result['evidence'].append({
                'source_type': 'trade_record',
                'source': 'buyers_90d',
                'evidence': f"Buyer profile: shipments={row[2]}, last_seen={row[3]}",
                'confidence': 0.85
            })

        with self.db.c() as x:
            row = x.execute("SELECT * FROM suppliers WHERE supplier_norm=?", (norm,)).fetchone()
        if row:
            result['found'] = True
            if not result['fields'].get('name'):
                result['fields']['name'] = row[1] or norm
            result['evidence'].append({
                'source_type': 'trade_record',
                'source': 'suppliers',
                'evidence': f"Supplier profile: shipments={row[2]}",
                'confidence': 0.85
            })
        return result

    # ========== Source 2: Company Website ==========
    def _source_company_website(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        entity = self.db.get_entity(norm)
        website = entity.get('website', '') if entity else ''

        if not website:
            search = self._quick_search(f"{norm} official website")
            if search.get('links'):
                for link in search['links'][:3]:
                    if self._looks_like_official(link, norm):
                        website = link
                        break

        if not website:
            return {'found': False, 'fields': {}, 'evidence': []}

        try:
            resp = self.session.get(website, timeout=15, allow_redirects=True)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, 'lxml')

            fields = {}
            evidence = []
            title = soup.title.string if soup.title else ''
            meta_desc = soup.find('meta', attrs={'name': 'description'})
            description = meta_desc['content'] if meta_desc else ''

            phone_pattern = re.compile(r'[\+]?[\d\s\-\(\)]{8,20}')
            phones = phone_pattern.findall(soup.get_text())
            if phones:
                fields['phone'] = phones[0].strip()

            addr_keywords = ['address', '总部', '地址', 'location']
            for p in soup.find_all(['p', 'div']):
                text = p.get_text().lower()
                if any(k in text for k in addr_keywords):
                    addr = p.get_text().strip()
                    if len(addr) > 10 and len(addr) < 200:
                        fields['address'] = addr
                        break

            if description:
                fields['industry'] = self._infer_industry(description)

            fields['website'] = website

            evidence.append({
                'source_type': 'company_website',
                'source': website,
                'evidence': f"Website scraped: title='{title[:100]}', desc='{description[:150]}'",
                'confidence': 0.75
            })

            return {'found': True, 'fields': fields, 'evidence': evidence}

        except Exception as e:
            return {'found': False, 'fields': {}, 'evidence': [], 'error': str(e)}

    # ========== Source 3: Public Webpage ==========
    def _source_public_webpage(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        try:
            search = self._quick_search(f"{norm} company profile about us")
            fields = {}
            evidence = []

            for link in search.get('links', [])[:3]:
                try:
                    resp = self.session.get(link, timeout=10)
                    soup = BeautifulSoup(resp.text, 'lxml')
                    text = soup.get_text()

                    if 'inc.' in text.lower() or 'corp.' in text.lower() or 'ltd.' in text.lower():
                        fields['enterprise_type'] = self._extract_enterprise_type(text)

                    brand = self._extract_brand(text, norm)
                    if brand and not fields.get('brand'):
                        fields['brand'] = brand

                    evidence.append({
                        'source_type': 'public_webpage',
                        'source': link,
                        'evidence': f"Public page analyzed: {link}",
                        'confidence': 0.5
                    })
                    break
                except:
                    continue

            return {'found': bool(fields), 'fields': fields, 'evidence': evidence}
        except Exception as e:
            return {'found': False, 'fields': {}, 'evidence': [], 'error': str(e)}

    # ========== Source 4: Search Engine ==========
    def _source_search_engine(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        try:
            search = self._quick_search(norm)
            fields = {}
            evidence = []
            snippets = search.get('snippets', [])
            full_text = ' '.join(snippets)

            country = self._extract_country(full_text)
            if country and not self.db.get_entity(norm, {}).get('country'):
                fields['country'] = country

            linkedin_links = [l for l in search.get('links', []) if 'linkedin.com' in l]
            if linkedin_links:
                evidence.append({
                    'source_type': 'search_engine',
                    'source': 'duckduckgo',
                    'evidence': f"LinkedIn presence found: {linkedin_links[0]}",
                    'confidence': 0.55
                })

            return {'found': bool(fields or evidence), 'fields': fields, 'evidence': evidence}
        except Exception as e:
            return {'found': False, 'fields': {}, 'evidence': [], 'error': str(e)}

    # ========== Source 5: Public Registry ==========
    def _source_public_registry(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        return {'found': False, 'fields': {}, 'evidence': []}

    # ========== Source 6: Contact Finder ==========
    def _source_contact_finder(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        entity = self.db.get_entity(norm)
        website = entity.get('website', '') if entity else ''
        contacts_found = []
        evidence = []

        if website:
            try:
                contact_urls = [f"{website}/contact", f"{website}/about", website]
                for url in contact_urls:
                    try:
                        resp = self.session.get(url, timeout=10)
                        soup = BeautifulSoup(resp.text, 'lxml')
                        text = soup.get_text()

                        email_pattern = re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')
                        emails = list(set(email_pattern.findall(text)))

                        for email in emails:
                            if 'example' not in email and 'test' not in email:
                                contacts_found.append({'name': 'General Contact', 'email': email, 'source': url})

                        if emails:
                            evidence.append({
                                'source_type': 'contact_finder',
                                'source': url,
                                'evidence': f"Found {len(emails)} emails on {url}",
                                'confidence': 0.6
                            })
                            break
                    except:
                        continue
            except:
                pass

        for contact in contacts_found:
            self.db.save_contact(
                entity_id=entity_id,
                name=contact['name'],
                email=contact['email'],
                source=contact['source']
            )

        return {'found': bool(contacts_found), 'fields': {}, 'evidence': evidence}

    # ========== Source 7: AI Validation ==========
    def _source_ai_validation(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        entity = self.db.get_entity(norm)
        if not entity:
            return {'found': False, 'fields': {}, 'evidence': []}

        existing = {
            'name': entity.get('name', ''),
            'country': entity.get('country', ''),
            'website': entity.get('website', ''),
            'product_categories': entity.get('product_categories', ''),
            'description': entity.get('industry', ''),
        }

        prompt = f"""Based on the following company info, infer industry, enterprise_type and product_categories.
Company: {norm}
Existing: {json.dumps(existing, ensure_ascii=False)}
Return JSON: {{"industry":"...","enterprise_type":"...","product_categories":"...","confidence":0.6,"reasoning":"..."}}
Return empty {{}} if insufficient info."""

        ai_result = ai_route_structured(prompt, model_preference=['deepseek', 'qwen', 'gpt'])
        if not ai_result['success']:
            return {'found': False, 'fields': {}, 'evidence': []}

        parsed = ai_result.get('parsed_json', {})
        if not parsed:
            return {'found': False, 'fields': {}, 'evidence': []}

        fields = {}
        if parsed.get('industry'): fields['industry'] = parsed['industry']
        if parsed.get('enterprise_type'): fields['enterprise_type'] = parsed['enterprise_type']
        if parsed.get('product_categories'): fields['product_categories'] = parsed['product_categories']

        return {
            'found': bool(fields),
            'fields': fields,
            'evidence': [{
                'source_type': 'ai_inference',
                'source': f"ai/{ai_result.get('provider', 'unknown')}",
                'evidence': parsed.get('reasoning', 'AI inference'),
                'confidence': parsed.get('confidence', 0.3)
            }]
        }

    # ========== Helpers ==========
    def _quick_search(self, query: str, max_retries: int = 3) -> Dict:
        """
        v45.1 加固版快速搜索：带重试、User-Agent轮换、指数退避
        """
        import random
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
        ]

        last_error = None
        for attempt in range(max_retries):
            try:
                headers = {
                    'User-Agent': random.choice(user_agents),
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                }
                url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
                resp = self.session.get(
                    url, 
                    headers=headers, 
                    timeout=15 + attempt * 5,
                    allow_redirects=True
                )
                resp.raise_for_status()

                soup = BeautifulSoup(resp.text, 'html.parser')
                links = []
                snippets = []
                for result in soup.select('.result'):
                    a = result.select_one('.result__a')
                    if a and a.get('href'):
                        links.append(a['href'])
                    snippet = result.select_one('.result__snippet')
                    if snippet:
                        snippets.append(snippet.get_text())

                return {'links': links[:10], 'snippets': snippets[:10], 
                        'found': len(links) > 0, 'query': query}

            except Exception as e:
                last_error = str(e)
                wait_time = 2 ** attempt
                time.sleep(wait_time)
                continue

        return {
            'links': [], 'snippets': [], 'found': False,
            'query': query,
            'error': f'Search failed after {max_retries} retries: {last_error}',
            'degraded': True
        }

    def _looks_like_official(self, url: str, norm: str) -> bool:
        domain = urlparse(url).netloc.lower()
        norm_clean = norm.lower().replace(' ', '').replace('_', '').replace('-', '')
        return norm_clean in domain or 'official' in domain

    def _extract_country(self, text: str) -> Optional[str]:
        countries = ['USA', 'United States', 'China', 'Germany', 'UK', 'India', 
                     'France', 'Italy', 'Spain', 'Canada', 'Australia', 'Japan']
        text_upper = text.upper()
        for c in countries:
            if c.upper() in text_upper:
                return c
        return None

    def _infer_industry(self, text: str) -> str:
        industries = {
            'candle': 'Home Decor / Candle Manufacturing',
            'enamel': 'Kitchenware / Cookware',
            'felt': 'Textile / Craft Supplies',
            'furniture': 'Furniture',
            'textile': 'Textile',
            'food': 'Food & Beverage',
        }
        text_lower = text.lower()
        for k, v in industries.items():
            if k in text_lower:
                return v
        return 'General Trading'

    def _extract_enterprise_type(self, text: str) -> str:
        if 'inc.' in text.lower(): return 'Incorporated'
        if 'ltd.' in text.lower() or 'limited' in text.lower(): return 'Limited Company'
        if 'llc' in text.lower(): return 'LLC'
        if 'corp.' in text.lower() or 'corporation' in text.lower(): return 'Corporation'
        return 'Private Enterprise'

    def _extract_brand(self, text: str, norm: str) -> Optional[str]:
        return None

    def _save_field(self, norm: str, field: str, value: str, source: str):
        self.db.update_entity(norm, **{field: value})
        entity = self.db.get_entity(norm)
        if entity:
            self.db.save_evidence(
                entity_id=entity['entity_id'],
                source_type='enrichment',
                source=source,
                evidence=f"Field '{field}' enriched from {source}: {str(value)[:100]}",
                confidence=0.6
            )

    def _calculate_completeness(self, entity_id: str) -> float:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return 0.0
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories']
        filled = sum(1 for f in fields if entity.get(f))
        return round(filled / len(fields) * 100, 1)

    def _get_filled_fields(self, entity_id: str) -> Dict:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return {}
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories', 'brand']
        return {f: entity.get(f) for f in fields if entity.get(f)}

    def _get_completeness_detail(self, entity_id: str) -> Dict:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return {}
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories']
        return {f: bool(entity.get(f)) for f in fields}
