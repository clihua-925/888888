# -*- coding: utf-8 -*-
"""Waterfall Enrichment Engine v45 (FULL)

多源瀑布式补全 / Waterfall Enrichment

基本流程：
贸易原始信息 → 已有数据库信息 → 企业官网 → 公开网页 → 搜索引擎 →
公开企业信息 → 联系人信息 → 公开邮箱 → AI验证 → 证据合并 → 更新情报档案

原则：
1. 已经存在的信息不得重复浪费资源
2. 缺什么查什么
3. 每个字段记录来源
4. 每个关键字段记录证据
5. 新信息不得直接覆盖旧信息，必须保留来源和更新时间
6. 一个来源失败，应继续使用下一来源
7. 公开数据路径必须遵守访问限制
8. 不把普通搜索结果直接当成贸易证据
9. 贸易证据与普通企业公开信息严格区分
"""
import time, json
from typing import Dict, List, Any, Optional
from core.memory.db import DB
from core.intelligence.ai_router import ai_route_structured


class WaterfallEnrichmentEngine:
    """
    瀑布式信息补全引擎。
    按优先级依次尝试多个数据源，缺什么补什么。
    """

    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.sources = [
            ('database', self._source_database),
            ('company_website', self._source_company_website),
            ('public_webpage', self._source_public_webpage),
            ('search_engine', self._source_search_engine),
            ('public_registry', self._source_public_registry),
            ('contact_finder', self._source_contact_finder),
            ('ai_validation', self._source_ai_validation),
        ]

    def enrich_entity(self, norm: str, category_id: str = None,
                      force: bool = False) -> Dict[str, Any]:
        """
        对指定实体执行瀑布式补全。

        Returns:
            {
                'norm': str,
                'completeness': float,      # 0-100
                'detail': dict,
                'fields_enriched': list,
                'sources_used': list,
                'evidence_added': list,
                'errors': list,
            }
        """
        entity = self.db.get_or_create_entity(norm, norm)
        entity_id = entity['entity_id']

        # 获取当前完整度基线
        baseline = self._calculate_completeness(entity_id)
        fields_before = self._get_filled_fields(entity_id)

        enriched_fields = []
        sources_used = []
        evidence_added = []
        errors = []

        # 按优先级遍历数据源
        for source_name, source_func in self.sources:
            try:
                result = source_func(norm, entity_id, category_id, force)
                if result and result.get('found'):
                    sources_used.append(source_name)
                    # 保存补全结果
                    for field, value in result.get('fields', {}).items():
                        if value and not fields_before.get(field):
                            self._save_field(norm, field, value, source_name)
                            enriched_fields.append(field)
                    # 保存证据
                    for ev in result.get('evidence', []):
                        ev_id = self.db.save_evidence(
                            entity_id=entity_id,
                            source_type=ev.get('source_type', source_name),
                            source=ev.get('source', source_name),
                            evidence=ev.get('evidence', ''),
                            confidence=ev.get('confidence', 0.5)
                        )
                        evidence_added.append(ev_id)
            except Exception as e:
                errors.append({'source': source_name, 'error': str(e)})
                continue  # 来源失败，继续下一来源

        # 重新计算完整度
        final_completeness = self._calculate_completeness(entity_id)
        detail = self._get_completeness_detail(entity_id)

        return {
            'norm': norm,
            'completeness': final_completeness,
            'detail': detail,
            'fields_enriched': enriched_fields,
            'sources_used': sources_used,
            'evidence_added': evidence_added,
            'errors': errors,
            'baseline': baseline,
            'improvement': final_completeness - baseline,
        }

    def _source_database(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        """来源1：已有数据库（customs_raw / buyers_90d / suppliers）"""
        result = {'found': False, 'fields': {}, 'evidence': []}

        # 从 customs_raw 查找贸易记录
        with self.db.c() as x:
            x.row_factory = None
            rows = x.execute("""
                SELECT importer, shipper, hs, descr, origin, port_load, port_discharge, ts
                FROM customs_raw
                WHERE importer_norm=? OR shipper=? OR notify=?
                ORDER BY ts DESC LIMIT 5
            """, (norm, norm, norm)).fetchall()

        if rows:
            result['found'] = True
            # 提取国家、产品等信息
            countries = set()
            products = set()
            for r in rows:
                if r[4]: countries.add(r[4])
                if r[3]: products.add(r[3])
            if countries:
                result['fields']['country'] = list(countries)[0]
            if products:
                result['fields']['product_categories'] = ', '.join(list(products)[:3])
            result['evidence'].append({
                'source_type': 'trade_record',
                'source': 'customs_raw',
                'evidence': f"Found {len(rows)} customs records for {norm}",
                'confidence': 0.9
            })

        # 从 buyers_90d 补充
        with self.db.c() as x:
            row = x.execute("SELECT * FROM buyers_90d WHERE importer_norm=?", (norm,)).fetchone()
        if row:
            result['found'] = True
            result['fields']['name'] = row[1] if row[1] else norm
            if row[9] and not result['fields'].get('country'):
                result['fields']['country'] = row[9].split(',')[0] if row[9] else ''
            result['evidence'].append({
                'source_type': 'trade_record',
                'source': 'buyers_90d',
                'evidence': f"Buyer profile: {row[2]} shipments, last seen {row[3]}",
                'confidence': 0.85
            })

        return result

    def _source_company_website(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        """来源2：企业官网"""
        entity = self.db.get_entity(norm)
        website = entity.get('website', '') if entity else ''
        if not website:
            return {'found': False, 'fields': {}, 'evidence': []}

        # 实际实现中应使用爬虫/请求获取网页内容
        # 此处为框架，返回占位
        return {
            'found': False,
            'fields': {},
            'evidence': [],
            'note': 'Website enrichment requires web scraper implementation'
        }

    def _source_public_webpage(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        """来源3：公开网页"""
        # 框架占位
        return {'found': False, 'fields': {}, 'evidence': []}

    def _source_search_engine(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        """来源4：搜索引擎"""
        # 框架占位
        return {'found': False, 'fields': {}, 'evidence': []}

    def _source_public_registry(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        """来源5：公开企业注册信息"""
        # 框架占位
        return {'found': False, 'fields': {}, 'evidence': []}

    def _source_contact_finder(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        """来源6：联系人信息查找"""
        # 框架占位
        return {'found': False, 'fields': {}, 'evidence': []}

    def _source_ai_validation(self, norm: str, entity_id: str, category_id: str, force: bool) -> Dict:
        """来源7：AI 验证与推断（最后一步，低置信度）"""
        entity = self.db.get_entity(norm)
        if not entity:
            return {'found': False, 'fields': {}, 'evidence': []}

        # 收集已有信息供 AI 分析
        existing = {
            'name': entity.get('name', ''),
            'country': entity.get('country', ''),
            'website': entity.get('website', ''),
            'product_categories': entity.get('product_categories', ''),
        }

        prompt = f"""基于以下企业信息，判断其行业、企业类型和产品类别。
企业名称: {norm}
已有信息: {json.dumps(existing, ensure_ascii=False)}

请返回 JSON:
{{
  "industry": "推断的行业",
  "enterprise_type": "推断的企业类型",
  "product_categories": "推断的产品类别",
  "confidence": 0.6,
  "reasoning": "推断理由"
}}
如果信息不足，返回空对象 {{}}。"""

        ai_result = ai_route_structured(prompt, model_preference=['deepseek', 'qwen', 'gpt'])
        if not ai_result['success']:
            return {'found': False, 'fields': {}, 'evidence': []}

        parsed = ai_result.get('parsed_json', {})
        if not parsed:
            return {'found': False, 'fields': {}, 'evidence': []}

        fields = {}
        if parsed.get('industry'):
            fields['industry'] = parsed['industry']
        if parsed.get('enterprise_type'):
            fields['enterprise_type'] = parsed['enterprise_type']
        if parsed.get('product_categories'):
            fields['product_categories'] = parsed['product_categories']

        return {
            'found': bool(fields),
            'fields': fields,
            'evidence': [{
                'source_type': 'ai_inference',
                'source': f"ai_validation/{ai_result.get('provider', 'unknown')}",
                'evidence': parsed.get('reasoning', 'AI inference'),
                'confidence': parsed.get('confidence', 0.3)
            }]
        }

    def _save_field(self, norm: str, field: str, value: str, source: str):
        """保存单个字段到实体表，同时记录来源"""
        self.db.update_entity(norm, **{field: value})
        entity = self.db.get_entity(norm)
        if entity:
            self.db.save_evidence(
                entity_id=entity['entity_id'],
                source_type='enrichment',
                source=source,
                evidence=f"Field '{field}' enriched from {source}: {value}",
                confidence=0.6
            )

    def _calculate_completeness(self, entity_id: str) -> float:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return 0.0
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories']
        filled = sum(1 for f in fields if entity.get(f))
        return round(filled / len(fields) * 100, 1)

    def _get_completeness_detail(self, entity_id: str) -> Dict:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return {}
        return {
            'basic_info': self._calculate_completeness(entity_id),
            'trade_info': min(100, self.db.count('trade_edges', 'from_entity_id=? OR to_entity_id=?', (entity_id, entity_id)) * 20),
            'product_info': 100 if entity.get('product_categories') else 0,
            'contact_info': min(100, self.db.count('contacts', 'entity_id=?', (entity_id,)) * 50),
            'email_info': min(100, len([c for c in self.db.list_entity_contacts(entity_id) if c.get('email')]) * 50),
            'website_info': 100 if entity.get('website') else 0,
        }

    def _get_filled_fields(self, entity_id: str) -> Dict[str, bool]:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return {}
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories', 'brand']
        return {f: bool(entity.get(f)) for f in fields}
