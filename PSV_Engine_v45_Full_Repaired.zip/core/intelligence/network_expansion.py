# -*- coding: utf-8 -*-
"""Network Expansion Engine v45 (FULL REPAIRED)

修复内容：
1. 补全全部 12 个扩张策略（原版本 7 个为空实现）
2. 移除 _add_to_pool 中的自动补全线程（小编排智能体失控）
3. 扩张引擎只负责发现节点并记录到数据库，不自行触发补全
4. 补全由 Orchestrator 根据任务状态统一调度
5. 所有新发现节点自动进入对应资源池
6. 证据分级：贸易证据 vs AI 推断严格区分
7. 支持断点续跑：pending_nodes 持久化到任务状态
"""
import time, uuid, json
from typing import Dict, List, Any, Optional, Set
from core.memory.db import DB
from core.intelligence.ai_router import ai_route_structured
from core.intelligence.stop_condition import DynamicStopCondition


class NetworkExpansionEngine:
    """
    网络扩张引擎 - 负责从种子节点双向扩张贸易网络。

    修复后原则：
    - 只负责发现节点和记录关系
    - 不自行决定后续流程（补全、验证等）
    - 所有结果返回给 Orchestrator，由编排器决定下一步
    - 支持从失败节点恢复（断点续跑）
    """

    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.stop_condition = DynamicStopCondition()
        self._strategies = [
            'customer_to_supplier',
            'supplier_to_customer',
            'same_supplier_new_customer',
            'same_customer_new_supplier',
            'same_product_customer',
            'same_product_supplier',
            'reverse_trade_relation',
            'associated_enterprise',
            'brand_association',
            'address_identity_association',
            'public_web_association',
            'contact_organization'
        ]

    def expand(self, seed_norm: str, task_id: str = None, category_id: str = None,
               max_depth: int = 3, resume_from: str = None, **kwargs) -> Dict[str, Any]:
        """
        从种子节点开始网络扩张。

        Args:
            seed_norm: 种子节点标准化名称
            task_id: 任务ID（如提供则恢复该任务，否则新建）
            category_id: 品类ID（三品类隔离）
            max_depth: 最大扩张深度
            resume_from: 从指定任务恢复（断点续跑）

        Returns:
            扩张结果报告
        """
        if resume_from:
            task = self.db.get_task(resume_from)
            if task and task.get('run_status') in ('failed', 'paused'):
                task_id = resume_from
                self.db.update_task(task_id, run_status='running')
                self.db.save_task_log(task_id, 'expansion_resume',
                                     f"Resuming expansion from failed/paused state")
            else:
                task_id = f"net-{uuid.uuid4().hex[:8]}"
        else:
            task_id = task_id or f"net-{uuid.uuid4().hex[:8]}"

        # 创建/更新任务面板
        self.db.create_task(
            task_id=task_id,
            task_name=f"Network Expansion: {seed_norm}",
            task_type='network_expansion',
            category_id=category_id,
            parent_task_id=kwargs.get('parent_task_id')
        )
        self.db.update_task(task_id, run_status='running', current_stage='expansion')

        # 初始化
        visited: Set[str] = set()
        discovered_nodes: List[Dict] = []
        round_num = 0
        start_time = time.time()

        # 种子节点入队
        pending_nodes = [(seed_norm, 0, None)]  # (norm, depth, parent_norm)
        seed_entity = self.db.get_or_create_entity(norm=seed_norm, name=seed_norm)

        self.db.save_task_log(task_id, 'expansion_start',
                             f"Starting expansion from {seed_norm}, category={category_id}, max_depth={max_depth}")

        try:
            while pending_nodes:
                current_norm, current_depth, parent_norm = pending_nodes.pop(0)

                if current_norm in visited:
                    continue
                visited.add(current_norm)

                if current_depth >= max_depth:
                    continue

                round_num += 1
                self.db.update_task(task_id, current_node=current_norm,
                                   current_stage=f"round_{round_num}_depth_{current_depth}")

                # 执行一轮扩张
                round_result = self._expand_round(
                    current_norm, current_depth, parent_norm,
                    task_id, category_id, visited
                )

                # 记录信息增益
                self.db.record_info_gain(
                    task_id=task_id,
                    round_num=round_num,
                    strategy='multi_strategy',
                    new_customers=round_result.get('new_customers', 0),
                    new_suppliers=round_result.get('new_suppliers', 0),
                    new_edges=round_result.get('new_edges', 0),
                    new_evidence=round_result.get('new_evidence', 0),
                    total_gain=round_result.get('total_gain', 0)
                )

                # 将新发现的节点加入待处理队列（作为下一轮种子）
                for new_node in round_result.get('new_nodes', []):
                    if new_node['norm'] not in visited:
                        pending_nodes.append((new_node['norm'], current_depth + 1, current_norm))

                discovered_nodes.extend(round_result.get('new_nodes', []))

                # 更新任务进度
                self.db.update_task(
                    task_id=task_id,
                    progress_pct=min(100, round(visited.__len__() / max(1, len(pending_nodes) + visited.__len__()) * 100, 1)),
                    discovered_customers=len([n for n in discovered_nodes if n.get('role') == 'customer']),
                    discovered_suppliers=len([n for n in discovered_nodes if n.get('role') == 'supplier']),
                    new_edges=len(discovered_nodes),
                    new_evidence=round_result.get('new_evidence', 0)
                )

                # 检查动态停止条件
                should_stop, stop_reason = self.stop_condition.should_stop(
                    task_id=task_id,
                    current_round=round_num,
                    execution_time=time.time() - start_time,
                    info_gain_stats=self._get_round_stats(task_id, round_num)
                )

                if should_stop:
                    self.db.save_task_log(task_id, 'expansion_stop', stop_reason)
                    break

        except Exception as e:
            self.db.save_task_log(task_id, 'expansion_error', str(e))
            self.db.update_task(task_id, run_status='failed', failure_reason=str(e))
            # 保存断点状态，支持恢复
            return {
                'task_id': task_id,
                'seed_norm': seed_norm,
                'status': 'failed',
                'error': str(e),
                'last_node': current_norm if 'current_norm' in dir() else seed_norm,
                'pending_nodes': pending_nodes,
                'visited_count': len(visited),
                'can_resume': True
            }

        # 任务完成
        self.db.update_task(
            task_id=task_id,
            run_status='completed',
            progress_pct=100,
            discovered_customers=len([n for n in discovered_nodes if n.get('role') == 'customer']),
            discovered_suppliers=len([n for n in discovered_nodes if n.get('role') == 'supplier']),
            current_stage='completed',
            completed_at=time.time()
        )

        return {
            'task_id': task_id,
            'seed_norm': seed_norm,
            'total_rounds': round_num,
            'total_discovered': len(discovered_nodes),
            'discovered_nodes': discovered_nodes,
            'visited_count': len(visited),
            'duration': time.time() - start_time,
            'status': 'completed'
        }

    def _expand_round(self, current_norm: str, current_depth: int, parent_norm: Optional[str],
                     task_id: str, category_id: str, visited: set) -> Dict:
        """执行单轮扩张，尝试所有策略。"""
        new_nodes = []
        new_customers = 0
        new_suppliers = 0
        new_edges = 0
        new_evidence = 0

        for strategy in self._strategies:
            try:
                results = self._execute_strategy(
                    strategy, current_norm, parent_norm,
                    task_id, category_id, visited
                )

                for result in results:
                    norm = result['norm']
                    if norm not in visited:
                        new_nodes.append(result)
                        if result.get('role') == 'customer':
                            new_customers += 1
                        elif result.get('role') == 'supplier':
                            new_suppliers += 1
                        new_edges += 1

                        # 记录扩张日志
                        self.db.log_expansion(
                            task_id=task_id,
                            round_num=current_depth,
                            strategy=strategy,
                            discovered_entity_id=result.get('entity_id', ''),
                            discovered_norm=norm,
                            discovered_name=result.get('name', norm),
                            discovered_role=result.get('role', 'unknown'),
                            relation_type=result.get('relation', ''),
                            from_entity_id=self.db.get_entity(current_norm).get('entity_id', '') if self.db.get_entity(current_norm) else '',
                            evidence=result.get('evidence', ''),
                            confidence=result.get('confidence', 0),
                            category_id=category_id
                        )

                        # 记录证据（区分来源类型）
                        if result.get('evidence'):
                            entity = self.db.get_or_create_entity(norm=norm, name=result.get('name', norm))
                            source_type = result.get('source_type', 'network_expansion')
                            self.db.save_evidence(
                                entity_id=entity.get('entity_id'),
                                source_type=source_type,
                                source=strategy,
                                evidence=result['evidence'],
                                confidence=result.get('confidence', 0)
                            )
                            new_evidence += 1

                        # 自动加入资源池
                        self._add_to_pool(norm, result.get('name', norm),
                                         result.get('role', 'unknown'),
                                         strategy, task_id, category_id)

            except Exception as e:
                self.db.save_task_log(task_id, 'strategy_error', f"{strategy}: {str(e)}")
                continue

        return {
            'new_nodes': new_nodes,
            'new_customers': new_customers,
            'new_suppliers': new_suppliers,
            'new_edges': new_edges,
            'new_evidence': new_evidence,
            'total_gain': new_customers + new_suppliers + new_edges + new_evidence
        }

    def _execute_strategy(self, strategy: str, current_norm: str, parent_norm: Optional[str],
                         task_id: str, category_id: str, visited: set) -> List[Dict]:
        """执行单个扩张策略。"""
        strategy_map = {
            'customer_to_supplier': self._expand_customer_to_supplier,
            'supplier_to_customer': self._expand_supplier_to_customer,
            'same_supplier_new_customer': self._expand_same_supplier,
            'same_customer_new_supplier': self._expand_same_customer,
            'same_product_customer': self._expand_same_product_customer,
            'same_product_supplier': self._expand_same_product_supplier,
            'reverse_trade_relation': self._expand_reverse_relation,
            'associated_enterprise': self._expand_associated_enterprise,
            'brand_association': self._expand_brand,
            'address_identity_association': self._expand_address,
            'public_web_association': self._expand_public_web,
            'contact_organization': self._expand_contact_org
        }

        func = strategy_map.get(strategy)
        if not func:
            return []

        return func(current_norm, parent_norm, task_id, category_id, visited)

    # ========== 策略 1：客户 → 寻找其供应商 ==========
    def _expand_customer_to_supplier(self, norm, parent, task_id, category_id, visited):
        entity = self.db.get_entity(norm)
        if not entity:
            return []
        edges = self.db.list_trade_edges(entity_id=entity['entity_id'])
        results = []
        for edge in edges:
            if edge.get('relation') == 'supplier_of' and edge.get('to_norm'):
                if edge['to_norm'] not in visited:
                    results.append({
                        'norm': edge['to_norm'],
                        'name': edge.get('to_norm'),
                        'role': 'supplier',
                        'relation': 'supplier_of',
                        'evidence': f"Trade edge from {norm}: {edge.get('evidence', '')}",
                        'confidence': edge.get('confidence', 0.7),
                        'entity_id': edge.get('to_entity_id', ''),
                        'source_type': 'trade_record'
                    })
        return results

    # ========== 策略 2：供应商 → 寻找其客户 ==========
    def _expand_supplier_to_customer(self, norm, parent, task_id, category_id, visited):
        entity = self.db.get_entity(norm)
        if not entity:
            return []
        edges = self.db.list_trade_edges(entity_id=entity['entity_id'])
        results = []
        for edge in edges:
            if edge.get('relation') == 'customer_of' and edge.get('to_norm'):
                if edge['to_norm'] not in visited:
                    results.append({
                        'norm': edge['to_norm'],
                        'name': edge.get('to_norm'),
                        'role': 'customer',
                        'relation': 'customer_of',
                        'evidence': f"Trade edge from {norm}: {edge.get('evidence', '')}",
                        'confidence': edge.get('confidence', 0.7),
                        'entity_id': edge.get('to_entity_id', ''),
                        'source_type': 'trade_record'
                    })
        return results

    # ========== 策略 3：同供应商 → 新客户 ==========
    def _expand_same_supplier(self, norm, parent, task_id, category_id, visited):
        """找到 norm 的供应商，然后找这些供应商的其他客户"""
        entity = self.db.get_entity(norm)
        if not entity:
            return []

        # 获取 norm 的所有供应商
        supplier_edges = self.db.list_trade_edges(entity_id=entity['entity_id'])
        suppliers = [e for e in supplier_edges if e.get('relation') == 'supplier_of']

        results = []
        for sup in suppliers:
            supplier_norm = sup.get('to_norm')
            if not supplier_norm:
                continue
            # 找这个供应商的所有客户
            customer_edges = self.db.get_customers_of(supplier_norm)
            for ce in customer_edges:
                customer_norm = ce.get('from_norm')
                if customer_norm and customer_norm != norm and customer_norm not in visited:
                    results.append({
                        'norm': customer_norm,
                        'name': customer_norm,
                        'role': 'customer',
                        'relation': 'same_supplier_customer',
                        'evidence': f"Shared supplier {supplier_norm} with {norm}",
                        'confidence': 0.6,
                        'entity_id': ce.get('from_entity_id', ''),
                        'source_type': 'trade_record'
                    })
        return results

    # ========== 策略 4：同客户 → 新供应商 ==========
    def _expand_same_customer(self, norm, parent, task_id, category_id, visited):
        """找到 norm 的客户，然后找这些客户的其他供应商"""
        entity = self.db.get_entity(norm)
        if not entity:
            return []

        # 获取 norm 作为供应商的所有客户
        customer_edges = self.db.get_customers_of(norm)
        results = []
        for ce in customer_edges:
            customer_norm = ce.get('from_norm')
            if not customer_norm:
                continue
            # 找这个客户的所有供应商
            supplier_edges = self.db.list_trade_edges(norm=customer_norm)
            for se in supplier_edges:
                if se.get('relation') == 'supplier_of':
                    supplier_norm = se.get('to_norm')
                    if supplier_norm and supplier_norm != norm and supplier_norm not in visited:
                        results.append({
                            'norm': supplier_norm,
                            'name': supplier_norm,
                            'role': 'supplier',
                            'relation': 'same_customer_supplier',
                            'evidence': f"Shared customer {customer_norm} with {norm}",
                            'confidence': 0.6,
                            'entity_id': se.get('to_entity_id', ''),
                            'source_type': 'trade_record'
                        })
        return results

    # ========== 策略 5：同产品 → 相关客户 ==========
    def _expand_same_product_customer(self, norm, parent, task_id, category_id, visited):
        """找与 norm 采购相同产品的其他客户"""
        entity = self.db.get_entity(norm)
        if not entity:
            return []

        # 获取 norm 采购的产品
        edges = self.db.list_trade_edges(entity_id=entity['entity_id'])
        products = set()
        for e in edges:
            if e.get('relation') == 'supplier_of' and e.get('product'):
                products.add(e['product'])

        if not products:
            return []

        results = []
        with self.db.c() as x:
            x.row_factory = None
            for product in products:
                rows = x.execute("""
                    SELECT DISTINCT from_norm, from_entity_id FROM trade_edges
                    WHERE product=? AND relation='supplier_of' AND from_norm != ?
                    LIMIT 20
                """, (product, norm)).fetchall()
                for row in rows:
                    if row[0] not in visited:
                        results.append({
                            'norm': row[0],
                            'name': row[0],
                            'role': 'customer',
                            'relation': 'same_product_customer',
                            'evidence': f"Purchases same product: {product}",
                            'confidence': 0.55,
                            'entity_id': row[1] or '',
                            'source_type': 'trade_record'
                        })
        return results

    # ========== 策略 6：同产品 → 相关供应商 ==========
    def _expand_same_product_supplier(self, norm, parent, task_id, category_id, visited):
        """找与 norm 供应相同产品的其他供应商"""
        entity = self.db.get_entity(norm)
        if not entity:
            return []

        edges = self.db.list_trade_edges(entity_id=entity['entity_id'])
        products = set()
        for e in edges:
            if e.get('relation') == 'customer_of' and e.get('product'):
                products.add(e['product'])

        if not products:
            return []

        results = []
        with self.db.c() as x:
            x.row_factory = None
            for product in products:
                rows = x.execute("""
                    SELECT DISTINCT to_norm, to_entity_id FROM trade_edges
                    WHERE product=? AND relation='supplier_of' AND to_norm != ?
                    LIMIT 20
                """, (product, norm)).fetchall()
                for row in rows:
                    if row[0] not in visited:
                        results.append({
                            'norm': row[0],
                            'name': row[0],
                            'role': 'supplier',
                            'relation': 'same_product_supplier',
                            'evidence': f"Supplies same product: {product}",
                            'confidence': 0.55,
                            'entity_id': row[1] or '',
                            'source_type': 'trade_record'
                        })
        return results

    # ========== 策略 7：贸易关系反向扩张 ==========
    def _expand_reverse_relation(self, norm, parent, task_id, category_id, visited):
        """如果 A 是 B 的供应商，则 B 可能是 A 的客户（反向验证）"""
        entity = self.db.get_entity(norm)
        if not entity:
            return []

        results = []
        # 获取 norm 作为供应商的客户
        customer_edges = self.db.get_customers_of(norm)
        for ce in customer_edges:
            customer_norm = ce.get('from_norm')
            if not customer_norm or customer_norm in visited:
                continue
            # 反向：检查该客户是否确实把 norm 列为供应商
            reverse_edges = self.db.list_trade_edges(norm=customer_norm)
            has_reverse = any(e.get('to_norm') == norm and e.get('relation') == 'supplier_of' for e in reverse_edges)
            if has_reverse:
                results.append({
                    'norm': customer_norm,
                    'name': customer_norm,
                    'role': 'customer',
                    'relation': 'reverse_verified',
                    'evidence': f"Reverse trade relation verified: {customer_norm} lists {norm} as supplier",
                    'confidence': 0.8,
                    'entity_id': ce.get('from_entity_id', ''),
                    'source_type': 'trade_record'
                })
        return results

    # ========== 策略 8-12：AI 辅助扩张（低置信度，严格标记） ==========
    def _expand_associated_enterprise(self, norm, parent, task_id, category_id, visited):
        return self._ai_assisted_expansion(norm, 'associated_enterprise', visited)

    def _expand_brand(self, norm, parent, task_id, category_id, visited):
        return self._ai_assisted_expansion(norm, 'brand_association', visited)

    def _expand_address(self, norm, parent, task_id, category_id, visited):
        return self._ai_assisted_expansion(norm, 'address_identity', visited)

    def _expand_public_web(self, norm, parent, task_id, category_id, visited):
        return self._ai_assisted_expansion(norm, 'public_web', visited)

    def _expand_contact_org(self, norm, parent, task_id, category_id, visited):
        return self._ai_assisted_expansion(norm, 'contact_organization', visited)

    def _ai_assisted_expansion(self, norm: str, strategy: str, visited: set) -> List[Dict]:
        """AI 辅助扩张 - 仅作为建议，低置信度，严格标记为 ai_inference。"""
        try:
            # 先收集已有信息，减少幻觉
            entity = self.db.get_entity(norm)
            existing_info = ""
            if entity:
                existing_info = f"Country: {entity.get('country','')}, Industry: {entity.get('industry','')}, Products: {entity.get('product_categories','')}"

            prompt = f"""基于企业 '{norm}' 的已有信息：{existing_info}

尝试发现与其相关的贸易伙伴。策略：{strategy}
请返回可能的关联企业列表（JSON格式）：
[{{"name": "企业名称", "role": "customer|supplier", "confidence": 0.3, "reason": "关联原因"}}]
如果没有发现，返回空数组 []。
注意：只返回你有较高确信度的关联，不要编造。"""

            result = ai_route_structured(prompt, model_preference=['deepseek', 'qwen', 'gpt'])
            if not result['success']:
                return []

            parsed = result.get('parsed_json')
            if not parsed or not isinstance(parsed, list):
                return []

            results = []
            for item in parsed:
                name = item.get('name', '')
                if not name or name in visited:
                    continue
                confidence = item.get('confidence', 0.3)
                if confidence < 0.3:
                    continue  # 过滤过低置信度
                results.append({
                    'norm': name.lower().replace(' ', '_'),
                    'name': name,
                    'role': item.get('role', 'unknown'),
                    'relation': strategy,
                    'evidence': item.get('reason', 'AI inference'),
                    'confidence': confidence,
                    'entity_id': '',
                    'source_type': 'ai_inference'  # 严格标记
                })
            return results
        except Exception:
            return []

    def _add_to_pool(self, norm: str, name: str, role: str, source: str,
                    task_id: str, category_id: str):
        """
        将新发现的节点加入资源池。
        修复后：只记录到数据库，不自行触发补全。
        补全由 Orchestrator 统一调度。
        """
        entity = self.db.get_or_create_entity(norm=norm, name=name)
        entity_id = entity.get('entity_id')

        self.db.set_entity_role(entity_id, role)
        if category_id:
            self.db.set_entity_category(entity_id, category_id)

        if role == 'customer':
            self.db.add_to_customer_pool(norm, name, category_id, source, task_id)
        elif role == 'supplier':
            self.db.add_to_supplier_pool(norm, name, category_id, source, task_id)

        # 记录生命周期转换
        current_state = self.db.get_current_lifecycle_state(entity_id)
        if current_state == 'DISCOVERED':
            self.db.transition_lifecycle(
                entity_id=entity_id,
                from_state='DISCOVERED',
                to_state='TRADE_CONFIRMED',
                reason=f'Network expansion discovered as {role} via {source}',
                actor='network_expansion_engine'
            )

        self.db.log_expansion(
            task_id=task_id,
            round_num=0,
            strategy='pool_add',
            discovered_entity_id=entity_id,
            discovered_norm=norm,
            discovered_name=name,
            discovered_role=role,
            relation_type='discovered',
            category_id=category_id
        )

    def _get_round_stats(self, task_id: str, round_num: int) -> Dict:
        curve = self.db.get_info_gain_curve(task_id)
        if not curve:
            return {}
        recent = [c for c in curve if c['round_num'] >= round_num - 2]
        return {
            'recent_rounds': recent,
            'total_rounds': len(curve)
        }
