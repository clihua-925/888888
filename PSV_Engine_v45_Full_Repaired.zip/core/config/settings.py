# -*- coding: utf-8 -*-
"""PSV Engine Configuration - v45 Full Repaired"""
import os

DATABASE_PATH = os.environ.get("PSV_DB_PATH", "./psv_engine_v45.db")
AI_TIMEOUT = int(os.environ.get("PSV_AI_TIMEOUT", "60"))
MAX_EXPANSION_DEPTH = int(os.environ.get("PSV_MAX_DEPTH", "5"))
MAX_EXPANSION_TIME = int(os.environ.get("PSV_MAX_TIME", "1800"))  # 30min safety
MIN_EXPANSION_TIME = int(os.environ.get("PSV_MIN_TIME", "120"))   # 2min minimum

# AI Provider configs (fallback chain)
AI_PROVIDERS = [
    {"name": "gpt", "priority": 1, "api_key_env": "OPENAI_API_KEY", "model": "gpt-4o"},
    {"name": "deepseek", "priority": 2, "api_key_env": "DEEPSEEK_API_KEY", "model": "deepseek-chat"},
    {"name": "qwen", "priority": 3, "api_key_env": "DASHSCOPE_API_KEY", "model": "qwen-max"},
]

# Product categories (三品类隔离)
CATEGORIES = {
    "candle": {"id": "cat_candle", "name": "蜡烛", "hs_prefix": ["34"]},
    "enamel_pot": {"id": "cat_enamel", "name": "珐琅锅", "hs_prefix": ["73", "69"]},
    "felt": {"id": "cat_felt", "name": "毛毡", "hs_prefix": ["56", "63"]},
}

# Lifecycle states
LIFECYCLE_STATES = [
    "DISCOVERED", "TRADE_CONFIRMED", "ENRICHING", "ENRICHED",
    "CONTACT_FOUND", "CONTACT_VERIFIED", "QUALIFIED",
    "READY_FOR_OUTREACH", "OUTREACH_ACTIVE", "REPLIED",
    "FOLLOW_UP", "OPPORTUNITY", "CUSTOMER",
    "QUARANTINED", "INVALID", "NO_SIGNAL", "DO_NOT_CONTACT"
]

# Evidence priority
EVIDENCE_PRIORITY = {
    "trade_record": 100,
    "customs_data": 95,
    "official_registry": 80,
    "company_website": 70,
    "public_webpage": 50,
    "ai_inference": 20,
    "user_input": 10,
}
