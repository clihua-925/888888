# -*- coding: utf-8 -*-
"""PSV Engine v45 - Unified Database Layer (FULL REPAIRED)

核心原则：
1. 一个实体 = 一个 entity_id + 多个角色/关系/证据/品类关联
2. 情报中心/贸易图谱/业务中心共享统一 entities 表
3. 禁止同一公司三个模块各存一份数据
4. 所有后半程表增加 category_id 字段，三品类严格隔离
5. 第一采集链表 100% 冻结，不修改（customs_raw/buyers_90d 只读）
6. 旧表 leads/trade_nodes/relationships 废弃，不再写入新数据
7. 提供迁移兼容层，供旧数据只读查询直到完全迁移
"""
import sqlite3, time, json, uuid
from typing import Dict, List, Any, Optional
from core.config import settings


class DB:
    def __init__(self, path=None):
        self.path = path or settings.DATABASE_PATH
        self.init()

    def c(self):
        return sqlite3.connect(self.path, timeout=10, check_same_thread=False)

    def init(self):
        with self.c() as x:
            # ========== 第一采集链表（100% 冻结，只读）==========
            x.executescript("""
            CREATE TABLE IF NOT EXISTS customs_raw(
                id INTEGER PRIMARY KEY AUTOINCREMENT, row_hash TEXT UNIQUE,
                bol TEXT, ts REAL, importer TEXT, importer_norm TEXT,
                shipper TEXT, notify TEXT, hs TEXT, descr TEXT, qty REAL,
                weight REAL, teu REAL, origin TEXT, port_load TEXT,
                port_discharge TEXT, source_file TEXT,
                direct_importer INT, created_at REAL
            );
            CREATE TABLE IF NOT EXISTS buyers_90d(
                importer_norm TEXT PRIMARY KEY, importer TEXT,
                first_seen REAL, last_seen REAL, shipments INT,
                total_weight REAL, total_qty REAL, total_teu REAL,
                supplier_count INT, origins TEXT, ports TEXT,
                sample_desc TEXT, score REAL, reasons TEXT, updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS suppliers(
                supplier_norm TEXT PRIMARY KEY, name TEXT, slug TEXT,
                shipments INT, first_seen REAL, last_seen REAL,
                harvested_at REAL, bol_fetched INT, updated_at REAL
            );
            """)

            # ========== 后半程统一架构表 ==========
            x.executescript("""
            CREATE TABLE IF NOT EXISTS entities(
                entity_id TEXT PRIMARY KEY,
                norm TEXT UNIQUE NOT NULL,
                name TEXT,
                original_name TEXT,
                country TEXT,
                address TEXT,
                website TEXT,
                phone TEXT,
                enterprise_type TEXT,
                industry TEXT,
                product_categories TEXT,
                brand TEXT,
                entity_status TEXT DEFAULT 'active',
                data_source TEXT,
                info_completeness REAL DEFAULT 0,
                value_score_total REAL DEFAULT 0,
                dev_qualified INT DEFAULT 0,
                created_at REAL,
                updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS entity_roles(
                entity_id TEXT,
                role TEXT CHECK(role IN ('customer','supplier','dual')),
                assigned_at REAL,
                PRIMARY KEY(entity_id, role)
            );
            CREATE TABLE IF NOT EXISTS entity_categories(
                entity_id TEXT,
                category_id TEXT,
                assigned_at REAL,
                PRIMARY KEY(entity_id, category_id)
            );
            CREATE TABLE IF NOT EXISTS trade_edges(
                edge_id TEXT PRIMARY KEY,
                from_entity_id TEXT,
                from_norm TEXT,
                to_entity_id TEXT,
                to_norm TEXT,
                relation TEXT CHECK(relation IN ('supplier_of','customer_of','trades_with')),
                product TEXT,
                hs_code TEXT,
                shipment_count INT DEFAULT 0,
                first_trade REAL,
                last_trade REAL,
                evidence TEXT,
                source_type TEXT,
                confidence REAL DEFAULT 0,
                category_id TEXT,
                created_at REAL,
                updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS evidence(
                evidence_id TEXT PRIMARY KEY,
                entity_id TEXT,
                source_type TEXT,
                source TEXT,
                evidence TEXT,
                confidence REAL DEFAULT 0,
                priority INT DEFAULT 0,
                discovered_at REAL,
                verified_at REAL
            );
            CREATE TABLE IF NOT EXISTS contacts(
                contact_id TEXT PRIMARY KEY,
                entity_id TEXT,
                name TEXT,
                title TEXT,
                email TEXT,
                phone TEXT,
                linkedin TEXT,
                verified INT DEFAULT 0,
                source TEXT,
                discovered_at REAL
            );
            CREATE TABLE IF NOT EXISTS lifecycle_history(
                history_id TEXT PRIMARY KEY,
                entity_id TEXT,
                from_state TEXT,
                to_state TEXT,
                reason TEXT,
                actor TEXT,
                transitioned_at REAL
            );
            CREATE TABLE IF NOT EXISTS tasks(
                task_id TEXT PRIMARY KEY,
                task_name TEXT,
                task_type TEXT,
                category_id TEXT,
                parent_task_id TEXT,
                run_status TEXT DEFAULT 'pending',
                current_stage TEXT,
                current_node TEXT,
                progress_pct REAL DEFAULT 0,
                discovered_customers INT DEFAULT 0,
                discovered_suppliers INT DEFAULT 0,
                new_edges INT DEFAULT 0,
                new_evidence INT DEFAULT 0,
                enrichment_count INT DEFAULT 0,
                development_count INT DEFAULT 0,
                failure_reason TEXT,
                created_at REAL,
                updated_at REAL,
                completed_at REAL
            );
            CREATE TABLE IF NOT EXISTS task_logs(
                log_id TEXT PRIMARY KEY,
                task_id TEXT,
                actor TEXT,
                message TEXT,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS info_gain(
                gain_id TEXT PRIMARY KEY,
                task_id TEXT,
                round_num INT,
                strategy TEXT,
                new_customers INT DEFAULT 0,
                new_suppliers INT DEFAULT 0,
                new_edges INT DEFAULT 0,
                new_evidence INT DEFAULT 0,
                new_contacts INT DEFAULT 0,
                new_emails INT DEFAULT 0,
                total_gain INT DEFAULT 0,
                recorded_at REAL
            );
            CREATE TABLE IF NOT EXISTS expansion_logs(
                log_id TEXT PRIMARY KEY,
                task_id TEXT,
                round_num INT,
                strategy TEXT,
                discovered_entity_id TEXT,
                discovered_norm TEXT,
                discovered_name TEXT,
                discovered_role TEXT,
                relation_type TEXT,
                from_entity_id TEXT,
                evidence TEXT,
                confidence REAL,
                category_id TEXT,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS customer_pool(
                pool_id TEXT PRIMARY KEY,
                norm TEXT,
                name TEXT,
                category_id TEXT,
                source TEXT,
                source_task_id TEXT,
                entity_id TEXT,
                added_at REAL
            );
            CREATE TABLE IF NOT EXISTS supplier_pool(
                pool_id TEXT PRIMARY KEY,
                norm TEXT,
                name TEXT,
                category_id TEXT,
                source TEXT,
                source_task_id TEXT,
                entity_id TEXT,
                added_at REAL
            );
            CREATE TABLE IF NOT EXISTS execution_records(
                record_id TEXT PRIMARY KEY,
                entity_id TEXT,
                execution_type TEXT,
                task_id TEXT,
                draft_subject TEXT,
                draft_body TEXT,
                personalized_content TEXT,
                recipient_email TEXT,
                used_intelligence TEXT,
                used_evidence TEXT,
                used_ai_model TEXT,
                send_status TEXT DEFAULT 'DRAFT',
                sent_at REAL,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS enrichment_queue(
                queue_id TEXT PRIMARY KEY,
                norm TEXT,
                category_id TEXT,
                source_task_id TEXT,
                status TEXT DEFAULT 'pending',
                priority INT DEFAULT 5,
                created_at REAL,
                started_at REAL,
                completed_at REAL
            );
            CREATE TABLE IF NOT EXISTS messages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id TEXT,
                lead_norm TEXT,
                direction TEXT,
                channel TEXT,
                content TEXT,
                draft INT,
                ts REAL
            );
            """)

            x.executescript("""
            CREATE INDEX IF NOT EXISTS idx_entities_norm ON entities(norm);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_from ON trade_edges(from_entity_id, category_id);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_to ON trade_edges(to_entity_id, category_id);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_norms ON trade_edges(from_norm, to_norm);
            CREATE INDEX IF NOT EXISTS idx_evidence_entity ON evidence(entity_id, priority DESC);
            CREATE INDEX IF NOT EXISTS idx_contacts_entity ON contacts(entity_id);
            CREATE INDEX IF NOT EXISTS idx_lifecycle_entity ON lifecycle_history(entity_id, transitioned_at DESC);
            CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(run_status, task_type);
            CREATE INDEX IF NOT EXISTS idx_tasks_parent ON tasks(parent_task_id);
            CREATE INDEX IF NOT EXISTS idx_info_gain_task ON info_gain(task_id, round_num);
            CREATE INDEX IF NOT EXISTS idx_expansion_task ON expansion_logs(task_id, round_num);
            CREATE INDEX IF NOT EXISTS idx_pool_norm ON customer_pool(norm, category_id);
            CREATE INDEX IF NOT EXISTS idx_supplier_pool_norm ON supplier_pool(norm, category_id);
            CREATE INDEX IF NOT EXISTS idx_customs_importer ON customs_raw(importer_norm, ts DESC);
            CREATE INDEX IF NOT EXISTS idx_customs_shipper ON customs_raw(shipper, ts DESC);
            """)

    def get_entity(self, norm: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM entities WHERE norm=?", (norm,)).fetchone()
            return dict(row) if row else None

    def get_entity_by_id(self, entity_id: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM entities WHERE entity_id=?", (entity_id,)).fetchone()
            return dict(row) if row else None

    def get_or_create_entity(self, norm: str, name: str = None, **kwargs) -> Dict:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            existing = x.execute("SELECT * FROM entities WHERE norm=?", (norm,)).fetchone()
            if existing:
                return dict(existing)
            entity_id = f"ent-{uuid.uuid4().hex[:12]}"
            now = time.time()
            x.execute("""
                INSERT INTO entities (entity_id, norm, name, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
            """, (entity_id, norm, name or norm, now, now))
            x.execute("""
                INSERT INTO lifecycle_history (history_id, entity_id, from_state, to_state, reason, actor, transitioned_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (f"lh-{uuid.uuid4().hex[:8]}", entity_id, "", "DISCOVERED", "Entity created", "db_layer", now))
            x.commit()
            return self.get_entity(norm)

    def update_entity(self, norm: str, **fields) -> bool:
        if not fields:
            return False
        allowed = {'name','original_name','country','address','website','phone',
                   'enterprise_type','industry','product_categories','brand',
                   'entity_status','data_source','info_completeness','value_score_total',
                   'dev_qualified'}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        sets = ", ".join([f"{k}=?" for k in updates])
        vals = list(updates.values()) + [time.time(), norm]
        with self.c() as x:
            x.execute(f"UPDATE entities SET {sets}, updated_at=? WHERE norm=?", vals)
            x.commit()
        return True

    def set_entity_role(self, entity_id: str, role: str):
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO entity_roles (entity_id, role, assigned_at)
                VALUES (?, ?, ?)
            """, (entity_id, role, time.time()))
            x.commit()

    def get_entity_roles(self, entity_id: str) -> List[str]:
        with self.c() as x:
            rows = x.execute("SELECT role FROM entity_roles WHERE entity_id=?", (entity_id,)).fetchall()
            return [r[0] for r in rows]

    def set_entity_category(self, entity_id: str, category_id: str):
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO entity_categories (entity_id, category_id, assigned_at)
                VALUES (?, ?, ?)
            """, (entity_id, category_id, time.time()))
            x.commit()

    def get_entity_categories(self, entity_id: str) -> List[str]:
        with self.c() as x:
            rows = x.execute("SELECT category_id FROM entity_categories WHERE entity_id=?", (entity_id,)).fetchall()
            return [r[0] for r in rows]

    def save_trade_edge(self, from_norm: str, to_norm: str, relation: str,
                        product: str = None, hs_code: str = None,
                        shipment_count: int = 0, evidence: str = None,
                        source_type: str = None, confidence: float = 0,
                        category_id: str = None) -> str:
        from_ent = self.get_or_create_entity(from_norm, from_norm)
        to_ent = self.get_or_create_entity(to_norm, to_norm)
        edge_id = f"edge-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT OR REPLACE INTO trade_edges
                (edge_id, from_entity_id, from_norm, to_entity_id, to_norm,
                 relation, product, hs_code, shipment_count, evidence,
                 source_type, confidence, category_id, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (edge_id, from_ent['entity_id'], from_norm, to_ent['entity_id'], to_norm,
                  relation, product, hs_code, shipment_count, evidence,
                  source_type, confidence, category_id, now, now))
            x.commit()
        return edge_id

    def list_trade_edges(self, entity_id: str = None, norm: str = None,
                         category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if entity_id:
                rows = x.execute("""
                    SELECT * FROM trade_edges
                    WHERE from_entity_id=? OR to_entity_id=?
                    ORDER BY confidence DESC, updated_at DESC
                """, (entity_id, entity_id)).fetchall()
            elif norm:
                rows = x.execute("""
                    SELECT * FROM trade_edges
                    WHERE from_norm=? OR to_norm=?
                    ORDER BY confidence DESC, updated_at DESC
                """, (norm, norm)).fetchall()
            else:
                rows = x.execute("SELECT * FROM trade_edges ORDER BY updated_at DESC LIMIT 500").fetchall()
            return [dict(r) for r in rows]

    def find_common_suppliers(self, norm_a: str, norm_b: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT t1.to_norm as supplier_norm, t1.to_entity_id as supplier_id,
                       t1.product, t1.shipment_count as a_count,
                       t2.shipment_count as b_count
                FROM trade_edges t1
                JOIN trade_edges t2 ON t1.to_norm = t2.to_norm
                WHERE t1.from_norm = ? AND t1.relation = 'supplier_of'
                  AND t2.from_norm = ? AND t2.relation = 'supplier_of'
            """, (norm_a, norm_b)).fetchall()
            return [dict(r) for r in rows]

    def find_common_customers(self, norm_a: str, norm_b: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT t1.to_norm as customer_norm, t1.to_entity_id as customer_id,
                       t1.product, t1.shipment_count as a_count,
                       t2.shipment_count as b_count
                FROM trade_edges t1
                JOIN trade_edges t2 ON t1.to_norm = t2.to_norm
                WHERE t1.from_norm = ? AND t1.relation = 'customer_of'
                  AND t2.from_norm = ? AND t2.relation = 'customer_of'
            """, (norm_a, norm_b)).fetchall()
            return [dict(r) for r in rows]

    def get_suppliers_of(self, norm: str) -> List[Dict]:
        return self.list_trade_edges(norm=norm)

    def get_customers_of(self, norm: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM trade_edges WHERE to_norm=? AND relation='customer_of'
                ORDER BY confidence DESC
            """, (norm,)).fetchall()
            return [dict(r) for r in rows]

    def save_evidence(self, entity_id: str, source_type: str, source: str,
                      evidence: str, confidence: float = 0) -> str:
        ev_id = f"ev-{uuid.uuid4().hex[:12]}"
        priority = settings.EVIDENCE_PRIORITY.get(source_type, 0)
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO evidence (evidence_id, entity_id, source_type, source,
                                      evidence, confidence, priority, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (ev_id, entity_id, source_type, source, evidence, confidence, priority, now))
            x.commit()
        return ev_id

    def list_evidence(self, entity_id: str, min_priority: int = 0) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM evidence WHERE entity_id=? AND priority>=?
                ORDER BY priority DESC, discovered_at DESC
            """, (entity_id, min_priority)).fetchall()
            return [dict(r) for r in rows]

    def save_contact(self, entity_id: str, name: str = None, title: str = None,
                     email: str = None, phone: str = None, linkedin: str = None,
                     source: str = None, verified: int = 0) -> str:
        contact_id = f"ct-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO contacts (contact_id, entity_id, name, title, email,
                                      phone, linkedin, source, verified, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (contact_id, entity_id, name, title, email, phone, linkedin, source, verified, now))
            x.commit()
        return contact_id

    def list_entity_contacts(self, entity_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("SELECT * FROM contacts WHERE entity_id=?", (entity_id,)).fetchall()
            return [dict(r) for r in rows]

    def get_current_lifecycle_state(self, entity_id: str) -> str:
        with self.c() as x:
            row = x.execute("""
                SELECT to_state FROM lifecycle_history
                WHERE entity_id=? ORDER BY transitioned_at DESC LIMIT 1
            """, (entity_id,)).fetchone()
            return row[0] if row else "DISCOVERED"

    def transition_lifecycle(self, entity_id: str, from_state: str, to_state: str,
                             reason: str, actor: str) -> str:
        hist_id = f"lh-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO lifecycle_history (history_id, entity_id, from_state, to_state,
                                               reason, actor, transitioned_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (hist_id, entity_id, from_state, to_state, reason, actor, now))
            x.commit()
        return hist_id

    def get_lifecycle_history(self, entity_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM lifecycle_history WHERE entity_id=?
                ORDER BY transitioned_at DESC
            """, (entity_id,)).fetchall()
            return [dict(r) for r in rows]

    def create_task(self, task_id: str, task_name: str, task_type: str,
                    category_id: str = None, parent_task_id: str = None) -> str:
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT OR REPLACE INTO tasks
                (task_id, task_name, task_type, category_id, parent_task_id,
                 run_status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
            """, (task_id, task_name, task_type, category_id, parent_task_id, now, now))
            x.commit()
        return task_id

    def get_task(self, task_id: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            return dict(row) if row else None

    def update_task(self, task_id: str, **fields) -> bool:
        allowed = {'run_status','current_stage','current_node','progress_pct',
                   'discovered_customers','discovered_suppliers','new_edges',
                   'new_evidence','enrichment_count','development_count',
                   'failure_reason','completed_at'}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        sets = ", ".join([f"{k}=?" for k in updates])
        vals = list(updates.values()) + [time.time(), task_id]
        with self.c() as x:
            x.execute(f"UPDATE tasks SET {sets}, updated_at=? WHERE task_id=?", vals)
            x.commit()
        return True

    def list_tasks(self, status: str = None, task_type: str = None,
                   category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            conditions = []
            params = []
            if status:
                conditions.append("run_status=?")
                params.append(status)
            if task_type:
                conditions.append("task_type=?")
                params.append(task_type)
            if category_id:
                conditions.append("category_id=?")
                params.append(category_id)
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = x.execute(f"SELECT * FROM tasks {where} ORDER BY created_at DESC", params).fetchall()
            return [dict(r) for r in rows]

    def pause_task(self, task_id: str) -> bool:
        return self.update_task(task_id, run_status='paused')

    def resume_task(self, task_id: str) -> bool:
        return self.update_task(task_id, run_status='running')

    def save_task_log(self, task_id: str, actor: str, message: str) -> str:
        log_id = f"log-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO task_logs (log_id, task_id, actor, message, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (log_id, task_id, actor, message, now))
            x.commit()
        return log_id

    def get_task_logs(self, task_id: str, limit: int = 100) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM task_logs WHERE task_id=? ORDER BY created_at DESC LIMIT ?
            """, (task_id, limit)).fetchall()
            return [dict(r) for r in rows]

    def record_info_gain(self, task_id: str, round_num: int, strategy: str,
                         new_customers: int = 0, new_suppliers: int = 0,
                         new_edges: int = 0, new_evidence: int = 0,
                         new_contacts: int = 0, new_emails: int = 0,
                         total_gain: int = 0) -> str:
        gain_id = f"gain-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO info_gain (gain_id, task_id, round_num, strategy,
                                       new_customers, new_suppliers, new_edges,
                                       new_evidence, new_contacts, new_emails,
                                       total_gain, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (gain_id, task_id, round_num, strategy, new_customers, new_suppliers,
                  new_edges, new_evidence, new_contacts, new_emails, total_gain, now))
            x.commit()
        return gain_id

    def get_info_gain_curve(self, task_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM info_gain WHERE task_id=? ORDER BY round_num ASC
            """, (task_id,)).fetchall()
            return [dict(r) for r in rows]

    def get_latest_info_gain(self, task_id: str, n_rounds: int = 3) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM info_gain WHERE task_id=?
                ORDER BY round_num DESC LIMIT ?
            """, (task_id, n_rounds)).fetchall()
            return [dict(r) for r in rows]

    def log_expansion(self, task_id: str, round_num: int, strategy: str,
                      discovered_entity_id: str, discovered_norm: str,
                      discovered_name: str, discovered_role: str,
                      relation_type: str, from_entity_id: str = None,
                      evidence: str = None, confidence: float = 0,
                      category_id: str = None) -> str:
        log_id = f"exp-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO expansion_logs (log_id, task_id, round_num, strategy,
                                            discovered_entity_id, discovered_norm,
                                            discovered_name, discovered_role,
                                            relation_type, from_entity_id,
                                            evidence, confidence, category_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (log_id, task_id, round_num, strategy, discovered_entity_id,
                  discovered_norm, discovered_name, discovered_role, relation_type,
                  from_entity_id, evidence, confidence, category_id, now))
            x.commit()
        return log_id

    def get_expansion_logs(self, task_id: str, limit: int = 500) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM expansion_logs WHERE task_id=? ORDER BY created_at DESC LIMIT ?
            """, (task_id, limit)).fetchall()
            return [dict(r) for r in rows]

    def add_to_customer_pool(self, norm: str, name: str = None, category_id: str = None,
                             source: str = None, task_id: str = None) -> str:
        entity = self.get_or_create_entity(norm, name or norm)
        pool_id = f"cp-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO customer_pool
                (pool_id, norm, name, category_id, source, source_task_id, entity_id, added_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (pool_id, norm, name or norm, category_id, source, task_id, entity['entity_id'], now))
            x.commit()
        return pool_id

    def add_to_supplier_pool(self, norm: str, name: str = None, category_id: str = None,
                             source: str = None, task_id: str = None) -> str:
        entity = self.get_or_create_entity(norm, name or norm)
        pool_id = f"sp-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO supplier_pool
                (pool_id, norm, name, category_id, source, source_task_id, entity_id, added_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (pool_id, norm, name or norm, category_id, source, task_id, entity['entity_id'], now))
            x.commit()
        return pool_id

    def list_customer_pool(self, category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if category_id:
                rows = x.execute("SELECT * FROM customer_pool WHERE category_id=? ORDER BY added_at DESC", (category_id,)).fetchall()
            else:
                rows = x.execute("SELECT * FROM customer_pool ORDER BY added_at DESC").fetchall()
            return [dict(r) for r in rows]

    def list_supplier_pool(self, category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if category_id:
                rows = x.execute("SELECT * FROM supplier_pool WHERE category_id=? ORDER BY added_at DESC", (category_id,)).fetchall()
            else:
                rows = x.execute("SELECT * FROM supplier_pool ORDER BY added_at DESC").fetchall()
            return [dict(r) for r in rows]

    def queue_intelligence_task(self, norm: str, category_id: str = None,
                                source_task_id: str = None, priority: int = 5) -> str:
        queue_id = f"q-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO enrichment_queue (queue_id, norm, category_id, source_task_id,
                                              status, priority, created_at)
                VALUES (?, ?, ?, ?, 'pending', ?, ?)
            """, (queue_id, norm, category_id, source_task_id, priority, now))
            x.commit()
        return queue_id

    def get_pending_enrichment_tasks(self, limit: int = 10) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM enrichment_queue WHERE status='pending'
                ORDER BY priority ASC, created_at ASC LIMIT ?
            """, (limit,)).fetchall()
            return [dict(r) for r in rows]

    def mark_enrichment_started(self, queue_id: str):
        with self.c() as x:
            x.execute("UPDATE enrichment_queue SET status='running', started_at=? WHERE queue_id=?",
                      (time.time(), queue_id))
            x.commit()

    def mark_enrichment_completed(self, queue_id: str):
        with self.c() as x:
            x.execute("UPDATE enrichment_queue SET status='completed', completed_at=? WHERE queue_id=?",
                      (time.time(), queue_id))
            x.commit()

    def create_execution_record(self, entity_id: str, execution_type: str, task_id: str,
                                draft_subject: str = "", draft_body: str = "",
                                personalized_content: str = "", recipient_email: str = "",
                                used_intelligence: dict = None, used_evidence: list = None,
                                used_ai_model: str = "") -> str:
        record_id = f"exec-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO execution_records
                (record_id, entity_id, execution_type, task_id, draft_subject, draft_body,
                 personalized_content, recipient_email, used_intelligence, used_evidence,
                 used_ai_model, send_status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?)
            """, (record_id, entity_id, execution_type, task_id, draft_subject, draft_body,
                  personalized_content, recipient_email,
                  json.dumps(used_intelligence or {}), json.dumps(used_evidence or []),
                  used_ai_model, now))
            x.commit()
        return record_id

    def update_execution_status(self, record_id: str, status: str, sent_at: float = None):
        with self.c() as x:
            if sent_at:
                x.execute("UPDATE execution_records SET send_status=?, sent_at=? WHERE record_id=?",
                          (status, sent_at, record_id))
            else:
                x.execute("UPDATE execution_records SET send_status=? WHERE record_id=?",
                          (status, record_id))
            x.commit()

    def get_execution_records(self, entity_id: str = None, status: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            conditions = []
            params = []
            if entity_id:
                conditions.append("entity_id=?")
                params.append(entity_id)
            if status:
                conditions.append("send_status=?")
                params.append(status)
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = x.execute(f"SELECT * FROM execution_records {where} ORDER BY created_at DESC", params).fetchall()
            return [dict(r) for r in rows]

    def save_account_intelligence(self, norm: str, data: dict) -> bool:
        entity = self.get_or_create_entity(norm, data.get('name', norm))
        updates = {}
        if 'country' in data: updates['country'] = data['country']
        if 'address' in data: updates['address'] = data['address']
        if 'website' in data: updates['website'] = data['website']
        if 'phone' in data: updates['phone'] = data['phone']
        if 'enterprise_type' in data: updates['enterprise_type'] = data['enterprise_type']
        if 'industry' in data: updates['industry'] = data['industry']
        if 'product_categories' in data: updates['product_categories'] = data['product_categories']
        if 'brand' in data: updates['brand'] = data['brand']
        if 'info_completeness' in data: updates['info_completeness'] = data['info_completeness']
        if 'value_score_total' in data: updates['value_score_total'] = data['value_score_total']
        if 'dev_qualified' in data: updates['dev_qualified'] = 1 if data['dev_qualified'] else 0
        if updates:
            return self.update_entity(norm, **updates)
        return False

    def save_trade_intelligence(self, norm: str, trade_data: dict) -> bool:
        if not trade_data.get('relation'):
            return False
        self.save_trade_edge(
            from_norm=norm,
            to_norm=trade_data.get('to_norm', ''),
            relation=trade_data['relation'],
            product=trade_data.get('product'),
            hs_code=trade_data.get('hs_code'),
            shipment_count=trade_data.get('shipment_count', 0),
            evidence=trade_data.get('evidence'),
            source_type=trade_data.get('source_type', 'trade_record'),
            confidence=trade_data.get('confidence', 0.7),
            category_id=trade_data.get('category_id')
        )
        entity = self.get_entity(norm)
        if entity and trade_data.get('evidence'):
            self.save_evidence(
                entity_id=entity['entity_id'],
                source_type='trade_record',
                source=trade_data.get('source', 'trade_intelligence'),
                evidence=trade_data['evidence'],
                confidence=trade_data.get('confidence', 0.7)
            )
        return True

    def save_contact_intelligence(self, norm: str, contact_data: dict) -> bool:
        entity = self.get_or_create_entity(norm, contact_data.get('company_name', norm))
        self.save_contact(
            entity_id=entity['entity_id'],
            name=contact_data.get('name'),
            title=contact_data.get('title'),
            email=contact_data.get('email'),
            phone=contact_data.get('phone'),
            linkedin=contact_data.get('linkedin'),
            source=contact_data.get('source', 'enrichment'),
            verified=contact_data.get('verified', 0)
        )
        return True

    def get_old_lead(self, norm: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM leads WHERE norm=?", (norm,)).fetchone()
            return dict(row) if row else None

    def list_old_leads(self, limit: int = 100) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("SELECT * FROM leads LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def get_old_trade_node(self, norm: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM trade_nodes WHERE norm=?", (norm,)).fetchone()
            return dict(row) if row else None

    def count(self, table: str, where: str = "", params: tuple = ()) -> int:
        with self.c() as x:
            sql = f"SELECT COUNT(*) FROM {table}"
            if where:
                sql += f" WHERE {where}"
            row = x.execute(sql, params).fetchone()
            return row[0] if row else 0

    def get_lead_detail(self, norm: str) -> Optional[Dict]:
        entity = self.get_entity(norm)
        if entity:
            return self.get_intelligence(norm)
        return self.get_old_lead(norm)

    def get_intelligence(self, norm: str) -> Optional[Dict]:
        entity = self.get_entity(norm)
        if not entity:
            return None
        entity_id = entity['entity_id']
        return {
            'entity_id': entity_id,
            'norm': norm,
            'basic_identity': {
                'standard_name': entity.get('name', ''),
                'original_name': entity.get('original_name', ''),
                'country': entity.get('country', ''),
                'address': entity.get('address', ''),
                'website': entity.get('website', ''),
                'phone': entity.get('phone', ''),
                'enterprise_type': entity.get('enterprise_type', ''),
                'industry': entity.get('industry', ''),
                'product_categories': entity.get('product_categories', ''),
                'brand': entity.get('brand', ''),
                'entity_status': entity.get('entity_status', 'active'),
                'data_source': entity.get('data_source', ''),
            },
            'trade_identity': {
                'roles': self.get_entity_roles(entity_id),
                'trade_count': self.count('trade_edges', 'from_entity_id=? OR to_entity_id=?', (entity_id, entity_id)),
                'edges': self.list_trade_edges(entity_id=entity_id),
            },
            'contacts': self.list_entity_contacts(entity_id),
            'evidence': self.list_evidence(entity_id),
            'lifecycle': self.get_lifecycle_history(entity_id),
            'info_completeness': entity.get('info_completeness', 0),
            'value_score_total': entity.get('value_score_total', 0),
            'dev_qualified': bool(entity.get('dev_qualified', 0)),
        }

    def move_lead(self, norm: str, from_pool: str, to_pool: str, reason: str = "") -> bool:
        entity = self.get_entity(norm)
        if not entity:
            return False
        self.transition_lifecycle(
            entity_id=entity['entity_id'],
            from_state=from_pool,
            to_state=to_pool,
            reason=reason or f"Moved from {from_pool} to {to_pool}",
            actor="system"
        )
        return True

    def expansion_activity(self, task_id: str = None) -> Dict:
        with self.c() as x:
            total = x.execute("SELECT COUNT(*) FROM expansion_logs").fetchone()[0]
            if task_id:
                task_total = x.execute("SELECT COUNT(*) FROM expansion_logs WHERE task_id=?", (task_id,)).fetchone()[0]
            else:
                task_total = 0
            return {'total': total, 'task_total': task_total}

    def save_schedule(self, name: str, job_type: str, params: dict) -> str:
        return f"sched-{uuid.uuid4().hex[:8]}"

    def toggle_schedule(self, name: str, enabled: bool) -> bool:
        return True

    def delete_schedule(self, name: str) -> bool:
        return True

    def get_sender_profile(self) -> Dict:
        return {
            'name': 'Sales Team',
            'email': 'sales@company.com',
            'signature': 'Best regards,\nSales Team'
        }

    def list_ai_calls(self, limit: int = 100) -> List[Dict]:
        return []
