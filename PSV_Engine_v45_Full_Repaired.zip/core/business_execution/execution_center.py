# -*- coding: utf-8 -*-
"""Business Execution Center v45 (FULL)

业务中心只接收【已经达到开发条件的客户】。
标准流程：
客户确认 → 真实需求证据 → 企业信息达到要求 → 联系人发现 →
联系人验证 → 邮箱验证 → 开发优先级确认 → AI生成开发信 →
生成邮件 → 打开微软邮箱 → 执行发送 → 记录结果 → 跟进
"""
import time, json
from typing import Dict, List, Any, Optional
from core.memory.db import DB
from core.intelligence.ai_router import ai_route, ai_route_structured


class BusinessExecutionCenter:
    def __init__(self, db: DB = None):
        self.db = db or DB()

    def qualify_for_development(self, lead_norm: str) -> Dict[str, Any]:
        """检查开发资格。"""
        entity = self.db.get_entity(lead_norm)
        if not entity:
            return {'qualified': False, 'reason': 'Entity not found'}

        entity_id = entity['entity_id']
        score = self._calculate_score(entity_id)
        contacts = self.db.list_entity_contacts(entity_id)
        has_email = any(c.get('email') for c in contacts)
        current_state = self.db.get_current_lifecycle_state(entity_id)

        checks = {
            'entity_exists': True,
            'trade_evidence': score.get('trade_realness', 0) >= 40,
            'product_match': score.get('product_match', 0) >= 50,
            'recent_activity': score.get('recent_activity', 0) >= 40,
            'info_complete': score.get('info_completeness', 0) >= 40,
            'has_contact': len(contacts) > 0,
            'has_email': has_email,
            'not_blocked': current_state not in ('QUARANTINED', 'INVALID', 'DO_NOT_CONTACT'),
        }

        qualified = all(checks.values())
        failed = [k for k, v in checks.items() if not v]

        return {
            'qualified': qualified,
            'checks': checks,
            'failed_checks': failed,
            'reason': 'All checks passed' if qualified else f"Failed: {', '.join(failed)}",
            'score': score,
            'current_state': current_state,
        }

    def generate_development_letter(self, lead_norm: str, our_product: str = None,
                                    our_company: str = None) -> Dict[str, Any]:
        """AI 生成开发信，使用真实客户情报。"""
        entity = self.db.get_entity(lead_norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found'}

        entity_id = entity['entity_id']
        intelligence = self.db.get_intelligence(lead_norm)
        contacts = self.db.list_entity_contacts(entity_id)
        primary_contact = contacts[0] if contacts else {}
        evidence = self.db.list_evidence(entity_id, min_priority=50)

        # 构建提示
        prompt = f"""请为以下客户生成一封个性化的英文开发信（Business Development Email）。

客户信息：
- 公司名称: {entity.get('name', lead_norm)}
- 国家: {entity.get('country', '')}
- 行业: {entity.get('industry', '')}
- 产品类别: {entity.get('product_categories', '')}
- 联系人: {primary_contact.get('name', '')} ({primary_contact.get('title', '')})
- 贸易证据: {json.dumps([e['evidence'] for e in evidence[:3]], ensure_ascii=False)}

我方信息：
- 我方公司: {our_company or 'Our Company'}
- 我方产品: {our_product or 'relevant products'}

要求：
1. 使用真实客户情报（贸易行为、产品、国家等）
2. 不要生成泛化群发邮件
3. 自然、专业、简洁
4. 包含明确的行动号召（CTA）
5. 主题行要吸引人但不过度营销

请返回：
Subject: [邮件主题]
Body: [邮件正文]
"""

        result = ai_route_structured(prompt, model_preference=['deepseek', 'qwen', 'gpt'])
        if not result['success']:
            return {'ok': False, 'error': result.get('error', 'AI generation failed')}

        content = result['content']
        subject = self._extract_subject(content)
        body = self._extract_body(content)

        # 保存执行记录
        record_id = self.db.create_execution_record(
            entity_id=entity_id,
            execution_type='development_letter',
            task_id=f"dev-{int(time.time())}",
            draft_subject=subject,
            draft_body=body,
            personalized_content=content,
            recipient_email=primary_contact.get('email', ''),
            used_intelligence=intelligence,
            used_evidence=[e['evidence_id'] for e in evidence[:5]],
            used_ai_model=result.get('provider', 'unknown')
        )

        # 更新生命周期
        self.db.transition_lifecycle(
            entity_id=entity_id,
            from_state=self.db.get_current_lifecycle_state(entity_id),
            to_state='READY_FOR_OUTREACH',
            reason='Development letter generated',
            actor='business_execution_center'
        )

        return {
            'ok': True,
            'record_id': record_id,
            'subject': subject,
            'body': body,
            'personalized': content,
            'recipient': primary_contact.get('email', ''),
            'used_model': result.get('provider'),
            'used_intelligence': intelligence,
        }

    def open_outlook_and_send(self, record_id: str) -> Dict[str, Any]:
        """
        半自动销售执行：
        系统生成邮件草稿 → 用户点击【打开邮箱/发送】→
        AI/浏览器打开微软邮箱 → 自动创建邮件 → 填写信息 → 系统执行发送动作
        """
        records = self.db.get_execution_records(record_id=record_id)
        if not records:
            return {'ok': False, 'error': 'Record not found', 'status': 'FAILED'}

        record = records[0]

        # 检查邮箱环境
        # 实际实现中应调用浏览器自动化（如 Playwright/Selenium）
        # 此处为框架逻辑
        try:
            # 模拟：检查 Outlook 登录状态
            outlook_ready = self._check_outlook_login()
            if not outlook_ready:
                return {
                    'ok': False,
                    'error': 'Microsoft Outlook not logged in. Please login first.',
                    'status': 'FAILED',
                    'action_required': 'LOGIN_OUTLOOK'
                }

            # 模拟：创建邮件并发送
            # 实际应调用浏览器自动化
            sent = self._simulate_send(record)
            if sent:
                self.db.update_execution_status(record_id, 'SENT', sent_at=time.time())
                # 更新生命周期
                entity_id = record.get('entity_id')
                if entity_id:
                    self.db.transition_lifecycle(
                        entity_id=entity_id,
                        from_state='READY_FOR_OUTREACH',
                        to_state='OUTREACH_ACTIVE',
                        reason='Email sent via Outlook',
                        actor='business_execution_center'
                    )
                return {
                    'ok': True,
                    'status': 'SENT',
                    'record_id': record_id,
                    'sent_at': time.time()
                }
            else:
                self.db.update_execution_status(record_id, 'FAILED')
                return {'ok': False, 'error': 'Send failed', 'status': 'FAILED'}

        except Exception as e:
            self.db.update_execution_status(record_id, 'FAILED')
            return {'ok': False, 'error': str(e), 'status': 'FAILED'}

    def _calculate_score(self, entity_id: str) -> Dict:
        """计算开发价值评分（复用情报中心逻辑）"""
        entity = self.db.get_entity_by_id(entity_id)
        edges = self.db.list_trade_edges(entity_id=entity_id)
        contacts = self.db.list_entity_contacts(entity_id)

        trade_realness = min(100, len(edges) * 25)
        product_match = 70
        recent_activity = 80 if edges and any(e.get('last_trade', 0) > time.time() - 90*86400 for e in edges) else 40
        purchase_strength = min(100, sum(e.get('shipment_count', 0) for e in edges) * 5)
        info_completeness = self._calc_completeness(entity_id)
        contact_availability = min(100, len(contacts) * 50)

        total = (trade_realness * 0.2 + product_match * 0.15 + recent_activity * 0.15 +
                purchase_strength * 0.15 + info_completeness * 0.15 + contact_availability * 0.2)

        return {
            'trade_realness': trade_realness,
            'product_match': product_match,
            'recent_activity': recent_activity,
            'purchase_strength': purchase_strength,
            'info_completeness': info_completeness,
            'contact_availability': contact_availability,
            'total_score': round(total, 1),
        }

    def _calc_completeness(self, entity_id: str) -> float:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return 0.0
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories']
        filled = sum(1 for f in fields if entity.get(f))
        return round(filled / len(fields) * 100, 1)

    def _extract_subject(self, content: str) -> str:
        for line in content.split('\n'):
            if line.lower().startswith('subject:'):
                return line.split(':', 1)[1].strip()
        return "Business Collaboration Opportunity"

    def _extract_body(self, content: str) -> str:
        parts = content.split('Body:', 1)
        return parts[1].strip() if len(parts) > 1 else content

    def _check_outlook_login(self) -> bool:
        # 实际应检测浏览器中的 Outlook 登录状态
        return True  # 框架占位

    def _simulate_send(self, record: Dict) -> bool:
        # 实际应调用浏览器自动化发送
        return True  # 框架占位
