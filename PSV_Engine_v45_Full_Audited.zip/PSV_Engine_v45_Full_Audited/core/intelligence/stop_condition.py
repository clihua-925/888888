# -*- coding: utf-8 -*-
"""Dynamic Stop Condition v45 (AUDITED)

Core principle: Information gain prioritized over fixed time.
- Check info gain first, then time
- Switch strategies before stopping
- Multiple consecutive low-gain rounds with different strategies = convergence
"""
import time
from typing import Dict, Tuple
from core.config import settings


class DynamicStopCondition:
    def __init__(self):
        self.min_time = settings.MIN_EXPANSION_TIME
        self.max_time = settings.MAX_EXPANSION_TIME
        self.convergence_threshold = settings.CONVERGENCE_THRESHOLD
        self.gain_threshold = settings.GAIN_THRESHOLD
        self.strategy_switch_threshold = 2

    def should_stop(self, task_id: str, current_round: int, execution_time: float,
                    info_gain_stats: Dict) -> Tuple[bool, str]:
        # 1. Minimum execution time guard
        if execution_time < self.min_time:
            return False, f"Minimum time not reached ({int(execution_time)}s < {self.min_time}s)"

        # 2. Maximum safety time
        if execution_time > self.max_time:
            return True, f"Maximum safety time reached ({int(execution_time)}s > {self.max_time}s)"

        # 3. Info gain analysis
        recent = info_gain_stats.get('recent_rounds', [])
        if len(recent) < self.convergence_threshold:
            return False, f"Insufficient rounds for convergence ({len(recent)} < {self.convergence_threshold})"

        low_gain_rounds = 0
        strategies_in_low_gain = set()
        for r in recent:
            total = r.get('total_gain', 0)
            if total < self.gain_threshold:
                low_gain_rounds += 1
                strategies_in_low_gain.add(r.get('strategy', 'unknown'))
            else:
                low_gain_rounds = 0
                strategies_in_low_gain.clear()

        # 4. Consecutive low gain threshold
        if low_gain_rounds >= self.convergence_threshold:
            unique_strategies = len(strategies_in_low_gain)
            if unique_strategies >= self.strategy_switch_threshold:
                return True, (
                    f"CONVERGENCE: {low_gain_rounds} consecutive low-gain rounds "
                    f"with {unique_strategies} strategies tried. "
                    f"Last gain: {recent[-1].get('total_gain', 0)}. "
                    f"Time: {int(execution_time)}s."
                )
            else:
                return False, (
                    f"LOW_GAIN: {low_gain_rounds} rounds low gain, "
                    f"but only {unique_strategies} strategy types. "
                    f"RECOMMEND: Switch to untried strategy before stopping."
                )

        # 5. Continue normally
        last_gain = recent[-1].get('total_gain', 0) if recent else 0
        return False, f"Gain continues: {last_gain} new items in last round."

    def get_stop_summary(self, task_id: str, info_gain_curve: list) -> Dict:
        if not info_gain_curve:
            return {'stop_reason': 'No data', 'last_round': 0, 'gain_curve': []}

        total_rounds = len(info_gain_curve)
        peak_gain = max(r.get('total_gain', 0) for r in info_gain_curve) if info_gain_curve else 0
        avg_gain = sum(r.get('total_gain', 0) for r in info_gain_curve) / total_rounds if total_rounds > 0 else 0

        return {
            'stop_reason': 'Convergence or safety limit',
            'last_round': info_gain_curve[-1].get('round_num', 0),
            'gain_curve': info_gain_curve,
            'unprocessed_nodes': 0,
            'total_rounds': total_rounds,
            'peak_gain': peak_gain,
            'average_gain': round(avg_gain, 2),
        }
