# -*- coding: utf-8 -*-
"""PSV Engine Configuration v45 (AUDITED)"""

import os

DATABASE_PATH = os.environ.get('PSV_DB_PATH', 'psv_engine_v45.db')

AI_PROVIDERS = [
    {
        'name': 'deepseek',
        'model': 'deepseek-chat',
        'api_key_env': 'DEEPSEEK_API_KEY',
        'priority': 1,
        'base_url': 'https://api.deepseek.com'
    },
    {
        'name': 'qwen',
        'model': 'qwen-max',
        'api_key_env': 'QWEN_API_KEY',
        'priority': 2,
        'base_url': 'https://dashscope.aliyuncs.com/compatible-mode/v1'
    },
    {
        'name': 'gpt',
        'model': 'gpt-4o',
        'api_key_env': 'OPENAI_API_KEY',
        'priority': 3,
        'base_url': None
    }
]

AI_TIMEOUT = 60

EVIDENCE_PRIORITY = {
    'trade_record': 100,
    'customs_raw': 95,
    'buyers_90d': 90,
    'company_website': 70,
    'public_registry': 65,
    'search_engine': 50,
    'public_webpage': 45,
    'contact_finder': 40,
    'enrichment': 35,
    'network_expansion': 25,
    'ai_inference': 20,
}

LIFECYCLE_STATES = [
    'DISCOVERED', 'TRADE_CONFIRMED', 'ENRICHING', 'ENRICHED',
    'CONTACT_FOUND', 'CONTACT_VERIFIED', 'QUALIFIED',
    'READY_FOR_OUTREACH', 'OUTREACH_ACTIVE', 'REPLIED',
    'FOLLOW_UP', 'OPPORTUNITY', 'CUSTOMER',
    'QUARANTINED', 'INVALID', 'NO_SIGNAL', 'DO_NOT_CONTACT'
]

MIN_EXPANSION_TIME = 120
MAX_EXPANSION_TIME = 1800
CONVERGENCE_THRESHOLD = 3
GAIN_THRESHOLD = 2

CATEGORIES = {
    'candle': '蜡烛',
    'enamel_pot': '珐琅锅',
    'felt': '毛毡'
}
