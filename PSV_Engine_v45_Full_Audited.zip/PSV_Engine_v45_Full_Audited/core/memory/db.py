# -*- coding: utf-8 -*-
"""PSV Engine v45 - Unified Database Layer (FULL AUDITED)

Core principles:
1. One entity = one entity_id + multiple roles/relations/evidence/category links
2. Intelligence/Graph/Business share unified entities table
3. No duplicate company data across modules
4. All post-collection tables have category_id field (3-category isolation)
5. First collection chain 100% frozen (customs_raw/buyers_90d read-only)
6. Old tables leads/trade_nodes/relationships deprecated, no new writes
"""
import sqlite3, time, json, uuid
from typing import Dict, List, Any, Optional
from core.config import settings


class DB:
    def __init__(self, path=None):
        self.path = path or settings.DATABASE_PATH
        self.init()

    def c(self):
        return sqlite3.connect(self.path, timeout=10, check_same_thread=False)

    def init(self):
        with self.c() as x:
            # ========== First Collection Chain (100% FROZEN, READ-ONLY) ==========
            x.executescript("""
            CREATE TABLE IF NOT EXISTS customs_raw(
                id INTEGER PRIMARY KEY AUTOINCREMENT, row_hash TEXT UNIQUE,
                bol TEXT, ts REAL, importer TEXT, importer_norm TEXT,
                shipper TEXT, notify TEXT, hs TEXT, descr TEXT, qty REAL,
                weight REAL, teu REAL, origin TEXT, port_load TEXT,
                port_discharge TEXT, source_file TEXT,
                direct_importer INT, created_at REAL
            );
            CREATE TABLE IF NOT EXISTS buyers_90d(
                importer_norm TEXT PRIMARY KEY, importer TEXT,
                first_seen REAL, last_seen REAL, shipments INT,
                total_weight REAL, total_qty REAL, total_teu REAL,
                supplier_count INT, origins TEXT, ports TEXT,
                sample_desc TEXT, score REAL, reasons TEXT, updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS suppliers(
                supplier_norm TEXT PRIMARY KEY, name TEXT, slug TEXT,
                shipments INT, first_seen REAL, last_seen REAL,
                harvested_at REAL, bol_fetched INT, updated_at REAL
            );
            """)

            # ========== Post-Collection Unified Schema ==========
            x.executescript("""
            CREATE TABLE IF NOT EXISTS entities(
                entity_id TEXT PRIMARY KEY,
                norm TEXT UNIQUE NOT NULL,
                name TEXT,
                original_name TEXT,
                country TEXT,
                address TEXT,
                website TEXT,
                phone TEXT,
                enterprise_type TEXT,
                industry TEXT,
                product_categories TEXT,
                brand TEXT,
                entity_status TEXT DEFAULT 'active',
                data_source TEXT,
                info_completeness REAL DEFAULT 0,
                value_score_total REAL DEFAULT 0,
                dev_qualified INT DEFAULT 0,
                created_at REAL,
                updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS entity_roles(
                entity_id TEXT,
                role TEXT CHECK(role IN ('customer','supplier','dual')),
                assigned_at REAL,
                PRIMARY KEY(entity_id, role)
            );
            CREATE TABLE IF NOT EXISTS entity_categories(
                entity_id TEXT,
                category_id TEXT,
                assigned_at REAL,
                PRIMARY KEY(entity_id, category_id)
            );
            CREATE TABLE IF NOT EXISTS trade_edges(
                edge_id TEXT PRIMARY KEY,
                from_entity_id TEXT,
                from_norm TEXT,
                to_entity_id TEXT,
                to_norm TEXT,
                relation TEXT CHECK(relation IN ('supplier_of','customer_of','trades_with')),
                product TEXT,
                hs_code TEXT,
                shipment_count INT DEFAULT 0,
                first_trade REAL,
                last_trade REAL,
                evidence TEXT,
                source_type TEXT,
                confidence REAL DEFAULT 0,
                category_id TEXT,
                created_at REAL,
                updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS evidence(
                evidence_id TEXT PRIMARY KEY,
                entity_id TEXT,
                source_type TEXT,
                source TEXT,
                evidence TEXT,
                confidence REAL DEFAULT 0,
                priority INT DEFAULT 0,
                discovered_at REAL,
                verified_at REAL
            );
            CREATE TABLE IF NOT EXISTS contacts(
                contact_id TEXT PRIMARY KEY,
                entity_id TEXT,
                name TEXT,
                title TEXT,
                email TEXT,
                phone TEXT,
                linkedin TEXT,
                verified INT DEFAULT 0,
                source TEXT,
                discovered_at REAL
            );
            CREATE TABLE IF NOT EXISTS lifecycle_history(
                history_id TEXT PRIMARY KEY,
                entity_id TEXT,
                from_state TEXT,
                to_state TEXT,
                reason TEXT,
                actor TEXT,
                transitioned_at REAL
            );
            CREATE TABLE IF NOT EXISTS tasks(
                task_id TEXT PRIMARY KEY,
                task_name TEXT,
                task_type TEXT,
                category_id TEXT,
                parent_task_id TEXT,
                run_status TEXT DEFAULT 'pending',
                current_stage TEXT,
                current_node TEXT,
                progress_pct REAL DEFAULT 0,
                discovered_customers INT DEFAULT 0,
                discovered_suppliers INT DEFAULT 0,
                new_edges INT DEFAULT 0,
                new_evidence INT DEFAULT 0,
                enrichment_count INT DEFAULT 0,
                development_count INT DEFAULT 0,
                failure_reason TEXT,
                created_at REAL,
                updated_at REAL,
                completed_at REAL
            );
            CREATE TABLE IF NOT EXISTS task_logs(
                log_id TEXT PRIMARY KEY,
                task_id TEXT,
                actor TEXT,
                message TEXT,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS info_gain(
                gain_id TEXT PRIMARY KEY,
                task_id TEXT,
                round_num INT,
                strategy TEXT,
                new_customers INT DEFAULT 0,
                new_suppliers INT DEFAULT 0,
                new_edges INT DEFAULT 0,
                new_evidence INT DEFAULT 0,
                new_contacts INT DEFAULT 0,
                new_emails INT DEFAULT 0,
                total_gain INT DEFAULT 0,
                recorded_at REAL
            );
            CREATE TABLE IF NOT EXISTS expansion_logs(
                log_id TEXT PRIMARY KEY,
                task_id TEXT,
                round_num INT,
                strategy TEXT,
                discovered_entity_id TEXT,
                discovered_norm TEXT,
                discovered_name TEXT,
                discovered_role TEXT,
                relation_type TEXT,
                from_entity_id TEXT,
                evidence TEXT,
                confidence REAL,
                category_id TEXT,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS customer_pool(
                pool_id TEXT PRIMARY KEY,
                norm TEXT,
                name TEXT,
                category_id TEXT,
                source TEXT,
                source_task_id TEXT,
                entity_id TEXT,
                added_at REAL
            );
            CREATE TABLE IF NOT EXISTS supplier_pool(
                pool_id TEXT PRIMARY KEY,
                norm TEXT,
                name TEXT,
                category_id TEXT,
                source TEXT,
                source_task_id TEXT,
                entity_id TEXT,
                added_at REAL
            );
            CREATE TABLE IF NOT EXISTS execution_records(
                record_id TEXT PRIMARY KEY,
                entity_id TEXT,
                execution_type TEXT,
                task_id TEXT,
                draft_subject TEXT,
                draft_body TEXT,
                personalized_content TEXT,
                recipient_email TEXT,
                used_intelligence TEXT,
                used_evidence TEXT,
                used_ai_model TEXT,
                send_status TEXT DEFAULT 'DRAFT',
                sent_at REAL,
                created_at REAL
            );
            CREATE TABLE IF NOT EXISTS enrichment_queue(
                queue_id TEXT PRIMARY KEY,
                norm TEXT,
                category_id TEXT,
                source_task_id TEXT,
                status TEXT DEFAULT 'pending',
                priority INT DEFAULT 5,
                created_at REAL,
                started_at REAL,
                completed_at REAL
            );
            CREATE TABLE IF NOT EXISTS messages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id TEXT,
                lead_norm TEXT,
                direction TEXT,
                channel TEXT,
                content TEXT,
                draft INT,
                ts REAL
            );
            """)

            x.executescript("""
            CREATE INDEX IF NOT EXISTS idx_entities_norm ON entities(norm);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_from ON trade_edges(from_entity_id, category_id);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_to ON trade_edges(to_entity_id, category_id);
            CREATE INDEX IF NOT EXISTS idx_trade_edges_norms ON trade_edges(from_norm, to_norm);
            CREATE INDEX IF NOT EXISTS idx_evidence_entity ON evidence(entity_id, priority DESC);
            CREATE INDEX IF NOT EXISTS idx_contacts_entity ON contacts(entity_id);
            CREATE INDEX IF NOT EXISTS idx_lifecycle_entity ON lifecycle_history(entity_id, transitioned_at DESC);
            CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(run_status, task_type);
            CREATE INDEX IF NOT EXISTS idx_tasks_parent ON tasks(parent_task_id);
            CREATE INDEX IF NOT EXISTS idx_info_gain_task ON info_gain(task_id, round_num);
            CREATE INDEX IF NOT EXISTS idx_expansion_task ON expansion_logs(task_id, round_num);
            CREATE INDEX IF NOT EXISTS idx_pool_norm ON customer_pool(norm, category_id);
            CREATE INDEX IF NOT EXISTS idx_supplier_pool_norm ON supplier_pool(norm, category_id);
            CREATE INDEX IF NOT EXISTS idx_customs_importer ON customs_raw(importer_norm, ts DESC);
            CREATE INDEX IF NOT EXISTS idx_customs_shipper ON customs_raw(shipper, ts DESC);
            """)

    # ========== Entity Operations ==========
    def get_entity(self, norm: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM entities WHERE norm=?", (norm,)).fetchone()
            return dict(row) if row else None

    def get_entity_by_id(self, entity_id: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM entities WHERE entity_id=?", (entity_id,)).fetchone()
            return dict(row) if row else None

    def get_or_create_entity(self, norm: str, name: str = None, **kwargs) -> Dict:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            existing = x.execute("SELECT * FROM entities WHERE norm=?", (norm,)).fetchone()
            if existing:
                return dict(existing)
            entity_id = f"ent-{uuid.uuid4().hex[:12]}"
            now = time.time()
            x.execute("""
                INSERT INTO entities (entity_id, norm, name, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
            """, (entity_id, norm, name or norm, now, now))
            x.execute("""
                INSERT INTO lifecycle_history (history_id, entity_id, from_state, to_state, reason, actor, transitioned_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (f"lh-{uuid.uuid4().hex[:8]}", entity_id, "", "DISCOVERED", "Entity created", "db_layer", now))
            x.commit()
            return self.get_entity(norm)

    def update_entity(self, norm: str, **fields) -> bool:
        if not fields:
            return False
        allowed = {'name','original_name','country','address','website','phone',
                   'enterprise_type','industry','product_categories','brand',
                   'entity_status','data_source','info_completeness','value_score_total',
                   'dev_qualified'}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        sets = ", ".join([f"{k}=?" for k in updates])
        vals = list(updates.values()) + [time.time(), norm]
        with self.c() as x:
            x.execute(f"UPDATE entities SET {sets}, updated_at=? WHERE norm=?", vals)
            x.commit()
        return True

    def set_entity_role(self, entity_id: str, role: str):
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO entity_roles (entity_id, role, assigned_at)
                VALUES (?, ?, ?)
            """, (entity_id, role, time.time()))
            x.commit()

    def get_entity_roles(self, entity_id: str) -> List[str]:
        with self.c() as x:
            rows = x.execute("SELECT role FROM entity_roles WHERE entity_id=?", (entity_id,)).fetchall()
            return [r[0] for r in rows]

    def set_entity_category(self, entity_id: str, category_id: str):
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO entity_categories (entity_id, category_id, assigned_at)
                VALUES (?, ?, ?)
            """, (entity_id, category_id, time.time()))
            x.commit()

    def get_entity_categories(self, entity_id: str) -> List[str]:
        with self.c() as x:
            rows = x.execute("SELECT category_id FROM entity_categories WHERE entity_id=?", (entity_id,)).fetchall()
            return [r[0] for r in rows]

    # ========== Trade Edge Operations ==========
    def save_trade_edge(self, from_norm: str, to_norm: str, relation: str,
                        product: str = None, hs_code: str = None,
                        shipment_count: int = 0, evidence: str = None,
                        source_type: str = None, confidence: float = 0,
                        category_id: str = None) -> str:
        from_ent = self.get_or_create_entity(from_norm, from_norm)
        to_ent = self.get_or_create_entity(to_norm, to_norm)
        edge_id = f"edge-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT OR REPLACE INTO trade_edges
                (edge_id, from_entity_id, from_norm, to_entity_id, to_norm,
                 relation, product, hs_code, shipment_count, evidence,
                 source_type, confidence, category_id, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (edge_id, from_ent['entity_id'], from_norm, to_ent['entity_id'], to_norm,
                  relation, product, hs_code, shipment_count, evidence,
                  source_type, confidence, category_id, now, now))
            x.commit()
        return edge_id

    def list_trade_edges(self, entity_id: str = None, norm: str = None,
                         category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if entity_id:
                rows = x.execute("""
                    SELECT * FROM trade_edges
                    WHERE from_entity_id=? OR to_entity_id=?
                    ORDER BY confidence DESC, updated_at DESC
                """, (entity_id, entity_id)).fetchall()
            elif norm:
                rows = x.execute("""
                    SELECT * FROM trade_edges
                    WHERE from_norm=? OR to_norm=?
                    ORDER BY confidence DESC, updated_at DESC
                """, (norm, norm)).fetchall()
            else:
                rows = x.execute("SELECT * FROM trade_edges ORDER BY updated_at DESC LIMIT 500").fetchall()
            return [dict(r) for r in rows]

    def get_customers_of(self, norm: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM trade_edges WHERE to_norm=? AND relation='customer_of'
                ORDER BY confidence DESC
            """, (norm,)).fetchall()
            return [dict(r) for r in rows]

    # ========== Evidence Operations ==========
    def save_evidence(self, entity_id: str, source_type: str, source: str,
                      evidence: str, confidence: float = 0) -> str:
        ev_id = f"ev-{uuid.uuid4().hex[:12]}"
        priority = settings.EVIDENCE_PRIORITY.get(source_type, 0)
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO evidence (evidence_id, entity_id, source_type, source,
                                      evidence, confidence, priority, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (ev_id, entity_id, source_type, source, evidence, confidence, priority, now))
            x.commit()
        return ev_id

    def list_evidence(self, entity_id: str, min_priority: int = 0) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM evidence WHERE entity_id=? AND priority>=?
                ORDER BY priority DESC, discovered_at DESC
            """, (entity_id, min_priority)).fetchall()
            return [dict(r) for r in rows]

    # ========== Contact Operations ==========
    def save_contact(self, entity_id: str, name: str = None, title: str = None,
                     email: str = None, phone: str = None, linkedin: str = None,
                     source: str = None, verified: int = 0) -> str:
        contact_id = f"ct-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO contacts (contact_id, entity_id, name, title, email,
                                      phone, linkedin, source, verified, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (contact_id, entity_id, name, title, email, phone, linkedin, source, verified, now))
            x.commit()
        return contact_id

    def list_entity_contacts(self, entity_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("SELECT * FROM contacts WHERE entity_id=?", (entity_id,)).fetchall()
            return [dict(r) for r in rows]

    # ========== Lifecycle Operations ==========
    def get_current_lifecycle_state(self, entity_id: str) -> str:
        with self.c() as x:
            row = x.execute("""
                SELECT to_state FROM lifecycle_history
                WHERE entity_id=? ORDER BY transitioned_at DESC LIMIT 1
            """, (entity_id,)).fetchone()
            return row[0] if row else "DISCOVERED"

    def transition_lifecycle(self, entity_id: str, from_state: str, to_state: str,
                             reason: str, actor: str) -> str:
        hist_id = f"lh-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO lifecycle_history (history_id, entity_id, from_state, to_state,
                                               reason, actor, transitioned_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (hist_id, entity_id, from_state, to_state, reason, actor, now))
            x.commit()
        return hist_id

    def get_lifecycle_history(self, entity_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM lifecycle_history WHERE entity_id=?
                ORDER BY transitioned_at DESC
            """, (entity_id,)).fetchall()
            return [dict(r) for r in rows]

    # ========== Task Operations ==========
    def create_task(self, task_id: str, task_name: str, task_type: str,
                    category_id: str = None, parent_task_id: str = None) -> str:
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT OR REPLACE INTO tasks
                (task_id, task_name, task_type, category_id, parent_task_id,
                 run_status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
            """, (task_id, task_name, task_type, category_id, parent_task_id, now, now))
            x.commit()
        return task_id

    def get_task(self, task_id: str) -> Optional[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            row = x.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            return dict(row) if row else None

    def update_task(self, task_id: str, **fields) -> bool:
        allowed = {'run_status','current_stage','current_node','progress_pct',
                   'discovered_customers','discovered_suppliers','new_edges',
                   'new_evidence','enrichment_count','development_count',
                   'failure_reason','completed_at'}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        sets = ", ".join([f"{k}=?" for k in updates])
        vals = list(updates.values()) + [time.time(), task_id]
        with self.c() as x:
            x.execute(f"UPDATE tasks SET {sets}, updated_at=? WHERE task_id=?", vals)
            x.commit()
        return True

    def list_tasks(self, status: str = None, task_type: str = None,
                   category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            conditions = []
            params = []
            if status:
                conditions.append("run_status=?")
                params.append(status)
            if task_type:
                conditions.append("task_type=?")
                params.append(task_type)
            if category_id:
                conditions.append("category_id=?")
                params.append(category_id)
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = x.execute(f"SELECT * FROM tasks {where} ORDER BY created_at DESC", params).fetchall()
            return [dict(r) for r in rows]

    def pause_task(self, task_id: str) -> bool:
        return self.update_task(task_id, run_status='paused')

    def resume_task(self, task_id: str) -> bool:
        return self.update_task(task_id, run_status='running')

    def save_task_log(self, task_id: str, actor: str, message: str) -> str:
        log_id = f"log-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO task_logs (log_id, task_id, actor, message, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (log_id, task_id, actor, message, now))
            x.commit()
        return log_id

    def get_task_logs(self, task_id: str, limit: int = 100) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM task_logs WHERE task_id=? ORDER BY created_at DESC LIMIT ?
            """, (task_id, limit)).fetchall()
            return [dict(r) for r in rows]

    # ========== Info Gain Operations ==========
    def record_info_gain(self, task_id: str, round_num: int, strategy: str,
                         new_customers: int = 0, new_suppliers: int = 0,
                         new_edges: int = 0, new_evidence: int = 0,
                         new_contacts: int = 0, new_emails: int = 0,
                         total_gain: int = 0) -> str:
        gain_id = f"gain-{uuid.uuid4().hex[:8]}"
        now = time.time()
        with self.c() as x:
            x.execute("""
                INSERT INTO info_gain (gain_id, task_id, round_num, strategy,
                                       new_customers, new_suppliers, new_edges,
                                       new_evidence, new_contacts, new_emails,
                                       total_gain, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (gain_id, task_id, round_num, strategy, new_customers, new_suppliers,
                  new_edges, new_evidence, new_contacts, new_emails, total_gain, now))
            x.commit()
        return gain_id

    def get_info_gain_curve(self, task_id: str) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM info_gain WHERE task_id=? ORDER BY round_num ASC
            """, (task_id,)).fetchall()
            return [dict(r) for r in rows]

    def get_latest_info_gain(self, task_id: str, n_rounds: int = 3) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM info_gain WHERE task_id=? ORDER BY round_num DESC LIMIT ?
            """, (task_id, n_rounds)).fetchall()
            return [dict(r) for r in rows]

    # ========== Pool Operations ==========
    def add_to_customer_pool(self, norm: str, name: str, category_id: str,
                             source: str, task_id: str):
        pool_id = f"cp-{uuid.uuid4().hex[:8]}"
        entity = self.get_entity(norm)
        entity_id = entity.get('entity_id') if entity else None
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO customer_pool
                (pool_id, norm, name, category_id, source, source_task_id, entity_id, added_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (pool_id, norm, name or norm, category_id, source, task_id, entity_id, time.time()))
            x.commit()

    def add_to_supplier_pool(self, norm: str, name: str, category_id: str,
                             source: str, task_id: str):
        pool_id = f"sp-{uuid.uuid4().hex[:8]}"
        entity = self.get_entity(norm)
        entity_id = entity.get('entity_id') if entity else None
        with self.c() as x:
            x.execute("""
                INSERT OR IGNORE INTO supplier_pool
                (pool_id, norm, name, category_id, source, source_task_id, entity_id, added_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (pool_id, norm, name or norm, category_id, source, task_id, entity_id, time.time()))
            x.commit()

    def list_customer_pool(self, category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if category_id:
                rows = x.execute("SELECT * FROM customer_pool WHERE category_id=? ORDER BY added_at DESC", (category_id,)).fetchall()
            else:
                rows = x.execute("SELECT * FROM customer_pool ORDER BY added_at DESC").fetchall()
            return [dict(r) for r in rows]

    def list_supplier_pool(self, category_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            if category_id:
                rows = x.execute("SELECT * FROM supplier_pool WHERE category_id=? ORDER BY added_at DESC", (category_id,)).fetchall()
            else:
                rows = x.execute("SELECT * FROM supplier_pool ORDER BY added_at DESC").fetchall()
            return [dict(r) for r in rows]

    # ========== Expansion Log Operations ==========
    def log_expansion(self, task_id: str, round_num: int, strategy: str,
                      discovered_entity_id: str, discovered_norm: str,
                      discovered_name: str, discovered_role: str,
                      relation_type: str, from_entity_id: str = None,
                      evidence: str = None, confidence: float = 0,
                      category_id: str = None):
        log_id = f"el-{uuid.uuid4().hex[:8]}"
        with self.c() as x:
            x.execute("""
                INSERT INTO expansion_logs
                (log_id, task_id, round_num, strategy, discovered_entity_id,
                 discovered_norm, discovered_name, discovered_role, relation_type,
                 from_entity_id, evidence, confidence, category_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (log_id, task_id, round_num, strategy, discovered_entity_id,
                  discovered_norm, discovered_name, discovered_role, relation_type,
                  from_entity_id, evidence, confidence, category_id, time.time()))
            x.commit()

    def get_expansion_logs(self, task_id: str, limit: int = 500) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            rows = x.execute("""
                SELECT * FROM expansion_logs WHERE task_id=?
                ORDER BY round_num, created_at DESC LIMIT ?
            """, (task_id, limit)).fetchall()
            return [dict(r) for r in rows]

    # ========== Execution Record Operations ==========
    def create_execution_record(self, entity_id: str, execution_type: str,
                                task_id: str, draft_subject: str = None,
                                draft_body: str = None, personalized_content: str = None,
                                recipient_email: str = None, used_intelligence: Any = None,
                                used_evidence: Any = None, used_ai_model: str = None) -> str:
        record_id = f"ex-{uuid.uuid4().hex[:12]}"
        with self.c() as x:
            x.execute("""
                INSERT INTO execution_records
                (record_id, entity_id, execution_type, task_id, draft_subject,
                 draft_body, personalized_content, recipient_email, used_intelligence,
                 used_evidence, used_ai_model, send_status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?)
            """, (record_id, entity_id, execution_type, task_id, draft_subject,
                  draft_body, personalized_content, recipient_email,
                  json.dumps(used_intelligence) if used_intelligence else None,
                  json.dumps(used_evidence) if used_evidence else None,
                  used_ai_model, time.time()))
            x.commit()
        return record_id

    def update_execution_status(self, record_id: str, status: str, sent_at: float = None):
        with self.c() as x:
            if sent_at:
                x.execute("UPDATE execution_records SET send_status=?, sent_at=? WHERE record_id=?",
                         (status, sent_at, record_id))
            else:
                x.execute("UPDATE execution_records SET send_status=? WHERE record_id=?",
                         (status, record_id))
            x.commit()

    def get_execution_records(self, entity_id: str = None, status: str = None,
                              record_id: str = None) -> List[Dict]:
        with self.c() as x:
            x.row_factory = sqlite3.Row
            conditions = []
            params = []
            if entity_id:
                conditions.append("entity_id=?")
                params.append(entity_id)
            if status:
                conditions.append("send_status=?")
                params.append(status)
            if record_id:
                conditions.append("record_id=?")
                params.append(record_id)
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = x.execute(f"SELECT * FROM execution_records {where} ORDER BY created_at DESC", params).fetchall()
            return [dict(r) for r in rows]

    # ========== Intelligence Aggregation ==========
    def get_intelligence(self, norm: str) -> Dict:
        entity = self.get_entity(norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found'}
        entity_id = entity['entity_id']
        roles = self.get_entity_roles(entity_id)
        categories = self.get_entity_categories(entity_id)
        edges = self.list_trade_edges(entity_id=entity_id)
        contacts = self.list_entity_contacts(entity_id)
        evidence = self.list_evidence(entity_id)
        history = self.get_lifecycle_history(entity_id)

        base_fields = ['name', 'country', 'address', 'website', 'phone',
                       'enterprise_type', 'industry', 'product_categories', 'brand']
        base_filled = sum(1 for f in base_fields if entity.get(f))
        base_pct = round(base_filled / len(base_fields) * 100, 1)

        trade_pct = min(100, len(edges) * 20)
        product_pct = min(100, len(set(e.get('product') for e in edges if e.get('product'))) * 25)
        contact_pct = min(100, len(contacts) * 25)
        email_pct = min(100, sum(1 for c in contacts if c.get('email')) * 50)
        website_pct = 100 if entity.get('website') else 0
        overall = round((base_pct + trade_pct + product_pct + contact_pct + email_pct + website_pct) / 6, 1)

        gaps = []
        if not entity.get('website'): gaps.append('website')
        if not entity.get('phone'): gaps.append('phone')
        if not contacts: gaps.append('contacts')
        if not any(c.get('email') for c in contacts): gaps.append('emails')
        if len(edges) < 2: gaps.append('trade_relations')

        next_steps = []
        if 'website' in gaps: next_steps.append('Search company website')
        if 'contacts' in gaps: next_steps.append('Find contacts via LinkedIn/web')
        if 'emails' in gaps: next_steps.append('Verify email addresses')
        if 'trade_relations' in gaps: next_steps.append('Expand trade network')

        return {
            'ok': True,
            'data': {
                'entity': entity,
                'roles': roles,
                'categories': categories,
                'trade_edges': edges,
                'contacts': contacts,
                'evidence': evidence,
                'lifecycle_history': history,
                'completeness': {
                    'base_info': base_pct,
                    'trade_info': trade_pct,
                    'product_info': product_pct,
                    'contact_info': contact_pct,
                    'email_info': email_pct,
                    'website_info': website_pct,
                    'overall': overall,
                },
                'gaps': gaps,
                'next_steps': next_steps,
            }
        }
