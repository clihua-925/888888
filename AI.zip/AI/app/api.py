from flask import Flask, request, jsonify, render_template
from pathlib import Path


from runtime.final_production_runtime import FinalProductionRuntime

from graph.agent_maintenance_flow import AgentMaintenanceFlow
from graph.maintenance_closed_loop import MaintenanceClosedLoop
from graph.final_e2e_production_pipeline import FinalE2EProductionPipeline
from graph.e2e_execution_validator import E2EExecutionValidator


BASE_DIR = Path(__file__).resolve().parent.parent



app = Flask(

    __name__,

    template_folder=str(BASE_DIR / "ui"),

    static_folder=str(BASE_DIR / "ui" / "static")

)



runtime = FinalProductionRuntime()

agent_flow = AgentMaintenanceFlow()

closed_loop = MaintenanceClosedLoop()

e2e_pipeline = FinalE2EProductionPipeline()

validator = E2EExecutionValidator()



@app.route("/")

def index():

    return render_template("index.html")




@app.route("/api/status")

def status():

    return jsonify({

        "system":"AI_Code_Maintenance",

        "version":"V4",

        "stage":runtime.stage,

        "runtime":"healthy",

        "agents":"ready",

        "graph":"ready",

        "memory":"ready",

        "checkpoint":"ready",

        "recovery":"ready"

    })





@app.route("/api/task",methods=["POST"])

def task():


    data=request.json or {}


    task_text=data.get(

        "task",

        "empty task"

    )



    result={}



    # Agent

    result["agent"] = agent_flow.run(task_text)



    # Closed Loop

    result["pipeline"] = closed_loop.execute(task_text)



    # E2E

    result["e2e"] = e2e_pipeline.run(task_text)



    # Validator

    result["validation"] = validator.validate({

        "task":task_text

    })



    result["stage"]="STAGE48"



    result["status"]="completed"



    return jsonify(result)





@app.route("/api/health")

def health():

    return jsonify({

        "stage":"STAGE48",

        "status":"healthy"

    })





if __name__=="__main__":


    print("="*60)

    print("AI_Code_Maintenance V4 Web UI")

    print("STAGE48 Full Pipeline Connected")

    print("="*60)



    app.run(

        host="0.0.0.0",

        port=8000,

        debug=False

    )