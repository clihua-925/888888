def compress_context(data, limit=12000):
    return str(data)[:limit]
