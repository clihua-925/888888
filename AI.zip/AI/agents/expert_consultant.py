def expert_consultant_node(state: dict):
    state.setdefault('agent_outputs', {})['expert'] = 'expert review requested'
    return state
