def validator_node(state: dict):
    patches = state.get('patches', [])
    state['validation'] = {
        'passed': bool(patches),
        'reason': 'patch exists' if patches else 'empty patch'
    }
    return state
