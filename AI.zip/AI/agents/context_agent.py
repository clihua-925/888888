def build_agent_context(state: dict, role='general'):
    return {
        'role': role,
        'repository': state.get('repository_context', {}),
        'task': state.get('current_task', {})
    }
