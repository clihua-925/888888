def executor_node(state):
    tasks = state.get('task_graph', [])
    state['execution'] = {'task_count': len(tasks)}
    return state
