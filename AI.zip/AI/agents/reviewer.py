def reviewer_node(state: dict):
    patch = state.get('patches', [])
    state['review'] = {
        'passed': bool(patch),
        'reason': 'patch reviewed' if patch else 'empty patch'
    }
    return state
