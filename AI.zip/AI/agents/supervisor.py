def supervisor_node(state: dict):
    state["execution_mode"] = (
        "parallel"
        if len(state.get("task_graph", [])) > 1
        else "single"
    )
    return state
