async function loadStatus(){

    let r =
        await fetch("/api/status");

    let data =
        await r.json();


    document.getElementById(
        "status"
    ).innerHTML =

    `
    <span class="green">
    ${data.stage}
    </span>
    <br>
    ${data.status}
    <br>
    ${data.runtime}
    `;

}



async function runTask(){


    let task =
    document.getElementById(
        "task"
    ).value;


    let r =
    await fetch(
        "/api/task",
        {

        method:"POST",

        headers:{
            "Content-Type":
            "application/json"
        },

        body:
        JSON.stringify(
            {
                task:task
            }
        )

        }
    );


    let data =
    await r.json();


    document.getElementById(
        "result"
    ).textContent =

    JSON.stringify(
        data,
        null,
        2
    );

}



loadStatus();