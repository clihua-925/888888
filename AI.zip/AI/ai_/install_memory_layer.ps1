Write-Host "================================="
Write-Host "Install Memory Retrieval Layer"
Write-Host "================================="

$root = Get-Location

New-Item -ItemType Directory -Force knowledge | Out-Null
New-Item -ItemType Directory -Force knowledge\index | Out-Null


@'
from pathlib import Path
import json
import hashlib


class CodeMemory:

    def __init__(self, root="."):
        self.root = Path(root)
        self.index_dir = self.root / "knowledge" / "index"
        self.index_dir.mkdir(parents=True, exist_ok=True)

        self.memory_file = self.index_dir / "code_memory.json"


    def build_index(self):

        files=[]

        ignore={
            ".git",
            ".venv",
            "__pycache__",
            "knowledge"
        }

        for p in self.root.rglob("*"):

            if p.is_file():

                if any(x in p.parts for x in ignore):
                    continue

                if p.suffix in [
                    ".py",
                    ".md",
                    ".txt",
                    ".json"
                ]:

                    try:
                        text=p.read_text(
                            encoding="utf-8",
                            errors="ignore"
                        )

                        files.append({
                            "path":str(p.relative_to(self.root)),
                            "size":len(text),
                            "hash":hashlib.md5(
                                text.encode()
                            ).hexdigest(),
                            "summary":text[:1000]
                        })

                    except:
                        pass


        self.memory_file.write_text(
            json.dumps(
                files,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )


        return {
            "files_indexed":len(files),
            "memory":str(self.memory_file)
        }



    def search(self,keyword,limit=5):

        if not self.memory_file.exists():
            self.build_index()


        data=json.loads(
            self.memory_file.read_text(
                encoding="utf-8"
            )
        )


        result=[]

        for item in data:

            if keyword.lower() in item["summary"].lower():

                result.append(item)


        return result[:limit]
'@ | Out-File knowledge\memory.py -Encoding utf8


@'
from .memory import CodeMemory
'@ | Out-File knowledge\__init__.py -Encoding utf8


Write-Host "[OK] knowledge layer created"


python -m py_compile knowledge\memory.py


Write-Host "================================="
Write-Host "Memory Layer Installed"
Write-Host "================================="