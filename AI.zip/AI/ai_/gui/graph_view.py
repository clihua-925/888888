
from PySide6.QtWidgets import QWidget
from PySide6.QtGui import QPainter, QColor, QPen
from PySide6.QtCore import Qt


class GraphView(QWidget):

    def __init__(self):
        super().__init__()

        self.current="START"

        self.nodes=[
            "START",
            "ANALYSIS",
            "PLANNER",
            "EXECUTION",
            "ACCEPTANCE",
            "DONE"
        ]

        self.setMinimumWidth(350)
        self.setMinimumHeight(600)



    def set_node(self,node):

        self.current=node
        self.update()



    def paintEvent(self,event):

        p=QPainter(self)

        y=40

        for i,node in enumerate(self.nodes):

            if node==self.current:
                p.setBrush(
                    QColor(0,200,0)
                )
            else:
                p.setBrush(
                    QColor(100,100,100)
                )


            p.setPen(
                QPen(Qt.black)
            )


            p.drawEllipse(
                120,
                y,
                45,
                45
            )


            p.drawText(
                40,
                y+75,
                node
            )


            if i < len(self.nodes)-1:

                p.drawLine(
                    142,
                    y+45,
                    142,
                    y+90
                )

            y+=90

