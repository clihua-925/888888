class Rollback:

    def execute(self):

        return True
