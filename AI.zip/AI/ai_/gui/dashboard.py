import subprocess
import threading

import sys

from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QLabel,
    QTextEdit,
    QPushButton,
    QLineEdit,
    QGroupBox
)

from PySide6.QtCore import Qt

from gui.task_runner import TaskRunner



class Dashboard(QMainWindow):


    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "AI CODE MAINTENANCE CENTER"
        )

        self.resize(
            1100,
            750
        )


        self.runner=None


        root=QWidget()

        layout=QVBoxLayout()


        # 状�?

        status=QGroupBox(
            "SYSTEM STATUS"
        )

        status_layout=QVBoxLayout()

        self.status_label=QLabel(
            """
Python        🟢
DeepSeek      🟢
LangGraph     🟢
AI Chrome     🟢
            """
        )

        status_layout.addWidget(
            self.status_label
        )

        status.setLayout(
            status_layout
        )

        layout.addWidget(
            status
        )


        # 任务输入

        self.input=QLineEdit()

        self.input.setPlaceholderText(
            "请输入维护任�?.."
        )


        layout.addWidget(
            self.input
        )


        self.button=QPushButton(
            "执行任务"
        )

        self.button.clicked.connect(
            self.start_task
        )

        layout.addWidget(
            self.button
        )


        # Agent流程

        flow=QLabel(
            """
AGENT FLOW

INPUT
 �?
ANALYSIS
 �?
PLANNER
 �?
EXECUTOR
 �?
REVIEW
 �?
DONE
"""
        )

        layout.addWidget(
            flow
        )


        # 日志

        self.log_box=QTextEdit()

        self.log_box.setReadOnly(
            True
        )

        layout.addWidget(
            self.log_box
        )


        root.setLayout(
            layout
        )

        self.setCentralWidget(
            root
        )



    def write_log(self,text):

        self.log_box.append(
            text
        )



    def start_task(self):

        task=self.input.text().strip()

        if not task:

            self.write_log(
                "[WARN] empty task"
            )

            return


        self.runner=TaskRunner(
            task
        )


        self.runner.log.connect(
            self.write_log
        )


        self.runner.finished.connect(
            self.write_log
        )


        self.runner.start()



if __name__=="__main__":

    app=QApplication(sys.argv)

    win=Dashboard()

    win.show()

    sys.exit(
        app.exec()
    )

