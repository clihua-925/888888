
from PySide6.QtCore import QThread, Signal
import subprocess
import sys


class TaskRunner(QThread):

    log = Signal(str)
    finished = Signal(str)


    def __init__(self, task):

        super().__init__()

        self.task = task



    def run(self):

        self.log.emit(
            "[TASK] " + self.task
        )


        try:

            process = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "app"
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8"
            )


            for line in process.stdout:

                self.log.emit(
                    line.rstrip()
                )


            process.wait()


            self.finished.emit(
                "Task finished"
            )


        except Exception as e:

            self.log.emit(
                "[ERROR] " + str(e)
            )

