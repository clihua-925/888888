from PySide6.QtCore import QThread, Signal
import subprocess
import sys


class AgentWorker(QThread):

    output = Signal(str)

    node = Signal(str)


    def run(self):

        self.node.emit("START")


        self.output.emit(
            "启动 Agent..."
        )


        self.node.emit(
            "DIFFICULTY_ASSESSMENT"
        )


        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "app"
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )


        for line in process.stdout:

            text=line.rstrip()

            self.output.emit(text)


            upper=text.upper()


            if "PLANNER" in upper:
                self.node.emit("PLANNER")


            elif "EXECUTION" in upper:
                self.node.emit("EXECUTION")


            elif "ACCEPTANCE" in upper:
                self.node.emit("ACCEPTANCE")


        self.node.emit(
            "DONE"
        )


        self.output.emit(
            "任务完成"
        )
