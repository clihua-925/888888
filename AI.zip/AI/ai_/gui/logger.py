from datetime import datetime


def log(message):

    return (
        datetime.now().strftime("%H:%M:%S")
        + " "
        + message
    )
