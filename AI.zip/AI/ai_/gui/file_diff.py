class FileDiff:

    def compare(self):

        return "diff preview"
