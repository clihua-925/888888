"""Deterministic architecture tests. External model/browser calls are never required."""
import tempfile
from pathlib import Path
import subprocess

from agents.difficulty import difficulty_assessment_node
from agents.dispatcher import task_dispatcher_node, dispatch_router
from agents.result_collector import result_collector_node
from graph.graph import build_graph
from providers.base import MockProvider
from graph.state import merge_task_states


def git_project():
    root = Path(tempfile.mkdtemp(prefix="acm_test_"))
    subprocess.run(["git", "init"], cwd=root, capture_output=True, text=True, check=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=root, check=True)
    (root / "calculator.py").write_text("def add(a,b): return a+b\n", encoding="utf-8")
    (root / "tests").mkdir()
    (root / "tests" / "test_calculator.py").write_text("from calculator import add\ndef test_add(): assert add(1,2)==3\n", encoding="utf-8")
    subprocess.run(["git", "add", "."], cwd=root, check=True)
    subprocess.run(["git", "commit", "-m", "initial"], cwd=root, capture_output=True, text=True, check=True)
    return root


def test_graph_compiles():
    graph = build_graph(provider=MockProvider())
    assert graph is not None


def test_task_state_reducer_preserves_parallel_tasks():
    result = merge_task_states(
        {"A": {"status": "DISPATCHED", "retry_count": 0}},
        {"B": {"status": "READY_TO_MERGE"}},
    )
    assert result["A"]["status"] == "DISPATCHED"
    assert result["B"]["status"] == "READY_TO_MERGE"


def test_dispatch_send_context_preserves_project_path():
    root = git_project()
    state = {
        "project_path": str(root), "original_goal": "test", "run_id": "T",
        "execution_tasks": [{"task": {"task_id": "T1", "dependencies": [], "target_files": ["calculator.py"]}}],
        "task_states": {"T1": {"status": "PENDING"}}, "dispatched_task_ids": [],
    }
    dispatched = task_dispatcher_node(state)
    sends = dispatch_router(dispatched)
    assert sends[0].args["__send_context"]["project_path"] == str(root)


def test_collector_preserves_root_context():
    state = {
        "project_path": "C:/project", "original_goal": "goal", "run_id": "R1",
        "task_states": {"T1": {"status": "DISPATCHED"}},
        "agent_results": [{"task_id": "T1", "status": "SUCCESS", "changed_files": ["calculator.py"], "evidence": {}}],
    }
    result = result_collector_node(state)
    assert result["project_path"] == "C:/project"
    assert result["task_states"]["T1"]["status"] == "READY_TO_MERGE"


def test_difficulty_gate_uses_local_provider():
    result = difficulty_assessment_node({"original_goal": "test"}, provider=MockProvider())
    assert result["difficulty_assessment"]["overall_level"] == "LOW"
