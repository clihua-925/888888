from pathlib import Path
import sys


ROOT = Path(__file__).parent.parent.resolve()

sys.path.insert(
    0,
    str(ROOT)
)


from knowledge.memory import CodeMemory
from knowledge.retriever import ContextRetriever



def main():

    memory = CodeMemory(
        ROOT
    )


    result = memory.build_index()

    print("INDEX:")
    print(result)


    retriever = ContextRetriever(
        ROOT
    )


    result = retriever.retrieve(
        "provider"
    )


    print("\nRETRIEVE:")

    for item in result:
        print(item)



if __name__ == "__main__":
    main()
