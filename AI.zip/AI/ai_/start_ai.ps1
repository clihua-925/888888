$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "[CHECK] Project Path"
Write-Host "[OK] $ROOT"
Write-Host ""


# 检查虚拟环境

$python = "$ROOT\.venv\Scripts\python.exe"

if (!(Test-Path $python)) {

    Write-Host "[ERROR] Virtual environment missing"
    Write-Host "Create with:"
    Write-Host "py -3.12 -m venv .venv"

    exit
}

Write-Host "[CHECK] Python Environment"
Write-Host "[OK] .venv"
Write-Host ""


# 浏览器目录

$browser = "$ROOT\.browser\chrome_ai_profile"

if (!(Test-Path $browser)) {

    New-Item -ItemType Directory -Path $browser -Force | Out-Null

}

Write-Host "[CHECK] AI Browser Profile"
Write-Host "[OK] Chrome Profile"
Write-Host ""


# 启动 AI 浏览器

Write-Host "[START] AI Browser"


Start-Process `
    $python `
    "$ROOT\test_browser.py"



Start-Sleep -Seconds 3


# 启动 Agent

Write-Host "[START] LangGraph Agent"

Start-Process `
    "powershell" `
    "-NoExit -Command `"cd '$ROOT'; .\.venv\Scripts\Activate.ps1; python -m gui.dashboard`""


Write-Host ""

Write-Host "=========================================="
Write-Host " SYSTEM READY"
Write-Host "=========================================="