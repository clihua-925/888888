@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo AI Code Maintenance System - Windows Launcher
echo ==========================================

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Virtual environment not found.
  echo Create it with: py -3.12 -m venv .venv
  exit /b 1
)

.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1

echo.
echo ==========================================
echo Running doctor check
echo ==========================================
.venv\Scripts\python.exe -m app.doctor
if errorlevel 1 echo [WARN] Doctor reported a problem. Continuing only for diagnosis.

echo.
echo ==========================================
echo Starting AI Code Maintenance System
 echo ==========================================
.venv\Scripts\python.exe -m app %*
set EXITCODE=%ERRORLEVEL%

echo.
echo Application exited with code %EXITCODE%.
pause
exit /b %EXITCODE%
