from pathlib import Path


path = Path("graph/graph.py")

text = path.read_text(
    encoding="utf-8"
)


# import
old = "from graph.state import AgentState\n"

new = """from graph.state import AgentState
from knowledge.graph_memory import (
    memory_indexer_node,
    context_retriever_node,
)
"""


if old not in text:
    raise RuntimeError(
        "state import anchor not found"
    )


text = text.replace(
    old,
    new
)


# add nodes
old = """    builder.add_node("PROJECT_SCANNER", project_scanner_node)
"""

new = """    builder.add_node("PROJECT_SCANNER", project_scanner_node)
    builder.add_node("MEMORY_INDEXER", memory_indexer_node)
    builder.add_node("CONTEXT_RETRIEVER", context_retriever_node)
"""


if old not in text:
    raise RuntimeError(
        "node anchor not found"
    )


text = text.replace(
    old,
    new
)


# replace edge
old = """    builder.add_edge("PROJECT_SCANNER", "DIFFICULTY_ASSESSMENT")
"""

new = """    builder.add_edge("PROJECT_SCANNER", "MEMORY_INDEXER")
    builder.add_edge("MEMORY_INDEXER", "CONTEXT_RETRIEVER")
    builder.add_edge("CONTEXT_RETRIEVER", "DIFFICULTY_ASSESSMENT")
"""


if old not in text:
    raise RuntimeError(
        "edge anchor not found"
    )


text = text.replace(
    old,
    new
)


path.write_text(
    text,
    encoding="utf-8"
)


print(
    "graph.py memory layer connected"
)
