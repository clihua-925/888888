from pathlib import Path

def build_context(state, purpose):
    ctx={"purpose":purpose}
    if purpose=="architect":
        ctx["repository_context"]=state.get("repository_context",{})
        ctx["findings"]=state.get("findings",[])
    elif purpose=="coder":
        ctx["current_task"]=state.get("current_task",{})
        ctx["files"]=state.get("repository_context",{}).get("files",[])[:20]
    else:
        ctx.update(dict(state))
    return ctx
