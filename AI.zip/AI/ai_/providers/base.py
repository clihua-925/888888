from __future__ import annotations

from typing import Any

from providers.hybrid import HybridProvider


class AIProvider:
    name = "base"

    def assess_difficulty(self, ctx: dict[str, Any]):
        raise NotImplementedError

    def architect_review(self, ctx: dict[str, Any]):
        raise NotImplementedError

    def plan(self, ctx: dict[str, Any]):
        raise NotImplementedError

    def expert_task_advice(self, ctx: dict[str, Any]):
        raise NotImplementedError

    def generate_code(self, ctx: dict[str, Any]):
        raise NotImplementedError

    def analyze_failure(
        self,
        evidence: dict[str, Any],
        plan: dict[str, Any],
        goal: str,
    ):
        raise NotImplementedError

    def acceptance_review(self, evidence: dict[str, Any]):
        raise NotImplementedError


class MockProvider(AIProvider):
    """
    Fallback provider for tests.
    """

    name = "mock"

    def assess_difficulty(self, ctx):

        return {
            "overall_level": "LOW",
            "planning_requires_expert": False,
            "architecture_requires_expert": False,
            "reasons": [
                "mock provider"
            ],
            "task_ratings": [],
        }


    def architect_review(self, ctx):

        return {
            "architecture_summary": "Mock review",
            "architecture_findings": [],
            "architecture_risks": [],
            "dependency_analysis": {},
            "affected_modules": [],
            "architecture_constraints": [],
            "recommended_changes": [],
            "review_status": "PASS",
        }


    def plan(self, ctx):

        return {
            "plan_version": "PLAN-v1",
            "objective": ctx.get(
                "original_goal",
                "",
            ),
            "success_criteria": [],
            "execution_strategy": [],
            "task_list": [],
            "dependencies": {},
            "affected_files": [],
            "constraints": [],
            "rollback_point": "",
            "acceptance_requirements": [],
        }


    def expert_task_advice(self, ctx):

        return {
            "approach": [],
            "steps": [],
            "risks": [],
            "files_to_inspect": [],
            "acceptance_checks": [],
            "do_not_do": [],
        }


    def generate_code(self, ctx):

        return {
            "patch": "",
            "summary": "No patch",
            "tests_to_run": [],
        }


    def analyze_failure(
        self,
        evidence,
        plan,
        goal,
    ):

        return {
            "recommended_target": "HUMAN_REVIEW",
            "recommended_task_ids": [],
            "analysis": "Mock failure analysis",
            "retry_strategy": "human_review",
            "requires_expert": False,
        }


    def acceptance_review(self, evidence):

        return {
            "confidence": "LOW",
            "concerns": [],
            "missing_evidence": [],
        }


class BrokenProvider(MockProvider):

    name = "broken"


    def generate_code(self, ctx):

        raise RuntimeError(
            "BrokenProvider simulated failure"
        )


class OpenAIProvider(HybridProvider):
    """
    Compatibility alias.
    """

    name = "openai"


class DeepSeekProvider(HybridProvider):
    """
    Compatibility alias.
    """

    name = "deepseek"
