# providers/hybrid.py

from __future__ import annotations

import json
import os
import re
import time

from typing import Any

from openai import OpenAI



DEFAULT_LOCAL_BASE_URL = (
    "http://192.168.1.26:8081/v1"
)


DEFAULT_LOCAL_MODEL = (
    "/home/chang/models/deepseek-r1-70b/"
    "DeepSeek-R1-Distill-Llama-70B-Q6_K-00001-of-00002.gguf"
)



def safe_text(
    text: str,
):
    return (
        text
        or ""
    ).strip()



def compact_json(
    data,
    limit=16000,
):

    try:

        text = json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
        )

    except Exception:

        text = str(data)


    if len(text) > limit:

        text = (
            text[:limit]
            +
            "\n...[trimmed]"
        )


    return text



def extract_json(
    text,
):

    text = safe_text(
        text
    )


    text = re.sub(
        r"```json",
        "",
        text,
        flags=re.I,
    )


    text = re.sub(
        r"```",
        "",
        text,
    )



    match = re.search(
        r"\{.*\}",
        text,
        flags=re.S,
    )


    if not match:

        return {
            "raw_response":
                text
        }



    try:

        return json.loads(
            match.group(0)
        )

    except Exception:

        return {
            "raw_response":
                text
        }





class LocalModel:
    """
    Local DeepSeek model.

    Used for:
    - code generation
    - structured processing
    - simple analysis

    """



    def __init__(
        self,
    ):


        self.base_url = os.getenv(
            "LOCAL_MODEL_BASE_URL",
            DEFAULT_LOCAL_BASE_URL,
        ).rstrip("/")



        self.model = os.getenv(
            "LOCAL_MODEL_NAME",
            DEFAULT_LOCAL_MODEL,
        )



        self.client = OpenAI(

            api_key=os.getenv(
                "LOCAL_MODEL_API_KEY",
                "local",
            ),

            base_url=self.base_url,

        )





    def ask(
        self,
        system,
        user,
        temperature=0.1,
    ):


        response = (

            self.client
            .chat
            .completions
            .create(

                model=self.model,

                messages=[

                    {
                        "role":
                            "system",

                        "content":
                            system,

                    },

                    {
                        "role":
                            "user",

                        "content":
                            user,

                    },

                ],

                temperature=temperature,

            )

        )


        return safe_text(

            response
            .choices[0]
            .message
            .content

        )





    def ask_json(
        self,
        system,
        user,
        temperature=0.1,
    ):

        return extract_json(

            self.ask(
                system,
                user,
                temperature,
            )

        )
class BrowserChatGPTExpert:
    """
    ChatGPT expert through existing Chrome.

    Architecture:

    Chrome:
        always running

    Playwright:
        connect_over_cdp

    Request:
        open/use ChatGPT tab

    Finish:
        close tab only

    Browser session:
        never closed
    """



    def __init__(
        self,
    ):


        from playwright.sync_api import sync_playwright


        self.sync_playwright = (
            sync_playwright
        )


        self.cdp_url = os.getenv(
            "CHROME_CDP_URL",
            "http://127.0.0.1:9222",
        )


        self.chatgpt_url = os.getenv(
            "CHATGPT_URL",
            "https://chatgpt.com/",
        )


        self.timeout = int(
            os.getenv(
                "CHATGPT_TIMEOUT_MS",
                "180000",
            )
        )


        self.playwright = None

        self.browser = None




    def connect(
        self,
    ):


        if self.browser:

            try:

                self.browser.contexts

                return

            except Exception:

                self.browser = None



        if self.playwright is None:

            self.playwright = (

                self.sync_playwright()
                .start()

            )



        self.browser = (

            self.playwright
            .chromium
            .connect_over_cdp(

                self.cdp_url

            )

        )




    def get_page(
        self,
    ):


        self.connect()



        if not self.browser.contexts:

            raise RuntimeError(
                "Chrome context unavailable"
            )



        context = (

            self.browser
            .contexts[0]

        )



        for page in context.pages:


            try:

                url = page.url.lower()


                if (
                    "chatgpt.com"
                    in url
                    or
                    "chat.openai.com"
                    in url
                ):

                    return page, False


            except Exception:

                pass



        return (
            context.new_page(),
            True,
        )





    def find_input(
        self,
        page,
    ):


        selectors = [

            "textarea",

            "[contenteditable='true']",

            "div[role='textbox']",

        ]



        for selector in selectors:


            locator = page.locator(
                selector
            )


            for i in range(
                locator.count()
            ):


                item = locator.nth(
                    i
                )


                try:

                    if item.is_visible():

                        return item


                except Exception:

                    continue



        return None




    def read_answers(
        self,
        page,
    ):


        selectors = [

            "[data-message-author-role='assistant']",

            "article",

        ]



        result = []



        for selector in selectors:


            try:

                locator = page.locator(
                    selector
                )


                for i in range(
                    locator.count()
                ):


                    text = (

                        locator
                        .nth(i)
                        .inner_text()
                        .strip()

                    )


                    if text:

                        result.append(
                            text
                        )


            except Exception:

                pass



        return result
    def ask(
        self,
        prompt,
        timeout_ms=None,
    ):


        timeout_ms = (
            timeout_ms
            or
            self.timeout
        )


        page = None

        temporary = False



        try:


            page, temporary = (
                self.get_page()
            )



            if page.url != self.chatgpt_url:

                page.goto(

                    self.chatgpt_url,

                    wait_until="domcontentloaded",

                    timeout=timeout_ms,

                )



            page.wait_for_timeout(
                5000
            )



            editor = (

                self.find_input(
                    page
                )

            )



            if editor is None:

                raise RuntimeError(
                    "ChatGPT input not found"
                )



            before = (

                self.read_answers(
                    page
                )

            )



            editor.click(
                force=True
            )



            editor.fill(
                prompt
            )



            editor.press(
                "Enter"
            )



            deadline = (

                time.time()

                +

                timeout_ms / 1000

            )



            last = ""

            stable = 0



            while time.time() < deadline:


                page.wait_for_timeout(
                    2000
                )


                answers = (

                    self.read_answers(
                        page
                    )

                )


                if not answers:

                    continue



                current = answers[-1]



                if current not in before:


                    if current == last:

                        stable += 1


                    else:

                        last = current

                        stable = 0



                    if stable >= 3:

                        return current



            raise TimeoutError(
                "ChatGPT response timeout"
            )



        finally:


            if temporary and page:

                try:

                    page.close()

                except Exception:

                    pass




    def close(
        self,
    ):

        """
        Only disconnect Playwright.

        Do not close Chrome.
        """


        try:

            if self.browser:

                self.browser = None


            if self.playwright:

                self.playwright.stop()


        except Exception:

            pass



        self.playwright = None
class HybridProvider:
    """
    Hybrid maintenance intelligence.

    Local model:
        - difficulty analysis
        - code generation
        - structured tasks

    ChatGPT:
        - architecture thinking
        - planning
        - complex diagnosis

    Expert output:
        natural language only
    """



    name = "hybrid"



    def __init__(
        self,
        local=None,
        expert=None,
    ):


        self.local = (

            local

            or

            LocalModel()

        )


        self._expert = expert


        self.expert_calls = 0




    @property
    def expert(
        self,
    ):


        if self._expert is None:

            self._expert = (

                BrowserChatGPTExpert()

            )


        return self._expert





    def _expert_answer(
        self,
        prompt,
    ):


        self.expert_calls += 1


        return {

            "response":

                self.expert.ask(
                    prompt
                ),

            "source":

                "chatgpt",

        }






    def reduce_context(
        self,
        ctx,
    ):


        if not isinstance(
            ctx,
            dict,
        ):

            return {}



        keys = [

            "goal",

            "project",

            "project_path",

            "project_structure",

            "difficulty",

            "architecture",

            "master_plan",

            "tasks",

            "task_results",

            "failure_analysis",

            "acceptance_result",

        ]



        result = {}



        for key in keys:


            if key in ctx:

                result[key] = ctx[key]



        return result





    def assess_difficulty(
        self,
        ctx,
    ):


        return self.local.ask_json(

            """

You are a software maintenance difficulty evaluator.

Return JSON.

Judge:

- complexity
- risk
- whether expert planning is needed


Only use supplied evidence.

Do not invent facts.

""",

            compact_json(
                self.reduce_context(ctx),
                12000,
            ),

        )






    def architect_review(
        self,
        ctx,
    ):


        difficulty = (

            ctx.get(
                "difficulty",
                {}
            )

            or {}

        )


        prompt = """

You are a senior software architect.

Review this software maintenance task.

Give a natural language architecture review.

Include:

1. Current architecture understanding

2. Technical risks

3. Dependency impact

4. Affected modules

5. Recommended improvements

6. Constraints


Rules:

Only use provided evidence.

Do not invent files.

Do not claim tests were executed.

"""


        prompt += "\n\nEvidence:\n"


        prompt += compact_json(

            self.reduce_context(ctx),

            16000,

        )



        if (

            difficulty.get(
                "architecture_requires_expert",
                False,
            )

            or

            difficulty.get(
                "overall_level",
                "LOW",
            )

            in [

                "HIGH",

                "CRITICAL",

            ]

        ):


            return self._expert_answer(
                prompt
            )



        return {

            "response":

                self.local.ask(

                    "You are a conservative software architect.",

                    prompt,

                ),

            "source":

                "local",

        }





    def plan(
        self,
        ctx,
    ):


        prompt = """

You are a senior software maintenance planner.

Create an implementation plan.

Answer naturally.

Include:

- objective

- execution order

- files involved

- dependencies

- implementation steps

- acceptance criteria

- rollback strategy


Only use supplied evidence.

Do not invent repository information.

"""


        prompt += "\n\nEvidence:\n"


        prompt += compact_json(

            self.reduce_context(ctx),

            16000,

        )


        return self._expert_answer(
            prompt
        )
    def expert_task_advice(
        self,
        ctx,
    ):


        prompt = """

You are a senior implementation advisor.

Provide natural language guidance.

Include:

- recommended approach

- execution steps

- technical risks

- files to inspect

- acceptance checks

- things to avoid


Rules:

Do not write code.

Do not invent repository facts.

"""


        prompt += "\n\nEvidence:\n"


        prompt += compact_json(

            self.reduce_context(ctx),

            12000,

        )


        return self._expert_answer(
            prompt
        )






    def generate_code(
        self,
        ctx,
    ):


        prompt = """

You are a local coding engineer.

Generate a safe maintenance patch.

Return JSON only.

Required:

patch

summary

tests_to_run


Rules:

- patch must be unified diff
- modify only justified files
- do not invent code
- do not claim tests passed


If unsafe:

return empty patch.

"""


        prompt += "\n\nEvidence:\n"


        prompt += compact_json(

            self.reduce_context(ctx),

            14000,

        )


        return self.local.ask_json(

            "You are a careful software engineer.",

            prompt,

        )






    def analyze_failure(
        self,
        evidence,
        plan,
        goal,
    ):


        prompt = """

You are a software failure recovery expert.

Analyze the failed maintenance attempt.

Give natural language analysis.

Include:

1. Failure reason

2. Possible root cause

3. Recommended next action

4. Retry or replan decision

5. Risks


Rules:

Use only supplied evidence.

Do not invent causes.

"""


        prompt += "\n\nGoal:\n"

        prompt += str(goal)



        prompt += "\n\nPlan:\n"

        prompt += compact_json(

            plan,

            8000,

        )



        prompt += "\n\nEvidence:\n"

        prompt += compact_json(

            evidence,

            8000,

        )


        return self._expert_answer(
            prompt
        )






    def acceptance_review(
        self,
        evidence,
    ):


        return {

            "response":

                self.local.ask(

                    """

Review software maintenance evidence.

Provide natural language judgement.

Include:

- confidence

- concerns

- missing evidence


Never invent evidence.

""",

                    compact_json(

                        evidence,

                        10000,

                    ),

                ),

            "source":

                "local",

        }
