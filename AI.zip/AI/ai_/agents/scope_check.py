"""Verify changed files against the approved plan and project root."""
from pathlib import Path


def scope_check_node(state):
    project = Path(state.get("project_path", ".")).resolve()
    plan = state.get("master_plan", {}) or {}
    allowed = set(plan.get("affected_files", []) or [])
    forbidden = set(plan.get("must_not_change", []) or [])
    agents = state.get("agent_results", []) or []

    if not agents:
        return {"scope_check_result": {"status": "EVIDENCE_INVALID", "reason": "No agent results"}, "current_stage": "SCOPE_CHECK"}

    for result in agents:
        if not result.get("agent_commit"):
            return {"scope_check_result": {"status": "EVIDENCE_INVALID", "reason": "agent_commit missing"}, "current_stage": "SCOPE_CHECK"}
        for filename in result.get("changed_files", []) or []:
            candidate = (project / filename).resolve()
            try:
                candidate.relative_to(project)
            except ValueError:
                return {"scope_check_result": {"status": "FAIL", "reason": f"Path escapes project: {filename}"}, "current_stage": "SCOPE_CHECK"}
            if filename in forbidden:
                return {"scope_check_result": {"status": "FAIL", "reason": f"Modified must_not_change file: {filename}"}, "current_stage": "SCOPE_CHECK"}
            if allowed and filename not in allowed:
                return {"scope_check_result": {"status": "FAIL", "reason": f"Modified file outside affected_files: {filename}"}, "current_stage": "SCOPE_CHECK"}

    return {"scope_check_result": {"status": "PASS", "checked_files": sum(len(r.get("changed_files", [])) for r in agents)}, "current_stage": "SCOPE_CHECK"}
