from pathlib import Path

from providers.base import MockProvider


def code_agent_node(
    state,
    provider=None,
):

    provider = provider or MockProvider()

    from tools.code_executor import CodeExecutor


    context = dict(
        state.get(
            "__send_context",
            {},
        )
        or {}
    )


    wrapper = (
        state.get(
            "__task",
            {},
        )
        or {}
    )


    task = (
        wrapper.get(
            "task",
            {},
        )
        or {}
    )


    task_id = task.get(
        "task_id",
        "UNKNOWN",
    )


    project_path = context.get(
        "project_path",
        state.get(
            "project_path",
            "",
        ),
    )


    plan = context.get(
        "master_plan",
        state.get(
            "master_plan",
            {},
        ),
    )


    advice = (
        context.get(
            "expert_advice",
            state.get(
                "expert_advice",
                {},
            ),
        )
        or {}
    )


    previous = (
        context.get(
            "task_states",
            {},
        )
        or {}
    ).get(
        task_id,
        {},
    )


    if context.get(
        "sandbox_mode",
        state.get(
            "sandbox_mode",
            False,
        ),
    ):

        return {
            "task_states": {
                task_id: {
                    **previous,
                    "status": "READY_TO_MERGE",
                }
            },

            "agent_results": [
                {
                    "task_id": task_id,
                    "status": "SUCCESS",
                    "changed_files": task.get(
                        "target_files",
                        [],
                    ),

                    "evidence": {
                        "sandbox": True,
                        "tests": {
                            "success": True,
                        },
                    },

                    "base_commit": "SANDBOX",
                    "agent_commit": "SANDBOX",
                    "summary":
                        "Sandbox execution",
                }
            ],

            "current_stage":
                "CODE_AGENT_COMPLETE",
        }


    executor = CodeExecutor(
        project_path
    )


    base_commit = (
        executor.git.get_head_commit()
        or ""
    )


    files = []

    for filename in (
        task.get(
            "target_files",
            [],
        )
        or []
    ):

        path = (
            Path(project_path)
            /
            filename
        )

        if path.is_file():

            files.append(
                {
                    "path": filename,

                    "content":
                        path.read_text(
                            encoding="utf-8",
                            errors="replace",
                        )[:60000],
                }
            )


    result = provider.generate_code(
        {
            "task": task,

            "mission_goal":
                context.get(
                    "original_goal",
                    "",
                ),

            "plan": plan,

            "constraints":
                plan.get(
                    "constraints",
                    [],
                ),

            "project_path":
                project_path,

            "expert_advice":
                advice.get(
                    task_id,
                    {},
                ),

            "files": files,
        }
    )


    changed_files = []
    agent_commit = ""
    tests = {
        "success": False,
    }
    status = "FAIL"
    error = ""


    try:

        changed_files = executor.apply_patch(
            result.get(
                "patch",
                "",
            )
        )


        tests = executor.run_tests(
            result.get(
                "tests_to_run",
                [],
            )
        )


        if not tests.get(
            "success",
            False,
        ):

            raise RuntimeError(
                "tests failed"
            )


        changed_files = (
            executor.changed_files()
        )


        agent_commit = executor.commit(
            f"AI maintenance: {task_id}"
        )


        status = "SUCCESS"


    except Exception as exc:

        error = str(exc)



    return {

        "task_states": {
            task_id: {
                **previous,

                "status":
                    "READY_TO_MERGE"
                    if status == "SUCCESS"
                    else "FAILED",
            }
        },


        "agent_results": [
            {
                "task_id": task_id,

                "status": status,

                "changed_files": changed_files,

                "evidence": {
                    "tests": tests,

                    "error": error,

                    "base_commit": base_commit,
                },

                "base_commit":
                    base_commit,

                "agent_commit":
                    agent_commit,

                "summary":
                    result.get(
                        "summary",
                        "",
                    ),
            }
        ],


        "base_commit_by_task": {
            task_id: base_commit,
        },


        "agent_commit_by_task": {
            task_id: agent_commit,
        },


        "current_stage":
            "CODE_AGENT_COMPLETE",
    }
