"""Worktree Cleanup Agent."""
import shutil
import stat
from pathlib import Path


def _remove_readonly(func, path, _):
    """Windows compatible: clear read-only bit before removal."""
    Path(path).chmod(stat.S_IWRITE)
    func(path)


def worktree_cleanup_node(state):
    """Cleanup worktrees."""
    worktree_by_task = state.get("worktree_by_task", {})
    project_path = Path(state.get("project_path", "")).resolve()

    for tid, wt in worktree_by_task.items():
        if not wt:
            continue
        wt_path = Path(wt).resolve()
        try:
            wt_path.relative_to(project_path.parent if project_path.name else project_path)
        except ValueError:
            return {
                "worktree_cleanup_result": {"status": "FAIL", "reason": f"Unsafe worktree path: {wt}"},
                "current_stage": "WORKTREE_CLEANUP"
            }
        try:
            if wt_path.exists():
                shutil.rmtree(wt_path, onerror=_remove_readonly)
        except Exception as e:
            return {
                "worktree_cleanup_result": {"status": "FAIL", "reason": str(e)},
                "current_stage": "WORKTREE_CLEANUP"
            }

    return {
        "worktree_cleanup_result": {"status": "SUCCESS"},
        "current_stage": "WORKTREE_CLEANUP"
    }
