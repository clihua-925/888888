"""Collect parallel Send results without losing root execution context."""


def result_collector_node(state):
    task_states = {key: dict(value) for key, value in (state.get("task_states", {}) or {}).items()}
    for result in state.get("agent_results", []) or []:
        task_id = result.get("task_id")
        if not task_id:
            continue
        previous = task_states.get(task_id, {})
        task_states[task_id] = {
            **previous,
            "status": "READY_TO_MERGE" if result.get("status") == "SUCCESS" else "FAILED",
        }

    return {
        "project_path": state.get("project_path", ""),
        "original_goal": state.get("original_goal", ""),
        "run_id": state.get("run_id", ""),
        "max_retries": state.get("max_retries", 3),
        "max_replans": state.get("max_replans", 2),
        "retry_count": state.get("retry_count", 0),
        "replan_count": state.get("replan_count", 0),
        "repeated_failure_count": state.get("repeated_failure_count", 0),
        "master_plan": state.get("master_plan", {}),
        "plan_version": state.get("plan_version", ""),
        "execution_tasks": state.get("execution_tasks", []),
        "expert_advice": state.get("expert_advice", {}),
        "difficulty_assessment": state.get("difficulty_assessment", {}),
        "task_states": task_states,
        "current_stage": "RESULTS_COLLECTED",
    }
