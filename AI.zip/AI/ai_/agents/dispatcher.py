"""Task dispatcher with explicit Send context preservation."""
from langgraph.types import Send

_CONTEXT_KEYS = (
    "project_path", "original_goal", "run_id", "max_retries", "max_replans",
    "retry_count", "replan_count", "repeated_failure_count", "sandbox_mode", "master_plan",
    "plan_version", "execution_tasks", "task_states", "expert_advice",
    "difficulty_assessment",
)


def _completed(task_states):
    return {
        task_id for task_id, task in (task_states or {}).items()
        if task.get("status") in {"READY_TO_MERGE", "MERGED", "COMPLETED"}
    }


def build_send_context(state, task_states=None):
    context = {key: state[key] for key in _CONTEXT_KEYS if key in state}
    if task_states is not None:
        context["task_states"] = task_states
    return context


def task_dispatcher_node(state):
    task_states = {key: dict(value) for key, value in (state.get("task_states", {}) or {}).items()}
    execution_tasks = state.get("execution_tasks", []) or []
    dispatched = set(state.get("dispatched_task_ids", []) or [])
    completed = _completed(task_states)
    ready = []

    for execution_task in execution_tasks:
        task = execution_task.get("task", {}) or {}
        task_id = task.get("task_id", "")
        deps = task.get("dependencies", []) or []
        current = task_states.get(task_id, {})
        if not task_id or task_id in dispatched:
            continue
        if current.get("status") in {"FAILED", "RETRYING"}:
            continue
        if not set(deps).issubset(completed):
            continue
        ready.append(execution_task)
        dispatched.add(task_id)
        task_states[task_id] = {**current, "status": "DISPATCHED"}
        break

    return {
        "ready_tasks": ready,
        "dispatched_task_ids": list(dispatched),
        "task_states": task_states,
        "__send_context": build_send_context(state, task_states),
        "current_stage": "DISPATCHING",
    }


def dispatch_router(state):
    ready = state.get("ready_tasks", []) or []
    if not ready:
        return "HUMAN_REVIEW"
    context = dict(state.get("__send_context") or build_send_context(state))
    return [Send("CODE_AGENT", {"__task": task, "__send_context": context}) for task in ready]
