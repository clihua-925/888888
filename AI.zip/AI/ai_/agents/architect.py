"""Architecture review node."""

from providers.base import MockProvider


def architect_review_node(
    state,
    provider=None,
):

    provider = provider or MockProvider()

    context = {
        "project_structure": state.get(
            "project_structure",
            {},
        ),

        "current_code_summary": state.get(
            "current_code_summary",
            "",
        ),

        "original_goal": state.get(
            "original_goal",
            "",
        ),

        "project_path": state.get(
            "project_path",
            "",
        ),

        "difficulty": state.get(
            "difficulty_assessment",
            {},
        ),

        "memory_context": state.get(
            "memory_context",
            [],
        ),
    }


    result = provider.architect_review(
        context
    )


    defaults = {
        "architecture_summary": "",
        "architecture_findings": [],
        "architecture_risks": [],
        "dependency_analysis": {},
        "affected_modules": [],
        "architecture_constraints": [],
        "recommended_changes": [],
        "review_status": "UNKNOWN",
    }


    for key, value in defaults.items():

        result.setdefault(
            key,
            value,
        )


    return {
        "architecture_report": result,
        "current_stage": "ARCHITECT_REVIEW",
    }
