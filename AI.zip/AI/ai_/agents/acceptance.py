"""Evidence-first acceptance gate.

No language model can turn missing or failed hard evidence into PASS.
"""
from pathlib import Path
import subprocess
import sys


def _path_inside(root: Path, relative: str) -> bool:
    try:
        (root / relative).resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _real_diff_files(project: Path) -> list[str]:
    try:
        result = subprocess.run(
            ["git", "status", "--short"], cwd=str(project), capture_output=True,
            text=True, shell=False, timeout=30
        )
        if result.returncode != 0:
            return []
        files = []
        for line in result.stdout.splitlines():
            if len(line) >= 4:
                files.append(line[3:].strip().strip('"'))
        return files
    except Exception:
        return []


def acceptance_node(state, provider=None):
    tests = state.get("integration_test_results", []) or []
    agents = state.get("agent_results", []) or []
    scope = state.get("scope_check_result", {}) or {}
    merge = state.get("merge_result", {}) or {}
    project = Path(state.get("project_path", ".")).resolve()
    plan = state.get("master_plan", {}) or {}

    test_ok = bool(tests) and all(item.get("success") is True for item in tests)
    agent_ok = bool(agents) and all(
        item.get("status") == "SUCCESS"
        and isinstance(item.get("changed_files"), list)
        and bool(item.get("changed_files"))
        and isinstance(item.get("evidence"), dict)
        for item in agents
    )
    scope_ok = scope.get("status") == "PASS"
    merge_ok = merge.get("status") in {"SUCCESS", "MERGED"}

    reasons = []
    if not tests: reasons.append("No test execution evidence")
    if not test_ok: reasons.append("One or more tests failed")
    if not agent_ok: reasons.append("Agent execution evidence is incomplete")
    if not scope_ok: reasons.append("Scope verification did not PASS")
    if not merge_ok: reasons.append("Merge verification did not PASS")

    allowed = set(plan.get("affected_files", []) or [])
    if allowed:
        for agent in agents:
            for filename in agent.get("changed_files", []) or []:
                if not _path_inside(project, filename):
                    reasons.append(f"Changed path escapes project: {filename}")
                elif filename not in allowed:
                    reasons.append(f"Changed file outside approved scope: {filename}")

    real_status = _real_diff_files(project)
    if not state.get("sandbox_mode") and not real_status and agent_ok:
        # A repository without Git changes may still be valid in a sandbox/mock run,
        # but a real run must provide an agent commit or explicit verified evidence.
        if not all(item.get("agent_commit") for item in agents):
            reasons.append("No verifiable repository change/agent commit")

    hard_pass = not reasons
    advisory = None
    if provider is not None and hasattr(provider, "acceptance_review"):
        try:
            advisory = provider.acceptance_review({
                "tests": tests, "agents": agents, "scope": scope,
                "merge": merge, "plan": plan, "hard_pass": hard_pass,
            })
        except Exception as exc:
            advisory = {"confidence": "LOW", "concerns": [str(exc)], "missing_evidence": []}

    return {
        "acceptance_result": {
            "status": "PASS" if hard_pass else "FAIL",
            "hard_checks": {"status": "PASS" if test_ok else "FAIL"},
            "test_results": {"status": "PASS" if test_ok else "FAIL", "results": tests},
            "scope_result": {"status": "PASS" if scope_ok else "FAIL"},
            "evidence_check": {"status": "PASS" if agent_ok else "FAIL"},
            "merge_check": {"status": "PASS" if merge_ok else "FAIL"},
            "reasons": reasons,
            "advisory_review": advisory,
            "ai_override_allowed": False,
        },
        "current_stage": "ACCEPTANCE",
    }
