from pathlib import Path

def scan_repository(state):
    root=Path(state.get("project_path") or ".")
    files=[]
    for f in root.rglob("*.py"):
        if "__pycache__" not in str(f):
            files.append(str(f))
    state["repository_context"]={"files":files,"file_count":len(files)}
    state.setdefault("findings",[])
    state["agent_outputs"]={**state.get("agent_outputs",{}),"scanner":state["repository_context"]}
    return state
