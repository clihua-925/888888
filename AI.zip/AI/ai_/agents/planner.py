"""Planning node."""

from providers.base import MockProvider


def planner_node(state, provider=None):

    provider = provider or MockProvider()

    context = {
        "original_goal": state.get(
            "original_goal",
            "",
        ),
        "project_path": state.get(
            "project_path",
            "",
        ),
        "project_structure": state.get(
            "project_structure",
            {},
        ),
        "architecture_report": state.get(
            "architecture_report",
            {},
        ),
        "difficulty_assessment": state.get(
            "difficulty_assessment",
            {},
        ),
        "memory_context": state.get(
            "memory_context",
            [],
        ),
        "previous_failure": state.get(
            "failure_analysis",
            {},
        ),
        "previous_plan_version": state.get(
            "plan_version",
            "",
        ),
    }


    result = provider.plan(
        context
    )


    defaults = {
        "plan_version": "PLAN-v1",
        "objective": context["original_goal"],
        "success_criteria": [],
        "execution_strategy": [],
        "task_list": [],
        "dependencies": {},
        "affected_files": [],
        "constraints": [],
        "rollback_point": "",
        "acceptance_requirements": [],
    }


    for key, value in defaults.items():

        result.setdefault(
            key,
            value,
        )


    tasks = [
        task
        for task in result.get(
            "task_list",
            [],
        )
        if task.get(
            "task_id"
        )
    ]


    execution_tasks = []

    for task in tasks:

        execution_tasks.append(
            {
                "task": task,
                "plan_version": result.get(
                    "plan_version",
                    "PLAN-v1",
                ),
                "run_id": state.get(
                    "run_id",
                    "",
                ),
            }
        )


    return {
        "master_plan": result,

        "plan_version": result.get(
            "plan_version",
            "PLAN-v1",
        ),

        "execution_tasks": execution_tasks,

        "pending_task_ids": [
            task["task_id"]
            for task in tasks
        ],

        "task_states": {
            task["task_id"]: {
                "status": "PENDING",
                "retry_count": 0,
            }
            for task in tasks
        },

        "current_stage":
            "PLANNING_COMPLETE",
    }
