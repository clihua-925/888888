"""Failure analysis node."""

from providers.base import MockProvider


def failure_analysis_node(
    state,
    provider=None,
):

    provider = provider or MockProvider()

    acceptance = state.get(
        "acceptance_result",
        {},
    ) or {}

    plan = state.get(
        "master_plan",
        {},
    ) or {}

    goal = state.get(
        "original_goal",
        "",
    )


    try:

        result = provider.analyze_failure(
            acceptance,
            plan,
            goal,
        )


    except Exception as exc:

        result = {
            "recommended_target": "HUMAN_REVIEW",

            "recommended_task_ids": [],

            "analysis":
                "Failure analyzer unavailable",

            "retry_strategy":
                "human_review",

            "requires_expert":
                True,

            "error":
                str(exc),
        }


    defaults = {

        "recommended_target":
            "HUMAN_REVIEW",

        "recommended_task_ids":
            [],

        "analysis":
            "",

        "retry_strategy":
            "human_review",

        "requires_expert":
            False,
    }


    for key, value in defaults.items():

        result.setdefault(
            key,
            value,
        )


    return {
        "failure_analysis": result,

        "current_stage":
            "FAILURE_ANALYSIS",
    }
