"""Atomic rollback with state preservation."""
from mission_board import MissionBoard
from tools.git import GitTool


def rollback_node(state, board=None):
    project_path = state.get("project_path", "")
    task_checkpoint_ref = state.get("rollback_target_checkpoint", state.get("task_checkpoint_ref", ""))
    if not project_path:
        return {"rollback_performed": False, "rollback_status": "ROLLBACK_FAILED", "reason": "No project_path"}
    board = board or MissionBoard()
    try:
        checkpoint = board.get_checkpoint(task_checkpoint_ref)
    except Exception:
        checkpoint = None
    if not checkpoint:
        return {"rollback_performed": False, "rollback_status": "ROLLBACK_FAILED", "reason": "Checkpoint not found"}

    git_commit = checkpoint.get("git_commit", "")
    if not git_commit:
        return {"rollback_performed": False, "rollback_status": "ROLLBACK_FAILED", "reason": "No git_commit in checkpoint"}
    try:
        git = GitTool(project_path)
        git.reset(git_commit, hard=True)
        if git.get_head_commit() != git_commit:
            raise RuntimeError("HEAD mismatch after reset")
    except Exception as exc:
        return {"rollback_performed": False, "rollback_status": "ROLLBACK_FAILED", "reason": str(exc)}

    board.log_event("ROLLBACK", {"task_checkpoint_ref": task_checkpoint_ref, "git_commit": git_commit})
    return {
        "rollback_performed": True,
        "rollback_status": "ROLLBACK_PERFORMED",
        "task_checkpoint_ref": task_checkpoint_ref,
        "replan_count": state.get("replan_count", 0) + 1,
        "plan_version": checkpoint.get("plan_version", ""),
        "task_states": checkpoint.get("task_states_snapshot", {}),
        "pending_task_ids": checkpoint.get("active_task_ids", []),
        "master_plan": {},
        "failure_context": checkpoint.get("failure_context", ""),
        "current_stage": "ROLLBACK_COMPLETE",
    }


