"""Dependency Checker."""


def _get_completed_task_ids(task_states):
    """Unified completed status check."""
    completed = set()
    for tid, ts in task_states.items():
        if ts.get("status") in ("READY_TO_MERGE", "MERGED", "COMPLETED"):
            completed.add(tid)
    return completed


def dependency_checker_node(state):
    """Check dependencies."""
    task_states = state.get("task_states", {})
    execution_tasks = state.get("execution_tasks", [])

    completed = _get_completed_task_ids(task_states)
    all_deps_met = True
    blocked_tasks = []

    for et in execution_tasks:
        task = et.get("task", {})
        tid = task.get("task_id", "")
        deps = task.get("dependencies", [])
        if deps and not set(deps).issubset(completed):
            all_deps_met = False
            blocked_tasks.append(tid)

    return {
        "dependency_check_result": {
            "status": "PASS" if all_deps_met else "BLOCKED",
            "blocked_tasks": blocked_tasks
        },
        "current_stage": "DEPENDENCY_CHECKED"
    }
