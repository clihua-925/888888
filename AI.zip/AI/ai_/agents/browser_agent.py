
from pathlib import Path
from playwright.sync_api import sync_playwright


ROOT = Path(__file__).parent.parent

PROFILE = ROOT / ".browser" / "chrome_ai_profile"


class BrowserAgent:


    def __init__(self):

        self.playwright = None
        self.context = None
        self.page = None



    def start(self):

        self.playwright = sync_playwright().start()


        self.context = (
            self.playwright
            .chromium
            .launch_persistent_context(
                
                user_data_dir=str(PROFILE),

                headless=False,

                channel="chrome",

                no_viewport=True,

                args=[

                    "--start-maximized",

                    "--disable-blink-features=AutomationControlled"

                ]
            )
        )


        if self.context.pages:

            self.page = self.context.pages[0]

        else:

            self.page = self.context.new_page()


        self.page.goto(
            "https://chat.openai.com"
        )


        return self.page



    def close(self):

        if self.context:

            self.context.close()


        if self.playwright:

            self.playwright.stop()
