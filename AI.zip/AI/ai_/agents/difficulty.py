"""Difficulty gate and expert consultation nodes."""

from providers.base import MockProvider


def difficulty_assessment_node(
    state,
    provider=None,
):

    provider = provider or MockProvider()

    context = {
        "original_goal": state.get(
            "original_goal",
            "",
        ),
        "project_path": state.get(
            "project_path",
            "",
        ),
        "project_structure": state.get(
            "project_structure",
            {},
        ),
        "architecture_report": state.get(
            "architecture_report",
            {},
        ),
        "failure_analysis": state.get(
            "failure_analysis",
            {},
        ),
        "retry_count": state.get(
            "retry_count",
            0,
        ),
        "repeated_failure_count": state.get(
            "repeated_failure_count",
            0,
        ),
        "execution_tasks": state.get(
            "execution_tasks",
            [],
        ),
    }


    result = provider.assess_difficulty(
        context
    )


    result.setdefault(
        "overall_level",
        "LOW",
    )

    result.setdefault(
        "planning_requires_expert",
        True,
    )

    result.setdefault(
        "architecture_requires_expert",
        False,
    )

    result.setdefault(
        "task_ratings",
        [],
    )


    return {
        "difficulty_assessment": result,
        "current_stage": "DIFFICULTY_ASSESSED",
    }



def task_expert_advice_node(
    state,
    provider=None,
):

    provider = provider or MockProvider()


    difficulty = (
        state.get(
            "difficulty_assessment",
            {},
        )
        or {}
    )


    ratings = {
        item.get("task_id"): item
        for item in difficulty.get(
            "task_ratings",
            [],
        )
        if item.get(
            "task_id"
        )
    }


    advice = dict(
        state.get(
            "expert_advice",
            {},
        )
        or {}
    )


    consultations = list(
        state.get(
            "expert_consultations",
            [],
        )
        or []
    )


    for execution_task in state.get(
        "execution_tasks",
        [],
    ):

        task = (
            execution_task.get(
                "task",
                {},
            )
            or {}
        )


        task_id = task.get(
            "task_id",
            "",
        )


        if not task_id:
            continue


        rating = ratings.get(
            task_id,
            {},
        )


        complexity = str(
            task.get(
                "complexity",
                rating.get(
                    "level",
                    "LOW",
                ),
            )
        ).upper()


        need = (
            bool(
                rating.get(
                    "requires_expert",
                    False,
                )
            )
            or complexity in {
                "HIGH",
                "CRITICAL",
                "EXPERT",
            }
        )


        if not need:
            continue


        if task_id in advice:
            continue


        advice[task_id] = provider.expert_task_advice(
            {
                "goal": state.get(
                    "original_goal",
                    "",
                ),
                "task": task,
                "plan": state.get(
                    "master_plan",
                    {},
                ),
                "architecture": state.get(
                    "architecture_report",
                    {},
                ),
                "project_path": state.get(
                    "project_path",
                    "",
                ),
            }
        )


        consultations.append(
            {
                "type": "TASK",
                "task_id": task_id,
            }
        )


    return {
        "expert_advice": advice,
        "expert_consultations": consultations,
        "current_stage": "EXPERT_ADVICE_READY",
    }
