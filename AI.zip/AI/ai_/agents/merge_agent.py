"""Merge verification.

The coding agent is expected to produce verified commits/worktrees. This node
never fabricates a merge; it only verifies the current repository base and
records the contract needed by Acceptance.
"""
from tools.git import GitTool


def merge_agent_node(state):
    project_path = state.get("project_path", "")
    if state.get("sandbox_mode"):
        return {"merge_result": {"status": "SUCCESS", "sandbox": True, "merged_tasks": [r.get("task_id") for r in state.get("agent_results", []) or []]}, "current_stage": "MERGE_COMPLETE"}
    if not project_path:
        return {"merge_result": {"status": "FAIL", "reason": "No project_path", "recoverable": True}, "current_stage": "MERGE"}

    try:
        git = GitTool(project_path)
        head = git.get_head_commit()
    except Exception as exc:
        return {"merge_result": {"status": "FAIL", "reason": str(exc), "recoverable": False}, "current_stage": "MERGE"}

    if not head:
        # Non-Git projects can still be maintained, but they cannot pass a Git-based
        # merge gate. Keep this explicit instead of pretending to have merged.
        return {"merge_result": {"status": "FAIL", "reason": "Repository has no HEAD commit", "recoverable": True}, "current_stage": "MERGE"}

    base_by_task = state.get("base_commit_by_task", {}) or {}
    stale = []
    for result in state.get("agent_results", []) or []:
        task_id = result.get("task_id", "")
        base = result.get("base_commit") or base_by_task.get(task_id)
        if base and base != head:
            stale.append(task_id)

    if stale:
        return {
            "merge_result": {"status": "STALE_BASE", "reason": "Repository HEAD changed", "tasks": stale},
            "current_stage": "MERGE",
        }

    merged_ids = [r.get("task_id") for r in state.get("agent_results", []) or [] if r.get("status") == "SUCCESS"]
    task_states = {key: dict(value) for key, value in (state.get("task_states", {}) or {}).items()}
    for task_id in merged_ids:
        task_states[task_id] = {**task_states.get(task_id, {}), "status": "MERGED"}
    return {
        "merge_result": {"status": "SUCCESS", "merged_tasks": merged_ids, "verified_head": head},
        "task_states": task_states,
        "current_stage": "MERGE_COMPLETE",
    }
