"""Retry policy: local analysis first, expert escalation on complexity or repetition."""

def retry_manager_node(state):
    failure = state.get("failure_analysis", {}) or {}
    task_ids = failure.get("recommended_task_ids", []) or []
    target = failure.get("recommended_target", "HUMAN_REVIEW")
    retry_count = state.get("retry_count", 0) + 1
    repeated = state.get("repeated_failure_count", 0) + 1
    task_states = {key: dict(value) for key, value in (state.get("task_states", {}) or {}).items()}

    for task_id in task_ids:
        if task_id in task_states:
            previous = task_states[task_id]
            task_states[task_id] = {
                **previous,
                "status": "RETRYING",
                "retry_count": previous.get("retry_count", 0) + 1,
            }

    return {
        "retry_count": retry_count,
        "repeated_failure_count": repeated,
        "recommended_task_ids": task_ids,
        "task_states": task_states,
        "replan_needed": target == "PLANNER",
        "current_stage": "RETRY_MANAGED",
    }
