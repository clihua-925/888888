"""Retry Send dispatcher with the same explicit context contract as first dispatch."""
from langgraph.types import Send
from agents.dispatcher import build_send_context


def retry_dispatcher_node(state):
    ids = set(state.get("recommended_task_ids", []) or state.get("failure_analysis", {}).get("recommended_task_ids", []) or [])
    context = build_send_context(state)
    sends = []
    for execution_task in state.get("execution_tasks", []) or []:
        task_id = (execution_task.get("task", {}) or {}).get("task_id", "")
        if task_id in ids:
            sends.append(Send("CODE_AGENT", {"__task": execution_task, "__send_context": context}))
    return sends or "HUMAN_REVIEW"
