"""Environment health check for the local-model + browser-expert architecture."""
import os
import shutil
import subprocess
import sys
from pathlib import Path


def check_python():
    v = sys.version_info
    return v >= (3, 11), f"Python {v.major}.{v.minor}.{v.micro}"


def check_git():
    git = shutil.which("git")
    if not git:
        return False, "Git not found in PATH"
    try:
        result = subprocess.run([git, "--version"], capture_output=True, text=True, shell=False, check=True)
        return True, result.stdout.strip()
    except Exception as exc:
        return False, str(exc)


def check_project_path():
    root = Path(__file__).resolve().parent.parent
    return root.exists(), str(root)


def check_mission_board():
    try:
        from mission_board import MissionBoard
        board = MissionBoard()
        return True, f"Board dir: {board.board_dir}"
    except Exception as exc:
        return False, str(exc)


def check_file_lock():
    try:
        from filelock import FileLock  # noqa: F401
        return True, "filelock available"
    except ImportError:
        return False, "filelock not installed"


def check_local_model_config():
    base = os.getenv("LOCAL_MODEL_BASE_URL", "http://192.168.1.26:8081/v1")
    model = os.getenv(
        "LOCAL_MODEL_NAME",
        "/home/chang/models/deepseek-r1-70b/DeepSeek-R1-Distill-Llama-70B-Q6_K-00001-of-00002.gguf",
    )
    return bool(base and model), f"Local model: {model}; endpoint: {base}"


def check_chatgpt_config():
    url = os.getenv("CHATGPT_URL", "https://chatgpt.com/")
    profile = os.getenv("CHATGPT_PROFILE_DIR", ".chatgpt_profile")
    return bool(url), f"Browser expert: {url}; profile: {profile}"


def check_dependencies():
    required = ["langgraph", "langchain_core", "openai", "pytest", "filelock", "playwright"]
    lines = []
    ok = True
    for module in required:
        try:
            __import__(module)
            lines.append(f"[OK] {module}")
        except ImportError:
            lines.append(f"[FAIL] {module}")
            ok = False
    return ok, "\n".join(lines)


def main():
    checks = [
        ("Python", check_python),
        ("Git", check_git),
        ("Project Path", check_project_path),
        ("Mission Board", check_mission_board),
        ("File Lock", check_file_lock),
        ("Local Model Configuration", check_local_model_config),
        ("ChatGPT Browser Configuration", check_chatgpt_config),
        ("Dependencies", check_dependencies),
    ]
    print("=" * 60)
    print("AI Code Maintenance System - Doctor")
    print("=" * 60)
    all_ok = True
    for name, fn in checks:
        ok, detail = fn()
        print(f"{'[OK]' if ok else '[FAIL]'} {name}: {detail}")
        all_ok = all_ok and ok
    print("=" * 60)
    if all_ok:
        print("All checks passed.")
    else:
        print("Some checks failed. Sandbox mode can still run without the local model or browser expert.")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
