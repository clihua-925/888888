from __future__ import annotations

import os
import traceback


from graph.graph import build_graph
from providers.hybrid import HybridProvider




def main():

    print("=" * 60)
    print("AI CODE MAINTENANCE")
    print("=" * 60)



    project_path = os.getenv(
        "PROJECT_PATH",
        ".",
    )


    goal = os.getenv(
        "GOAL",
        "Fix bugs and improve code quality",
    )



    print(
        "Mode: HYBRID"
    )

    print(
        "Project:",
        project_path,
    )

    print(
        "Goal:",
        goal,
    )



    provider = HybridProvider()



    graph = build_graph(
        provider=provider,
    )



    state = {

        "project_path":
            project_path,

        "project":
            project_path,

        "goal":
            goal,

        "original_goal":
            goal,

        "run_id":
            "manual-run",

        "retry_count":
            0,

        "max_retries":
            3,

        "replan_count":
            0,

        "max_replans":
            2,

        "repeated_failure_count":
            0,

        "sandbox_mode":
            False,

    }



    try:


        result = graph.invoke(
            state
        )



        print("=" * 60)

        print(
            "FINAL RESULT"
        )



        print(
            result
        )



        print("=" * 60)



        print(
            "STATUS:",
            result.get(
                "status",
                "UNKNOWN",
            )
        )



        print(
            "SUMMARY:",
            result.get(
                "summary",
                "",
            )
        )



        if result.get(
            "failure"
        ):

            print(
                "FAILURE:"
            )

            print(
                result[
                    "failure"
                ]
            )



        print(
            "Expert calls:",
            provider.expert_calls,
        )



    except Exception:

        print(
            "[ERROR]"
        )

        traceback.print_exc()




if __name__ == "__main__":

    main()
