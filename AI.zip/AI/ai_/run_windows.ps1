# AI Code Maintenance System - Windows PowerShell Launcher
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $MyInvocation.MyCommand.Path)

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "AI Code Maintenance System - Windows Launcher" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

python --version
if ($LASTEXITCODE -ne 0) { throw "Python 3.11+ is required." }
git --version
if ($LASTEXITCODE -ne 0) { throw "Git is required." }

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    python -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw "Failed to create virtual environment." }
}

.venv\Scripts\python.exe -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }

Write-Host ""
Write-Host "Running doctor check..." -ForegroundColor Cyan
.venv\Scripts\python.exe -m app.doctor
if ($LASTEXITCODE -ne 0) {
    Write-Host "[WARN] Doctor reported a problem. Continuing for diagnosis." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Starting maintenance system..." -ForegroundColor Cyan
.venv\Scripts\python.exe -m app @args
exit $LASTEXITCODE
