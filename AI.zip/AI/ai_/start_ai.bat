@echo off
chcp 65001 >nul

title AI CODE MAINTENANCE CENTER

echo ==========================================
echo  AI CODE MAINTENANCE CENTER
echo ==========================================
echo.

cd /d %~dp0

powershell -ExecutionPolicy Bypass -File "%~dp0start_ai.ps1"

pause