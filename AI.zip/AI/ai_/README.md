# AI Code Maintenance System

## Architecture

This project uses a two-layer intelligence model:

- **Local DeepSeek = executor / hands**: scanning, task analysis, coding, testing, evidence collection and ordinary failure handling.
- **ChatGPT Web = expert / brain**: browser consultation for planning, high-risk architecture, complex implementation strategy, ambiguous failures and repeated failures.

The browser expert never directly edits the repository. Its output is treated as advice and is passed back to the local executor.

## Local model

Default endpoint:

`http://192.168.1.26:8081/v1`

Default model identifier:

`/home/chang/models/deepseek-r1-70b/DeepSeek-R1-Distill-Llama-70B-Q6_K-00001-of-00002.gguf`

If the server exposes a different model ID through `/v1/models`, set `LOCAL_MODEL_NAME` to that exact ID.

## Expert escalation

The local difficulty gate classifies work as `LOW`, `MEDIUM`, `HIGH` or `CRITICAL`.

- Planning is always consulted with the browser expert.
- Architecture uses the expert for `HIGH`/`CRITICAL` work or when explicitly requested by the difficulty gate.
- High/critical individual coding tasks receive expert implementation strategy.
- Failure analysis starts locally and escalates to the expert for complex, ambiguous or repeated failures.

## Acceptance

Acceptance is evidence-first. An AI response cannot override a failed hard check. A successful run requires real test evidence, agent evidence, scope verification and merge verification.

## Windows

1. Copy `.env.example` to `.env` if desired and adjust values.
2. Install dependencies with `\.venv\Scripts\python.exe -m pip install -r requirements.txt`.
3. Install browser support once with `\.venv\Scripts\python.exe -m playwright install chromium`.
4. Run `\.\run_windows.bat`.
5. The first browser-expert consultation may require logging into ChatGPT in the persistent `.chatgpt_profile` browser profile.

Use `\.venv\Scripts\python.exe -m app --sandbox` to exercise the graph without a local model or browser expert.
