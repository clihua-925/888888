"""Mission Board - Shared task panel."""
import os
import json
import time
from pathlib import Path

try:
    from filelock import FileLock, Timeout
    HAS_FILELOCK = True
except ImportError:
    HAS_FILELOCK = False


class MissionBoard:
    """Shared task panel for missions."""

    def __init__(self, board_dir=None):
        self.board_dir = Path(board_dir) if board_dir else Path(".mission_board")
        self.board_dir.mkdir(parents=True, exist_ok=True)
        self._missions = {}
        self._checkpoints = {}
        self._events = []
        self._load()

    def _lock_path(self, filename):
        """Get lock file path for a JSON file."""
        return self.board_dir / f"{filename}.lock"

    def _with_lock(self, filename, operation):
        """Execute operation with cross-platform file lock."""
        lock_path = self._lock_path(filename)
        if HAS_FILELOCK:
            lock = FileLock(str(lock_path), timeout=10)
            with lock:
                return operation()
        else:
            # Fallback: no lock (warning logged but not blocking)
            return operation()

    def _load_file(self, filename, default):
        """Load a JSON file with locking."""
        def _do_load():
            filepath = self.board_dir / filename
            if filepath.exists():
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        return json.load(f)
                except (json.JSONDecodeError, OSError):
                    return default
            return default
        return self._with_lock(filename, _do_load)

    def _save_file(self, filename, data):
        """Save a JSON file with locking."""
        def _do_save():
            filepath = self.board_dir / filename
            tmp_path = filepath.with_suffix(".tmp")
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            # Atomic rename (Windows compatible)
            tmp_path.replace(filepath)
        self._with_lock(filename, _do_save)

    def _load(self):
        self._missions = self._load_file("missions.json", {})
        self._checkpoints = self._load_file("checkpoints.json", {})
        self._events = self._load_file("events.json", [])

    def _save(self):
        self._save_file("missions.json", self._missions)
        self._save_file("checkpoints.json", self._checkpoints)
        self._save_file("events.json", self._events)

    def create_mission(self, mission):
        mid = mission.get("mission_id")
        self._missions[mid] = mission
        self._save()

    def get_mission(self, mission_id):
        return self._missions.get(mission_id)

    def update_mission(self, mission_id, updates):
        if mission_id in self._missions:
            self._missions[mission_id].update(updates)
            self._save()

    def create_checkpoint(self, checkpoint):
        cid = checkpoint.get("task_checkpoint_ref")
        self._checkpoints[cid] = checkpoint
        self._save()

    def get_checkpoint(self, task_checkpoint_ref):
        return self._checkpoints.get(task_checkpoint_ref)

    def restore_checkpoint(self, task_checkpoint_ref):
        cp = self.get_checkpoint(task_checkpoint_ref)
        if not cp:
            raise ValueError(f"Checkpoint not found: {task_checkpoint_ref}")
        return cp

    def log_event(self, event_type, details):
        event = {
            "timestamp": time.time(),
            "type": event_type,
            "details": details
        }
        self._events.append(event)
        self._save()

    def get_events(self):
        return list(self._events)

    def list_checkpoints(self):
        return list(self._checkpoints.values())


