from pathlib import Path
import json
import hashlib
import ast


class CodeMemory:

    def __init__(self, root="."):

        self.root = Path(root).resolve()

        self.index_dir = (
            self.root
            / "knowledge"
            / "index"
        )

        self.index_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        self.memory_file = (
            self.index_dir
            / "code_memory.json"
        )


    def extract_structure(
        self,
        text: str,
        suffix: str
    ):

        result = {
            "functions": [],
            "classes": [],
            "imports": [],
            "parse_error": None
        }


        if suffix != ".py":
            return result


        try:

            tree = ast.parse(text)


            for node in ast.walk(tree):

                if isinstance(
                    node,
                    (
                        ast.FunctionDef,
                        ast.AsyncFunctionDef
                    )
                ):

                    result["functions"].append(
                        node.name
                    )


                elif isinstance(
                    node,
                    ast.ClassDef
                ):

                    result["classes"].append(
                        node.name
                    )


                elif isinstance(
                    node,
                    ast.Import
                ):

                    for item in node.names:
                        result["imports"].append(
                            item.name
                        )


                elif isinstance(
                    node,
                    ast.ImportFrom
                ):

                    if node.module:

                        result["imports"].append(
                            node.module
                        )


        except Exception as exc:

            result["parse_error"] = str(exc)


        return result



    def build_index(self):

        files = []

        ignored = {
            ".git",
            ".venv",
            "__pycache__",
            "knowledge",
            ".mission_board",
            ".browser",
            ".chatgpt_profile"
        }


        for path in self.root.rglob("*"):


            if not path.is_file():
                continue


            if any(
                item in path.parts
                for item in ignored
            ):
                continue


            if path.suffix not in {
                ".py",
                ".md",
                ".txt",
                ".json"
            }:
                continue


            try:

                text = path.read_text(
                    encoding="utf-8",
                    errors="ignore"
                )


                structure = self.extract_structure(
                    text,
                    path.suffix
                )


                files.append(
                    {
                        "path": str(
                            path.relative_to(
                                self.root
                            )
                        ),

                        "size": len(text),

                        "hash": hashlib.md5(
                            text.encode(
                                "utf-8"
                            )
                        ).hexdigest(),

                        "summary": text[:1000],

                        "structure": structure
                    }
                )


            except Exception as exc:

                files.append(
                    {
                        "path": str(
                            path.relative_to(
                                self.root
                            )
                        ),

                        "error": str(exc)
                    }
                )


        self.memory_file.write_text(
            json.dumps(
                files,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )


        return {
            "files_indexed": len(files),
            "memory": str(
                self.memory_file
            )
        }



    def search(
        self,
        keyword,
        limit=5
    ):


        if not self.memory_file.exists():

            self.build_index()


        data = json.loads(
            self.memory_file.read_text(
                encoding="utf-8"
            )
        )


        result = []


        keyword = keyword.lower()


        for item in data:

            content = (
                item.get(
                    "summary",
                    ""
                )
                +
                json.dumps(
                    item.get(
                        "structure",
                        {}
                    ),
                    ensure_ascii=False
                )
            )


            if keyword in content.lower():

                result.append(
                    item
                )


        return result[:limit]
