from knowledge.memory import CodeMemory


class ContextRetriever:
    """
    Retrieval layer.

    Agent 不读取整个项目�?
    只获得当前任务相关上下文�?
    """


    def __init__(self, root="."):

        self.memory = CodeMemory(
            root
        )



    def retrieve(
        self,
        query,
        limit=8
    ):

        results = self.memory.search(
            query,
            limit
        )


        context = []


        for item in results:

            context.append(
                {
                    "file":
                        item.get(
                            "path",
                            ""
                        ),

                    "structure":
                        item.get(
                            "structure",
                            {}
                        )
                }
            )


        return context
