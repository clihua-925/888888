from __future__ import annotations

from pathlib import Path
import json
import hashlib
from typing import Any


class GraphMemory:
    """
    Lightweight project knowledge graph memory.

    Stores:
    - files
    - structures
    - relations
    - history
    """

    def __init__(
        self,
        root=".",
    ):

        self.root = Path(
            root
        ).resolve()

        self.storage = (
            self.root
            /
            ".mission_board"
            /
            "graph_memory.json"
        )

        self.storage.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        self.data = self._load()


    def _load(self):

        if not self.storage.exists():

            return {
                "files": {},
                "relations": [],
                "history": [],
            }

        try:

            return json.loads(
                self.storage.read_text(
                    encoding="utf-8"
                )
            )

        except Exception:

            return {
                "files": {},
                "relations": [],
                "history": [],
            }


    def save(self):

        self.storage.write_text(
            json.dumps(
                self.data,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )


    def file_id(
        self,
        path: str,
    ):

        return hashlib.sha1(
            path.encode(
                "utf-8"
            )
        ).hexdigest()


    def add_file(
        self,
        path: str,
        structure: dict[str, Any],
    ):

        fid = self.file_id(
            path
        )

        self.data["files"][fid] = {
            "path": path,
            "structure": structure,
        }

        self.save()

        return fid


    def add_relation(
        self,
        source: str,
        target: str,
        relation: str,
    ):

        self.data["relations"].append(
            {
                "source": source,
                "target": target,
                "relation": relation,
            }
        )

        self.save()


    def search(
        self,
        query: str,
        limit=8,
    ):

        query = (
            query
            or ""
        ).lower()

        results = []

        for item in self.data.get(
            "files",
            {},
        ).values():

            path = item.get(
                "path",
                "",
            ).lower()


            if (
                query in path
                or not query
            ):

                results.append(
                    item
                )


        return results[:limit]



def memory_indexer_node(
    state,
):

    root = Path(
        state.get(
            "project_path",
            ".",
        )
    )


    memory = GraphMemory(
        root
    )


    for path in root.rglob("*"):

        if not path.is_file():
            continue

        if any(
            part in {
                ".git",
                "__pycache__",
                ".venv",
            }
            for part in path.parts
        ):
            continue


        try:

            relative = str(
                path.relative_to(root)
            )

            memory.add_file(
                relative,
                {
                    "suffix":
                        path.suffix,
                    "size":
                        path.stat().st_size,
                },
            )

        except Exception:

            continue


    return {
        "memory_index": memory.data,
        "current_stage": "MEMORY_INDEXED",
    }



def context_retriever_node(
    state,
):

    memory = GraphMemory(
        state.get(
            "project_path",
            ".",
        )
    )


    context = memory.search(
        state.get(
            "original_goal",
            "",
        )
    )


    return {
        "memory_context": context,
        "current_stage": "CONTEXT_RETRIEVED",
    }
