"""Git Tool - Safe Git operations without shell=True."""
import subprocess
import os
import re
from pathlib import Path


class GitTool:
    """Safe Git operations."""

    SAFE_BRANCH_PATTERN = re.compile(r"^[a-zA-Z0-9_/.\\-]+$")
    SAFE_COMMIT_PATTERN = re.compile(r"^[a-f0-9]{4,40}$")

    def __init__(self, project_path):
        self.project_path = Path(project_path).resolve()
        if not self.project_path.exists():
            raise ValueError(f"project_path does not exist: {project_path}")

    def _run(self, args, cwd=None, check=True):
        """Run git command with args list, never shell=True."""
        cmd = ["git"] + args
        result = subprocess.run(
            cmd,
            cwd=cwd or str(self.project_path),
            capture_output=True,
            text=True,
            shell=False
        )
        if check and result.returncode != 0:
            raise RuntimeError(f"Git command failed: {' '.join(cmd)}\n{result.stderr}")
        return result

    def _validate_branch(self, branch):
        if not branch or not isinstance(branch, str):
            raise ValueError("Invalid branch name")
        if not self.SAFE_BRANCH_PATTERN.match(branch):
            raise ValueError(f"Unsafe branch name: {branch}")
        return branch

    def _validate_commit(self, commit):
        if not commit or not isinstance(commit, str):
            raise ValueError("Invalid commit hash")
        if commit in ("HEAD", "HEAD~1") or commit.startswith("HEAD~"):
            return commit
        if not self.SAFE_COMMIT_PATTERN.match(commit):
            if not re.match(r"^[a-f0-9]+$", commit):
                raise ValueError(f"Unsafe commit: {commit}")
        return commit

    def _validate_path(self, file_path):
        """Ensure relative paths are resolved from the project root."""
        raw = Path(file_path)
        p = (self.project_path / raw).resolve() if not raw.is_absolute() else raw.resolve()
        try:
            p.relative_to(self.project_path)
        except ValueError:
            raise ValueError(f"Path escapes project directory: {file_path}")
        return str(p)

    def get_head_commit(self):
        result = self._run(["rev-parse", "HEAD"], check=False)
        if result.returncode != 0:
            return None
        return result.stdout.strip()

    def reset(self, commit, hard=True):
        commit = self._validate_commit(commit)
        args = ["reset"]
        if hard:
            args.append("--hard")
        args.append(commit)
        return self._run(args)

    def create_branch(self, branch_name, start_point=None):
        branch_name = self._validate_branch(branch_name)
        args = ["checkout", "-b", branch_name]
        if start_point:
            args.append(self._validate_commit(start_point))
        return self._run(args)

    def checkout(self, branch_or_commit):
        target = self._validate_branch(branch_or_commit)
        return self._run(["checkout", target])

    def add(self, paths):
        if isinstance(paths, str):
            paths = [paths]
        validated = [self._validate_path(p) for p in paths]
        return self._run(["add"] + validated)

    def commit(self, message):
        return self._run(["commit", "-m", message])

    def diff(self, commit_a, commit_b, paths=None):
        commit_a = self._validate_commit(commit_a)
        commit_b = self._validate_commit(commit_b)
        args = ["diff", f"{commit_a}..{commit_b}"]
        if paths:
            if isinstance(paths, str):
                paths = [paths]
            validated = [self._validate_path(p) for p in paths]
            args += ["--"] + validated
        result = self._run(args, check=False)
        return result.stdout

    def merge(self, branch, no_ff=False, no_commit=False):
        branch = self._validate_branch(branch)
        args = ["merge"]
        if no_ff:
            args.append("--no-ff")
        if no_commit:
            args.append("--no-commit")
        args.append(branch)
        result = self._run(args, check=False)
        return result

    def init(self):
        return self._run(["init"])

    def config(self, key, value):
        return self._run(["config", key, value])
