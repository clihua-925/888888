"""Safe host-side execution of model-produced unified patches."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from tools.git import GitTool


class CodeExecutor:
    def __init__(self, project_path: str):
        self.project = Path(project_path).resolve()
        self.git = GitTool(self.project)

    def apply_patch(self, patch: str) -> list[str]:
        if not patch or not patch.strip():
            raise ValueError("Model returned an empty patch")
        result = subprocess.run(
            ["git", "apply", "--whitespace=nowarn", "-"],
            cwd=str(self.project), input=patch, capture_output=True, text=True, shell=False,
        )
        if result.returncode != 0:
            raise RuntimeError(f"git apply failed: {result.stderr.strip()}")
        return self.changed_files()

    def changed_files(self) -> list[str]:
        result = subprocess.run(
            ["git", "status", "--short"], cwd=str(self.project),
            capture_output=True, text=True, shell=False,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip())
        files = []
        for line in result.stdout.splitlines():
            if len(line) >= 4:
                files.append(line[3:].strip().strip('"'))
        return files

    def run_tests(self, commands: list[str] | None = None) -> dict:
        commands = commands or []
        if commands:
            # Only execute the project's test runner commands, not arbitrary shell syntax.
            # The default is pytest; model-provided commands are intentionally ignored.
            commands = []
        tests_dir = self.project / "tests"
        if not tests_dir.exists():
            return {"success": False, "error": "tests directory not found"}
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "-q"], cwd=str(self.project),
            capture_output=True, text=True, timeout=900, shell=False,
        )
        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": result.stdout[-16000:],
            "stderr": result.stderr[-16000:],
        }

    def commit(self, message: str) -> str:
        changed = self.changed_files()
        if not changed:
            raise RuntimeError("No repository changes to commit")
        self.git.add(changed)
        self.git.commit(message[:200] or "AI maintenance change")
        head = self.git.get_head_commit()
        if not head:
            raise RuntimeError("Commit completed but HEAD could not be verified")
        return head
