
from agents.browser_agent import BrowserAgent
import time


print("==============================")
print("AI Chrome Browser")
print("==============================")


agent = BrowserAgent()

agent.start()


print("Chrome running")
print("Please login manually")
print("CTRL+C close")


try:

    while True:

        time.sleep(5)


except KeyboardInterrupt:

    agent.close()

    print("closed")
