"""Graph routing policy."""


def route_after_merge(state):
    status = (state.get("merge_result", {}) or {}).get("status")
    if status == "STALE_BASE":
        return "rollback"
    if status not in {"SUCCESS", "MERGED"}:
        return "human_review"
    tasks = state.get("execution_tasks", []) or []
    states = state.get("task_states", {}) or {}
    remaining = [
        (item.get("task", {}) or {}).get("task_id")
        for item in tasks
        if (item.get("task", {}) or {}).get("task_id")
        and states.get((item.get("task", {}) or {}).get("task_id"), {}).get("status") not in {"MERGED", "COMPLETED"}
    ]
    return "task_dispatcher" if remaining else "worktree_cleanup"


def route_after_worktree_cleanup(state):
    return "human_review" if (state.get("worktree_cleanup_result", {}) or {}).get("status") != "SUCCESS" else "test_runner"


def route_after_acceptance(state):
    return "final_report" if (state.get("acceptance_result", {}) or {}).get("status") == "PASS" else "failure_analysis"


def route_after_rollback(state):
    return "planner" if state.get("replan_count", 0) < state.get("max_replans", 2) else "human_review"


def route_after_retry_manager(state):
    failure = state.get("failure_analysis", {}) or {}
    target = failure.get("recommended_target", "HUMAN_REVIEW")
    if target == "PLANNER":
        return "rollback" if state.get("replan_count", 0) < state.get("max_replans", 2) else "human_review"
    if target == "CODE_AGENT" and state.get("retry_count", 0) < state.get("max_retries", 3):
        return "retry_dispatcher"
    return "human_review"
