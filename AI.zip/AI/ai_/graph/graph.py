# graph/graph.py

from __future__ import annotations

from typing import Any

from langgraph.graph import (
    StateGraph,
    END,
)

from graph.state import MaintenanceState
from agents.scanner import scan_repository



def safe_dict(value):

    if isinstance(
        value,
        dict,
    ):

        return value


    return {}



def normalize_plan(
    plan,
):

    """
    Compatibility layer.

    Support:

    old:
        {
            task_list:[]
        }

    new:
        {
            response:"..."
        }

    """

    plan = safe_dict(
        plan
    )


    if plan.get(
        "task_list"
    ):

        return plan



    response = plan.get(
        "response",
        "",
    )


    if response:


        return {

            "plan_version":
                "natural",

            "objective":
                response[:500],

            "task_list":[

                {

                    "task_id":
                        "TASK_001",

                    "description":
                        response,

                    "dependencies":[],

                    "target_files":[],

                    "complexity":
                        "UNKNOWN",

                    "acceptance_checks":[],

                }

            ],

            "raw_plan":
                response,

        }



    return {

        "task_list":[]

    }





def difficulty_assessment_node(
    state: MaintenanceState,
    provider,
):

    result = provider.assess_difficulty(

        dict(state)

    )


    state["difficulty"] = result


    return state
def architect_review_node(
    state: MaintenanceState,
    provider,
):


    ctx = dict(
        state
    )


    result = provider.architect_review(
        ctx
    )


    state["architecture"] = result


    return state





def planner_node(
    state: MaintenanceState,
    provider,
):


    ctx = dict(
        state
    )


    result = provider.plan(
        ctx
    )


    state["master_plan"] = normalize_plan(
        result
    )


    return state





def dispatch_node(
    state: MaintenanceState,
):


    plan = normalize_plan(

        state.get(
            "master_plan",
            {}
        )

    )


    tasks = plan.get(
        "task_list",
        []
    )


    if not tasks:


        state["status"] = (
            "NEEDS_HUMAN_REVIEW"
        )


        state["failure"] = {

            "stage":
                "DISPATCHING",

            "reason":
                "No executable tasks generated",

        }


        return state



    state["tasks"] = tasks


    state["current_task_index"] = 0


    state["status"] = (
        "EXECUTING"
    )


    return state
def code_agent_node(
    state: MaintenanceState,
    provider,
):


    tasks = state.get(
        "tasks",
        []
    )


    index = state.get(
        "current_task_index",
        0
    )


    if index >= len(tasks):

        state["status"] = (
            "VALIDATING"
        )

        return state



    current_task = tasks[index]


    ctx = {

        **dict(state),

        "current_task":
            current_task,

    }


    result = provider.generate_code(
        ctx
    )


    state["patch_result"] = result


    return state





def validation_node(
    state: MaintenanceState,
):


    patch = state.get(
        "patch_result",
        {}
    )


    if not patch:


        state["validation"] = {

            "passed":
                False,

            "reason":
                "No patch result",

        }


        state["status"] = (
            "FAILED"
        )


        return state



    patch_text = patch.get(
        "patch",
        "",
    )


    if not patch_text:


        state["validation"] = {

            "passed":
                False,

            "reason":
                "Empty patch",

        }


        state["status"] = (
            "FAILED"
        )


        return state



    state["validation"] = {

        "passed":
            True,

        "reason":
            "Patch generated",

    }


    state["status"] = (
        "ACCEPTANCE"
    )


    return state





def acceptance_node(
    state: MaintenanceState,
    provider,
):


    evidence = {

        "validation":
            state.get(
                "validation",
                {}
            ),

        "patch":
            state.get(
                "patch_result",
                {}
            ),

    }


    result = provider.acceptance_review(
        evidence
    )


    state["acceptance"] = result


    state["status"] = (
        "COMPLETED"
    )


    return state
def failure_analysis_node(
    state: MaintenanceState,
    provider,
):


    result = provider.analyze_failure(

        state.get(
            "validation",
            {}
        ),

        state.get(
            "master_plan",
            {}
        ),

        state.get(
            "goal",
            ""
        ),

    )


    state["failure"] = result


    state["status"] = (
        "NEEDS_HUMAN_REVIEW"
    )


    return state





def build_graph(
    provider,
):


    workflow = StateGraph(
        MaintenanceState
    )



    workflow.add_node(

        "REPOSITORY_SCAN",

        lambda state: scan_repository(state)

    )


    workflow.add_node(

        "DIFFICULTY_ASSESSMENT",

        lambda state:

            difficulty_assessment_node(

                state,

                provider,

            )

    )



    workflow.add_node(

        "ARCHITECT_REVIEW",

        lambda state:

            architect_review_node(

                state,

                provider,

            )

    )



    workflow.add_node(

        "PLANNER",

        lambda state:

            planner_node(

                state,

                provider,

            )

    )



    workflow.add_node(

        "DISPATCHING",

        lambda state:

            dispatch_node(

                state,

            )

    )



    workflow.add_node(

        "CODE_AGENT",

        lambda state:

            code_agent_node(

                state,

                provider,

            )

    )



    workflow.add_node(

        "VALIDATION",

        lambda state:

            validation_node(

                state,

            )

    )



    workflow.add_node(

        "ACCEPTANCE",

        lambda state:

            acceptance_node(

                state,

                provider,

            )

    )



    workflow.add_node(

        "FAILURE_ANALYSIS",

        lambda state:

            failure_analysis_node(

                state,

                provider,

            )

    )



    workflow.set_entry_point(

        "REPOSITORY_SCAN"

    )



    workflow.add_edge(

        "REPOSITORY_SCAN",

        "DIFFICULTY_ASSESSMENT",

    )


    workflow.add_edge(

        "DIFFICULTY_ASSESSMENT",

        "ARCHITECT_REVIEW"

    )



    workflow.add_edge(

        "ARCHITECT_REVIEW",

        "PLANNER"

    )



    workflow.add_edge(

        "PLANNER",

        "DISPATCHING"

    )



    workflow.add_conditional_edges(

        "DISPATCHING",

        lambda state:

            (

                "CODE_AGENT"

                if state.get(
                    "status"
                )
                ==
                "EXECUTING"

                else

                "FAILURE_ANALYSIS"

            ),

    )



    workflow.add_edge(

        "CODE_AGENT",

        "VALIDATION"

    )



    workflow.add_conditional_edges(

        "VALIDATION",

        lambda state:

            (

                "ACCEPTANCE"

                if state.get(
                    "validation",
                    {}
                )
                .get(
                    "passed",
                    False
                )

                else

                "FAILURE_ANALYSIS"

            ),

    )



    workflow.add_edge(

        "ACCEPTANCE",

        END

    )



    workflow.add_edge(

        "FAILURE_ANALYSIS",

        END

    )



    return workflow.compile()

def create_graph(
    provider,
):

    return build_graph(
        provider
    )



__all__ = [
    "build_graph",
    "create_graph",
]
