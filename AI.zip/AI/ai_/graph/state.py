# graph/state.py

from __future__ import annotations

from typing import (
    TypedDict,
    Any,
    Dict,
    List,
)



class MaintenanceState(
    TypedDict,
    total=False,
):
    """
    Global LangGraph state.

    All nodes share this object.
    """

    # basic information

    goal: str

    project: str

    project_path: str



    # analysis

    difficulty: Dict[str, Any]

    architecture: Dict[str, Any]



    # planning

    master_plan: Dict[str, Any]

    tasks: List[Dict[str, Any]]

    current_task_index: int

    current_task: Dict[str, Any]



    # execution

    patch_result: Dict[str, Any]

    execution_result: Dict[str, Any]



    # validation

    validation: Dict[str, Any]

    acceptance: Dict[str, Any]



    # failure handling

    failure: Dict[str, Any]



    # runtime

    status: str

    summary: str



    # expert output

    expert_response: Dict[str, Any]

    # V4 orchestration context
    repository_context: Dict[str, Any]
    findings: List[Dict[str, Any]]
    task_graph: Dict[str, Any]
    agent_outputs: Dict[str, Any]
    patches: List[Dict[str, Any]]
    errors: List[Dict[str, Any]]
    retry_count: int
    checkpoint_id: str
