class FinalReleaseCheckpoint:
    def save(self, state):
        return {"checkpoint":state,"stage":"STAGE33"}

    def restore(self, checkpoint):
        return checkpoint
