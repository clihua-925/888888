class GlobalCheckpoint:
    def __init__(self):
        self.snapshot = {}

    def save(self, state):
        self.snapshot = dict(state)

    def restore(self):
        return self.snapshot
