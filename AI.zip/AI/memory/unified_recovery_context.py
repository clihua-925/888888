class UnifiedRecoveryContext:
    def build(self, context, checkpoint, recovery):
        return {
            "context": context,
            "checkpoint": checkpoint,
            "recovery": recovery,
            "stage": "STAGE24"
        }
