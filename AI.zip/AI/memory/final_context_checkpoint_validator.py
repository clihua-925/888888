class FinalContextCheckpointValidator:
    def validate(self, context, checkpoint):
        return {
            "context_valid": True,
            "checkpoint_valid": True,
            "stage": "STAGE30"
        }
