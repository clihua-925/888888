class DeploymentCheckpointManager:
    def save(self, state):
        return {
            "checkpoint": state,
            "stage": "STAGE31"
        }

    def restore(self, checkpoint):
        return checkpoint
