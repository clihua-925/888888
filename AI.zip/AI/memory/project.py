import json
from pathlib import Path

class ProjectMemory:
    def __init__(self, path='memory/project.json'):
        self.path = Path(path)

    def save(self, data):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
