class UnifiedContextRuntime:
    def __init__(self):
        self.state = {}

    def update(self, key, value):
        self.state[key] = value

    def snapshot(self):
        return dict(self.state)

    def restore(self, snapshot):
        self.state = dict(snapshot)
