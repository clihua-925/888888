class ReleaseConfigurationManager:
    def load(self, config=None):
        return {
            "stage": "STAGE40",
            "configuration": config or {},
            "status": "loaded"
        }
