class ContextRuntimeUnifier:
    def merge(self, context, runtime):
        return {
            "context": context,
            "runtime": runtime,
            "stage": "STAGE21"
        }
