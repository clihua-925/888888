import json
from pathlib import Path

class CheckpointManager:
    def __init__(self, path='memory/checkpoint.json'):
        self.path = Path(path)

    def save(self, state):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )
