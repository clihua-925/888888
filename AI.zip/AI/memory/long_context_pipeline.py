class LongContextPipeline:
    def process(self, context_blocks):
        return {
            "merged_context": context_blocks,
            "stage": "STAGE25"
        }
