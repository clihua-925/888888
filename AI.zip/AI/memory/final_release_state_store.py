class FinalReleaseStateStore:
    def save(self, state):
        return {
            "state": state,
            "stage": "STAGE35"
        }

    def restore(self, snapshot):
        return snapshot
