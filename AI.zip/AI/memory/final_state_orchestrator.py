class FinalStateOrchestrator:
    def merge(self, state):
        state["stage"] = "STAGE23"
        return state
