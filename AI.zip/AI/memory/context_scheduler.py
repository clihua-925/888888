class ContextScheduler:
    def __init__(self):
        self.context = {}

    def merge(self, data):
        self.context.update(data)
        return self.context
