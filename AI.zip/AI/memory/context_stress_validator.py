class ContextStressValidator:
    def validate(self, context_chain):
        return {"valid": True, "items": context_chain, "stage":"STAGE48"}
