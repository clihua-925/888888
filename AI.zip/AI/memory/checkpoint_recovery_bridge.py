class CheckpointRecoveryBridge:
    def __init__(self):
        self.checkpoint = None
    def save(self, state):
        self.checkpoint = dict(state)
    def recover(self):
        return self.checkpoint
