import json
from pathlib import Path
class ContextStore:
    def __init__(self,path="memory/context.json"):
        self.path=Path(path)
    def save(self,data):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    def load(self):
        if self.path.exists(): return json.loads(self.path.read_text(encoding="utf-8"))
        return {}
