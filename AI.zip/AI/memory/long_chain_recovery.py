class LongChainRecovery:
    def restore(self, checkpoint):
        return {"checkpoint": checkpoint, "stage": "STAGE29"}
