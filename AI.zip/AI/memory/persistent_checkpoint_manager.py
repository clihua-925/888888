class PersistentCheckpointManager:
    def save(self, state):
        return {"checkpoint": state, "stage": "STAGE48"}

    def restore(self, checkpoint):
        return checkpoint
