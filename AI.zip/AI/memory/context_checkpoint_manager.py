class ContextCheckpointManager:
    def __init__(self):
        self.context = {}
        self.checkpoint = {}

    def save(self, context):
        self.context = dict(context)
        self.checkpoint = dict(context)

    def restore(self):
        return self.checkpoint
