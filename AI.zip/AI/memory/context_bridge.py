def bridge_context(state):
    return {
        'context': state.get('repository_context', {}),
        'memory': state.get('memory', {})
    }
