class ReleaseStateManager:
    def save(self, state):
        return {"state":state,"stage":"STAGE48"}
