class RuntimeContext:
    def __init__(self):
        self.data={}
    def set(self,k,v):
        self.data[k]=v
    def get(self,k,default=None):
        return self.data.get(k,default)
