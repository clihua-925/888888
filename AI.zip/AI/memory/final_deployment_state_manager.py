class FinalDeploymentStateManager:
    def save(self,state):
        return {"stage":"STAGE36","state":state}
