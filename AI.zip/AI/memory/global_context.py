class GlobalContext:
    def __init__(self):
        self.context = {}

    def merge(self, data):
        self.context.update(data)

    def snapshot(self):
        return dict(self.context)
