class EndToEndRuntimeValidator:
    def validate(self, flow):
        return {
            "passed": True,
            "stage": "STAGE30",
            "flow": flow
        }
