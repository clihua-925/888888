def integrate_flow(state: dict):
    state.setdefault('flow', {})
    state['flow']['integrated'] = True
    state['flow']['stage'] = 'STAGE10'
    return state
