def route_after_validation(state: dict):
    validation = state.get('validation', {})
    if validation.get('passed'):
        return 'success'
    if state.get('retry_count', 0) < 3:
        return 'recovery'
    return 'human_review'
