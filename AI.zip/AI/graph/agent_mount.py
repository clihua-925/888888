def mount_agents(state: dict):
    state.setdefault('agents', {})
    state['agents']['mounted'] = True
    return state
