def runtime_node(state: dict):
    state.setdefault('runtime', {})
    state['runtime']['active'] = True
    return state
