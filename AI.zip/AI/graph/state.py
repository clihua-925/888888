from typing import TypedDict, Any, List, Dict

class MaintenanceState(TypedDict, total=False):
    goal: str
    project: str
    project_path: str
    repository_context: Dict[str, Any]
    findings: List[Any]
    architecture: Dict[str, Any]
    task_graph: List[Any]
    patches: List[Any]
    validation: Dict[str, Any]
    errors: List[Any]
    retry_count: int
    status: str
