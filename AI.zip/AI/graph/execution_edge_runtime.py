class ExecutionEdgeRuntime:
    def route(self, status):
        if status == "success":
            return "continue"
        if status == "retry":
            return "retry"
        return "human_review"
