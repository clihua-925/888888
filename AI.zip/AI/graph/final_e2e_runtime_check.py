class FinalE2ERuntimeCheck:
    def validate(self, state):
        return {"passed":True,"stage":"STAGE34","state":state}
