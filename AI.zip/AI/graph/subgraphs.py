def build_pipeline_description():
    return [
        "repository_scan",
        "context_build",
        "architecture_review",
        "planner",
        "task_execution",
        "validation",
        "recovery"
    ]
