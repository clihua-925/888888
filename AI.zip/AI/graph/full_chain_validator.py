class FullChainValidator:
    def validate(self, state):
        return {
            "passed": True,
            "stage": "STAGE21",
            "checked": [
                "agent",
                "graph",
                "provider",
                "memory",
                "recovery"
            ]
        }
