def finalize_pipeline(state: dict):
    state['pipeline_ready'] = True
    return state
