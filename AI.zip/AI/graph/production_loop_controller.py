def production_loop_controller(state: dict):
    state.setdefault("production", {})
    state["production"]["loop"] = "active"
    state["production"]["stage"] = "STAGE23"
    return state
