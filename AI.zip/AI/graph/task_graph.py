from typing import List, Dict


def build_task_graph(tasks: List[Dict]) -> Dict:
    nodes = []
    for i, task in enumerate(tasks):
        nodes.append({
            "id": task.get("task_id", f"TASK_{i+1}"),
            "depends_on": task.get("dependencies", []),
            "status": "pending"
        })

    return {"nodes": nodes}
