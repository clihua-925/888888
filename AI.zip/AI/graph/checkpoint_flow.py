def checkpoint_flow(state):
    state['checkpoint_ready']=True
    return state
