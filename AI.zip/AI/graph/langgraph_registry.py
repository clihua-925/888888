def register_nodes(graph):
    graph.setdefault('nodes', [])
    return graph
