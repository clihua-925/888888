def next_condition(state: dict):
    if state.get('validation', {}).get('passed'):
        return 'success'
    if state.get('retry_count', 0) < 3:
        return 'retry'
    return 'human_review'
