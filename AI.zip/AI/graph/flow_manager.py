def update_flow_state(state: dict):
    state.setdefault('flow', {})
    state['flow']['stage'] = 'ORCHESTRATION'
    return state
