class RuntimeNodeBinding:
    def bind(self, nodes):
        return {"nodes": nodes, "stage": "STAGE29"}
