from pathlib import Path
import os
import json


from providers.hybrid import HybridProvider
from graph.execution_node import ExecutionNode



class ProjectDiscovery:


    def __init__(
        self,
        root=None
    ):

        self.root = Path(
            root or os.getcwd()
        )


    def scan(self):

        python_files = []

        directories = []


        for path in self.root.rglob("*"):


            if path.is_dir():

                if ".venv" not in str(path):

                    directories.append(
                        str(
                            path.relative_to(
                                self.root
                            )
                        )
                    )


            elif (

                path.suffix == ".py"

                and ".venv" not in str(path)

            ):

                python_files.append(

                    str(
                        path.relative_to(
                            self.root
                        )
                    )

                )


        return {


            "project_path":

                str(
                    self.root
                ),


            "directories":

                directories[:200],


            "python_files":

                python_files[:300],


            "python_file_count":

                len(
                    python_files
                )

        }





class MaintenanceClosedLoop:


    def __init__(self):

        self.stage = (
            "STAGE50"
        )


        self.provider = (
            HybridProvider()
        )


        self.discovery = (
            ProjectDiscovery()
        )


        self.execution = (
            ExecutionNode()
        )



    def execute(
        self,
        task
    ):


        print(
            "\n[DISCOVER] scanning project..."
        )


        structure = (
            self.discovery.scan()
        )



        context = {


            "task":

                task,


            "project":

                structure

        }



        print(
            "[AI] sending to DeepSeek..."
        )


        analysis = (
            self.provider.analyze(
                json.dumps(
                    context,
                    ensure_ascii=False
                )
            )
        )



        print(
            "[PLAN] generating plan..."
        )


        plan = (
            self.provider.plan(
                json.dumps(
                    analysis,
                    ensure_ascii=False
                )
            )
        )



        print(
            "[EXECUTE] running command..."
        )


        execution = (
            self.execution.execute(
                plan
            )
        )



        print(
            "[REVIEW] reviewing..."
        )


        review = (
            self.provider.review(
                plan
            )
        )



        print(
            "[VALIDATE] validating..."
        )


        validation = (
            self.provider.validate(
                review
            )
        )



        return {


            "stage":

                self.stage,


            "status":

                "completed",


            "task":

                task,


            "discover":

                structure,


            "analysis":

                analysis,


            "plan":

                plan,


            "execution":

                execution,


            "review":

                review,


            "validation":

                validation

        }