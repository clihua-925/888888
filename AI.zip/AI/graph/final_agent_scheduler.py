class FinalAgentScheduler:
    def __init__(self):
        self.agents = []

    def register(self, agent):
        self.agents.append(agent)

    def dispatch(self, task):
        return {
            "task": task,
            "agents": self.agents,
            "stage": "STAGE24"
        }
