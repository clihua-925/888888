from graph.code_editor import CodeEditor


class CodePatchExecutor:


    def __init__(self, root=None):

        self.editor = CodeEditor(root)



    def execute_patch(
        self,
        patch
    ):

        results = []


        for item in patch:

            file_path = (
                item["file"]
            )

            old = (
                item["old"]
            )

            new = (
                item["new"]
            )


            result = (
                self.editor.replace(
                    file_path,
                    old,
                    new
                )
            )


            results.append(
                {
                    "file": file_path,
                    "result": result
                }
            )


        return {
            "success": all(
                r["result"].get("success")
                for r in results
            ),
            "results": results
        }