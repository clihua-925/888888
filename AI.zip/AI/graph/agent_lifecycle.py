def lifecycle_event(state: dict, event: str):
    state.setdefault("lifecycle", [])
    state["lifecycle"].append(event)
    return state
