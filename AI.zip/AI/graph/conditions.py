def should_retry(state):
    return state.get("retry_count",0) < 3 and not state.get("validation",{}).get("passed",False)

def should_human_review(state):
    return state.get("retry_count",0) >= 3
