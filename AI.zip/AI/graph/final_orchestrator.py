def final_orchestrator(state: dict):
    state.setdefault('final_runtime', {})
    state['final_runtime']['orchestrator_ready'] = True
    return state
