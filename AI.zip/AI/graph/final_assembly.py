def final_assembly(state: dict):
    state.setdefault('assembly', {})
    state['assembly']['stage']='STAGE15'
    state['assembly']['ready']=True
    return state
