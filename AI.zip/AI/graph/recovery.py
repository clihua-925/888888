def recovery_node(state):
    state['retry_count'] = state.get('retry_count', 0) + 1
    state['status'] = 'RECOVERING'
    return state
