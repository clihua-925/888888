class ConditionalRetryManager:
    def decide(self, result):
        if result.get("recoverable"):
            return "retry"
        return "continue"
