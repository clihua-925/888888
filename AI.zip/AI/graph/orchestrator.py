def orchestrator_node(state: dict):
    state.setdefault('orchestration', {})
    state['orchestration']['agents_ready'] = True
    state['orchestration']['mode'] = 'langgraph'
    return state
