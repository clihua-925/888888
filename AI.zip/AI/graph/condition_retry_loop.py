def retry_loop(state: dict):
    state.setdefault("retry", 0)
    state["retry"] += 1
    return state
