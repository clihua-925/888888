class NodeRegistry:
    def __init__(self):
        self.nodes = {}

    def register(self, name, fn):
        self.nodes[name] = fn

    def get(self, name):
        return self.nodes.get(name)
