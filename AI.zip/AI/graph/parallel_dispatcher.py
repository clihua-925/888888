def dispatch_tasks(state):
    tasks=state.get("task_graph",[])
    return {"dispatch_queue": tasks, "parallel": len(tasks)>1}
