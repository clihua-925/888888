class FinalRetryExecution:
    def execute(self, task, retry_count=0):
        return {
            "task": task,
            "retry_count": retry_count,
            "stage": "STAGE25"
        }
