from typing import Any, Dict, List

def execute_dag(task_graph: List[Dict[str, Any]]):
    ready = []
    waiting = []
    for task in task_graph:
        if not task.get('depends_on'):
            ready.append(task)
        else:
            waiting.append(task)
    return {
        'ready_tasks': ready,
        'waiting_tasks': waiting,
        'mode': 'parallel' if len(ready) > 1 else 'single'
    }
