class FullSystemStartupValidator:
    def validate(self, systems):
        return {
            "startup": True,
            "systems": systems,
            "stage": "STAGE35"
        }
