def release_orchestrator(state: dict):
    state.setdefault("release", {})
    state["release"]["stage"] = "STAGE14"
    state["release"]["ready"] = True
    return state
