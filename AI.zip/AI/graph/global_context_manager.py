class GlobalContextManager:
    def merge(self, short_term, task, code, history):
        return {
            "short_term": short_term,
            "task": task,
            "code": code,
            "history": history,
            "stage": "STAGE48"
        }
