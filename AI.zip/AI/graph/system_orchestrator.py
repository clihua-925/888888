def system_orchestrator(state: dict):
    state.setdefault("system", {})
    state["system"]["orchestrated"] = True
    state["system"]["stage"] = "STAGE20"
    return state
