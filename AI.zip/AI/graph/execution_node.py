from runtime.code_executor_runtime import CodeExecutorRuntime


class ExecutionNode:

    def __init__(self):

        self.executor = CodeExecutorRuntime()


    def execute(self, plan):

        command = self.extract_command(
            plan
        )

        result = self.executor.execute(
            command
        )

        return {

            "execution": result,

            "execution_success":
                result.get(
                    "success",
                    False
                ),

            "command":
                command

        }


    def extract_command(self, plan):

        """
        从AI计划中提取执行命令
        """

        if isinstance(
            plan,
            dict
        ):

            if "command" in plan:

                return plan[
                    "command"
                ]


            if "commands" in plan:

                commands = plan[
                    "commands"
                ]

                if isinstance(
                    commands,
                    list
                ) and commands:

                    return commands[0]


        if isinstance(
            plan,
            str
        ):

            lines = (
                plan
                .splitlines()
            )


            for line in lines:

                cmd = (
                    line
                    .strip()
                    .replace(
                        "-",
                        "",
                        1
                    )
                    .strip()
                )


                if cmd.startswith(
                    "python "
                ):

                    return cmd


                if cmd.startswith(
                    "python -m"
                ):

                    return cmd


                if cmd.startswith(
                    "pytest"
                ):

                    return cmd


                if cmd.startswith(
                    "pip "
                ):

                    return cmd


        return (
            "python --version"
        )