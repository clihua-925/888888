class NodeRuntimeManager:
    def __init__(self):
        self.nodes = {}

    def register(self, name, handler):
        self.nodes[name] = handler

    def get(self, name):
        return self.nodes.get(name)
