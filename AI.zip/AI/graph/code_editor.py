from pathlib import Path
import shutil
from datetime import datetime


class CodeEditor:


    def __init__(self, root=None):

        self.root = Path(root or ".")

        self.backup_dir = (
            self.root / ".maintenance_backup"
        )

        self.backup_dir.mkdir(
            exist_ok=True
        )



    def read_file(self, file_path):

        path = self.root / file_path

        if not path.exists():
            raise FileNotFoundError(
                f"File not found: {file_path}"
            )


        return path.read_text(
            encoding="utf-8"
        )



    def backup_file(self, file_path):

        source = self.root / file_path

        if not source.exists():
            raise FileNotFoundError(
                file_path
            )


        timestamp = (
            datetime.now()
            .strftime("%Y%m%d_%H%M%S")
        )


        target = (
            self.backup_dir /
            f"{source.name}.{timestamp}.bak"
        )


        shutil.copy2(
            source,
            target
        )


        return str(target)



    def write_file(
        self,
        file_path,
        content
    ):

        path = self.root / file_path


        self.backup_file(
            file_path
        )


        path.write_text(
            content,
            encoding="utf-8"
        )


        return {
            "success": True,
            "file": str(file_path)
        }



    def replace(
        self,
        file_path,
        old,
        new
    ):

        content = self.read_file(
            file_path
        )


        if old not in content:

            return {
                "success": False,
                "reason":
                "target code not found"
            }


        updated = content.replace(
            old,
            new,
            1
        )


        return self.write_file(
            file_path,
            updated
        )