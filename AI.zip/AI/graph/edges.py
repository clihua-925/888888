from typing import Any


def should_retry(state: dict) -> str:
    validation = state.get("validation", {})
    errors = state.get("errors", [])
    retry_count = state.get("retry_count", 0)

    if validation.get("passed"):
        return "success"

    if retry_count < 3 and errors:
        return "recovery"

    return "human_review"


def execution_route(state: dict) -> str:
    task_graph = state.get("task_graph", [])
    if len(task_graph) > 1:
        return "parallel"
    return "single"
