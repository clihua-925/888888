class EndToEndPipeline:
    def __init__(self):
        self.status = "initialized"

    def run(self):
        self.status = "completed"
        return self.status
