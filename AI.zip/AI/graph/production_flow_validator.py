class ProductionFlowValidator:
    def validate(self, flow):
        return {'stage':'STAGE39','flow':flow,'status':'validated'}
