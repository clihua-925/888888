def supervisor_node(state: dict):
    tasks = state.get('task_graph', [])
    state['execution_mode'] = 'parallel' if len(tasks) > 1 else 'single'
    return state
