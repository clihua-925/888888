class RuntimeDeploymentValidator:
    def validate(self, runtime):
        return {"stage":"STAGE47","runtime":runtime,"status":"ready"}
