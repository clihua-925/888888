import subprocess
import os
import json
from pathlib import Path


class CodeExecutorRuntime:

    def __init__(self, workdir=None):
        self.workdir = Path(workdir or os.getcwd())

    def normalize_command(self, command):

        if command.strip() == "pytest":
            return "python -m pytest tests"

        if command.startswith("pytest "):
            target = command.replace("pytest ", "")
            return f"python -m pytest {target}"

        return command


    def execute(self, command, timeout=120):

        command = self.normalize_command(command)

        try:

            result = subprocess.run(
                command,
                cwd=str(self.workdir),
                shell=True,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                timeout=timeout
            )


            return {
                "success": result.returncode == 0,
                "exit_code": result.returncode,
                "command": command,
                "stdout": result.stdout,
                "stderr": result.stderr
            }


        except subprocess.TimeoutExpired:

            return {
                "success": False,
                "exit_code": -1,
                "command": command,
                "stdout": "",
                "stderr": "execution timeout"
            }


        except Exception as e:

            return {
                "success": False,
                "exit_code": -1,
                "command": command,
                "stdout": "",
                "stderr": str(e)
            }



if __name__ == "__main__":

    executor = CodeExecutorRuntime()

    result = executor.execute(
        "python --version"
    )

    print(
        json.dumps(
            result,
            ensure_ascii=False,
            indent=2
        )
    )