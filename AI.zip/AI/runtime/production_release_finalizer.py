class ProductionReleaseFinalizer:
    def finalize(self, state=None):
        return {
            "stage": "STAGE40",
            "release": "production_candidate",
            "state": state or {}
        }
