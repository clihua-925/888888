from graph.execution_node import ExecutionNode


def test_execution_node():

    node = ExecutionNode()

    result = node.run(
        "python --version"
    )

    assert result["execution_success"] is True