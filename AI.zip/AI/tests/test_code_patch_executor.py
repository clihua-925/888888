from graph.code_patch_executor import CodePatchExecutor



def test_patch_executor(tmp_path):


    file = (
        tmp_path /
        "demo.py"
    )


    file.write_text(
        "value = 1",
        encoding="utf-8"
    )


    executor = CodePatchExecutor(
        tmp_path
    )


    patch = [

        {
            "file": "demo.py",
            "old": "value = 1",
            "new": "value = 2"
        }

    ]


    result = (
        executor.execute_patch(
            patch
        )
    )


    assert result["success"]


    content = (
        file.read_text(
            encoding="utf-8"
        )
    )


    assert (
        "value = 2"
        in content
    )