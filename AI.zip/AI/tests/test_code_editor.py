from pathlib import Path

from graph.code_editor import CodeEditor



def test_code_editor(tmp_path):


    file = (
        tmp_path /
        "demo.py"
    )


    file.write_text(
        "print('old')",
        encoding="utf-8"
    )


    editor = CodeEditor(
        tmp_path
    )


    result = editor.replace(
        "demo.py",
        "old",
        "new"
    )


    assert result["success"]


    content = (
        file.read_text(
            encoding="utf-8"
        )
    )


    assert "new" in content