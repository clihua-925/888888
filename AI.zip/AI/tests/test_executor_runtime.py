from runtime.code_executor_runtime import CodeExecutorRuntime


def test_python_execute():

    executor = CodeExecutorRuntime()

    result = executor.execute(
        "python --version"
    )

    assert result["success"] is True



def test_shell_execute():

    executor = CodeExecutorRuntime()

    result = executor.execute(
        "dir"
    )

    assert result["success"] is True