class BrowserStabilityController:
    def __init__(self):
        self.state = "idle"

    def healthy(self):
        return self.state == "connected"

    def recover(self):
        self.state = "recovering"
