class BrowserProductionValidator:
    def validate(self, session):
        return {
            "session": session,
            "browser_ready": True,
            "stage": "STAGE30"
        }
