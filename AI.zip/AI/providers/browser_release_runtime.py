class BrowserReleaseRuntime:
    def check(self):
        return {"browser":"ready","stage":"STAGE34"}

    def recover(self):
        return {"browser":"recovered","stage":"STAGE34"}
