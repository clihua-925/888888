class BrowserFaultTolerance:
    def __init__(self):
        self.state = "healthy"

    def detect(self):
        return self.state

    def recover(self):
        self.state = "recovered"
