class BrowserSessionManager:
    def __init__(self):
        self.connected = False

    def ensure(self):
        return self.connected
