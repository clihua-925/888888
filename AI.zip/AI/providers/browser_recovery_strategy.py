class BrowserRecoveryStrategy:
    def recover(self, error=None):
        return {
            "action": "recover",
            "error": error,
            "stage": "STAGE20"
        }
