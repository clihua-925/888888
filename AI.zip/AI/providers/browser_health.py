class BrowserHealth:
    def check(self):
        return {"browser":"managed","status":"check_required"}
