def provider_router(state: dict):
    provider = state.get('provider', 'browser')
    return {'selected_provider': provider}
