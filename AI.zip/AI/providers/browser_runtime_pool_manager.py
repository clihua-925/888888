class BrowserRuntimePoolManager:
    def __init__(self):
        self.sessions = {}

    def register(self, name):
        self.sessions[name] = "ready"

    def recover(self, name):
        self.sessions[name] = "recovering"
