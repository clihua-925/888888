class BrowserLifecycleManager:
    def __init__(self):
        self.state = 'idle'
    def set_state(self, value):
        self.state = value
    def get_state(self):
        return self.state
