from __future__ import annotations

import os
import json
import re

from openai import OpenAI


DEFAULT_LOCAL_BASE_URL = (
    "http://192.168.1.26:8081/v1"
)


DEFAULT_LOCAL_MODEL = (
    "/home/chang/models/deepseek-r1-70b/"
    "DeepSeek-R1-Distill-Llama-70B-Q6_K-00001-of-00002.gguf"
)


def safe_text(text):
    if text is None:
        return ""

    return str(text).strip()



def extract_json(text):

    text = safe_text(text)

    text = re.sub(
        r"```json",
        "",
        text,
        flags=re.I
    )

    text = re.sub(
        r"```",
        "",
        text
    )


    match = re.search(
        r"\{.*\}",
        text,
        flags=re.S
    )


    if not match:

        return {
            "raw_response": text
        }


    try:

        return json.loads(
            match.group(0)
        )

    except Exception:

        return {
            "raw_response": text
        }




class LocalModel:

    """
    llama.cpp OpenAI compatible client

    DeepSeek-R1-70B
    """


    def __init__(self):

        self.base_url = os.getenv(
            "LOCAL_MODEL_BASE_URL",
            DEFAULT_LOCAL_BASE_URL
        )


        self.model = os.getenv(
            "LOCAL_MODEL_NAME",
            DEFAULT_LOCAL_MODEL
        )


        self.client = OpenAI(

            api_key="local",

            base_url=self.base_url

        )



    def ask(
        self,
        system,
        user=None,
        temperature=0.1
    ):


        if user is None:

            user = system

            system = (
                "You are a professional "
                "software maintenance AI."
            )


        result = self.client.chat.completions.create(

            model=self.model,

            messages=[

                {
                    "role":"system",
                    "content":system
                },

                {
                    "role":"user",
                    "content":user
                }

            ],

            temperature=temperature

        )


        return safe_text(

            result
            .choices[0]
            .message
            .content

        )



    def ask_json(
        self,
        system,
        user
    ):

        return extract_json(

            self.ask(
                system,
                user
            )

        )






class HybridProvider:


    name="hybrid"



    def __init__(self):

        self.local = LocalModel()



    def analyze(
        self,
        task
    ):


        prompt=f"""

执行软件维护分析任务。

任务:

{task}


要求:

1. 分析架构
2. 分析风险
3. 找出问题
4. 给出建议

返回JSON:

{{
 "issues":[],
 "risk":"",
 "recommendations":[]
}}

"""


        return self.local.ask_json(

            "你是DeepSeek软件架构专家",

            prompt

        )



    def plan(
        self,
        task
    ):


        return self.local.ask(

            """

你是高级软件维护工程师。

制定详细执行计划。

""",

            task

        )



    def generate_code(
        self,
        task
    ):


        return self.local.ask(

            """

你是Python高级工程师。

根据任务生成安全修改方案。

不要编造文件。

""",

            task

        )



    def review(
        self,
        result
    ):


        return self.local.ask(

            """

你是代码审查专家。

审查下面结果:

""",

            str(result)

        )



    def validate(
        self,
        result
    ):


        return {

            "passed":True,

            "model":
            "DeepSeek-R1-70B",

            "result":result

        }