class RecoveryController:
    def __init__(self, max_retry=3):
        self.max_retry = max_retry

    def check(self, state):
        return state.get("retry_count", 0) < self.max_retry
