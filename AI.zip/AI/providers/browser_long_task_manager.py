class BrowserLongTaskManager:
    def __init__(self):
        self.state = "ready"

    def recover(self):
        self.state = "recovering"
