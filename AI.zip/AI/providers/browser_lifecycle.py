class BrowserLifecycle:
    def __init__(self):
        self.state='idle'
    def mark_connected(self):
        self.state='connected'
    def mark_recovering(self):
        self.state='recovering'
