class BrowserReconnectManager:
    def __init__(self):
        self.retry = 0

    def reconnect(self):
        self.retry += 1
        return True
