class BrowserMainFlowAdapter:
    def __init__(self):
        self.status = "ready"

    def attach(self):
        self.status = "attached"

    def recover(self):
        self.status = "recovering"
