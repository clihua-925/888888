class BrowserProviderBridge:
    def __init__(self):
        self.state = "idle"

    def connect(self):
        self.state = "connected"

    def recover(self):
        self.state = "recovering"
