class BrowserTaskExecutor:
    def __init__(self):
        self.state="ready"
    def execute(self, prompt):
        self.state="executing"
        return {"prompt":prompt,"state":self.state,"stage":"STAGE48"}
