class BrowserSessionPool:
    def __init__(self):
        self.sessions = {}

    def acquire(self, key):
        self.sessions[key] = "active"
        return self.sessions[key]

    def recover(self, key):
        self.sessions[key] = "recovered"
