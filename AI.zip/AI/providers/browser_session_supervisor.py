class BrowserSessionSupervisor:
    def __init__(self):
        self.state = "idle"

    def monitor(self):
        return self.state

    def recover(self):
        self.state = "recovering"
