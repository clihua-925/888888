class ProviderHealth:
    def __init__(self):
        self.status = {}

    def update(self, provider, value):
        self.status[provider] = value

    def get(self, provider):
        return self.status.get(provider, "unknown")
