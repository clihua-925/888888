class BrowserProductionGuard:
    def __init__(self):
        self.status = "idle"

    def check(self):
        return self.status

    def recover(self):
        self.status = "recovering"
