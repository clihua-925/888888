class ProviderHealthCheck:
    def check(self, provider):
        return {"stage":"STAGE47","provider":provider,"status":"healthy"}
