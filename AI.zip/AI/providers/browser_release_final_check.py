class BrowserReleaseFinalCheck:
    def verify(self, session=None):
        return {"stage":"STAGE42","session":session,"status":"checked"}
