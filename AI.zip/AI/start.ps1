Write-Host "============================================================"
Write-Host "AI_Code_Maintenance V4"
Write-Host "STAGE48 Production System Starting"
Write-Host "============================================================"


# 检查虚拟环境

if (!(Test-Path ".venv")) {

    Write-Host "Creating virtual environment..."

    python -m venv .venv

}


# 激活环境

& ".\.venv\Scripts\Activate.ps1"


Write-Host ""
Write-Host "[1/6] Checking dependencies..."


python -m pip install -r requirements.txt --quiet



Write-Host ""
Write-Host "[2/6] Runtime checking..."


python -c "
from runtime.final_production_runtime import FinalProductionRuntime

r=FinalProductionRuntime()

print({
'stage':r.stage,
'status':'runtime_ready'
})
"



Write-Host ""
Write-Host "[3/6] Agent checking..."


python -c "
from graph.agent_manager import AgentManager

print({
'agents':'ready'
})
"



Write-Host ""
Write-Host "[4/6] Graph checking..."


python -c "
from graph.maintenance_closed_loop import MaintenanceClosedLoop

print({
'graph':'ready'
})
"



Write-Host ""
Write-Host "[5/6] Memory Checkpoint Recovery checking..."


python -c "
from graph.checkpoint import CheckpointStore
from graph.failure_recovery_engine import FailureRecoveryEngine

CheckpointStore()
FailureRecoveryEngine()

print({
'memory':'ready',
'recovery':'ready'
})
"



Write-Host ""
Write-Host "[6/6] Starting Web UI..."
Write-Host ""
Write-Host "============================================================"
Write-Host "Web UI:"
Write-Host "http://127.0.0.1:8000"
Write-Host "============================================================"


python -m app.api