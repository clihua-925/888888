Write-Host "AI_Code_Maintenance Setup"

if (!(Test-Path ".venv")) {

    python -m venv .venv

}

.\.venv\Scripts\activate

python -m pip install --upgrade pip

pip install -r requirements.txt


Write-Host ""
Write-Host "Environment Ready"