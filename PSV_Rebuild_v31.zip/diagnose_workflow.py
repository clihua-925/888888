"""Per-node execution recorder (offline diagnostic).

用法:
  .venv\\Scripts\\python.exe diagnose_workflow.py trade_collection "采集美国毛毡海关数据" "United States" felt

以真实计划/路由/节点 + 真实 provider（本地 LLM、项目数据库）逐节点执行，
把每个节点的输入摘要、输出摘要、耗时、错误与完整堆栈写入:
  diagnose_<workflow_id>_<timestamp>.jsonl
每行一个 JSON 对象，供逐节点达标判定。不改动任何项目文件与数据库结构。
"""
from __future__ import annotations

import json
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
except Exception:
    load_dotenv = None  # dotenv 不可用时由 Settings 直接读环境变量

from core.config.settings import Settings, APP_VERSION
from core.contracts.context import push_providers, pop_providers
from core.memory.db import Database
from core.orchestration.conditions import ConditionEdgeEngine
from core.orchestration.decision import DecisionLayer
from core.orchestration.plan import OrchestrationPlanGenerator
from core.orchestration.providers import DatabaseProvider
from core.orchestration.registry import WorkflowRegistry


def _sizes(state: dict) -> dict:
    out = {}
    for key, value in state.items():
        if isinstance(value, (list, dict, str)):
            out[key] = len(value)
    return out


def _sample(value, limit: int = 2):
    if isinstance(value, list):
        return [str(item)[:200] for item in value[:limit]]
    if isinstance(value, dict):
        return {k: str(v)[:160] for k, v in list(value.items())[:limit]}
    return str(value)[:200]


def main() -> int:
    if len(sys.argv) < 3:
        print("用法: python diagnose_workflow.py <workflow_id> \"<request>\" [market] [industry]")
        return 2
    workflow_id = sys.argv[1]
    request = sys.argv[2]
    market = sys.argv[3] if len(sys.argv) > 3 else "United States"
    industry = sys.argv[4] if len(sys.argv) > 4 else "felt"

    settings = Settings()
    registry = WorkflowRegistry()
    registry.discover()
    plan = OrchestrationPlanGenerator(registry).plan_for(workflow_id)
    router = ConditionEdgeEngine()
    wf_obj = next((w for w in registry.workflows() if w.workflow_id == workflow_id), None)
    if wf_obj is None:
        print(f"[recorder] 未找到工作流: {workflow_id}")
        return 2
    node_fn = registry.node_functions(wf_obj)
    database = Database(settings.database_path)
    token = push_providers(DecisionLayer(), DatabaseProvider(database), None)

    task_id = f"diag-{workflow_id}-{datetime.now():%H%M%S}"
    out_path = ROOT / f"diagnose_{workflow_id}_{datetime.now():%Y%m%d_%H%M%S}.jsonl"
    state = {
        "task_id": task_id, "status": "RUNNING",
        "mission": {"request": request, "market": market, "industry": industry},
        "trade_nodes": [], "relationships": [], "evidence_pool": [], "entities": [],
        "decisions": [], "node_reports": {}, "fragments": [], "product_definition": {},
        "history": [], "orchestration": {}, "error": None,
    }
    database.create_task(task_id, workflow_id, {"request": request, "market": market, "industry": industry}, "RUNNING")
    print(f"[recorder] {APP_VERSION} workflow={workflow_id} plan={plan.order}")
    print(f"[recorder] 记录文件: {out_path}")
    current = plan.order[0]
    try:
        with out_path.open("w", encoding="utf-8") as fh:
            while current:
                before = _sizes(state)
                t0 = time.time()
                record = {"node_id": current, "step": len(state["node_reports"]) + 1,
                          "inputs": before, "ts": datetime.now().isoformat()}
                try:
                    state = node_fn[current](state)
                    record["duration_ms"] = int((time.time() - t0) * 1000)
                    record["outputs"] = _sizes(state)
                    record["output_sample"] = {
                        "trade_nodes": _sample(state.get("trade_nodes")),
                        "entities": _sample(state.get("entities")),
                        "relationships": _sample(state.get("relationships")),
                        "evidence_pool": _sample(state.get("evidence_pool")),
                        "decisions_tail": _sample((state.get("decisions") or [])[-2:]),
                    }
                    record["status"] = "ok"
                except Exception as exc:  # noqa: BLE001 - recorder must capture everything
                    record["duration_ms"] = int((time.time() - t0) * 1000)
                    record["status"] = "failed"
                    record["error"] = f"{type(exc).__name__}: {exc}"
                    record["traceback"] = traceback.format_exc()
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")
                fh.flush()
                print(f"[recorder] {record['status'].upper():6s} {current} ({record['duration_ms']}ms)")
                if record["status"] != "ok":
                    print(record["traceback"])
                    break
                state["status"] = "RUNNING"
                route = router.choose(plan, state, current)
                current = route.target
                if route.reason == "workflow_completed":
                    print(f"[recorder] workflow_completed, 节点报告: {json.dumps(state['node_reports'].get('DATABASE_COMMIT', {}), ensure_ascii=False)[:300]}")
                    break
    finally:
        pop_providers(token)
    try:
        database.update_task(task_id, {}, "COMPLETED")
    except Exception as _exc:
        print(f"[recorder] 状态标记失败（不影响记录）: {_exc}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
