@echo off
rem ============================================================
rem PSV Trade OS 9.4.1 - Start Script (UTF-8 NO BOM + CRLF)
rem Chain: .env -> Python -> venv -> deps -> verify -> WebUI -> CDP Chrome
rem ============================================================
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
title PSV Trade OS 9.4.1 Launcher
cd /d "%~dp0"

set "LOG=%~dp0start.log"
echo [%DATE% %TIME%] BOOT cwd=%CD% >> "%LOG%"

rem --- 0. Ensure .env exists ---
if not exist "%~dp0.env" (
    if exist "%~dp0.env.example" (
        copy /y "%~dp0.env.example" "%~dp0.env" >nul
        echo [OK] Created .env from .env.example
    ) else (
        echo [WARN] .env.example not found; environment defaults will be used.
    )
)
echo [%DATE% %TIME%] step=1_env >> "%LOG%"

rem --- 1. Resolve Python interpreter (3.10 - 3.14) ---
rem PYTHON_EXE is "python" or "py -3.12": no spaces/special chars, never quote the whole string.
set "PYTHON_EXE="
set "PYTHON_VERSION="
for /f "tokens=2 delims= " %%V in ('python --version 2^>^&1') do set "PYTHON_VERSION=%%V"
if defined PYTHON_VERSION (
    echo %PYTHON_VERSION% | findstr /r /c:"^3\.1[0-4]\." >nul
    if not errorlevel 1 set "PYTHON_EXE=python"
)
if defined PYTHON_EXE (
    %PYTHON_EXE% -c "import sys" >nul 2>&1
    if errorlevel 1 (
        echo [INFO] PATH python is a stub/broken, ignoring.
        set "PYTHON_EXE="
    )
)
if not defined PYTHON_EXE (
    echo [INFO] Trying Python launcher for version 3.14-3.10 ...
    for %%V in (3.14 3.13 3.12 3.11 3.10) do (
        if not defined PYTHON_EXE (
            py -%%V -c "import sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] <= (3,14) else 1)" >nul 2>&1
            if not errorlevel 1 set "PYTHON_EXE=py -%%V"
        )
    )
)
if not defined PYTHON_EXE goto die_no_python
echo [OK] Using Python: %PYTHON_EXE%
echo [%DATE% %TIME%] step=2_python=%PYTHON_EXE% >> "%LOG%"

rem --- 2. .env legacy migration (MAX_TASK_SECONDS 1800 -> 7200) ---
if exist "%~dp0.env" (
    %PYTHON_EXE% -c "from pathlib import Path; p=Path('.env'); t=p.read_text(encoding='utf-8',errors='replace'); u=t.replace('MAX_TASK_SECONDS=1800','MAX_TASK_SECONDS=7200'); (p.write_text(u,encoding='utf-8') if u!=t else None)" >nul 2>&1
    if errorlevel 1 echo [WARN] .env migration skipped.
)

rem --- 3. Create/reuse virtual environment ---
set "VENV_DIR=%~dp0.venv"
set "ENV_PYTHON=%VENV_DIR%\Scripts\python.exe"
if not exist "%ENV_PYTHON%" (
    echo [INFO] Creating virtual environment in .venv ...
    %PYTHON_EXE% -m venv "%VENV_DIR%"
    if errorlevel 1 goto die_venv
) else (
    echo [OK] Virtual environment found.
)

rem --- 4. Dependencies (probe first, then install) ---
"%ENV_PYTHON%" -c "import flask, openai, langgraph, dotenv, playwright, curl_cffi, uuid_utils" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing dependencies ...
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip >nul
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
    if errorlevel 1 goto die_deps
)
echo [OK] Dependencies ready.
echo [%DATE% %TIME%] step=4_deps >> "%LOG%"

rem --- 5. Native runtime verification gate ---
"%ENV_PYTHON%" "%~dp0verify_install.py"
if errorlevel 1 goto die_verify

rem --- 6. Port collision guard ---
"%ENV_PYTHON%" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8090/',timeout=1).read(1)" >nul 2>&1
if not errorlevel 1 (
    echo [WARN] Port 8090 already responding - old instance running?
    echo         Readiness check below may confirm the OLD instance, not a new one.
    pause
)

rem --- 7. Start WebUI in a dedicated window ---
start "PSV Trade OS WebUI" cmd /k ""%ENV_PYTHON%" "%~dp0run_webui.py""
echo [%DATE% %TIME%] step=7_webui >> "%LOG%"

rem --- 8. Readiness wait (up to ~2 minutes) ---
for /l %%I in (1,1,60) do (
    "%ENV_PYTHON%" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8090/',timeout=1).read(1)" >nul 2>&1
    if not errorlevel 1 goto webui_ready
    timeout /t 2 /nobreak >nul
)
echo [ERROR] WebUI not ready in ~2 minutes. Check the WebUI window and start.log.
echo [%DATE% %TIME%] step=8_timeout >> "%LOG%"
pause
exit /b 1

:webui_ready
echo [OK] WebUI is responding at http://127.0.0.1:8090

rem --- 9. CDP browser ---
netstat -ano | findstr /r ":9222 .*LISTENING" >nul
if not errorlevel 1 echo [INFO] Port 9222 already listening - reusing CDP session.
call "%~dp0start_chrome_debug.bat"

echo.
echo  WebUI: http://127.0.0.1:8090   Chrome CDP: http://127.0.0.1:9222
echo  Logs:  start.log, data\logs\worker_*.log
pause
exit /b 0

:die_no_python
echo [ERROR] No usable Python 3.10-3.14. Install from python.org and tick "Add to PATH".
echo [%DATE% %TIME%] DIE no_python >> "%LOG%"
pause
exit /b 1
:die_venv
echo [ERROR] venv creation failed.
echo [%DATE% %TIME%] DIE venv >> "%LOG%"
pause
exit /b 1
:die_deps
echo [ERROR] Dependency installation failed. Check network / pip mirror.
echo [%DATE% %TIME%] DIE deps >> "%LOG%"
pause
exit /b 1
:die_verify
echo [ERROR] Static verification failed. See messages above.
echo [%DATE% %TIME%] DIE verify >> "%LOG%"
pause
exit /b 1
