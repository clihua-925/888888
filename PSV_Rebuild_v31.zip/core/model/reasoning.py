"""OpenAI-compatible reasoning engine for PSV Trade OS 9.4.1."""

from __future__ import annotations
import os

import json
import logging
from typing import Any

try:
    from openai import OpenAI
except ImportError as exc:
    OpenAI = None  # type: ignore[assignment]
    _OPENAI_IMPORT_ERROR = exc
else:
    _OPENAI_IMPORT_ERROR = None

from core.config.settings import Settings, settings

LOGGER = logging.getLogger(__name__)
EXPECTED_REASONING_MODEL = "deepseek-r1-distill-llama-70b"


class ReasoningEngineError(RuntimeError):
    """Base error for reasoning-engine failures."""


class ReasoningResponseError(ReasoningEngineError):
    """Raised when the model response cannot be parsed as JSON."""


def _env_float(name: str, default):
    """读取浮点环境变量；'0'/'none'/'unlimited'/非法 -> None（不限制）；空 -> default。"""
    raw = os.getenv(name, "").strip()
    if raw == "":
        return default
    if raw.lower() in {"0", "none", "null", "unlimited"}:
        return None
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value > 0 else None


def _llm_timeout():
    """模型调用超时：LLM_TIMEOUT_SECONDS，默认3600（单次调用一小时=实际不限制），0=真无限。"""
    return _env_float("LLM_TIMEOUT_SECONDS", 3600.0)


def _llm_max_tokens():
    """模型输出上限：LLM_MAX_TOKENS，默认16384（本地模型实际不限输出）。"""
    raw = os.getenv("LLM_MAX_TOKENS", "").strip()
    try:
        value = int(raw)
        return value if value > 0 else 16384
    except ValueError:
        return 16384


class ReasoningEngine:
    """Call the configured OpenAI-compatible reasoning endpoint."""

    def __init__(self, runtime_settings: Settings = settings) -> None:
        self.settings = runtime_settings
        configured_model = (self.settings.llm_model or "").strip()
        if configured_model != EXPECTED_REASONING_MODEL:
            message = (
                "Unsupported reasoning model: "
                f"{configured_model!r}. PSV Trade OS 9.4.1 requires "
                f"{EXPECTED_REASONING_MODEL!r}."
            )
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        base_url = (self.settings.llm_base_url or "").strip()
        if not base_url:
            message = "LLM_BASE_URL must not be empty"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        api_key = (self.settings.llm_api_key or "").strip()
        if not api_key:
            LOGGER.warning(
                "LLM_API_KEY is empty; using a local-compatible runtime credential"
            )
            api_key = "local-runtime"

        if OpenAI is None:
            message = (
                "The installed openai package does not provide the OpenAI client. "
                "PSV Trade OS 9.4.1 requires openai>=1.50,<2.0. "
                "Run `python -m pip install -r requirements.txt` in a fresh virtual environment."
            )
            if _OPENAI_IMPORT_ERROR is not None:
                message += f" Import detail: {_OPENAI_IMPORT_ERROR}"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        try:
            self._client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=_llm_timeout(),   # 默认3600s/次（=不限制）；LLM_TIMEOUT_SECONDS=0 设真正无限
                max_retries=1,
            )
        except Exception as exc:
            LOGGER.exception("Failed to initialize OpenAI-compatible reasoning client")
            raise ReasoningEngineError(
                f"Failed to initialize reasoning client: {exc}"
            ) from exc

    @staticmethod
    def _salvage_truncated_json(text):
        """截断JSON抢救：从末尾向前在值边界截断，自动补齐未闭合括号后解析。

        推理模型输出超长被截断时（多发生在长字符串/长数组中间），
        前面的字段通常完整可用——比整体丢弃好得多。
        """
        decoder = json.JSONDecoder()
        for cut in range(len(text), 0, -1):
            if text[cut - 1] not in '"}]':
                continue
            prefix = text[:cut]
            stack: list = []
            in_str = False
            esc = False
            for ch in prefix:
                if in_str:
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        in_str = False
                    continue
                if ch == '"':
                    in_str = True
                elif ch in "{[":
                    stack.append(ch)
                elif ch in "}]":
                    if stack and {"}": "{", "]": "["}[ch] == stack[-1]:
                        stack.pop()
            if in_str:
                continue  # 停在字符串中间，不是有效边界
            closers = "".join("}" if c == "{" else "]" for c in reversed(stack))
            try:
                obj, _ = decoder.raw_decode(prefix + closers)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                continue
        return None

    def review(
        self,
        prompt: str,
        system: str = "",
        response_schema: dict[str, Any] | None = None,
        max_tokens: int | None = None,
    ) -> dict[str, Any]:
        """Send a reasoning request and return its JSON response."""
        normalized_prompt = prompt.strip() if isinstance(prompt, str) else ""
        normalized_system = system.strip() if isinstance(system, str) else ""
        if not normalized_prompt:
            message = "Reasoning prompt must not be empty"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        messages: list[dict[str, str]] = []
        if normalized_system:
            messages.append({"role": "system", "content": normalized_system})
        messages.append({"role": "user", "content": normalized_prompt})

        effective_max_tokens = max_tokens if max_tokens is not None else _llm_max_tokens()
        if isinstance(effective_max_tokens, bool) or not isinstance(effective_max_tokens, int) or effective_max_tokens <= 0:
            raise ReasoningEngineError("max_tokens must be a positive integer")

        try:
            request_kwargs: dict[str, Any] = {
                "model": self.settings.llm_model,
                "messages": messages,
                "temperature": 0.0,
                "max_tokens": effective_max_tokens,
            }
            if response_schema is not None:
                request_kwargs["response_format"] = {
                    "type": "json_object",
                    "schema": response_schema,
                }
            else:
                request_kwargs["response_format"] = {"type": "json_object"}
            response = self._client.chat.completions.create(**request_kwargs)
        except Exception as exc:
            LOGGER.exception("Reasoning API request failed")
            raise ReasoningEngineError(
                f"Reasoning API request failed: {exc}"
            ) from exc

        try:
            content = response.choices[0].message.content
        except (AttributeError, IndexError, TypeError) as exc:
            LOGGER.exception("Reasoning API returned an invalid response structure")
            raise ReasoningResponseError(
                f"Invalid reasoning response structure: {exc}"
            ) from exc

        if not isinstance(content, str):
            message = "Reasoning API returned non-text content"
            LOGGER.error(message)
            raise ReasoningResponseError(message)
        if not content.strip():
            message = "LLM returned empty message.content"
            LOGGER.error(message)
            raise ReasoningResponseError(message)

        normalized_content = self._normalize_json_content(content)
        parsed = None
        try:
            parsed = json.loads(normalized_content)
        except json.JSONDecodeError:
            # 推理模型输出超长被截断时，抢救最后一个完整字段对（截断多发生在
            # 长数组/长字符串中间，前面的字段完整可用，比整体丢弃好得多）。
            parsed = self._salvage_truncated_json(normalized_content)
            if parsed is None:
                LOGGER.error("Reasoning model returned invalid JSON: %s", content)
                raise ReasoningResponseError("LLM returned unparseable JSON")
        if parsed is None:
            LOGGER.error("Reasoning model returned invalid JSON: %s", content)
            raise ReasoningResponseError(f"LLM returned invalid JSON: {exc}") from exc

        if not isinstance(parsed, dict):
            message = "Reasoning model JSON response must be an object"
            LOGGER.error("%s: %r", message, parsed)
            raise ReasoningResponseError(message)
        return parsed

    @staticmethod
    def _normalize_json_content(content: str) -> str:
        """Normalize reasoning-model output: strip <think> blocks and code fences."""
        normalized = content.strip()
        # deepseek-r1 系推理模型可能在 JSON 前输出 <think>...</think> 推理段。
        if "<think>" in normalized:
            end = normalized.find("</think>")
            if end != -1:
                normalized = normalized[end + len("</think>"):].strip()
        if normalized.startswith("```json") and normalized.endswith("```"):
            normalized = normalized[len("```json") :].strip()
            normalized = normalized[:-len("```")].strip()
        elif normalized.startswith("```") and normalized.endswith("```"):
            normalized = normalized[len("```") :].strip()
            normalized = normalized[:-len("```")].strip()
        # 兜底：若 JSON 对象外包裹了解释性文字，截取最外层 {} 区间。
        if not normalized.startswith("{"):
            start = normalized.find("{")
            end = normalized.rfind("}")
            if start != -1 and end > start:
                normalized = normalized[start:end + 1]
        return normalized
