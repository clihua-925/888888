"""SQLite persistence for PSV Trade OS 9.4.1."""

from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


def _retry_busy(fn):
    """Retry sqlite 'database is locked' with short backoff (local single-file DB + concurrent readers)."""
    def wrapper(*args, **kwargs):
        last = None
        for attempt in range(4):
            try:
                return fn(*args, **kwargs)
            except sqlite3.OperationalError as exc:
                last = exc
                if "locked" in str(exc).lower() and attempt < 3:
                    time.sleep(0.4 * (attempt + 1))
                    continue
                raise
        raise last
    return wrapper


class Database:
    """SQLite database gateway for task and trade persistence."""

    def __init__(self, database_path: str | Path) -> None:
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=60)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA busy_timeout = 60000")
        return connection

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)

    def initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id TEXT PRIMARY KEY, workflow_id TEXT NOT NULL, status TEXT NOT NULL,
                state_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS task_events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL,
                event_type TEXT NOT NULL, node_id TEXT, status TEXT, payload TEXT,
                created_at TEXT NOT NULL, FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_task_events_task_id ON task_events(task_id);
            CREATE TABLE IF NOT EXISTS trade_entities (
                entity_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, canonical_name TEXT NOT NULL,
                role TEXT, country TEXT, source TEXT, metadata TEXT,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_trade_entities_task_id ON trade_entities(task_id);
            CREATE TABLE IF NOT EXISTS trade_edges (
                edge_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, source_entity_id TEXT NOT NULL,
                target_entity_id TEXT NOT NULL, relation_type TEXT NOT NULL, confidence REAL,
                evidence_ids TEXT, metadata TEXT,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_trade_edges_task_id ON trade_edges(task_id);
            CREATE TABLE IF NOT EXISTS trade_raw_pages (
                raw_id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                query TEXT NOT NULL,
                page_number INTEGER NOT NULL DEFAULT 1,
                url TEXT NOT NULL,
                title TEXT NOT NULL DEFAULT '',
                html TEXT NOT NULL,
                text TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                source TEXT NOT NULL DEFAULT 'importyeti_browser',
                screenshot TEXT NOT NULL DEFAULT '',
                metadata TEXT NOT NULL DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS trade_extracted_entities (
                extraction_id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                company_name TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT '',
                country TEXT NOT NULL DEFAULT '',
                address TEXT NOT NULL DEFAULT '',
                product TEXT NOT NULL DEFAULT '',
                shipment_count INTEGER NOT NULL DEFAULT 0,
                confidence REAL NOT NULL DEFAULT 0,
                evidence TEXT NOT NULL DEFAULT '',
                source_url TEXT NOT NULL DEFAULT '',
                raw_page_id INTEGER NOT NULL DEFAULT 0,
                raw_ids TEXT NOT NULL DEFAULT '[]',
                created_time TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_te_ext_task ON trade_extracted_entities(task_id);
            CREATE TABLE IF NOT EXISTS trade_extracted_edges (
                extraction_edge_id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                supplier TEXT NOT NULL,
                buyer TEXT NOT NULL,
                product TEXT NOT NULL DEFAULT '',
                evidence TEXT NOT NULL,
                source_url TEXT NOT NULL DEFAULT '',
                raw_page_id INTEGER NOT NULL DEFAULT 0,
                source_entity_extraction_id TEXT NOT NULL DEFAULT '',
                confidence REAL NOT NULL DEFAULT 0,
                created_time TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_tedge_ext_task ON trade_extracted_edges(task_id);
            CREATE INDEX IF NOT EXISTS ix_raw_pages_task ON trade_raw_pages(task_id);
            CREATE INDEX IF NOT EXISTS ix_raw_pages_query ON trade_raw_pages(query);
            CREATE TABLE IF NOT EXISTS evidence (
                evidence_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, entity_name TEXT NOT NULL,
                evidence_type TEXT, source TEXT, shipments TEXT, verified INTEGER NOT NULL DEFAULT 0,
                evidence_json TEXT, created_at TEXT NOT NULL,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_evidence_task_id ON evidence(task_id);
            CREATE TABLE IF NOT EXISTS outreach_letters (
                letter_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, lead_node_id TEXT,
                entity_name TEXT NOT NULL, subject TEXT, body TEXT,
                review_status TEXT, composed_by TEXT, language TEXT,
                send_status TEXT, send_reason TEXT, sent_at TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_outreach_letters_task_id ON outreach_letters(task_id);
            """)

    @_retry_busy
    def create_task(self, task_id: str, workflow_id: str, state: Mapping[str, Any], status: str) -> dict[str, Any]:
        timestamp = self._now()
        with self._connect() as connection:
            connection.execute("""INSERT INTO tasks(task_id,workflow_id,status,state_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?)""", (task_id, workflow_id, status, self._json(dict(state)), timestamp, timestamp))
        return self.get_task(task_id)

    @_retry_busy
    def update_task(self, task_id: str, state: Mapping[str, Any], status: str) -> dict[str, Any]:
        with self._connect() as connection:
            cursor = connection.execute("""UPDATE tasks SET status=?,state_json=?,updated_at=? WHERE task_id=?""",
                (status, self._json(dict(state)), self._now(), task_id))
            if cursor.rowcount == 0:
                raise KeyError(f"Task not found: {task_id}")
        return self.get_task(task_id)

    def get_tasks_by_status(self, statuses: tuple[str, ...]) -> list[dict[str, Any]]:
        """Return persisted tasks whose lifecycle status requires scheduler recovery."""
        normalized = tuple(str(status).strip() for status in statuses if str(status).strip())
        if not normalized:
            return []
        bindings = ",".join("?" for _ in normalized)
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT task_id,workflow_id,status,state_json,created_at,updated_at "
                f"FROM tasks WHERE status IN ({bindings}) ORDER BY created_at ASC",
                normalized,
            ).fetchall()
        tasks: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["state"] = json.loads(item.pop("state_json"))
            tasks.append(item)
        return tasks

    def list_trade_entities(self, limit: int = 500, role: str = "") -> list:
        sql = "SELECT task_id, entity_id, canonical_name, role, country, source, metadata FROM trade_entities"
        args: list = []
        if role:
            sql += " WHERE role=?"
            args.append(role)
        sql += " ORDER BY rowid DESC LIMIT ?"
        args.append(int(limit))
        with self._connect() as connection:
            return [dict(row) for row in connection.execute(sql, args).fetchall()]

    def list_trade_relationships(self, limit: int = 500) -> list:
        sql = (
            "SELECT r.task_id, r.edge_id, r.relation_type, r.confidence, "
            "s.canonical_name AS source_name, t.canonical_name AS target_name "
            "FROM trade_edges r "
            "LEFT JOIN trade_entities s ON s.task_id = r.task_id AND s.entity_id = r.source_entity_id "
            "LEFT JOIN trade_entities t ON t.task_id = r.task_id AND t.entity_id = r.target_entity_id "
            "ORDER BY r.rowid DESC LIMIT ?"
        )
        with self._connect() as connection:
            return [dict(row) for row in connection.execute(sql, (int(limit),)).fetchall()]

    def list_outreach_letters(self, limit: int = 200) -> list:
        sql = (
            "SELECT task_id, letter_id, entity_name, subject, review_status, composed_by, "
            "send_status, language, created_at FROM outreach_letters "
            "ORDER BY rowid DESC LIMIT ?"
        )
        with self._connect() as connection:
            return [dict(row) for row in connection.execute(sql, (int(limit),)).fetchall()]

    @_retry_busy
    def get_task(self, task_id: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute("""SELECT task_id,workflow_id,status,state_json,created_at,updated_at
                FROM tasks WHERE task_id=?""", (task_id,)).fetchone()
        if row is None:
            raise KeyError(f"Task not found: {task_id}")
        result = dict(row)
        result["state"] = json.loads(result.pop("state_json"))
        return result

    @_retry_busy
    def add_event(self, task_id: str, event_type: str, node_id: str | None = None,
                  status: str | None = None, payload: Mapping[str, Any] | None = None) -> int:
        with self._connect() as connection:
            exists = connection.execute("SELECT 1 FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            cursor = connection.execute("""INSERT INTO task_events(task_id,event_type,node_id,status,payload,created_at)
                VALUES(?,?,?,?,?,?)""", (task_id, event_type, node_id, status, self._json(payload or {}), self._now()))
            return int(cursor.lastrowid)

    @_retry_busy
    def get_task_events(self, task_id: str) -> list[dict[str, Any]]:
        """Return all persisted events for a task in chronological order."""
        with self._connect() as connection:
            exists = connection.execute(
                "SELECT 1 FROM tasks WHERE task_id=?", (task_id,)
            ).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            rows = connection.execute(
                """SELECT event_id,event_type,node_id,status,payload,created_at
                   FROM task_events
                   WHERE task_id=?
                   ORDER BY created_at ASC, event_id ASC""",
                (task_id,),
            ).fetchall()
        events: list[dict[str, Any]] = []
        for row in rows:
            event = dict(row)
            raw_payload = event.get("payload")
            if isinstance(raw_payload, str):
                try:
                    event["payload"] = json.loads(raw_payload)
                except json.JSONDecodeError:
                    event["payload"] = {"raw": raw_payload}
            elif raw_payload is None:
                event["payload"] = {}
            events.append(event)
        return events

    @_retry_busy
    def _migrate_raw_pages(self) -> None:
        try:
            with self._connect() as connection:
                connection.execute("ALTER TABLE trade_raw_pages ADD COLUMN screenshot TEXT NOT NULL DEFAULT ''")
        except Exception:
            pass
        try:
            with self._connect() as connection:
                connection.execute("ALTER TABLE trade_raw_pages RENAME COLUMN created_at TO timestamp")
        except Exception:
            pass

    @_retry_busy
    def save_raw_page(self, task_id: str, query: str, page_number: int, url: str,
                      html: str, text: str, title: str = "",
                      source: str = "importyeti_browser", metadata: Mapping[str, Any] | None = None,
                      created_at: str | None = None, screenshot: str = "",
                      timestamp: str | None = None) -> int:
        """原始页面落库（ELT 采集层）：页面上有什么存什么，提炼层事后加工。"""
        import time as _time
        ts = created_at or timestamp or _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())
        self._migrate_raw_pages()
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO trade_raw_pages (task_id, query, page_number, url, title, html, text, timestamp, source, screenshot, metadata) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (task_id, query, int(page_number), str(url), str(title),
                 str(html), str(text), ts, source, str(screenshot), self._json(dict(metadata or {}))))
            return int(cursor.lastrowid or 0)

    @_retry_busy
    def get_raw_pages(self, task_id: str | None = None, query: str | None = None,
                      limit: int = 5000) -> list[dict[str, Any]]:
        """读取原始页面（提炼层入口）：可按 task / query 过滤，旧到新。"""
        sql = "SELECT raw_id, task_id, query, page_number, url, title, html, text, timestamp, source, screenshot, metadata FROM trade_raw_pages"
        cond, params = [], []
        if task_id:
            cond.append("task_id = ?"); params.append(task_id)
        if query:
            cond.append("query = ?"); params.append(query)
        if cond:
            sql += " WHERE " + " AND ".join(cond)
        sql += " ORDER BY raw_id ASC LIMIT ?"
        params.append(int(limit))
        with self._connect() as connection:
            rows = connection.execute(sql, tuple(params)).fetchall()
        return [{
            "raw_id": r[0], "task_id": r[1], "query": r[2], "page_number": r[3],
            "url": r[4], "title": r[5], "html": r[6], "text": r[7],
            "timestamp": r[8], "source": r[9], "screenshot": r[10],
            "metadata": json.loads(r[11] or "{}"),
        } for r in rows]

    def _migrate_extracted(self) -> None:
        for stmt in (
            "ALTER TABLE trade_extracted_entities RENAME COLUMN source_raw_page_id TO raw_page_id",
            "ALTER TABLE trade_extracted_edges ADD COLUMN source_url TEXT NOT NULL DEFAULT ''",
        ):
            try:
                with self._connect() as connection:
                    connection.execute(stmt)
            except Exception:
                pass

    @_retry_busy
    def save_trade_entity(self, task_id: str, entity: Mapping[str, Any],
                          source_raw_page_id: int = 0, created_time: str | None = None) -> str:
        """Silver 实体落库（幂等 REPLACE）。entity_id 确定性：同 task+公司名 恒定。"""
        import time as _time
        name = str(entity.get("company_name") or entity.get("name") or "").strip()
        if not name:
            return ""
        self._migrate_extracted()
        eid = f"TX_{abs(hash((task_id + '|' + name).lower())) % 10**8:08d}"
        ts = created_time or _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())
        with self._connect() as connection:
            connection.execute(
                "INSERT OR REPLACE INTO trade_extracted_entities (extraction_id, task_id, company_name, role, country, address, product, shipment_count, confidence, evidence, source_url, raw_page_id, raw_ids, created_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (eid, task_id, name, str(entity.get("role") or ""),
                 str(entity.get("country") or ""), str(entity.get("address") or ""),
                 str(entity.get("product") or ""), int(entity.get("shipments") or entity.get("shipment_count") or 0),
                 float(entity.get("confidence") or 0), str(entity.get("evidence") or ""),
                 str(entity.get("source_url") or entity.get("url") or ""), int(source_raw_page_id or 0),
                 self._json(list(entity.get("raw_ids") or [])), ts))
        return eid

    @_retry_busy
    def save_trade_edge(self, task_id: str, supplier_id: str, buyer_id: str, product: str,
                        evidence: str, source_url: str = "", raw_page_id: int = 0,
                        source_entity_id: str = "",
                        confidence: float = 0.0, created_time: str | None = None) -> str:
        """Gold 关系落库（幂等 REPLACE）。调用方必须保证 evidence 非空——禁止按名字猜关系。"""
        import time as _time
        if not supplier_id or not buyer_id or not str(evidence or "").strip():
            return ""
        self._migrate_extracted()
        eid = f"XE_{abs(hash((task_id + '|' + supplier_id + '|' + buyer_id).lower())) % 10**8:08d}"
        ts = created_time or _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())
        with self._connect() as connection:
            connection.execute(
                "INSERT OR REPLACE INTO trade_extracted_edges (extraction_edge_id, task_id, supplier, buyer, product, evidence, source_url, raw_page_id, source_entity_extraction_id, confidence, created_time) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (eid, task_id, supplier_id, buyer_id, str(product or ""),
                 str(evidence or ""), str(source_url or ""), int(raw_page_id or 0),
                 str(source_entity_id or ""), float(confidence or 0), ts))
        return eid

    @_retry_busy
    def get_trade_entities(self, task_id: str | None = None, limit: int = 5000) -> list[dict[str, Any]]:
        sql = "SELECT extraction_id, task_id, company_name, role, country, address, product, shipment_count, confidence, evidence, source_url, raw_page_id, raw_ids, created_time FROM trade_extracted_entities"
        params: list = []
        if task_id:
            sql += " WHERE task_id = ?"
            params.append(task_id)
        sql += " ORDER BY shipment_count DESC LIMIT ?"
        params.append(int(limit))
        with self._connect() as connection:
            rows = connection.execute(sql, tuple(params)).fetchall()
        return [{"extraction_id": r[0], "task_id": r[1], "company_name": r[2], "role": r[3],
                 "country": r[4], "address": r[5], "product": r[6], "shipment_count": r[7],
                 "confidence": r[8], "evidence": r[9], "source_url": r[10],
                 "raw_page_id": r[11], "raw_ids": json.loads(r[12] or "[]"),
                 "created_time": r[13]} for r in rows]

    @_retry_busy
    def get_trade_edges(self, task_id: str | None = None, limit: int = 5000) -> list[dict[str, Any]]:
        sql = "SELECT extraction_edge_id, task_id, supplier, buyer, product, evidence, source_url, raw_page_id, source_entity_extraction_id, confidence, created_time FROM trade_extracted_edges"
        params: list = []
        if task_id:
            sql += " WHERE task_id = ?"
            params.append(task_id)
        sql += " ORDER BY extraction_edge_id ASC LIMIT ?"
        params.append(int(limit))
        with self._connect() as connection:
            rows = connection.execute(sql, tuple(params)).fetchall()
        return [{"extraction_edge_id": r[0], "task_id": r[1], "supplier": r[2], "buyer": r[3],
                 "product": r[4], "evidence": r[5], "source_url": r[6], "raw_page_id": r[7],
                 "source_entity_extraction_id": r[8], "confidence": r[9], "created_time": r[10]} for r in rows]

    def _check_referential_consistency(self, task_id: str, trade_entities: list[Mapping[str, Any]],
                                       trade_edges: list[Mapping[str, Any]], evidence: list[Mapping[str, Any]]) -> None:
        """应用层提交前一致性检查（不改 schema）：evidence/edge 引用必须在本次提交或库内可解析。"""
        entity_ids = {str(e.get("entity_id")) for e in trade_entities if e.get("entity_id")}
        evidence_ids = {str(v.get("evidence_id")) for v in evidence if v.get("evidence_id")}
        for entity in trade_entities:
            if not str(entity.get("canonical_name") or "").strip():
                raise ValueError(f"entity canonical_name empty: {entity.get('entity_id')}")
        for item in evidence:
            if not str(item.get("entity_name") or "").strip():
                raise ValueError(f"evidence entity_name empty: {item.get('evidence_id')}")
        with self._connect() as connection:
            known_evid = {str(r[0]) for r in connection.execute("SELECT evidence_id FROM evidence WHERE task_id=?", (task_id,)).fetchall()}
            known_ent = {str(r[0]) for r in connection.execute("SELECT entity_id FROM trade_entities WHERE task_id=?", (task_id,)).fetchall()}
        for edge in trade_edges:
            for ref in (edge.get("evidence_ids") or []):
                if str(ref) not in evidence_ids and str(ref) not in known_evid:
                    raise ValueError(f"edge {edge.get('edge_id')} references unknown evidence {ref}")
            for key in ("source_entity_id", "target_entity_id"):
                ref = str(edge.get(key) or "")
                if ref and ref not in entity_ids and ref not in known_ent:
                    raise ValueError(f"edge {edge.get('edge_id')} references unknown entity {ref} ({key})")

    def commit_trade_data(self, task_id: str, trade_entities: list[Mapping[str, Any]],
                          trade_edges: list[Mapping[str, Any]], evidence: list[Mapping[str, Any]]) -> dict[str, int]:
        timestamp = self._now()
        with self._connect() as connection:
            exists = connection.execute("SELECT 1 FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            self._check_referential_consistency(task_id, trade_entities, trade_edges, evidence)
            counts = {"trade_entities": 0, "trade_edges": 0, "evidence": 0}
            for entity in trade_entities:
                connection.execute("""INSERT OR REPLACE INTO trade_entities
                    (entity_id,task_id,canonical_name,role,country,source,metadata) VALUES(?,?,?,?,?,?,?)""",
                    (str(entity["entity_id"]), task_id, str(entity["canonical_name"]), entity.get("role"),
                     entity.get("country"), entity.get("source"), self._json(entity.get("metadata", {}))))
                counts["trade_entities"] += 1
            for edge in trade_edges:
                connection.execute("""INSERT OR REPLACE INTO trade_edges
                    (edge_id,task_id,source_entity_id,target_entity_id,relation_type,confidence,evidence_ids,metadata)
                    VALUES(?,?,?,?,?,?,?,?)""", (str(edge["edge_id"]), task_id, str(edge["source_entity_id"]),
                    str(edge["target_entity_id"]), str(edge["relation_type"]), edge.get("confidence"),
                    self._json(edge.get("evidence_ids", [])), self._json(edge.get("metadata", {}))))
                counts["trade_edges"] += 1
            for item in evidence:
                connection.execute("""INSERT OR REPLACE INTO evidence
                    (evidence_id,task_id,entity_name,evidence_type,source,shipments,verified,evidence_json,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?)""", (str(item["evidence_id"]), task_id, str(item["entity_name"]),
                    item.get("evidence_type"), item.get("source"), self._json(item.get("shipments", [])),
                    1 if bool(item.get("verified", False)) else 0, self._json(item.get("evidence_json", {})),
                    item.get("created_at", timestamp)))
                counts["evidence"] += 1
        return counts
    @_retry_busy
    def commit_outreach_letters(self, task_id: str, letters: list) -> dict:
        """Atomically commit development letters and return counts."""
        timestamp = self._now()
        with self._connect() as connection:
            exists = connection.execute("SELECT 1 FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            # 轻量迁移：旧库补 send_status/send_reason/sent_at 列
            cols = {row[1] for row in connection.execute("PRAGMA table_info(outreach_letters)")}
            for col, decl in (("send_status", "TEXT"), ("send_reason", "TEXT"), ("sent_at", "TEXT")):
                if col not in cols:
                    connection.execute(f"ALTER TABLE outreach_letters ADD COLUMN {col} {decl}")
            for letter in letters:
                connection.execute("""INSERT OR REPLACE INTO outreach_letters
                    (letter_id,task_id,lead_node_id,entity_name,subject,body,review_status,composed_by,language,send_status,send_reason,sent_at,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (str(letter.get("letter_id")), task_id, str(letter.get("lead_node_id", "")),
                     str(letter.get("entity_name", "")), letter.get("subject"), letter.get("body"),
                     letter.get("review_status"), letter.get("composed_by"), letter.get("language", "en"),
                     letter.get("send_status"), letter.get("send_reason"), letter.get("sent_at"), timestamp))
        return {"letter_count": len(letters), "status": "committed"}


