"""Flask Web API and WebUI for PSV Trade OS 9.4.1."""

from .app import app, create_app

__all__ = ["app", "create_app"]
