"""Shared task state definitions for PSV Trade OS 9.4.1."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, TypedDict

STATUS_PENDING = "PENDING"
STATUS_RUNNING = "RUNNING"
STATUS_COMPLETED = "COMPLETED"
STATUS_FAILED = "FAILED"
STATUS_PAUSED = "PAUSED"
STATUS_TIMEOUT = "TASK_TIMEOUT"

STATUS_VALUES = frozenset({STATUS_PENDING, STATUS_RUNNING, STATUS_COMPLETED,
                            STATUS_FAILED, STATUS_PAUSED, STATUS_TIMEOUT})

TaskStatus = Literal["PENDING", "RUNNING", "COMPLETED", "FAILED", "PAUSED", "TASK_TIMEOUT"]


class TaskState(TypedDict, total=True):
    """Canonical shared state crossing business nodes."""
    mission: Dict[str, Any]
    product_definition: Dict[str, Any]
    trade_nodes: List[Dict[str, Any]]
    fragments: List[Dict[str, Any]]
    search_queries: List[str]          # TRADE_STRATEGY 产出 -> CUSTOMS_NODE_COLLECTION 消费
    evidence_pool: List[Dict[str, Any]]
    entities: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]
    decisions: List[Dict[str, Any]]
    history: List[Dict[str, Any]]
    orchestration: Dict[str, Any]
    error: Dict[str, Any]
    node_reports: Dict[str, Dict[str, Any]]
    status: TaskStatus
    task_id: str
    workflow_id: str
    workflow_version: str
