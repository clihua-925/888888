"""Provider interfaces: the only dependency channel Business may use."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class DecisionProvider(ABC):
    """AI decision interface available to business nodes."""

    @abstractmethod
    def decide(self, state: Any, decision_type: str, prompt: str, context: Any) -> dict:
        """Return a structured decision record."""
        ...


class DataProvider(ABC):
    """Data write interface available to business nodes."""

    @abstractmethod
    def commit_trade_data(self, task_id: str, entities: Any, edges: Any, evidence: Any) -> dict[str, int]:
        """Atomically commit trade data and return per-table counts."""
        ...

    def commit_outreach_letters(self, task_id: str, letters: Any) -> dict[str, int]:
        """Commit development letters; providers without letter storage may override."""
        raise RuntimeError("outreach letter storage is not supported by this provider")


class MailSender(ABC):
    """Optional outbound mail channel for development letters (auto-send feature).

    Business workflows call this through core.contracts.context.get_mail_sender();
    the concrete sender (e.g. Playwright/Outlook) is bound by the orchestration
    layer, keeping business fully decoupled from delivery infrastructure.
    """

    @abstractmethod
    def send_letter(self, letter: dict) -> dict:
        """Send one reviewed letter; returns {"status": "sent"|"skipped"|"failed", ...}."""
        ...
