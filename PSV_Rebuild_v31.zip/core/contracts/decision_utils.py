"""决策返回值工具：统一"包装器/内层"双兼容解包约定。

decide() 返回 {"decision": {...内层判断对象...}, confidence, rationale, metadata}
包装器；部分路径会内层直返。所有消费方必须经 unwrap_decision 取值，
禁止直接 .get("product_name") 等——历史上两次生产事故都源于手写解包遗漏。
"""

from typing import Any, Mapping


def unwrap_decision(value: Any) -> Mapping:
    """返回内层判断对象；无包装器时原样返回；非 Mapping 返回空映射。"""
    if isinstance(value, Mapping):
        inner = value.get("decision")
        if isinstance(inner, Mapping):
            return inner
        return value
    return {}
