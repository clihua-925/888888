"""Shared node contract data definitions for PSV Trade OS 9.4.1."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ContractDefinition:
    """Formal data contract between a node and shared state."""
    node_id: str
    input_keys: tuple[str, ...] = ()
    output_keys: tuple[str, ...] = ()
    responsibility: str = ""
    success: str = ""
    failure: str = ""
    blocking: bool = True
    side_effects: tuple[str, ...] = ()
    database_write_authority: bool = False

    def __post_init__(self) -> None:
        if not self.node_id.strip():
            raise ValueError("node_id must not be empty")
        if not self.responsibility.strip():
            raise ValueError(f"responsibility is required for {self.node_id}")

    def validate_input(self, state: Mapping[str, Any]) -> None:
        missing = [key for key in self.input_keys if key not in state]
        if missing:
            raise ValueError(f"{self.node_id} missing input keys: {', '.join(missing)}")

    def validate_output(self, state: Mapping[str, Any]) -> None:
        missing = [key for key in self.output_keys if key not in state]
        if missing:
            raise ValueError(f"{self.node_id} missing output keys: {', '.join(missing)}")


NodeContract = ContractDefinition
