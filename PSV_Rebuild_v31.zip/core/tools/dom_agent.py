"""DOM Agent：让本地推理模型像人一样操作网页。

职责边界：只负责"看页面 → 决定下一个动作 → 执行"；采集什么由调用方决定。
定位约定：所有可交互元素先打上 data-domagent-id 属性，之后一律用该属性
选择器定位，不用 nth-of-type（页面结构变化也不失效）。
"""

from __future__ import annotations

import json
import time
from typing import Any, Mapping

from core.model.reasoning import ReasoningEngine, ReasoningEngineError
from core.contracts.decision_utils import unwrap_decision
from core.tools.dom_prompts import (
    DOM_ACTION_PROMPT,
    DOM_ERROR_PROMPT,
    DOM_RETRY_PROMPT,
    DOM_SYSTEM_PROMPT,
    VALID_ACTIONS,
)

MAX_ELEMENTS = 50
MAX_LLM_RETRIES = 3
DEFAULT_MAX_STEPS = 10


def _log(message: str) -> None:
    print(f"[DOMAgent] {message}", flush=True)

def page_snapshot(page, html_limit: int = 200_000, text_limit: int = 100_000) -> dict:
    """页面快照：完整 HTML + visible_text + URL（提取阶段用，无 selector 依赖）。"""
    try:
        html = page.content() or ""
    except Exception:
        html = ""
    try:
        text = page.evaluate("() => document.body ? document.body.innerText : ''") or ""
    except Exception:
        text = ""
    try:
        url = page.url or ""
    except Exception:
        url = ""
    try:
        title = page.title() or ""
    except Exception:
        title = ""
    return {
        "html": html[:html_limit],
        "visible_text": text[:text_limit],
        "url": url,
        "title": title,
        "html_len": len(html),
        "text_len": len(text),
    }



class DOMAgent:
    """基于本地 LLM 的页面操作代理。

    extract_interactive_elements: 打标并盘点可见可交互元素
    decide_next_action:           调 ReasoningEngine 决策下一步（失败重试3次）
    execute_action:               执行决策（click/type/press/wait/extract）
    run_goal:                     主循环，直到 done / 步数耗尽 / 不可恢复错误
    """

    def __init__(self, engine: ReasoningEngine | None = None) -> None:
        self._engine = engine or ReasoningEngine()
        self._step = 0

    # ------------------------------------------------------------------
    # 1. 元素盘点
    # ------------------------------------------------------------------
    def extract_interactive_elements(self, page: Any) -> list[dict[str, Any]]:
        """提取当前页面可见的可交互元素（input/button/a/textarea/select）。

        每个元素被打上 data-domagent-id="da-<n>"，返回的 dict 带同样的 id，
        后续 execute_action 用 [data-domagent-id="da-<n>"] 定位。
        返回字段: id / tag / type / placeholder / text / href / visible
        """
        script = """
() => {
  const tags = ["input", "button", "a", "textarea", "select"];
  const out = [];
  let seq = 0;
  for (const tag of tags) {
    for (const el of document.querySelectorAll(tag)) {
      if (out.length >= 50) break;
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      const visible = (
        style.display !== "none" &&
        style.visibility !== "hidden" &&
        Number(style.opacity) > 0 &&
        rect.width > 0 && rect.height > 0
      );
      if (!visible) continue;
      const id = "da-" + (seq++);
      el.setAttribute("data-domagent-id", id);
      const text = (el.innerText || el.value || el.getAttribute("aria-label") || "").trim();
      out.push({
        id: id,
        tag: el.tagName.toLowerCase(),
        type: (el.getAttribute("type") || "").toLowerCase(),
        placeholder: (el.getAttribute("placeholder") || "").trim(),
        text: text.slice(0, 80),
        href: el.tagName.toLowerCase() === "a" ? (el.getAttribute("href") || "") : "",
        visible: true,
      });
    }
    if (out.length >= 50) break;
  }
  return out;
}
"""
        try:
            raw = page.evaluate(script)
        except Exception as exc:  # 页面导航中/上下文失效
            _log(f"extract failed: {type(exc).__name__}: {exc}")
            return []
        elements = [dict(item) for item in (raw or []) if isinstance(item, dict)]
        for item in elements:
            item.setdefault("id", "")
            item.setdefault("tag", "")
            item.setdefault("type", "")
            item.setdefault("placeholder", "")
            item.setdefault("text", "")
            item.setdefault("href", "")
            item.setdefault("visible", True)
        if len(elements) > MAX_ELEMENTS:
            elements = elements[:MAX_ELEMENTS]
        _log(f"extract elements: {len(elements)} visible interactive")
        return elements

    # ------------------------------------------------------------------
    # 2. 决策
    # ------------------------------------------------------------------
    def _validate_action(
        self, action: Any, elements: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """校验并规范化模型输出；不合法返回 None。"""
        action = unwrap_decision(action)
        if not isinstance(action, Mapping) or "action" not in action:
            return None
        name = str(action.get("action", "")).strip().lower()
        if name not in VALID_ACTIONS:
            return None
        valid_ids = {str(el.get("id", "")) for el in elements}
        normalized: dict[str, Any] = {"action": name, "reason": str(action.get("reason", ""))[:200]}
        if name in {"click", "type"}:
            element_id = str(action.get("id", ""))
            if element_id not in valid_ids:
                return None
            normalized["id"] = element_id
        if name == "type":
            normalized["value"] = str(action.get("value", ""))
            if not normalized["value"]:
                return None
        if name in {"press", "wait"}:
            normalized["value"] = str(action.get("value", ""))
        if name == "press" and not normalized["value"]:
            normalized["value"] = "Enter"
        if name == "wait" and not normalized["value"]:
            normalized["value"] = "2000"
        return normalized

    def decide_next_action(
        self,
        elements: list[dict[str, Any]],
        goal: str,
        history: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """调用本地模型决策下一步。3 次失败后返回 {"done": False, "error": "llm_failed"}。"""
        elements_json = json.dumps(elements, ensure_ascii=False)[:4000]
        history_text = self._format_history(history)
        last_reply = ""
        for attempt in range(1, MAX_LLM_RETRIES + 1):
            if attempt == 1:
                prompt = DOM_ACTION_PROMPT.format(
                    goal=goal, history=history_text, elements=elements_json
                )
            elif last_reply:
                prompt = DOM_RETRY_PROMPT.format(
                    goal=goal, last_reply=last_reply[:800], elements=elements_json
                )
            else:
                prompt = DOM_ACTION_PROMPT.format(
                    goal=goal, history=history_text, elements=elements_json
                )
            try:
                result = self._engine.review(
                    prompt=prompt,
                    system=DOM_SYSTEM_PROMPT,
                    response_schema=None,
                    max_tokens=2048,
                )
            except (ReasoningEngineError, Exception) as exc:  # noqa: BLE001
                _log(f"decide attempt {attempt} engine error: {type(exc).__name__}: {exc}")
                time.sleep(1)
                continue
            if isinstance(result, dict) and "decision" in result and isinstance(result["decision"], dict):
                result = result["decision"]
            if isinstance(result, str):
                try:
                    result = json.loads(result)
                except ValueError:
                    last_reply = result[:400]
                    continue
            validated = self._validate_action(result, elements)
            if validated is not None:
                _log(f"action decision: {validated['action']} reason={validated.get('reason', '')[:60]}")
                return validated
            last_reply = json.dumps(result, ensure_ascii=False)[:400]
            _log(f"decide attempt {attempt} invalid action, retrying")
        _log("decide failed after 3 attempts")
        return {"done": False, "error": "llm_failed"}

    @staticmethod
    def _format_history(history: list[dict[str, Any]]) -> str:
        if not history:
            return "(none)"
        lines = []
        for item in history[-8:]:
            step = item.get("step", "?")
            action = item.get("action", "?")
            detail = item.get("detail", "")
            lines.append(f"{step}. {action} {detail}".strip())
        return "\n".join(lines) if lines else "(none)"

    # ------------------------------------------------------------------
    # 3. 执行
    # ------------------------------------------------------------------
    def execute_action(
        self,
        page: Any,
        action: dict[str, Any],
        elements: list[dict[str, Any]],
    ) -> None:
        """执行决策。type 只允许落在 input/textarea；press 先聚焦再按键。"""
        name = action.get("action")
        if name == "extract":
            _log("extract requested by model, handing control back")
            return
        if name == "wait":
            page.wait_for_timeout(int(action.get("value", "2000") or 2000))
            return
        if name in {"click", "type"}:
            element_id = str(action.get("id", ""))
            selector = f'[data-domagent-id="{element_id}"]'
            meta = next((el for el in elements if str(el.get("id", "")) == element_id), {})
            tag = str(meta.get("tag", ""))
            if name == "click":
                page.click(selector, timeout=8000)
                _log(f"execute click {selector}")
                return
            if tag not in {"input", "textarea"}:
                raise RuntimeError(f"type target {tag or 'unknown'} is not input/textarea")
            page.fill(selector, str(action.get("value", "")), timeout=8000)
            _log(f"execute type {selector} value_len={len(str(action.get('value', '')))}")
            return
        if name == "press":
            page.focus("body")
            page.keyboard.press(str(action.get("value", "Enter")))
            _log(f"execute press {action.get('value', 'Enter')}")
            return
        raise RuntimeError(f"unsupported action: {name}")

    # ------------------------------------------------------------------
    # 4. 主循环
    # ------------------------------------------------------------------
    @staticmethod
    def _cleanup_marks(page: Any) -> None:
        try:
            page.evaluate(
                "() => { document.querySelectorAll('[data-domagent-id]')"
                ".forEach((el) => el.removeAttribute('data-domagent-id')); }"
            )
        except Exception:  # 页面可能已关闭
            _log("cleanup: page already gone, skipped")

    def run_goal(self, page: Any, goal: str, max_steps: int = DEFAULT_MAX_STEPS,
                 budget_ms: int | None = None) -> dict[str, Any]:
        """主循环：extract → decide → execute，直到 done / 步数耗尽 / 预算超时。

        budget_ms: 整轮墙钟预算（毫秒）；超限返回 error="query_budget"。
        返回 {"done": bool, "steps": int, "history": list, "error": str}
        无论成功与否都会清理 data-domagent-id 属性。
        """
        history: list[dict[str, Any]] = []
        steps = 0
        started = time.monotonic()
        try:
            for step in range(1, max_steps + 1):
                if budget_ms is not None and (time.monotonic() - started) * 1000 > budget_ms:
                    _log(f"goal budget {budget_ms}ms exceeded at step {step}")
                    return {"done": False, "steps": steps, "history": history,
                            "error": "query_budget"}
                self._step = step
                steps = step
                elements = self.extract_interactive_elements(page)
                if not elements:
                    _log("no visible interactive elements, page may still be loading")
                    page.wait_for_timeout(2500)
                    elements = self.extract_interactive_elements(page)
                    if not elements:
                        return {"done": False, "steps": steps, "history": history,
                                "error": "no_elements"}
                decision = self.decide_next_action(elements, goal, history)
                if decision.get("error"):
                    return {"done": False, "steps": steps, "history": history,
                            "error": str(decision["error"])}
                name = decision.get("action", "")
                detail = decision.get("value", "") or decision.get("id", "")
                history.append({"step": step, "action": name, "detail": str(detail)[:120]})
                if name == "done":
                    _log(f"goal achieved at step {step}")
                    return {"done": True, "steps": steps, "history": history, "error": ""}
                try:
                    self.execute_action(page, decision, elements)
                except Exception as exc:  # noqa: BLE001
                    _log(f"execute failed at step {step}: {type(exc).__name__}: {exc}")
                    history.append({"step": step, "action": "execute_error",
                                    "detail": str(exc)[:160]})
                    recovery = self.decide_next_action(
                        elements, goal + f"\n(Hint: last action failed: {type(exc).__name__})", history
                    )
                    if recovery.get("error"):
                        return {"done": False, "steps": steps, "history": history,
                                "error": f"execute_failed:{type(exc).__name__}"}
                    decision = recovery
                    name = decision.get("action", "")
                    history.append({"step": step, "action": name,
                                    "detail": str(decision.get("value", ""))[:120]})
                    if name == "done":
                        return {"done": True, "steps": steps, "history": history, "error": ""}
                    try:
                        self.execute_action(page, decision, elements)
                    except Exception as exc2:  # noqa: BLE001
                        return {"done": False, "steps": steps, "history": history,
                                "error": f"execute_failed:{type(exc2).__name__}"}
                page.wait_for_timeout(800)
            _log(f"max_steps {max_steps} reached without done")
            return {"done": False, "steps": steps, "history": history, "error": "max_steps"}
        finally:
            self._cleanup_marks(page)
