"""Orchestration policy definitions for PSV Trade OS 9.4.1."""

from __future__ import annotations

from dataclasses import dataclass
from core.config.settings import APP_VERSION, settings


@dataclass(frozen=True)
class Policy:
    """Runtime policy consumed by orchestration components."""
    max_task_seconds: int
    max_steps: int
    max_retries: int
    no_progress_limit: int
    version: str = APP_VERSION

    def __post_init__(self) -> None:
        if self.max_task_seconds <= 0:
            raise ValueError("max_task_seconds must be greater than zero")
        if self.max_steps <= 0:
            raise ValueError("max_steps must be greater than zero")
        if self.max_retries < 0:
            raise ValueError("max_retries must not be negative")
        if self.no_progress_limit <= 0:
            raise ValueError("no_progress_limit must be greater than zero")


DEFAULT_POLICY = Policy(settings.max_task_seconds, settings.max_steps,
                        settings.max_retries, settings.no_progress_limit)
