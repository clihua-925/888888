"""Compatibility shim: the real shared state schema lives in core.contracts.state."""

from core.contracts.state import (
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_PAUSED,
    STATUS_PENDING,
    STATUS_RUNNING,
    STATUS_TIMEOUT,
    STATUS_VALUES,
    TaskState,
    TaskStatus,
)

__all__ = [
    "STATUS_COMPLETED",
    "STATUS_FAILED",
    "STATUS_PAUSED",
    "STATUS_PENDING",
    "STATUS_RUNNING",
    "STATUS_TIMEOUT",
    "STATUS_VALUES",
    "TaskState",
    "TaskStatus",
]
