"""Dynamic workflow registry for PSV Trade OS 9.4.1."""

from __future__ import annotations

import importlib
import logging
import pkgutil
from dataclasses import dataclass
from types import ModuleType
from typing import Any, Callable

import business.workflows as workflows_package

LOGGER = logging.getLogger(__name__)


class WorkflowDiscoveryError(RuntimeError):
    """Raised when workflow discovery or registration fails."""


@dataclass(frozen=True)
class RegisteredWorkflow:
    """Validated declarative workflow specification."""

    workflow_id: str
    version: str
    spec: ModuleType

    @property
    def node_ids(self) -> tuple[str, ...]:
        return tuple(getattr(self.spec, "NODE_IDS"))

    @property
    def node_specs(self) -> dict[str, Any]:
        return dict(getattr(self.spec, "NODE_SPECS"))

    @property
    def contracts(self) -> tuple[Any, ...]:
        return tuple(getattr(self.spec, "CONTRACTS"))

    @property
    def payload_keys(self) -> dict[str, tuple[str, ...]]:
        return dict(getattr(self.spec, "PAYLOAD_KEYS"))

    @property
    def capabilities(self) -> tuple[str, ...]:
        return tuple(getattr(self.spec, "CAPABILITIES"))


class WorkflowRegistry:
    """Discover, validate, and expose declarative workflow specifications."""

    def __init__(self) -> None:
        self._workflows: dict[str, RegisteredWorkflow] = {}

    def discover(self) -> tuple[RegisteredWorkflow, ...]:
        """Discover all workflow ``spec.py`` modules and register them."""
        discovered: dict[str, RegisteredWorkflow] = {}
        try:
            package_path = getattr(workflows_package, "__path__", None)
            if package_path is None:
                raise WorkflowDiscoveryError(
                    "business.workflows does not expose a package __path__"
                )
            for module_info in pkgutil.iter_modules(package_path):
                if not module_info.ispkg:
                    continue
                spec_module_name = f"{workflows_package.__name__}.{module_info.name}.spec"
                try:
                    spec_module = importlib.import_module(spec_module_name)
                    workflow = self._build_registration(spec_module, spec_module_name)
                    if workflow.workflow_id in discovered:
                        raise WorkflowDiscoveryError(
                            f"Duplicate workflow_id discovered: {workflow.workflow_id}"
                        )
                    discovered[workflow.workflow_id] = workflow
                    LOGGER.info(
                        "Workflow discovered: workflow_id=%s version=%s module=%s",
                        workflow.workflow_id, workflow.version, spec_module_name,
                    )
                except Exception as exc:
                    LOGGER.exception("Workflow discovery failed for %s", spec_module_name)
                    raise WorkflowDiscoveryError(
                        f"Failed to discover workflow spec '{spec_module_name}': {exc}"
                    ) from exc
        except WorkflowDiscoveryError:
            raise
        except Exception as exc:
            LOGGER.exception("Workflow discovery failed while scanning business.workflows")
            raise WorkflowDiscoveryError(f"Failed to scan business.workflows: {exc}") from exc
        self._workflows = discovered
        return self.workflows()

    def get(self, workflow_id: str) -> RegisteredWorkflow:
        """Return a registered workflow or raise a clear error."""
        normalized_id = workflow_id.strip()
        if not normalized_id:
            raise KeyError("workflow_id must not be empty")
        try:
            return self._workflows[normalized_id]
        except KeyError as exc:
            raise KeyError(f"Workflow not registered: {normalized_id}") from exc

    def workflows(self) -> tuple[RegisteredWorkflow, ...]:
        """Return registered workflows in deterministic ID order."""
        return tuple(self._workflows[key] for key in sorted(self._workflows))

    def node_functions(self, workflow: RegisteredWorkflow) -> dict[str, Callable[[dict[str, Any]], dict[str, Any]]]:
        """Load business node callables through the registered workflow package only."""
        package_name = getattr(workflow.spec, "__package__", "")
        if not package_name:
            raise WorkflowDiscoveryError(
                f"Workflow spec has no package metadata: {workflow.workflow_id}"
            )
        nodes_module = importlib.import_module(f"{package_name}.nodes")
        getter = getattr(nodes_module, "get_node_function", None)
        if not callable(getter):
            raise WorkflowDiscoveryError(
                f"Workflow '{workflow.workflow_id}' nodes module must expose get_node_function"
            )
        functions: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {}
        for node_id in workflow.node_ids:
            function = getter(node_id)
            if not callable(function):
                raise WorkflowDiscoveryError(
                    f"Workflow '{workflow.workflow_id}' node '{node_id}' is not callable"
                )
            functions[node_id] = function
        return functions

    @staticmethod
    def _build_registration(spec_module: ModuleType, module_name: str) -> RegisteredWorkflow:
        required = (
            "WORKFLOW_ID", "WORKFLOW_VERSION", "NODE_IDS", "NODE_SPECS",
            "CONTRACTS", "PAYLOAD_KEYS", "CAPABILITIES",
        )
        missing = [name for name in required if not hasattr(spec_module, name)]
        if missing:
            raise WorkflowDiscoveryError(
                f"Workflow spec '{module_name}' is missing required declarations: "
                + ", ".join(missing)
            )
        workflow_id = str(getattr(spec_module, "WORKFLOW_ID")).strip()
        version = str(getattr(spec_module, "WORKFLOW_VERSION")).strip()
        node_ids = tuple(getattr(spec_module, "NODE_IDS"))
        node_specs = getattr(spec_module, "NODE_SPECS")
        contracts = tuple(getattr(spec_module, "CONTRACTS"))
        payload_keys = getattr(spec_module, "PAYLOAD_KEYS")
        capabilities = tuple(getattr(spec_module, "CAPABILITIES"))
        if not workflow_id:
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' has empty WORKFLOW_ID")
        if not version:
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' has empty WORKFLOW_VERSION")
        if not node_ids or len(node_ids) != len(set(node_ids)):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' must declare unique NODE_IDS")
        if set(node_specs) != set(node_ids):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' NODE_SPECS must match NODE_IDS")
        contract_ids = tuple(contract.node_id for contract in contracts)
        if set(contract_ids) != set(node_ids) or len(contract_ids) != len(set(contract_ids)):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' CONTRACTS must match NODE_IDS")
        if not isinstance(payload_keys, dict):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' PAYLOAD_KEYS must be a mapping")
        if not capabilities or len(capabilities) != len(set(capabilities)):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' must declare unique CAPABILITIES")
        return RegisteredWorkflow(workflow_id=workflow_id, version=version, spec=spec_module)
