"""Expert review layer (v40 acceptance-gate pattern, orchestration side).

After each business node succeeds, ExpertReviewer builds an acceptance checklist
for that node and asks the DecisionProvider (LLM) for a verdict. Fail-closed
only when BOTH the LLM verdict and the rule acceptance fail; "degraded" always
records and continues. When the LLM is unavailable the gate degrades to pure
rule acceptance, so workflows never block on infrastructure.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Mapping

from core.contracts.context import get_decision_provider

LOGGER = logging.getLogger(__name__)


class ExpertReviewError(RuntimeError):
    """Raised when a node fails both LLM review and rule acceptance."""


# 通用验收标准（core 层，不 import 任何 business 内容；按节点输出契约检查）
_ACCEPTANCE: dict[str, list[str]] = {
    "PRODUCT_DEFINITION": ["product_definition"],
    "TRADE_STRATEGY": ["fragments"],
    "CUSTOMS_NODE_COLLECTION": ["trade_nodes", "evidence_pool"],
    "EVIDENCE_VERIFY": ["evidence_pool"],
    "ENTITY_RESOLUTION": ["entities"],
    "TRADE_EDGE_BUILD": ["node_reports"],  # 空关系是合法结果（LLM 可判无有效对），不以此判失败
    "GRAPH_EXPANSION": ["trade_nodes"],
    "RESOURCE_CLASSIFICATION": ["trade_nodes"],
    "EXPANSION_PLAN": ["fragments"],
    "SEED_SELECTION": ["trade_nodes"],
    "RELATION_FANOUT": ["relationships"],
    "EXPANSION_FILTER": ["trade_nodes", "relationships"],
    "OUTREACH_PLAN": ["fragments"],
    "LEAD_SELECTION": ["trade_nodes"],
    "PROFILE_ENRICHMENT": ["entities"],
    "QUALIFICATION": ["decisions"],
    "LETTER_COMPOSITION": ["evidence_pool"],
    "DRAFT_REVIEW_GATE": ["evidence_pool"],
    "OUTREACH_SEND": ["decisions"],
}
_DEFAULT_ACCEPTANCE = ["node_reports"]


def _acceptance_checklist(node_id: str) -> list[str]:
    return _ACCEPTANCE.get(node_id, _DEFAULT_ACCEPTANCE)


class ExpertReviewer:
    """Per-node LLM acceptance gate with rule fallback."""

    def __init__(self) -> None:
        self._enabled = os.environ.get("EXPERT_REVIEW_ENABLED", "1").strip() != "0"

    def review(self, state: Mapping[str, Any], task_id: str, node_id: str, workflow_id: str, step: int) -> None:
        if not self._enabled:
            return
        checklist = _acceptance_checklist(node_id)
        rule_issues = self._rule_accept(state, checklist)

        prompt = (
            "You are the quality expert for node " + str(node_id) + " of workflow " + str(workflow_id) + ".\n"
            "Acceptance checklist: " + str(checklist) + ".\n"
            "Current state excerpt: " + self._excerpt(state, checklist) + ".\n"
            "Give a verdict. Return a JSON object with a string field 'verdict' "
            "(one of 'pass', 'degraded', 'fail') and a string field 'reason'."
        )
        verdict, reason, confidence = self._llm_verdict(state, node_id, prompt)

        reports = state.get("node_reports")
        report: dict[str, Any] = {}
        if isinstance(reports, dict) and isinstance(reports.get(node_id), dict):
            report = reports[node_id]
        if verdict == "pass" and not rule_issues:
            report["expert"] = {"verdict": "pass", "confidence": confidence}
            self._record(state, task_id, node_id, "pass", reason, confidence)
            return
        if verdict == "fail" and rule_issues:
            report["expert"] = {"verdict": "fail", "reason": reason, "rule_issues": rule_issues}
            self._record(state, task_id, node_id, "fail", reason, confidence)
            raise ExpertReviewError(
                f"Expert review failed for {node_id}: llm='{reason}'; rules={rule_issues}"
            )
        # degraded / pass-with-rule-issues / llm-offline: record and continue
        report["expert"] = {"verdict": "degraded", "reason": reason or "rule_issues", "rule_issues": rule_issues, "confidence": confidence}
        self._record(state, task_id, node_id, "degraded", reason or ";".join(rule_issues) or "review degraded", confidence)

    # ------------------------------------------------------------------
    def _rule_accept(self, state: Mapping[str, Any], checklist: list[str]) -> list[str]:
        issues = []
        for key in checklist:
            value = state.get(key)
            if value is None:
                issues.append(f"missing:{key}")
            elif isinstance(value, (list, dict)) and not value:
                issues.append(f"empty:{key}")
        return issues

    def _llm_verdict(self, state: Mapping[str, Any], node_id: str, prompt: str) -> tuple[str, str, float]:
        try:
            provider = get_decision_provider()
            decide = getattr(provider, "decide", None)
            if not callable(decide):
                return "", "", 0.0
            outcome = decide(state, "expert_review", prompt, {})
            decision = (outcome or {}).get("decision") or {}
            verdict = str(decision.get("verdict", "")).strip().lower()
            reason = str(decision.get("reason", ""))
            confidence = float((outcome or {}).get("confidence") or 0.0)
            if verdict not in {"pass", "degraded", "fail"}:
                return "", "", confidence
            return verdict, reason, confidence
        except Exception as exc:  # noqa: BLE001 - LLM outage must degrade, never block
            LOGGER.warning("Expert review LLM unavailable for %s: %s", node_id, exc)
            return "", "", 0.0

    def _record(self, state: Mapping[str, Any], task_id: str, node_id: str, verdict: str, reason: str, confidence: float) -> None:
        decisions = state.get("decisions")
        if not isinstance(decisions, list):
            return
        decisions.append({
            "decision_type": "expert_review",
            "decision": {"node_id": node_id, "verdict": verdict, "reason": reason[:400]},
            "confidence": confidence or 0.5,
        })

    @staticmethod
    def _excerpt(state: Mapping[str, Any], keys: list[str], limit: int = 300) -> str:
        parts = []
        for key in keys:
            value = state.get(key)
            text = str(value)
            parts.append(f"{key}={text[:limit]}")
        return "; ".join(parts)[:2000]
