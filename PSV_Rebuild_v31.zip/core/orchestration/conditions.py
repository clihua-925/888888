"""Condition Edge Engine: the sole formal workflow router."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .plan import ExecutionPlan
from .recovery import TASK_FAILED, should_stop_retry
from .state import (
    STATUS_COMPLETED, STATUS_FAILED, STATUS_PAUSED, STATUS_RUNNING, STATUS_TIMEOUT,
    TaskState,
)


@dataclass(frozen=True)
class RouteOutcome:
    """Result of evaluating one routing decision."""

    target: str | None
    reason: str
    outcome: dict[str, Any] = field(default_factory=dict)


class ConditionEdgeEngine:
    """Evaluate shared-state conditions and select the next graph node."""

    def choose(
        self,
        workflow: ExecutionPlan,
        state: Mapping[str, Any] | TaskState,
        current: str,
    ) -> RouteOutcome:
        """Choose the next node using current shared state and the initial order."""
        status = state.get("status")

        # The evidence gate is an orchestration-only condition. Business nodes
        # produce evidence state; this router alone decides whether the workflow
        # may proceed to entity resolution.
        if current == "EVIDENCE_VERIFY":
            evidence_pool = state.get("evidence_pool", [])
            verified = any(
                isinstance(item, Mapping) and item.get("verified") is True
                for item in evidence_pool
            ) if isinstance(evidence_pool, (list, tuple)) else False
            if verified:
                return RouteOutcome(
                    target="ENTITY_RESOLUTION",
                    reason="verified_evidence_gate",
                    outcome={
                        "success": True,
                        "status": STATUS_RUNNING,
                        "current": current,
                        "target": "ENTITY_RESOLUTION",
                        "verified_evidence": True,
                    },
                )
            if not verified and should_stop_retry(state.get("orchestration", {})):
                failure = {
                    "code": "TASK_FAILED",
                    "message": "retry budget or no-progress limit exhausted at EVIDENCE_VERIFY",
                    "failure_type": "retry_limit",
                }
                if isinstance(state, dict):
                    state["status"] = TASK_FAILED
                    state["error"] = failure
                return RouteOutcome(
                    target=None,
                    reason="retry_limit_exceeded",
                    outcome={"success": False, "status": TASK_FAILED, "error": failure},
                )
            failure = {
                "code": "VERIFIED_EVIDENCE_REQUIRED",
                "message": "EVIDENCE_VERIFY requires at least one evidence item with verified=True",
                "failure_type": "node_failure",
            }
            if isinstance(state, dict):
                state["status"] = STATUS_FAILED
                state["error"] = failure
            return RouteOutcome(
                target=None,
                reason="verified_evidence_gate_failed",
                outcome={"success": False, "status": STATUS_FAILED, "error": failure},
            )

        if status in {STATUS_FAILED, STATUS_TIMEOUT, STATUS_PAUSED, TASK_FAILED}:
            return RouteOutcome(
                target=None,
                reason="terminal_task_status",
                outcome={"success": False, "status": status},
            )
        if status != STATUS_RUNNING:
            return RouteOutcome(
                target=None,
                reason="non_running_task_status",
                outcome={"success": False, "status": status},
            )
        try:
            current_index = workflow.order.index(current)
        except ValueError:
            return RouteOutcome(
                target=None,
                reason="current_node_not_in_plan",
                outcome={"success": False, "current": current},
            )

        if current_index + 1 >= len(workflow.order):
            return RouteOutcome(
                target=None,
                reason="workflow_completed",
                outcome={"success": True, "status": STATUS_COMPLETED},
            )

        target = workflow.order[current_index + 1]
        return RouteOutcome(
            target=target,
            reason="state_running_successor",
            outcome={
                "success": True,
                "status": STATUS_RUNNING,
                "current": current,
                "target": target,
            },
        )
