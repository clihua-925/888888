"""Orchestration-side provider adapters for PSV Trade OS 9.4.1.

Dependency direction:
core.orchestration.providers -> core.contracts.providers -> (DecisionLayer / Database)
No cycle: core.contracts never imports core.orchestration.
"""

from __future__ import annotations

from typing import Any

from core.contracts.providers import DataProvider, DecisionProvider


class DecisionLayerProvider(DecisionProvider):
    """Adapt the orchestration DecisionLayer to the DecisionProvider interface."""

    def __init__(self, decision_layer: Any) -> None:
        self._decision_layer = decision_layer

    def decide(self, state: Any, decision_type: str, prompt: str, context: Any) -> dict:
        return self._decision_layer.decide(state, decision_type, prompt, context)


class DatabaseProvider(DataProvider):
    """Adapt the infrastructure Database to the DataProvider interface.

    database_write_authority is enforced here, on the write path, not only
    on the audit-event path: any node without authority that attempts a
    commit raises PermissionError.
    """

    def __init__(self, database: Any, authorized_nodes: set[str] | None = None) -> None:
        self._database = database
        self._authorized_nodes = set(authorized_nodes or set())
        self._current_node: str | None = None

    def set_current_node(self, node_id: str | None) -> None:
        self._current_node = node_id

    def _enforce_authority(self) -> None:
        if self._current_node is not None and self._current_node not in self._authorized_nodes:
            raise PermissionError(f"node {self._current_node} lacks database_write_authority")

    def commit_trade_data(self, task_id: str, entities: Any, edges: Any, evidence: Any) -> dict[str, int]:
        self._enforce_authority()
        return self._database.commit_trade_data(task_id, entities, edges, evidence)

    def commit_outreach_letters(self, task_id: str, letters: Any) -> dict[str, int]:
        self._enforce_authority()
        return self._database.commit_outreach_letters(task_id, letters)
