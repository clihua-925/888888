"""Automatic per-node execution recorder (orchestration layer).

Every node attempt in every UI-driven task is recorded to records/<task_id>.jsonl:
one JSON line per attempt with input/output summaries, duration, status, error and
full traceback. Designed for offline analysis: send the jsonl to the maintainer.
Default on; disable with NODE_RECORDING_ENABLED=0.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Any

LOGGER = logging.getLogger(__name__)
_LOCK = threading.Lock()


def _sizes(state: Any) -> dict:
    out = {}
    if isinstance(state, dict):
        for key, value in state.items():
            if isinstance(value, (list, dict, str)):
                out[key] = len(value)
    return out


def _sample_list(value: list, limit: int = 2, width: int = 220) -> list:
    return [json.dumps(item, ensure_ascii=False, default=str)[:width] for item in value[:limit]]


class NodeRecorder:
    """Append-only JSONL recorder; one file per task under records/."""

    def __init__(self, root: str | Path = "records") -> None:
        self._enabled = os.environ.get("NODE_RECORDING_ENABLED", "1").strip() != "0"
        self._dir = Path(root)
        if self._enabled:
            try:
                self._dir.mkdir(parents=True, exist_ok=True)
            except Exception as exc:  # noqa: BLE001
                LOGGER.warning("NodeRecorder disabled: cannot create %s (%s)", self._dir, exc)
                self._enabled = False

    def begin(self, task_id: str, node_id: str, step: int, attempt: int, state: dict) -> None:
        if not self._enabled:
            return
        record = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "task_id": task_id, "node_id": node_id, "step": step, "attempt": attempt,
            "phase": "begin", "inputs": _sizes(state),
            "input_samples": {
                key: _sample_list(value)
                for key, value in state.items()
                if isinstance(value, list) and value
            },
        }
        self._write(task_id, record)

    def end(self, task_id: str, node_id: str, step: int, attempt: int, state: dict,
            status: str, duration_ms: int, error: BaseException | None, tb: str | None) -> None:
        if not self._enabled:
            return
        reports = state.get("node_reports") if isinstance(state, dict) else None
        report = reports.get(node_id) if isinstance(reports, dict) else None
        record = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "task_id": task_id, "node_id": node_id, "step": step, "attempt": attempt,
            "phase": "end", "status": status, "duration_ms": duration_ms,
            "outputs": _sizes(state),
            "output_samples": {
                key: _sample_list(value)
                for key, value in state.items()
                if isinstance(value, list) and value
            },
            "node_report": report if isinstance(report, dict) else None,
        }
        if error is not None:
            record["error"] = f"{type(error).__name__}: {error}"
            record["traceback"] = tb
        self._write(task_id, record)

    def _write(self, task_id: str, record: dict) -> None:
        path = self._dir / f"{task_id}.jsonl"
        try:
            with _LOCK:
                with path.open("a", encoding="utf-8") as fh:
                    fh.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("NodeRecorder write failed: %s", exc)
