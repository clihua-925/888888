"""Generic task recovery engine for PSV Trade OS 9.4.1."""

from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Mapping, MutableMapping
from typing import Any

from core.config.settings import MAX_RETRIES, NO_PROGRESS_LIMIT

from .policies import DEFAULT_POLICY, Policy
from .state import STATUS_FAILED, STATUS_PAUSED, STATUS_RUNNING, TaskState

LOGGER = logging.getLogger(__name__)

TASK_FAILED = "TASK_FAILED"

FAILURE_TYPES = frozenset({
    "node_failure",
    "contract_input_failure",
    "contract_output_failure",
    "timeout",
    "no_information_gain",
    "engine_failure",
})


class RecoveryManager:
    """Apply generic recovery policy without business-node knowledge."""

    def __init__(self, policy: Policy = DEFAULT_POLICY) -> None:
        self.policy = policy

    def can_retry(self, state: Mapping[str, Any], node_id: str, failure_type: str) -> bool:
        """Determine whether the failure type is retryable and budget remains."""
        normalized_failure_type = self._validate_failure_type(failure_type)
        if normalized_failure_type in {"timeout", "no_information_gain"}:
            return False
        attempts = self._attempts_for(state, node_id)
        return attempts < self.policy.max_retries

    def prepare_retry(
        self,
        state: MutableMapping[str, Any] | TaskState,
        node_id: str,
        error: Exception | str,
        failure_type: str,
    ) -> dict[str, Any]:
        """Prepare a generic retry or fail according to failure type and retry budget."""
        normalized_failure_type = self._validate_failure_type(failure_type)
        attempts = self._attempts_for(state, node_id)
        next_attempt = attempts + 1
        if not self.can_retry(state, node_id, normalized_failure_type):
            return self.fail(
                state,
                code="RECOVERY_NOT_RETRYABLE",
                message=f"Failure type {normalized_failure_type} is not retryable or retry limit reached for node {node_id}",
            )

        orchestration = self._orchestration(state)
        attempts_map = orchestration.setdefault("attempts", {})
        attempts_map[node_id] = next_attempt
        orchestration["recovery_action"] = "RETRY"
        orchestration["resume_node"] = node_id
        state["status"] = STATUS_RUNNING
        state["error"] = {
            "code": "RETRY_SCHEDULED",
            "message": str(error),
            "node_id": node_id,
            "attempt": next_attempt,
            "failure_type": normalized_failure_type,
        }
        LOGGER.warning(
            "Retry scheduled: node=%s attempt=%s/%s failure_type=%s error=%s",
            node_id,
            next_attempt,
            self.policy.max_retries,
            normalized_failure_type,
            error,
        )
        return {
            "action": "RETRY",
            "node_id": node_id,
            "attempt": next_attempt,
            "failure_type": normalized_failure_type,
            "error": state["error"],
        }

    def fail(
        self,
        state: MutableMapping[str, Any] | TaskState,
        code: str,
        message: str,
    ) -> dict[str, Any]:
        """Mark the task failed and persist the failure in shared state."""
        error = {"code": code, "message": message}
        state["error"] = error
        state["status"] = STATUS_FAILED
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "FAIL"
        orchestration.pop("resume_node", None)
        LOGGER.error(
            "Task recovery failed: code=%s message=%s",
            code,
            message,
        )
        return {"action": "FAIL", "error": error}

    def pause(
        self,
        state: MutableMapping[str, Any] | TaskState,
        reason: str,
    ) -> dict[str, Any]:
        """Pause a task for later orchestration resume."""
        state["status"] = STATUS_PAUSED
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "PAUSE"
        orchestration["pause_reason"] = reason
        LOGGER.warning("Task paused: %s", reason)
        return {"action": "PAUSE", "reason": reason}

    def resume(
        self,
        state: MutableMapping[str, Any] | TaskState,
    ) -> dict[str, Any]:
        """Resume a paused task."""
        state["status"] = STATUS_RUNNING
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "RESUME"
        LOGGER.info("Task resumed")
        return {"action": "RESUME"}

    @staticmethod
    def _validate_failure_type(failure_type: str) -> str:
        """Validate and normalize the generic failure category."""
        normalized = str(failure_type).strip().lower()
        if normalized not in FAILURE_TYPES:
            raise ValueError(
                "Unsupported failure_type: "
                f"{failure_type!r}; expected one of {sorted(FAILURE_TYPES)}"
            )
        return normalized

    @staticmethod
    def _orchestration(
        state: MutableMapping[str, Any],
    ) -> MutableMapping[str, Any]:
        """Return the mutable orchestration state container."""
        value = state.get("orchestration")
        if value is None:
            value = {}
            state["orchestration"] = value
        if not isinstance(value, MutableMapping):
            raise TypeError(
                "state['orchestration'] must be a mutable mapping"
            )
        return value

    @classmethod
    def _attempts_for(
        cls,
        state: Mapping[str, Any],
        node_id: str,
    ) -> int:
        """Read the generic attempt counter from shared state."""
        orchestration = state.get("orchestration", {})
        if not isinstance(orchestration, Mapping):
            return 0
        attempts = orchestration.get("attempts", {})
        if not isinstance(attempts, Mapping):
            return 0
        value = attempts.get(node_id, 0)
        try:
            return max(0, int(value))
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Invalid attempt counter for node {node_id}: {value!r}"
            ) from exc


def should_stop_retry(orchestration_state: dict) -> bool:
    """Return True when retry budget or no-progress limit is exhausted.

    Only reads the state["orchestration"] sub-dict; never mutates shared state.
    retry_count: prefer the explicit counter, fall back to the engine's
    consecutive-retry counter. no_progress_count: consider both the
    node-execution counter and the route-level counter.
    """
    if not isinstance(orchestration_state, dict):
        return False
    retry_count = max(
        int(orchestration_state.get("retry_count") or 0),
        int(orchestration_state.get("retry_consecutive") or 0),
    )
    no_progress_count = max(
        int(orchestration_state.get("no_progress_count") or 0),
        int(orchestration_state.get("route_no_progress_count") or 0),
    )
    return retry_count >= MAX_RETRIES or no_progress_count >= NO_PROGRESS_LIMIT


def update_progress_state(state: dict) -> None:
    """Track (current_node, status, error, step_count) signature progress.

    Writes only into state["orchestration"]; adds no new top-level State fields.
    """
    orchestration = state.get("orchestration")
    if not isinstance(orchestration, dict):
        orchestration = {}
        state["orchestration"] = orchestration

    current_node = str(
        orchestration.get("current_node")
        or orchestration.get("resume_node")
        or state.get("current_node")
        or ""
    )
    probe = {
        "current_node": current_node,
        "status": state.get("status"),
        "error": state.get("error"),
        "step_count": orchestration.get("step_count", 0),
    }
    signature = hashlib.sha1(
        json.dumps(probe, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()

    # Route-level counters use dedicated keys. The node-execution progress
    # counter (no_progress_count / last_state_signature) is owned by
    # engine._after_node_success and must not be overwritten here.
    if orchestration.get("last_route_signature") == signature:
        orchestration["route_no_progress_count"] = int(
            orchestration.get("route_no_progress_count") or 0
        ) + 1
    else:
        orchestration["route_no_progress_count"] = 0
    orchestration["last_route_signature"] = signature
