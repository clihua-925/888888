"""Playwright/Outlook concrete mail sender (orchestration layer).

Gated by environment: OUTLOOK_SEND_ENABLED=1. Without the flag or without a
recipient address the sender degrades to "skipped" - business never blocks on
delivery infrastructure.
"""
from __future__ import annotations

import logging
import os
from typing import Any

from core.contracts.providers import MailSender

LOGGER = logging.getLogger(__name__)


class OutlookMailSender(MailSender):
    """Drive Outlook web via Playwright CDP; safe no-op when unconfigured."""

    def __init__(self) -> None:
        self._enabled = os.environ.get("OUTLOOK_SEND_ENABLED", "").strip() == "1"
        self._profile_dir = os.environ.get("OUTLOOK_PROFILE_DIR", "").strip()
        self._cdp_url = os.environ.get("OUTLOOK_CDP_URL", "").strip() or "http://127.0.0.1:9222"

    def send_letter(self, letter: dict) -> dict:
        recipient = str(letter.get("recipient", "") or "").strip()
        if not self._enabled:
            return {"status": "skipped", "reason": "outlook_send_disabled"}
        if not recipient:
            return {"status": "skipped", "reason": "no_recipient"}
        try:
            return self._send_via_outlook(letter, recipient)
        except Exception as exc:  # noqa: BLE001 - delivery must never break the workflow
            LOGGER.exception("Outlook send failed: %s", exc)
            return {"status": "failed", "reason": f"outlook_error: {exc}"}

    def _send_via_outlook(self, letter: dict, recipient: str) -> dict:
        from playwright.sync_api import sync_playwright  # lazy import; optional dependency

        subject = str(letter.get("subject", ""))
        body = str(letter.get("body", ""))
        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(self._cdp_url)
            context = browser.contexts[0] if browser.contexts else browser.new_context()
            page = context.pages[0] if context.pages else context.new_page()
            if "outlook" not in page.url:
                page.goto("https://outlook.live.com/mail/0/", timeout=60000)
            page.click('button[name="New mail"], [aria-label*="New mail"], text="New mail"', timeout=30000)
            page.fill('input[placeholder*="To"], [aria-label*="To"]', recipient, timeout=30000)
            page.fill('input[placeholder*="Add a subject"], [aria-label*="Add a subject"]', subject, timeout=30000)
            page.fill('[role="textbox"], [contenteditable="true"]', body, timeout=30000)
            page.click('button[aria-label*="Send"], button[name="Send"]', timeout=30000)
        return {"status": "sent", "recipient": recipient}
