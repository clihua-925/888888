"""AI Trade Extractor（V18）：PageSnapshot -> 贸易实体。

唯一入口 extract_companies(snapshot)：AI 理解优先、规则兜底并集，
出口强制 Entity Validator（七键缺一即丢）。
Node3 强制数据流的"AI 页面解析函数"即本函数。
"""

from __future__ import annotations

from typing import Any

from core.trade_graph import trade_extractor


def extract_companies(snapshot) -> list[dict[str, Any]]:
    """输入 PageSnapshot（或含 text/url/query 的等价对象），输出七键实体列表。

    输出键：name/company_name/role/country/address/shipments/evidence/source_url/product。
    """
    url = str(getattr(snapshot, "url", "") or (snapshot.get("url") if isinstance(snapshot, dict) else ""))
    query = str(getattr(snapshot, "query", "") or (snapshot.get("query") if isinstance(snapshot, dict) else ""))
    text = str(getattr(snapshot, "text", "") or getattr(snapshot, "visible_text", "")
               or (snapshot.get("text") if isinstance(snapshot, dict) else ""))
    page_number = int(getattr(snapshot, "page_number", 1)
                      or (snapshot.get("page_number", 1) if isinstance(snapshot, dict) else 1))
    records = trade_extractor.extract_from_snapshot({"visible_text": text, "url": url, "query": query})
    out = []
    for rec in records:
        rec["page_number"] = page_number
        if trade_extractor.validate_entity(rec):
            out.append(rec)
    return out


def validate_company(rec: dict) -> bool:
    """Entity Validator 外部入口。"""
    return trade_extractor.validate_entity(rec)
