"""通用贸易实体文本提取器（v13）。

不依赖任何 DOM selector：从页面可见文本中识别
importer / buyer / supplier / shipment / address / country。
纯 stdlib，供 iy_web.parse_page / import_sources 提取阶段替换使用。
"""

from __future__ import annotations

import re
from typing import Any

# 角色触发词（按优先级）
ROLE_PATTERNS = (
    ("importer", re.compile(r"\b(importer|import company|imports?)\b", re.I)),
    ("buyer", re.compile(r"\b(buyer|purchaser|procurement|wholesale buyer)\b", re.I)),
    ("supplier", re.compile(r"\b(supplier|manufacturer|factory|exporter|vendor|oem)\b", re.I)),
    ("distributor", re.compile(r"\b(distributor|wholesaler|reseller|retailer)\b", re.I)),
)

SHIPMENTS_RE = re.compile(r"([\d,]{1,9})\s+(?:shipments?|consignments?|import records?)", re.I)
ADDRESS_RE = re.compile(r"(\d{1,6}\s+[A-Z][A-Za-z0-9.\'\- ]{2,60}(?:Street|St\b|Avenue|Ave\b|Road|Rd\b|Drive|Dr\b|Lane|Ln\b|Blvd|Boulevard|Way|Court|Ct\b|Suite|Ste\b|Unit)\s*[,.]?\s*(?:[A-Z][A-Za-z.\'\- ]+[,\s]+)?(?:[A-Z]{2}\s+\d{5}(?:-\d{4})?|United States|USA|USA\b)?)", re.I)

COUNTRIES = (
    "United States|USA|US\b", "China", "India", "Vietnam", "Germany", "Mexico", "Canada",
    "United Kingdom|UK|England", "Japan", "Korea", "Taiwan", "Thailand", "Malaysia",
    "Indonesia", "Turkey", "Italy", "France", "Spain", "Netherlands", "Brazil", "Pakistan",
)
COUNTRY_RE = re.compile(r"\b(" + "|".join(COUNTRIES) + r")\b", re.I)

# 公司名启发式：2-6 个词，含商业后缀或首字母大写序列
COMPANY_HINT_RE = re.compile(
    r"\b([A-Z][A-Za-z0-9&\'\-.]{1,30}(?:\s+(?:of|and|the|for)\s+[A-Z][A-Za-z0-9&\'\-.]{1,30}|\s+[A-Z][A-Za-z0-9&\'\-.]{1,30}){0,4}"
    r"\s+(?:Co\.?|Company|Corp\.?|Corporation|Inc\.?|Incorporated|Ltd\.?|Limited|LLC|L\.L\.C\.|Group|Holdings|Industries|Enterprise|Enterprises|Trading|Import|Imports|Export|Exports|Supply|Supplies|Distribution|Distributors|Manufacturing|Factory|International|Intl\.?|USA|US|Global))\b")
TITLE_LINE_RE = re.compile(r"^([A-Z][A-Za-z0-9&'\-.]{1,30}(?: [A-Z][A-Za-z0-9&'\-.]{1,30}){1,4})$")

GENERIC_REJECT = re.compile(
    r"^(import yeti|search results?|sign (up|in)|log ?in|home|about|contact|privacy|terms"
    r"|find any|showing \d|companies & suppliers|advanced search|product finder)", re.I)
TOTAL_SHIP_LABEL = re.compile(r"^total shipments$", re.I)
REJECT_EXACT = {
    "u.s. imports", "us imports", "all companies", "search results", "export data",
    "import data", "importyeti", "u.s. imports and exports", "top importers",
    "top suppliers", "browse companies", "company directory", "import genius",
    "also exports", "u.s. exports", "exports", "u.s. import", "u.s. export",
    "total shipments", "all suppliers", "total exports", "shipment data",
    "trade data", "browse", "results", "companies", "suppliers", "importers",
    "united states", "united kingdom", "usa", "home page", "importyeti.com",
    "south korea", "korea", "china", "india", "vietnam", "japan", "taiwan",
    "germany", "mexico", "canada", "thailand", "malaysia", "turkey", "brazil",
    "also exports", "total shipments", "all suppliers",
}
SUPPLIER_RE = re.compile(
    r"(?:imported from|supplied by|sourced from|shipped by|exporter[:：])\s*"
    r"([A-Z][A-Za-z0-9&'\-.]{1,40}(?:\s+[A-Z][A-Za-z0-9&'\-.]{1,30}){0,3})", re.I)


def _norm_name(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip())


def looks_like_company(name: str) -> bool:
    n = _norm_name(name)
    if not (3 <= len(n) <= 80) or GENERIC_REJECT.match(n):
        return False
    if n.lower() in REJECT_EXACT:
        return False
    if not re.search(r"[A-Za-z]", n):
        return False
    return True


def extract_trade_entities(text: str, query: str = "") -> list[dict[str, Any]]:
    """从页面可见文本提取贸易实体记录。

    返回 [{name, role, country, shipments, address, matched_line}]，按出现顺序去重。
    """
    if not text:
        return []
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    found: dict[str, dict[str, Any]] = {}
    line_index: dict[str, int] = {}  # name.lower() -> 首现行号

    # 1) 公司名 + 邻近角色/出货量/国家
    for idx, ln in enumerate(lines):
        for m in COMPANY_HINT_RE.finditer(ln):
            name = _norm_name(m.group(1))
            if not looks_like_company(name):
                continue
            key = name.lower()
            rec = found.setdefault(key, {"name": name, "role": "", "country": "",
                                         "shipments": 0, "address": "", "matched_line": ln[:200]})
            line_index.setdefault(key, idx)
            for role, pat in ROLE_PATTERNS:
                if not rec["role"] and pat.search(ln):
                    rec["role"] = role
            sm = SHIPMENTS_RE.search(ln)
            if sm and not rec["shipments"]:
                try:
                    rec["shipments"] = int(sm.group(1).replace(",", ""))
                except ValueError:
                    pass
            if not rec["country"]:
                cm = COUNTRY_RE.search(ln)
                if cm:
                    rec["country"] = cm.group(1)
            am = ADDRESS_RE.search(ln)
            if am and not rec["address"] and len(am.group(1)) >= 8:
                rec["address"] = _norm_name(am.group(1))[:160]

    # 1b) 宽松模式：整行 2-5 个首字母大写词（无业务后缀的真实公司名，如 Shinwon Felt）
    for idx, ln in enumerate(lines):
        tm = TITLE_LINE_RE.match(ln)
        if tm and looks_like_company(tm.group(1)):
            key = tm.group(1).lower()
            found.setdefault(key, {"name": tm.group(1), "role": "", "country": "",
                                   "shipments": 0, "address": "", "matched_line": ln[:200]})
            line_index.setdefault(key, idx)

    # 2) 角色行反查公司名（"Acme Corp — Importer" 类布局）
    for ln in lines:
        role_hit = next((r for r, p in ROLE_PATTERNS if p.search(ln)), None)
        if not role_hit:
            continue
        for m in COMPANY_HINT_RE.finditer(ln):
            name = _norm_name(m.group(1))
            if not looks_like_company(name):
                continue
            rec = found.setdefault(name.lower(), {"name": name, "role": "", "country": "",
                                                  "shipments": 0, "address": "", "matched_line": ln[:200]})
            if not rec["role"]:
                rec["role"] = role_hit

    # 3) query 词命中行补强（搜索词本身出现的行大概率是结果卡片区）
    if query:
        q = query.strip().strip("\"")
        if len(q) >= 3:
            for ln in lines:
                if q.lower() in ln.lower():
                    for m in COMPANY_HINT_RE.finditer(ln):
                        name = _norm_name(m.group(1))
                        if looks_like_company(name):
                            rec = found.setdefault(name.lower(), {"name": name, "role": "", "country": "",
                                                                  "shipments": 0, "address": "", "matched_line": ln[:200]})
                            sm = SHIPMENTS_RE.search(ln)
                            if sm and not rec["shipments"]:
                                try:
                                    rec["shipments"] = int(sm.group(1).replace(",", ""))
                                except ValueError:
                                    pass

    # 邻行补强：公司名与出货量/地址/国家不同行时，从 ±2 行窗口补齐
    for key, idx in line_index.items():
        rec = found.get(key)
        if rec is None:
            continue
        window = lines[max(0, idx - 2): idx + 7]
        for _wi, wln in enumerate(window):
            if not rec["shipments"] and TOTAL_SHIP_LABEL.match(wln.strip()) and _wi + 1 < len(window):
                _nv = window[_wi + 1].strip().replace(",", "")
                if _nv.isdigit():
                    rec["shipments"] = int(_nv)
            if not rec["role"] and wln.strip().lower() not in REJECT_EXACT:
                for role, pat in ROLE_PATTERNS:
                    if pat.search(wln):
                        rec["role"] = role
                        break
            if not rec["shipments"]:
                sm = SHIPMENTS_RE.search(wln)
                if sm:
                    try:
                        rec["shipments"] = int(sm.group(1).replace(",", ""))
                    except ValueError:
                        pass
            if not rec["country"]:
                cm = COUNTRY_RE.search(wln)
                if cm:
                    rec["country"] = cm.group(1)
            if not rec["address"]:
                am = ADDRESS_RE.search(wln)
                if am and len(am.group(1)) >= 8:
                    rec["address"] = _norm_name(am.group(1))[:160]

    # 供应商反查："imported from X" 类证据行
    for key, idx in line_index.items():
        rec = found.get(key)
        if rec is None:
            continue
        for wln in lines[max(0, idx - 2): idx + 3]:
            sm2 = SUPPLIER_RE.search(wln)
            if sm2 and sm2.group(1).strip().lower() != rec["name"].lower():
                rec["supplier"] = _norm_name(sm2.group(1))[:80]
                break
    out = list(found.values())
    for rec in out:
        if not rec["role"]:
            rec["role"] = "buyer"
        if not rec["country"]:
            rec["country"] = ""
        ev = rec.get("matched_line", "")
        if ev.strip().lower() == rec["name"].lower() or len(ev) < len(rec["name"]) + 6:
            idx0 = line_index.get(rec["name"].lower(), -1)
            best = ev
            for wln in (lines[max(0, idx0 - 2): idx0 + 3] if idx0 >= 0 else []):
                if SHIPMENTS_RE.search(wln) or any(p.search(wln) for _, p in ROLE_PATTERNS) or COUNTRY_RE.search(wln):
                    if len(wln) > len(best):
                        best = wln
            ev = best
        rec["evidence"] = ev[:200]
        rec.setdefault("supplier", "")
    return out



def validate_entity(rec: dict) -> bool:
    """Entity Validator：name/role/source_url/evidence 四要素缺一即丢弃。"""
    if not isinstance(rec, dict):
        return False
    if not str(rec.get("name") or "").strip():
        return False
    if not str(rec.get("role") or "").strip():
        return False
    if not str(rec.get("source_url") or rec.get("url") or "").strip():
        return False
    if not str(rec.get("evidence") or "").strip():
        return False
    return True


def _extract_with_ai(text: str, query: str, url: str) -> list:
    """AI 页面理解层：LLM 从页面文本识别公司实体（经 contracts.context 决策通道）。"""
    try:
        from core.contracts.context import get_decision_provider
        provider = get_decision_provider()
    except Exception:
        return []
    if provider is None:
        return []
    excerpt = (text or "")[:6000]
    prompt = (
        "从以下 ImportYeti 页面文本中提取真实贸易公司实体。只输出 JSON，不要其他内容。\n"
        "{\"companies\":[{\"company_name\":\"\",\"role\":\"buyer|supplier|importer|distributor\","
        "\"country\":\"\",\"address\":\"\",\"shipments\":0,\"evidence\":\"<原文依据行>\"}]}\n"
        "规则：只提取真实公司；禁止页面标题类文字（U.S. Imports/Search Results/Top Suppliers/"
        "Total Shipments/Import Data/Export Data/国家名）；每条必须带 evidence 原文依据行；shipments 取数字。\n"
        "页面文本：\n" + excerpt + "\n搜索词：" + str(query)
    )
    try:
        from core.contracts.decision_utils import unwrap_decision
        decision = provider.decide({}, "customs_collection", prompt, {"query": query, "url": url})
        payload = dict(unwrap_decision(decision) or {})
    except Exception:
        return []
    out = []
    for c in payload.get("companies") or []:
        if not isinstance(c, dict):
            continue
        name = str(c.get("company_name") or c.get("name") or "").strip()
        if not looks_like_company(name):
            continue
        role = str(c.get("role") or "buyer").strip().lower()
        if role not in ("buyer", "supplier", "importer", "distributor", "manufacturer"):
            role = "buyer"
        try:
            shipments = int(str(c.get("shipments") or "0").replace(",", "") or 0)
        except ValueError:
            shipments = 0
        rec = {"name": name, "company_name": name, "role": role,
               "country": str(c.get("country") or ""), "address": str(c.get("address") or ""),
               "shipments": shipments, "evidence": str(c.get("evidence") or "")[:200], "supplier": ""}
        if validate_entity({**rec, "source_url": url}):
            out.append(rec)
    return out


def extract_from_snapshot(snapshot: dict) -> list:

    """Trade Extraction Layer：Page Snapshot -> companies[]（含 product/source_url，已过拒识名单）。"""
    if not isinstance(snapshot, dict):
        return []
    text = str(snapshot.get("visible_text") or snapshot.get("text") or "")
    query = str(snapshot.get("query") or "")
    url = str(snapshot.get("url") or "")
    companies: dict = {}
    # AI 层优先，正则层补齐（并集去重，同名以 AI 为准）
    for rec in _extract_with_ai(text, query, url):
        companies[rec["name"].lower()] = rec
    for rec in extract_trade_entities(text, query):
        key = rec.get("name", "").lower()
        if key and key not in companies:
            if not validate_entity({**rec, "source_url": url}):
                continue
            companies[key] = {
                "name": rec.get("name", ""), "company_name": rec.get("name", ""),
                "role": rec.get("role", ""), "country": rec.get("country", ""),
                "address": rec.get("address", ""),
                "shipments": int(rec.get("shipments") or 0),
                "product": query, "evidence": rec.get("evidence", ""),
                "source_url": url, "supplier": rec.get("supplier", ""),
            }
    for rec in companies.values():
        rec.setdefault("supplier", "")
        rec["product"] = query
        rec["source_url"] = url
    return list(companies.values())
