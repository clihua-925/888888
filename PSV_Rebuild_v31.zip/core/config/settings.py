"""Central runtime configuration for PSV Trade OS 9.4.1."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - dependency gate reports missing package
    load_dotenv = None

APP_VERSION = "9.4.1"
ROOT = Path(__file__).resolve().parents[2]

if load_dotenv is not None:
    load_dotenv(ROOT / ".env", override=False)


def _read_int(name: str, default: int) -> int:
    value = os.getenv(name, str(default)).strip()
    try:
        return int(value)
    except ValueError:
        import warnings
        warnings.warn(f"Invalid {name}={value!r}; falling back to default {default}")
        return default


@dataclass
class Settings:
    """Immutable application configuration."""

    app_version: str = APP_VERSION
    web_host: str = os.getenv("WEB_HOST", "127.0.0.1")
    web_port: int = _read_int("WEB_PORT", 8090)
    llm_base_url: str = os.getenv("LLM_BASE_URL", "http://127.0.0.1:8081/v1")
    llm_api_key: str = os.getenv("LLM_API_KEY", "")
    llm_model: str = os.getenv("LLM_MODEL", "deepseek-r1-distill-llama-70b")
    database_path: Path = Path(os.getenv("DATABASE_PATH", "data/psv.db"))
    checkpoint_path: Path = Path(os.getenv("CHECKPOINT_PATH", "data/checkpoints.db"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    max_task_seconds: int = _read_int("MAX_TASK_SECONDS", 7200)  # 放宽模型调用后任务总预算默认2小时，可用环境变量调
    max_steps: int = _read_int("MAX_STEPS", 40)
    max_retries: int = _read_int("MAX_RETRIES", 3)
    no_progress_limit: int = _read_int("NO_PROGRESS_LIMIT", 2)

    def ensure_directories(self) -> None:
        """Create runtime parent directories when they do not exist."""
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)

    @property
    def database_path_string(self) -> str:
        return str(self.database_path)

    @property
    def checkpoint_path_string(self) -> str:
        return str(self.checkpoint_path)


settings = Settings()

MAX_RETRIES = int(os.getenv('MAX_RETRIES', '3'))
NO_PROGRESS_LIMIT = int(os.getenv('NO_PROGRESS_LIMIT', '2'))


# ---- v14.1 ImportYeti 网页收割 ----
IY_WEB_ENABLED=os.getenv('IY_WEB_ENABLED','true').lower()=='true'
IY_WEB_HEADLESS=os.getenv('IY_WEB_HEADLESS','true').lower()=='true'
IY_WEB_AUTO_HEADED=os.getenv('IY_WEB_AUTO_HEADED','true').lower()=='true'
IY_WEB_CHALLENGE_WAIT=float(os.getenv('IY_WEB_CHALLENGE_WAIT','30'))
IY_WEB_CDP_ENABLED=os.getenv('IY_WEB_CDP_ENABLED','true').lower()=='true'
IY_WEB_CDP_URL=os.getenv('IY_WEB_CDP_URL','http://127.0.0.1:9222')
IY_WEB_DELAY_MIN=float(os.getenv('IY_WEB_DELAY_MIN','4'))
IY_WEB_DELAY_MAX=float(os.getenv('IY_WEB_DELAY_MAX','8'))
IY_WEB_SEARCH_LIMIT=int(os.getenv('IY_WEB_SEARCH_LIMIT','25'))
IY_WEB_TOP_BUYERS=int(os.getenv('IY_WEB_TOP_BUYERS','5'))
IY_WEB_MAX_SUPPLIERS=int(os.getenv('IY_WEB_MAX_SUPPLIERS','5'))
IY_WEB_MAX_CUSTOMERS=int(os.getenv('IY_WEB_MAX_CUSTOMERS','25'))
# v30.3 节点网络与页访预算：ImportYeti 免费额度约 25 页/IP，页访是稀缺资源。
# 单次任务页访预算；节点页访问历史持久化，NODE_REVISIT_DAYS 内绝不重复访问同一节点。
IY_PAGE_BUDGET=int(os.getenv('IY_PAGE_BUDGET','25'))
NODE_REVISIT_DAYS=int(os.getenv('NODE_REVISIT_DAYS','21'))
IY_REL_MAX_ROWS=int(os.getenv('IY_REL_MAX_ROWS','100'))  # 单节点关系区一次最多抓取的行数（尽量拿全该节点全部提票关系）
# v30.5 节点渗透：第一搜索在 ImportYeti 锁定节点后，递归展开关系网的深度与安全上限。
# 渗透残片不按 quantity 截断——第一阶段建完整图谱，数量闸门属于第二阶段。
IY_PENETRATION_DEPTH=int(os.getenv('IY_PENETRATION_DEPTH','2'))
IY_SEARCH_VARIANTS=int(os.getenv('IY_SEARCH_VARIANTS','3'))
COLLECT_MAX_NODES=int(os.getenv('COLLECT_MAX_NODES','300'))

# v30 风格兼容：core.config.settings 实例同步模块级 IY_*/COLLECT_* 常量
# （v6 的 core/config/__init__.py 导出 Settings 实例遮蔽模块；iy_web/hs_finder/customs_graph/sources/pipeline 按实例属性读取）
for _cfg_name in ("IY_WEB_ENABLED", "IY_WEB_HEADLESS", "IY_WEB_AUTO_HEADED", "IY_WEB_CHALLENGE_WAIT",
                  "IY_WEB_CDP_ENABLED", "IY_WEB_CDP_URL", "IY_WEB_DELAY_MIN", "IY_WEB_DELAY_MAX",
                  "IY_WEB_SEARCH_LIMIT", "IY_WEB_TOP_BUYERS", "IY_WEB_MAX_SUPPLIERS", "IY_WEB_MAX_CUSTOMERS",
                  "IY_SEARCH_VARIANTS", "IY_PENETRATION_DEPTH", "IY_REL_MAX_ROWS", "COLLECT_MAX_NODES"):
    if _cfg_name in globals():
        setattr(settings, _cfg_name, globals()[_cfg_name])
del _cfg_name
