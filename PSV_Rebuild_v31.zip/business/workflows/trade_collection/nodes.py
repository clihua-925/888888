"""Real deterministic and AI-assisted business nodes for PSV Trade OS 9.4.1."""

from __future__ import annotations

import json
import logging
import re
from copy import deepcopy
from difflib import SequenceMatcher
from typing import Any, Mapping

from core.config.industry import load_industry
from core.config.settings import ROOT
from core.contracts.state import TaskState
from core.contracts.context import get_data_provider, get_decision_provider
from core.contracts.decision_utils import unwrap_decision
from business.shared.text_utils import market_name as _market_name, hs_chapter as _hs_chapter
from core.tools import trade_filter, customs_graph
from core.tools import suppliers as suppliers_pool

LOGGER = logging.getLogger(__name__)

REPORT_STATUS_COMMITTED = "committed"

# Decision labels are business input values; the decision service itself is injected by orchestration.
DECISION_ENTITY_RESOLUTION = "entity_resolution"
DECISION_RELATIONSHIP_JUDGMENT = "relationship_judgment"
DECISION_EVIDENCE_VERIFICATION = "evidence_verification"
DECISION_EVIDENCE_VERIFICATION_BATCH = "evidence_verification_batch"
DECISION_RESOURCE_CLASSIFICATION = "resource_classification"
DECISION_PRODUCT_DEFINITION = "product_definition"
DECISION_TRADE_STRATEGY = "trade_strategy"


_PRODUCT_RULES: tuple[tuple[tuple[str, ...], str, str, tuple[str, ...]], ...] = (
    (("solar", "photovoltaic", "pv"), "Solar photovoltaic equipment", "8501", ("solar", "photovoltaic", "pv")),
    (("battery", "energy storage", "storage"), "Energy storage equipment", "8507", ("battery", "energy storage", "storage")),
    (("inverter", "inverters"), "Power inverter equipment", "8504", ("inverter", "power conversion")),
    (("semiconductor", "chip", "chips", "integrated circuit"), "Semiconductor components", "8542", ("semiconductor", "chip", "integrated circuit")),
    (("steel", "stainless steel", "steel product"), "Steel products", "7200", ("steel", "metal", "industrial")),
    (("aluminum", "aluminium"), "Aluminum products", "7600", ("aluminum", "metal", "industrial")),
    (("coffee", "cocoa", "cacao", "tea"), "Agricultural beverage products", "0900", ("agricultural", "beverage", "food")),
    (("machinery", "machine", "equipment", "industrial equipment"), "Industrial machinery and equipment", "8400", ("machinery", "equipment", "industrial")),
    (("textile", "apparel", "garment", "clothing"), "Textile and apparel products", "6100", ("textile", "apparel", "garment")),
    (("plastic", "polymer", "resin"), "Plastic and polymer products", "3900", ("plastic", "polymer", "resin")),
)


_COUNTRY_BY_MARKET = {
    "us": "United States",
    "usa": "United States",
    "united states": "United States",
    "china": "China",
    "cn": "China",
    "germany": "Germany",
    "de": "Germany",
    "japan": "Japan",
    "jp": "Japan",
    "south korea": "South Korea",
    "korea": "South Korea",
    "uk": "United Kingdom",
    "united kingdom": "United Kingdom",
    "france": "France",
    "italy": "Italy",
    "singapore": "Singapore",
    "india": "India",
    "vietnam": "Vietnam",
    "australia": "Australia",
    "canada": "Canada",
    "mexico": "Mexico",
    "brazil": "Brazil",
}


def _industry_profile(industry: str) -> Mapping[str, Any]:
    """Load optional bundled industry metadata without affecting orchestration."""
    try:
        profile = load_industry(industry)
    except (OSError, ValueError, TypeError):
        return {}
    return profile if isinstance(profile, Mapping) else {}


def _mission_text(mission: Mapping[str, Any]) -> str:
    values = [
        mission.get("objective", ""),
        mission.get("task_type", ""),
        mission.get("intent", ""),
        mission.get("industry", ""),
        mission.get("market", ""),
    ]
    targets = mission.get("targets", [])
    if isinstance(targets, (list, tuple)):
        values.extend(str(item) for item in targets)
    return " ".join(str(item) for item in values if item).strip()


def _target_values(mission: Mapping[str, Any]) -> list[str]:
    targets = mission.get("targets", [])
    if isinstance(targets, str):
        candidates = re.split(r"[,;|/]+", targets)
    elif isinstance(targets, (list, tuple, set)):
        candidates = [str(item) for item in targets]
    else:
        candidates = []
    cleaned = [item.strip() for item in candidates if item and item.strip()]
    return list(dict.fromkeys(cleaned))


def _keywords_for_product(text: str, industry: str) -> list[str]:
    lowered = text.lower()
    keywords: list[str] = []
    for triggers, _, _, rule_keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            keywords.extend(rule_keywords)
    if industry:
        keywords.append(industry.strip().lower())
    if not keywords:
        words = re.findall(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}", lowered)
        keywords.extend(words[:6])
    return list(dict.fromkeys(keyword for keyword in keywords if keyword))[:12]


def _product_rule(text: str) -> tuple[str, str, tuple[str, ...]]:
    lowered = text.lower()
    for triggers, product_name, hs_code, keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            return product_name, hs_code, keywords
    targets = _target_values({"targets": [text]})
    product_name = targets[0] if targets else "Target trade product"
    return product_name, "UNSPECIFIED", ()


def _decision_provider(state: TaskState) -> Any:
    """Return the process-local orchestration decision service."""
    candidate = get_decision_provider()
    if not callable(getattr(candidate, "decide", None)):
        raise RuntimeError("Decision provider runtime context is invalid")
    return candidate


def _decision_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, Mapping):
        for key in ("verified", "merge", "related", "match", "relevant", "approve"):
            if key in value:
                return bool(value[key])
        return False
    if isinstance(value, str):
        return value.strip().lower() in {"true", "yes", "verified", "merge", "related", "match", "approve"}
    return bool(value) if isinstance(value, (int, float)) else False


def _decision_text(value: Any, default: str = "") -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        for key in ("rationale", "verification_reason", "canonical_name", "resource_class"):
            item = value.get(key)
            if item:
                return str(item)
    return default


def _decision_value(result: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    decision = result.get("decision")
    if isinstance(decision, Mapping):
        for key in keys:
            if key in decision:
                return decision[key]
    metadata = result.get("metadata")
    if isinstance(metadata, Mapping):
        for key in keys:
            if key in metadata:
                return metadata[key]
    for key in keys:
        if key in result:
            return result[key]
    return default


_VALID_QUERY_ANGLES = {"buyer", "supplier", "market", "general"}


def _normalize_query_plan(raw: Any) -> list:
    """Validate AI query plan -> [(query, angle, language)] with dedupe and caps."""
    out: list[tuple[str, str, str]] = []
    seen: set[str] = set()
    if not isinstance(raw, (list, tuple)):
        return out
    for item in raw:
        if isinstance(item, str):
            query, angle, lang = item, "general", ""
        elif isinstance(item, Mapping):
            query = str(item.get("query") or "").strip()
            angle = str(item.get("angle") or "general").strip().lower()
            lang = str(item.get("language") or "").strip()
        else:
            continue
        if not query or len(query) > 120 or query.lower() in seen:
            continue
        if angle not in _VALID_QUERY_ANGLES:
            angle = "general"
        seen.add(query.lower())
        out.append((query, angle, lang))
        if len(out) >= 12:
            break
    return out


def _product_definition_prompt(mission_text: str, market: str, industry: str,
                               target_text: str, product_name: str,
                               keywords: list, hs_code: str,
                               target_customer: str) -> str:
    return (
        "You are defining a trade product for customs-data buyer discovery.\n"
        f"Mission: {mission_text or '(unspecified)'}\n"
        f"Target market: {market or '(unspecified)'}\n"
        f"Industry: {industry or '(unspecified)'}\n"
        f"Request/target hints: {target_text or '(none)'}\n"
        f"Deterministic draft (may be wrong - verify and improve it): "
        f"name={product_name}, hs_code={hs_code}, keywords={keywords}, customer={target_customer}\n\n"
        "Tasks:\n"
        "1. Identify the exact trade product. Be precise: the product name must be a real "
        "B2B tradable product, never the whole request sentence.\n"
        "2. Determine the primary language of the target market. Give the product name and "
        "a one-sentence description IN THAT LANGUAGE (product_name_local, description_local). "
        "Search and outreach downstream depend on these local terms.\n"
        "3. Provide 4-10 English keywords for customs/search systems, plus 3-8 "
        "local_search_terms: queries exactly as a local buyer would type them "
        "(synonyms, category names, trade/HS-style descriptions).\n"
        "4. Guess the HS code (2-6 digits) when reasonably inferable, else 'UNSPECIFIED'.\n"
        "5. State the target customer type: importers/distributors/wholesalers, retailers, "
        "or manufacturers.\n"
        "Be concise: the entire JSON must fit within 400 words.\nReturn the structured decision exactly per schema."
    )


def _trade_strategy_prompt(product: Mapping, fragments: list) -> str:
    draft = {k: product.get(k) for k in (
        "product_name", "product_name_local", "description", "description_local",
        "market_language", "keywords", "local_search_terms",
        "hs_code_guess", "market", "industry", "target_customer_type",
    )}
    return (
        "You are planning how to SEARCH a customs database (US import records) to find "
        "real buyers and suppliers for the product below.\n"
        f"Product definition: {json.dumps(draft, ensure_ascii=False)}\n"
        f"Draft fragments: {json.dumps(fragments, ensure_ascii=False)}\n\n"
        "Tasks:\n"
        "1. Produce 4-10 concrete search queries. Each query has: query text, angle "
        "(buyer/supplier/market), language code (en/es/de/ja/... or the market language).\n"
        "Query design rules learned in production:\n"
        "- Use exact product/category terms a customs record would contain.\n"
        "- Do NOT include company suffixes (llc, inc, ltd) and do NOT paste the "
        "market/country name into the query.\n"
        "- Cover multiple angles: exact product name, general category term, HS-style "
        "term, local-language term, and use-case term.\n"
        "- Keep queries short (1-4 words ideally, 8 maximum).\n"
        "- ImportYeti contains US ENGLISH import records only: every query must be in "
        "English. Market-language terms belong to non-customs channels.\n"
        "2. buyer_focus_terms / supplier_focus_terms: which terms signal a buyer vs a "
        "supplier in this trade.\n"
        "3. hs_chapters: 2-digit HS chapters worth checking.\n"
        "Be concise: the entire JSON must fit within 400 words.\nReturn the structured decision exactly per schema."
    )


def _std_keywords(product: Mapping[str, Any]) -> list[str]:
    """从 product_name/industry/keywords/product_terms 生成规范化关键词列表。"""
    raw: list[str] = []
    for key in ("product_name", "industry", "product_terms"):
        value = product.get(key)
        if isinstance(value, str) and value.strip():
            raw.append(value.strip())
        elif isinstance(value, list):
            raw.extend(str(v).strip() for v in value if str(v).strip())
    value = product.get("keywords")
    if isinstance(value, list):
        raw.extend(str(v).strip() for v in value if str(v).strip())
    elif isinstance(value, str) and value.strip():
        raw.append(value.strip())
    seen: set[str] = set()
    out: list[str] = []
    for kw in raw:
        key = kw.lower()
        if key and key not in seen:
            seen.add(key)
            out.append(kw)
    return out


def _std_hs_chapters(product: Mapping[str, Any]) -> set[str]:
    """从 hs_code / hs_codes 生成 HS 章节前缀集合（前 2 位数字）。"""
    codes: list[str] = []
    for key in ("hs_code", "hs_codes"):
        value = product.get(key)
        if isinstance(value, str) and value.strip():
            codes.append(value.strip())
        elif isinstance(value, list):
            codes.extend(str(v).strip() for v in value if str(v).strip())
    chapters: set[str] = set()
    for code in codes:
        digits = "".join(ch for ch in code if ch.isdigit())
        if len(digits) >= 2:
            chapters.add(digits[:2])
    return chapters


def _record_hs_chapter(item: Mapping[str, Any]) -> str:
    """从 item 的 hs_code / hs / metadata.hs_code 提取章节前缀，返回 str。"""
    candidates = [item.get("hs_code"), item.get("hs")]
    metadata = item.get("metadata")
    if isinstance(metadata, Mapping):
        candidates.append(metadata.get("hs_code"))
    for value in candidates:
        if not value:
            continue
        digits = "".join(ch for ch in str(value) if ch.isdigit())
        if len(digits) >= 2:
            return digits[:2]
    return ""


def _normalize_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _entity_id_for_node(node: Mapping[str, Any], index: int) -> str:
    existing = str(node.get("entity_id", "")).strip()
    if existing:
        return existing
    node_id = str(node.get("node_id", "")).strip()
    if node_id:
        return f"ENTITY_{node_id}"
    return f"ENTITY_{index + 1}"


def _entity_map(entities: list[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    return {
        str(entity.get("entity_id")): entity
        for entity in entities
        if entity.get("entity_id")
    }


def PRODUCT_DEFINITION(state: TaskState) -> TaskState:
    """V31 编排层：接收 state → 调 Product Definition Service → 更新 state。"""
    result = dict(state)
    mission = dict(result.get("mission") or {})
    product = str(mission.get("industry") or "").strip()
    market = str(mission.get("market") or "").strip()
    supply = str(mission.get("supply_country") or "China").strip() or "China"
    if not product:
        result["error"] = "PRODUCT_DEFINITION: empty industry in mission"
        return result
    provider = _decision_provider(result)
    from business.product.product_definition_service import generate as generate_product
    out = generate_product(product, market, supply, provider)
    result["product_definition"] = out["product_definition"]
    result["decisions"] = list(result.get("decisions") or []) + [{
        "decision_type": DECISION_PRODUCT_DEFINITION,
        "decision": {"segments": [s["name_en"] for s in out["product_definition"].get("product_segments") or []],
                     "locked_count": len(out["product_definition"].get("locked_detail") or [])},
    }]
    reports = dict(result.get("node_reports") or {})
    reports["PRODUCT_DEFINITION"] = out["report"]
    result["node_reports"] = reports
    return result


def TRADE_STRATEGY(state: TaskState) -> TaskState:
    """V31 编排层：接收 state → 调 Trade Strategy Service → 更新 fragments/search_queries。"""
    result = dict(state)
    mission = dict(result.get("mission") or {})
    market = str(mission.get("market") or "").strip()
    supply = str(mission.get("supply_country") or "China").strip() or "China"
    product = str(mission.get("industry") or "").strip()
    pd = dict(result.get("product_definition") or {})
    locked = pd.get("locked_detail") or [
        {"category": "", "subcategory": s, "application": ""}
        for s in (pd.get("locked_subcategories") or [])
    ]
    provider = _decision_provider(result)
    from business.trade.trade_strategy_service import generate as generate_strategy
    out = generate_strategy(pd, locked, market, supply, product, provider)
    result["fragments"] = out["fragments"]
    result["search_queries"] = out["search_queries"]
    reports = dict(result.get("node_reports") or {})
    reports["TRADE_STRATEGY"] = out["report"]
    result["node_reports"] = reports
    return result


def CUSTOMS_NODE_COLLECTION(state: TaskState) -> TaskState:
    """按前两个环节确立采集标准，宽松判断后只保留标准化客户/供应商信息。

    简化版：PRODUCT_DEFINITION + TRADE_STRATEGY 的产物在此被消费为采集标准
    （产品词 / HS 章 / 市场 / 行业 / 标准角色）；本地记录宽松匹配后仅保留
    标准 schema 的实体；策略碎片不再向下游传递。
    """
    result = deepcopy(state)
    product = dict(result.get("product_definition", {}))
    market = _market_name(product.get("market", "")) or "Target market"
    industry = str(product.get("industry", "")).strip()
    product_name = str(product.get("product_name", "Target trade product"))

    # 1) 采集标准（来自前两个环节）
    std_keywords = _std_keywords(product)
    std_hs = _std_hs_chapters(product)
    std_roles = {"buyer", "supplier", "importer", "exporter"}
    # V20：以 fragments 为权威源构建带 segment 的查询计划（Node2 分段输出）
    query_plan: list[dict] = []
    for _f in (result.get("fragments") or []):
        _seg = str(_f.get("segment") or "")
        for _k in (_f.get("keywords") or []):
            _k = str(_k).strip()
            if _k:
                query_plan.append({"query": _k, "segment": _seg})
    if not query_plan:
        query_plan = [{"query": str(q).strip(), "segment": ""}
                      for q in (result.get("search_queries") or []) if str(q).strip()]
    search_queries = [p["query"] for p in query_plan]

    existing_nodes = list(result.get("trade_nodes", []))
    existing_evidence = list(result.get("evidence_pool", []))
    existing_node_ids = {str(item.get("node_id")) for item in existing_nodes}
    existing_evidence_ids = {str(item.get("evidence_id")) for item in existing_evidence}

    def _accept_record(item: Any) -> bool:
        """与下方过滤同标准：名字有效 + 标准角色 + 任一信号命中（宽松）。"""
        if not isinstance(item, Mapping):
            return False
        name = str(item.get("name") or item.get("company") or "").strip()
        if len(name) < 2 or name.lower() in {"unknown", "n/a", "null"}:
            return False
        role = str(item.get("role") or "").strip().lower()
        if role not in std_roles:
            return False
        country = _market_name(item.get("country") or market)
        rec_industry = str(item.get("industry") or industry).strip()
        hs_chapter = _record_hs_chapter(item)
        meta = item.get("metadata") if isinstance(item.get("metadata"), Mapping) else {}
        meta_text = " ".join(str(v).lower() for v in meta.values())
        if country == market:
            return True
        if hs_chapter and hs_chapter in std_hs:
            return True
        if std_keywords and any(k in name.lower() or k in meta_text for k in std_keywords):
            return True
        if industry and rec_industry.lower() == industry.lower():
            return True
        return False

    from business.shared.import_sources import load_import_records_diag
    records, source_diag = load_import_records_diag(
        str(product.get("market", "")), str(product.get("industry", "")),
        queries=search_queries or None, accept=_accept_record, full=True,
    )

    # ===== V31 编排层：collector → extractor → normalizer（数据库唯一来源，无内存兜底）=====
    extracted_entities: list[dict[str, Any]] = []
    browser_diag: dict = {"snapshots": [], "errors": [], "queries": {}}
    silver_error = ""
    extracted_saved = 0
    edges_saved = 0
    _task_id = str(result.get("task_id") or "")
    _fetched: list[dict[str, Any]] = []
    try:
        from business.trade.import_collector import ImportCollector
        _fetched, browser_diag = ImportCollector().collect(
            query_plan=query_plan, market=str(product.get("market") or ""),
            industry=str(product.get("industry") or ""), limit=int(limit or 200),
            task_id=_task_id)
    except Exception as exc:
        silver_error = f"pipeline:{type(exc).__name__}"
    if _fetched:
        from business.trade.trade_extractor import TradeExtractor
        _persist = TradeExtractor().persist(_task_id, _fetched)
        extracted_saved = int(_persist.get("saved") or 0)
        edges_saved = int(_persist.get("edges") or 0)
        silver_error = silver_error or str(_persist.get("error") or "")
    if _task_id and not silver_error:
        from business.trade.entity_normalizer import EntityNormalizer
        extracted_entities = EntityNormalizer().load_validated(_task_id)
    elif not _task_id:
        silver_error = silver_error or "silver:no_task_id"
    entities_validated = len(extracted_entities)
    if not extracted_entities:
        LOGGER.warning("CUSTOMS_NODE_COLLECTION V31: no validated entities in DB -> degraded/no_data")

    # Graph Builder：validated entities -> trade_nodes 原料（Gold 出口）
    from business.trade.graph_builder import GraphBuilder
    primary_nodes: list[dict[str, Any]] = GraphBuilder().build_nodes(
        extracted_entities,
        market=str(product.get("market") or ""),
        industry=str(product.get("industry") or ""),
        supply_country=str(dict(result.get("mission") or {}).get("supply_country") or "China"))

    # ---- v30.5 采集增强恢复：trade_filter 硬证据信号 + customs_graph 本地买方→供应商扩展 ----
    signal_kept = 0
    for node in source_nodes:
        if trade_filter.has_keep_signal({
            "type": "trade_node",
            "evidence": {"shipments": int(node.get("shipments") or 0),
                         "hs": str((node.get("metadata") or {}).get("hs_code") or "")},
        }):
            signal_kept += 1
    expanded = 0
    try:
        buyer_names = [n.get("name") for n in source_nodes if str(n.get("role") or "") == "buyer"]
        rel = customs_graph.buyer_to_suppliers(buyer_names[:20]) or {}
        existing = {str(n.get("name") or "").lower() for n in source_nodes}
        for buyer_key, supplier_rows in (rel.items() if isinstance(rel, dict) else []):
            for row in (supplier_rows or []):
                sname = str((row or {}).get("name") or (row or {}).get("shipper") or "").strip()
                if not sname or sname.lower() in existing:
                    continue
                existing.add(sname.lower())
                source_nodes.append({
                    "node_id": f"IYC_{len(source_nodes)+1:04d}",
                    "name": sname, "role": "supplier",
                    "country": str((result.get("mission") or {}).get("supply_country") or "China"),
                    "source": "customs_graph", "shipments": int((row or {}).get("shipments") or 0),
                    "industry": str(product.get("industry") or ""),
                    "metadata": {"buyer": str(buyer_key), "slug": suppliers_pool.slugify(sname),
                                 "norm": suppliers_pool.norm(sname)},
                })
                expanded += 1
    except Exception as exc:
        LOGGER.warning("CUSTOMS_NODE_COLLECTION customs_graph expansion failed: %s", exc)


    # 3) 采集失败（records 为空或全部被过滤）：如实上报，绝不生成 SYNTHETIC_*
    # 占位节点冒充成功——假数据会污染实体归一/关系构建/开发信全链；
    # 空证据链由 EVIDENCE_VERIFY 证据门拦截，失败在此透明暴露并保留诊断。
    collection_note = ""
    if not source_nodes:
        # 诊断信息由节点报告承载：sources(各级明细) + errors + 本行 note
        collection_note = f"collection_failed: all sources empty or filtered; errors={list(source_diag.get('errors') or [])}"

    for node in source_nodes:
        node_id = str(node.get("node_id") or "").strip()
        if not node_id or node_id in existing_node_ids:
            continue
        existing_nodes.append(node)
        existing_node_ids.add(node_id)

    # 4) 标准证据（不再携带 strategy_fragments）
    for index, node in enumerate(existing_nodes, start=1):
        node_id = str(node.get("node_id") or f"TRADE_NODE_{index:03d}")
        node["node_id"] = node_id
        evidence_id = f"EVIDENCE_{node_id}"  # 确定性ID：续跑/重试不产生重复或缺失证据
        if evidence_id in existing_evidence_ids:
            continue
        meta = node.get("metadata") if isinstance(node.get("metadata"), Mapping) else {}
        source_url = str(meta.get("detail_url") or meta.get("url") or source_diag.get("current_url") or "")
        existing_evidence.append({
            "evidence_id": evidence_id,
            "entity_name": str(node.get("name", "")),
            "evidence_type": "trade_record",
            "source": str(node.get("source", "local_import")),
            "source_url": source_url,
            "shipments": int(node.get("shipments", 0) or 0),
            "verified": False,
            "evidence_json": {
                "node_id": node_id,
                "product": product_name,
                "market": market,
                "hs_code": str(meta.get("hs_code", "")),
                "matched_by": list(meta.get("matched_by", [])),
                "url": source_url,
                "raw_html": str(meta.get("raw_html", ""))[:50000],
                "query": str(meta.get("query", "")),
                "snapshot_at": str(meta.get("snapshot_at", "")),
                "evidence": str(meta.get("evidence", "")),
                "supplier": str(meta.get("supplier", "")),
                "segment": str(meta.get("segment", "")),
                "snapshot_file": str(meta.get("snapshot_file", "")),
            },
        })
        existing_evidence_ids.add(evidence_id)

    result["trade_nodes"] = existing_nodes
    result["evidence_pool"] = existing_evidence
    result["fragments"] = []  # 碎片已被采集标准消费，不再向下游传递
    reports = dict(result.get("node_reports", {}))
    reports["CUSTOMS_NODE_COLLECTION"] = {
        "status": "ok" if source_nodes else "failed",
        "sources": source_diag, "nodes": len(existing_nodes),
        "synthetic": False, "queries": search_queries,
        "success": bool(source_nodes), "collection_failed": not source_nodes,
        "errors": list(source_diag.get("errors") or []),
        "per_query": dict(source_diag.get("per_query") or {}),
        "signal_kept": signal_kept, "customs_graph_expanded": expanded,
        "dropped_invalid": dropped_invalid,
        "v18_primary_ai": len(primary_nodes),
        "raw_pages_saved": int((browser_diag or {}).get("raw_pages_saved") or 0),
        "extracted_entities_saved": extracted_saved,
        "entities_validated": entities_validated,
        "edges_saved": edges_saved,
        "silver_error": silver_error,
        "degraded_no_data": not extracted_entities,
        "v18_browser": {"snapshots": len(browser_diag.get("snapshots") or []),
                        "errors": list(browser_diag.get("errors") or [])[:8],
                        "queries": dict(browser_diag.get("queries") or {})},
        "supplier_nodes": [{"name": n.get("name"), "type": "supplier", "country": n.get("country"),
                            "shipments": n.get("shipments"), "segment": str((n.get("metadata") or {}).get("segment") or ""),
                            "evidence": str((n.get("metadata") or {}).get("evidence") or "")}
                           for n in existing_nodes if str(n.get("role") or "") == "supplier"],
        "buyer_nodes": [{"name": n.get("name"), "type": "buyer", "country": n.get("country"),
                         "shipments": n.get("shipments"), "segment": str((n.get("metadata") or {}).get("segment") or ""),
                         "evidence": str((n.get("metadata") or {}).get("evidence") or "")}
                        for n in existing_nodes if str(n.get("role") or "") == "buyer"],
        "trade_edges": [{"supplier": str((n.get("metadata") or {}).get("supplier") or ""),
                         "buyer": n.get("name"), "evidence": str((n.get("metadata") or {}).get("evidence") or "")}
                        for n in existing_nodes if str((n.get("metadata") or {}).get("supplier") or "")],
        "collection_plan": dict((result.get("node_reports") or {}).get("TRADE_STRATEGY") or {}).get("collection_plan") or [],
        "source_diag": dict(source_diag),
        "supply_country": str(dict(result.get("mission") or {}).get("supply_country") or "China"),
        "note": collection_note if not source_nodes else "",
    }
    result["node_reports"] = reports
    return result

_RELATION_TYPE_WHITELIST = {
    "buyer-seller", "buyer-supplier", "supplier-customer", "supplier-buyer",
    "importer-exporter", "importer-supplier", "customer-supplier",
    "trade_partner_candidate", "trade_partner", "network_expansion", "trade",
}


def TRADE_EDGE_BUILD(state: TaskState) -> TaskState:
    """Use the decision provider to judge candidate buyer-seller relationships."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence = list(result.get("evidence_pool", []))
    relationships = list(result.get("relationships", []))
    entities = list(result.get("entities", []))
    ai = _decision_provider(result)
    skipped_edges = 0
    entity_by_id = _entity_map(entities)
    node_to_entity: dict[str, Mapping[str, Any]] = {}
    for entity in entities:
        metadata = entity.get("metadata", {})
        if isinstance(metadata, Mapping):
            for source_node_id in metadata.get("merged_from", []):
                node_to_entity[str(source_node_id)] = entity

    role_pairs = {
        ("buyer", "supplier"),
        ("buyer", "exporter"),
        ("importer", "supplier"),
        ("importer", "exporter"),
    }

    existing_edges = {str(item.get("edge_id")) for item in relationships}
    evidence_by_name = {
        str(item.get("entity_name", "")): item
        for item in evidence
    }

    for left_index, left in enumerate(nodes):
        for right_index in range(left_index + 1, len(nodes)):
            right = nodes[right_index]
            pair = (
                str(left.get("role", "")).lower(),
                str(right.get("role", "")).lower(),
            )
            reverse_pair = (pair[1], pair[0])
            if pair not in role_pairs and reverse_pair not in role_pairs:
                continue

            left_node_id = str(left.get("node_id") or f"SYNTHETIC_NODE_{left_index + 1:03d}")
            right_node_id = str(right.get("node_id") or f"SYNTHETIC_NODE_{right_index + 1:03d}")
            left_entity_record = node_to_entity.get(left_node_id)
            right_entity_record = node_to_entity.get(right_node_id)
            left_id = str(
                left_entity_record.get("entity_id")
                if left_entity_record
                else _entity_id_for_node(left, left_index)
            )
            right_id = str(
                right_entity_record.get("entity_id")
                if right_entity_record
                else _entity_id_for_node(right, right_index)
            )
            left_entity = entity_by_id.get(left_id, left)
            right_entity = entity_by_id.get(right_id, right)
            prompt = (
                "Judge whether these two trade entities have a commercially plausible "
                "buyer-seller or importer-exporter relationship. Use the supplied roles, "
                "countries, shipment counts, and evidence. Do not infer a relationship "
                "solely because both entities exist."
            )
            payload = {
                "source": left_entity or left,
                "target": right_entity or right,
                "source_role": left.get("role"),
                "target_role": right.get("role"),
                "source_country": left.get("country"),
                "target_country": right.get("country"),
                "source_shipments": left.get("shipments", 0),
                "target_shipments": right.get("shipments", 0),
                "source_evidence": evidence_by_name.get(str(left.get("name", "")), {}),
                "target_evidence": evidence_by_name.get(str(right.get("name", "")), {}),
            }
            decision = ai.decide(
                result,
                DECISION_RELATIONSHIP_JUDGMENT,
                prompt,
                payload,
            )
            accepted = _decision_bool(decision.get("decision"))
            confidence = float(decision.get("confidence", 0.0))
            if not accepted or confidence < 0.5:
                continue

            if left_id == right_id:
                continue  # 自环边无业务含义（同一实体不与自己构成买卖关系）
            edge_id = f"EDGE_{left_id}_{right_id}"
            if edge_id in existing_edges:
                continue

            relation_type = _decision_value(
                decision,
                "relation_type",
                "relationship_type",
                default="trade_partner_candidate",
            )
            # schema 校验层：关系类型受控词表 + 置信度归一（前沿做法：LLM 输出视为候选，过校验才入库）
            if str(relation_type).lower() not in _RELATION_TYPE_WHITELIST:
                skipped_edges += 1
                continue
            try:
                confidence = min(1.0, max(0.0, float(confidence)))
            except (TypeError, ValueError):
                confidence = 0.5
            rationale = str(
                decision.get(
                    "rationale",
                    _decision_text(decision.get("decision")),
                )
            )
            evidence_ids = []
            for node in (left, right):
                evidence_item = evidence_by_name.get(str(node.get("name", "")))
                if evidence_item and evidence_item.get("evidence_id"):
                    evidence_ids.append(str(evidence_item["evidence_id"]))

            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": left_id,
                    "target_entity_id": right_id,
                    "relation_type": str(relation_type),
                    "confidence": confidence,
                    "evidence_ids": evidence_ids,
                    "rationale": rationale,
                    "source_node_id": left_node_id,
                    "target_node_id": right_node_id,
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result


def EVIDENCE_VERIFY(state: TaskState) -> TaskState:
    """Use the decision provider to verify every evidence item in the shared pool."""
    result = deepcopy(state)
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_provider(result)

    # 批量核验优先：本地推理模型调用昂贵，N 条一次调用；返回不合规则逐条回退
    batch_verdicts: dict[int, Mapping] = {}
    try:
        batch = ai.decide(
            result,
            DECISION_EVIDENCE_VERIFICATION_BATCH,
            (
                "Verify every evidence item in the provided list for internal coherence and "
                "whether it supports the stated trade entity. Return a JSON object with a "
                "'verdicts' array; each element must contain: index (integer, 0-based), "
                "verified (boolean), verification_reason (string), issues (array of strings). "
                "Also include top-level 'verified': true and 'issues': [] to satisfy the schema."
            ),
            {"evidence_items": evidence_pool, "trade_nodes": result.get("trade_nodes", [])},
        )
        if isinstance(batch, Mapping):
            raw = unwrap_decision(batch)  # 包装器/内层双兼容（统一走 decision_utils）
            if isinstance(raw, Mapping) and isinstance(raw.get("verdicts"), list):
                for item in raw["verdicts"]:
                    if isinstance(item, Mapping) and isinstance(item.get("index"), int):
                        batch_verdicts[item["index"]] = item
    except Exception as exc:
        LOGGER.warning("EVIDENCE_VERIFY batch failed, falling back to per-item: %s", exc)
        batch_verdicts = {}

    def _apply_verdict(evidence: dict, verified: Any, confidence: float, reason: Any, issues: Any) -> None:
        if isinstance(verified, str):
            verified = verified.strip().lower() in {"true", "yes", "verified"}
        if isinstance(issues, str):
            issues = [issues]
        elif not isinstance(issues, list):
            issues = [str(issues)] if issues else []
        evidence["verified"] = bool(verified)
        evidence["verification_confidence"] = float(confidence)
        evidence["verification_reason"] = str(reason or "")
        evidence["issues"] = issues

    per_item_budget = 5  # 本地模型单次调用约2分钟：限制逐条回退条数，避免节点长时间挂起
    per_item_used = 0
    for index, evidence in enumerate(evidence_pool):
        if index in batch_verdicts:
            verdict = batch_verdicts[index]
            raw_conf = verdict.get("confidence")
            if raw_conf is None:
                LOGGER.warning("EVIDENCE_VERIFY verdict missing confidence, default 0.5: evidence_id=%s", evidence.get("evidence_id"))
                raw_conf = 0.5
            try:
                conf = float(raw_conf)
            except (TypeError, ValueError):
                conf = 0.5
            _apply_verdict(
                evidence,
                verdict.get("verified", False),
                conf,
                verdict.get("verification_reason", ""),
                verdict.get("issues", []),
            )
            continue
        if per_item_used >= per_item_budget:
            if not evidence.get("verification_reason"):
                evidence["verification_reason"] = "deferred: per-item verification budget"
                evidence.setdefault("issues", [])
            continue
        per_item_used += 1
        try:
            prompt = (
                "Verify whether this evidence is internally coherent and sufficiently supports "
                "the stated trade entity. Return a boolean verification judgment, a confidence "
                "score, a concise verification reason, and any material issues."
            )
            decision = ai.decide(
                result,
                DECISION_EVIDENCE_VERIFICATION,
                prompt,
                {
                    "evidence": evidence,
                    "trade_nodes": result.get("trade_nodes", []),
                },
            )
            verified = _decision_value(
                decision,
                "verified",
                default=_decision_bool(decision.get("decision")),
            )
            if isinstance(verified, str):
                verified = verified.strip().lower() in {"true", "yes", "verified"}

            issues = _decision_value(
                decision,
                "issues",
                default=decision.get("metadata", {}).get("issues", [])
                if isinstance(decision.get("metadata"), Mapping)
                else [],
            )
            if isinstance(issues, str):
                issues = [issues]
            elif not isinstance(issues, list):
                issues = [str(issues)] if issues else []

            reason = _decision_value(
                decision,
                "verification_reason",
                default=decision.get("rationale", ""),
            )
            _apply_verdict(evidence, verified, float(decision.get("confidence", 0.0)), reason, issues)
        except Exception as exc:  # 单次核验失败不拖垮整个节点
            LOGGER.warning("EVIDENCE_VERIFY per-item failed: evidence_id=%s error=%s", evidence.get("evidence_id"), exc)
            evidence["verification_reason"] = f"verify_failed: {type(exc).__name__}"
            evidence.setdefault("issues", [])
            continue

    result["evidence_pool"] = evidence_pool
    return result


def ENTITY_RESOLUTION(state: TaskState) -> TaskState:
    """Resolve similar trade nodes into canonical entities using AI judgment."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_provider(result)

    parent: dict[str, str] = {}
    node_records: dict[str, dict[str, Any]] = {}

    for index, node in enumerate(nodes):
        node_id = str(node.get("node_id") or f"SYNTHETIC_NODE_{index + 1:03d}")
        node_records[node_id] = node
        parent[node_id] = node_id

    def find(node_id: str) -> str:
        current = node_id
        while parent[current] != current:
            parent[current] = parent[parent[current]]
            current = parent[current]
        return current

    def merge(first: str, second: str) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parent[second_root] = first_root

    candidates: list[tuple[str, str]] = []
    resolution_overrides: dict[str, dict[str, Any]] = {}
    for left_index, left in enumerate(nodes):
        left_name = _normalize_name(left.get("name"))
        for right in nodes[left_index + 1 :]:
            right_name = _normalize_name(right.get("name"))
            if not left_name or not right_name:
                continue
            similarity = SequenceMatcher(None, left_name, right_name).ratio()
            same_country = str(left.get("country", "")).lower() == str(right.get("country", "")).lower()
            same_role = str(left.get("role", "")).lower() == str(right.get("role", "")).lower()
            if similarity >= 0.65 or (same_country and same_role and similarity >= 0.45):
                candidates.append((str(left.get("node_id")), str(right.get("node_id"))))

    for left_id, right_id in candidates:
        left = node_records[left_id]
        right = node_records[right_id]
        decision = ai.decide(
            result,
            DECISION_ENTITY_RESOLUTION,
            (
                "Determine whether the two supplied trade records represent the same "
                "underlying entity. If they are duplicates, provide a canonical name. "
                "Use name similarity, role, country, and evidence context."
            ),
            {
                "left": left,
                "right": right,
                "evidence_pool": evidence_pool,
            },
        )
        should_merge = _decision_value(
            decision,
            "merge",
            default=_decision_bool(decision.get("decision")),
        )
        if isinstance(should_merge, str):
            should_merge = should_merge.strip().lower() in {"true", "yes", "merge"}
        if bool(should_merge) and float(decision.get("confidence", 0.0)) >= 0.5:
            root_left, root_right = find(left_id), find(right_id)
            if root_left != root_right:
                left_group = sum(1 for nid in parent if find(nid) == root_left)
                right_group = sum(1 for nid in parent if find(nid) == root_right)
                if left_group > 1 or right_group > 1:
                    # verified merge：跨既有簇合并必须二次确认（前沿教训：单条假阳性经传递闭包污染全团）
                    confirm = ai.decide(
                        result,
                        DECISION_ENTITY_RESOLUTION,
                        (
                            "Re-examine carefully: these two groups of trade records are about to be "
                            "merged into one entity. Confirm ONLY if you are confident they are the same "
                            "real-world company. Answer merge=true only with strong evidence."
                        ),
                        {"left": left, "right": right,
                         "left_group_size": left_group, "right_group_size": right_group},
                    )
                    if not isinstance(confirm, Mapping):
                        continue  # 确认调用失败/无响应：保守跳过合并
                    confirm_merge = _decision_value(confirm, "merge", default=False)
                    if isinstance(confirm_merge, str):
                        confirm_merge = confirm_merge.strip().lower() in {"true", "yes", "merge"}
                    if not bool(confirm_merge):
                        continue
            merge(left_id, right_id)
            canonical_name = _decision_value(decision, "canonical_name", default="")
            if canonical_name:
                resolution_overrides[find(left_id)] = {
                    "canonical_name": str(canonical_name).strip(),
                    "confidence": float(decision.get("confidence", 0.0)),
                    "rationale": str(decision.get("rationale", "")),
                }

    groups: dict[str, list[dict[str, Any]]] = {}
    for node_id, node in node_records.items():
        groups.setdefault(find(node_id), []).append(node)

    entities: list[dict[str, Any]] = []
    for index, group in enumerate(groups.values(), start=1):
        canonical = max(
            group,
            key=lambda item: int(item.get("shipments", 0) or 0),
        )
        merged_from = [str(item.get("node_id")) for item in group]
        confidence = 1.0 if len(group) == 1 else 0.75
        root_id = find(str(group[0].get("node_id")))
        override = resolution_overrides.get(root_id, {})
        canonical_name = str(override.get("canonical_name", "")).strip() or str(canonical.get("name", "")).strip()
        if override.get("confidence") is not None:
            confidence = float(override["confidence"])
        source_value = str(canonical.get("source") or "unknown")
        hs_value = str(canonical.get("hs_code") or "")
        if source_value == "unknown" and int(canonical.get("shipments", 0) or 0) == 0 and not hs_value:
            continue
        entity_id = f"ENTITY_{index:03d}"
        entities.append(
            {
                "entity_id": entity_id,
                "canonical_name": canonical_name,
                "role": canonical.get("role"),
                "country": canonical.get("country"),
                "source": source_value,
                "metadata": {
                    "confidence": confidence,
                    "merged_from": merged_from,
                    "shipments": sum(int(item.get("shipments", 0) or 0) for item in group),
                    "resolution_rationale": str(override.get("rationale", "")),
                },
            }
        )

    node_to_entity: dict[str, str] = {}
    for entity in entities:
        for source_id in entity["metadata"]["merged_from"]:
            node_to_entity[source_id] = entity["entity_id"]

    for relationship in result.get("relationships", []):
        source_id = str(relationship.get("source_node_id", ""))
        target_id = str(relationship.get("target_node_id", ""))
        if source_id in node_to_entity:
            relationship["source_entity_id"] = node_to_entity[source_id]
        if target_id in node_to_entity:
            relationship["target_entity_id"] = node_to_entity[target_id]

    result["entities"] = entities
    return result


def GRAPH_EXPANSION(state: TaskState) -> TaskState:
    """Add deterministic expanded relationships from existing canonical entities."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    existing_edges = {str(item.get("edge_id")) for item in relationships}

    for left_index, left in enumerate(entities):
        for right in entities[left_index + 1 :]:
            if not left.get("entity_id") or not right.get("entity_id"):
                continue
            same_country = str(left.get("country", "")).strip().lower() == str(right.get("country", "")).strip().lower()
            same_role = str(left.get("role", "")).strip().lower() == str(right.get("role", "")).strip().lower()
            if not same_country and not same_role:
                continue
            source_id = str(left["entity_id"])
            target_id = str(right["entity_id"])
            edge_id = f"EXPANDED_{source_id}_{target_id}"
            if edge_id in existing_edges:
                continue
            relation_type = "same_country_partner" if same_country else "same_role_network"
            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": source_id,
                    "target_entity_id": target_id,
                    "relation_type": relation_type,
                    "confidence": 0.55,
                    "evidence_ids": [],
                    "rationale": "Deterministic graph expansion from shared entity attributes.",
                    "metadata": {"expansion": "expanded"},
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result


def RESOURCE_CLASSIFICATION(state: TaskState) -> TaskState:
    """Classify every canonical entity with the decision provider."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_provider(result)

    for entity in entities:
        decision = ai.decide(
            result,
            DECISION_RESOURCE_CLASSIFICATION,
            (
                "Classify this trade entity by commercial resource value. Return a resource "
                "class, a priority value, confidence, and rationale. Consider role, country, "
                "relationship count, shipments, and verified evidence."
            ),
            {
                "entity": entity,
                "relationships": relationships,
                "evidence_pool": evidence_pool,
            },
        )
        resource_class = _decision_value(
            decision,
            "resource_class",
            "class",
            default="unclassified_resource",
        )
        priority = _decision_value(
            decision,
            "priority",
            default=decision.get("metadata", {}).get("priority", 3)
            if isinstance(decision.get("metadata"), Mapping)
            else 3,
        )
        entity.setdefault("metadata", {})
        entity["metadata"]["resource_class"] = str(resource_class)
        entity["metadata"]["priority"] = priority
        entity["metadata"]["classification_confidence"] = float(decision.get("confidence", 0.0))
        entity["metadata"]["classification_rationale"] = str(decision.get("rationale", ""))

    result["entities"] = entities
    return result


def DATABASE_COMMIT(state: TaskState) -> TaskState:
    """Commit finalized entities, relationships, and evidence through the data provider."""
    result = deepcopy(state)
    database = get_data_provider()
    if not callable(getattr(database, "commit_trade_data", None)):
        raise RuntimeError("DATABASE_COMMIT runtime database gateway is invalid")

    task_id = str(result.get("task_id", "")).strip()
    if not task_id:
        raise ValueError("DATABASE_COMMIT requires state['task_id']")

    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    evidence_pool = list(result.get("evidence_pool", []))

    counts = database.commit_trade_data(task_id, entities, relationships, evidence_pool)

    backend = getattr(database, "_database", None)
    post_commit_edge_rows = -1
    if backend is not None and callable(getattr(backend, "list_trade_relationships", None)):
        post_commit_edge_rows = len([
            row for row in backend.list_trade_relationships(limit=100000)
            if str(row.get("task_id") or "") == task_id
        ])

    reports = dict(result.get("node_reports", {}))
    reports["DATABASE_COMMIT"] = {
        "status": REPORT_STATUS_COMMITTED,
        "entity_count": counts.get("trade_entities", len(entities)),
        "relationship_count": counts.get("trade_edges", len(relationships)),
        "evidence_count": counts.get("evidence", len(evidence_pool)),
        "post_commit_edge_rows": post_commit_edge_rows,
        "entity_ids": [str(e.get("entity_id")) for e in entities][:20],
        "edge_ids": [str(r.get("edge_id")) for r in relationships][:20],
        "evidence_ids": [str(v.get("evidence_id")) for v in evidence_pool][:20],
    }
    result["node_reports"] = reports
    return result


NODE_FUNCTIONS = {
    "PRODUCT_DEFINITION": PRODUCT_DEFINITION,
    "TRADE_STRATEGY": TRADE_STRATEGY,
    "CUSTOMS_NODE_COLLECTION": CUSTOMS_NODE_COLLECTION,
    "TRADE_EDGE_BUILD": TRADE_EDGE_BUILD,
    "EVIDENCE_VERIFY": EVIDENCE_VERIFY,
    "ENTITY_RESOLUTION": ENTITY_RESOLUTION,
    "GRAPH_EXPANSION": GRAPH_EXPANSION,
    "RESOURCE_CLASSIFICATION": RESOURCE_CLASSIFICATION,
    "DATABASE_COMMIT": DATABASE_COMMIT,
}


def get_node_function(node_id: str):
    """Return a registered business node callable."""
    try:
        return NODE_FUNCTIONS[node_id]
    except KeyError as exc:
        raise KeyError(f"Unknown business node: {node_id}") from exc