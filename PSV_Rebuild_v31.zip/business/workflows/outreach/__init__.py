"""Outreach workflow: plan -> lead selection -> profiling -> qualification -> AI letter -> review gate -> commit."""
