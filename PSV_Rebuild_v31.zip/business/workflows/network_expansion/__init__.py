"""Network expansion workflow: seed selection -> multi-hop relation fan-out -> standard filter -> commit."""
