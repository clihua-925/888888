"""贸易策略 Prompt 层（V31）。"""

from __future__ import annotations


def build_keyword_prompt(seg_en: str, seg_aliases: str, sub: str, sub_en: str,
                         supply: str, market: str) -> str:
    return (
        "产品分段：" + seg_en + "（别名：" + (seg_aliases or "无") + "）。\n"
        "细分：" + sub + ("（英文名：" + sub_en + "）" if sub_en else "") + "。\n"
        "供应地：" + supply + "；目标市场：" + market + "。\n"
        "生成搜索关键词 JSON（不要输出其他内容）：\n"
        "{\"buyer_keywords\": [\"<5 条，importer/buyer/distributor/wholesaler 意图，英文>\"],\n"
        " \"supplier_keywords\": [\"<5 条，manufacturer/factory/supplier/exporter/OEM 意图，英文>\"]}\n"
        "要求：全部英文（ImportYeti 英文站），使用分段名 " + seg_en + " 与细分英文名拼接，"
        "禁止任何中文字符；buyer 词面向 " + market + " 采购商，supplier 词面向 " + supply + " 供应商。"
    )
