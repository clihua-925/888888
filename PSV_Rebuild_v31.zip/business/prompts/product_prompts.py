"""产品定义 Prompt 层（V31）：Node1/Service 之外唯一存放产品 prompt 的地方。"""

from __future__ import annotations


def build_taxonomy_prompt(product: str, market: str) -> str:
    return (
        "你是产品研究专家。产品：\"" + product + "\"（目标市场：" + market + "）。\n"
        "输出 JSON（不要输出其他内容）：\n"
        "{\"product_name_zh\": \"" + product + "\", \"product_name_en\": \"<标准英文名>\",\n"
        " \"product_segments\": [\n"
        "  {\"name_zh\": \"<分段中文名>\", \"name_en\": \"<分段英文名>\",\n"
        "   \"aliases\": [\"<同义商品名>=3，英文>\"], \"applications\": [\"<下游应用>=3>\"],\n"
        "   \"buyer_keywords\": [\"<买家搜索词>=5，英文>\"],\n"
        "   \"supplier_keywords\": [\"<供应商搜索词>=3，英文>\"],\n"
        "   \"hs_candidates\": [\"<HS编码>\"]}],\n"
        " \"major_categories\": [\n"
        "  {\"name_zh\": \"<大类>\", \"name_en\": \"<en>\", \"description\": \"<用途>\",\n"
        "   \"subcategories\": [{\"name_zh\": \"<细分>\", \"name_en\": \"<en>\", \"application\": \"<应用>\"}]}]}\n"
        "]}\n"
        "要求：1) 按商业用途拆成 >= 2 个分段（如工业用途 vs 消费/装饰用途），不得单一宽泛分段；"
        "2) 每段独立输出别名/应用/买家词/供应商词/HS；3) 搜索词全英文，禁止中文；"
        "4) 标准商业英文名（毛毡->Felt，工业毛毡->Industrial Felt，民用/装饰毛毡->Decorative Felt）。"
    )


def build_segmentation_retry_prompt(product: str) -> str:
    return (
        "把产品 \"" + product + "\" 按商业用途拆成 2-4 个分段。只输出 JSON：\n"
        "{\"product_segments\":[{\"name_zh\":\"...\",\"name_en\":\"...\","
        "\"aliases\":[\"...\"],\"buyer_keywords\":[\"...\"],\"supplier_keywords\":[\"...\"]}]}\n"
        "要求：name_en 与所有关键词必须英文（如 Industrial Felt / Decorative Felt）；"
        "工业用途与消费/装饰用途必须分开。"
    )


def build_scoring_prompt(subs_flat, supply: str, market: str) -> str:
    import json as _json
    return (
        "你是供应链分析师。供应地：" + supply + "；目标市场：" + market + "。\n"
        "评估以下产品细分（JSON 数组），逐项判断供应地产业优势与市场需求，0-1 打分：\n"
        + _json.dumps(subs_flat, ensure_ascii=False) + "\n"
        "输出 JSON（不要输出其他内容）：\n"
        "{\"filtered_subcategories\": [{\"category\": \"...\", \"subcategory\": \"...\",\n"
        "  \"supply_advantage\": 0.0, \"market_demand\": 0.0, \"combined_score\": 0.0, \"reason\": \"一句话依据\"}]}\n"
        "combined_score = 0.5*supply_advantage + 0.5*market_demand。逐项输出，不要遗漏。"
    )
