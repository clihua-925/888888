"""Import Collector（V31）：Browser/ImportYeti/PageSnapshot/trade_raw_pages 的唯一业务入口。"""

from __future__ import annotations

from repository.trade_repository import TradeRepository, repository as default_repository


class ImportCollector:
    def __init__(self, repo: TradeRepository | None = None) -> None:
        self._repo = repo or default_repository

    def collect(self, query_plan, market: str = "", industry: str = "",
                limit: int = 200, deadline_seconds: int = 1080, task_id: str = "") -> tuple:
        from business.shared import import_sources as _isrc
        return _isrc.node3_browser_pipeline(
            queries=query_plan, market=market, industry=industry,
            limit=limit, deadline_seconds=deadline_seconds, task_id=task_id)
