"""Entity Normalizer（V31）：Silver 回读 + 标准化/角色确认/去重。数据库唯一来源。"""

from __future__ import annotations

from typing import Any

from repository.trade_repository import TradeRepository, repository as default_repository

ROLE_OK = ("buyer", "supplier", "importer", "distributor", "manufacturer", "exporter")


class EntityNormalizer:
    def __init__(self, repo: TradeRepository | None = None) -> None:
        self._repo = repo or default_repository

    def load_validated(self, task_id: str) -> list[dict[str, Any]]:
        rows = self._repo.get_extracted_entities(task_id=task_id)
        out: dict[str, dict[str, Any]] = {}
        for s in rows:
            name = str(s.get("company_name") or "").strip()
            ev = str(s.get("evidence") or "").strip()
            if not name or not ev:
                continue
            role = str(s.get("role") or "").strip().lower()
            if role not in ROLE_OK:
                role = "buyer"
            key = name.lower()
            if key not in out:
                out[key] = {"name": name, "role": role,
                            "country": str(s.get("country") or "").strip(),
                            "address": str(s.get("address") or "").strip(),
                            "shipments": int(s.get("shipment_count") or 0),
                            "confidence": float(s.get("confidence") or 0),
                            "evidence": ev,
                            "source_url": str(s.get("source_url") or "").strip(),
                            "product": str(s.get("product") or "").strip(),
                            "raw_page_id": int(s.get("raw_page_id") or 0),
                            "supplier": ""}
            else:
                cur = out[key]
                if int(s.get("shipment_count") or 0) > int(cur["shipments"]):
                    cur["shipments"] = int(s.get("shipment_count") or 0)
                if not cur.get("evidence") and ev:
                    cur["evidence"] = ev
        return list(out.values())
