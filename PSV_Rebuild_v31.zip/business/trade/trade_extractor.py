"""Trade Extractor（V31）：AI 抽取结果强制落 Silver + 证据驱动 edges。"""

from __future__ import annotations

import logging
from typing import Any

from repository.trade_repository import TradeRepository, repository as default_repository

LOGGER = logging.getLogger(__name__)


class TradeExtractor:
    def __init__(self, repo: TradeRepository | None = None) -> None:
        self._repo = repo or default_repository

    def persist(self, task_id: str, fetched: list[dict[str, Any]]) -> dict[str, Any]:
        saved = 0
        edges = 0
        error = ""
        eid_map: dict[str, str] = {}
        if not task_id:
            return {"saved": 0, "eid_map": eid_map, "edges": 0, "error": "no_task_id"}
        try:
            for ent in fetched:
                eid = self._repo.save_extracted_entity(
                    task_id, ent, raw_page_id=int(ent.get("raw_page_id") or 0))
                if eid:
                    eid_map[str(ent.get("name") or "").lower()] = eid
                    saved += 1
            for ent in fetched:
                sup = str(ent.get("supplier") or "").strip()
                ev = str(ent.get("evidence") or "").strip()
                rid = int(ent.get("raw_page_id") or 0)
                url = str(ent.get("source_url") or "").strip()
                if not (sup and ev and rid > 0 and url and sup.lower() != str(ent.get("name") or "").lower()):
                    continue
                sup_eid = eid_map.get(sup.lower()) or self._repo.save_extracted_entity(
                    task_id, {"company_name": sup, "role": "supplier", "evidence": ev,
                              "source_url": url, "raw_page_id": rid}, raw_page_id=rid)
                buyer_eid = eid_map.get(str(ent.get("name") or "").lower(), "")
                ed = self._repo.save_extracted_edge(
                    task_id, sup_eid, buyer_eid, str(ent.get("product") or ""), ev,
                    source_url=url, raw_page_id=rid,
                    shipment_count=int(ent.get("shipments") or 0),
                    source_entity_id=buyer_eid,
                    confidence=float(ent.get("confidence") or 0.8))
                if ed:
                    edges += 1
        except Exception as exc:
            error = f"{type(exc).__name__}: {str(exc)[:160]}"
            LOGGER.warning("trade_extractor.persist failed: %s", error)
        return {"saved": saved, "eid_map": eid_map, "edges": edges, "error": error}
