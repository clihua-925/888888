"""Graph Builder（V31）：validated entities -> trade_nodes（Gold 出口原料）。"""

from __future__ import annotations

from typing import Any


class GraphBuilder:
    def build_nodes(self, validated: list[dict[str, Any]], market: str = "",
                    industry: str = "", supply_country: str = "China") -> list[dict[str, Any]]:
        nodes: list[dict[str, Any]] = []
        for ix, e in enumerate(validated, start=1):
            name = str(e.get("name") or "").strip()
            if not name:
                continue
            nodes.append({
                "node_id": f"IX{ix:04d}",
                "name": name,
                "role": str(e.get("role") or "buyer"),
                "country": str(e.get("country") or market or ""),
                "source": "importyeti_ai",
                "shipments": int(e.get("shipments") or 0),
                "industry": industry,
                "metadata": {"query": str(e.get("product") or ""),
                             "url": str(e.get("source_url") or ""),
                             "evidence": str(e.get("evidence") or ""),
                             "address": str(e.get("address") or ""),
                             "matched_by": ["ai_extractor"],
                             "supplier": str(e.get("supplier") or ""),
                             "segment": "",
                             "raw_html": "", "snapshot_at": "",
                             "page_number": 1,
                             "raw_page_id": int(e.get("raw_page_id") or 0)},
            })
        return nodes
