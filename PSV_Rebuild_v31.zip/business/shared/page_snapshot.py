"""PageSnapshot：Node3 采集层的强制页面对象（V18）。

数据流：Browser Agent -> ImportYeti 页面 -> PageSnapshot -> AI Trade Extractor。
七键齐全：url / query / page_number / html / text / timestamp（+title 附加）。
"""

from __future__ import annotations

from dataclasses import dataclass, field
import time


@dataclass
class PageSnapshot:
    url: str = ""
    query: str = ""
    page_number: int = 1
    html: str = ""
    text: str = ""
    timestamp: str = ""
    title: str = field(default="")

    @classmethod
    def from_page(cls, page, query: str = "", page_number: int = 1) -> "PageSnapshot":
        from core.tools.dom_agent import page_snapshot as _snap

        s = _snap(page)
        return cls(
            url=str(s.get("url") or ""),
            query=str(query),
            page_number=int(page_number),
            html=str(s.get("html") or ""),
            text=str(s.get("visible_text") or ""),
            timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            title=str(s.get("title") or ""),
        )

    def to_dict(self) -> dict:
        return {"url": self.url, "query": self.query, "page_number": self.page_number,
                "html": self.html, "text": self.text, "timestamp": self.timestamp,
                "title": self.title}
