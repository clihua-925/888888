"""Shared text/field normalization helpers for business workflows."""
from __future__ import annotations

from typing import Any


def market_name(value: Any) -> str:
    text = str(value or "").replace("_", " ").strip()
    return " ".join(word.capitalize() for word in text.split()) if text else ""


def hs_chapter(value: Any) -> str:
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    return digits[:2] if len(digits) >= 2 else ""
