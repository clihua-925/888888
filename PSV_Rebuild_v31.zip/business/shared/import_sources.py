"""Shared multi-source import-record loader (local first, IY human-like browser session, IY API, graceful degrade)."""
from __future__ import annotations
import time
import logging

LOGGER = logging.getLogger(__name__)

import json
import os
import re
import urllib.parse
import urllib.request
from pathlib import Path

_TIMEOUT = 15


def _load_local(market: str, industry: str) -> list:
    m = str(market or "").strip().lower().replace(" ", "_")
    ind = str(industry or "").strip().lower()
    candidates = []
    if m and ind:
        candidates.append(Path("data/imports") / f"{m}_{ind}.json")
    candidates.append(Path("data/imports/records.json"))
    for path in candidates:
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    return [x for x in data if isinstance(x, dict)]
        except Exception:
            continue
    return []


_IY_CHROME_LABELS = {
    "customers", "customer", "suppliers", "supplier", "products", "product",
    "shipments", "shipment", "search", "results", "result", "home", "about",
    "contact", "login", "sign up", "signup", "companies", "company", "importers",
    "exporters", "importer", "exporter", "pages", "page", "menu", "help",
    "total sea shipments over time", "top shippers", "recent searches",
    "trending searches", "importyeti", "all rights reserved", "privacy", "terms",
}


_BUSINESS_SUFFIXES = re.compile(
    r"(llc|inc|corp|co|ltd|group|trading|importers?|exporters?|company|enterprise|gmbh|sarl|bv|b\.v|spa|pty)"
)


def _looks_like_company_name(name, reject_words=None) -> bool:
    """剔除 ImportYeti 页面导航/标题文字，只留公司名。

    reject_words: 与查询词/产品词相同的单词名直接拒收（如查询"Felt"时
    结果里的"Felt"是查询词本身不是公司）；单词短名必须带商业后缀。
    """
    text = str(name or "").strip()
    if len(text) < 4 or len(text) > 80 or not any(ch.isalpha() for ch in text):
        return False
    low = text.lower()
    if low in _IY_CHROME_LABELS:
        return False
    if reject_words and low in reject_words:
        return False
    if len(low.split()) < 2 and not _BUSINESS_SUFFIXES.search(low):
        return False
    return True


def _collect_company_names(page) -> list:
    """从结果页收集 /company/ 链接文本（滚动两轮去重）。"""
    def _once() -> list:
        names = []
        for a in page.query_selector_all('a[href*="/company/"]'):
            try:
                text = (a.inner_text() or "").strip()
            except Exception:
                continue
            if text and text not in names:
                names.append(text)
        return names

    found = _once()
    for _ in range(3):
        if not found:
            break
        before = len(found)
        try:
            page.mouse.wheel(0, 900)
            page.wait_for_timeout(1500)
            for name in _once():
                if name not in found:
                    found.append(name)
        except Exception:
            break
        if len(found) == before:
            break  # 无新公司出现即停
    return found


_FAST_SELECTORS = (
    'input[type="search"], input[placeholder*="earch" i], input[placeholder*="Find" i], '
    'input[placeholder*="Supplier" i], input[placeholder*="Company" i], input[name="q"], '
    'input[aria-label*="earch" i], input[aria-label*="Find" i], input[data-testid*="earch" i], '
    'textarea[placeholder*="earch" i], form input[type="text"]'
)


def _wait_stable_selector(page, selector: str = 'a[href*="/company/"]', max_wait: int = 15) -> int:
    """渲染稳定等待（spec 4.3）：连续 3 秒目标选择器计数不变且 >0 即完成，最长 max_wait 秒。"""
    last_count, stable_rounds = 0, 0
    for _ in range(max_wait):
        page.wait_for_timeout(1000)
        try:
            count = len(page.query_selector_all(selector))
        except Exception:
            return last_count
        if count == last_count and count > 0:
            stable_rounds += 1
            if stable_rounds >= 3:
                return count
        else:
            stable_rounds = 0
        last_count = count
    return last_count


def _fast_search(page, query: str, diag: dict | None = None):
    """快通道：直接选择器搜索，无 LLM，全程约 15-20 秒。

    返回名单表示成功；返回 None 表示失败（无搜索框/等待超时/异常），
    失败原因写入 diag["fast_path_error"]，由调用方决定是否升级 DOM Agent 慢通道。
    """
    diag = diag if diag is not None else {}
    try:
        box = page.query_selector(_FAST_SELECTORS)
        if box is None:
            diag["fast_path_error"] = "no_search_box"
            return None
        box.click()
        box.fill("")
        box.type(query, delay=40)
        page.keyboard.press("Enter")
        page.wait_for_selector('a[href*="/company/"]', timeout=12000)
        _wait_stable_selector(page)
        return _collect_company_names(page)
    except Exception as exc:
        diag["fast_path_error"] = f"{type(exc).__name__}: {str(exc)[:200]}"
        return None


def _human_search_once(page, query: str, diag: dict, reject_words=None) -> list:
    """双通道仿人工搜索。

    快通道（选择器直搜，≤20秒）优先；失败才升级 DOM Agent 恢复（每查询
    预算180秒，模型逐步决策）。成功（结果页出现公司链接）后收集并过滤；
    失败把错误与决策历史写进 diag，返回空列表走下一数据源。
    """
    reject = {str(w).strip().lower() for w in (reject_words or []) if str(w).strip()}
    fast = _fast_search(page, query, diag)
    if fast is not None:
        names = [nm for nm in fast if _looks_like_company_name(nm, reject)]
        diag["browser_error"] = "" if names else "fast_path_no_results"
        return names
    from core.tools.dom_agent import DOMAgent
    agent = DOMAgent()
    goal = f'在 ImportYeti 首页搜索框输入 "{query}"，然后按回车或点击搜索按钮，等待结果页面出现公司链接'
    result = agent.run_goal(page, goal, max_steps=10, budget_ms=180000)
    if not result.get("done"):
        diag["browser_error"] = result.get("error") or "dom_agent_failed"
        diag["dom_history"] = result.get("history") or []
        return []
    names = _collect_company_names(page)
    return [nm for nm in names if _looks_like_company_name(nm, reject)]


def _fetch_importyeti_browser(market: str, industry: str, limit: int = 60, full: bool = False,
                              queries: list | None = None, diag: dict | None = None,
                              deadline_seconds: int | None = None) -> list:
    """仿人工浏览器采集主循环：多查询轮询（策略来自方案节点），全程可见（IY_BROWSER_VISIBLE=0 关闭）。"""
    import time as _time
    if diag is None:
        diag = {}
    def _fail(reason: str) -> tuple:
        diag["browser_error"] = reason
        return ([], diag)
    if not (queries or industry or market):
        return _fail("empty_query")
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return _fail("playwright_missing")
    try:
        cdp = os.environ.get("IY_WEB_CDP_URL") or os.environ.get("OUTLOOK_CDP_URL") or "http://127.0.0.1:9222"
        visible = os.environ.get("IY_BROWSER_VISIBLE", "1").strip() != "0"
        with sync_playwright() as pw:
            try:
                browser = pw.chromium.connect_over_cdp(cdp)
            except Exception as exc:
                return _fail(f"cdp_unreachable: {type(exc).__name__}")
            context = browser.contexts[0] if browser.contexts else None
            if context is None:
                return _fail("no_browser_context")
            page = None
            for pg in context.pages:
                if "importyeti.com" in (pg.url or ""):
                    page = pg
                    break
            if page is None:
                page = context.new_page()
            # 始终回到首页再搜索：公司详情页/其他子页面没有搜索框，
            # 之前的"复用任意importyeti页面"逻辑会在公司页上抓版块标题当公司名。
            try:
                page.goto("https://www.importyeti.com/", timeout=60000, wait_until="domcontentloaded")
                try:
                    page.wait_for_load_state("networkidle", timeout=10000)
                except Exception:
                    page.wait_for_timeout(3000)
            except Exception:
                page.wait_for_timeout(1000)  # 首页打不开也继续，搜索盒检测会给出真实错误
            # Cloudflare挑战等待（参考老版iy_web.py的轮询思路）：
            # 出现挑战页时等搜索框出现，最长20秒；超时如实报错。
            try:
                head = page.evaluate("() => (document.body ? document.body.innerText.slice(0, 400) : '')") or ""
            except Exception:
                head = ""
            if re.search(r"just a moment|attention required|cf-chl|verify you are", head, re.I):
                diag["browser_error"] = "cloudflare"
                try:
                    page.wait_for_selector('input[type="search"], input[placeholder*="earch" i], input[name="q"]', timeout=20000)
                    diag["browser_error"] = ""
                except Exception:
                    diag["browser_error"] = "cloudflare_timeout"
                    return _fail("cloudflare_timeout")
            if visible:
                try:
                    page.bring_to_front()
                except Exception as exc:
                    diag["bring_to_front_error"] = type(exc).__name__ + ": " + str(exc)[:120]
            out = []
            seen_names = set()
            qi = 0
            budget_seconds = int(deadline_seconds) if deadline_seconds else (1080 if full else 360)
            total_deadline = time.time() + budget_seconds  # full 模式浏览器预算 18 分钟
            default_queries = [q for q in (str(industry or "").strip(),) if q] or [str(market or "").strip()]
            queue = list(queries or default_queries) if full else list(queries or default_queries)[:4]
            per_query: dict[str, dict[str, Any]] = {}
            _cn_pat = re.compile(r"[\u4e00-\u9fff]")
            for qi, query in enumerate(queue, start=1):
                if _cn_pat.search(query):
                    LOGGER.warning("跳过中文关键词: %s", query)
                    diag.setdefault("skipped_chinese_queries", []).append(query)
                    continue
                if len(out) >= limit:
                    break
                if time.time() > total_deadline:
                    diag["browser_error"] = diag.get("browser_error") or "source_budget_exceeded"
                    break
                text_record_map: dict = {}
                try:
                    names = _human_search_once(page, query, diag, reject_words={query, industry, market, "importyeti"})
                    if full:
                        # V16 三层流水线：Page1 快照+抽取 -> Paginate(Page2..3 每页快照+抽取)
                        from core.tools import iy_web as _iy
                        _page_counter = [1]
                        try:
                            _s1, _companies1 = _iy.snapshot_and_extract(page, query=query, page_number=1)
                            if _s1:
                                diag.setdefault("snapshot_files", []).append(_s1)
                            for c in _companies1:
                                nm = str(c.get("name") or "").strip()
                                if nm:
                                    text_record_map[nm] = c
                                    if nm not in names:
                                        names.append(nm)
                            diag["text_extract_used"] = int(diag.get("text_extract_used") or 0) + 1
                        except Exception as exc:
                            diag.setdefault("text_extract_errors", []).append(
                                {"query": query, "error": str(exc)[:160]})
                        names = _paginate_collect(page, query, names,
                                                  reject_words={query, industry, market, "importyeti"},
                                                  record_map=text_record_map, _page_counter=_page_counter)
                except Exception as exc:  # 单词失败记录后继续，不中断整个浏览器源
                    err = f"{type(exc).__name__}: {str(exc)[:160]}"
                    diag["browser_error"] = diag.get("browser_error") or f"dom_agent_exception:{type(exc).__name__}"
                    diag.setdefault("failed_queries", []).append({"query": query, "error": err})
                    per_query[query] = {"browser": 0, "status": "failed", "error": err}
                    continue
                q_before = len(out)
                try:
                    diag["current_url"] = page.url
                    rounds_done, pages_done = 1, 0
                    if full and len(names) < 20:
                        # 不足 20：追加翻页（最多3页），仍不足则追加滚动轮（最多3轮）
                        before_extra = len(names)
                        names = _paginate_collect(page, query, names, reject_words={query, industry, market, "importyeti"})
                        pages_done = 1
                        if len(names) - before_extra <= 0:
                            for _round in range(3):
                                prev = len(names)
                                names = list(names) + [n for n in _collect_company_names(page) if n not in set(names)]
                                names = list(dict.fromkeys(names))
                                rounds_done += 1
                                if len(names) == prev:
                                    break
                    details: dict[str, dict[str, Any]] = {}
                    if full:
                        details = _company_details_batch(page, list(names)[:25]) or {}
                except Exception as exc:
                    diag.setdefault("query_warnings", []).append({"query": query, "stage": "enrich", "error": str(exc)[:160]})
                    details = {}
                snap_ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                for name in names:
                    if name in seen_names or len(out) >= limit:
                        continue
                    seen_names.add(name)
                    detail = details.get(name) or {}
                    tr = text_record_map.get(name) or {}
                    out.append({
                        "node_id": f"IYB_{len(out)+1:04d}",
                        "name": name,
                        "role": str(tr.get("role") or "buyer"),
                        "country": str(tr.get("country") or market),
                        "shipments": int(detail.get("shipments") or tr.get("shipments") or 0),
                        "industry": industry,
                        "source": "importyeti_browser",
                        "metadata": {"query": query, **detail,
                                     "raw_html": str(tr.get("raw_html") or "")[:50000],
                                     "url": str(tr.get("url") or "") or diag.get("current_url", ""),
                                     "snapshot_at": snap_ts,
                                     "evidence": str(tr.get("evidence") or ""),
                                     "supplier": str(tr.get("supplier") or ""),
                                     "product": str(tr.get("product") or ""),
                                     "source_url": str(tr.get("source_url") or tr.get("url") or ""),
                                     "snapshot_file": str(tr.get("snapshot_file") or "")},
                    })
                got = len(out) - q_before
                per_query[query] = {"browser": got, "attempted_rounds": rounds_done,
                                    "attempted_pages": pages_done,
                                    "pages_snapshotted": _page_counter[0] if full else 1,
                                    "validated_records": len(text_record_map),
                                    "status": "ok" if got >= 20 else "below_20"}
                if full and got < 20:
                    diag.setdefault("below_20_queries", []).append(query)
                time.sleep(1.2)
            if full:
                diag["per_query"] = per_query
            if not out:
                return _fail(diag.get("browser_error") or "empty_extraction")
            diag["browser_queries"] = qi
            diag["browser_error"] = ""
            return (out, diag)
    except Exception as exc:
        return _fail(f"exception: {type(exc).__name__}: {str(exc)[:120]}")


def _fetch_importyeti(market: str, industry: str, diag: dict | None = None) -> list:
    """ImportYeti 公开摘要 API（v45 原版同款端点，匿名免 key，curl_cffi Chrome 指纹优先）。"""
    def _fail(reason: str) -> list:
        if diag is not None:
            diag["http_error"] = reason
        return []
    if str(market).strip().lower() not in ("us", "usa", "united states", "america", "\u7f8e\u56fd", ""):
        return _fail("unsupported_market")
    query = f"{industry}".strip()
    if not query:
        return _fail("empty_query")
    try:
        from core.config.industry import load_industry
        profile = load_industry(industry) or {}
        for word in (profile.get("keywords") or []) + (profile.get("product_terms") or []):
            word = str(word).strip()
            if word and re.search(r"[A-Za-z]", word):
                query = word
                break
    except Exception:
        query = query
    try:
        url = "https://www.importyeti.com/api/search?q=" + urllib.parse.quote(query) + "&page=1"
        payload = None
        try:
            from curl_cffi import requests as creq
            resp = creq.get(url, impersonate="chrome", timeout=_TIMEOUT,
                            headers={"Referer": "https://www.importyeti.com/"})
            if resp.status_code == 200:
                payload = resp.json()
            else:
                return _fail(f"http_{resp.status_code}")
        except ImportError:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
                "Accept": "application/json, text/plain, */*",
                "Referer": "https://www.importyeti.com/",
            })
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                payload = json.loads(resp.read().decode("utf-8", "replace"))
        rows = []
        if isinstance(payload, dict):
            rows = payload.get("searchResults") or payload.get("results") or payload.get("data") or []
        if not isinstance(rows, list) or not rows:
            return _fail("empty_results")
        if diag is not None:
            diag["http_error"] = ""
        out = []
        for idx, item in enumerate(rows[:50], start=1):
            if not isinstance(item, dict):
                continue
            name = item.get("title") or item.get("name") or item.get("companyName") or ""
            name = str(name).strip()
            if len(name) < 2:
                continue
            try:
                shipments = int(item.get("totalShipments") or 0)
            except (TypeError, ValueError):
                shipments = 0
            out.append({
                "node_id": f"IY_{idx:04d}",
                "name": name,
                "role": "buyer",
                "country": "United States",
                "shipments": shipments,
                "industry": industry,
                "source": "importyeti",
                "metadata": {"website": item.get("website") or "", "address": item.get("address") or ""},
            })
        if not out:
            return _fail("no_valid_rows")
        return out
    except Exception as exc:
        return _fail(f"exception: {type(exc).__name__}: {str(exc)[:120]}")


def fetch_comtrade_flows(hs_code: str = "", reporter: str = "USA", partner: str = "World",
                         period: str = "2024", max_records: int = 50) -> list:
    """UN Comtrade 宏观贸易流校验（免费 key，注册即得，免费档 500 次/日）。"""
    key = os.environ.get("COMTRADE_API_KEY", "").strip()
    if not key or not hs_code:
        return []
    try:
        url = (
            "https://comtradeapi.un.org/public/v1/preview/C/A/HS"
            f"?reporterCode={reporter}&partnerCode={partner}&period={period}"
            f"&cmdCode={hs_code}&maxRecords={max_records}"
        )
        req = urllib.request.Request(url, headers={"Ocp-Apim-Subscription-Key": key, "User-Agent": "PSV-Trade-OS/9.4"})
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            payload = json.loads(resp.read().decode("utf-8", "replace"))
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            return []
        return [{
            "reporter": item.get("reporterDesc", ""),
            "partner": item.get("partnerDesc", ""),
            "flow": item.get("flowDesc", ""),
            "hs": item.get("cmdCode", ""),
            "value_usd": item.get("primaryValue", 0),
            "period": item.get("period", ""),
        } for item in data[:max_records] if isinstance(item, dict)]
    except Exception:
        return []


def load_import_records_diag(market: str = "", industry: str = "", queries: list | None = None,
                             accept=None, full: bool = False, supply_country: str = "") -> tuple:
    """级联加载并返回各源诊断：本地 → 浏览器会话(仿人工多查询) → 匿名HTTP。

    accept: 可选判定谓词。某源有原始记录但 0 条通过 accept 时视为"该源无有效
    数据"，继续下一级——修复旧版"本地文件存在即短路、过滤后 0 条静默无数据"。
    full=True：三层全部执行、按名归一合并、不短路（trade_collection 节点3重建）。
    """
    if full:
        return _load_records_full(market, industry, queries=queries, accept=accept)
    diag = {"local": 0, "browser": 0, "http": 0, "used": "none", "errors": []}

    def _kept(records: list) -> list:
        if accept is None or not records:
            return records
        return [item for item in records if accept(item)]

    # 1) 本地
    local_records = _load_local(market, industry)
    diag["local"] = len(local_records)
    kept = _kept(local_records)
    diag["local_kept"] = len(kept)
    if kept:
        diag["used"] = "local"
        return kept, diag
    if local_records:
        diag["errors"].append("local: all_filtered")

    # 2) 仿人工浏览器会话（可见；IY_BROWSER_ENABLED=0 关闭）
    if os.environ.get("IY_BROWSER_ENABLED", "1").strip() == "1":
        browser_records, _bd = _fetch_importyeti_browser(market, industry, diag=diag, queries=queries) or ([], {})
        browser_records = browser_records or []
        diag["browser"] = len(browser_records)
        kept = _kept(browser_records)
        diag["browser_kept"] = len(kept)
        if kept:
            diag["used"] = "browser"
            return kept, diag
        if browser_records:
            diag["errors"].append("browser: all_filtered")
        elif diag.get("browser_error"):
            diag["errors"].append(f"browser: {diag['browser_error']}")
    else:
        diag["browser_error"] = "disabled"

    # 3) 匿名 HTTP（IY_FETCH_ENABLED=0 关闭）
    if os.environ.get("IY_FETCH_ENABLED", "1").strip() == "1":
        http_records = _fetch_importyeti(market, industry, diag=diag) or []
        diag["http"] = len(http_records)
        kept = _kept(http_records)
        diag["http_kept"] = len(kept)
        if kept:
            diag["used"] = "http"
            return kept, diag
        if http_records:
            diag["errors"].append("http: all_filtered")
        elif diag.get("http_error"):
            diag["errors"].append(f"http: {diag['http_error']}")
    else:
        diag["http_error"] = "disabled"

    if not diag["errors"]:
        diag["errors"].append("all_sources_empty")
    return [], diag


def _wait_render_stable(page, max_ms: int = 15000) -> None:
    """渲染稳定等待：1s 轮询 body 文本长度，连续 3 次不变即返回，上限 max_ms。"""
    last, stable, waited = -1, 0, 0
    while waited < max_ms:
        try:
            page.wait_for_timeout(1000)
        except Exception:
            return
        waited += 1000
        try:
            size = int(page.evaluate("() => document.body ? document.body.innerText.length : 0") or 0)
        except Exception:
            return
        if size == last:
            stable += 1
            if stable >= 3:
                return
        else:
            stable, last = 0, size


_NEXT_SELECTORS = (
    "text=/^Next$/i",
    "button:has-text('Next')",
    "a:has-text('Next')",
    "[aria-label*='next' i]",
    ".pagination-next:not([disabled])",
    "button:has-text('Next page')",
    "li[class*='next'] a", "li[class*='pagination'] a:text-is('Next')",
    "[class*='pagination'] a:text-is('2')", "[class*='pagination'] button:text-is('2')",
    "a[rel='next']",
)


def _paginate_collect(page, query: str, initial: list, reject_words=None,
                       record_map: dict | None = None, _page_counter: list | None = None) -> list:
    """结果页翻页扩展：点击 Next 最多 3 页，每页复用 _collect_company_names 归并。"""
    names = list(initial or [])
    seen = {n.lower() for n in names}
    if record_map is None:
        record_map = {}
    if _page_counter is None:
        _page_counter = [1]
    try:
        for _ in range(3):
            try:
                page.mouse.wheel(0, 900)
            except Exception as exc:
                diag["error"] = type(exc).__name__ + ": " + str(exc)[:200]
            time.sleep(0.8)
            clicked = False
            for sel in _NEXT_SELECTORS:
                try:
                    loc = page.locator(sel).first
                    if loc.count() > 0 and loc.is_visible():
                        loc.click(timeout=3000)
                        clicked = True
                        break
                except Exception:
                    continue
            if not clicked:
                break
            _wait_render_stable(page, max_ms=10000)
            try:
                from core.tools import iy_web as _iyw
                _pg_no = _page_counter[0] = _page_counter[0] + 1
                _snap_file, _companies = _iyw.snapshot_and_extract(page, query=query, page_number=_pg_no)
                if _snap_file:
                    diag.setdefault("snapshot_files", []).append(_snap_file)
                for c in _companies:
                    nm = str(c.get("name") or "").strip()
                    if nm:
                        record_map[nm] = c
                        if nm.lower() not in seen:
                            seen.add(nm.lower())
                            names.append(nm)
            except Exception as exc:
                diag.setdefault("query_warnings", []).append(
                    {"query": query, "stage": f"page{_page_counter[0]+1}", "error": str(exc)[:160]})
            for name in _collect_company_names(page):
                if name.lower() not in seen:
                    seen.add(name.lower())
                    names.append(name)
    except Exception as exc:
        diag["error"] = type(exc).__name__ + ": " + str(exc)[:200]
    return names


def _company_details_batch(page, names: list, max_items: int = 25) -> dict[str, dict[str, Any]]:
    """对名单前 max_items 家逐一点击 /company/ 详情页，提取 shipments/hs/website/address。"""
    details: dict[str, dict[str, Any]] = {}
    for name in list(names or [])[:max_items]:
        try:
            link = page.locator(f'a[href*="/company/"]:has-text("{str(name)[:30]}")').first
            if link.count() == 0:
                continue
            href = link.get_attribute("href") or ""
            link.click(timeout=5000)
            _wait_render_stable(page, max_ms=10000)
            info = page.evaluate("""() => {
                const t = document.body ? document.body.innerText : "";
                const grab = (re) => { const m = t.match(re); return m ? m[1].trim() : ""; };
                return {
                    shipments: grab(/([\\d,]+)\\s+(?:Shipments|shipments)/),
                    hs_code: grab(/(HS\\s*Code[\\s:]*[\\d.]+)/i),
                    website: grab(/(https?:\\/\\/[^\\s]+)/i),
                    address: grab(/(\\d+[^\\n]{5,80}(?:USA|United States|US)\\b)/i),
                };
            }""") or {}
            info["detail_url"] = href
            details[name] = {k: v for k, v in dict(info).items() if v}
            try:
                page.go_back()
                _wait_render_stable(page, max_ms=8000)
            except Exception as exc:
                diag["error"] = type(exc).__name__ + ": " + str(exc)[:200]
        except Exception:
            try:
                page.go_back()
            except Exception as exc:
                diag["error"] = type(exc).__name__ + ": " + str(exc)[:200]
            continue
    return details


def _load_records_full(market: str, industry: str, queries: list | None = None, accept=None) -> tuple:
    """三层全量采集（不短路）：local 跑完 -> browser 全队列跑完 -> http 跑完，按名归一合并。"""
    def _kept(records: list) -> list:
        if accept is None or not records:
            return records
        return [item for item in records if accept(item)]

    def _norm_name(item: dict) -> str:
        return re.sub(r"\s+", " ", str(item.get("name") or item.get("company") or "").strip().lower())

    diag: dict[str, Any] = {"local": 0, "browser": 0, "http": 0, "used": "none",
                            "errors": [], "per_query": {}}
    merged: dict[str, dict[str, Any]] = {}

    local_records = _load_local(market, industry)
    diag["local"] = len(local_records)
    for item in _kept(local_records):
        key = _norm_name(item)
        if key:
            merged.setdefault(key, dict(item))

    browser_records: list = []
    if os.environ.get("IY_BROWSER_ENABLED", "1").strip() == "1":
        try:
            browser_records, browser_diag = _fetch_importyeti_browser(
                market, industry, limit=200, queries=queries,
                deadline_seconds=1080, diag=None, full=True) or ([], {})
            diag["browser_error"] = (browser_diag or {}).get("browser_error", "") or diag.get("browser_error", "")
            diag["per_query"] = dict((browser_diag or {}).get("per_query") or {})
        except Exception as exc:
            diag["browser_error"] = f"exception: {type(exc).__name__}"
            browser_records = []
    diag["browser"] = len(browser_records)
    for item in _kept(browser_records):
        key = _norm_name(item)
        if key:
            merged.setdefault(key, dict(item))

    # ---- v30.5 渗透链恢复：IYWeb 会话 + iy_penetration 递归扩展 ----
    pen_nodes: list = []
    pen_relations: list = []
    try:
        from core.config import settings as _settings
        from core.tools import iy_web
        if iy_web.available():
            from core.trade_graph import iy_penetration
            seeds = [
                {"name": str(r.get("name") or ""), "url": str((r.get("metadata") or {}).get("detail_url") or ""),
                 "kind": "company", "shipments": int(r.get("shipments") or 0)}
                for r in browser_records if str(r.get("name") or "").strip()
            ][: int(getattr(_settings, "IY_WEB_SEARCH_LIMIT", 25))]
            if seeds:
                with iy_web.IYWeb() as w:
                    out = iy_penetration.penetrate(seeds, w, task_id=task_id) or {}
                pen_nodes = list(out.get("nodes") or [])
                pen_relations = list(out.get("relations") or [])
                diag["penetration"] = {"nodes": len(pen_nodes), "relations": len(pen_relations),
                                       "stats": dict(out.get("stats") or {})}
    except Exception as exc:
        diag["penetration_error"] = type(exc).__name__ + ": " + str(exc)[:200]
    for item in pen_nodes:
        key = _norm_name(item if isinstance(item, dict) else {"name": item})
        if key and key not in merged:
            merged[key] = {"name": item.get("name") or item.get("company") or key,
                           "role": "supplier", "country": market,
                           "source": "importyeti_penetration",
                           "shipments": int(item.get("shipments") or 0),
                           "metadata": {"kind": item.get("kind", ""), "url": item.get("url", ""),
                                        "penetration": True, "relations": pen_relations}}

    http_records: list = []
    if os.environ.get("IY_FETCH_ENABLED", "1").strip() == "1":
        try:
            http_records = _fetch_importyeti(market, industry, diag=diag) or []
        except Exception as exc:
            diag["http_error"] = f"exception: {type(exc).__name__}"
            http_records = []
    diag["http"] = len(http_records)
    for item in _kept(http_records):
        key = _norm_name(item)
        if not key:
            continue
        if key in merged:
            base_meta = merged[key].setdefault("metadata", {})
            src_meta = item.get("metadata") or {}
            for f in ("shipments", "hs_code", "website", "address"):
                if not base_meta.get(f) and src_meta.get(f):
                    base_meta[f] = src_meta[f]
            if not merged[key].get("shipments") and item.get("shipments"):
                merged[key]["shipments"] = item["shipments"]
        else:
            merged[key] = dict(item)

    diag["browser_diag"] = {k: browser_diag.get(k) for k in
                            ("browser_error", "login_required", "failed_url",
                             "screenshot_path", "dom_history") if (browser_diag or {}).get(k)}
    diag["used"] = "+".join(k for k in ("local", "browser", "http") if diag[k]) or "none"
    if not merged:
        diag["errors"].append("all_sources_empty")
    return list(merged.values()), diag

def browse_query_snapshots(page, query: str, max_pages: int = 3) -> list:
    """Browser -> PageSnapshot：当前页 + Next 翻页至 max_pages，每页一个 PageSnapshot 对象。"""
    from business.shared.page_snapshot import PageSnapshot

    snaps = [PageSnapshot.from_page(page, query=query, page_number=1)]
    for n in range(2, max_pages + 1):
        clicked = False
        for sel in _NEXT_SELECTORS:
            try:
                loc = page.locator(sel).first
                if loc.count() > 0 and loc.is_visible():
                    loc.click(timeout=3000)
                    clicked = True
                    break
            except Exception:
                continue
        if not clicked:
            break
        _wait_render_stable(page, max_ms=10000)
        snaps.append(PageSnapshot.from_page(page, query=query, page_number=n))
    return snaps


def node3_browser_pipeline(queries, market: str = "", industry: str = "",
                           limit: int = 200, deadline_seconds: int = 1080, task_id: str = "") -> tuple:
    """V18 强制数据流：Node2 search_queries -> Browser Agent -> ImportYeti -> PageSnapshot
    -> AI Trade Extractor -> Entity Validator -> entities（七键）。"""
    from core.trade_graph.ai_trade_extractor import extract_companies

    entities: dict = {}
    diag: dict = {"snapshots": [], "errors": [], "queries": {}}
    cdp = os.environ.get("IY_WEB_CDP_URL") or os.environ.get("OUTLOOK_CDP_URL") or "http://127.0.0.1:9222"
    try:
        from playwright.sync_api import sync_playwright
        pw = sync_playwright().start()
    except Exception:
        diag["errors"].append("browser_init:playwright_missing")
        return [], diag
    try:
        browser = pw.chromium.connect_over_cdp(cdp)
        context = browser.contexts[0] if browser.contexts else browser.new_context()
        page = context.pages[0] if context.pages else context.new_page()
        page.goto("https://www.importyeti.com", timeout=60000, wait_until="domcontentloaded")
        page.wait_for_timeout(2000)
    except Exception as exc:
        try:
            pw.stop()
        except Exception:
            pass
        diag["errors"].append(f"browser_init:{type(exc).__name__}: {str(exc)[:120]}")
        return [], diag
    deadline = time.time() + int(deadline_seconds)
    for _qitem in list(queries or []):
        if isinstance(_qitem, dict):
            query = str(_qitem.get("query") or "").strip()
            _seg = str(_qitem.get("segment") or "").strip()
        else:
            query = str(_qitem).strip()
            _seg = ""
        if time.time() > deadline or len(entities) >= limit:
            break
        if not query or re.search(r"[\u4e00-\u9fff]", query):
            continue
        try:
            box = page.query_selector(_FAST_SELECTORS)
            if box is None:
                raise RuntimeError("no_search_box")
            box.click()
            box.fill("")
            box.type(query, delay=40)
            page.keyboard.press("Enter")
            page.wait_for_selector("a[href*=\"/company/\"]", timeout=12000)
            _wait_stable_selector(page)
        except Exception as exc:
            diag["errors"].append(f"search:{query}:{type(exc).__name__}")
            continue
        try:
            snaps = browse_query_snapshots(page, query, max_pages=3)
            diag["snapshots"].append({"query": query, "pages": len(snaps)})
            got = 0
            for _snap in snaps:
                # V29：Bronze 先落库拿 raw_id，再抽取——实体直接锚定原文页
                _rid = 0
                if task_id:
                    try:
                        import os as _os
                        import time as _time
                        from core.memory.db import Database as _DB
                        from core.config.settings import settings as _st
                        _db = _DB(_st.database_path)
                        _dir = _os.path.join("data", "importyeti")
                        _os.makedirs(_dir, exist_ok=True)
                        _shot = ""
                        try:
                            _ts = _time.strftime("%Y%m%dT%H%M%SZ", _time.gmtime())
                            _shot = _os.path.join(_dir, f"shot_{_ts}_p{_snap.page_number}.png")
                            page.screenshot(path=_shot, timeout=5000)
                        except Exception:
                            _shot = ""
                        _rid = _db.save_raw_page(task_id, _snap.query, _snap.page_number, _snap.url,
                                                 _snap.html, _snap.text, title=_snap.title, screenshot=_shot)
                        diag["raw_pages_saved"] = int(diag.get("raw_pages_saved") or 0) + 1
                    except Exception as _exc:
                        diag.setdefault("raw_errors", []).append(str(_exc)[:160])
                for ent in extract_companies(_snap):
                    key = str(ent.get("name") or "").lower()
                    if key:
                        ent["segment"] = _seg or str(ent.get("product") or "")
                        ent["raw_page_id"] = _rid
                        entities.setdefault(key, ent)
                        got += 1
            diag["queries"][query] = {"pages": len(snaps), "entities": got}
        except Exception as exc:
            diag["errors"].append(f"extract:{query}:{type(exc).__name__}")
    try:
        pw.stop()
    except Exception:
        pass
    return list(entities.values())[:limit], diag
