"""Shared business helpers (not a workflow package)."""
