"""raw_pages 库内提炼（ELT 下游任务，非九节点流程）。

用法：
    python tools/refine_raw.py --task <task_id>     # 按任务提炼
    python tools/refine_raw.py --all                 # 全量
    python tools/refine_raw.py --task <id> --out data/refined/<task>.json

可反复重跑：换 prompt/模型/修提取器后重提炼，零重新爬取。
不写业务五表（那是 Node9 的职责），仅输出提炼报告。
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core.config.settings import settings
from core.memory.db import Database
from core.trade_graph.ai_trade_extractor import extract_companies


def refine(task_id: str | None = None, out: str | None = None) -> dict:
    db = Database(settings.database_path)
    pages = db.get_raw_pages(task_id=task_id, limit=100000)
    merged: dict[str, dict] = {}
    per_query: dict[str, int] = defaultdict(int)
    for page in pages:
        companies = extract_companies({
            "visible_text": page["text"], "url": page["url"], "query": page["query"],
        })
        for c in companies:
            key = str(c.get("name") or "").lower()
            if not key:
                continue
            cur = merged.get(key)
            if cur is None:
                c["raw_ids"] = [page["raw_id"]]
                c["pages_seen"] = 1
                merged[key] = c
            else:
                cur["raw_ids"].append(page["raw_id"])
                cur["pages_seen"] += 1
                if int(c.get("shipments") or 0) > int(cur.get("shipments") or 0):
                    cur["shipments"] = c["shipments"]
                if not cur.get("evidence") and c.get("evidence"):
                    cur["evidence"] = c["evidence"]
            per_query[page["query"]] += 1
    # Silver 落库（方法调用，幂等 REPLACE，raw_ids 证据锚）
    import time as _time
    from core.memory.db import Database
    _db2 = Database(settings.database_path)
    _now = _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())
    _eid_map: dict = {}
    for _name, _c in merged.items():
        _c.setdefault("raw_ids", [])
        _eid_map[_name] = _db2.save_trade_entity(task_id or "", _c, source_raw_page_id=int((_c.get("raw_ids") or [0])[0]), created_time=_now)
    # edges：仅当证据行含 supplier 反查（extractor 的 "imported from X"），禁止按名字猜
    edges = []
    for _name, _c in merged.items():
        _sup = str(_c.get("supplier") or "").strip()
        if _sup and _sup.lower() != (_c.get("name") or "").lower() and _c.get("evidence"):
            edges.append({"supplier": _sup, "buyer": _c.get("name"),
                          "evidence": _c.get("evidence"), "source": "ImportYeti"})
            _ev0 = str(_c.get("evidence") or "")
            _rid0 = int((_c.get("raw_ids") or [0])[0])
            _url0 = str(_c.get("source_url") or "").strip()
            if not (_ev0.strip() and _rid0 > 0 and _url0):
                continue  # V30：无页面锚/无 URL/无证据，不生成关系（禁止关键词伪验证）
            _sup_eid = _eid_map.get(_sup.lower()) or _db2.save_trade_entity(
                task_id or "", {"company_name": _sup, "role": "supplier",
                                "evidence": _c.get("evidence"), "source_url": _url0,
                                "raw_page_id": _rid0},
                source_raw_page_id=_rid0, created_time=_now)
            _db2.save_trade_edge(task_id or "", _sup_eid, _eid_map.get(_name, ""),
                                 str(_c.get("product") or ""), _ev0,
                                 source_url=_url0, raw_page_id=_rid0,
                                 source_entity_id=_eid_map.get(_name, ""),
                                 confidence=float(_c.get("confidence") or 0.8), created_time=_now)
    report = {
        "pages": len(pages),
        "entities": len(merged),
        "edges": len(edges),
        "per_query": dict(per_query),
        "edges_detail": edges,
        "companies": sorted(merged.values(), key=lambda x: int(x.get("shipments") or 0), reverse=True),
    }
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        Path(out).write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", default=None)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--out", default=None)
    ap.add_argument("--top", type=int, default=30)
    args = ap.parse_args()
    task_id = None if args.all else (args.task or "")
    out = args.out or (f"data/refined/{task_id or 'all'}.json" if (args.out is None) else None)
    rep = refine(task_id=task_id, out=out)
    print(f"pages={rep['pages']} entities={rep['entities']} -> {out}")
    for c in rep["companies"][: args.top]:
        print(f"  {c.get('name')} | {c.get('role')} | {c.get('shipments')} | {c.get('country')} | pages={c.get('pages_seen')}")


if __name__ == "__main__":
    main()
