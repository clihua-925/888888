"""Build the fused release package via release_rules (the single rule source)."""

from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

from release_rules import deployable_files, is_deployable, is_excluded

# Backward-compatible test hook; the canonical rule remains release_rules.is_excluded.
_is_excluded = is_excluded

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "PSV_Trade_OS_FUSED_COMPLETE.zip"


def clean_transients() -> None:
    """Remove generated caches only; runtime config such as .env is never touched."""
    from release_rules import GENERATED_DIRS, GENERATED_SUFFIXES
    for path in sorted(ROOT.rglob("*"), reverse=True):
        if path.is_dir() and path.name in GENERATED_DIRS:
            shutil.rmtree(path, ignore_errors=True)
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in GENERATED_SUFFIXES:
            path.unlink()


def validate_clean_archive(files: list[Path]) -> None:
    forbidden = [path for path in files if not is_deployable(path.relative_to(ROOT).as_posix())]
    if forbidden:
        raise RuntimeError("Forbidden transient files remain: " + ", ".join(map(str, forbidden)))


def build() -> None:
    clean_transients()
    files = deployable_files(ROOT)
    # Recompute after manifest generation so the archive and manifest use one exact file set.
    files = deployable_files(ROOT)
    validate_clean_archive(files)
    if OUTPUT.exists():
        OUTPUT.unlink()
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(OUTPUT, "r") as archive:
        bad = [name for name in archive.namelist() if not is_deployable(name)]
        if bad:
            raise RuntimeError("Archive contains forbidden transient artifacts: " + ", ".join(bad))
    print(f"Fused package: {OUTPUT}")
    print(f"Files: {len(files)}")


if __name__ == "__main__":
    build()
