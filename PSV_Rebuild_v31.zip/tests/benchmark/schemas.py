"""Data schemas for the customs-collection benchmark."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class BenchmarkCase:
    case_id: str
    product: str
    country: str
    min_companies: int


@dataclass
class CaseResult:
    case_id: str
    success: bool
    company_count: int
    elapsed_seconds: float
    failure_code: str | None
    required_fields: list[str]
    field_complete_count: int = 0
    field_total_count: int = 0
    detail: dict = field(default_factory=dict)

    @property
    def field_completeness(self) -> float:
        if self.field_total_count == 0:
            return 0.0
        return round(self.field_complete_count / self.field_total_count, 4)
