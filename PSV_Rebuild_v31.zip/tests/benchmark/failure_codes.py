"""Standard failure classification codes for collection benchmark."""

from __future__ import annotations

from enum import Enum


class FailureCode(str, Enum):
    BROWSER_FAILED = "BROWSER_FAILED"
    NO_RECORDS = "NO_RECORDS"
    INCOMPLETE_FIELDS = "INCOMPLETE_FIELDS"
    TIMEOUT = "TIMEOUT"
    UNKNOWN = "UNKNOWN"


BROWSER_ERROR_MARKERS = (
    "cdp",
    "browser",
    "playwright",
    "cloudflare",
    "no_browser_context",
    "dom_agent",
)


def classify_failure(node_report: dict, company_count: int,
                     elapsed_seconds: float, elapsed_limit: float,
                     exc: BaseException | None = None) -> FailureCode:
    """Map a benchmark run outcome onto the standard failure-code enum."""
    if exc is not None:
        if isinstance(exc, TimeoutError):
            return FailureCode.TIMEOUT
        return FailureCode.UNKNOWN
    if elapsed_seconds >= elapsed_limit:
        return FailureCode.TIMEOUT
    if company_count == 0:
        errors = " ".join(str(e) for e in (node_report.get("errors") or [])).lower()
        if any(marker in errors for marker in BROWSER_ERROR_MARKERS):
            return FailureCode.BROWSER_FAILED
        return FailureCode.NO_RECORDS
    return FailureCode.UNKNOWN
