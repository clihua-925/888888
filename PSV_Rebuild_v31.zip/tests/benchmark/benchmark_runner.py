"""Real customs-collection benchmark runner.

Runs the production CUSTOMS_NODE_COLLECTION node function against benchmark
cases, counts companies, validates required fields, times execution and
writes a JSON report. No synthetic records are ever injected.

Usage:
    python -m tests.benchmark.benchmark_runner
"""

from __future__ import annotations

import json
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from tests.benchmark.failure_codes import FailureCode, classify_failure
from tests.benchmark.schemas import BenchmarkCase, CaseResult

BENCH_DIR = Path(__file__).resolve().parent
CASES_PATH = BENCH_DIR / "customs_cases" / "cases.json"
REPORTS_DIR = BENCH_DIR / "reports"

# Hard per-case wall-clock budget. The browser source itself budgets 6 minutes;
# the benchmark allows a little headroom and classifies overruns as TIMEOUT.
CASE_TIME_LIMIT_SECONDS = 420.0

# trade_nodes carry name/country/source; required company_name/product are
# validated against the canonical fields of the same record / case definition.
FIELD_MAPPING = {
    "company_name": ("name", "company"),
    "country": ("country",),
    "product": ("product", "product_name"),
    "source": ("source",),
}


def load_cases() -> tuple[list[BenchmarkCase], list[str]]:
    raw = json.loads(CASES_PATH.read_text(encoding="utf-8"))
    cases = [BenchmarkCase(**item) for item in raw["cases"]]
    required = list(raw["required_fields"])
    return cases, required


def build_minimal_state(case: BenchmarkCase) -> dict:
    """Minimal shared state: mission + fields CUSTOMS_NODE_COLLECTION reads."""
    return {
        "mission": {
            "task_id": f"BENCH_{case.case_id}",
            "description": f"Find {case.product} buyers in {case.country}",
            "market": case.country,
            "product": case.product,
        },
        "product_definition": {
            "product_name": case.product,
            "market": case.country,
            "industry": case.product,
        },
        "search_queries": [case.product],
        "trade_nodes": [],
        "evidence_pool": [],
        "fragments": [],
        "node_reports": {},
        "orchestration": {"step_count": 0, "no_progress_count": 0},
        "decisions": [],
        "history": [],
        "entities": [],
        "relationships": [],
        "error": {},
        "status": "RUNNING",
        "task_id": f"BENCH_{case.case_id}",
        "workflow_id": "trade_collection",
        "workflow_version": "9.4.1",
    }


def extract_companies(result: dict) -> list[dict]:
    nodes = result.get("trade_nodes") or []
    return [dict(item) for item in nodes if isinstance(item, dict)]


def validate_fields(companies: list[dict], product: str,
                    required: list[str]) -> tuple[int, int, list[str]]:
    """Return (complete_count, total_count, missing_fields) over required fields."""
    total = len(companies) * len(required)
    complete = 0
    missing: list[str] = []
    for company in companies:
        for field_name in required:
            value = None
            for key in FIELD_MAPPING.get(field_name, (field_name,)):
                value = company.get(key)
                if value:
                    break
            if field_name == "product" and not value:
                value = product  # product context comes from the case definition
            if value:
                complete += 1
            else:
                missing.append(field_name)
    return complete, total, missing


def run_case(case: BenchmarkCase, required: list[str]) -> CaseResult:
    from business.workflows.trade_collection.nodes import CUSTOMS_NODE_COLLECTION

    state = build_minimal_state(case)
    started = time.perf_counter()
    result: dict | None = None
    exc: BaseException | None = None
    try:
        result = CUSTOMS_NODE_COLLECTION(state)
    except BaseException as err:  # noqa: BLE001 - classify, never crash the bench
        exc = err
        traceback.print_exc()
    elapsed = time.perf_counter() - started

    companies = extract_companies(result) if isinstance(result, dict) else []
    node_report: dict = {}
    if isinstance(result, dict):
        reports = result.get("node_reports") or {}
        node_report = reports.get("CUSTOMS_NODE_COLLECTION") or {}

    complete, total, missing = validate_fields(companies, case.product, required)
    failure = classify_failure(
        node_report, len(companies), elapsed, CASE_TIME_LIMIT_SECONDS, exc,
    )
    if failure == FailureCode.UNKNOWN and companies and missing:
        failure = FailureCode.INCOMPLETE_FIELDS
    if failure == FailureCode.UNKNOWN and len(companies) < case.min_companies:
        failure = FailureCode.NO_RECORDS

    success = (
        exc is None
        and len(companies) >= case.min_companies
        and failure is FailureCode.UNKNOWN
        and not missing
    )
    if success:
        failure = None

    return CaseResult(
        case_id=case.case_id,
        success=success,
        company_count=len(companies),
        elapsed_seconds=round(elapsed, 3),
        failure_code=failure.value if failure else None,
        required_fields=required,
        field_complete_count=complete,
        field_total_count=total,
        detail={
            "product": case.product,
            "country": case.country,
            "min_companies": case.min_companies,
            "missing_fields": sorted(set(missing)),
            "node_report": {
                "status": node_report.get("status"),
                "success": node_report.get("success"),
                "collection_failed": node_report.get("collection_failed"),
                "errors": node_report.get("errors"),
            },
            "exception": type(exc).__name__ if exc else None,
        },
    )


def main() -> int:
    cases, required = load_cases()
    results: list[CaseResult] = []
    for case in cases:
        print(f"[benchmark] running {case.case_id}: {case.product} / {case.country}")
        result = run_case(case, required)
        results.append(result)
        print(
            f"[benchmark] {case.case_id}: success={result.success} "
            f"companies={result.company_count} elapsed={result.elapsed_seconds}s "
            f"failure={result.failure_code} completeness={result.field_completeness}",
        )

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = REPORTS_DIR / f"{stamp}.json"
    payload = {
        "generated_at": stamp,
        "summary": {
            "total": len(results),
            "passed": sum(1 for r in results if r.success),
            "failed": sum(1 for r in results if not r.success),
        },
        "results": [r.__dict__ for r in results],
    }
    report_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8",
    )
    print(f"[benchmark] report written: {report_path}")
    return 0 if all(r.success for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
