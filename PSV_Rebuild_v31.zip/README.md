# PSV Trade OS 9.4.0
9.4.1 (2026-09-16) 整合维护版：
  - 统一版本标识至 9.4.1（VERSION/release_rules/settings/三个workflow spec/启动横幅）
  - 清理诊断与打包残留（diagnose_workflow.py、stage_b_verify.py、pack_fused.py、
    两份 diagnose jsonl 日志），均经 AST 引用扫描确认零引用
  - 节点AI化修复合入：产品定义/贸易策略接入本地AI、海关采集查询管道恢复、
    数据源级联短路修复、英文搜索保障、页面垃圾过滤、证据核验批量修复
  - 模型调用放宽：单次超时默认3600s（LLM_TIMEOUT_SECONDS可调）、
    输出上限默认16384（LLM_MAX_TOKENS可调）、任务总预算7200s
  - 启动链加固：CRLF行尾修复、8090/9222端口预检、依赖探针离线可重启、
    .env旧值自动迁移、Python 3.10-3.14


编排式贸易情报系统：LangGraph 声明式工作流 + 进程级调度执行 + WebUI 任务控制台。

## 快速启动（Windows）

双击 `start.bat`。启动器自动：解析解释器（项目 `.venv` → 系统 Python → 旁侧 venv）→
补齐 `.env` → 校验/安装依赖 → 原生扩展自检自愈（uuid-utils/langgraph）→ 静态验证
（`verify_install.py`，期望 `VERIFY_OK`）→ 拉起 WebUI（http://127.0.0.1:8090）→ 打开 CDP 浏览器。

手动方式：`.venv\Scripts\python.exe run_webui.py`

## 工作流（任务总控下拉选择，全部经真实引擎调度）

| 工作流 | 节点数 | 用途 |
|---|---|---|
| trade_collection | 9 | 海关采集链：产品定义→策略→采集(宽松判断/标准信息)→核验→归一→建边→扩张→分类→落库 |
| network_expansion | 5 | 网络扩张：方案→种子→多跳扇出→标准化→落库 |
| outreach | 8 | 开发信：方案→选潜客→画像→资格→AI写信→审查门→自动发送→落库 |

每个节点执行后由**专家质检层**做 LLM 验收（规则兜底、离线降级，`EXPERT_REVIEW_ENABLED` 开关）。

## 环境开关（.env）

- `OUTLOOK_SEND_ENABLED=0` 开发信自动发送（需 9222 CDP 浏览器登录 Outlook，潜客带 email/contact）
- `EXPERT_REVIEW_ENABLED=1` 专家质检层
- `IY_FETCH_ENABLED=1` ImportYeti 真实抓取（本地 data/imports 优先，失败静默降级）
- LLM：`LLM_BASE_URL` / `LLM_API_KEY` / `LLM_MODEL`

## 维护命令

```cmd
.venv\Scripts\python.exe verify_install.py            :: 静态验证（VERIFY_OK）
.venv\Scripts\python.exe stage_b_verify.py            :: 深度验证链
```

## 结构

见 `ARCHITECTURE.md`。分层纪律：business 只依赖 core.contracts / core.config，
编排（core.orchestration）与业务（business）完全解耦，经 registry 动态发现 + provider 注入协作。
