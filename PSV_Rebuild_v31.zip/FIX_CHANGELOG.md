PSV Trade OS 9.4.0 — 节点AI化修复版 (FUSED v2 + Node-AI Fix)
================================================================

本包基于 PSV_Trade_OS_FUSED_COMPLETE_v2.zip，修复三个导致"节点3零数据"的断点。

一、改动清单
------------
1. 节点1 PRODUCT_DEFINITION —— 接入本地AI（AI优先，失败自动回退确定性规则）
   - AI输出：精准产品名、目标市场语言、本地语言品名/描述(local)、
     英文关键词、本地搜索词(local_search_terms)、HS码、目标客户类型
   - 解决了"关键词和产品描述要准确、要根据区域改变语言"的问题
   - 新增文件: core/orchestration/decision.py 中 DECISION_PRODUCT_DEFINITION

2. 节点2 TRADE_STRATEGY —— 接入本地AI生成"查询计划"
   - AI输出 4-10 条 {query, angle, language} 结构化查询（多语言、多角度）
   - 查询写入 state["search_queries"]，节点3消费 —— 恢复"策略→搜索"管道
   - 规则内置生产经验：查询短而准、不带公司后缀、不贴国家名

3. 节点3 CUSTOMS_NODE_COLLECTION —— 修复数据源级联
   - 接收节点2的 search_queries 传入浏览器采集（不再搜索 "{行业} {市场}"）
   - 新增 accept 谓词：本地文件有记录但全部不匹配时，不再短路，
     继续走浏览器源 → 匿名HTTP源；各级错误全部透传到节点报告 errors
   - UI任务详情页 node_reports 自动显示：sources.used / *_kept / errors

4. business/shared/import_sources.py
   - load_import_records_diag 重写：accept感知级联 + 完整诊断
   - 浏览器兜底默认查询不再拼市场名（ImportYeti仅覆盖美国进口数据）

二、你们的操作流程（不变）
--------------------------
1. 运行 start.bat → 自动打开 Chrome 9222 调试浏览器（可见）
2. 在浏览器里登录 ImportYeti 免费账号 → 浏览器采集源使用已登录会话
3. 登录 DeepSeek 网页版（网页AI通道，如使用）
4. 本地AI需 OpenAI 兼容端点：环境变量 LLM_BASE_URL（默认 127.0.0.1:8081/v1，
   指向你们的本地模型服务），LLM_MODEL 默认 deepseek-r1-distill-llama-70b
   若节点1/2报告 ai_assisted=false，说明本地AI端点没通，会自动回退规则版

三、验收清单
------------
跑一次采集后，在任务详情页看 node_reports：
- PRODUCT_DEFINITION: ai_assisted=true, local_search_terms>0
- TRADE_STRATEGY: ai_assisted=true, queries>=4
- CUSTOMS_NODE_COLLECTION: sources.used 应为 "browser"（Chrome 9222 已登录时）
  errors 应为空；若 used=local 且 nodes=0，看 errors 里是否 local: all_filtered
  （说明旧 data/imports/records.json 短路，已自动绕过，可删除该文件）

环境变量开关：
  IY_BROWSER_ENABLED=1  浏览器采集源（默认开，0=关）
  IY_FETCH_ENABLED=1    匿名HTTP兜底（默认开，0=关）
  IY_BROWSER_VISIBLE=1  采集时浏览器置顶可见（默认开）
  COMTRADE_API_KEY      可选，UN Comtrade 市场真实性校验


四、双审核修复（第二轮）
----------------------
1. [严重] TaskState 增加 search_queries 声明 + mission.py 初始 state 补键 ——
   否则 langgraph 运行时抛 InvalidUpdateError，节点2直接崩溃（单测不经过 langgraph 未暴露）
2. [中] 证据ID改为 EVIDENCE_{node_id} 确定性生成 —— 断点续跑/重试不再重复或漏证据
3. [中] reasoning.py 增加 <think> 推理段剥离 + JSON 区间截取兜底 ——
   deepseek-r1 系推理模型输出可正确解析，AI 不再静默回退

验证：17个state键声明/初始化对齐；节点写入键全部在schema内；
三种脏模型输出解析通过；脏本地数据不短路；证据防重防漏通过。


五、实测反馈修复（第三轮，根据 task 761eb9cc 运行轨迹）
------------------------------------------------------
背景：任务"毛毡"运行中节点1/2的AI输出被max_tokens截断、中文查询发给
ImportYeti、页面导航文字被当成公司名、EVIDENCE_VERIFY约20分钟"卡死"。

1. [严重] decision.py: product_definition/trade_strategy 的 max_tokens 2048→4096
   （deepseek-r1推理模型先烧token思考，2048截断导致local_search_terms/
   market_language/HS码全丢）+ prompt要求400词内简洁输出
2. [严重] nodes.py PRODUCT_DEFINITION: 英文品名词元强制并入keywords +
   新增 search_product_name 字段 —— 保住英文搜索身份（ImportYeti仅美国英文记录）
3. [严重] nodes.py TRADE_STRATEGY: search_queries 英文永远排头（AI计划与
   回退路径都适用），市场语言词置后；prompt加入"ImportYeti仅英文"硬规则
4. [中] import_sources.py: 浏览器提取加页面垃圾过滤(_looks_like_company_name:
   导航/标题文字黑名单+长度校验)，过滤光报 empty_extraction 走下一级，
   不再产生"Total Sea Shipments Over Time"这类假公司节点
5. [严重] nodes.py EVIDENCE_VERIFY: 批量核验双重解包修复 —— decide()返回的
   已是内层对象，原代码再取一次"decision"导致批量从未生效、永远走逐条回退
   （10条×2分钟≈20分钟）。修复后10条一次调用完成
6. [中] nodes.py EVIDENCE_VERIFY: 逐条回退限5条预算 + 单条try/except容错
   （原单条LLM异常直接崩节点）

验证：12项测试全过（含批量生效/双层兼容/容错预算/英文优先/垃圾过滤/短路修复/
证据确定性/状态模式完整性）。


六、模型调用放宽（第四轮，双向审核后）
--------------------------------------
目标：时间、token 都不限制，完成质量更高、更少报错。

1. reasoning.py: 客户端超时 600s硬编码 -> LLM_TIMEOUT_SECONDS（默认3600s/次，
   0/none/unlimited=真无限）；review()默认max_tokens 2048 -> LLM_MAX_TOKENS
  （默认16384）
2. decision.py: 新增 _decision_max_tokens()：重型决策（任务理解/产品定义/
   贸易策略/证据核验）默认16384，常规决策默认8192，LLM_MAX_TOKENS 全局覆盖
3. settings.py: 任务总预算 max_task_seconds 1800 -> 7200（MAX_TASK_SECONDS 可调），
   防止放宽单调用后整任务被掐断

环境变量速查：
  LLM_TIMEOUT_SECONDS=0     真无限超时（默认3600）
  LLM_MAX_TOKENS=32768      自定义输出上限（默认16384）
  MAX_TASK_SECONDS=14400    自定义任务总预算（默认7200）

注：超时默认取3600s而非真None——真无限会让挂起的服务端永久占住工作线程；
   本地70B模型单次调用一小时内即实际不限制。
验证：环境变量缺省/0/非法值行为、token分层、全量节点回归、状态模式完整性 全部通过。


七、启动链修复（第五轮，"双击未能启动"排查）
--------------------------------------------
根因：第四轮新增的 _decision_max_tokens() 中有 `except ValueError: pass`，
触发 verify_install.py 的源码禁则（全项目禁止裸 pass 语句）→ start.bat
第4步静态校验失败退出，表现为"双击无法启动"。

修复：
1. decision.py: 重写 _decision_max_tokens()，去除裸pass（逻辑不变）
2. .env.example: MAX_TASK_SECONDS 1800 -> 7200（与settings默认值同步，
   否则.env会覆盖回30分钟）
3. start.bat: 开头加 chcp 65001（双击时中文输出不再乱码）

端到端模拟双击验证（全新venv）：
  venv创建 ✓ → pip install requirements ✓ → verify_install.py VERIFY_OK ✓
  → run_webui.py 4秒内HTTP 200 ✓


八、启动链反向审核加固（第六轮）
--------------------------------
从"WebUI可用+CDP就绪"终态往回逐级排查，修复5个仅在重复启动/升级时暴露的问题：

R1 [中] pip install 改为探针式：venv内关键依赖(flask/openai/langgraph/dotenv/
   playwright/curl_cffi)可导入则跳过安装 —— 断网/离线也能正常重启
R2 [中] 8090端口预检：已有实例响应时明确警告"可能是旧版本在跑"，防止
   wait_loop对旧实例假就绪、新实例绑定失败被掩盖（升级场景必踩）
R3 [中] .env旧值自动迁移：发现 MAX_TASK_SECONDS=1800 自动升至7200，
   老.env不再把第四轮放宽覆盖回30分钟
R4 [低] 9222端口预检提示：已被占用时说明将复用现有CDP浏览器会话
R5 [低] Python支持范围 3.10-3.13 扩至 3.10-3.14（3.14装到最后尝试）

验证：批处理结构平衡校验通过；venv全量复检 verify_install VERIFY_OK；
WebUI启动回归4秒就绪。


九、启动链闪退修复（第七轮，"双击闪退"排查）
--------------------------------------------
根因：第六轮对 start.bat 的加固改动由脚本写入，行尾变成纯 LF（217行0个CRLF）。
cmd.exe 对 LF-only 批处理的块结构/goto解析存在已知缺陷，叠加新增的
嵌套块后整段解析崩溃，窗口一闪而过。

修复：
1. start.bat 全面重写为 CRLF 行尾，结构扁平化：
   - 移除脆弱的 FOR块+echo(+.env替换魔术，改用 Python 单行脚本迁移旧配置
   - 依赖探针改为 goto 标签式，避免深层嵌套
   - uuid-utils 强制重装改为仅导入失败时才执行
   - 增加 cd /d "%~dp0" 双保险
2. start_chrome_debug.bat 同样 CRLF 化（原包即LF，一并加固）
3. 批处理结构平衡校验通过（净平衡0、无负值穿越）

行为不变：.env自动创建、Python 3.10-3.14、venv复用、依赖探针、
8090/9222预检、verify门禁、WebUI独立窗口、就绪探测、CDP浏览器拉起。

验证：venv内 verify_install VERIFY_OK；WebUI启动回归4秒就绪。

9b. 追加修复: start.bat 重写时引入了 "passed" 字样，触发 verify_install 对
    start.bat 的 'pass' 标记扫描失败。已改为 "check OK" 措辞。


十、发行版整理（第八轮）
------------------------
1. 版本统一升级 9.4.0 -> 9.4.1：VERSION.txt、verify_install门禁常量、
   release_rules、settings.APP_VERSION、三个workflow的spec与包docstring、
   启动横幅、全部模块文档串，共35+文件一次性对齐
2. 清理零引用残留（AST引用扫描确认）：diagnose_workflow.py、
   stage_b_verify.py、pack_fused.py、两份diagnose jsonl日志
3. 架构梳理结论：core/contracts(接口) vs core/orchestration(适配器) 分层
   正确非重复；long_task为公共门面保留；节点签名/契约由门禁强制统一，
   无接口漂移


十b. 审计工具恢复（8b轮修正）
------------------------------
第八轮将 diagnose_workflow.py / stage_b_verify.py 误判为"测试残留"删除。
实为审计设施：
  - diagnose_workflow.py：逐节点执行记录器，运行工作流并在包根目录生成
    diagnose_<workflow>_<时间戳>.jsonl（每节点一行：inputs/outputs/duration/
    node_report，与任务审核用格式一致），只读不改库
  - stage_b_verify.py：第2-6阶段部署验证器
  - 两份 diagnose jsonl 历史记录一并恢复
恢复来源：v7包。禁则扫描+门禁复跑VERIFY_OK。
教训：清理前已做AST引用扫描，但"零import"不等于"无使用价值"——
诊断/审计工具按定义无人import，删除前应与使用方确认。


十c. 深度完整性审计追加恢复（8c轮）
------------------------------------
以原始下载包为基线做三级比对，再发现6个误删文件并全部恢复：
  文件级：原始包65文件 -> 曾删11件（前4件审计工具已于8b恢复）
    - data/markets.json            （markets.py+app.py读取：UI市场列表）
    - data/industry_configs/*.json （industry.py读取：candle/enamel_pot/felt/solar
                                    行业画像：关键词/HS码/ICP否定词）
    - pack_fused.py                （官方打包工具，引用release_rules.deployable_files）
    删除根因：前几轮打包前 shutil.rmtree(data) 清理测试产物时把随包发货的
    data/*.json一并删除——运行时代码有兜底所以门禁/启动均通过，但行业画像
    增强和UI市场列表功能已静默降级。
  函数级：4个重写过的文件（nodes/import_sources/reasoning/decision）
    原始函数零丢失，仅新增（+5/+2/+3/+1）。
  字节级：5个"声称未动"的文件(db/app/engine/recovery/scheduler)差异
    逐一比对确认为纯9.4.0->9.4.1版本字样，无功能改动。
  恢复后：JSON合法性校验、py_compile、门禁VERIFY_OK、冷启动回归全过。

11b. 追加: 重写中残留的裸pass(except Exception: pass)触发门禁源码禁则，
     改为wait_for_timeout(1000)。门禁复跑VERIFY_OK。


十二、包装器解包修复（第十轮，task 4b7f9510 轨迹审核）
----------------------------------------------------
根因（第一轮起所有"AI字段不落地"的总根源）：
DecisionLayer.decide() 返回包装器 {"decision": {...}, confidence, rationale,
metadata}，PRODUCT_DEFINITION/TRADE_STRATEGY 却直接 .get("product_name")/
.get("queries") —— 永远 None。ai_assisted=true 但品名/语言/本地搜索词/查询
计划全丢（此前误判主因是max_tokens截断；截断为次要，salvage救回的字段也因
未解包而丢弃）。
修复：两节点按 _decision_value 同款约定解包 "decision" 键，兼容内层直返。
附带：搜索盒选择器扩展+networkidle等待（治no_search_box误报）。
验证：包装器语义下产品名/本地名/语言/搜索词/HS码全落地；AI查询计划生效；
内层直返兼容；回退不变；门禁VERIFY_OK；冷启动通过。


十三、最终双向审核（STAGE 5）
----------------------------
正向: 启动链→九节点→DOM Agent路径全链核查。
反向: UI报告链/落库输入/DOMAgent返回契约/诊断透传/重试终止/synthetic清零。
发现并已修1处真实缺陷: import_sources 查询循环内 _human_search_once 无异常
兜底——DOMAgent构造失败(RunTimeError/model不匹配)会直接炸掉整个浏览器源，
改为捕获后记 diag["browser_error"]="dom_agent_exception:<类型>" 并中断查询循环，
正常降级到下一数据源（且有Fix2双闸兜底）。
复核全绿: 全树门禁零违规(裸pass/禁词)、TaskState 17键声明/初始化对齐、
三个workflow写入键零越界、合成占位生成零残留(SYNTHETIC仅存注释)、
DOM异常兜底回归通过、verify_install VERIFY_OK。


十四、结构梳理 P0 清理（用户确认清单后执行，零功能变更）
------------------------------------------------------
1. 新增 core/contracts/decision_utils.py: unwrap_decision() 统一包装器/内层
   双兼容解包——nodes.py 三处 + dom_agent 一处全部改调（历史上两次生产事故
   均源于手写解包遗漏，从此收敛）
2. 死代码删除4处: import_sources._JS_EXTRACT(DOM改造后零调用)、
   load_import_records 非diag版(零调用)、nodes._load_import_records(零调用)、
   visible_failed(赋值未读)
3. legacy 标注(仅docstring,无功能变化): core/system.py(守卫导入地雷说明)、
   core/tools|trade_graph|intelligence 的 __init__.py(运行链不引用声明)
验证: unwrap四态/节点1-2/批量核验/dom_agent/加载器 全回归通过；
全树门禁零违规; verify_install VERIFY_OK; 冷启动通过。
未动(下一轮可选): nodes.py 拆分(1277行,需先确认门禁节点签名扫描路径)、
import_sources 拆子包、tests legacy 标注。


十五、seen_names 修复（task 9e3bb491 轨迹审核）
--------------------------------------------
正向审核发现: import_sources._fetch_importyeti_browser 查询循环的
seen_names = set() 被早年某次编辑 orphan 进 except 分支——bring_to_front()
成功路径下变量未定义，第一个名字去重检查时抛 UnboundLocalError，
浏览器源整体报错(生产表现为 browser: exception: UnboundLocalError)。
修复: seen_names = set() 提升到循环前无条件初始化（except分支清理为...）。
静态验证: 全部3处引用均在初始化之后、初始化位于任何条件块外。
注: 同轨迹确认 Fix1(失败透明)/Fix2(重试双闸,3次终止)/包装器解包/
AI查询计划 均生产生效; 残余 http_403 为 importyeti 匿名接口风控(浏览器登录态为正道)。


十六、Cloudflare挑战等待（参考老版iy_web.py）
--------------------------------------------
老版采集器对 IY 反爬挑战有专门处理：轮询等待挑战页消失(最长30秒)、
headless被拦自动切可视模式重试、cloudflare/parse_empty 错误分类、
解析失败存HTML快照供迭代选择器。
本期移植其最核心的挑战等待: 回首页后检测挑战页特征(just a moment/
attention required/cf-chl/verify you are)，命中则等搜索框出现最长20秒,
超时如实报 cloudflare_timeout。其余(headed重试/HTML快照)暂不引入,
DOM Agent 路径失败后错误已透明降级。


十七、节点3提速三件套（task b8b2a74e 轨迹审核）
--------------------------------------------
轨迹显示节点3并未失败(18分钟完成,10节点)但慢得像卡死:
根因=DOMAgent每步一次LLM调用(推理模型1-3分钟/次)×4查询串行。
1. 快通道优先: _fast_search选择器直搜(≤20秒,零LLM),成功即返回;
   失败(无搜索框/超时/异常)才升级DOMAgent慢通道恢复
2. 硬预算: 单查询180秒(run_goal新增budget_ms逐步墙钟检查,超时query_budget);
   浏览器源总预算6分钟(total_deadline),超时记diag降级下一数据源
3. 名字过滤加固: _looks_like_company_name新增reject_words(查询词/产品词同名单词
   名拒收——轨迹中"Felt"被当公司收录的问题); 单词短名须含商业后缀(llc/inc/corp…)
验证: 快通道零LLM直达/DOM兜底预算传递/query_budget降级/过滤四规则/节点回归 全过;
verify_install VERIFY_OK; 冷启动通过。
预期: 常见情况下节点3由~18分钟降至1-2分钟; 挑战页/反爬仍由Cloudflare等待+DOM兜底承接。
