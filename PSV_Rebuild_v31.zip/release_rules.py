"""Single source of truth for deployable-file classification (release rules only).

This module belongs to neither the orchestration layer nor the business layer.
It only answers: is a project-relative path a deployable source file?
Every consumer (packer, manifest generator, acceptance test, verify scripts,
ZIP final check) must call this implementation and never re-implement it.
"""

from __future__ import annotations

__version__ = "9.4.1"

import re
from pathlib import Path

# Runtime-only configuration: never deployable, never in the manifest, never in the ZIP.
RUNTIME_ONLY_NAMES = {".env"}

# Deployable template: must always survive every wildcard (explicitly allowed).
DEPLOYABLE_TEMPLATES = {".env.example"}

# Generated / cache / VCS / venv directories.
GENERATED_DIRS = {"__pycache__", ".pytest_cache", ".venv", "venv", ".git", "stageb_variants", "backups"}

# Generated file suffixes.
GENERATED_SUFFIXES = {".pyc", ".pyo", ".tmp", ".bak", ".swp"}

# Runtime output files produced by local execution.
GENERATED_FILES = {
    "webui.out.log", "webui.err.log", "webui_runtime.log", "verify_output.log", "monitor_task.py",
}

# Stage B development leftovers and apply-script backups.
RESIDUE_NAMES = {"nodes.py.real"}
BACKUP_NAME = re.compile(r"\.before_b\d+$")


def is_deployable(rel: str) -> bool:
    """Return True when a project-relative posix path is a deployable source file."""
    parts = rel.split("/")
    name = parts[-1]
    if name in RUNTIME_ONLY_NAMES:
        return False
    if name in DEPLOYABLE_TEMPLATES:
        return True
    if any(part in GENERATED_DIRS for part in parts):
        return False
    if rel.startswith("data/") and ".db" in name:
        return False
    if name in GENERATED_FILES or name in RESIDUE_NAMES:
        return False
    if Path(name).suffix.lower() in GENERATED_SUFFIXES:
        return False
    if BACKUP_NAME.search(name):
        return False
    return True


def is_excluded(path) -> bool:
    """Legacy interface used by tooling: True when the path is NOT deployable."""
    return not is_deployable(Path(path).as_posix().replace("\\", "/"))


def deployable_files(root: Path) -> list[Path]:
    """All deployable files under root, sorted by relative posix path."""
    return sorted(
        (p for p in root.rglob("*") if p.is_file() and is_deployable(p.relative_to(root).as_posix())),
        key=lambda p: p.relative_to(root).as_posix(),
    )
