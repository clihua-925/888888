"""Stage 2-6 verification runner for PSV Trade OS 9.4.0.

Pure verification tool. It never modifies the source tree: no file deletion,
no process termination. Runtime configuration is read exclusively from .env.
The runner itself is a deployable project tool (root-level .py).
"""

from __future__ import annotations

import argparse
import os
import re

from release_rules import is_deployable
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PY = sys.executable
LAST_RUNTIME_OUTPUT = ""



def hr(title: str) -> None:
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


def ts(message: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {message}")


def run(cmd, cwd=None, timeout=300):
    proc = subprocess.run(
        cmd, cwd=cwd or ROOT, capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def load_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip()
    return values


def step_0_environment_check() -> bool:
    """Read-only environment check. Never deletes files, never kills processes."""
    hr("STEP 0: Environment check (read-only)")
    port = int(os.environ.get("WEB_PORT", "8090"))
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.settimeout(1)
    try:
        probe.connect(("127.0.0.1", port))
        busy = True
    except OSError:
        busy = False
    finally:
        probe.close()
    if busy:
        print(f"  [WARN] Port {port} is already in use.")
        print("  [HINT] Stop the existing service in another window, then re-run this script.")
        print("         This runner never terminates processes automatically.")
    else:
        print(f"  [OK] Port {port} is free")
    print(f"  [OK] Python: {PY}")
    return True


def step_2_architecture_verification() -> bool:
    """Cross-layer import-direction scan; does not duplicate the acceptance suite."""
    hr("STEP 2: Architecture verification (cross-layer import direction)")
    problems: list[str] = []
    orchestration_dir = ROOT / "core" / "orchestration"
    business_dir = ROOT / "business"
    for path in sorted(orchestration_dir.rglob("*.py")):
        text = path.read_text(encoding="utf-8", errors="replace")
        if re.search(r"^\s*(from|import)\s+business\.", text, re.MULTILINE):
            problems.append(f"orchestration imports business: {path.relative_to(ROOT)}")
    for path in sorted(business_dir.rglob("*.py")):
        text = path.read_text(encoding="utf-8", errors="replace")
        if "core.orchestration" in text:
            problems.append(f"business imports orchestration: {path.relative_to(ROOT)}")
    if problems:
        for item in problems:
            print(f"  [FAIL] {item}")
        return False
    print("  [OK] Orchestration layer has no business imports")
    print("  [OK] Business layer has no orchestration imports")
    return True


def step_3_hygiene() -> bool:
    """Verify release-tree hygiene using the canonical release rule only."""
    hr("STEP 3: Release package hygiene")
    forbidden_found = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if not is_deployable(rel):
            forbidden_found.append(rel)
    if forbidden_found:
        for rel in forbidden_found:
            print(f"  [FAIL] Non-deployable artifact present: {rel}")
        return False
    print("  [OK] Release tree contains only files allowed by release_rules.is_deployable()")
    return True

def step_4_manifest() -> bool:
    """Manifest file was retired in Rev.3 cleanup; consistency is now implied by step_3."""
    hr("STEP 4: Manifest consistency")
    print("  [SKIP] PROJECT_SOURCE_MANIFEST.txt retired (Rev.3 cleanup); step_3 covers deployable-tree rules")
    return True
def step_5_runtime(env: dict[str, str]) -> bool:
    hr("STEP 5: Runtime verification (verify_install.py --runtime)")
    if not env.get("LLM_BASE_URL"):
        print("  [FAIL] LLM_BASE_URL not set in .env; configure runtime before --runtime")
        return False
    global LAST_RUNTIME_OUTPUT
    rc, out, err = run([PY, "verify_install.py", "--runtime"], timeout=1800)
    LAST_RUNTIME_OUTPUT = out or ""
    tail = "\n".join(LAST_RUNTIME_OUTPUT.splitlines()[-15:])
    print(tail)
    if rc != 0:
        print(f"\n  [FAIL] runtime verification failed (rc={rc})")
        if err:
            print(f"  stderr: {err[:800]}")
        return False
    print("\n  [PASS] runtime verification finished (rc=0)")
    return True


def step_6_db_check(env: dict[str, str]) -> bool:
    """Verify DB creation during Runtime Gate; verify_install removes its temp tree afterward."""
    hr("STEP 6: Runtime database artifacts")
    if "RUNTIME_DB_CHECK=PASS" not in LAST_RUNTIME_OUTPUT:
        print("  [FAIL] verify_install.py did not report successful runtime DB/checkpoint validation")
        return False
    print("  [PASS] Runtime DB/checkpoint files were validated while the temporary runtime tree was alive")
    print("  [INFO] verify_install.py removes the temporary DB/checkpoint tree after validation; Step 6 does not inspect project data/ files")
    return True

def main() -> int:
    parser = argparse.ArgumentParser(description="PSV Trade OS 9.4.0 Stage 2-6 verification runner")
    parser.add_argument("--skip-runtime", action="store_true",
                        help="skip Step 5 runtime gate and Step 6 db check")
    parser.add_argument("--runtime", action="store_true",
                        help="force full runtime verification (default when neither flag is given)")
    args = parser.parse_args()
    do_runtime = not args.skip_runtime

    env = load_env(ROOT / ".env")
    results: dict[str, bool] = {}
    hr("Stage 2-6 verification: PSV Trade OS 9.4.0")
    results["Step 0 Environment check"] = step_0_environment_check()
    results["Step 2 Architecture verification"] = step_2_architecture_verification()
    results["Step 3 Hygiene"] = step_3_hygiene()
    results["Step 4 Manifest"] = step_4_manifest()
    if do_runtime:
        results["Step 5 Runtime"] = step_5_runtime(env)
        results["Step 6 DB artifacts"] = step_6_db_check(env) if results["Step 5 Runtime"] else False
    else:
        print("\n[INFO] --skip-runtime: Step 5 and Step 6 skipped")
    hr("SUMMARY")
    failed = 0
    for label, ok in results.items():
        mark = "PASS" if ok else "FAIL"
        if not ok:
            failed += 1
        print(f"  [{mark}] {label}")
    if failed:
        print(f"\n  FAILED - {failed} step(s) failed")
        return 1
    mode_name = "full" if do_runtime else "--skip-runtime"
    print(f"\n  ALL PASS - Stage 2-6 verified ({mode_name} mode)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
