"""数据层仓库：Node/Service 与 Database 之间的唯一通道（V31 解耦）。

业务层只允许调用本仓库，禁止 nodes.py / services 直接 db.insert/save。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from core.config.settings import settings
from core.memory.db import Database


class TradeRepository:
    def __init__(self, database: Database | None = None) -> None:
        self._db = database or Database(Path(settings.database_path))

    # Bronze
    def save_raw_page(self, task_id: str, query: str, page_number: int, url: str,
                      html: str, text: str, title: str = "", screenshot: str = "") -> int:
        return self._db.save_raw_page(task_id, query, page_number, url, html, text,
                                      title=title, screenshot=screenshot)

    def get_raw_pages(self, task_id: str | None = None, query: str | None = None,
                      limit: int = 5000) -> list[dict[str, Any]]:
        return self._db.get_raw_pages(task_id=task_id, query=query, limit=limit)

    # Silver
    def save_extracted_entity(self, task_id: str, entity: Mapping[str, Any],
                              raw_page_id: int = 0) -> str:
        return self._db.save_trade_entity(task_id, entity, source_raw_page_id=raw_page_id)

    def get_extracted_entities(self, task_id: str | None = None,
                               limit: int = 5000) -> list[dict[str, Any]]:
        return self._db.get_trade_entities(task_id=task_id, limit=limit)

    # Gold（预生成，证据驱动）
    def save_extracted_edge(self, task_id: str, supplier_id: str, buyer_id: str,
                            product: str, evidence: str, source_url: str = "",
                            raw_page_id: int = 0, source_entity_id: str = "",
                            confidence: float = 0.0) -> str:
        return self._db.save_trade_edge(task_id, supplier_id, buyer_id, product, evidence,
                                        source_url=source_url, raw_page_id=raw_page_id,
                                        source_entity_id=source_entity_id, confidence=confidence)

    def get_extracted_edges(self, task_id: str | None = None,
                            limit: int = 5000) -> list[dict[str, Any]]:
        return self._db.get_trade_edges(task_id=task_id, limit=limit)


repository = TradeRepository()
