# -*- coding: utf-8 -*-
"""Shared Schema - 公共数据结构，被contracts引用"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime

class TraceContext(BaseModel):
    """追踪上下文"""
    trace_id: str
    workflow_id: str
    task_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class Pagination(BaseModel):
    """分页参数"""
    page: int = 1
    page_size: int = 20
    total: int = 0

class ApiResponse(BaseModel):
    """统一API响应"""
    success: bool = True
    code: str = "OK"
    message: str = ""
    data: Optional[Dict[str, Any]] = None
    trace_id: Optional[str] = None
