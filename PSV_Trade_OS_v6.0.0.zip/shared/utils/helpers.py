# -*- coding: utf-8 -*-
"""Shared Utils - 纯工具函数，零外部依赖"""
import re
import uuid
import hashlib
from typing import Any, Dict
from datetime import datetime

def generate_id(prefix: str = "") -> str:
    """生成唯一ID"""
    return f"{prefix}{uuid.uuid4().hex[:16]}"

def normalize_company_name(name: str) -> str:
    """企业名称归一化"""
    if not name:
        return ""
    name = name.upper().strip()
    name = re.sub(r"\s+", " ", name)
    name = re.sub(r"[^A-Z0-9\s]", "", name)
    suffixes = ["INC", "LLC", "LTD", "CORP", "CO", "GMBH", "SARL", "BV", "PTY"]
    for suffix in suffixes:
        name = re.sub(rf"\s+{suffix}\b", "", name)
    return name.strip()

def hash_dict(data: Dict[str, Any]) -> str:
    """字典哈希"""
    import json
    return hashlib.md5(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def now_iso() -> str:
    """当前ISO时间"""
    return datetime.utcnow().isoformat()

def safe_get(data: Dict, key: str, default: Any = None) -> Any:
    """安全获取字典值"""
    if not isinstance(data, dict):
        return default
    return data.get(key, default)
