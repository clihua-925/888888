# -*- coding: utf-8 -*-
"""Shared Config - 纯配置，不依赖任何业务模块"""
import os
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()

class Settings:
    """统一配置入口，database通过app/main.py注入，不在这里创建连接"""

    # 应用
    APP_NAME = "PSV Trade OS"
    APP_VERSION = "6.0.0"
    DEBUG = os.getenv("DEBUG", "false").lower() == "true"

    # 数据库（仅配置字符串，不创建连接）
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///data/psv_trade.db")

    # LLM
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o")
    LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.3"))

    # 采集
    COLLECTION_CONFIG = {
        "max_workers": int(os.getenv("MAX_WORKERS", "4")),
        "request_timeout": int(os.getenv("REQUEST_TIMEOUT", "30")),
        "user_agents": [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.0",
        ],
        "retry_times": 3,
        "retry_delay": 2,
    }

    # 客户分级
    CUSTOMER_TIERS = ["S", "A", "B", "C", "D"]
    DEVELOPMENT_STAGES = ["new", "contacted", "qualified", "proposal", "negotiation", "closed"]

    # 审计
    AUDIT_CONFIG = {
        "batch_size": int(os.getenv("AUDIT_BATCH_SIZE", "100")),
        "flush_interval_sec": 30,
    }

    # 恢复
    RECOVERY_CONFIG = {
        "checkpoint_ttl_days": 7,
        "max_recovery_attempts": 3,
    }

    # 缓存
    CACHE_CONFIG = {
        "default_ttl": 3600,
        "max_size": 10000,
    }

settings = Settings()
