# -*- coding: utf-8 -*-
"""Orchestrator测试"""
import unittest
from orchestrator import TradeOrchestrator, PlannerAgent, SupervisorAgent, RouterAgent
from state import create_initial_workflow_state

class TestOrchestrator(unittest.TestCase):
    def test_planner(self):
        planner = PlannerAgent()
        plan = planner.plan("开发美国蜡烛进口商", "birthday candles", "USA")
        self.assertTrue(len(plan["plan"]) > 0)
        self.assertEqual(plan["schema_version"], None)  # plan返回dict，非Pydantic

    def test_workflow_state(self):
        state = create_initial_workflow_state("task_123", "test", "product", "USA")
        self.assertEqual(state["task"]["task_id"], "task_123")
        self.assertEqual(state["schema_version"], "2.0.0")

    def test_router(self):
        router = RouterAgent()
        state = {"errors": [], "current_step": 0, "plan": [{}, {}], "should_pause": False, "recovery_attempts": 0}
        self.assertEqual(router.route(state), "executor")

    def test_supervisor(self):
        sup = SupervisorAgent()
        state = {"current_step": 0, "plan": [{"agent": "test", "input": {}}], "errors": [], "task": {}}
        result = sup.supervise(state)
        self.assertEqual(result["current_node"], "test")

if __name__ == "__main__":
    unittest.main()
