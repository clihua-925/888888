#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""启动前验证 - 10项检查 v6.0.0"""
import sys
import os

VERSION = "6.0.0"
REQUIRED_CHECKS = 10

class StartupVerifier:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []

    def check(self, name, condition, error_msg):
        if condition:
            print(f"  [OK] {name}")
            self.passed += 1
        else:
            print(f"  [FAIL] {name}: {error_msg}")
            self.failed += 1
            self.errors.append(error_msg)
        return condition

    def run_all(self):
        print(f"PSV Trade OS v{VERSION} - 启动验证")
        print("=" * 50)

        # 1. Python版本
        self.check("Python版本", sys.version_info >= (3, 10), f"需要Python 3.10+, 当前{sys.version}")

        # 2. 虚拟环境
        in_venv = hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)
        self.check("虚拟环境", in_venv, "未检测到虚拟环境")

        # 3. 依赖检查
        required = ['langgraph', 'langchain', 'pydantic', 'sqlalchemy', 'flask', 'requests']
        missing = []
        for pkg in required:
            try:
                __import__(pkg)
            except ImportError:
                missing.append(pkg)
        self.check("核心依赖", len(missing) == 0, f"缺少依赖: {missing}")

        # 4. 目录结构
        required_dirs = ['agents', 'business', 'contracts', 'database', 'orchestrator', 'audit', 'state', 'shared']
        missing_dirs = [d for d in required_dirs if not os.path.isdir(d)]
        self.check("目录结构", len(missing_dirs) == 0, f"缺少目录: {missing_dirs}")

        # 5. 数据库初始化
        db_file = os.path.join("data", "psv_trade.db")
        self.check("数据库文件", os.path.exists(db_file), "数据库未初始化，运行 install.bat")

        # 6. LangGraph编译检查
        try:
            from orchestrator.graph import TradeOrchestrator
            orch = TradeOrchestrator()
            self.check("LangGraph编译", True, "")
        except Exception as e:
            self.check("LangGraph编译", False, str(e))

        # 7. Agent注册检查
        try:
            from agents.registry import AgentRegistry
            registry = AgentRegistry()
            agents = registry.list_agents()
            self.check("Agent注册", len(agents) >= 8, f"仅注册{len(agents)}个Agent")
        except Exception as e:
            self.check("Agent注册", False, str(e))

        # 8. Workflow契约检查
        try:
            from contracts.workflow_contract import WorkflowContract
            wf = WorkflowContract(workflow_type="trade_development", task_id="test")
            self.check("Workflow契约", wf.schema_version == "2.0.0", f"版本不匹配: {wf.schema_version}")
        except Exception as e:
            self.check("Workflow契约", False, str(e))

        # 9. Audit系统检查
        try:
            from audit import AuditLogger, AuditRepository
            self.check("Audit系统", True, "")
        except Exception as e:
            self.check("Audit系统", False, str(e))

        # 10. Checkpoint恢复检查
        try:
            from orchestrator.checkpoint import CheckpointManager
            self.check("Checkpoint系统", True, "")
        except Exception as e:
            self.check("Checkpoint系统", False, str(e))

        print("=" * 50)
        print(f"结果: {self.passed}/{REQUIRED_CHECKS} 通过")

        if self.failed > 0:
            print("错误详情:")
            for err in self.errors:
                print(f"  - {err}")
            sys.exit(1)
        else:
            print("所有检查通过，系统可以启动")
            sys.exit(0)

if __name__ == "__main__":
    verifier = StartupVerifier()
    verifier.run_all()
