# -*- coding: utf-8 -*-
"""报告生成Agent - Schema定义"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class ReportInput(BaseModel):
    request_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    task_id: str
    aggregated: Optional[Dict[str, Any]] = None

class ReportOutput(BaseModel):
    response_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    request_id: str
    task_id: str
    report: str = ""
    summary: Dict[str, Any] = Field(default_factory=dict)
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    status: str = Field(default="success")
    error: Optional[str] = None
    duration_sec: float = Field(0.0, ge=0.0)
