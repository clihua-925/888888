# -*- coding: utf-8 -*-
"""销售策略Agent - Agent实现"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import SalesstrategyInput, SalesstrategyOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class SalesstrategyAgent(BaseAgent):
    """销售策略Agent"""

    def __init__(self):
        super().__init__(
            agent_type="sales_strategy",
            agent_name="销售策略Agent",
            system_prompt=SYSTEM_PROMPT,
        )

    def _run(self, request: AgentRequest) -> AgentResponse:
        
        companies = request.input_data.get("companies", [])
        scores = request.input_data.get("scores", [])

        strategies = []
        for c, s in zip(companies, scores):
            tier = s.get("tier", "D")
            if tier in ["S", "A"]:
                strategy = "优先开发，安排视频会议，提供样品"
            elif tier == "B":
                strategy = "邮件开发，定期跟进，发送产品目录"
            else:
                strategy = "批量邮件，自动化跟进"

            strategies.append({
                "company_name": c.get("name"),
                "tier": tier,
                "strategy": strategy,
                "priority": s.get("overall_score", 50),
                "next_action": "发送开发信" if tier in ["S", "A", "B"] else "加入邮件列表",
            })

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"strategies": strategies},
            confidence=0.75,
            status="success",
        )
    
