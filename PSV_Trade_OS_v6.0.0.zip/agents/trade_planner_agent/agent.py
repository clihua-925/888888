# -*- coding: utf-8 -*-
"""贸易规划Agent - Agent实现"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import TradeplannerInput, TradeplannerOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class TradeplannerAgent(BaseAgent):
    """贸易规划Agent"""

    def __init__(self):
        super().__init__(
            agent_type="trade_planner",
            agent_name="贸易规划Agent",
            system_prompt=SYSTEM_PROMPT,
        )

    def _run(self, request: AgentRequest) -> AgentResponse:
        
        input_data = request.input_data
        objective = input_data.get("objective", "")
        product = input_data.get("product", "")
        market = input_data.get("market", "")
        target = input_data.get("target_customer", "importer")

        # 生成计划
        plan = [
            {"step": 0, "agent": "market_research", "description": f"研究{market}市场"},
            {"step": 1, "agent": "company_discovery", "description": f"发现{product}的{target}"},
            {"step": 2, "agent": "company_enrichment", "description": "补全企业画像"},
            {"step": 3, "agent": "contact_discovery", "description": "发现关键联系人"},
            {"step": 4, "agent": "lead_scoring", "description": "客户评分分级"},
            {"step": 5, "agent": "sales_strategy", "description": "生成开发策略"},
            {"step": 6, "agent": "report", "description": "生成最终报告"},
        ]

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"plan": plan, "total_steps": len(plan), "estimated_duration_min": len(plan) * 5},
            confidence=0.9,
            status="success",
        )
    
