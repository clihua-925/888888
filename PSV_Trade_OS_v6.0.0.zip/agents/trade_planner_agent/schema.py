# -*- coding: utf-8 -*-
"""贸易规划Agent - Schema定义"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class TradeplannerInput(BaseModel):
    request_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    task_id: str
    objective: str
    product: str
    market: str
    target_customer: str = "importer"
    constraints: Optional[Dict[str, Any]] = None

class TradeplannerOutput(BaseModel):
    response_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    request_id: str
    task_id: str
    plan: List[Dict[str, Any]] = Field(default_factory=list)
    total_steps: int = 0
    estimated_duration_min: int = 0
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    status: str = Field(default="success")
    error: Optional[str] = None
    duration_sec: float = Field(0.0, ge=0.0)
