# -*- coding: utf-8 -*-
"""Agent Base - 所有Agent的抽象基类 v6.0.0

标准：
- 每个Agent独立目录
- 包含 agent.py / schema.py / tools.py / prompt.py
- 禁止直接访问数据库
- 通过Service Layer或Repository Interface访问业务数据
"""
import time
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional

from contracts.agent_contract import AgentRequest, AgentResponse
from audit.logger import AuditLogger

class BaseAgent(ABC):
    """智能体基类"""

    def __init__(self, agent_type: str, agent_name: str, system_prompt: str = ""):
        self.agent_type = agent_type
        self.agent_name = agent_name
        self.system_prompt = system_prompt
        self._audit: Optional[AuditLogger] = None

    def set_audit_logger(self, audit: AuditLogger):
        """注入审计日志器（由上层编排器注入）"""
        self._audit = audit

    def execute(self, request: AgentRequest) -> AgentResponse:
        """执行Agent（统一入口）"""
        start_time = time.time()
        task_id = request.task_id
        trace_id = request.trace_id
        workflow_id = request.workflow_id

        # 记录调用
        if self._audit:
            self._audit.log_agent_call(
                trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
                agent_id=f"{self.agent_type}_{int(start_time)}",
                agent_type=self.agent_type,
                input_data=request.input_data,
                node_name=self.agent_type,
            )

        try:
            result = self._run(request)
            duration = time.time() - start_time

            # 记录结果
            if self._audit:
                self._audit.log_agent_result(
                    trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
                    agent_id=f"{self.agent_type}_{int(start_time)}",
                    agent_type=self.agent_type,
                    output_data=result.result,
                    confidence=result.confidence,
                    duration_sec=duration,
                    status=result.status,
                )

            result.duration_sec = duration
            result.trace_id = trace_id
            result.workflow_id = workflow_id
            return result

        except Exception as e:
            duration = time.time() - start_time
            error_msg = str(e)

            if self._audit:
                self._audit.log_error(
                    trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
                    agent_id=f"{self.agent_type}_{int(start_time)}",
                    error=error_msg, node_name=self.agent_type,
                )

            return AgentResponse(
                request_id=request.request_id,
                task_id=task_id,
                agent_type=self.agent_type,
                result={},
                confidence=0.0,
                status="failed",
                error=error_msg,
                duration_sec=duration,
                trace_id=trace_id,
                workflow_id=workflow_id,
            )

    @abstractmethod
    def _run(self, request: AgentRequest) -> AgentResponse:
        """子类必须实现的执行逻辑"""
        pass

    def _call_tool(self, task_id: str, trace_id: str, workflow_id: str,
                   tool_name: str, parameters: Dict[str, Any], timeout: int = 60) -> Any:
        """调用工具（带审计）"""
        from contracts.tool_contract import ToolRegistry

        start = time.time()
        handler = ToolRegistry.get(tool_name)

        if not handler:
            raise ValueError(f"未注册的工具: {tool_name}")

        try:
            result = handler(**parameters)
            duration = time.time() - start

            if self._audit:
                self._audit.log_tool_call(
                    trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
                    agent_id=self.agent_type,
                    tool_name=tool_name, parameters=parameters,
                    result=result, duration_sec=duration, success=True,
                )

            return result

        except Exception as e:
            duration = time.time() - start

            if self._audit:
                self._audit.log_tool_call(
                    trace_id=trace_id, workflow_id=workflow_id, task_id=task_id,
                    agent_id=self.agent_type,
                    tool_name=tool_name, parameters=parameters,
                    result=str(e), duration_sec=duration, success=False,
                )

            raise
