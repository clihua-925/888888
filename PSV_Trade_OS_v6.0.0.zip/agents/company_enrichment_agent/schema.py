# -*- coding: utf-8 -*-
"""企业补全Agent - Schema定义"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class CompanyenrichmentInput(BaseModel):
    request_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    task_id: str
    companies: List[Dict[str, Any]]

class CompanyenrichmentOutput(BaseModel):
    response_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    request_id: str
    task_id: str
    enriched_companies: List[Dict[str, Any]] = Field(default_factory=list)
    enrichment_rate: float = 0.0
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    status: str = Field(default="success")
    error: Optional[str] = None
    duration_sec: float = Field(0.0, ge=0.0)
