# -*- coding: utf-8 -*-
"""企业补全Agent - Prompt定义"""

SYSTEM_PROMPT = """你是一个专业的企业信息补全Agent。通过多源数据补全企业画像。"""


