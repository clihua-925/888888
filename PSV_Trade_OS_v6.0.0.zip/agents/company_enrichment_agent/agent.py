# -*- coding: utf-8 -*-
"""企业补全Agent - Agent实现"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import CompanyenrichmentInput, CompanyenrichmentOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class CompanyenrichmentAgent(BaseAgent):
    """企业补全Agent"""

    def __init__(self):
        super().__init__(
            agent_type="company_enrichment",
            agent_name="企业补全Agent",
            system_prompt=SYSTEM_PROMPT,
        )

    def _run(self, request: AgentRequest) -> AgentResponse:
        
        companies = request.input_data.get("companies", [])

        enriched = []
        for c in companies:
            c["main_products"] = c.get("main_products", ["Product A", "Product B"])
            c["company_size"] = c.get("company_size", "Medium")
            c["supply_chain_role"] = c.get("supply_chain_role", "Importer")
            c["purchase_probability"] = 0.5
            c["match_score"] = 0.6
            c["deal_probability"] = 0.4
            enriched.append(c)

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"enriched_companies": enriched, "enrichment_rate": 1.0},
            confidence=0.8,
            status="success",
        )
    
