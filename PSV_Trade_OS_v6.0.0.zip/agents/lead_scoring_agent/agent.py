# -*- coding: utf-8 -*-
"""客户评分Agent - Agent实现"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import LeadscoringInput, LeadscoringOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class LeadscoringAgent(BaseAgent):
    """客户评分Agent"""

    def __init__(self):
        super().__init__(
            agent_type="lead_scoring",
            agent_name="客户评分Agent",
            system_prompt=SYSTEM_PROMPT,
        )

    def _run(self, request: AgentRequest) -> AgentResponse:
        
        companies = request.input_data.get("companies", [])

        scores = []
        tier_dist = {"S": 0, "A": 0, "B": 0, "C": 0, "D": 0}

        for c in companies:
            score = c.get("credibility_score", 50)
            if score >= 80:
                tier = "S"
            elif score >= 60:
                tier = "A"
            elif score >= 40:
                tier = "B"
            elif score >= 20:
                tier = "C"
            else:
                tier = "D"

            tier_dist[tier] = tier_dist.get(tier, 0) + 1
            scores.append({
                "company_name": c.get("name"),
                "overall_score": score,
                "match_degree": c.get("match_score", 0.5),
                "deal_probability": c.get("deal_probability", 0.4),
                "purchase_likelihood": 0.5,
                "company_strength": 0.6,
                "tier": tier,
            })

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"scores": scores, "tier_distribution": tier_dist},
            confidence=0.8,
            status="success",
        )
    
