# -*- coding: utf-8 -*-
"""企业发现Agent - 工具定义"""
from typing import Dict, List, Any
from contracts.tool_contract import ToolRegistry


