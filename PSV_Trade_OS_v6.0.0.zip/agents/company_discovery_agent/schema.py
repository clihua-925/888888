# -*- coding: utf-8 -*-
"""企业发现Agent - Schema定义"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class CompanydiscoveryInput(BaseModel):
    request_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    task_id: str
    product: str
    market: str
    customer_type: str = "importer"
    max_results: int = 50

class CompanydiscoveryOutput(BaseModel):
    response_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    request_id: str
    task_id: str
    companies: List[Dict[str, Any]] = Field(default_factory=list)
    total_found: int = 0
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    status: str = Field(default="success")
    error: Optional[str] = None
    duration_sec: float = Field(0.0, ge=0.0)
