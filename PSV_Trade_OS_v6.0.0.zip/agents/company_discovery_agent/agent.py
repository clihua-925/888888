# -*- coding: utf-8 -*-
"""企业发现Agent - Agent实现"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import CompanydiscoveryInput, CompanydiscoveryOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class CompanydiscoveryAgent(BaseAgent):
    """企业发现Agent"""

    def __init__(self):
        super().__init__(
            agent_type="company_discovery",
            agent_name="企业发现Agent",
            system_prompt=SYSTEM_PROMPT,
        )

    def _run(self, request: AgentRequest) -> AgentResponse:
        
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")
        customer_type = request.input_data.get("customer_type", "importer")
        max_results = request.input_data.get("max_results", 50)

        # 模拟企业发现
        companies = []
        for i in range(min(max_results, 5)):
            companies.append({
                "name": f"{market} {customer_type.title()} {i+1} Corp",
                "country": market,
                "website": f"https://example{i+1}.com",
                "industry": "Trading",
                "credibility_score": 50 + i * 5,
                "source": "simulated",
            })

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"companies": companies, "total_found": len(companies)},
            confidence=0.7,
            status="success",
        )
    
