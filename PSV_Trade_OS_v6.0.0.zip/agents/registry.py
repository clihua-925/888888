# -*- coding: utf-8 -*-
"""Agent Registry - Agent注册中心

所有Agent必须通过Registry注册，禁止直接实例化。
"""
from typing import Dict, List, Optional, Type
from .base.base_agent import BaseAgent

class AgentRegistry:
    """Agent注册表"""

    _agents: Dict[str, Type[BaseAgent]] = {}
    _instances: Dict[str, BaseAgent] = {}

    @classmethod
    def register(cls, agent_type: str, agent_class: Type[BaseAgent]):
        """注册Agent类"""
        cls._agents[agent_type] = agent_class

    @classmethod
    def get_agent(cls, agent_type: str) -> Optional[BaseAgent]:
        """获取Agent实例（懒加载）"""
        if agent_type in cls._instances:
            return cls._instances[agent_type]

        agent_class = cls._agents.get(agent_type)
        if not agent_class:
            return None

        instance = agent_class()
        cls._instances[agent_type] = instance
        return instance

    @classmethod
    def list_agents(cls) -> List[str]:
        """列出所有已注册Agent"""
        return list(cls._agents.keys())

    @classmethod
    def clear(cls):
        """清空注册表"""
        cls._agents.clear()
        cls._instances.clear()

# 自动注册所有Agent
def _auto_register():
    try:
        from .trade_planner_agent.agent import TradePlannerAgent
        AgentRegistry.register("trade_planner", TradePlannerAgent)
    except ImportError:
        pass

    try:
        from .market_research_agent.agent import MarketResearchAgent
        AgentRegistry.register("market_research", MarketResearchAgent)
    except ImportError:
        pass

    try:
        from .company_discovery_agent.agent import CompanyDiscoveryAgent
        AgentRegistry.register("company_discovery", CompanyDiscoveryAgent)
    except ImportError:
        pass

    try:
        from .company_enrichment_agent.agent import CompanyEnrichmentAgent
        AgentRegistry.register("company_enrichment", CompanyEnrichmentAgent)
    except ImportError:
        pass

    try:
        from .contact_discovery_agent.agent import ContactDiscoveryAgent
        AgentRegistry.register("contact_discovery", ContactDiscoveryAgent)
    except ImportError:
        pass

    try:
        from .lead_scoring_agent.agent import LeadScoringAgent
        AgentRegistry.register("lead_scoring", LeadScoringAgent)
    except ImportError:
        pass

    try:
        from .sales_strategy_agent.agent import SalesStrategyAgent
        AgentRegistry.register("sales_strategy", SalesStrategyAgent)
    except ImportError:
        pass

    try:
        from .report_agent.agent import ReportAgent
        AgentRegistry.register("report", ReportAgent)
    except ImportError:
        pass

_auto_register()
