# -*- coding: utf-8 -*-
"""联系人发现Agent - 工具定义"""
from typing import Dict, List, Any
from contracts.tool_contract import ToolRegistry


