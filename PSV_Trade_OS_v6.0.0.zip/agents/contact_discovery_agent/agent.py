# -*- coding: utf-8 -*-
"""联系人发现Agent - Agent实现"""
from agents.base.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from .schema import ContactdiscoveryInput, ContactdiscoveryOutput
from .tools import *
from .prompt import SYSTEM_PROMPT

class ContactdiscoveryAgent(BaseAgent):
    """联系人发现Agent"""

    def __init__(self):
        super().__init__(
            agent_type="contact_discovery",
            agent_name="联系人发现Agent",
            system_prompt=SYSTEM_PROMPT,
        )

    def _run(self, request: AgentRequest) -> AgentResponse:
        
        companies = request.input_data.get("companies", [])

        contacts = []
        for c in companies:
            contacts.append({
                "company_name": c.get("name"),
                "name": f"Contact at {c.get('name', '')}",
                "title": "Purchasing Manager",
                "email": f"contact@{c.get('website', 'example.com').replace('https://', '')}",
                "is_decision_maker": True,
                "confidence": 0.6,
            })

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"contacts": contacts, "total_contacts": len(contacts)},
            confidence=0.65,
            status="success",
        )
    
