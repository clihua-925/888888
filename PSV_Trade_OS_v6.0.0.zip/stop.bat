@echo off
echo PSV Trade OS v6.0.0 - 停止脚本
taskkill /F /IM python.exe /FI "WINDOWTITLE eq PSV Trade OS*" >nul 2>&1
echo 系统已停止
