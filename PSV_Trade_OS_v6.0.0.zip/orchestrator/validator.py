# -*- coding: utf-8 -*-
"""Workflow Validator - 工作流验证器"""
from typing import Dict, List, Any

class WorkflowValidator:
    """工作流验证器"""

    def validate(self, state: Dict[str, Any]) -> Dict[str, Any]:
        errors = []
        task = state.get("task", {})

        if not task.get("objective"):
            errors.append("missing objective")
        if not task.get("product"):
            errors.append("missing product")
        if not task.get("market"):
            errors.append("missing market")
        if not state.get("plan") and not state.get("agent_outputs"):
            errors.append("empty workflow execution")

        return {"valid": not errors, "errors": errors}

    def validate_plan(self, plan: List[Dict[str, Any]]) -> Dict[str, Any]:
        errors = []
        if not plan:
            errors.append("plan is empty")
        for i, step in enumerate(plan):
            if not step.get("agent"):
                errors.append(f"step {i} missing agent")
            if not step.get("description"):
                errors.append(f"step {i} missing description")
        return {"valid": not errors, "errors": errors}
