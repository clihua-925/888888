# -*- coding: utf-8 -*-
"""Planner Agent - 任务规划Agent

职责：
- 分解外贸任务
- 生成执行计划（plan）
- 创建workflow
"""
from typing import Dict, List, Any
from contracts.task_contract import TaskPlanStep
from contracts.agent_contract import AgentRequest, AgentResponse
from shared.utils import generate_id, now_iso

class PlannerAgent:
    """任务规划Agent"""

    def __init__(self):
        self.agent_type = "planner"

    def plan(self, objective: str, product: str, market: str, 
             target_customer: str = "importer") -> Dict[str, Any]:
        """生成外贸开发任务执行计划"""
        plan = []

        # Step 0: 市场研究
        plan.append(TaskPlanStep(
            step_number=0,
            agent_type="market_research",
            description=f"研究{market}市场，分析{product}的竞争格局",
            input={"product": product, "market": market},
            expected_output={"market_analysis": "MarketAnalysis对象"},
        ))

        # Step 1: 企业发现
        plan.append(TaskPlanStep(
            step_number=1,
            agent_type="company_discovery",
            description=f"在{market}发现{product}的{target_customer}",
            input={"product": product, "market": market, "customer_type": target_customer, "from_step_0": "market_analysis"},
            expected_output={"companies": "List[CompanyProfile]"},
            dependencies=[0],
        ))

        # Step 2: 企业补全
        plan.append(TaskPlanStep(
            step_number=2,
            agent_type="company_enrichment",
            description="补全企业画像信息",
            input={"companies": "from_step_1"},
            expected_output={"enriched_companies": "List[CompanyProfile]"},
            dependencies=[1],
        ))

        # Step 3: 联系人发现
        plan.append(TaskPlanStep(
            step_number=3,
            agent_type="contact_discovery",
            description="发现企业关键联系人",
            input={"companies": "from_step_2"},
            expected_output={"contacts": "List[ContactInfo]"},
            dependencies=[2],
        ))

        # Step 4: 客户评分
        plan.append(TaskPlanStep(
            step_number=4,
            agent_type="lead_scoring",
            description="对客户进行评分分级",
            input={"companies": "from_step_2", "contacts": "from_step_3"},
            expected_output={"scores": "List[LeadScore]"},
            dependencies=[2, 3],
        ))

        # Step 5: 销售策略
        plan.append(TaskPlanStep(
            step_number=5,
            agent_type="sales_strategy",
            description="生成客户开发策略",
            input={"companies": "from_step_2", "scores": "from_step_4"},
            expected_output={"strategies": "List[Dict]"},
            dependencies=[4],
        ))

        # Step 6: 报告生成
        plan.append(TaskPlanStep(
            step_number=6,
            agent_type="report",
            description="生成最终外贸开发报告",
            input={"aggregated": True},
            expected_output={"report": "str"},
            dependencies=[0, 1, 2, 3, 4, 5],
        ))

        return {
            "plan_id": generate_id("plan_"),
            "plan": [p.dict() for p in plan],
            "total_steps": len(plan),
            "estimated_duration_min": len(plan) * 5,
            "created_at": now_iso(),
        }

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph节点入口"""
        task = state.get("task", {})
        plan_result = self.plan(
            objective=task.get("objective", ""),
            product=task.get("product", ""),
            market=task.get("market", ""),
            target_customer=task.get("target_customer", "importer"),
        )
        state["plan"] = plan_result.get("plan", [])
        state["current_step"] = 0
        state["should_continue"] = True
        state["agent_outputs"] = []
        state["errors"] = []
        state["current_node"] = "planner"
        return state
