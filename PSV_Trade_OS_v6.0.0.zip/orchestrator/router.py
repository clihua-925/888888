# -*- coding: utf-8 -*-
"""Router Agent - 路由决策Agent

职责：
- 根据状态选择下一节点
- 智能路由决策
"""
from typing import Dict, Any

class RouterAgent:
    """Router Agent - 工作流路由决策器"""

    def __init__(self):
        self.agent_type = "router"

    def route(self, state: Dict[str, Any]) -> str:
        """根据当前状态返回下一节点名称"""
        errors = state.get("errors", [])
        current_step = state.get("current_step", 0)
        plan = state.get("plan", [])
        should_pause = state.get("should_pause", False)
        recovery_attempts = state.get("recovery_attempts", 0)

        # 错误过多 -> 恢复
        if len(errors) > 3 and recovery_attempts < 3:
            return "recovery"

        # 用户暂停
        if should_pause:
            return "checkpoint"

        # 所有步骤完成
        if current_step >= len(plan):
            return "finalize"

        # 正常执行
        return "executor"

    def route_after_execution(self, state: Dict[str, Any]) -> str:
        """执行后路由"""
        errors = state.get("errors", [])
        if len(errors) > 3:
            return "fail"
        return "reviewer"

    def route_after_review(self, state: Dict[str, Any]) -> str:
        """评审后路由"""
        reviews = state.get("reviews", [])
        if not reviews:
            return "checkpoint"
        last_review = reviews[-1]
        quality = last_review.get("quality_score", 1.0)
        retry_count = last_review.get("retry_count", 0)

        if quality >= 0.7:
            return "checkpoint"
        if retry_count < 3:
            return "supervisor"  # 重试
        return "recovery"

    def route_after_checkpoint(self, state: Dict[str, Any]) -> str:
        """检查点后路由"""
        if state.get("should_continue", False):
            return "supervisor"
        return "finalize"

    def route_after_recovery(self, state: Dict[str, Any]) -> str:
        """恢复后路由"""
        recovery_attempts = state.get("recovery_attempts", 0)
        if recovery_attempts < 3:
            return "supervisor"
        return "finalize"

    def __call__(self, state: Dict[str, Any]) -> str:
        return self.route(state)
