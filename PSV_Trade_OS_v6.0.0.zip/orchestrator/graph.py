# -*- coding: utf-8 -*-
"""LangGraph Orchestrator - 核心运行引擎 v6.0.0

完整流程：
User Intent → Planner → Supervisor → Router → Executor → Reviewer → Checkpoint → (循环) → Finalize

支持：暂停/恢复/继续执行/失败恢复
"""
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from typing import Dict, Any

from .planner import PlannerAgent
from .supervisor import SupervisorAgent
from .router import RouterAgent
from .executor import ExecutorAgent
from .reviewer import ReviewerAgent
from .checkpoint import CheckpointManager
from .recovery import RecoveryCoordinator
from .validator import WorkflowValidator
from state import WorkflowState, create_initial_workflow_state

class TradeOrchestrator:
    """贸易智能编排器 - LangGraph核心"""

    def __init__(self, checkpoint_manager=None, agent_registry=None, checkpointer=None):
        self.planner = PlannerAgent()
        self.supervisor = SupervisorAgent()
        self.router = RouterAgent()
        self.executor = ExecutorAgent(registry=agent_registry)
        self.reviewer = ReviewerAgent()
        self.checkpoint = checkpoint_manager or CheckpointManager()
        self.recovery = RecoveryCoordinator(checkpoint_manager)
        self.validator = WorkflowValidator()
        self.checkpointer = checkpointer or MemorySaver()
        self.graph = self._build_graph()

    def _build_graph(self):
        workflow = StateGraph(WorkflowState)

        # 7个核心节点
        workflow.add_node("planner", self.planner)
        workflow.add_node("supervisor", self.supervisor)
        workflow.add_node("router", self.router)
        workflow.add_node("executor", self.executor)
        workflow.add_node("reviewer", self.reviewer)
        workflow.add_node("checkpoint", self.checkpoint)
        workflow.add_node("finalize", self._finalize)
        workflow.add_node("recovery", self.recovery)

        # 入口
        workflow.set_entry_point("planner")

        # Planner → Supervisor
        workflow.add_edge("planner", "supervisor")

        # Supervisor → Router
        workflow.add_edge("supervisor", "router")

        # Router条件路由
        workflow.add_conditional_edges(
            "router",
            self._router_decision,
            {
                "executor": "executor",
                "checkpoint": "checkpoint",
                "recovery": "recovery",
                "finalize": "finalize",
            }
        )

        # Executor → Reviewer
        workflow.add_edge("executor", "reviewer")

        # Reviewer条件路由
        workflow.add_conditional_edges(
            "reviewer",
            self._review_decision,
            {
                "checkpoint": "checkpoint",
                "supervisor": "supervisor",
                "recovery": "recovery",
            }
        )

        # Checkpoint条件路由
        workflow.add_conditional_edges(
            "checkpoint",
            self._checkpoint_decision,
            {
                "supervisor": "supervisor",
                "finalize": "finalize",
                "end": END,
            }
        )

        # Recovery条件路由
        workflow.add_conditional_edges(
            "recovery",
            self._recovery_decision,
            {
                "supervisor": "supervisor",
                "finalize": "finalize",
            }
        )

        workflow.add_edge("finalize", END)

        return workflow.compile(checkpointer=self.checkpointer)

    def _router_decision(self, state: WorkflowState) -> str:
        return self.router.route(state)

    def _review_decision(self, state: WorkflowState) -> str:
        return self.router.route_after_review(state)

    def _checkpoint_decision(self, state: WorkflowState) -> str:
        return self.router.route_after_checkpoint(state)

    def _recovery_decision(self, state: WorkflowState) -> str:
        return self.router.route_after_recovery(state)

    def _finalize(self, state: WorkflowState) -> WorkflowState:
        state["status"] = "completed" if not state.get("errors") else "failed"
        state["current_node"] = "finalize"
        state["should_continue"] = False
        return state

    def run(self, task_id: str, objective: str, product: str, market: str,
            target_customer: str = "importer", config: Dict[str, Any] = None) -> WorkflowState:
        """运行完整工作流"""
        initial_state = create_initial_workflow_state(
            task_id=task_id, objective=objective, product=product,
            market=market, target_customer=target_customer
        )

        # 验证
        validation = self.validator.validate(initial_state)
        if not validation["valid"]:
            initial_state["errors"] = validation["errors"]
            initial_state["status"] = "failed"
            return initial_state

        result = self.graph.invoke(initial_state, config=config)
        return result

    def resume(self, task_id: str, checkpoint_id: str = None, config: Dict[str, Any] = None) -> WorkflowState:
        """恢复中断任务"""
        if not self.checkpoint.can_resume(task_id):
            raise ValueError(f"Task {task_id} cannot be resumed")

        checkpoint = self.checkpoint.load(task_id)
        if not checkpoint:
            raise ValueError(f"No checkpoint found for task {task_id}")

        # 从检查点重建状态
        from state import StateManager
        sm = StateManager()
        state = sm.deserialize(checkpoint.get("workflow_id", ""), checkpoint.get("graph_state", "{}"))

        # 恢复协调
        state = self.recovery.attempt_resume(state)

        result = self.graph.invoke(state, config=config)
        return result
