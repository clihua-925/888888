@echo off
chcp 65001 >nul
echo ==========================================
echo PSV Trade OS v6.0.0 - 安装脚本
echo ==========================================

REM 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python未安装，请先安装Python 3.10+
    exit /b 1
)

REM 创建虚拟环境
if not exist venv (
    echo [1/5] 创建虚拟环境...
    python -m venv venv
)

REM 激活虚拟环境
echo [2/5] 激活虚拟环境...
call venv\Scripts\activate.bat

REM 安装依赖
echo [3/5] 安装依赖...
pip install -r requirements.txt

REM 初始化数据库
echo [4/5] 初始化数据库...
python -m app.main --init-db

REM 验证安装
echo [5/5] 验证安装...
python verify_startup.py

echo.
echo ==========================================
echo 安装完成！运行 start.bat 启动系统
echo ==========================================
pause
