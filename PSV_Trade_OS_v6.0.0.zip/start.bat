@echo off
chcp 65001 >nul
echo ==========================================
echo PSV Trade OS v6.0.0 - 启动脚本
echo ==========================================

REM 验证启动
echo [1/2] 运行启动验证...
python verify_startup.py
if errorlevel 1 (
    echo [ERROR] 启动验证失败，请运行 install.bat 重新安装
    pause
    exit /b 1
)

REM 启动系统
echo [2/2] 启动PSV Trade OS...
call venv\Scripts\activate.bat
python -m app.main --webui

pause
