# -*- coding: utf-8 -*-
"""Database Package - 纯数据存储能力"""
from .models import Base, TradeCompany, TradeContact, TradeProduct, TradeMarket, TradeCustomerPool
from .models import CustomsRaw, TradeTask, TradeWorkflow, TradeOpportunity, AuditEvent, AgentExecutionLog, CheckpointRecord
from .session import init_database, get_session_factory, get_engine
from .repository import (
    ICompanyRepository, CompanyRepository,
    ITaskRepository, TaskRepository,
    IWorkflowRepository, WorkflowRepository,
    IAuditRepository, AuditRepository,
    ICustomerPoolRepository, CustomerPoolRepository,
)

__all__ = [
    "Base", "init_database", "get_session_factory", "get_engine",
    "TradeCompany", "TradeContact", "TradeProduct", "TradeMarket", "TradeCustomerPool",
    "CustomsRaw", "TradeTask", "TradeWorkflow", "TradeOpportunity", "AuditEvent", "AgentExecutionLog", "CheckpointRecord",
    "ICompanyRepository", "CompanyRepository",
    "ITaskRepository", "TaskRepository",
    "IWorkflowRepository", "WorkflowRepository",
    "IAuditRepository", "AuditRepository",
    "ICustomerPoolRepository", "CustomerPoolRepository",
]
