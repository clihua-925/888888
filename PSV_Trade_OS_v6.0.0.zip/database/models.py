# -*- coding: utf-8 -*-
"""PSV Trade OS v6.0.0 - 纯数据库模型定义

核心原则：
1. 仅包含SQLAlchemy模型定义
2. 不创建engine/session（由上层注入）
3. 不import任何shared/business/agents/orchestrator模块
4. 提供to_dict()辅助方法
"""
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, JSON, Index, create_engine
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from sqlalchemy.sql import func
from datetime import datetime
import uuid

Base = declarative_base()

def generate_uuid() -> str:
    return uuid.uuid4().hex[:16]

# ========== 1. 贸易企业表 ==========
class TradeCompany(Base):
    __tablename__ = 'trade_company'
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    name = Column(String(500), nullable=False, index=True)
    name_norm = Column(String(500), index=True)
    country = Column(String(100), index=True)
    website = Column(String(500))
    industry = Column(String(200), index=True)
    main_products = Column(JSON)
    purchase_direction = Column(JSON)
    company_size = Column(String(50))
    supply_chain_role = Column(String(100))
    credibility_score = Column(Float, default=0.0)
    purchase_probability = Column(Float, default=0.0)
    match_score = Column(Float, default=0.0)
    deal_probability = Column(Float, default=0.0)
    development_priority = Column(Integer, default=0)
    development_stage = Column(String(50), default='new')
    customer_tier = Column(String(10), default='D')
    is_active = Column(Boolean, default=True)
    source = Column(String(200))
    evidence = Column(JSON)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    contacts = relationship("TradeContact", back_populates="company", cascade="all, delete-orphan")
    opportunities = relationship("TradeOpportunity", back_populates="company")
    audit_logs = relationship("AuditEvent", back_populates="company")

    def to_dict(self):
        return {
            "entity_id": self.entity_id, "name": self.name, "country": self.country,
            "website": self.website, "industry": self.industry, "main_products": self.main_products,
            "credibility_score": self.credibility_score, "customer_tier": self.customer_tier,
            "development_stage": self.development_stage, "source": self.source,
        }

# ========== 2. 联系人表 ==========
class TradeContact(Base):
    __tablename__ = 'trade_contact'
    id = Column(Integer, primary_key=True, autoincrement=True)
    contact_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    name = Column(String(200))
    title = Column(String(200))
    email = Column(String(300), index=True)
    phone = Column(String(100))
    linkedin = Column(String(500))
    is_decision_maker = Column(Boolean, default=False)
    confidence = Column(Float, default=0.0)
    source = Column(String(200))
    verified = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    company = relationship("TradeCompany", back_populates="contacts")

# ========== 3. 产品表 ==========
class TradeProduct(Base):
    __tablename__ = 'trade_product'
    id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    name = Column(String(300), nullable=False, index=True)
    hs_code = Column(String(50), index=True)
    category = Column(String(200), index=True)
    description = Column(Text)
    target_markets = Column(JSON)
    competitors = Column(JSON)
    price_range = Column(String(200))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

# ========== 4. 市场表 ==========
class TradeMarket(Base):
    __tablename__ = 'trade_market'
    id = Column(Integer, primary_key=True, autoincrement=True)
    market_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    country_code = Column(String(10), unique=True, index=True)
    country_name = Column(String(200))
    currency = Column(String(10))
    language = Column(String(50))
    customs_source = Column(String(200))
    market_size = Column(Float)
    growth_rate = Column(Float)
    competition_level = Column(String(50))
    entry_difficulty = Column(String(50))
    analysis_data = Column(JSON)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

# ========== 5. 客户池表 ==========
class TradeCustomerPool(Base):
    __tablename__ = 'trade_customer_pool'
    id = Column(Integer, primary_key=True, autoincrement=True)
    pool_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    product_id = Column(String(32), ForeignKey('trade_product.product_id'))
    market_id = Column(String(32), ForeignKey('trade_market.market_id'))
    customer_value = Column(Float, default=0.0)
    match_score = Column(Float, default=0.0)
    deal_probability = Column(Float, default=0.0)
    development_priority = Column(Integer, default=0)
    follow_up_status = Column(String(50), default='new')
    next_action = Column(String(200))
    last_contact = Column(DateTime)
    notes = Column(Text)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    company = relationship("TradeCompany")

# ========== 6. 海关原始数据表 ==========
class CustomsRaw(Base):
    __tablename__ = 'customs_raw'
    id = Column(Integer, primary_key=True, autoincrement=True)
    record_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    bol = Column(String(100))
    importer = Column(String(500), index=True)
    importer_norm = Column(String(500), index=True)
    exporter = Column(String(500), index=True)
    hs = Column(String(50), index=True)
    descr = Column(Text, index=True)
    qty = Column(Float)
    weight = Column(Float)
    value_usd = Column(Float)
    country = Column(String(100), index=True)
    ts = Column(Integer, index=True)
    source_file = Column(String(500))
    created_at = Column(DateTime, default=func.now())

# ========== 7. 任务表 ==========
class TradeTask(Base):
    __tablename__ = 'trade_task'
    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    objective = Column(Text)
    product = Column(String(300))
    market = Column(String(100))
    target_customer = Column(String(100))
    workflow = Column(JSON)
    status = Column(String(50), default='pending')
    current_node = Column(String(100))
    resume_state = Column(Text)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    completed_at = Column(DateTime)

# ========== 8. 工作流表 ==========
class TradeWorkflow(Base):
    __tablename__ = 'trade_workflow'
    id = Column(Integer, primary_key=True, autoincrement=True)
    workflow_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    task_id = Column(String(32), index=True)
    workflow_type = Column(String(100))
    graph_state = Column(Text)
    checkpoint_data = Column(Text)
    is_resumable = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

# ========== 9. 机会表 ==========
class TradeOpportunity(Base):
    __tablename__ = 'trade_opportunity'
    id = Column(Integer, primary_key=True, autoincrement=True)
    opportunity_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'), index=True)
    product_id = Column(String(32), ForeignKey('trade_product.product_id'))
    market_id = Column(String(32), ForeignKey('trade_market.market_id'))
    opportunity_type = Column(String(100))
    score = Column(Float, default=0.0)
    status = Column(String(50), default='open')
    notes = Column(Text)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    company = relationship("TradeCompany", back_populates="opportunities")

# ========== 10. 审计事件表 ==========
class AuditEvent(Base):
    __tablename__ = 'audit_event'
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    trace_id = Column(String(32), index=True)
    workflow_id = Column(String(32), index=True)
    task_id = Column(String(32), index=True)
    agent_id = Column(String(32), index=True)
    event_type = Column(String(100), index=True)
    status = Column(String(50), index=True)
    input_data = Column(Text)
    output_data = Column(Text)
    error_details = Column(Text)
    duration_sec = Column(Float, default=0.0)
    timestamp = Column(DateTime, default=func.now(), index=True)
    company_id = Column(String(32), ForeignKey('trade_company.entity_id'))
    company = relationship("TradeCompany", back_populates="audit_logs")

# ========== 11. Agent执行日志表 ==========
class AgentExecutionLog(Base):
    __tablename__ = 'agent_execution_log'
    id = Column(Integer, primary_key=True, autoincrement=True)
    log_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    trace_id = Column(String(32), index=True)
    workflow_id = Column(String(32), index=True)
    task_id = Column(String(32), index=True)
    agent_type = Column(String(100), index=True)
    agent_name = Column(String(200))
    input_data = Column(Text)
    output_data = Column(Text)
    confidence = Column(Float, default=0.0)
    duration_sec = Column(Float, default=0.0)
    status = Column(String(50), index=True)
    error = Column(Text)
    timestamp = Column(DateTime, default=func.now(), index=True)

# ========== 12. 检查点表 ==========
class CheckpointRecord(Base):
    __tablename__ = 'checkpoint_record'
    id = Column(Integer, primary_key=True, autoincrement=True)
    checkpoint_id = Column(String(32), unique=True, default=generate_uuid, index=True)
    task_id = Column(String(32), index=True)
    workflow_id = Column(String(32), index=True)
    node_name = Column(String(100))
    state_data = Column(Text)
    agent_outputs = Column(Text)
    version = Column(String(20), default='6.0.0')
    timestamp = Column(DateTime, default=func.now())
    expires_at = Column(DateTime)
