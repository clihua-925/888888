# -*- coding: utf-8 -*-
"""Repository Interface - 数据库访问的唯一合法入口

所有business/agent/audit模块必须通过Repository Interface访问数据。
禁止直接import database.models。
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from .session import get_session_factory

# ========== 公司Repository ==========
class ICompanyRepository(ABC):
    @abstractmethod
    def get_by_id(self, entity_id: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def get_by_name_norm(self, name_norm: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def list_by_country(self, country: str, limit: int = 100) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def save(self, data: Dict[str, Any]) -> str: ...
    @abstractmethod
    def update(self, entity_id: str, data: Dict[str, Any]) -> bool: ...
    @abstractmethod
    def list_all(self, limit: int = 1000) -> List[Dict[str, Any]]: ...

class CompanyRepository(ICompanyRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def get_by_id(self, entity_id: str) -> Optional[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            row = s.query(TradeCompany).filter(TradeCompany.entity_id == entity_id).first()
            return row.to_dict() if row else None
        finally:
            s.close()

    def get_by_name_norm(self, name_norm: str) -> Optional[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            row = s.query(TradeCompany).filter(TradeCompany.name_norm == name_norm).first()
            return row.to_dict() if row else None
        finally:
            s.close()

    def list_by_country(self, country: str, limit: int = 100) -> List[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            rows = s.query(TradeCompany).filter(TradeCompany.country == country).limit(limit).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

    def save(self, data: Dict[str, Any]) -> str:
        from .models import TradeCompany
        s = self._session()
        try:
            company = TradeCompany(**data)
            s.add(company)
            s.commit()
            s.refresh(company)
            return company.entity_id
        finally:
            s.close()

    def update(self, entity_id: str, data: Dict[str, Any]) -> bool:
        from .models import TradeCompany
        s = self._session()
        try:
            row = s.query(TradeCompany).filter(TradeCompany.entity_id == entity_id).first()
            if not row:
                return False
            for k, v in data.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            s.commit()
            return True
        finally:
            s.close()

    def list_all(self, limit: int = 1000) -> List[Dict[str, Any]]:
        from .models import TradeCompany
        s = self._session()
        try:
            rows = s.query(TradeCompany).limit(limit).all()
            return [r.to_dict() for r in rows]
        finally:
            s.close()

# ========== 任务Repository ==========
class ITaskRepository(ABC):
    @abstractmethod
    def get_by_id(self, task_id: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def save(self, data: Dict[str, Any]) -> str: ...
    @abstractmethod
    def update_status(self, task_id: str, status: str, resume_state: str = None) -> bool: ...

class TaskRepository(ITaskRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def get_by_id(self, task_id: str) -> Optional[Dict[str, Any]]:
        from .models import TradeTask
        s = self._session()
        try:
            row = s.query(TradeTask).filter(TradeTask.task_id == task_id).first()
            if not row:
                return None
            return {
                "task_id": row.task_id, "objective": row.objective,
                "product": row.product, "market": row.market,
                "status": row.status, "current_node": row.current_node,
                "workflow": row.workflow, "resume_state": row.resume_state,
            }
        finally:
            s.close()

    def save(self, data: Dict[str, Any]) -> str:
        from .models import TradeTask
        s = self._session()
        try:
            task = TradeTask(**data)
            s.add(task)
            s.commit()
            s.refresh(task)
            return task.task_id
        finally:
            s.close()

    def update_status(self, task_id: str, status: str, resume_state: str = None) -> bool:
        from .models import TradeTask
        s = self._session()
        try:
            row = s.query(TradeTask).filter(TradeTask.task_id == task_id).first()
            if not row:
                return False
            row.status = status
            if resume_state:
                row.resume_state = resume_state
            s.commit()
            return True
        finally:
            s.close()

# ========== 工作流Repository ==========
class IWorkflowRepository(ABC):
    @abstractmethod
    def get_by_task(self, task_id: str) -> Optional[Dict[str, Any]]: ...
    @abstractmethod
    def save_checkpoint(self, task_id: str, workflow_id: str, checkpoint_data: str, graph_state: str = None) -> bool: ...

class WorkflowRepository(IWorkflowRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def get_by_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        from .models import TradeWorkflow
        s = self._session()
        try:
            row = s.query(TradeWorkflow).filter(TradeWorkflow.task_id == task_id).first()
            if not row:
                return None
            return {
                "workflow_id": row.workflow_id, "task_id": row.task_id,
                "workflow_type": row.workflow_type, "checkpoint_data": row.checkpoint_data,
                "is_resumable": row.is_resumable,
            }
        finally:
            s.close()

    def save_checkpoint(self, task_id: str, workflow_id: str, checkpoint_data: str, graph_state: str = None) -> bool:
        from .models import TradeWorkflow
        s = self._session()
        try:
            row = s.query(TradeWorkflow).filter(TradeWorkflow.task_id == task_id).first()
            if row:
                row.checkpoint_data = checkpoint_data
                row.is_resumable = True
                if graph_state:
                    row.graph_state = graph_state
            else:
                row = TradeWorkflow(
                    task_id=task_id, workflow_id=workflow_id,
                    checkpoint_data=checkpoint_data, is_resumable=True,
                    graph_state=graph_state
                )
                s.add(row)
            s.commit()
            return True
        finally:
            s.close()

# ========== 审计Repository ==========
class IAuditRepository(ABC):
    @abstractmethod
    def save_event(self, event: Dict[str, Any]) -> str: ...
    @abstractmethod
    def get_by_trace(self, trace_id: str) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def get_by_workflow(self, workflow_id: str) -> List[Dict[str, Any]]: ...

class AuditRepository(IAuditRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def save_event(self, event: Dict[str, Any]) -> str:
        from .models import AuditEvent
        s = self._session()
        try:
            record = AuditEvent(**event)
            s.add(record)
            s.commit()
            return record.event_id
        finally:
            s.close()

    def get_by_trace(self, trace_id: str) -> List[Dict[str, Any]]:
        from .models import AuditEvent
        s = self._session()
        try:
            rows = s.query(AuditEvent).filter(AuditEvent.trace_id == trace_id).order_by(AuditEvent.timestamp).all()
            return [{"event_id": r.event_id, "event_type": r.event_type, "status": r.status, "timestamp": r.timestamp.isoformat()} for r in rows]
        finally:
            s.close()

    def get_by_workflow(self, workflow_id: str) -> List[Dict[str, Any]]:
        from .models import AuditEvent
        s = self._session()
        try:
            rows = s.query(AuditEvent).filter(AuditEvent.workflow_id == workflow_id).order_by(AuditEvent.timestamp).all()
            return [{"event_id": r.event_id, "event_type": r.event_type, "status": r.status, "timestamp": r.timestamp.isoformat()} for r in rows]
        finally:
            s.close()

# ========== 客户池Repository ==========
class ICustomerPoolRepository(ABC):
    @abstractmethod
    def add(self, data: Dict[str, Any]) -> str: ...
    @abstractmethod
    def list_by_tier(self, tier: str, limit: int = 100) -> List[Dict[str, Any]]: ...
    @abstractmethod
    def update_status(self, pool_id: str, status: str) -> bool: ...

class CustomerPoolRepository(ICustomerPoolRepository):
    def __init__(self, session_factory=None):
        self._session_factory = session_factory or get_session_factory

    def _session(self):
        return self._session_factory() if callable(self._session_factory) else self._session_factory

    def add(self, data: Dict[str, Any]) -> str:
        from .models import TradeCustomerPool
        s = self._session()
        try:
            pool = TradeCustomerPool(**data)
            s.add(pool)
            s.commit()
            s.refresh(pool)
            return pool.pool_id
        finally:
            s.close()

    def list_by_tier(self, tier: str, limit: int = 100) -> List[Dict[str, Any]]:
        from .models import TradeCustomerPool, TradeCompany
        s = self._session()
        try:
            rows = s.query(TradeCustomerPool, TradeCompany).join(
                TradeCompany, TradeCustomerPool.company_id == TradeCompany.entity_id
            ).filter(TradeCompany.customer_tier == tier).limit(limit).all()
            return [{
                "pool_id": p.pool_id, "company_name": c.name, "tier": c.customer_tier,
                "customer_value": p.customer_value, "follow_up_status": p.follow_up_status,
            } for p, c in rows]
        finally:
            s.close()

    def update_status(self, pool_id: str, status: str) -> bool:
        from .models import TradeCustomerPool
        s = self._session()
        try:
            row = s.query(TradeCustomerPool).filter(TradeCustomerPool.pool_id == pool_id).first()
            if not row:
                return False
            row.follow_up_status = status
            s.commit()
            return True
        finally:
            s.close()
