# -*- coding: utf-8 -*-
"""PSV Trade OS v6.0.0 - 统一入口

启动流程：
1. 加载配置
2. 初始化数据库（注入连接）
3. 初始化审计系统
4. 初始化Agent注册表
5. 启动LangGraph编排器
6. 启动WebUI（可选）
"""
import os
import sys
import argparse
import json

# 确保项目根目录在路径中
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.config import settings
from database import init_database, get_session_factory
from database.repository import (
    CompanyRepository, TaskRepository, WorkflowRepository,
    AuditRepository, CustomerPoolRepository
)
from audit import AuditLogger
from agents.registry import AgentRegistry
from orchestrator import TradeOrchestrator
from state import StateManager

class PSVTradeOS:
    """PSV Trade OS 主应用"""

    def __init__(self):
        self.orchestrator = None
        self.audit = None
        self.state_manager = StateManager()
        self._initialized = False

    def initialize(self):
        """初始化系统"""
        if self._initialized:
            return

        print(f"🚀 初始化 {settings.APP_NAME} v{settings.APP_VERSION}")

        # 1. 初始化数据库（注入配置，database不自行创建连接）
        db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "psv_trade.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        database_url = f"sqlite:///{db_path}"
        init_database(database_url, echo=settings.DEBUG)
        session_factory = get_session_factory()
        print(f"  ✅ 数据库初始化完成: {db_path}")

        # 2. 初始化Repository
        company_repo = CompanyRepository(session_factory)
        task_repo = TaskRepository(session_factory)
        workflow_repo = WorkflowRepository(session_factory)
        audit_repo = AuditRepository(session_factory)
        pool_repo = CustomerPoolRepository(session_factory)

        # 3. 初始化审计系统
        self.audit = AuditLogger(audit_repo, batch_size=settings.AUDIT_CONFIG["batch_size"])
        print("  ✅ 审计系统初始化完成")

        # 4. 初始化Agent注册表并注入审计
        registry = AgentRegistry()
        for agent_type in registry.list_agents():
            agent = registry.get_agent(agent_type)
            if agent:
                agent.set_audit_logger(self.audit)
        print(f"  ✅ Agent注册完成: {len(registry.list_agents())} 个Agent")

        # 5. 初始化LangGraph编排器
        checkpoint_manager = orchestrator_module = __import__("orchestrator.checkpoint", fromlist=["CheckpointManager"]).CheckpointManager(workflow_repo, task_repo)
        self.orchestrator = TradeOrchestrator(
            checkpoint_manager=checkpoint_manager,
            agent_registry=registry,
        )
        print("  ✅ LangGraph编排器初始化完成")

        self._initialized = True
        print(f"\n🎉 {settings.APP_NAME} v{settings.APP_VERSION} 启动成功！")

    def run_task(self, objective: str, product: str, market: str, 
                 target_customer: str = "importer") -> Dict[str, Any]:
        """运行外贸开发任务"""
        if not self._initialized:
            self.initialize()

        from shared.utils import generate_id
        task_id = generate_id("task_")
        trace_id = generate_id("trace_")

        # 记录任务开始
        self.audit.log_workflow_start(
            trace_id=trace_id,
            workflow_id=task_id,
            task_id=task_id,
            objective=objective,
        )

        print(f"\n📋 启动任务: {objective}")
        print(f"   产品: {product} | 市场: {market} | 客户类型: {target_customer}")

        result = self.orchestrator.run(
            task_id=task_id,
            objective=objective,
            product=product,
            market=market,
            target_customer=target_customer,
        )

        # 记录任务完成
        self.audit.log_task_complete(
            trace_id=trace_id,
            workflow_id=task_id,
            task_id=task_id,
            status=result.get("status", "completed"),
            summary={"steps_completed": result.get("current_step", 0), "errors": result.get("errors", [])},
        )
        self.audit.flush()

        return result

    def resume_task(self, task_id: str) -> Dict[str, Any]:
        """恢复中断任务"""
        if not self._initialized:
            self.initialize()

        print(f"\n🔄 恢复任务: {task_id}")
        result = self.orchestrator.resume(task_id)
        return result

    def list_recoverable(self) -> list:
        """列出可恢复任务"""
        if not self._initialized:
            self.initialize()
        # 简化实现
        return []

    def start_webui(self, host="0.0.0.0", port=5000):
        """启动Web界面"""
        if not self._initialized:
            self.initialize()

        from webui.app import create_app
        app = create_app(self)
        print(f"\n🌐 启动WebUI: http://{host}:{port}")
        app.run(host=host, port=port, debug=settings.DEBUG)

def main():
    parser = argparse.ArgumentParser(description="PSV Trade OS v6.0.0")
    parser.add_argument("--objective", type=str, help="任务目标")
    parser.add_argument("--product", type=str, help="产品名称")
    parser.add_argument("--market", type=str, help="目标市场")
    parser.add_argument("--target-customer", type=str, default="importer", help="目标客户类型")
    parser.add_argument("--webui", action="store_true", help="启动Web界面")
    parser.add_argument("--resume", type=str, help="恢复任务ID")
    parser.add_argument("--list-recoverable", action="store_true", help="列出可恢复任务")
    parser.add_argument("--init-db", action="store_true", help="初始化数据库")

    args = parser.parse_args()

    app = PSVTradeOS()

    if args.init_db:
        app.initialize()
        print("✅ 数据库初始化完成")
        return

    if args.webui:
        app.start_webui()
        return

    if args.resume:
        result = app.resume_task(args.resume)
        print(json.dumps(result, indent=2, default=str))
        return

    if args.list_recoverable:
        tasks = app.list_recoverable()
        print("可恢复任务:", tasks)
        return

    if args.objective and args.product and args.market:
        result = app.run_task(
            objective=args.objective,
            product=args.product,
            market=args.market,
            target_customer=args.target_customer,
        )
        print("\n" + "="*60)
        print("任务执行结果:")
        print("="*60)
        print(f"状态: {result.get('status')}")
        print(f"完成步骤: {result.get('current_step', 0)}")
        print(f"错误: {result.get('errors', [])}")
        if result.get("final_report"):
            print(f"\n报告:\n{result['final_report']}")
        return

    parser.print_help()

if __name__ == "__main__":
    main()
