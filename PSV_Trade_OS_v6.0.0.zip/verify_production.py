#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生产环境验证 v6.0.0"""
import sys
import os

VERSION = "6.0.0"

def check():
    print(f"PSV Trade OS v{VERSION} - 生产环境验证")
    print("=" * 50)

    checks = [
        ("目录结构", os.path.isdir("agents") and os.path.isdir("orchestrator")),
        ("数据库解耦", not _has_import("database/models.py", "shared.")),
        ("Audit独立", not _has_import("audit/logger.py", "database.models")),
        ("版本统一", _check_version()),
        ("Agent架构", os.path.isdir("agents/trade_planner_agent")),
        ("Contract完整", os.path.exists("contracts/message_contract.py")),
        ("State分层", os.path.exists("state/workflow_state.py") and os.path.exists("state/agent_state.py")),
    ]

    passed = sum(1 for _, ok in checks if ok)
    for name, ok in checks:
        print(f"  [{'OK' if ok else 'FAIL'}] {name}")

    print(f"\n结果: {passed}/{len(checks)} 通过")
    return passed == len(checks)

def _has_import(filepath, pattern):
    if not os.path.exists(filepath):
        return False
    with open(filepath, 'r') as f:
        return pattern in f.read()

def _check_version():
    version_files = ["VERSION.txt", "shared/config/settings.py", "orchestrator/graph.py"]
    versions = []
    for f in version_files:
        if os.path.exists(f):
            with open(f) as fh:
                content = fh.read()
                if "6.0.0" in content:
                    versions.append(True)
    return len(versions) >= 2

if __name__ == "__main__":
    ok = check()
    sys.exit(0 if ok else 1)
