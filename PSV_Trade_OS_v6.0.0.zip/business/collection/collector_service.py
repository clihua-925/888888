# -*- coding: utf-8 -*-
"""Collection Service - 外贸采集业务逻辑

通过Repository Interface访问数据，禁止直接操作数据库。
"""
from typing import Dict, List, Any, Optional
from contracts.data_contract import CompanyProfile
from database.repository import ICompanyRepository

class CollectionService:
    """采集业务服务"""

    def __init__(self, company_repo: ICompanyRepository = None):
        self.company_repo = company_repo

    def discover_companies(self, product: str, market: str, 
                           customer_type: str = "importer",
                           max_results: int = 50) -> List[Dict[str, Any]]:
        """发现企业"""
        # 业务逻辑：组合多个数据源
        companies = []

        # 1. 从数据库查询已有数据
        if self.company_repo:
            existing = self.company_repo.list_by_country(market, limit=max_results)
            companies.extend(existing)

        # 2. 模拟网络采集（实际实现中调用采集工具）
        remaining = max_results - len(companies)
        for i in range(min(remaining, 5)):
            companies.append({
                "name": f"{market} {customer_type.title()} {i+1} Corp",
                "country": market,
                "website": f"https://example{i+1}.com",
                "industry": "Trading",
                "credibility_score": 50 + i * 5,
                "source": "collection",
            })

        return companies

    def deduplicate(self, companies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """去重"""
        seen = set()
        result = []
        for c in companies:
            key = c.get("name", "").upper().strip()
            if key and key not in seen:
                seen.add(key)
                result.append(c)
        return result
