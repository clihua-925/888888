# -*- coding: utf-8 -*-
"""Contracts Package - 统一契约层"""
from .workflow_contract import WorkflowContract
from .agent_contract import AgentRequest, AgentResponse, VALID_AGENT_TYPES
from .task_contract import TaskContract, TaskPlanStep
from .message_contract import MessageContract, MessageEnvelope
from .execution_contract import ExecutionContract, ExecutionBatch
from .data_contract import CompanyProfile, ContactInfo, LeadScore, MarketAnalysis
from .event_contract import EventContract
from .tool_contract import ToolContract, ToolRegistry

__all__ = [
    "WorkflowContract",
    "AgentRequest", "AgentResponse", "VALID_AGENT_TYPES",
    "TaskContract", "TaskPlanStep",
    "MessageContract", "MessageEnvelope",
    "ExecutionContract", "ExecutionBatch",
    "CompanyProfile", "ContactInfo", "LeadScore", "MarketAnalysis",
    "EventContract",
    "ToolContract", "ToolRegistry",
]
