# -*- coding: utf-8 -*-
"""Execution Contract - 执行契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class ExecutionContract(BaseModel):
    execution_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0")
    workflow_id: str = Field(...)
    task_id: str = Field(...)
    agent_id: str = Field(...)
    node_name: str = Field(..., description="LangGraph节点名称")
    input: Dict[str, Any] = Field(default_factory=dict)
    output: Dict[str, Any] = Field(default_factory=dict)
    status: str = Field(..., description="success/failed/retry/skipped/recovered")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    duration_sec: float = Field(0.0, ge=0.0)
    retry_count: int = Field(0, ge=0)
    max_retries: int = Field(3, ge=0)
    error: Optional[str] = None
    error_type: Optional[str] = None
    recovery_action: Optional[str] = None
    trace_id: str = Field(...)

    @validator("status")
    def validate_status(cls, v):
        if v not in ["success", "failed", "retry", "skipped", "recovered"]:
            raise ValueError(f"未知status: {v}")
        return v

class ExecutionBatch(BaseModel):
    batch_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0")
    workflow_id: str
    task_id: str
    executions: List[ExecutionContract] = Field(default_factory=list)
    status: str = Field(default="running")
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
