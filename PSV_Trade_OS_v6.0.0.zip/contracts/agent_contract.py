# -*- coding: utf-8 -*-
"""Agent Contract - 智能体契约"""
from pydantic import BaseModel, Field, validator
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

VALID_AGENT_TYPES = [
    "trade_planner", "market_research", "company_discovery",
    "company_enrichment", "contact_discovery", "lead_scoring",
    "sales_strategy", "report", "supervisor", "planner", "router", "reviewer"
]

class AgentRequest(BaseModel):
    request_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0")
    task_id: str = Field(..., description="关联任务ID")
    agent_type: str = Field(..., description="Agent类型")
    input_data: Dict[str, Any] = Field(..., description="输入数据")
    context: Dict[str, Any] = Field(default_factory=dict, description="上下文信息")
    priority: int = Field(1, ge=1, le=10, description="优先级1-10")
    timeout_sec: int = Field(300, ge=10, le=3600, description="超时时间")
    trace_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    workflow_id: str = Field(default="", description="关联workflow")

    @validator("agent_type")
    def validate_agent_type(cls, v):
        if v not in VALID_AGENT_TYPES:
            raise ValueError(f"未知Agent类型: {v}")
        return v

class AgentResponse(BaseModel):
    response_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0")
    request_id: str = Field(..., description="对应请求ID")
    task_id: str = Field(..., description="关联任务ID")
    agent_type: str = Field(..., description="Agent类型")
    result: Dict[str, Any] = Field(default_factory=dict, description="执行结果")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="置信度")
    status: str = Field(default="success", description="success/partial/failed")
    error: Optional[str] = Field(None, description="错误信息")
    duration_sec: float = Field(0.0, ge=0.0)
    trace_id: str = Field(default="")
    workflow_id: str = Field(default="")
    retry_count: int = Field(0, ge=0)

    @validator("status")
    def validate_status(cls, v):
        if v not in ["success", "partial", "failed"]:
            raise ValueError(f"未知status: {v}")
        return v
