# -*- coding: utf-8 -*-
"""Data Contract - 数据契约（业务数据结构）"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class CompanyProfile(BaseModel):
    entity_id: Optional[str] = None
    name: str = Field(..., description="公司名称")
    name_norm: Optional[str] = None
    country: str = Field(...)
    website: Optional[str] = None
    industry: Optional[str] = None
    main_products: Optional[List[str]] = Field(default_factory=list)
    purchase_direction: Optional[List[str]] = Field(default_factory=list)
    company_size: Optional[str] = None
    supply_chain_role: Optional[str] = None
    credibility_score: float = Field(0.0, ge=0.0, le=100.0)
    purchase_probability: float = Field(0.0, ge=0.0, le=1.0)
    match_score: float = Field(0.0, ge=0.0, le=1.0)
    deal_probability: float = Field(0.0, ge=0.0, le=1.0)
    customer_tier: str = Field(default="D", description="S/A/B/C/D")
    source: Optional[str] = None
    evidence: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    contacts: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    schema_version: str = Field(default="1.0.0")

class ContactInfo(BaseModel):
    contact_id: Optional[str] = None
    company_id: Optional[str] = None
    name: Optional[str] = None
    title: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    linkedin: Optional[str] = None
    is_decision_maker: bool = False
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    source: Optional[str] = None
    verified: bool = False
    schema_version: str = Field(default="1.0.0")

class LeadScore(BaseModel):
    entity_id: Optional[str] = None
    overall_score: float = Field(0.0, ge=0.0, le=100.0)
    match_degree: float = Field(0.0, ge=0.0, le=1.0)
    deal_probability: float = Field(0.0, ge=0.0, le=1.0)
    purchase_likelihood: float = Field(0.0, ge=0.0, le=1.0)
    company_strength: float = Field(0.0, ge=0.0, le=1.0)
    tier: str = Field(default="D", description="S/A/B/C/D")
    reasoning: Optional[str] = None
    schema_version: str = Field(default="1.0.0")

class MarketAnalysis(BaseModel):
    country_code: str
    market_size: Optional[float] = None
    competition_level: str = Field(default="unknown", description="high/medium/low/unknown")
    key_trends: List[str] = Field(default_factory=list)
    major_players: List[Dict[str, Any]] = Field(default_factory=list)
    opportunities: List[str] = Field(default_factory=list)
    risks: List[str] = Field(default_factory=list)
    entry_difficulty: str = Field(default="unknown")
    growth_rate: Optional[float] = None
    schema_version: str = Field(default="1.0.0")
