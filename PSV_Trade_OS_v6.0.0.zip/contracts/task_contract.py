# -*- coding: utf-8 -*-
"""Task Contract - 任务契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class TaskContract(BaseModel):
    task_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0")
    objective: str = Field(..., description="任务目标")
    product: str = Field(..., description="产品")
    market: str = Field(..., description="目标市场")
    target_customer: str = Field(default="importer", description="目标客户类型")
    workflow_id: Optional[str] = None
    status: str = Field(default="pending", description="pending/queued/running/paused/completed/failed")
    current_node: Optional[str] = None
    plan: List[Dict[str, Any]] = Field(default_factory=list)
    result_summary: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    trace_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    metadata: Dict[str, Any] = Field(default_factory=dict)
    retry_count: int = Field(0, ge=0)
    max_retries: int = Field(3, ge=1, le=10)

class TaskPlanStep(BaseModel):
    step_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:8])
    schema_version: str = Field(default="1.0.0")
    step_number: int = Field(..., ge=0)
    agent_type: str = Field(...)
    description: str = Field(...)
    input: Dict[str, Any] = Field(default_factory=dict)
    expected_output: Dict[str, Any] = Field(default_factory=dict)
    dependencies: List[int] = Field(default_factory=list)
    timeout_sec: int = Field(300, ge=10)
    retry_policy: str = Field(default="linear", description="linear/exponential/none")
