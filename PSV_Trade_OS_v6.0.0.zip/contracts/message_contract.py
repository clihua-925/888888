# -*- coding: utf-8 -*-
"""Message Contract - 消息契约（模块间通信标准）"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class MessageContract(BaseModel):
    message_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0")
    source: str = Field(..., description="发送方: user/planner/supervisor/router/executor/reviewer")
    target: str = Field(..., description="接收方")
    message_type: str = Field(..., description="command/query/response/error/event")
    payload: Dict[str, Any] = Field(..., description="消息载荷")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    trace_id: str = Field(..., description="全链路追踪ID")
    workflow_id: str = Field(...)
    task_id: str = Field(...)
    priority: int = Field(5, ge=1, le=10)
    correlation_id: Optional[str] = None

    @validator("message_type")
    def validate_type(cls, v):
        if v not in ["command", "query", "response", "error", "event"]:
            raise ValueError(f"未知message_type: {v}")
        return v

class MessageEnvelope(BaseModel):
    """消息信封，用于队列传输"""
    envelope_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0")
    message: MessageContract
    routing_key: str = Field(default="default")
    ttl_sec: Optional[int] = None
    delivery_count: int = Field(0, ge=0)
    created_at: datetime = Field(default_factory=datetime.utcnow)
