# -*- coding: utf-8 -*-
"""Workflow Contract - 工作流契约"""
from pydantic import BaseModel, Field, validator
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class WorkflowContract(BaseModel):
    workflow_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="2.0.0", description="契约版本号")
    workflow_type: str = Field(..., description="工作流类型")
    status: str = Field(default="pending", description="pending/running/paused/completed/failed/recovered")
    task_id: str = Field(..., description="关联任务ID")
    plan: List[Dict[str, Any]] = Field(default_factory=list)
    current_step: int = Field(default=0, ge=0)
    agent_outputs: List[Dict[str, Any]] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
    checkpoint_id: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    trace_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])

    @validator("workflow_type")
    def validate_type(cls, v):
        valid = ["trade_development", "market_research", "customer_enrichment", "competitive_analysis", "supply_chain"]
        if v not in valid:
            raise ValueError(f"未知workflow_type: {v}, 可选: {valid}")
        return v

    @validator("status")
    def validate_status(cls, v):
        valid = ["pending", "running", "paused", "completed", "failed", "recovered"]
        if v not in valid:
            raise ValueError(f"未知status: {v}")
        return v
