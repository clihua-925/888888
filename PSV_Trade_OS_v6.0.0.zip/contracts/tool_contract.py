# -*- coding: utf-8 -*-
"""Tool Contract - 工具契约"""
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Callable, Optional
from datetime import datetime
import uuid

class ToolContract(BaseModel):
    tool_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    schema_version: str = Field(default="1.0.0")
    tool_name: str = Field(..., description="工具名称")
    description: str = Field(...)
    parameters: Dict[str, Any] = Field(default_factory=dict, description="参数schema")
    return_schema: Dict[str, Any] = Field(default_factory=dict)
    timeout_sec: int = Field(60, ge=1)
    retry_policy: str = Field(default="linear")
    category: str = Field(default="general", description="web/search/database/analysis")
    enabled: bool = True

class ToolRegistry:
    """工具注册表"""
    _tools: Dict[str, Callable] = {}
    _schemas: Dict[str, ToolContract] = {}

    @classmethod
    def register(cls, name: str, schema: Optional[ToolContract] = None):
        def decorator(func: Callable):
            cls._tools[name] = func
            if schema:
                cls._schemas[name] = schema
            return func
        return decorator

    @classmethod
    def get(cls, name: str) -> Optional[Callable]:
        return cls._tools.get(name)

    @classmethod
    def list_tools(cls) -> List[str]:
        return list(cls._tools.keys())

    @classmethod
    def get_schema(cls, name: str) -> Optional[ToolContract]:
        return cls._schemas.get(name)
