# -*- coding: utf-8 -*-
"""WebUI - Flask应用"""
from flask import Flask, render_template, jsonify, request
from shared.config import settings

def create_app(psv_app):
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config["SECRET_KEY"] = "psv-trade-os-secret-key"

    @app.route("/")
    def dashboard():
        return render_template("dashboard.html", version=settings.APP_VERSION)

    @app.route("/api/tasks", methods=["POST"])
    def create_task():
        data = request.json
        result = psv_app.run_task(
            objective=data.get("objective", ""),
            product=data.get("product", ""),
            market=data.get("market", ""),
            target_customer=data.get("target_customer", "importer"),
        )
        return jsonify({"success": True, "data": result})

    @app.route("/api/status")
    def status():
        return jsonify({
            "version": settings.APP_VERSION,
            "agents": len(__import__("agents.registry", fromlist=["AgentRegistry"]).AgentRegistry.list_agents()),
            "status": "running",
        })

    return app
