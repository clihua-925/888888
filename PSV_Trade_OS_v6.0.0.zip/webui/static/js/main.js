document.getElementById("taskForm").addEventListener("submit", async function(e){
    e.preventDefault();
    const data = {
        objective: document.getElementById("objective").value,
        product: document.getElementById("product").value,
        market: document.getElementById("market").value,
    };
    const res = await fetch("/api/tasks", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)});
    const json = await res.json();
    document.getElementById("result").textContent = JSON.stringify(json, null, 2);
});