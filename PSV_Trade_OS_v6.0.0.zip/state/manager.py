# -*- coding: utf-8 -*-
"""State Manager - 统一状态管理入口"""
from typing import Dict, List, Any, Optional
import json
from .workflow_state import WorkflowState, create_initial_workflow_state, AgentState, TaskState
from .task_state import TaskStateManager
from .agent_state import AgentStateManager

class StateManager:
    """统一状态管理器"""

    def __init__(self):
        self._active_states: Dict[str, WorkflowState] = {}
        self._task_manager = TaskStateManager()
        self._agent_manager = AgentStateManager()

    def create_workflow(self, task_id: str, objective: str, product: str, market: str,
                        target_customer: str = "importer") -> WorkflowState:
        state = create_initial_workflow_state(task_id, objective, product, market, target_customer)
        self._active_states[state["workflow_id"]] = state
        return state

    def get_workflow(self, workflow_id: str) -> Optional[WorkflowState]:
        return self._active_states.get(workflow_id)

    def update_workflow(self, workflow_id: str, updates: Dict[str, Any]) -> Optional[WorkflowState]:
        state = self._active_states.get(workflow_id)
        if state:
            state.update(updates)
        return state

    def register_agent(self, workflow_id: str, agent_type: str, agent_id: str = None) -> AgentState:
        state = self._active_states.get(workflow_id)
        if not state:
            raise ValueError(f"Workflow {workflow_id} not found")
        agent_state = self._agent_manager.create(agent_type, agent_id)
        state["agents"][agent_state["agent_id"]] = agent_state
        return agent_state

    def update_agent(self, workflow_id: str, agent_id: str, updates: Dict[str, Any]) -> Optional[AgentState]:
        state = self._active_states.get(workflow_id)
        if state and agent_id in state["agents"]:
            state["agents"][agent_id].update(updates)
            return state["agents"][agent_id]
        return None

    def add_checkpoint(self, workflow_id: str, checkpoint_id: str) -> None:
        state = self._active_states.get(workflow_id)
        if state:
            state["checkpoints"].append(checkpoint_id)

    def add_review(self, workflow_id: str, review: Dict[str, Any]) -> None:
        state = self._active_states.get(workflow_id)
        if state:
            state["reviews"].append(review)

    def add_error(self, workflow_id: str, error: str) -> None:
        state = self._active_states.get(workflow_id)
        if state:
            state["error_log"].append({"error": error, "timestamp": __import__("datetime").datetime.utcnow().isoformat()})
            state["task"]["errors"].append(error)

    def serialize(self, workflow_id: str) -> str:
        state = self._active_states.get(workflow_id)
        if state:
            return json.dumps(state, default=str)
        return "{}"

    def deserialize(self, workflow_id: str, data: str) -> WorkflowState:
        state = json.loads(data)
        self._active_states[workflow_id] = state
        return state

    def clear(self, workflow_id: str) -> None:
        self._active_states.pop(workflow_id, None)
