# -*- coding: utf-8 -*-
"""AgentState - Agent状态管理"""
from typing import Dict, List, Any, Optional
from datetime import datetime

class AgentStateManager:
    """Agent状态管理器"""

    @staticmethod
    def create(agent_type: str, agent_id: str = None) -> Dict[str, Any]:
        from shared.utils import generate_id, now_iso
        return {
            "agent_id": agent_id or generate_id(f"agent_{agent_type}_"),
            "agent_type": agent_type,
            "status": "idle",
            "input": {},
            "output": {},
            "error": None,
            "retry_count": 0,
            "duration_sec": 0.0,
            "timestamp": now_iso(),
            "confidence": 0.0,
        }

    @staticmethod
    def start(agent_state: Dict[str, Any], input_data: Dict[str, Any]) -> Dict[str, Any]:
        from shared.utils import now_iso
        agent_state["status"] = "running"
        agent_state["input"] = input_data
        agent_state["timestamp"] = now_iso()
        agent_state["error"] = None
        return agent_state

    @staticmethod
    def complete(agent_state: Dict[str, Any], output_data: Dict[str, Any], 
                 confidence: float = 0.0, duration_sec: float = 0.0) -> Dict[str, Any]:
        from shared.utils import now_iso
        agent_state["status"] = "completed"
        agent_state["output"] = output_data
        agent_state["confidence"] = confidence
        agent_state["duration_sec"] = duration_sec
        agent_state["timestamp"] = now_iso()
        return agent_state

    @staticmethod
    def fail(agent_state: Dict[str, Any], error: str, duration_sec: float = 0.0) -> Dict[str, Any]:
        from shared.utils import now_iso
        agent_state["status"] = "failed"
        agent_state["error"] = error
        agent_state["duration_sec"] = duration_sec
        agent_state["retry_count"] = agent_state.get("retry_count", 0) + 1
        agent_state["timestamp"] = now_iso()
        return agent_state

    @staticmethod
    def can_retry(agent_state: Dict[str, Any], max_retries: int = 3) -> bool:
        return agent_state.get("retry_count", 0) < max_retries
