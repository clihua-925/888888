# PSV Trade OS 9.4.0 — Current Source Bundle
> Generated from the current audited deployment tree. Runtime databases and transient artifacts are excluded.

## `.env`

Runtime-only configuration source. Values below are masked: `.env` is never
deployable, never packaged, and never listed in the manifest.

```text
APP_VERSION=9.4.0
LLM_BASE_URL=<llama.cpp OpenAI-compatible endpoint>
LLM_API_KEY=<runtime credential, never published>
LLM_MODEL=deepseek-r1-distill-llama-70b
```

## `.env.example`

Deployable configuration template (kept in the manifest and the release ZIP;
must never contain a real credential).

```text
APP_VERSION=9.4.0
WEB_HOST=127.0.0.1
WEB_PORT=8090
LLM_BASE_URL=http://192.168.1.26:8081/v1
LLM_API_KEY=
LLM_MODEL=deepseek-r1-distill-llama-70b
DATABASE_PATH=data/psv.db
CHECKPOINT_PATH=data/checkpoints.db
MAX_TASK_SECONDS=1800
LOG_LEVEL=INFO
MAX_STEPS=40
MAX_RETRIES=2
NO_PROGRESS_LIMIT=3
```

## `AUDIT.txt`

```text
PSV Trade OS 9.4.0 AUDITED DEPLOYMENT REVIEW

审计对象：PSV Trade OS 9.4.0 当前 Runtime 修正版。
审核原则：冻结架构为唯一基线；未实际执行的外部运行时能力不写成 PASS。

1. 五层架构：PASS（静态）。WebUI/API、Orchestration、Business、Contract/Runtime/State、Infrastructure 边界保持。
2. 九业务节点：PASS（静态）。节点集合为冻结的九个节点；非 DATABASE_COMMIT 节点不直接依赖 Database 写入接口，也不包含路由/恢复/重试/超时/调度/checkpoint 控制。
3. WorkflowSpec：PASS（静态）。未声明 ORDER/EDGES/RECOVERY；仅声明 workflow、nodes、contracts、payload_keys、capabilities。
4. Workflow Registry：PASS（静态）。通过 pkgutil.iter_modules 动态发现 business.workflows 下的 workflow/spec.py，不硬编码 trade_collection 导入。
5. Condition Edge Engine：PASS（静态）。唯一正式路由器，包含 verified_evidence_gate。
6. RecoveryManager：PASS（静态）。通用 failure_type/retry/recovery，不硬编码业务节点 ID。
7. Shared State：PASS（静态）。冻结要求的 12 个核心状态字段保持。
8. Contract Registry：PASS（静态）。Engine 在节点执行前后执行 input/output contract validation。
9. Decision Layer：PASS（静态）。Task Understanding 与业务 AI 判断均通过统一 DecisionLayer；Mission Understanding 使用 schema-constrained response_format，并保留运行时校验。
10. LLM Structured Output：PASS（静态）。ReasoningEngine 使用 llama.cpp 兼容的 response_format={type: json_object, schema: ...}；llama.cpp 当前文档明确支持该形式。
11. 异步提交：PASS（静态）。POST /api/orchestration/run 先 create_pending 持久化，再由 Scheduler 后台线程执行 AI/Graph；Verifier 增加 HTTP 202 提交耗时门槛。
12. Hard Timeout：PASS（静态）。Task Understanding 在 Scheduler worker 进程内使用 daemon thread 并受阶段预算约束；Graph 使用 Scheduler worker 进程内的生命周期剩余 MAX_TASK_SECONDS 预算执行，因此整个任务生命周期受硬超时边界约束。
13. Durable Resume：PASS（静态）。LangGraph SqliteSaver 使用 task_id 作为 thread_id。
14. DATABASE_COMMIT：PASS（静态）。正式 trade_entities/trade_edges/evidence 写入仅由 DATABASE_COMMIT；数据库对象由 Engine 瞬态注入。
15. Runtime Verifier：PASS（静态）。使用随机 localhost 端口、独立临时 DB/checkpoint、Windows 进程树终止、文件锁重试、无 stdout PIPE 堵塞。
16. API/UI：PASS（静态）。冻结 API 与根页面保持。
17. Windows 启动：PASS（静态）。start.bat 使用项目本地 .venv；runtime gate 成功后启动 8090 WebUI。
18. 文件卫生：PASS（静态）。发布打包器先清理并在归档时再次排除 __pycache__、*.pyc、*.tmp、*.bak、*.swp 等瞬态文件；PROJECT_SOURCE_MANIFEST.txt 由实际发布树自动生成。
19. 禁止标记：PASS（静态）。源码未发现 pass/TODO/FIXME/NotImplemented/空函数。
20. 回归测试接口：PASS（静态）。Acceptance test double 已与生产 ReasoningEngine.review(response_schema=...) 接口一致；Scheduler 重启恢复与打包卫生均有测试覆盖；Manifest 含 File count 头并与部署树逐项一致。

动态验证边界：当前审计容器没有完整第三方 Python 依赖，无法诚实执行该包的 pytest/真实 LLM Runtime Gate；因此本文件不把它们写成 PASS。最终动态认证必须在用户 Windows 环境使用现有 venv 与真实 192.168.1.26:8081/v1 LLM 执行 verify_install.py 与 verify_install.py --runtime。
```

## `CHANGELOG.txt`

```text
9.4.0 Runtime Audit Revision
- 对 Runtime 修正版进行全面静态架构审计。
- 修正测试替身与 ReasoningEngine.review(response_schema=...) 的接口契约不一致。
- DecisionLayer 恢复明确的 schema forwarding，不再在生产路径使用反射兼容分支。
- 非 DATABASE_COMMIT 业务节点移除 Database 类依赖；数据库写入仍仅通过正式 DATABASE_COMMIT 注入边界。
- Runtime Gate 保留随机 localhost 端口、Windows 进程树终止、SQLite 文件锁重试与无 PIPE 堵塞设计。
- Runtime Gate 增加 HTTP 202 异步提交耗时验证。
- 部署包移除预置 data/psv.db，避免把开发数据库带入正式部署。
- 更新 PROJECT_SOURCE_MANIFEST.txt 与 PROJECT_SOURCE_BUNDLE.md。

9.4.0 deployment hardening
- Release packer now removes and excludes transient artifacts and regenerates PROJECT_SOURCE_MANIFEST.txt from the deployable tree.
- The deployable .env.example records the deployment LLM endpoint template; .env remains runtime-only, excluded from the manifest and release ZIP.
- Scheduler scans persisted PENDING/RUNNING tasks at startup; PENDING tasks are requeued and interrupted RUNNING tasks without checkpoints are marked failed with an audit event.
- Task Understanding runs as a daemon thread inside the Scheduler worker process with its stage budget; the remaining MAX_TASK_SECONDS budget is passed to graph execution, making the hard timeout lifecycle-wide.
- Acceptance coverage includes scheduler restart recovery and release-artifact filtering.
```

## `ENVIRONMENT_LAYOUT.txt`

```text
PSV Trade OS 9.4.0 - Environment Layout

Recommended Windows layout:

PSV_Trade_OS_9.4.0_FINAL\
  .venv\                                  <- project-local Python runtime environment
  data\
  core\
  business\
  tests\
  start.bat

The project start.bat always uses .venv inside the project directory.
If .venv does not exist, start.bat creates it automatically and installs requirements.txt.

The runtime environment therefore travels with the project deployment directory and remains
consistent with the frozen Windows-native startup chain.
```

## `README.md`

```text
# PSV Trade OS 9.4.0

PSV Trade OS 9.4.0 是 Windows 原生的外贸智能执行系统，以冻结架构为唯一运行基线。

## 冻结架构

五层边界：
1. WebUI / API
2. Orchestration Agent
3. Business
4. Contract / Runtime / State
5. Infrastructure

Business 层保持九个纯执行节点：
1. PRODUCT_DEFINITION
2. TRADE_STRATEGY
3. CUSTOMS_NODE_COLLECTION
4. TRADE_EDGE_BUILD
5. EVIDENCE_VERIFY
6. ENTITY_RESOLUTION
7. GRAPH_EXPANSION
8. RESOURCE_CLASSIFICATION
9. DATABASE_COMMIT

业务节点不负责路由、重试、恢复、超时、调度或 checkpoint 生命周期控制。DATABASE_COMMIT 是唯一正式业务数据库写入边界。

## Condition Edge verified_evidence_gate

`core/orchestration/conditions.py` 是唯一正式运行时路由器。当前节点为 `EVIDENCE_VERIFY` 时，路由器检查 `state["evidence_pool"]`：

- 存在 `verified=True` 的证据：路由到 `ENTITY_RESOLUTION`。
- 不存在：将状态设置为 `STATUS_FAILED`，写入 `VERIFIED_EVIDENCE_REQUIRED` 错误，并终止路由。

该条件逻辑不在 Business Node 或 WorkflowSpec。

## DATABASE 注入边界

`DATABASE_COMMIT` 不再创建 Database fallback。WorkflowEngine 在执行业务节点前向 `ContextVar provider binding` 注入 Database 实例，节点执行完成后移除该瞬态对象；缺失注入时 `DATABASE_COMMIT` 直接抛出 RuntimeError。

## 测试分层

`tests/conftest.py` 中的 `FixedDecisionReasoning` 和 `IntegrationSchedulerDouble` 都是隔离测试替身，不代表真实生产编排链路。Flask 测试用于 API、隔离数据库和路由契约验证。

真实全链路：

`API -> Scheduler -> Mission -> Task Understanding -> WorkflowRegistry -> LangGraph -> Condition Edge -> Business Nodes -> Checkpoint -> DATABASE_COMMIT -> SQLite`

由：

```text
python verify_install.py --runtime
```

执行验证。

## Windows 部署

1. 安装 Python 3.10–3.13。
2. 根据 `.env.example` 配置环境。
3. 配置可访问的 OpenAI-compatible LLM endpoint，并使用 `deepseek-r1-distill-llama-70b`。
4. 运行 `start.bat`。
5. 启动脚本创建项目内 `.venv`、安装 requirements、执行静态/运行时门禁，然后启动 `127.0.0.1:8090`。
6. 如需 Chrome/Edge CDP 9222，运行 `start_chrome_debug.bat`。

## 验证

静态验证：

```text
.venv\Scripts\python.exe verify_install.py
.venv\Scripts\python.exe -m pytest tests -q
```

完整运行时验证：

```text
.venv\Scripts\python.exe verify_install.py --runtime
```

Runtime Gate 要求真实第三方依赖和可访问的 OpenAI-compatible endpoint；不会使用 Mock LLM 替代真实运行。

## 固定配置

- APP_VERSION=9.4.0
- WEB_HOST=127.0.0.1
- WEB_PORT=8090
- LLM_BASE_URL=http://192.168.1.26:8081/v1
- LLM_MODEL=deepseek-r1-distill-llama-70b
- DATABASE_PATH=data/psv.db
- CHECKPOINT_PATH=data/checkpoints.db
- MAX_TASK_SECONDS=1800
- MAX_STEPS=40
- MAX_RETRIES=2
- NO_PROGRESS_LIMIT=3

## 环境目录

Windows 启动链使用项目内 `.venv`，环境目录与源码项目同级且属于项目部署目录的一部分。
```

## `VERSION.txt`

```text
9.4.0
```

## `business/__init__.py`

```python
"""PSV Trade OS business layer."""

__version__ = "9.4.0"
```

## `business/workflows/__init__.py`

```python
"""Business workflow package for PSV Trade OS 9.4.0."""
```

## `business/workflows/trade_collection/__init__.py`

```python
"""Trade collection workflow package for PSV Trade OS 9.4.0."""

from .spec import WORKFLOW_ID, WORKFLOW_VERSION, NODE_IDS, NODE_SPECS, CONTRACTS, PAYLOAD_KEYS, CAPABILITIES

__all__ = ["WORKFLOW_ID", "WORKFLOW_VERSION", "NODE_IDS", "NODE_SPECS", "CONTRACTS", "PAYLOAD_KEYS", "CAPABILITIES"]
```

## `business/workflows/trade_collection/nodes.py`

```python
"""Real deterministic and AI-assisted business nodes for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import logging
import re
from copy import deepcopy
from difflib import SequenceMatcher
from typing import Any, Mapping

from core.config.industry import load_industry
from core.config.settings import ROOT
from core.orchestration.state import TaskState

LOGGER = logging.getLogger(__name__)

REPORT_STATUS_COMMITTED = "committed"

# Decision labels are business input values; the decision service itself is injected by orchestration.
DECISION_ENTITY_RESOLUTION = "entity_resolution"
DECISION_RELATIONSHIP_JUDGMENT = "relationship_judgment"
DECISION_EVIDENCE_VERIFICATION = "evidence_verification"
DECISION_RESOURCE_CLASSIFICATION = "resource_classification"


_PRODUCT_RULES: tuple[tuple[tuple[str, ...], str, str, tuple[str, ...]], ...] = (
    (("solar", "photovoltaic", "pv"), "Solar photovoltaic equipment", "8501", ("solar", "photovoltaic", "pv")),
    (("battery", "energy storage", "storage"), "Energy storage equipment", "8507", ("battery", "energy storage", "storage")),
    (("inverter", "inverters"), "Power inverter equipment", "8504", ("inverter", "power conversion")),
    (("semiconductor", "chip", "chips", "integrated circuit"), "Semiconductor components", "8542", ("semiconductor", "chip", "integrated circuit")),
    (("steel", "stainless steel", "steel product"), "Steel products", "7200", ("steel", "metal", "industrial")),
    (("aluminum", "aluminium"), "Aluminum products", "7600", ("aluminum", "metal", "industrial")),
    (("coffee", "cocoa", "cacao", "tea"), "Agricultural beverage products", "0900", ("agricultural", "beverage", "food")),
    (("machinery", "machine", "equipment", "industrial equipment"), "Industrial machinery and equipment", "8400", ("machinery", "equipment", "industrial")),
    (("textile", "apparel", "garment", "clothing"), "Textile and apparel products", "6100", ("textile", "apparel", "garment")),
    (("plastic", "polymer", "resin"), "Plastic and polymer products", "3900", ("plastic", "polymer", "resin")),
)


_COUNTRY_BY_MARKET = {
    "us": "United States",
    "usa": "United States",
    "united states": "United States",
    "china": "China",
    "cn": "China",
    "germany": "Germany",
    "de": "Germany",
    "japan": "Japan",
    "jp": "Japan",
    "south korea": "South Korea",
    "korea": "South Korea",
    "uk": "United Kingdom",
    "united kingdom": "United Kingdom",
    "france": "France",
    "italy": "Italy",
    "singapore": "Singapore",
    "india": "India",
    "vietnam": "Vietnam",
    "australia": "Australia",
    "canada": "Canada",
    "mexico": "Mexico",
    "brazil": "Brazil",
}


def _industry_profile(industry: str) -> Mapping[str, Any]:
    """Load optional bundled industry metadata without affecting orchestration."""
    try:
        profile = load_industry(industry)
    except (OSError, ValueError, TypeError):
        return {}
    return profile if isinstance(profile, Mapping) else {}


def _load_import_records(state: TaskState) -> list[Mapping[str, Any]]:
    """Load optional normalized local trade records for business-node processing."""
    mission = state.get("mission", {})
    market = str(mission.get("market") or state.get("market") or "").strip().lower()
    industry = str(mission.get("industry") or state.get("industry") or "").strip().lower()
    candidates = [
        ROOT / "data" / "imports" / f"{market}_{industry}.json",
        ROOT / "data" / "imports" / "records.json",
    ]
    for path in candidates:
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"Invalid local trade record file: {path}") from exc
        records = payload.get("records", []) if isinstance(payload, Mapping) else payload
        if not isinstance(records, list):
            raise ValueError(f"Trade record file must contain a list: {path}")
        return [item for item in records if isinstance(item, Mapping)]
    return []


def _mission_text(mission: Mapping[str, Any]) -> str:
    values = [
        mission.get("objective", ""),
        mission.get("task_type", ""),
        mission.get("intent", ""),
        mission.get("industry", ""),
        mission.get("market", ""),
    ]
    targets = mission.get("targets", [])
    if isinstance(targets, (list, tuple)):
        values.extend(str(item) for item in targets)
    return " ".join(str(item) for item in values if item).strip()


def _target_values(mission: Mapping[str, Any]) -> list[str]:
    targets = mission.get("targets", [])
    if isinstance(targets, str):
        candidates = re.split(r"[,;|/]+", targets)
    elif isinstance(targets, (list, tuple, set)):
        candidates = [str(item) for item in targets]
    else:
        candidates = []
    cleaned = [item.strip() for item in candidates if item and item.strip()]
    return list(dict.fromkeys(cleaned))


def _market_name(value: Any) -> str:
    text = str(value or "").strip()
    return _COUNTRY_BY_MARKET.get(text.lower(), text)


def _keywords_for_product(text: str, industry: str) -> list[str]:
    lowered = text.lower()
    keywords: list[str] = []
    for triggers, _, _, rule_keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            keywords.extend(rule_keywords)
    if industry:
        keywords.append(industry.strip().lower())
    if not keywords:
        words = re.findall(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}", lowered)
        keywords.extend(words[:6])
    return list(dict.fromkeys(keyword for keyword in keywords if keyword))[:12]


def _product_rule(text: str) -> tuple[str, str, tuple[str, ...]]:
    lowered = text.lower()
    for triggers, product_name, hs_code, keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            return product_name, hs_code, keywords
    targets = _target_values({"targets": [text]})
    product_name = targets[0] if targets else "Target trade product"
    return product_name, "UNSPECIFIED", ()


def _decision_layer(state: TaskState) -> Any:
    """Return the orchestration-injected decision service or fail explicitly."""
    orchestration = state.get("orchestration", {})
    candidate = orchestration.get("decision_layer") if isinstance(orchestration, Mapping) else None
    if candidate is None or not callable(getattr(candidate, "decide", None)):
        raise RuntimeError(
            "DecisionLayer injection missing: orchestration must provide "
            "state['orchestration']['decision_layer'] before business execution"
        )
    return candidate


def _decision_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, Mapping):
        for key in ("verified", "merge", "related", "match", "relevant", "approve"):
            if key in value:
                return bool(value[key])
        return False
    if isinstance(value, str):
        return value.strip().lower() in {"true", "yes", "verified", "merge", "related", "match", "approve"}
    return bool(value) if isinstance(value, (int, float)) else False


def _decision_text(value: Any, default: str = "") -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        for key in ("rationale", "verification_reason", "canonical_name", "resource_class"):
            item = value.get(key)
            if item:
                return str(item)
    return default


def _decision_value(result: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    decision = result.get("decision")
    if isinstance(decision, Mapping):
        for key in keys:
            if key in decision:
                return decision[key]
    metadata = result.get("metadata")
    if isinstance(metadata, Mapping):
        for key in keys:
            if key in metadata:
                return metadata[key]
    for key in keys:
        if key in result:
            return result[key]
    return default


def _normalize_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _entity_id_for_node(node: Mapping[str, Any], index: int) -> str:
    existing = str(node.get("entity_id", "")).strip()
    if existing:
        return existing
    node_id = str(node.get("node_id", "")).strip()
    if node_id:
        return f"ENTITY_{node_id}"
    return f"ENTITY_{index + 1}"


def _entity_map(entities: list[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    return {
        str(entity.get("entity_id")): entity
        for entity in entities
        if entity.get("entity_id")
    }


def PRODUCT_DEFINITION(state: TaskState) -> TaskState:
    """Build a deterministic product definition from the Mission payload."""
    result = deepcopy(state)
    mission = dict(result.get("mission", {}))
    targets = _target_values(mission)
    mission_text = _mission_text(mission)
    industry = str(mission.get("industry", "")).strip()
    market = _market_name(mission.get("market", ""))

    target_text = " ".join(targets) if targets else mission_text
    product_name, hs_code, rule_keywords = _product_rule(target_text)
    profile = _industry_profile(industry)
    profile_keywords = [str(item).strip() for item in profile.get("keywords", []) if str(item).strip()]
    profile_hs_codes = [str(item).strip() for item in profile.get("hs_codes", []) if str(item).strip()]
    if product_name == "Target trade product" and profile.get("name"):
        product_name = str(profile["name"])
    if hs_code == "UNSPECIFIED" and profile_hs_codes:
        hs_code = profile_hs_codes[0]
    keywords = _keywords_for_product(target_text, industry)
    keywords.extend(rule_keywords)
    keywords.extend(profile_keywords)
    keywords = list(dict.fromkeys(keywords))[:12]

    description = (
        f"Trade product definition for {product_name} in the {market or 'target'} "
        f"market, serving the {industry or 'specified'} industry."
    )

    target_customer = "business buyers"
    lowered = mission_text.lower()
    if any(word in lowered for word in ("consumer", "retail", "ecommerce", "end user")):
        target_customer = "consumer and retail buyers"
    elif any(word in lowered for word in ("manufacturer", "factory", "industrial")):
        target_customer = "manufacturers and industrial buyers"
    elif any(word in lowered for word in ("distributor", "wholesaler", "importer")):
        target_customer = "importers, distributors, and wholesalers"

    result["product_definition"] = {
        "product_name": product_name,
        "description": description,
        "keywords": keywords,
        "hs_code_guess": hs_code,
        "market": market,
        "industry": industry,
        "target_customer_type": target_customer,
        "source_targets": targets,
        "industry_profile": dict(profile),
    }
    return result


def TRADE_STRATEGY(state: TaskState) -> TaskState:
    """Generate deterministic trade-search strategy fragments."""
    result = deepcopy(state)
    product = dict(result.get("product_definition", {}))
    market = str(product.get("market", "")).strip()
    keywords = list(product.get("keywords", []))
    product_name = str(product.get("product_name", "Target trade product"))

    keyword_text = list(dict.fromkeys([product_name.lower(), *[str(item) for item in keywords]]))
    fragments = [
        {
            "type": "buyer_search",
            "market": market,
            "keywords": keyword_text[:10],
            "priority": 1,
        },
        {
            "type": "supplier_search",
            "market": market,
            "keywords": keyword_text[:10],
            "priority": 1,
        },
        {
            "type": "market_entry",
            "market": market,
            "keywords": keyword_text[:8],
            "priority": 2,
        },
    ]

    result["fragments"] = fragments
    return result


def CUSTOMS_NODE_COLLECTION(state: TaskState) -> TaskState:
    """Collect normalized local records, with deterministic fallback fixtures when absent."""
    result = deepcopy(state)
    product = dict(result.get("product_definition", {}))
    fragments = list(result.get("fragments", []))
    market = _market_name(product.get("market", "")) or "Target market"
    industry = str(product.get("industry", "")).strip()
    product_name = str(product.get("product_name", "Target trade product"))

    existing_nodes = list(result.get("trade_nodes", []))
    existing_evidence = list(result.get("evidence_pool", []))
    existing_node_ids = {str(item.get("node_id")) for item in existing_nodes}
    existing_evidence_ids = {str(item.get("evidence_id")) for item in existing_evidence}

    records = _load_import_records(result)
    source_nodes: list[dict[str, Any]] = []
    for index, item in enumerate(records, start=1):
        name = str(item.get("name") or item.get("company") or "").strip()
        if not name:
            continue
        country = _market_name(item.get("country") or market)
        role = str(item.get("role") or "unknown").strip().lower()
        if role not in {"buyer", "supplier", "importer", "exporter", "unknown"}:
            role = "unknown"
        source_nodes.append({
            "node_id": str(item.get("node_id") or f"IMPORT_NODE_{index:03d}"),
            "name": name,
            "role": role,
            "country": country,
            "source": str(item.get("source") or "local_import"),
            "shipments": int(item.get("shipments") or 0),
            "industry": str(item.get("industry") or industry),
            "metadata": dict(item.get("metadata", {})) if isinstance(item.get("metadata"), Mapping) else {},
        })

    if not source_nodes:
        source_nodes = [
            {"node_id": "SYNTHETIC_BUYER_001", "name": f"{product_name} Buyer Group A", "role": "buyer", "country": market, "source": "synthetic", "shipments": 18, "contact": "unknown_contact", "industry": industry},
            {"node_id": "SYNTHETIC_SUPPLIER_001", "name": f"{product_name} Supplier Group A", "role": "supplier", "country": "China", "source": "synthetic", "shipments": 26, "contact": "unknown_contact", "industry": industry},
            {"node_id": "SYNTHETIC_IMPORTER_001", "name": f"{product_name} Importer Group A", "role": "importer", "country": market, "source": "synthetic", "shipments": 14, "contact": "unknown_contact", "industry": industry},
            {"node_id": "SYNTHETIC_EXPORTER_001", "name": f"{product_name} Exporter Group A", "role": "exporter", "country": "China", "source": "synthetic", "shipments": 22, "contact": "unknown_contact", "industry": industry},
        ]

    for node in source_nodes:
        node_id = str(node.get("node_id") or "").strip()
        if not node_id or node_id in existing_node_ids:
            continue
        existing_nodes.append(node)
        existing_node_ids.add(node_id)

    for index, node in enumerate(existing_nodes, start=1):
        node_id = str(node.get("node_id") or f"TRADE_NODE_{index:03d}")
        node["node_id"] = node_id
        evidence_id = f"EVIDENCE_{index:03d}"
        if evidence_id in existing_evidence_ids:
            continue
        existing_evidence.append({
            "evidence_id": evidence_id,
            "entity_name": str(node.get("name", "")),
            "evidence_type": "trade_record",
            "source": str(node.get("source", "local_import")),
            "shipments": int(node.get("shipments", 0) or 0),
            "verified": False,
            "evidence_json": {
                "node_id": node_id,
                "product": product_name,
                "strategy_fragments": [item.get("type") for item in fragments if isinstance(item, Mapping)],
            },
        })
        existing_evidence_ids.add(evidence_id)

    result["trade_nodes"] = existing_nodes
    result["evidence_pool"] = existing_evidence
    return result


def TRADE_EDGE_BUILD(state: TaskState) -> TaskState:
    """Use the DecisionLayer to judge candidate buyer-seller relationships."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence = list(result.get("evidence_pool", []))
    relationships = list(result.get("relationships", []))
    entities = list(result.get("entities", []))
    ai = _decision_layer(result)
    entity_by_id = _entity_map(entities)
    node_to_entity: dict[str, Mapping[str, Any]] = {}
    for entity in entities:
        metadata = entity.get("metadata", {})
        if isinstance(metadata, Mapping):
            for source_node_id in metadata.get("merged_from", []):
                node_to_entity[str(source_node_id)] = entity

    role_pairs = {
        ("buyer", "supplier"),
        ("buyer", "exporter"),
        ("importer", "supplier"),
        ("importer", "exporter"),
    }

    existing_edges = {str(item.get("edge_id")) for item in relationships}
    evidence_by_name = {
        str(item.get("entity_name", "")): item
        for item in evidence
    }

    for left_index, left in enumerate(nodes):
        for right_index in range(left_index + 1, len(nodes)):
            right = nodes[right_index]
            pair = (
                str(left.get("role", "")).lower(),
                str(right.get("role", "")).lower(),
            )
            reverse_pair = (pair[1], pair[0])
            if pair not in role_pairs and reverse_pair not in role_pairs:
                continue

            left_node_id = str(left.get("node_id") or f"SYNTHETIC_NODE_{left_index + 1:03d}")
            right_node_id = str(right.get("node_id") or f"SYNTHETIC_NODE_{right_index + 1:03d}")
            left_entity_record = node_to_entity.get(left_node_id)
            right_entity_record = node_to_entity.get(right_node_id)
            left_id = str(
                left_entity_record.get("entity_id")
                if left_entity_record
                else _entity_id_for_node(left, left_index)
            )
            right_id = str(
                right_entity_record.get("entity_id")
                if right_entity_record
                else _entity_id_for_node(right, right_index)
            )
            left_entity = entity_by_id.get(left_id, left)
            right_entity = entity_by_id.get(right_id, right)
            prompt = (
                "Judge whether these two trade entities have a commercially plausible "
                "buyer-seller or importer-exporter relationship. Use the supplied roles, "
                "countries, shipment counts, and evidence. Do not infer a relationship "
                "solely because both entities exist."
            )
            payload = {
                "source": left_entity or left,
                "target": right_entity or right,
                "source_role": left.get("role"),
                "target_role": right.get("role"),
                "source_country": left.get("country"),
                "target_country": right.get("country"),
                "source_shipments": left.get("shipments", 0),
                "target_shipments": right.get("shipments", 0),
                "source_evidence": evidence_by_name.get(str(left.get("name", "")), {}),
                "target_evidence": evidence_by_name.get(str(right.get("name", "")), {}),
            }
            decision = ai.decide(
                result,
                DECISION_RELATIONSHIP_JUDGMENT,
                prompt,
                payload,
            )
            accepted = _decision_bool(decision.get("decision"))
            confidence = float(decision.get("confidence", 0.0))
            if not accepted or confidence < 0.5:
                continue

            edge_id = f"EDGE_{left_id}_{right_id}"
            if edge_id in existing_edges:
                continue

            relation_type = _decision_value(
                decision,
                "relation_type",
                "relationship_type",
                default="trade_partner_candidate",
            )
            rationale = str(
                decision.get(
                    "rationale",
                    _decision_text(decision.get("decision")),
                )
            )
            evidence_ids = []
            for node in (left, right):
                evidence_item = evidence_by_name.get(str(node.get("name", "")))
                if evidence_item and evidence_item.get("evidence_id"):
                    evidence_ids.append(str(evidence_item["evidence_id"]))

            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": left_id,
                    "target_entity_id": right_id,
                    "relation_type": str(relation_type),
                    "confidence": confidence,
                    "evidence_ids": evidence_ids,
                    "rationale": rationale,
                    "source_node_id": left_node_id,
                    "target_node_id": right_node_id,
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result


def EVIDENCE_VERIFY(state: TaskState) -> TaskState:
    """Use the DecisionLayer to verify every evidence item in the shared pool."""
    result = deepcopy(state)
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_layer(result)

    for evidence in evidence_pool:
        prompt = (
            "Verify whether this evidence is internally coherent and sufficiently supports "
            "the stated trade entity. Return a boolean verification judgment, a confidence "
            "score, a concise verification reason, and any material issues."
        )
        decision = ai.decide(
            result,
            DECISION_EVIDENCE_VERIFICATION,
            prompt,
            {
                "evidence": evidence,
                "trade_nodes": result.get("trade_nodes", []),
            },
        )
        verified = _decision_value(
            decision,
            "verified",
            default=_decision_bool(decision.get("decision")),
        )
        if isinstance(verified, str):
            verified = verified.strip().lower() in {"true", "yes", "verified"}

        issues = _decision_value(
            decision,
            "issues",
            default=decision.get("metadata", {}).get("issues", [])
            if isinstance(decision.get("metadata"), Mapping)
            else [],
        )
        if isinstance(issues, str):
            issues = [issues]
        elif not isinstance(issues, list):
            issues = [str(issues)] if issues else []

        reason = _decision_value(
            decision,
            "verification_reason",
            default=decision.get("rationale", ""),
        )
        evidence["verified"] = bool(verified)
        evidence["verification_confidence"] = float(decision.get("confidence", 0.0))
        evidence["verification_reason"] = str(reason or "")
        evidence["issues"] = issues

    result["evidence_pool"] = evidence_pool
    return result


def ENTITY_RESOLUTION(state: TaskState) -> TaskState:
    """Resolve similar trade nodes into canonical entities using AI judgment."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_layer(result)

    parent: dict[str, str] = {}
    node_records: dict[str, dict[str, Any]] = {}

    for index, node in enumerate(nodes):
        node_id = str(node.get("node_id") or f"SYNTHETIC_NODE_{index + 1:03d}")
        node_records[node_id] = node
        parent[node_id] = node_id

    def find(node_id: str) -> str:
        current = node_id
        while parent[current] != current:
            parent[current] = parent[parent[current]]
            current = parent[current]
        return current

    def merge(first: str, second: str) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parent[second_root] = first_root

    candidates: list[tuple[str, str]] = []
    resolution_overrides: dict[str, dict[str, Any]] = {}
    for left_index, left in enumerate(nodes):
        left_name = _normalize_name(left.get("name"))
        for right in nodes[left_index + 1 :]:
            right_name = _normalize_name(right.get("name"))
            if not left_name or not right_name:
                continue
            similarity = SequenceMatcher(None, left_name, right_name).ratio()
            same_country = str(left.get("country", "")).lower() == str(right.get("country", "")).lower()
            same_role = str(left.get("role", "")).lower() == str(right.get("role", "")).lower()
            if similarity >= 0.65 or (same_country and same_role and similarity >= 0.45):
                candidates.append((str(left.get("node_id")), str(right.get("node_id"))))

    for left_id, right_id in candidates:
        left = node_records[left_id]
        right = node_records[right_id]
        decision = ai.decide(
            result,
            DECISION_ENTITY_RESOLUTION,
            (
                "Determine whether the two supplied trade records represent the same "
                "underlying entity. If they are duplicates, provide a canonical name. "
                "Use name similarity, role, country, and evidence context."
            ),
            {
                "left": left,
                "right": right,
                "evidence_pool": evidence_pool,
            },
        )
        should_merge = _decision_value(
            decision,
            "merge",
            default=_decision_bool(decision.get("decision")),
        )
        if isinstance(should_merge, str):
            should_merge = should_merge.strip().lower() in {"true", "yes", "merge"}
        if bool(should_merge) and float(decision.get("confidence", 0.0)) >= 0.5:
            merge(left_id, right_id)
            canonical_name = _decision_value(decision, "canonical_name", default="")
            if canonical_name:
                resolution_overrides[find(left_id)] = {
                    "canonical_name": str(canonical_name).strip(),
                    "confidence": float(decision.get("confidence", 0.0)),
                    "rationale": str(decision.get("rationale", "")),
                }

    groups: dict[str, list[dict[str, Any]]] = {}
    for node_id, node in node_records.items():
        groups.setdefault(find(node_id), []).append(node)

    entities: list[dict[str, Any]] = []
    for index, group in enumerate(groups.values(), start=1):
        canonical = max(
            group,
            key=lambda item: int(item.get("shipments", 0) or 0),
        )
        merged_from = [str(item.get("node_id")) for item in group]
        confidence = 1.0 if len(group) == 1 else 0.75
        root_id = find(str(group[0].get("node_id")))
        override = resolution_overrides.get(root_id, {})
        canonical_name = str(override.get("canonical_name", "")).strip() or str(canonical.get("name", "")).strip()
        if override.get("confidence") is not None:
            confidence = float(override["confidence"])
        entity_id = f"ENTITY_{index:03d}"
        entities.append(
            {
                "entity_id": entity_id,
                "canonical_name": canonical_name,
                "role": canonical.get("role"),
                "country": canonical.get("country"),
                "source": canonical.get("source", "synthetic"),
                "metadata": {
                    "confidence": confidence,
                    "merged_from": merged_from,
                    "shipments": sum(int(item.get("shipments", 0) or 0) for item in group),
                    "resolution_rationale": str(override.get("rationale", "")),
                },
            }
        )

    node_to_entity: dict[str, str] = {}
    for entity in entities:
        for source_id in entity["metadata"]["merged_from"]:
            node_to_entity[source_id] = entity["entity_id"]

    for relationship in result.get("relationships", []):
        source_id = str(relationship.get("source_node_id", ""))
        target_id = str(relationship.get("target_node_id", ""))
        if source_id in node_to_entity:
            relationship["source_entity_id"] = node_to_entity[source_id]
        if target_id in node_to_entity:
            relationship["target_entity_id"] = node_to_entity[target_id]

    result["entities"] = entities
    return result


def GRAPH_EXPANSION(state: TaskState) -> TaskState:
    """Add deterministic expanded relationships from existing canonical entities."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    existing_edges = {str(item.get("edge_id")) for item in relationships}

    for left_index, left in enumerate(entities):
        for right in entities[left_index + 1 :]:
            if not left.get("entity_id") or not right.get("entity_id"):
                continue
            same_country = str(left.get("country", "")).strip().lower() == str(right.get("country", "")).strip().lower()
            same_role = str(left.get("role", "")).strip().lower() == str(right.get("role", "")).strip().lower()
            if not same_country and not same_role:
                continue
            source_id = str(left["entity_id"])
            target_id = str(right["entity_id"])
            edge_id = f"EXPANDED_{source_id}_{target_id}"
            if edge_id in existing_edges:
                continue
            relation_type = "same_country_partner" if same_country else "same_role_network"
            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": source_id,
                    "target_entity_id": target_id,
                    "relation_type": relation_type,
                    "confidence": 0.55,
                    "evidence_ids": [],
                    "rationale": "Deterministic graph expansion from shared entity attributes.",
                    "metadata": {"expansion": "expanded"},
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result


def RESOURCE_CLASSIFICATION(state: TaskState) -> TaskState:
    """Classify every canonical entity with the DecisionLayer."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_layer(result)

    for entity in entities:
        decision = ai.decide(
            result,
            DECISION_RESOURCE_CLASSIFICATION,
            (
                "Classify this trade entity by commercial resource value. Return a resource "
                "class, a priority value, confidence, and rationale. Consider role, country, "
                "relationship count, shipments, and verified evidence."
            ),
            {
                "entity": entity,
                "relationships": relationships,
                "evidence_pool": evidence_pool,
            },
        )
        resource_class = _decision_value(
            decision,
            "resource_class",
            "class",
            default="unclassified_resource",
        )
        priority = _decision_value(
            decision,
            "priority",
            default=decision.get("metadata", {}).get("priority", 3)
            if isinstance(decision.get("metadata"), Mapping)
            else 3,
        )
        entity.setdefault("metadata", {})
        entity["metadata"]["resource_class"] = str(resource_class)
        entity["metadata"]["priority"] = priority
        entity["metadata"]["classification_confidence"] = float(decision.get("confidence", 0.0))
        entity["metadata"]["classification_rationale"] = str(decision.get("rationale", ""))

    result["entities"] = entities
    return result


def DATABASE_COMMIT(state: TaskState) -> TaskState:
    """Commit finalized entities, relationships, and evidence through Database."""
    result = deepcopy(state)
    orchestration = result.get("orchestration", {})
    database = orchestration.get("database") if isinstance(orchestration, Mapping) else None
    if database is None or not callable(getattr(database, "commit_trade_data", None)):
        raise RuntimeError(
            "DATABASE_COMMIT requires an injected database gateway at "
            "ContextVar provider binding"
        )

    task_id = str(result.get("task_id", "")).strip()
    if not task_id:
        raise ValueError("DATABASE_COMMIT requires state['task_id']")

    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    evidence_pool = list(result.get("evidence_pool", []))

    counts = database.commit_trade_data(
        task_id=task_id,
        trade_entities=entities,
        trade_edges=relationships,
        evidence=evidence_pool,
    )

    reports = dict(result.get("node_reports", {}))
    reports["DATABASE_COMMIT"] = {
        "status": REPORT_STATUS_COMMITTED,
        "entity_count": counts.get("trade_entities", len(entities)),
        "relationship_count": counts.get("trade_edges", len(relationships)),
        "evidence_count": counts.get("evidence", len(evidence_pool)),
    }
    result["node_reports"] = reports
    return result


NODE_FUNCTIONS = {
    "PRODUCT_DEFINITION": PRODUCT_DEFINITION,
    "TRADE_STRATEGY": TRADE_STRATEGY,
    "CUSTOMS_NODE_COLLECTION": CUSTOMS_NODE_COLLECTION,
    "TRADE_EDGE_BUILD": TRADE_EDGE_BUILD,
    "EVIDENCE_VERIFY": EVIDENCE_VERIFY,
    "ENTITY_RESOLUTION": ENTITY_RESOLUTION,
    "GRAPH_EXPANSION": GRAPH_EXPANSION,
    "RESOURCE_CLASSIFICATION": RESOURCE_CLASSIFICATION,
    "DATABASE_COMMIT": DATABASE_COMMIT,
}


def get_node_function(node_id: str):
    """Return a registered business node callable."""
    try:
        return NODE_FUNCTIONS[node_id]
    except KeyError as exc:
        raise KeyError(f"Unknown business node: {node_id}") from exc
```

## `business/workflows/trade_collection/spec.py`

```python
"""Declarative trade collection workflow specification."""

from __future__ import annotations
from core.orchestration.contracts import ContractDefinition, NodeContract

WORKFLOW_ID = "trade_collection"
WORKFLOW_VERSION = "9.4.0"
NODE_IDS = ("PRODUCT_DEFINITION","TRADE_STRATEGY","CUSTOMS_NODE_COLLECTION","TRADE_EDGE_BUILD","EVIDENCE_VERIFY","ENTITY_RESOLUTION","GRAPH_EXPANSION","RESOURCE_CLASSIFICATION","DATABASE_COMMIT")
NODE_SPECS = {
    "PRODUCT_DEFINITION": {"node_id":"PRODUCT_DEFINITION","responsibility":"Define the target trade product.","capabilities":("product_definition",)},
    "TRADE_STRATEGY": {"node_id":"TRADE_STRATEGY","responsibility":"Build trade analysis strategy fragments.","capabilities":("trade_strategy",)},
    "CUSTOMS_NODE_COLLECTION": {"node_id":"CUSTOMS_NODE_COLLECTION","responsibility":"Collect customs and trade nodes.","capabilities":("customs_collection",)},
    "TRADE_EDGE_BUILD": {"node_id":"TRADE_EDGE_BUILD","responsibility":"Build candidate trade relationships.","capabilities":("relationship_building","ai_assisted",)},
    "EVIDENCE_VERIFY": {"node_id":"EVIDENCE_VERIFY","responsibility":"Verify business evidence.","capabilities":("evidence_verification","ai_assisted",)},
    "ENTITY_RESOLUTION": {"node_id":"ENTITY_RESOLUTION","responsibility":"Resolve canonical trade entities.","capabilities":("entity_resolution","ai_assisted",)},
    "GRAPH_EXPANSION": {"node_id":"GRAPH_EXPANSION","responsibility":"Expand the trade graph.","capabilities":("graph_expansion",)},
    "RESOURCE_CLASSIFICATION": {"node_id":"RESOURCE_CLASSIFICATION","responsibility":"Classify trade resources.","capabilities":("resource_classification","ai_assisted",)},
    "DATABASE_COMMIT": {"node_id":"DATABASE_COMMIT","responsibility":"Persist finalized trade data.","capabilities":("database_commit",)},
}
CONTRACTS = (
    ContractDefinition("PRODUCT_DEFINITION",("mission",),("product_definition",),"Define the target trade product.","product_definition is available.","Product definition cannot be established."),
    ContractDefinition("TRADE_STRATEGY",("mission","product_definition"),("fragments",),"Form trade analysis strategy fragments.","Strategy fragments are available.","Trade strategy cannot be formed."),
    ContractDefinition("CUSTOMS_NODE_COLLECTION",("product_definition","fragments"),("trade_nodes","fragments","evidence_pool"),"Collect trade nodes and initial evidence.","Trade nodes and evidence are available.","Trade node collection cannot complete."),
    ContractDefinition("TRADE_EDGE_BUILD",("trade_nodes","evidence_pool"),("relationships","decisions"),"Build candidate trade relationships.","Candidate relationships are available.","Trade relationships cannot be built."),
    ContractDefinition("EVIDENCE_VERIFY",("evidence_pool","trade_nodes"),("evidence_pool","decisions"),"Verify evidence against trade nodes.","Evidence verification results are available.","Evidence verification cannot complete."),
    ContractDefinition("ENTITY_RESOLUTION",("trade_nodes","evidence_pool"),("entities","decisions"),"Resolve canonical entities.","Resolved entities are available.","Entity resolution cannot complete."),
    ContractDefinition("GRAPH_EXPANSION",("entities","relationships","evidence_pool"),("relationships",),"Expand the trade graph.","Expanded graph data is available.","Graph expansion cannot complete."),
    ContractDefinition("RESOURCE_CLASSIFICATION",("relationships","evidence_pool","decisions"),("decisions",),"Classify trade resources.","Classification decisions are available.","Resource classification cannot complete."),
    ContractDefinition("DATABASE_COMMIT",("entities","relationships","evidence_pool"),("node_reports",),"Persist finalized trade data.","Final trade data is committed.","Final trade data cannot be committed.",True,("business_database_write",),True),
)
PAYLOAD_KEYS = {
    "mission": ("mission",), "product_definition": ("product_definition",), "trade_strategy": ("fragments",),
    "customs_collection": ("trade_nodes","fragments","evidence_pool"), "trade_edge_build": ("relationships","decisions"),
    "evidence_verify": ("evidence_pool","decisions"), "entity_resolution": ("entities","decisions"),
    "graph_expansion": ("relationships",), "resource_classification": ("decisions",), "database_commit": ("node_reports",),
}
CAPABILITIES = ("product_definition","trade_strategy","customs_collection","relationship_building","evidence_verification","entity_resolution","graph_expansion","resource_classification","database_commit","ai_assisted")
```

## `core/__init__.py`

```python
"""PSV Trade OS core package."""

__version__ = "9.4.0"
```

## `core/config/__init__.py`

```python
"""PSV Trade OS configuration package."""

from .settings import Settings, settings

__all__ = ["Settings", "settings"]
```

## `core/config/industry.py`

```python
"""Industry configuration loader for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
from typing import Any

from core.config.settings import ROOT


def load_industry(name: str | None) -> dict[str, Any]:
    """Load a named industry profile, falling back to the bundled candle profile."""
    safe = str(name or "candle").strip().lower()
    path = ROOT / "data" / "industry_configs" / f"{safe}.json"
    if not path.exists():
        path = ROOT / "data" / "industry_configs" / "candle.json"
    if not path.exists():
        return {"name": safe, "keywords": [], "hs_codes": [], "product_terms": [], "icp_reject": []}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Industry profile must be an object: {path}")
    return payload
```

## `core/config/markets.py`

```python
"""Market configuration loader for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
from typing import Any

from core.config.settings import ROOT


def markets() -> list[dict[str, Any]]:
    """Load normalized market definitions from data/markets.json."""
    path = ROOT / "data" / "markets.json"
    if not path.exists():
        return []
    payload = json.loads(path.read_text(encoding="utf-8"))
    values = payload.get("markets", []) if isinstance(payload, dict) else payload
    return [item for item in values if isinstance(item, dict)] if isinstance(values, list) else []
```

## `core/config/settings.py`

```python
"""Central runtime configuration for PSV Trade OS 9.4.0."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - dependency gate reports missing package
    load_dotenv = None

APP_VERSION = "9.4.0"
ROOT = Path(__file__).resolve().parents[2]

if load_dotenv is not None:
    load_dotenv(ROOT / ".env", override=False)


def _read_int(name: str, default: int) -> int:
    value = os.getenv(name, str(default)).strip()
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc


@dataclass(frozen=True)
class Settings:
    """Immutable application configuration."""

    app_version: str = APP_VERSION
    web_host: str = os.getenv("WEB_HOST", "127.0.0.1")
    web_port: int = _read_int("WEB_PORT", 8090)
    llm_base_url: str = os.getenv("LLM_BASE_URL", "http://192.168.1.26:8081/v1")
    llm_api_key: str = os.getenv("LLM_API_KEY", "")
    llm_model: str = os.getenv("LLM_MODEL", "deepseek-r1-distill-llama-70b")
    database_path: Path = Path(os.getenv("DATABASE_PATH", "data/psv.db"))
    checkpoint_path: Path = Path(os.getenv("CHECKPOINT_PATH", "data/checkpoints.db"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    max_task_seconds: int = _read_int("MAX_TASK_SECONDS", 1800)
    max_steps: int = _read_int("MAX_STEPS", 40)
    max_retries: int = _read_int("MAX_RETRIES", 2)
    no_progress_limit: int = _read_int("NO_PROGRESS_LIMIT", 3)

    def ensure_directories(self) -> None:
        """Create runtime parent directories when they do not exist."""
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)

    @property
    def database_path_string(self) -> str:
        return str(self.database_path)

    @property
    def checkpoint_path_string(self) -> str:
        return str(self.checkpoint_path)


settings = Settings()
```

## `core/memory/__init__.py`

```python
"""PSV Trade OS persistence package."""

from .db import Database

__all__ = ["Database"]
```

## `core/memory/db.py`

```python
"""SQLite persistence for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


class Database:
    """SQLite database gateway for task and trade persistence."""

    def __init__(self, database_path: str | Path) -> None:
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)

    def initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id TEXT PRIMARY KEY, workflow_id TEXT NOT NULL, status TEXT NOT NULL,
                state_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS task_events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL,
                event_type TEXT NOT NULL, node_id TEXT, status TEXT, payload TEXT,
                created_at TEXT NOT NULL, FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_task_events_task_id ON task_events(task_id);
            CREATE TABLE IF NOT EXISTS trade_entities (
                entity_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, canonical_name TEXT NOT NULL,
                role TEXT, country TEXT, source TEXT, metadata TEXT,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_trade_entities_task_id ON trade_entities(task_id);
            CREATE TABLE IF NOT EXISTS trade_edges (
                edge_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, source_entity_id TEXT NOT NULL,
                target_entity_id TEXT NOT NULL, relation_type TEXT NOT NULL, confidence REAL,
                evidence_ids TEXT, metadata TEXT,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_trade_edges_task_id ON trade_edges(task_id);
            CREATE TABLE IF NOT EXISTS evidence (
                evidence_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, entity_name TEXT NOT NULL,
                evidence_type TEXT, source TEXT, shipments TEXT, verified INTEGER NOT NULL DEFAULT 0,
                evidence_json TEXT, created_at TEXT NOT NULL,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_evidence_task_id ON evidence(task_id);
            """)

    def create_task(self, task_id: str, workflow_id: str, state: Mapping[str, Any], status: str) -> dict[str, Any]:
        timestamp = self._now()
        with self._connect() as connection:
            connection.execute("""INSERT INTO tasks(task_id,workflow_id,status,state_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?)""", (task_id, workflow_id, status, self._json(dict(state)), timestamp, timestamp))
        return self.get_task(task_id)

    def update_task(self, task_id: str, state: Mapping[str, Any], status: str) -> dict[str, Any]:
        with self._connect() as connection:
            cursor = connection.execute("""UPDATE tasks SET status=?,state_json=?,updated_at=? WHERE task_id=?""",
                (status, self._json(dict(state)), self._now(), task_id))
            if cursor.rowcount == 0:
                raise KeyError(f"Task not found: {task_id}")
        return self.get_task(task_id)

    def get_tasks_by_status(self, statuses: tuple[str, ...]) -> list[dict[str, Any]]:
        """Return persisted tasks whose lifecycle status requires scheduler recovery."""
        normalized = tuple(str(status).strip() for status in statuses if str(status).strip())
        if not normalized:
            return []
        bindings = ",".join("?" for _ in normalized)
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT task_id,workflow_id,status,state_json,created_at,updated_at "
                f"FROM tasks WHERE status IN ({bindings}) ORDER BY created_at ASC",
                normalized,
            ).fetchall()
        tasks: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["state"] = json.loads(item.pop("state_json"))
            tasks.append(item)
        return tasks

    def get_task(self, task_id: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute("""SELECT task_id,workflow_id,status,state_json,created_at,updated_at
                FROM tasks WHERE task_id=?""", (task_id,)).fetchone()
        if row is None:
            raise KeyError(f"Task not found: {task_id}")
        result = dict(row)
        result["state"] = json.loads(result.pop("state_json"))
        return result

    def add_event(self, task_id: str, event_type: str, node_id: str | None = None,
                  status: str | None = None, payload: Mapping[str, Any] | None = None) -> int:
        with self._connect() as connection:
            exists = connection.execute("SELECT 1 FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            cursor = connection.execute("""INSERT INTO task_events(task_id,event_type,node_id,status,payload,created_at)
                VALUES(?,?,?,?,?,?)""", (task_id, event_type, node_id, status, self._json(payload or {}), self._now()))
            return int(cursor.lastrowid)

    def get_task_events(self, task_id: str) -> list[dict[str, Any]]:
        """Return all persisted events for a task in chronological order."""
        with self._connect() as connection:
            exists = connection.execute(
                "SELECT 1 FROM tasks WHERE task_id=?", (task_id,)
            ).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            rows = connection.execute(
                """SELECT event_id,event_type,node_id,status,payload,created_at
                   FROM task_events
                   WHERE task_id=?
                   ORDER BY created_at ASC, event_id ASC""",
                (task_id,),
            ).fetchall()
        events: list[dict[str, Any]] = []
        for row in rows:
            event = dict(row)
            raw_payload = event.get("payload")
            if isinstance(raw_payload, str):
                try:
                    event["payload"] = json.loads(raw_payload)
                except json.JSONDecodeError:
                    event["payload"] = {"raw": raw_payload}
            elif raw_payload is None:
                event["payload"] = {}
            events.append(event)
        return events

    def commit_trade_data(self, task_id: str, trade_entities: list[Mapping[str, Any]],
                          trade_edges: list[Mapping[str, Any]], evidence: list[Mapping[str, Any]]) -> dict[str, int]:
        timestamp = self._now()
        with self._connect() as connection:
            exists = connection.execute("SELECT 1 FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            for entity in trade_entities:
                connection.execute("""INSERT OR REPLACE INTO trade_entities
                    (entity_id,task_id,canonical_name,role,country,source,metadata) VALUES(?,?,?,?,?,?,?)""",
                    (str(entity["entity_id"]), task_id, str(entity["canonical_name"]), entity.get("role"),
                     entity.get("country"), entity.get("source"), self._json(entity.get("metadata", {}))))
            for edge in trade_edges:
                connection.execute("""INSERT OR REPLACE INTO trade_edges
                    (edge_id,task_id,source_entity_id,target_entity_id,relation_type,confidence,evidence_ids,metadata)
                    VALUES(?,?,?,?,?,?,?,?)""", (str(edge["edge_id"]), task_id, str(edge["source_entity_id"]),
                    str(edge["target_entity_id"]), str(edge["relation_type"]), edge.get("confidence"),
                    self._json(edge.get("evidence_ids", [])), self._json(edge.get("metadata", {}))))
            for item in evidence:
                connection.execute("""INSERT OR REPLACE INTO evidence
                    (evidence_id,task_id,entity_name,evidence_type,source,shipments,verified,evidence_json,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?)""", (str(item["evidence_id"]), task_id, str(item["entity_name"]),
                    item.get("evidence_type"), item.get("source"), self._json(item.get("shipments", [])),
                    1 if bool(item.get("verified", False)) else 0, self._json(item.get("evidence_json", {})),
                    item.get("created_at", timestamp)))
        return {"trade_entities": len(trade_entities), "trade_edges": len(trade_edges), "evidence": len(evidence)}
```

## `core/model/__init__.py`

```python
"""AI reasoning layer for PSV Trade OS 9.4.0."""

from .reasoning import (
    EXPECTED_REASONING_MODEL,
    ReasoningEngine,
    ReasoningEngineError,
    ReasoningResponseError,
)

__all__ = [
    "EXPECTED_REASONING_MODEL",
    "ReasoningEngine",
    "ReasoningEngineError",
    "ReasoningResponseError",
]
```

## `core/model/reasoning.py`

```python
"""OpenAI-compatible reasoning engine for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import logging
from typing import Any

try:
    from openai import OpenAI
except ImportError as exc:
    OpenAI = None  # type: ignore[assignment]
    _OPENAI_IMPORT_ERROR = exc
else:
    _OPENAI_IMPORT_ERROR = None

from core.config.settings import Settings, settings

LOGGER = logging.getLogger(__name__)
EXPECTED_REASONING_MODEL = "deepseek-r1-distill-llama-70b"


class ReasoningEngineError(RuntimeError):
    """Base error for reasoning-engine failures."""


class ReasoningResponseError(ReasoningEngineError):
    """Raised when the model response cannot be parsed as JSON."""


class ReasoningEngine:
    """Call the configured OpenAI-compatible reasoning endpoint."""

    def __init__(self, runtime_settings: Settings = settings) -> None:
        self.settings = runtime_settings
        configured_model = (self.settings.llm_model or "").strip()
        if configured_model != EXPECTED_REASONING_MODEL:
            message = (
                "Unsupported reasoning model: "
                f"{configured_model!r}. PSV Trade OS 9.4.0 requires "
                f"{EXPECTED_REASONING_MODEL!r}."
            )
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        base_url = (self.settings.llm_base_url or "").strip()
        if not base_url:
            message = "LLM_BASE_URL must not be empty"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        api_key = (self.settings.llm_api_key or "").strip()
        if not api_key:
            LOGGER.warning(
                "LLM_API_KEY is empty; using a local-compatible runtime credential"
            )
            api_key = "local-runtime"

        if OpenAI is None:
            message = (
                "The installed openai package does not provide the OpenAI client. "
                "PSV Trade OS 9.4.0 requires openai>=1.50,<2.0. "
                "Run `python -m pip install -r requirements.txt` in a fresh virtual environment."
            )
            if _OPENAI_IMPORT_ERROR is not None:
                message += f" Import detail: {_OPENAI_IMPORT_ERROR}"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        try:
            self._client = OpenAI(api_key=api_key, base_url=base_url)
        except Exception as exc:
            LOGGER.exception("Failed to initialize OpenAI-compatible reasoning client")
            raise ReasoningEngineError(
                f"Failed to initialize reasoning client: {exc}"
            ) from exc

    def review(
        self,
        prompt: str,
        system: str = "",
        response_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a reasoning request and return its JSON response."""
        normalized_prompt = prompt.strip() if isinstance(prompt, str) else ""
        normalized_system = system.strip() if isinstance(system, str) else ""
        if not normalized_prompt:
            message = "Reasoning prompt must not be empty"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        messages: list[dict[str, str]] = []
        if normalized_system:
            messages.append({"role": "system", "content": normalized_system})
        messages.append({"role": "user", "content": normalized_prompt})

        try:
            request_kwargs: dict[str, Any] = {
                "model": EXPECTED_REASONING_MODEL,
                "messages": messages,
                "temperature": 0.0,
                "response_format": {"type": "json_object"},
            }
            if response_schema is not None:
                request_kwargs["response_format"] = {
                    "type": "json_object",
                    "schema": response_schema,
                }
            response = self._client.chat.completions.create(**request_kwargs)
        except Exception as exc:
            LOGGER.exception("Reasoning API request failed")
            raise ReasoningEngineError(
                f"Reasoning API request failed: {exc}"
            ) from exc

        try:
            content = response.choices[0].message.content
        except (AttributeError, IndexError, TypeError) as exc:
            LOGGER.exception("Reasoning API returned an invalid response structure")
            raise ReasoningResponseError(
                f"Invalid reasoning response structure: {exc}"
            ) from exc

        if not isinstance(content, str):
            message = "Reasoning API returned non-text content"
            LOGGER.error(message)
            raise ReasoningResponseError(message)

        normalized_content = self._normalize_json_content(content)
        try:
            parsed = json.loads(normalized_content)
        except json.JSONDecodeError as exc:
            LOGGER.error("Reasoning model returned non-JSON content: %s", content)
            raise ReasoningResponseError(
                "Reasoning model response is not valid JSON"
            ) from exc

        if not isinstance(parsed, dict):
            message = "Reasoning model JSON response must be an object"
            LOGGER.error("%s: %r", message, parsed)
            raise ReasoningResponseError(message)
        return parsed

    @staticmethod
    def _normalize_json_content(content: str) -> str:
        """Normalize common JSON code-fence formatting."""
        normalized = content.strip()
        if normalized.startswith("```json") and normalized.endswith("```"):
            normalized = normalized[len("```json") :].strip()
            normalized = normalized[:-len("```")].strip()
        elif normalized.startswith("```") and normalized.endswith("```"):
            normalized = normalized[len("```") :].strip()
            normalized = normalized[:-len("```")].strip()
        return normalized
```

## `core/orchestration/__init__.py`

```python
"""PSV Trade OS orchestration foundation package."""

from .conditions import ConditionEdgeEngine, RouteOutcome
from .contracts import ContractDefinition, ContractRegistry, NodeContract
from .decision import (
    DECISION_MISSION_UNDERSTANDING, DECISION_EVIDENCE_VERIFICATION,
    DECISION_ENTITY_RESOLUTION, DECISION_RELATIONSHIP_JUDGMENT,
    DECISION_RESOURCE_CLASSIFICATION,
    DecisionLayer, DecisionLayerError, SUPPORTED_DECISION_TYPES,
)
from .engine import WorkflowEngine
from .long_task import LongTaskManager
from .mission import MissionDirector
from .plan import ExecutionPlan, OrchestrationPlanGenerator
from .policies import Policy
from .recovery import RecoveryManager
from .registry import RegisteredWorkflow, WorkflowDiscoveryError, WorkflowRegistry
from .scheduler import WorkflowScheduler
from .state import (
    STATUS_COMPLETED, STATUS_FAILED, STATUS_PAUSED, STATUS_PENDING,
    STATUS_RUNNING, STATUS_TIMEOUT, STATUS_VALUES, TaskState,
)
from .task_understanding import MISSION_FIELDS, TaskUnderstanding, TaskUnderstandingError

__all__ = [
    "ConditionEdgeEngine", "ContractDefinition", "ContractRegistry",
    "DECISION_MISSION_UNDERSTANDING", "DECISION_EVIDENCE_VERIFICATION",
    "DECISION_ENTITY_RESOLUTION",
    "DECISION_RELATIONSHIP_JUDGMENT", "DECISION_RESOURCE_CLASSIFICATION",
    "DecisionLayer", "DecisionLayerError", "ExecutionPlan", "LongTaskManager",
    "MISSION_FIELDS", "MissionDirector", "NodeContract", "OrchestrationPlanGenerator",
    "Policy", "RecoveryManager", "RegisteredWorkflow", "RouteOutcome",
    "SUPPORTED_DECISION_TYPES", "TaskState", "TaskUnderstanding", "TaskUnderstandingError",
    "WorkflowDiscoveryError", "WorkflowEngine", "WorkflowRegistry", "WorkflowScheduler",
    "STATUS_PENDING", "STATUS_RUNNING", "STATUS_COMPLETED", "STATUS_FAILED",
    "STATUS_PAUSED", "STATUS_TIMEOUT", "STATUS_VALUES",
]
```

## `core/orchestration/conditions.py`

```python
"""Condition Edge Engine: the sole formal workflow router."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .plan import ExecutionPlan
from .state import (
    STATUS_COMPLETED, STATUS_FAILED, STATUS_PAUSED, STATUS_RUNNING, STATUS_TIMEOUT,
    TaskState,
)


@dataclass(frozen=True)
class RouteOutcome:
    """Result of evaluating one routing decision."""

    target: str | None
    reason: str
    outcome: dict[str, Any] = field(default_factory=dict)


class ConditionEdgeEngine:
    """Evaluate shared-state conditions and select the next graph node."""

    def choose(
        self,
        workflow: ExecutionPlan,
        state: Mapping[str, Any] | TaskState,
        current: str,
    ) -> RouteOutcome:
        """Choose the next node using current shared state and the initial order."""
        status = state.get("status")

        # The evidence gate is an orchestration-only condition. Business nodes
        # produce evidence state; this router alone decides whether the workflow
        # may proceed to entity resolution.
        if current == "EVIDENCE_VERIFY":
            evidence_pool = state.get("evidence_pool", [])
            verified = any(
                isinstance(item, Mapping) and item.get("verified") is True
                for item in evidence_pool
            ) if isinstance(evidence_pool, (list, tuple)) else False
            if verified:
                return RouteOutcome(
                    target="ENTITY_RESOLUTION",
                    reason="verified_evidence_gate",
                    outcome={
                        "success": True,
                        "status": STATUS_RUNNING,
                        "current": current,
                        "target": "ENTITY_RESOLUTION",
                        "verified_evidence": True,
                    },
                )
            failure = {
                "code": "VERIFIED_EVIDENCE_REQUIRED",
                "message": "EVIDENCE_VERIFY requires at least one evidence item with verified=True",
                "failure_type": "node_failure",
            }
            if isinstance(state, dict):
                state["status"] = STATUS_FAILED
                state["error"] = failure
            return RouteOutcome(
                target=None,
                reason="verified_evidence_gate_failed",
                outcome={"success": False, "status": STATUS_FAILED, "error": failure},
            )

        if status in {STATUS_FAILED, STATUS_TIMEOUT, STATUS_PAUSED}:
            return RouteOutcome(
                target=None,
                reason="terminal_task_status",
                outcome={"success": False, "status": status},
            )
        if status != STATUS_RUNNING:
            return RouteOutcome(
                target=None,
                reason="non_running_task_status",
                outcome={"success": False, "status": status},
            )
        try:
            current_index = workflow.order.index(current)
        except ValueError:
            return RouteOutcome(
                target=None,
                reason="current_node_not_in_plan",
                outcome={"success": False, "current": current},
            )

        if current_index + 1 >= len(workflow.order):
            return RouteOutcome(
                target=None,
                reason="workflow_completed",
                outcome={"success": True, "status": STATUS_COMPLETED},
            )

        target = workflow.order[current_index + 1]
        return RouteOutcome(
            target=target,
            reason="state_running_successor",
            outcome={
                "success": True,
                "status": STATUS_RUNNING,
                "current": current,
                "target": target,
            },
        )
```

## `core/orchestration/contracts.py`

```python
"""Contract registry and validation primitives for PSV Trade OS 9.4.0."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class ContractDefinition:
    """Formal data contract between a node and shared state."""
    node_id: str
    input_keys: tuple[str, ...] = ()
    output_keys: tuple[str, ...] = ()
    responsibility: str = ""
    success: str = ""
    failure: str = ""
    blocking: bool = True
    side_effects: tuple[str, ...] = ()
    database_write_authority: bool = False

    def __post_init__(self) -> None:
        if not self.node_id.strip():
            raise ValueError("node_id must not be empty")
        if not self.responsibility.strip():
            raise ValueError(f"responsibility is required for {self.node_id}")

    def validate_input(self, state: Mapping[str, Any]) -> None:
        missing = [key for key in self.input_keys if key not in state]
        if missing:
            raise ValueError(f"{self.node_id} missing input keys: {', '.join(missing)}")

    def validate_output(self, state: Mapping[str, Any]) -> None:
        missing = [key for key in self.output_keys if key not in state]
        if missing:
            raise ValueError(f"{self.node_id} missing output keys: {', '.join(missing)}")


NodeContract = ContractDefinition


@dataclass
class ContractRegistry:
    contracts: dict[str, ContractDefinition] = field(default_factory=dict)

    def register(self, contract: ContractDefinition) -> None:
        if contract.node_id in self.contracts:
            raise ValueError(f"Contract already registered: {contract.node_id}")
        self.contracts[contract.node_id] = contract

    def register_many(self, contracts: Iterable[ContractDefinition]) -> None:
        pending = list(contracts)
        node_ids = [contract.node_id for contract in pending]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("Duplicate node_id found in contract collection")
        duplicates = [node_id for node_id in node_ids if node_id in self.contracts]
        if duplicates:
            raise ValueError(f"Contracts already registered: {', '.join(duplicates)}")
        for contract in pending:
            self.contracts[contract.node_id] = contract

    def get(self, node_id: str) -> ContractDefinition:
        try:
            return self.contracts[node_id]
        except KeyError as exc:
            raise KeyError(f"Contract not registered: {node_id}") from exc

    def validate(self, node_id: str, state: Mapping[str, Any], *, phase: str) -> bool:
        contract = self.get(node_id)
        normalized_phase = phase.strip().lower()
        if normalized_phase == "input":
            contract.validate_input(state)
        elif normalized_phase == "output":
            contract.validate_output(state)
        else:
            raise ValueError("phase must be either 'input' or 'output'")
        return True

    def validate_input(self, node_id: str, state: Mapping[str, Any]) -> bool:
        return self.validate(node_id, state, phase="input")

    def validate_output(self, node_id: str, state: Mapping[str, Any]) -> bool:
        return self.validate(node_id, state, phase="output")
```

## `core/orchestration/decision.py`

```python
"""AI Decision Layer for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
from typing import Any, Mapping, MutableMapping

from core.model.reasoning import ReasoningEngine, ReasoningEngineError
from core.orchestration.state import TaskState

LOGGER = logging.getLogger(__name__)
DECISION_MISSION_UNDERSTANDING = "mission_understanding"
DECISION_ENTITY_RESOLUTION = "entity_resolution"
DECISION_RELATIONSHIP_JUDGMENT = "relationship_judgment"
DECISION_EVIDENCE_VERIFICATION = "evidence_verification"
DECISION_RESOURCE_CLASSIFICATION = "resource_classification"
SUPPORTED_DECISION_TYPES = frozenset({
    DECISION_MISSION_UNDERSTANDING,
    DECISION_ENTITY_RESOLUTION,
    DECISION_RELATIONSHIP_JUDGMENT,
    DECISION_EVIDENCE_VERIFICATION,
    DECISION_RESOURCE_CLASSIFICATION,
})
REQUIRED_RESULT_FIELDS = ("decision", "confidence", "rationale", "metadata")


class DecisionLayerError(RuntimeError):
    """Raised when an AI decision cannot be produced safely."""


class DecisionLayer:
    """Central AI judgment layer without orchestration authority."""

    def __init__(self, reasoning_engine: ReasoningEngine | None = None) -> None:
        self.reasoning = reasoning_engine if reasoning_engine is not None else ReasoningEngine()

    def decide(
        self,
        state: MutableMapping[str, Any] | TaskState,
        decision_type: str,
        prompt: str,
        payload: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Perform an AI judgment through the single reasoning boundary."""
        normalized_type = decision_type.strip() if isinstance(decision_type, str) else ""
        if normalized_type not in SUPPORTED_DECISION_TYPES:
            message = (
                f"Unsupported decision_type: {decision_type!r}. Supported types: "
                + ", ".join(sorted(SUPPORTED_DECISION_TYPES))
            )
            LOGGER.error(message)
            raise DecisionLayerError(message)

        normalized_prompt = prompt.strip() if isinstance(prompt, str) else ""
        if not normalized_prompt:
            message = "Decision prompt must not be empty"
            LOGGER.error(message)
            raise DecisionLayerError(message)

        decision_payload = dict(payload) if payload is not None else {}
        try:
            review_kwargs: dict[str, Any] = {
                "prompt": self._build_prompt(normalized_type, normalized_prompt, decision_payload),
                "system": self._system_prompt(normalized_type),
            }
            response_schema = self._response_schema(normalized_type)
            if response_schema is not None:
                review_kwargs["response_schema"] = response_schema
            model_result = self.reasoning.review(**review_kwargs)
        except ReasoningEngineError as exc:
            LOGGER.exception("AI decision failed: type=%s", normalized_type)
            raise DecisionLayerError(f"AI decision failed for {normalized_type}: {exc}") from exc
        except Exception as exc:
            LOGGER.exception("Unexpected AI decision failure: type=%s", normalized_type)
            raise DecisionLayerError(f"Unexpected AI decision failure for {normalized_type}: {exc}") from exc

        LOGGER.debug("Structured model result received: %r", model_result)

        try:
            decision = self._validate_result(model_result)
        except (TypeError, ValueError) as exc:
            LOGGER.exception("Invalid structured AI decision: type=%s", normalized_type)
            raise DecisionLayerError(f"Invalid AI decision result for {normalized_type}: {exc}") from exc

        record = {
            "decision_type": normalized_type,
            "decision": decision["decision"],
            "confidence": decision["confidence"],
            "rationale": decision["rationale"],
            "metadata": decision["metadata"],
        }
        decisions = state.get("decisions")
        if decisions is None:
            decisions = []
            state["decisions"] = decisions
        if not isinstance(decisions, list):
            message = "state['decisions'] must be a list"
            LOGGER.error(message)
            raise DecisionLayerError(message)
        decisions.append(record)
        return decision

    def _system_prompt(self, decision_type: str) -> str:
        configured_model = str(
            getattr(getattr(self.reasoning, "settings", None), "llm_model", "")
        ).strip()
        model_name = configured_model or "deepseek-r1-distill-llama-70b"
        decision_value_rule = (
            "For mission_understanding, the `decision` value MUST itself be a JSON object "
            "containing the Mission fields requested by the caller. Do not stringify that object.\n"
            if decision_type == DECISION_MISSION_UNDERSTANDING
            else "The `decision` value must contain the semantic judgment requested by the caller.\n"
        )
        return (
            "You are the PSV Trade OS 9.4.0 AI Decision Layer.\n"
            f"Declared reasoning model: {model_name}\n"
            "Your responsibility is semantic judgment only.\n"
            f"Decision type: {decision_type}\n\n"
            "You must not decide workflow routing, retry behavior, timeout behavior, "
            "recovery strategy, scheduling, or database write boundaries.\n\n"
            "Return exactly one valid JSON object with these outer fields: "
            '`decision`, `confidence`, `rationale`, and `metadata`.\n'
            f"{decision_value_rule}"
            "For mission_understanding, do not place Mission fields directly beside the outer fields; "
            "nest them under `decision`.\n"
            "Do not return Markdown, a code fence, or explanatory prose outside the JSON object."
        )

    @staticmethod
    def _response_schema(decision_type: str) -> dict[str, Any] | None:
        """Return a server-side JSON Schema for decisions that have a frozen shape."""
        if decision_type != DECISION_MISSION_UNDERSTANDING:
            return None
        mission_schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "intent": {"type": "string"},
                "task_type": {"type": "string"},
                "objective": {"type": "string"},
                "targets": {"type": "array", "items": {"type": "string"}},
                "constraints": {"type": "array", "items": {"type": "string"}},
                "success_criteria": {"type": "array", "items": {"type": "string"}},
                "market": {"type": "string"},
                "industry": {"type": "string"},
            },
            "required": [
                "intent", "task_type", "objective", "targets",
                "constraints", "success_criteria", "market", "industry",
            ],
        }
        return {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "decision": mission_schema,
                "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                "rationale": {"type": "string"},
                "metadata": {"type": "object"},
            },
            "required": ["decision", "confidence", "rationale", "metadata"],
        }

    @staticmethod
    def _build_prompt(decision_type: str, prompt: str, payload: Mapping[str, Any]) -> str:
        return (
            f"Decision type: {decision_type}\n\n"
            f"Judgment instructions:\n{prompt}\n\n"
            f"Structured input payload:\n{dict(payload)}\n\n"
            "Return only the required JSON decision object."
        )

    @staticmethod
    def _validate_result(result: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(result, Mapping):
            raise TypeError("Decision result must be a mapping")
        missing = [field for field in REQUIRED_RESULT_FIELDS if field not in result]
        if missing:
            raise ValueError("Decision result is missing fields: " + ", ".join(missing))

        decision = result["decision"]
        confidence = result["confidence"]
        rationale = result["rationale"]
        metadata = result["metadata"]
        if not isinstance(decision, (str, dict, list, bool, int, float, type(None))):
            raise ValueError("decision must be JSON-compatible")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
            raise ValueError("confidence must be numeric")
        if not 0.0 <= float(confidence) <= 1.0:
            raise ValueError("confidence must be between 0.0 and 1.0")
        if not isinstance(rationale, str):
            raise ValueError("rationale must be a string")
        if not isinstance(metadata, Mapping):
            raise ValueError("metadata must be a mapping")
        return {
            "decision": decision,
            "confidence": float(confidence),
            "rationale": rationale,
            "metadata": dict(metadata),
        }
```

## `core/orchestration/engine.py`

```python
"""LangGraph workflow execution engine for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
import multiprocessing as mp
import queue
import types
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

from core.config.settings import Settings
from core.memory.db import Database

from .conditions import ConditionEdgeEngine
from .contracts import ContractRegistry
from .decision import DecisionLayer
from .plan import ExecutionPlan, OrchestrationPlanGenerator
from .policies import DEFAULT_POLICY, Policy
from .recovery import RecoveryManager
from .registry import RegisteredWorkflow, WorkflowRegistry
from .state import (
    STATUS_COMPLETED, STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING, STATUS_TIMEOUT,
    TaskState,
)

LOGGER = logging.getLogger(__name__)


class _CheckpointAuditBridge:
    """Attach audit events to a real SqliteSaver without replacing the checkpointer."""

    @staticmethod
    def attach(checkpointer: SqliteSaver, database: Database, task_id: str, resume: bool) -> None:
        original_put = checkpointer.put
        original_get_tuple = checkpointer.get_tuple

        def audited_put(*args: Any, **kwargs: Any) -> Any:
            result = original_put(*args, **kwargs)
            configurable = result.get("configurable", {}) if isinstance(result, Mapping) else {}
            database.add_event(
                task_id,
                "CHECKPOINT",
                status=STATUS_RUNNING,
                payload={
                    "action": "created",
                    "thread_id": configurable.get("thread_id", task_id),
                    "checkpoint_id": configurable.get("checkpoint_id"),
                },
            )
            return result

        def audited_get_tuple(*args: Any, **kwargs: Any) -> Any:
            result = original_get_tuple(*args, **kwargs)
            if resume and result is not None:
                result_config = getattr(result, "config", {})
                configurable = result_config.get("configurable", {}) if isinstance(result_config, Mapping) else {}
                database.add_event(
                    task_id,
                    "CHECKPOINT",
                    status=STATUS_RUNNING,
                    payload={
                        "action": "restored",
                        "thread_id": configurable.get("thread_id", task_id),
                        "checkpoint_id": configurable.get("checkpoint_id"),
                    },
                )
            return result

        checkpointer.put = types.MethodType(lambda _self, *args, **kwargs: audited_put(*args, **kwargs), checkpointer)
        checkpointer.get_tuple = types.MethodType(
            lambda _self, *args, **kwargs: audited_get_tuple(*args, **kwargs), checkpointer
        )


def _execute_graph_process(
    result_queue: Any,
    state: dict[str, Any],
    workflow_id: str,
    resume: bool,
    settings_values: dict[str, Any],
) -> None:
    """Execute one graph invocation in a dedicated process for hard timeout control."""
    try:
        settings = Settings(
            app_version=str(settings_values["app_version"]),
            web_host=str(settings_values["web_host"]),
            web_port=int(settings_values["web_port"]),
            llm_base_url=str(settings_values["llm_base_url"]),
            llm_api_key=str(settings_values["llm_api_key"]),
            llm_model=str(settings_values["llm_model"]),
            database_path=Path(settings_values["database_path"]),
            checkpoint_path=Path(settings_values["checkpoint_path"]),
            log_level=str(settings_values["log_level"]),
            max_task_seconds=int(settings_values["max_task_seconds"]),
            max_steps=int(settings_values["max_steps"]),
            max_retries=int(settings_values["max_retries"]),
            no_progress_limit=int(settings_values["no_progress_limit"]),
        )
        database = Database(settings.database_path)
        registry = WorkflowRegistry()
        registry.discover()
        engine = WorkflowEngine(
            registry=registry,
            condition_engine=ConditionEdgeEngine(),
            recovery_manager=RecoveryManager(
                Policy(
                    max_task_seconds=settings.max_task_seconds,
                    max_steps=settings.max_steps,
                    max_retries=settings.max_retries,
                    no_progress_limit=settings.no_progress_limit,
                    version=settings.app_version,
                )
            ),
            policy=Policy(
                max_task_seconds=settings.max_task_seconds,
                max_steps=settings.max_steps,
                max_retries=settings.max_retries,
                no_progress_limit=settings.no_progress_limit,
                version=settings.app_version,
            ),
            database=database,
            settings=settings,
        )
        workflow = registry.get(workflow_id)
        output = engine._run_graph_direct(state, workflow, resume=resume)
        result_queue.put({"ok": True, "state": dict(output)})
    except Exception as exc:
        LOGGER.exception("Workflow child process failed")
        failed_state = deepcopy(state)
        failed_state["status"] = STATUS_FAILED
        failed_state["error"] = {"code": "ENGINE_PROCESS_ERROR", "message": str(exc)}
        result_queue.put({"ok": False, "state": failed_state, "error": str(exc)})


class WorkflowEngine:
    """Build and execute LangGraph workflows with orchestration-only controls."""

    def __init__(
        self,
        registry: WorkflowRegistry,
        condition_engine: ConditionEdgeEngine,
        recovery_manager: RecoveryManager,
        policy: Policy = DEFAULT_POLICY,
        database: Database | None = None,
        settings: Settings | None = None,
    ) -> None:
        self.registry = registry
        self.condition_engine = condition_engine
        self.recovery_manager = recovery_manager
        self.policy = policy
        self.settings = settings if settings is not None else Settings()
        self.database = database if database is not None else Database(self.settings.database_path)
        self.contract_registry = ContractRegistry()
        self.decision_layer = DecisionLayer()

    def run(
        self,
        state: Mapping[str, Any],
        workflow: RegisteredWorkflow,
        resume: bool = False,
        timeout_seconds: int | None = None,
    ) -> TaskState:
        """Execute a workflow with a process-level hard timeout."""
        initial_state = deepcopy(dict(state))
        task_id = str(initial_state.get("task_id", "")).strip()
        if not task_id:
            raise ValueError("state['task_id'] is required")
        initial_state["workflow_id"] = workflow.workflow_id
        initial_state["workflow_version"] = workflow.version
        initial_state.setdefault("status", STATUS_PENDING)
        if not resume:
            initial_state["status"] = STATUS_RUNNING
        self.database.update_task(task_id, initial_state, str(initial_state["status"]))
        result_queue = mp.get_context("spawn").Queue()
        process = mp.get_context("spawn").Process(
            target=_execute_graph_process,
            args=(result_queue, initial_state, workflow.workflow_id, resume, self._settings_values()),
            daemon=True,
        )
        process.start()
        effective_timeout = self.policy.max_task_seconds if timeout_seconds is None else max(0, int(timeout_seconds))
        process.join(effective_timeout)
        if process.is_alive():
            process.terminate()
            process.join(10)
            timeout_state = deepcopy(initial_state)
            timeout_state["status"] = STATUS_TIMEOUT
            timeout_state["error"] = {
                "code": "MAX_TASK_SECONDS",
                "message": f"Task exceeded {effective_timeout} seconds",
            }
            orchestration = dict(timeout_state.get("orchestration", {}))
            orchestration["recovery_action"] = "TIMEOUT"
            timeout_state["orchestration"] = orchestration
            self.database.update_task(task_id, timeout_state, STATUS_TIMEOUT)
            self.database.add_event(
                task_id, "TASK_TIMEOUT", status=STATUS_TIMEOUT,
                payload=timeout_state["error"],
            )
            LOGGER.error("Hard task timeout: task_id=%s timeout=%ss", task_id, effective_timeout)
            return timeout_state
        try:
            message = result_queue.get(timeout=5)
        except queue.Empty as exc:
            failed_state = deepcopy(initial_state)
            failed_state["status"] = STATUS_FAILED
            failed_state["error"] = {"code": "ENGINE_NO_RESULT", "message": "Workflow process returned no result"}
            self.database.update_task(task_id, failed_state, STATUS_FAILED)
            self.database.add_event(task_id, "ENGINE_FAILURE", status=STATUS_FAILED, payload=failed_state["error"])
            raise RuntimeError("Workflow process returned no result") from exc
        output = dict(message["state"])
        status = str(output.get("status", STATUS_FAILED))
        self.database.update_task(task_id, output, status)
        if not message.get("ok", False):
            self.database.add_event(task_id, "ENGINE_FAILURE", status=STATUS_FAILED, payload=output.get("error", {}))
        return output

    def has_checkpoint(self, task_id: str) -> bool:
        """Return whether a durable LangGraph checkpoint exists for a task."""
        normalized = str(task_id).strip()
        if not normalized:
            return False
        checkpoint_path = Path(self.settings.checkpoint_path)
        if not checkpoint_path.exists():
            return False
        try:
            with SqliteSaver.from_conn_string(str(checkpoint_path)) as checkpointer:
                return checkpointer.get_tuple({"configurable": {"thread_id": normalized}}) is not None
        except Exception:
            LOGGER.exception("Checkpoint probe failed: task_id=%s", normalized)
            return False

    def _run_graph_direct(
        self,
        state: Mapping[str, Any],
        workflow: RegisteredWorkflow,
        resume: bool = False,
    ) -> TaskState:
        """Execute the compiled graph inside the dedicated worker process."""
        plan = OrchestrationPlanGenerator(self.registry).plan_for(workflow.workflow_id)
        self._register_workflow_contracts(workflow)
        graph = self._build_graph(workflow, plan)
        checkpoint_path = Path(self.settings.checkpoint_path)
        checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        task_id = str(state.get("task_id", "")).strip()
        if not task_id:
            raise ValueError("state['task_id'] is required")
        config = {"configurable": {"thread_id": task_id}}
        with SqliteSaver.from_conn_string(str(checkpoint_path)) as checkpointer:
            _CheckpointAuditBridge.attach(checkpointer, self.database, task_id, resume)
            compiled = graph.compile(checkpointer=checkpointer)
            if resume:
                resumed = compiled.invoke(None, config)
                return dict(resumed)
            output = compiled.invoke(dict(state), config)
            return dict(output)

    def _register_workflow_contracts(self, workflow: RegisteredWorkflow) -> None:
        """Register and verify the workflow contracts used by runtime validation."""
        for contract in workflow.contracts:
            existing = self.contract_registry.contracts.get(contract.node_id)
            if existing is None:
                self.contract_registry.register(contract)
                continue
            if existing != contract:
                raise ValueError(
                    f"Contract mismatch for node {contract.node_id}: "
                    "the same node_id is registered with a different contract"
                )

    def _build_graph(
        self,
        workflow: RegisteredWorkflow,
        plan: ExecutionPlan,
    ) -> StateGraph:
        """Build a real StateGraph using registry-provided node callables."""
        graph = StateGraph(TaskState)
        node_functions = self.registry.node_functions(workflow)
        for node_id in workflow.node_ids:
            graph.add_node(
                node_id,
                self._wrap_node(node_id, node_functions[node_id], plan),
            )
        if plan.order:
            graph.add_edge(START, plan.order[0])
        for node_id in plan.order:
            graph.add_conditional_edges(
                node_id,
                self._route_function(node_id, plan),
                self._route_targets(plan),
            )
        return graph

    def _wrap_node(
        self,
        node_id: str,
        node_function: Any,
        plan: ExecutionPlan,
    ) -> Any:
        """Wrap a business node with generic policy, progress, event, and recovery controls."""
        def wrapped(state: TaskState) -> TaskState:
            current = deepcopy(dict(state))
            while True:
                step_count = self._step_count(current)
                if step_count >= self.policy.max_steps:
                    current["status"] = STATUS_TIMEOUT
                    current["error"] = {
                        "code": "MAX_STEPS_REACHED",
                        "message": f"Maximum step count {self.policy.max_steps} reached before node execution",
                    }
                    self._set_recovery_action(current, "TIMEOUT")
                    self.database.update_task(str(current["task_id"]), current, STATUS_TIMEOUT)
                    self.database.add_event(
                        str(current["task_id"]), "MAX_STEPS_REACHED", node_id=node_id,
                        status=STATUS_TIMEOUT, payload=current["error"],
                    )
                    return current
                before_signature = self._state_signature(current)
                self._increment_steps(current)
                self.database.add_event(
                    str(current["task_id"]), "NODE_START", node_id=node_id,
                    status=STATUS_RUNNING, payload={"step": self._step_count(current)},
                )
                failure_type = "node_failure"
                decision_count_before = len(current.get("decisions", [])) if isinstance(current.get("decisions", []), list) else 0
                try:
                    failure_type = "contract_input_failure"
                    self.contract_registry.validate_input(node_id, current)
                    orchestration = dict(current.get("orchestration", {}))
                    orchestration["decision_layer"] = self.decision_layer
                    orchestration["database"] = self.database
                    current["orchestration"] = orchestration
                    try:
                        result = node_function(current)
                    finally:
                        current.get("orchestration", {}).pop("decision_layer", None)
                        current.get("orchestration", {}).pop("database", None)
                    clean_result = dict(result)
                    clean_orchestration = dict(clean_result.get("orchestration", {}))
                    clean_orchestration.pop("decision_layer", None)
                    clean_orchestration.pop("database", None)
                    clean_result["orchestration"] = clean_orchestration
                    self._record_new_ai_decisions(
                        clean_result, node_id, decision_count_before
                    )
                    failure_type = "contract_output_failure"
                    self.contract_registry.validate_output(node_id, clean_result)
                    next_state = deepcopy(clean_result)
                    next_state["status"] = STATUS_RUNNING
                    after_signature = self._state_signature(next_state)
                    if before_signature == after_signature:
                        no_progress = self._no_progress_count(next_state) + 1
                    else:
                        no_progress = 0
                    self._set_no_progress_count(next_state, no_progress)
                    if plan.order and node_id == plan.order[-1]:
                        next_state["status"] = STATUS_COMPLETED
                    if no_progress >= self.policy.no_progress_limit:
                        next_state["status"] = STATUS_FAILED
                        next_state["error"] = {
                            "code": "NO_INFORMATION_GAIN",
                            "message": f"State signature remained unchanged for {no_progress} consecutive node executions",
                        }
                        failure_type = "no_information_gain"
                        recovery = self.recovery_manager.prepare_retry(
                            next_state,
                            node_id,
                            next_state["error"]["message"],
                            failure_type,
                        )
                        self._set_recovery_action(next_state, str(recovery.get("action", "FAIL")))
                        self.database.update_task(str(next_state["task_id"]), next_state, STATUS_FAILED)
                        self.database.add_event(
                            str(next_state["task_id"]), "NO_INFORMATION_GAIN", node_id=node_id,
                            status=STATUS_FAILED, payload={**next_state["error"], "failure_type": failure_type},
                        )
                        self.database.add_event(
                            str(next_state["task_id"]), "RECOVERY", node_id=node_id,
                            status=STATUS_FAILED,
                            payload={"decision": recovery.get("action", "FAIL"), "reason": next_state["error"]["message"], "failure_type": failure_type},
                        )
                        return next_state
                    self.database.add_event(
                        str(next_state["task_id"]), "NODE_COMPLETE", node_id=node_id,
                        status=STATUS_RUNNING, payload={"step": self._step_count(next_state)},
                    )
                    self._record_database_commit(next_state, node_id)
                    return next_state
                except Exception as exc:
                    self._record_new_ai_decisions(current, node_id, decision_count_before)
                    recovery = self.recovery_manager.prepare_retry(current, node_id, exc, failure_type)
                    task_id = str(current["task_id"])
                    recovery_action = str(recovery.get("action", "FAIL"))
                    recovery_reason = str(
                        recovery.get("reason")
                        or recovery.get("error", {}).get("message")
                        or current.get("error", {}).get("message")
                        or str(exc)
                    )
                    self.database.add_event(
                        task_id, "NODE_FAILURE", node_id=node_id,
                        status=str(current.get("status", STATUS_FAILED)), payload=recovery,
                    )
                    self.database.add_event(
                        task_id, "RECOVERY", node_id=node_id,
                        status=str(current.get("status", STATUS_FAILED)),
                        payload={"decision": recovery_action, "reason": recovery_reason, "failure_type": failure_type},
                    )
                    if recovery_action == "RETRY":
                        self.database.add_event(
                            task_id, "RETRY", node_id=node_id,
                            status=STATUS_RUNNING,
                            payload={
                                "node_id": node_id,
                                "attempt": recovery.get("attempt"),
                                "reason": recovery_reason,
                                "failure_type": failure_type,
                            },
                        )
                    if recovery_action != "RETRY":
                        current["status"] = STATUS_FAILED
                        self.database.update_task(str(current["task_id"]), current, STATUS_FAILED)
                        return current
                    current["status"] = STATUS_RUNNING

        return wrapped

    def _record_new_ai_decisions(
        self, state: Mapping[str, Any], node_id: str, previous_count: int
    ) -> None:
        """Persist every new DecisionLayer record produced by one business node."""
        decisions = state.get("decisions", [])
        if not isinstance(decisions, list):
            return
        task_id = str(state.get("task_id", "")).strip()
        if not task_id:
            return
        for record in decisions[previous_count:]:
            if not isinstance(record, Mapping):
                continue
            self.database.add_event(
                task_id,
                "AI_DECISION",
                node_id=node_id,
                status=str(state.get("status", STATUS_RUNNING)),
                payload={
                    "decision_type": record.get("decision_type"),
                    "node_id": node_id,
                    "confidence": record.get("confidence"),
                    "rationale": record.get("rationale"),
                    "decision": record.get("decision"),
                    "metadata": record.get("metadata", {}),
                },
            )

    def _record_database_commit(self, state: Mapping[str, Any], node_id: str) -> None:
        """Audit a successful database-write-authority contract without naming business nodes."""
        contract = self.contract_registry.get(node_id)
        if not contract.database_write_authority:
            return
        report = state.get("node_reports", {}).get(node_id, {})
        if not isinstance(report, Mapping) or report.get("status") != "committed":
            return
        counts = {
            "entity_count": int(report.get("entity_count", 0)),
            "relationship_count": int(report.get("relationship_count", 0)),
            "evidence_count": int(report.get("evidence_count", 0)),
        }
        self.database.add_event(
            str(state["task_id"]),
            "DATABASE_COMMIT",
            node_id=node_id,
            status=str(state.get("status", STATUS_RUNNING)),
            payload=counts,
        )

    def _route_function(self, current: str, plan: ExecutionPlan) -> Any:
        """Create the single conditional router for one graph node."""
        def route(state: TaskState) -> str:
            outcome = self.condition_engine.choose(plan, state, current)
            if outcome.target is None:
                self._record_route_event(state, current, outcome.reason, outcome.outcome)
                return END
            self._record_route_event(state, current, outcome.reason, outcome.outcome)
            return outcome.target
        return route

    @staticmethod
    def _route_targets(plan: ExecutionPlan) -> dict[str, str]:
        """Return the graph's dynamic route target map without business-node knowledge."""
        targets = {node_id: node_id for node_id in plan.order}
        targets[END] = END
        return targets

    def _record_route_event(
        self, state: Mapping[str, Any], current: str, reason: str, outcome: Mapping[str, Any],
    ) -> None:
        task_id = str(state.get("task_id", "")).strip()
        if task_id:
            self.database.add_event(
                task_id, "ROUTE_DECISION", node_id=current,
                status=str(state.get("status", STATUS_RUNNING)),
                payload={"reason": reason, **dict(outcome)},
            )

    @staticmethod
    def _state_signature(state: Mapping[str, Any]) -> tuple[Any, ...]:
        """Build a stable signature over the defined information-bearing shared-state fields."""
        keys = ("trade_nodes", "evidence_pool", "entities", "relationships", "fragments")
        return tuple(WorkflowEngine._freeze(state.get(key, [])) for key in keys)

    @staticmethod
    def _freeze(value: Any) -> Any:
        """Convert nested state values into a deterministic comparable structure."""
        if isinstance(value, Mapping):
            return tuple(sorted((str(key), WorkflowEngine._freeze(item)) for key, item in value.items()))
        if isinstance(value, (list, tuple)):
            return tuple(WorkflowEngine._freeze(item) for item in value)
        if isinstance(value, set):
            return tuple(sorted(WorkflowEngine._freeze(item) for item in value))
        return value

    @staticmethod
    def _step_count(state: Mapping[str, Any]) -> int:
        orchestration = state.get("orchestration", {})
        if not isinstance(orchestration, Mapping):
            return 0
        try:
            return max(0, int(orchestration.get("step_count", 0)))
        except (TypeError, ValueError) as exc:
            raise ValueError("state orchestration step_count must be an integer") from exc

    @staticmethod
    def _increment_steps(state: TaskState) -> None:
        orchestration = state.setdefault("orchestration", {})
        if not isinstance(orchestration, dict):
            raise TypeError("state['orchestration'] must be a dictionary")
        orchestration["step_count"] = WorkflowEngine._step_count(state) + 1

    @staticmethod
    def _no_progress_count(state: Mapping[str, Any]) -> int:
        orchestration = state.get("orchestration", {})
        if not isinstance(orchestration, Mapping):
            return 0
        try:
            return max(0, int(orchestration.get("no_progress_count", 0)))
        except (TypeError, ValueError) as exc:
            raise ValueError("state orchestration no_progress_count must be an integer") from exc

    @staticmethod
    def _set_no_progress_count(state: TaskState, value: int) -> None:
        orchestration = state.setdefault("orchestration", {})
        if not isinstance(orchestration, dict):
            raise TypeError("state['orchestration'] must be a dictionary")
        orchestration["no_progress_count"] = value

    @staticmethod
    def _set_recovery_action(state: TaskState, action: str) -> None:
        orchestration = state.setdefault("orchestration", {})
        if not isinstance(orchestration, dict):
            raise TypeError("state['orchestration'] must be a dictionary")
        orchestration["recovery_action"] = action

    def _settings_values(self) -> dict[str, Any]:
        """Return spawn-safe settings values."""
        return {
            "app_version": self.settings.app_version,
            "web_host": self.settings.web_host,
            "web_port": self.settings.web_port,
            "llm_base_url": self.settings.llm_base_url,
            "llm_api_key": self.settings.llm_api_key,
            "llm_model": self.settings.llm_model,
            "database_path": str(self.settings.database_path),
            "checkpoint_path": str(self.settings.checkpoint_path),
            "log_level": self.settings.log_level,
            "max_task_seconds": self.settings.max_task_seconds,
            "max_steps": self.settings.max_steps,
            "max_retries": self.settings.max_retries,
            "no_progress_limit": self.settings.no_progress_limit,
        }
```

## `core/orchestration/long_task.py`

```python
"""Long-task facade for PSV Trade OS 9.4.0."""

from __future__ import annotations

from typing import Any

from .mission import MissionDirector
from .scheduler import WorkflowScheduler


class LongTaskManager:
    """Thin facade over asynchronous workflow scheduling and task tracking."""

    def __init__(self, scheduler: WorkflowScheduler) -> None:
        self.scheduler = scheduler

    def submit(
        self,
        workflow_id: str | None,
        request: str,
        market: str,
        industry: str,
    ) -> str:
        """Submit a new long-running task."""
        return self.scheduler.submit(workflow_id, request, market, industry)

    def resume(self, task_id: str) -> str:
        """Submit a durable checkpoint resume."""
        return self.scheduler.submit_resume(task_id)

    def track(self, task_id: str) -> dict[str, Any]:
        """Return the current persisted task record."""
        database = self.scheduler.mission_director.database
        return database.get_task(task_id)
```

## `core/orchestration/mission.py`

```python
"""Mission Director for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
import multiprocessing as mp
import queue
import time
import uuid
from typing import Any, Mapping

from core.config.settings import Settings
from core.memory.db import Database

from .engine import WorkflowEngine
from .registry import WorkflowRegistry
from .state import STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING, TaskState
from .task_understanding import TaskUnderstanding

LOGGER = logging.getLogger(__name__)
DEFAULT_WORKFLOW_ID = "trade_collection"


def _execute_task_understanding_process(result_queue: Any, request: str, settings_values: dict[str, Any]) -> None:
    """Run AI mission understanding in an isolated process for hard timeout enforcement."""
    try:
        settings = Settings(
            app_version=str(settings_values["app_version"]),
            web_host=str(settings_values["web_host"]),
            web_port=int(settings_values["web_port"]),
            llm_base_url=str(settings_values["llm_base_url"]),
            llm_api_key=str(settings_values["llm_api_key"]),
            llm_model=str(settings_values["llm_model"]),
            database_path=Path(settings_values["database_path"]),
            checkpoint_path=Path(settings_values["checkpoint_path"]),
            log_level=str(settings_values["log_level"]),
            max_task_seconds=int(settings_values["max_task_seconds"]),
            max_steps=int(settings_values["max_steps"]),
            max_retries=int(settings_values["max_retries"]),
            no_progress_limit=int(settings_values["no_progress_limit"]),
        )
        from core.model.reasoning import ReasoningEngine
        from .decision import DecisionLayer
        understanding = TaskUnderstanding(
            decision_layer=DecisionLayer(reasoning_engine=ReasoningEngine(settings))
        )
        mission = understanding.understand(request)
        result_queue.put({"ok": True, "mission": mission, "decision": dict(understanding.last_decision)})
    except Exception as exc:
        LOGGER.exception("Task understanding child process failed")
        result_queue.put({"ok": False, "error": str(exc)})


class MissionDirector:
    """Create standard Missions and delegate execution to the workflow engine."""

    def __init__(
        self,
        database: Database,
        registry: WorkflowRegistry,
        task_understanding: TaskUnderstanding,
        engine: WorkflowEngine,
    ) -> None:
        self.database = database
        self.registry = registry
        self.task_understanding = task_understanding
        self.engine = engine

    def create(
        self,
        request: str,
        market: str,
        industry: str,
        workflow_id: str | None = None,
    ) -> str:
        """Create a pending task and defer AI understanding to execution time."""
        selected_workflow_id = (workflow_id or DEFAULT_WORKFLOW_ID).strip()
        workflow = self.registry.get(selected_workflow_id)
        task_id = self.create_pending(
            request=request, market=market, industry=industry, workflow_id=workflow.workflow_id
        )
        return task_id

    def create_pending(
        self,
        request: str,
        market: str,
        industry: str,
        workflow_id: str | None = None,
    ) -> str:
        """Persist a pending task without blocking the HTTP submission path on AI inference."""
        selected_workflow_id = (workflow_id or DEFAULT_WORKFLOW_ID).strip()
        workflow = self.registry.get(selected_workflow_id)
        normalized_request = str(request).strip()
        normalized_market = str(market).strip()
        normalized_industry = str(industry).strip()
        if not normalized_request:
            raise ValueError("request must not be empty")
        if not normalized_market:
            raise ValueError("market must not be empty")
        if not normalized_industry:
            raise ValueError("industry must not be empty")
        task_id = str(uuid.uuid4())
        mission: dict[str, Any] = {
            "intent": "",
            "task_type": "",
            "objective": normalized_request,
            "targets": [],
            "constraints": [],
            "success_criteria": [],
            "market": normalized_market,
            "industry": normalized_industry,
            "request": normalized_request,
        }
        state: TaskState = {
            "mission": mission,
            "product_definition": {},
            "trade_nodes": [],
            "fragments": [],
            "evidence_pool": [],
            "entities": [],
            "relationships": [],
            "decisions": [],
            "history": [],
            "orchestration": {"step_count": 0, "no_progress_count": 0},
            "error": {},
            "node_reports": {},
            "status": STATUS_PENDING,
            "task_id": task_id,
            "workflow_id": workflow.workflow_id,
            "workflow_version": workflow.version,
        }
        self.database.create_task(task_id, workflow.workflow_id, state, STATUS_PENDING)
        self.database.add_event(
            task_id, "TASK_CREATED", status=STATUS_PENDING,
            payload={"workflow_id": workflow.workflow_id, "ai_understanding": "deferred"},
        )
        LOGGER.info("Mission task created: task_id=%s workflow_id=%s", task_id, workflow.workflow_id)
        return task_id

    def execute(self, task_id: str) -> TaskState:
        """Execute a persisted task with lifecycle-wide hard timeout enforcement."""
        started = time.monotonic()
        try:
            record = self.database.get_task(task_id)
            workflow = self.registry.get(record["workflow_id"])
            state = dict(record["state"])
            state["status"] = STATUS_RUNNING
            self.database.update_task(task_id, state, STATUS_RUNNING)
            self.database.add_event(task_id, "TASK_EXECUTION_STARTED", status=STATUS_RUNNING)

            max_seconds = max(1, int(self.engine.policy.max_task_seconds))
            understanding_timeout = min(120, max_seconds)
            remaining_before_ai = max_seconds - (time.monotonic() - started)
            if remaining_before_ai <= 0:
                return self._fail_timeout(task_id, state, 0)
            result_queue = mp.get_context("spawn").Queue()
            process = mp.get_context("spawn").Process(
                target=_execute_task_understanding_process,
                args=(result_queue, str(state["mission"].get("request", "")), self._settings_values()),
                daemon=True,
            )
            process.start()
            process.join(min(understanding_timeout, int(remaining_before_ai)))
            if process.is_alive():
                process.terminate()
                process.join(10)
                return self._fail_timeout(task_id, state, int(understanding_timeout))
            try:
                message = result_queue.get(timeout=5)
            except queue.Empty as exc:
                raise RuntimeError("Task understanding process returned no result") from exc
            if not message.get("ok"):
                raise RuntimeError(str(message.get("error", "Task understanding failed")))

            mission = dict(message["mission"])
            mission["market"] = str(state["mission"].get("market", "")).strip()
            mission["industry"] = str(state["mission"].get("industry", "")).strip()
            state["mission"] = mission
            decision_record = dict(message.get("decision", {}))
            if decision_record:
                self.database.add_event(
                    task_id, "AI_DECISION", node_id="TASK_UNDERSTANDING", status=STATUS_RUNNING,
                    payload={
                        "decision_type": decision_record.get("decision_type", "mission_understanding"),
                        "node_id": "TASK_UNDERSTANDING", "confidence": decision_record.get("confidence"),
                        "rationale": decision_record.get("rationale"), "decision": decision_record.get("decision"),
                        "metadata": decision_record.get("metadata", {}),
                    },
                )
            self.database.update_task(task_id, state, STATUS_RUNNING)
            elapsed = time.monotonic() - started
            remaining = max(0, int(max_seconds - elapsed))
            if remaining <= 0:
                return self._fail_timeout(task_id, state, max_seconds)
            result = self.engine.run(state, workflow, resume=False, timeout_seconds=remaining)
            final_status = str(result.get("status", STATUS_FAILED))
            self.database.update_task(task_id, result, final_status)
            self.database.add_event(task_id, "TASK_EXECUTION_FINISHED", status=final_status)
            return result
        except Exception as exc:
            LOGGER.exception("Mission execution failed: task_id=%s", task_id)
            record = self.database.get_task(task_id)
            state = dict(record["state"])
            state["status"] = STATUS_FAILED
            state["error"] = {"code": "MISSION_EXECUTION_ERROR", "message": str(exc)}
            self.database.update_task(task_id, state, STATUS_FAILED)
            self.database.add_event(task_id, "TASK_EXECUTION_FAILED", status=STATUS_FAILED, payload=state["error"])
            raise

    def _fail_timeout(self, task_id: str, state: Mapping[str, Any], elapsed_or_limit: int) -> TaskState:
        """Persist a lifecycle timeout after an isolated stage exceeds its hard budget."""
        failed = dict(state)
        failed["status"] = "TASK_TIMEOUT"
        failed["error"] = {
            "code": "MAX_TASK_SECONDS",
            "message": f"Task exceeded hard timeout during mission lifecycle (limit {self.engine.policy.max_task_seconds}s)",
        }
        orchestration = dict(failed.get("orchestration", {}))
        orchestration["recovery_action"] = "TIMEOUT"
        orchestration["timeout_stage"] = "TASK_UNDERSTANDING"
        failed["orchestration"] = orchestration
        self.database.update_task(task_id, failed, "TASK_TIMEOUT")
        self.database.add_event(task_id, "TASK_TIMEOUT", status="TASK_TIMEOUT", payload=failed["error"] | {"elapsed": elapsed_or_limit})
        return failed

    def _settings_values(self) -> dict[str, Any]:
        settings = self.engine.settings
        return {
            "app_version": settings.app_version, "web_host": settings.web_host, "web_port": settings.web_port,
            "llm_base_url": settings.llm_base_url, "llm_api_key": settings.llm_api_key, "llm_model": settings.llm_model,
            "database_path": str(settings.database_path), "checkpoint_path": str(settings.checkpoint_path),
            "log_level": settings.log_level, "max_task_seconds": settings.max_task_seconds,
            "max_steps": settings.max_steps, "max_retries": settings.max_retries, "no_progress_limit": settings.no_progress_limit,
        }

    def resume(self, task_id: str) -> TaskState:
        """Resume a task from its durable LangGraph checkpoint."""
        record = self.database.get_task(task_id)
        workflow = self.registry.get(record["workflow_id"])
        state = dict(record["state"])
        state["task_id"] = task_id
        state["status"] = STATUS_RUNNING
        self.database.update_task(task_id, state, STATUS_RUNNING)
        self.database.add_event(task_id, "TASK_RESUME_STARTED", status=STATUS_RUNNING)
        self.database.add_event(
            task_id,
            "CHECKPOINT",
            status=STATUS_RUNNING,
            payload={"action": "restore_requested", "thread_id": task_id},
        )
        try:
            result = self.engine.run(state, workflow, resume=True)
            final_status = str(result.get("status", STATUS_FAILED))
            self.database.update_task(task_id, result, final_status)
            self.database.add_event(task_id, "TASK_RESUME_FINISHED", status=final_status)
            return result
        except Exception as exc:
            LOGGER.exception("Mission resume failed: task_id=%s", task_id)
            failed = dict(state)
            failed["status"] = STATUS_FAILED
            failed["error"] = {"code": "MISSION_RESUME_ERROR", "message": str(exc)}
            self.database.update_task(task_id, failed, STATUS_FAILED)
            self.database.add_event(task_id, "TASK_RESUME_FAILED", status=STATUS_FAILED, payload=failed["error"])
            raise
```

## `core/orchestration/plan.py`

```python
"""Initial orchestration plan generation for PSV Trade OS 9.4.0."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .registry import RegisteredWorkflow, WorkflowRegistry


@dataclass(frozen=True)
class ExecutionPlan:
    """Declarative initial node order used only while building the LangGraph."""

    workflow_id: str
    version: str
    order: tuple[str, ...]


class OrchestrationPlanGenerator:
    """Build the initial node order from contract dependencies."""

    def __init__(self, registry: WorkflowRegistry) -> None:
        self.registry = registry

    def plan_for(self, workflow_id: str) -> ExecutionPlan:
        """Generate only the initial node order for a registered workflow."""
        workflow = self.registry.get(workflow_id)
        contracts = {contract.node_id: contract for contract in workflow.contracts}
        order = self._dependency_order(workflow, contracts)
        return ExecutionPlan(
            workflow_id=workflow.workflow_id,
            version=workflow.version,
            order=order,
        )

    @staticmethod
    def _dependency_order(
        workflow: RegisteredWorkflow,
        contracts: dict[str, Any],
    ) -> tuple[str, ...]:
        """Derive the initial node order from declared input/output dependencies."""
        node_ids = tuple(workflow.node_ids)
        produced_by: dict[str, set[str]] = {}

        for node_id in node_ids:
            for output_key in contracts[node_id].output_keys:
                produced_by.setdefault(output_key, set()).add(node_id)

        dependencies: dict[str, set[str]] = {
            node_id: set() for node_id in node_ids
        }
        for node_id in node_ids:
            for input_key in contracts[node_id].input_keys:
                dependencies[node_id].update(
                    producer
                    for producer in produced_by.get(input_key, set())
                    if producer != node_id
                )

        remaining = set(node_ids)
        resolved: list[str] = []
        while remaining:
            ready_candidates = [
                node_id
                for node_id in remaining
                if dependencies[node_id].issubset(set(resolved))
            ]
            if not ready_candidates:
                unresolved = ", ".join(sorted(remaining))
                raise ValueError(
                    f"Workflow '{workflow.workflow_id}' has cyclic or "
                    f"unresolved contract dependencies: {unresolved}"
                )

            previous_capabilities = (
                tuple(workflow.node_specs[resolved[-1]].get("capabilities", ()))
                if resolved
                else ()
            )

            def ready_key(node_id: str) -> tuple[int, int]:
                capabilities = tuple(
                    workflow.node_specs[node_id].get("capabilities", ())
                )
                if (
                    "evidence_verification" in previous_capabilities
                    and "entity_resolution" in capabilities
                ):
                    return (0, node_ids.index(node_id))
                if (
                    "evidence_verification" in capabilities
                    and "entity_resolution" not in capabilities
                ):
                    return (0, node_ids.index(node_id))
                return (1, node_ids.index(node_id))

            ready = sorted(ready_candidates, key=ready_key)
            resolved.extend(ready)
            remaining.difference_update(ready)

        return tuple(resolved)
```

## `core/orchestration/policies.py`

```python
"""Orchestration policy definitions for PSV Trade OS 9.4.0."""

from __future__ import annotations

from dataclasses import dataclass
from core.config.settings import APP_VERSION, settings


@dataclass(frozen=True)
class Policy:
    """Runtime policy consumed by orchestration components."""
    max_task_seconds: int
    max_steps: int
    max_retries: int
    no_progress_limit: int
    version: str = APP_VERSION

    def __post_init__(self) -> None:
        if self.max_task_seconds <= 0:
            raise ValueError("max_task_seconds must be greater than zero")
        if self.max_steps <= 0:
            raise ValueError("max_steps must be greater than zero")
        if self.max_retries < 0:
            raise ValueError("max_retries must not be negative")
        if self.no_progress_limit <= 0:
            raise ValueError("no_progress_limit must be greater than zero")


DEFAULT_POLICY = Policy(settings.max_task_seconds, settings.max_steps,
                        settings.max_retries, settings.no_progress_limit)
```

## `core/orchestration/recovery.py`

```python
"""Generic task recovery engine for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
from collections.abc import Mapping, MutableMapping
from typing import Any

from .policies import DEFAULT_POLICY, Policy
from .state import STATUS_FAILED, STATUS_PAUSED, STATUS_RUNNING, TaskState

LOGGER = logging.getLogger(__name__)

FAILURE_TYPES = frozenset({
    "node_failure",
    "contract_input_failure",
    "contract_output_failure",
    "timeout",
    "no_information_gain",
    "engine_failure",
})


class RecoveryManager:
    """Apply generic recovery policy without business-node knowledge."""

    def __init__(self, policy: Policy = DEFAULT_POLICY) -> None:
        self.policy = policy

    def can_retry(self, state: Mapping[str, Any], node_id: str, failure_type: str) -> bool:
        """Determine whether the failure type is retryable and budget remains."""
        normalized_failure_type = self._validate_failure_type(failure_type)
        if normalized_failure_type in {"timeout", "no_information_gain"}:
            return False
        attempts = self._attempts_for(state, node_id)
        return attempts < self.policy.max_retries

    def prepare_retry(
        self,
        state: MutableMapping[str, Any] | TaskState,
        node_id: str,
        error: Exception | str,
        failure_type: str,
    ) -> dict[str, Any]:
        """Prepare a generic retry or fail according to failure type and retry budget."""
        normalized_failure_type = self._validate_failure_type(failure_type)
        attempts = self._attempts_for(state, node_id)
        next_attempt = attempts + 1
        if not self.can_retry(state, node_id, normalized_failure_type):
            return self.fail(
                state,
                code="RECOVERY_NOT_RETRYABLE",
                message=f"Failure type {normalized_failure_type} is not retryable or retry limit reached for node {node_id}",
            )

        orchestration = self._orchestration(state)
        attempts_map = orchestration.setdefault("attempts", {})
        attempts_map[node_id] = next_attempt
        orchestration["recovery_action"] = "RETRY"
        orchestration["resume_node"] = node_id
        state["status"] = STATUS_RUNNING
        state["error"] = {
            "code": "RETRY_SCHEDULED",
            "message": str(error),
            "node_id": node_id,
            "attempt": next_attempt,
            "failure_type": normalized_failure_type,
        }
        LOGGER.warning(
            "Retry scheduled: node=%s attempt=%s/%s failure_type=%s error=%s",
            node_id,
            next_attempt,
            self.policy.max_retries,
            normalized_failure_type,
            error,
        )
        return {
            "action": "RETRY",
            "node_id": node_id,
            "attempt": next_attempt,
            "failure_type": normalized_failure_type,
            "error": state["error"],
        }

    def fail(
        self,
        state: MutableMapping[str, Any] | TaskState,
        code: str,
        message: str,
    ) -> dict[str, Any]:
        """Mark the task failed and persist the failure in shared state."""
        error = {"code": code, "message": message}
        state["error"] = error
        state["status"] = STATUS_FAILED
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "FAIL"
        orchestration.pop("resume_node", None)
        LOGGER.error(
            "Task recovery failed: code=%s message=%s",
            code,
            message,
        )
        return {"action": "FAIL", "error": error}

    def pause(
        self,
        state: MutableMapping[str, Any] | TaskState,
        reason: str,
    ) -> dict[str, Any]:
        """Pause a task for later orchestration resume."""
        state["status"] = STATUS_PAUSED
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "PAUSE"
        orchestration["pause_reason"] = reason
        LOGGER.warning("Task paused: %s", reason)
        return {"action": "PAUSE", "reason": reason}

    def resume(
        self,
        state: MutableMapping[str, Any] | TaskState,
    ) -> dict[str, Any]:
        """Resume a paused task."""
        state["status"] = STATUS_RUNNING
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "RESUME"
        LOGGER.info("Task resumed")
        return {"action": "RESUME"}

    @staticmethod
    def _validate_failure_type(failure_type: str) -> str:
        """Validate and normalize the generic failure category."""
        normalized = str(failure_type).strip().lower()
        if normalized not in FAILURE_TYPES:
            raise ValueError(
                "Unsupported failure_type: "
                f"{failure_type!r}; expected one of {sorted(FAILURE_TYPES)}"
            )
        return normalized

    @staticmethod
    def _orchestration(
        state: MutableMapping[str, Any],
    ) -> MutableMapping[str, Any]:
        """Return the mutable orchestration state container."""
        value = state.get("orchestration")
        if value is None:
            value = {}
            state["orchestration"] = value
        if not isinstance(value, MutableMapping):
            raise TypeError(
                "state['orchestration'] must be a mutable mapping"
            )
        return value

    @classmethod
    def _attempts_for(
        cls,
        state: Mapping[str, Any],
        node_id: str,
    ) -> int:
        """Read the generic attempt counter from shared state."""
        orchestration = state.get("orchestration", {})
        if not isinstance(orchestration, Mapping):
            return 0
        attempts = orchestration.get("attempts", {})
        if not isinstance(attempts, Mapping):
            return 0
        value = attempts.get(node_id, 0)
        try:
            return max(0, int(value))
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Invalid attempt counter for node {node_id}: {value!r}"
            ) from exc
```

## `core/orchestration/registry.py`

```python
"""Dynamic workflow registry for PSV Trade OS 9.4.0."""

from __future__ import annotations

import importlib
import logging
import pkgutil
from dataclasses import dataclass
from types import ModuleType
from typing import Any, Callable

import business.workflows as workflows_package

LOGGER = logging.getLogger(__name__)


class WorkflowDiscoveryError(RuntimeError):
    """Raised when workflow discovery or registration fails."""


@dataclass(frozen=True)
class RegisteredWorkflow:
    """Validated declarative workflow specification."""

    workflow_id: str
    version: str
    spec: ModuleType

    @property
    def node_ids(self) -> tuple[str, ...]:
        return tuple(getattr(self.spec, "NODE_IDS"))

    @property
    def node_specs(self) -> dict[str, Any]:
        return dict(getattr(self.spec, "NODE_SPECS"))

    @property
    def contracts(self) -> tuple[Any, ...]:
        return tuple(getattr(self.spec, "CONTRACTS"))

    @property
    def payload_keys(self) -> dict[str, tuple[str, ...]]:
        return dict(getattr(self.spec, "PAYLOAD_KEYS"))

    @property
    def capabilities(self) -> tuple[str, ...]:
        return tuple(getattr(self.spec, "CAPABILITIES"))


class WorkflowRegistry:
    """Discover, validate, and expose declarative workflow specifications."""

    def __init__(self) -> None:
        self._workflows: dict[str, RegisteredWorkflow] = {}

    def discover(self) -> tuple[RegisteredWorkflow, ...]:
        """Discover all workflow ``spec.py`` modules and register them."""
        discovered: dict[str, RegisteredWorkflow] = {}
        try:
            package_path = getattr(workflows_package, "__path__", None)
            if package_path is None:
                raise WorkflowDiscoveryError(
                    "business.workflows does not expose a package __path__"
                )
            for module_info in pkgutil.iter_modules(package_path):
                if not module_info.ispkg:
                    continue
                spec_module_name = f"{workflows_package.__name__}.{module_info.name}.spec"
                try:
                    spec_module = importlib.import_module(spec_module_name)
                    workflow = self._build_registration(spec_module, spec_module_name)
                    if workflow.workflow_id in discovered:
                        raise WorkflowDiscoveryError(
                            f"Duplicate workflow_id discovered: {workflow.workflow_id}"
                        )
                    discovered[workflow.workflow_id] = workflow
                    LOGGER.info(
                        "Workflow discovered: workflow_id=%s version=%s module=%s",
                        workflow.workflow_id, workflow.version, spec_module_name,
                    )
                except Exception as exc:
                    LOGGER.exception("Workflow discovery failed for %s", spec_module_name)
                    raise WorkflowDiscoveryError(
                        f"Failed to discover workflow spec '{spec_module_name}': {exc}"
                    ) from exc
        except WorkflowDiscoveryError:
            raise
        except Exception as exc:
            LOGGER.exception("Workflow discovery failed while scanning business.workflows")
            raise WorkflowDiscoveryError(f"Failed to scan business.workflows: {exc}") from exc
        self._workflows = discovered
        return self.workflows()

    def get(self, workflow_id: str) -> RegisteredWorkflow:
        """Return a registered workflow or raise a clear error."""
        normalized_id = workflow_id.strip()
        if not normalized_id:
            raise KeyError("workflow_id must not be empty")
        try:
            return self._workflows[normalized_id]
        except KeyError as exc:
            raise KeyError(f"Workflow not registered: {normalized_id}") from exc

    def workflows(self) -> tuple[RegisteredWorkflow, ...]:
        """Return registered workflows in deterministic ID order."""
        return tuple(self._workflows[key] for key in sorted(self._workflows))

    def node_functions(self, workflow: RegisteredWorkflow) -> dict[str, Callable[[dict[str, Any]], dict[str, Any]]]:
        """Load business node callables through the registered workflow package only."""
        package_name = getattr(workflow.spec, "__package__", "")
        if not package_name:
            raise WorkflowDiscoveryError(
                f"Workflow spec has no package metadata: {workflow.workflow_id}"
            )
        nodes_module = importlib.import_module(f"{package_name}.nodes")
        getter = getattr(nodes_module, "get_node_function", None)
        if not callable(getter):
            raise WorkflowDiscoveryError(
                f"Workflow '{workflow.workflow_id}' nodes module must expose get_node_function"
            )
        functions: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {}
        for node_id in workflow.node_ids:
            function = getter(node_id)
            if not callable(function):
                raise WorkflowDiscoveryError(
                    f"Workflow '{workflow.workflow_id}' node '{node_id}' is not callable"
                )
            functions[node_id] = function
        return functions

    @staticmethod
    def _build_registration(spec_module: ModuleType, module_name: str) -> RegisteredWorkflow:
        required = (
            "WORKFLOW_ID", "WORKFLOW_VERSION", "NODE_IDS", "NODE_SPECS",
            "CONTRACTS", "PAYLOAD_KEYS", "CAPABILITIES",
        )
        missing = [name for name in required if not hasattr(spec_module, name)]
        if missing:
            raise WorkflowDiscoveryError(
                f"Workflow spec '{module_name}' is missing required declarations: "
                + ", ".join(missing)
            )
        workflow_id = str(getattr(spec_module, "WORKFLOW_ID")).strip()
        version = str(getattr(spec_module, "WORKFLOW_VERSION")).strip()
        node_ids = tuple(getattr(spec_module, "NODE_IDS"))
        node_specs = getattr(spec_module, "NODE_SPECS")
        contracts = tuple(getattr(spec_module, "CONTRACTS"))
        payload_keys = getattr(spec_module, "PAYLOAD_KEYS")
        capabilities = tuple(getattr(spec_module, "CAPABILITIES"))
        if not workflow_id:
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' has empty WORKFLOW_ID")
        if not version:
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' has empty WORKFLOW_VERSION")
        if not node_ids or len(node_ids) != len(set(node_ids)):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' must declare unique NODE_IDS")
        if set(node_specs) != set(node_ids):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' NODE_SPECS must match NODE_IDS")
        contract_ids = tuple(contract.node_id for contract in contracts)
        if set(contract_ids) != set(node_ids) or len(contract_ids) != len(set(contract_ids)):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' CONTRACTS must match NODE_IDS")
        if not isinstance(payload_keys, dict):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' PAYLOAD_KEYS must be a mapping")
        if not capabilities or len(capabilities) != len(set(capabilities)):
            raise WorkflowDiscoveryError(f"Workflow spec '{module_name}' must declare unique CAPABILITIES")
        return RegisteredWorkflow(workflow_id=workflow_id, version=version, spec=spec_module)
```

## `core/orchestration/scheduler.py`

```python
"""Asynchronous workflow scheduler for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
import threading
from typing import Any

from .mission import MissionDirector
from .state import STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING

LOGGER = logging.getLogger(__name__)


class WorkflowScheduler:
    """Submit Missions to background threads without controlling business nodes."""

    def __init__(self, mission_director: MissionDirector) -> None:
        self.mission_director = mission_director
        self._threads: dict[str, threading.Thread] = {}
        self._lock = threading.Lock()
        self._recover_persisted_tasks()

    def _recover_persisted_tasks(self) -> None:
        """Recover persisted lifecycle work after a scheduler process restart."""
        try:
            tasks = self.mission_director.database.get_tasks_by_status((STATUS_PENDING, STATUS_RUNNING))
        except Exception:
            LOGGER.exception("Failed to scan persisted tasks during scheduler startup")
            return
        for task in tasks:
            task_id = str(task["task_id"])
            if task["status"] == STATUS_RUNNING:
                if self.mission_director.engine.has_checkpoint(task_id):
                    self._start_thread(task_id, self._resume_task, "psv-recover-resume")
                else:
                    state = dict(task["state"])
                    state["status"] = STATUS_FAILED
                    state["error"] = {
                        "code": "PROCESS_RESTART_INTERRUPTED",
                        "message": "Task was RUNNING when the scheduler process restarted and has no durable checkpoint",
                    }
                    self.mission_director.database.update_task(task_id, state, STATUS_FAILED)
                    self.mission_director.database.add_event(
                        task_id, "TASK_RECOVERY_FAILED", status=STATUS_FAILED, payload=state["error"]
                    )
                    LOGGER.warning("Marked interrupted RUNNING task failed: task_id=%s", task_id)
            else:
                self._start_thread(task_id, self._execute_task, "psv-recover")
                LOGGER.info("Recovered pending task: task_id=%s", task_id)

    def _start_thread(self, task_id: str, target: Any, name_prefix: str) -> None:
        """Start one recovery worker while keeping scheduler state thread-safe."""
        with self._lock:
            existing = self._threads.get(task_id)
            if existing is not None and existing.is_alive():
                return
            thread = threading.Thread(
                target=target, args=(task_id,), name=f"{name_prefix}-{task_id}", daemon=True
            )
            self._threads[task_id] = thread
        thread.start()

    def submit(
        self,
        workflow_id: str | None,
        request: str,
        market: str,
        industry: str,
    ) -> str:
        """Create a task and return immediately while execution runs in a daemon thread."""
        task_id = self.mission_director.create_pending(
            request=request, market=market, industry=industry, workflow_id=workflow_id
        )
        self._start_thread(task_id, self._execute_task, "psv-task")
        LOGGER.info("Workflow submitted asynchronously: task_id=%s", task_id)
        return task_id

    def submit_resume(self, task_id: str) -> str:
        """Resume a persisted task in a background thread and return immediately."""
        self._start_thread(task_id, self._resume_task, "psv-resume")
        LOGGER.info("Workflow resume submitted asynchronously: task_id=%s", task_id)
        return task_id

    def _execute_task(self, task_id: str) -> None:
        """Run one MissionDirector execution and contain worker exceptions."""
        try:
            self.mission_director.execute(task_id)
        except Exception:
            LOGGER.exception("Background workflow execution failed: task_id=%s", task_id)
        finally:
            with self._lock:
                self._threads.pop(task_id, None)

    def _resume_task(self, task_id: str) -> None:
        """Run one MissionDirector resume and contain worker exceptions."""
        try:
            self.mission_director.resume(task_id)
        except Exception:
            LOGGER.exception("Background workflow resume failed: task_id=%s", task_id)
        finally:
            with self._lock:
                self._threads.pop(task_id, None)
```

## `core/orchestration/state.py`

```python
"""Shared task state definitions for PSV Trade OS 9.4.0."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, TypedDict

STATUS_PENDING = "PENDING"
STATUS_RUNNING = "RUNNING"
STATUS_COMPLETED = "COMPLETED"
STATUS_FAILED = "FAILED"
STATUS_PAUSED = "PAUSED"
STATUS_TIMEOUT = "TASK_TIMEOUT"

STATUS_VALUES = frozenset({STATUS_PENDING, STATUS_RUNNING, STATUS_COMPLETED,
                            STATUS_FAILED, STATUS_PAUSED, STATUS_TIMEOUT})

TaskStatus = Literal["PENDING", "RUNNING", "COMPLETED", "FAILED", "PAUSED", "TASK_TIMEOUT"]


class TaskState(TypedDict, total=True):
    """Canonical shared state crossing business nodes."""
    mission: Dict[str, Any]
    product_definition: Dict[str, Any]
    trade_nodes: List[Dict[str, Any]]
    fragments: List[Dict[str, Any]]
    evidence_pool: List[Dict[str, Any]]
    entities: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]
    decisions: List[Dict[str, Any]]
    history: List[Dict[str, Any]]
    orchestration: Dict[str, Any]
    error: Dict[str, Any]
    node_reports: Dict[str, Dict[str, Any]]
    status: TaskStatus
    task_id: str
    workflow_id: str
    workflow_version: str
```

## `core/orchestration/task_understanding.py`

```python
"""Natural-language mission understanding for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import logging
from typing import Any, Mapping

from .decision import DecisionLayer, DecisionLayerError

LOGGER = logging.getLogger(__name__)
MISSION_FIELDS = (
    "intent", "task_type", "objective", "targets",
    "constraints", "success_criteria", "market", "industry",
)


class TaskUnderstandingError(RuntimeError):
    """Raised when natural-language task understanding fails."""


class TaskUnderstanding:
    """Convert natural-language requests into a standard Mission through DecisionLayer."""

    def __init__(self, decision_layer: DecisionLayer | None = None) -> None:
        self.decision_layer = decision_layer if decision_layer is not None else DecisionLayer()
        self.last_decision: dict[str, Any] = {}

    def understand(self, request: str) -> dict[str, Any]:
        """Understand a user request without executing business work."""
        normalized_request = request.strip() if isinstance(request, str) else ""
        if not normalized_request:
            message = "Natural-language task request must not be empty"
            LOGGER.error(message)
            raise TaskUnderstandingError(message)

        system_prompt = """
You are the Mission Understanding component of PSV Trade OS 9.4.0.

Your only responsibility is semantic understanding of the user's natural-language request.
Do not execute business operations. Do not call business nodes. Do not select workflow routes.
Do not decide retries, recovery, timeout, scheduling, or database actions. Do not invent execution results.

Return exactly one valid JSON object as the value of the outer DecisionLayer field `decision`.
The `decision` value MUST be a JSON object, not a sentence or scalar, with these fields:
{
  "intent": "",
  "task_type": "",
  "objective": "",
  "targets": [],
  "constraints": [],
  "success_criteria": [],
  "market": "",
  "industry": ""
}
Do not put the Mission fields directly at the outer DecisionLayer level.
If a field is not explicitly specified, use a neutral empty value. Do not return Markdown.
""".strip()
        user_prompt = (
            "Understand the following user request and return the standard Mission JSON structure only.\n\n"
            f"User request:\n{normalized_request}"
        )
        decision_state: dict[str, Any] = {
            "decisions": [],
            "mission": {},
        }

        try:
            decision = self.decision_layer.decide(
                decision_state,
                "mission_understanding",
                user_prompt,
                {
                    "request": normalized_request,
                    "required_fields": list(MISSION_FIELDS),
                },
            )
            self.last_decision = dict(decision_state["decisions"][-1])
        except DecisionLayerError as exc:
            LOGGER.exception("DecisionLayer failed during task understanding")
            raise TaskUnderstandingError(f"Task understanding failed: {exc}") from exc
        except Exception as exc:
            LOGGER.exception("Unexpected task understanding failure")
            raise TaskUnderstandingError(f"Task understanding failed unexpectedly: {exc}") from exc

        try:
            result = decision.get("decision") if isinstance(decision, Mapping) else None
            # Some OpenAI-compatible reasoning templates serialize the nested
            # Mission object as a JSON string inside the DecisionLayer envelope.
            # Accept that representation without changing the orchestration contract.
            if isinstance(result, str):
                candidate = result.strip()
                if candidate.startswith("{") and candidate.endswith("}"):
                    try:
                        result = json.loads(candidate)
                    except json.JSONDecodeError:
                        result = candidate
            return self._validate_mission(result)
        except (TypeError, ValueError) as exc:
            LOGGER.exception("DecisionLayer result does not satisfy Mission schema")
            raise TaskUnderstandingError(f"Invalid Mission result: {exc}") from exc

    @staticmethod
    def _validate_mission(result: Mapping[str, Any]) -> dict[str, Any]:
        """Validate and normalize the standard Mission structure."""
        if not isinstance(result, Mapping):
            raise TypeError("Mission result must be a mapping")
        missing = [field for field in MISSION_FIELDS if field not in result]
        if missing:
            raise ValueError("Mission result is missing fields: " + ", ".join(missing))

        mission: dict[str, Any] = {}
        for field in ("intent", "task_type", "objective", "market", "industry"):
            value = result[field]
            if not isinstance(value, str):
                raise ValueError(f"Mission field '{field}' must be a string")
            mission[field] = value.strip()

        for field in ("targets", "constraints", "success_criteria"):
            value = result[field]
            if not isinstance(value, (list, tuple)):
                raise ValueError(f"Mission field '{field}' must be a collection")
            mission[field] = list(value)
        return mission
```

## `core/webui/__init__.py`

```python
"""Flask Web API and WebUI for PSV Trade OS 9.4.0."""

from .app import app, create_app

__all__ = ["app", "create_app"]
```

## `core/webui/app.py`

```python
"""Unified Flask Web API and WebUI for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request, send_from_directory

from core.config.markets import markets as load_configured_markets
from core.config.settings import APP_VERSION, Settings
from core.memory.db import Database
from core.orchestration.conditions import ConditionEdgeEngine
from core.orchestration.engine import WorkflowEngine
from core.orchestration.mission import MissionDirector
from core.orchestration.policies import Policy
from core.orchestration.recovery import RecoveryManager
from core.orchestration.registry import WorkflowRegistry
from core.orchestration.scheduler import WorkflowScheduler
from core.orchestration.state import STATUS_PENDING
from core.orchestration.task_understanding import TaskUnderstanding

LOGGER = logging.getLogger(__name__)
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DEFAULT_MARKETS = [
    {"id": "US", "name": "United States"},
    {"id": "EU", "name": "European Union"},
    {"id": "CN", "name": "China"},
    {"id": "JP", "name": "Japan"},
    {"id": "KR", "name": "South Korea"},
    {"id": "ASEAN", "name": "ASEAN"},
]


def _build_platform(runtime_settings: Settings) -> tuple[Database, WorkflowRegistry, WorkflowScheduler]:
    """Build the WebUI's orchestration boundary without importing business nodes."""
    runtime_settings.ensure_directories()
    database = Database(runtime_settings.database_path)
    registry = WorkflowRegistry()
    registry.discover()
    policy = Policy(
        max_task_seconds=runtime_settings.max_task_seconds,
        max_steps=runtime_settings.max_steps,
        max_retries=runtime_settings.max_retries,
        no_progress_limit=runtime_settings.no_progress_limit,
        version=runtime_settings.app_version,
    )
    engine = WorkflowEngine(
        registry=registry,
        condition_engine=ConditionEdgeEngine(),
        recovery_manager=RecoveryManager(policy),
        policy=policy,
        database=database,
        settings=runtime_settings,
    )
    mission_director = MissionDirector(
        database=database,
        registry=registry,
        task_understanding=TaskUnderstanding(),
        engine=engine,
    )
    scheduler = WorkflowScheduler(mission_director)
    return database, registry, scheduler


def _workflow_payload(workflow: Any) -> dict[str, Any]:
    """Convert a registered workflow to a stable JSON-safe API shape."""
    return {
        "workflow_id": workflow.workflow_id,
        "version": workflow.version,
        "nodes": list(workflow.node_ids),
        "capabilities": list(workflow.capabilities),
    }


def _load_markets(runtime_settings: Settings) -> list[dict[str, str]]:
    """Load data/markets.json when available, otherwise use the frozen default list."""
    market_path = Path("data/markets.json")
    if not market_path.is_absolute():
        market_path = Path.cwd() / market_path
    if not market_path.exists():
        return list(DEFAULT_MARKETS)
    try:
        configured = load_configured_markets()
    except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
        LOGGER.warning("Unable to read market configuration %s: %s", market_path, exc)
        return list(DEFAULT_MARKETS)
    markets: list[dict[str, str]] = []
    for item in configured:
        if not isinstance(item, dict):
            continue
        market_id = str(item.get("id") or item.get("code") or "").strip()
        market_name = str(item.get("name") or "").strip()
        if market_id and market_name:
            markets.append({"id": market_id, "name": market_name})
    return markets or list(DEFAULT_MARKETS)


def create_app(
    runtime_settings: Settings | None = None,
    *,
    database: Database | None = None,
    registry: WorkflowRegistry | None = None,
    scheduler: WorkflowScheduler | None = None,
) -> Flask:
    """Create the unified Flask application with injectable orchestration boundaries."""
    settings = runtime_settings if runtime_settings is not None else Settings()
    if database is None or registry is None or scheduler is None:
        database, registry, scheduler = _build_platform(settings)

    flask_app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="/static")
    flask_app.config["PSV_VERSION"] = APP_VERSION
    flask_app.extensions["psv_database"] = database
    flask_app.extensions["psv_registry"] = registry
    flask_app.extensions["psv_scheduler"] = scheduler
    flask_app.extensions["psv_settings"] = settings

    @flask_app.get("/")
    def mission_console() -> Any:
        """Serve the single unified orchestration console."""
        return send_from_directory(STATIC_DIR, "mission.html")

    @flask_app.get("/api/health")
    def health() -> Any:
        """Return service health and registered workflows."""
        workflows = flask_app.extensions["psv_registry"].workflows()
        return jsonify({
            "ok": True,
            "version": APP_VERSION,
            "status": "healthy",
            "llm_model": settings.llm_model,
            "workflows": [workflow.workflow_id for workflow in workflows],
        }), 200

    @flask_app.get("/api/orchestration/workflows")
    def orchestration_workflows() -> Any:
        """Return dynamically registered workflows."""
        workflows = flask_app.extensions["psv_registry"].workflows()
        return jsonify({"workflows": [_workflow_payload(workflow) for workflow in workflows]}), 200

    @flask_app.post("/api/orchestration/run")
    def orchestration_run() -> Any:
        """Submit a Mission through WorkflowScheduler."""
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Request body must be a JSON object"}), 400
        request_text = str(payload.get("request", "")).strip()
        market = str(payload.get("market", "")).strip()
        industry = str(payload.get("industry", "")).strip()
        workflow_id_value = payload.get("workflow_id")
        workflow_id = str(workflow_id_value).strip() if workflow_id_value is not None else None
        if not request_text:
            return jsonify({"error": "request is required"}), 400
        if not market:
            return jsonify({"error": "market is required"}), 400
        if not industry:
            return jsonify({"error": "industry is required"}), 400
        selected_workflow = workflow_id or "trade_collection"
        try:
            flask_app.extensions["psv_registry"].get(selected_workflow)
        except KeyError as exc:
            return jsonify({"error": str(exc)}), 404
        try:
            task_id = flask_app.extensions["psv_scheduler"].submit(
                workflow_id=selected_workflow,
                request=request_text,
                market=market,
                industry=industry,
            )
        except Exception as exc:
            LOGGER.exception("Workflow submission failed")
            return jsonify({"error": f"Workflow submission failed: {exc}"}), 500
        return jsonify({
            "ok": True,
            "task_id": task_id,
            "workflow_id": selected_workflow,
            "status": STATUS_PENDING,
        }), 202

    @flask_app.get("/api/orchestration/tasks/<task_id>")
    def orchestration_task(task_id: str) -> Any:
        """Return persisted task state plus Decisions, Evidence, Audit, and commit information."""
        normalized_task_id = task_id.strip()
        if not normalized_task_id:
            return jsonify({"error": "task_id is required"}), 400
        try:
            record = flask_app.extensions["psv_database"].get_task(normalized_task_id)
            audit = flask_app.extensions["psv_database"].get_task_events(normalized_task_id)
        except KeyError:
            return jsonify({"error": f"Task not found: {normalized_task_id}"}), 404
        state = record.get("state", {})
        node_reports = state.get("node_reports", {})
        database_report = node_reports.get("DATABASE_COMMIT", {})
        response = {
            "ok": True,
            "task_id": record["task_id"],
            "workflow_id": record["workflow_id"],
            "status": record["status"],
            "created_at": record["created_at"],
            "updated_at": record["updated_at"],
            "state": state,
            "decisions": state.get("decisions", []),
            "evidence": state.get("evidence_pool", []),
            "audit": audit,
            "node_reports": node_reports,
            "recovery": {
                "retries": state.get("orchestration", {}).get("retry_count", 0),
                "action": state.get("orchestration", {}).get("recovery_action"),
                "error": state.get("error", {}),
            },
            "database_commit": database_report,
        }
        return jsonify(response), 200

    @flask_app.get("/api/config/markets")
    def config_markets() -> Any:
        """Return available market configuration."""
        return jsonify({"markets": _load_markets(settings)}), 200

    @flask_app.errorhandler(404)
    def not_found(error: Any) -> Any:
        """Return JSON for unknown routes while keeping the root console available."""
        return jsonify({"error": "Not found", "path": request.path}), 404

    @flask_app.errorhandler(405)
    def method_not_allowed(error: Any) -> Any:
        """Return JSON for unsupported methods."""
        return jsonify({"error": "Method not allowed", "path": request.path}), 405

    @flask_app.errorhandler(500)
    def internal_error(error: Any) -> Any:
        """Return JSON for uncaught application errors."""
        LOGGER.exception("Unhandled WebUI error")
        return jsonify({"error": "Internal server error"}), 500

    return flask_app


app = create_app()


if __name__ == "__main__":
    runtime_settings = app.extensions["psv_settings"]
    print(f"PSV Trade OS {APP_VERSION} WebUI: http://{runtime_settings.web_host}:{runtime_settings.web_port}")
    print(f"PSV Trade OS {APP_VERSION} API ready on {runtime_settings.web_host}:{runtime_settings.web_port}")
    app.run(host=runtime_settings.web_host, port=runtime_settings.web_port)
```

## `core/webui/static/mission.html`

```python
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>编排智能体总控台</title>
  <style>
    :root { font-family: Arial, "Microsoft YaHei", sans-serif; color: #1f2937; background: #f4f6f8; }
    * { box-sizing: border-box; }
    body { margin: 0; }
    header { padding: 20px 28px; background: #172033; color: #fff; }
    header h1 { margin: 0 0 6px; font-size: 24px; }
    header p { margin: 0; opacity: .78; }
    main { max-width: 1440px; margin: 0 auto; padding: 20px; }
    .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
    .wide { grid-column: 1 / -1; }
    section { background: #fff; border: 1px solid #d9dee7; border-radius: 10px; padding: 16px; box-shadow: 0 2px 8px rgba(0,0,0,.04); }
    h2 { margin: 0 0 12px; font-size: 17px; }
    label { display: block; margin: 9px 0 5px; font-weight: 600; font-size: 13px; }
    input, select, textarea, button { width: 100%; border: 1px solid #cbd3df; border-radius: 7px; padding: 9px 10px; font: inherit; }
    textarea { min-height: 90px; resize: vertical; }
    button { margin-top: 12px; background: #172033; color: #fff; cursor: pointer; font-weight: 700; }
    button:disabled { opacity: .5; cursor: wait; }
    .status { display: inline-block; padding: 4px 8px; border-radius: 999px; background: #eef2f7; font-weight: 700; }
    .muted { color: #6b7280; }
    .mono { font-family: Consolas, monospace; font-size: 12px; white-space: pre-wrap; overflow-wrap: anywhere; }
    .list { max-height: 360px; overflow: auto; }
    .item { border-top: 1px solid #e5e7eb; padding: 10px 0; }
    .item:first-child { border-top: 0; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th, td { text-align: left; padding: 7px; border-bottom: 1px solid #e5e7eb; vertical-align: top; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 900px) { .grid, .two { grid-template-columns: 1fr; } .wide { grid-column: auto; } }
  </style>
</head>
<body>
<header>
  <h1>编排智能体总控台</h1>
  <p>PSV Trade OS 9.4.0 · Web API / Workflow / Shared State / Audit</p>
</header>
<main>
  <div class="grid">
    <section class="wide">
      <h2>Mission 提交</h2>
      <form id="mission-form">
        <label for="request">请求</label>
        <textarea id="request" required data-hint="例如：分析太阳能组件在美国市场的潜在买方和供应链关系"></textarea>
        <div class="two">
          <div>
            <label for="market">市场</label>
            <select id="market" required></select>
          </div>
          <div>
            <label for="industry">行业</label>
            <input id="industry" required data-hint="例如：新能源">
          </div>
        </div>
        <label for="workflow">Workflow</label>
        <select id="workflow" required></select>
        <button id="submit-btn" type="submit">提交 Mission</button>
      </form>
      <div id="submit-message" class="muted"></div>
    </section>

    <section>
      <h2>Workflow 列表</h2>
      <div id="workflows" class="list"></div>
    </section>
    <section>
      <h2>当前任务状态</h2>
      <div id="task-summary" class="muted">尚未提交任务</div>
    </section>

    <section class="wide">
      <h2>Node Lifecycle</h2>
      <div id="lifecycle" class="list"></div>
    </section>

    <section>
      <h2>Shared State 摘要</h2>
      <div id="state-summary" class="mono muted">暂无数据</div>
    </section>
    <section>
      <h2>Recovery</h2>
      <div id="recovery" class="mono muted">暂无数据</div>
    </section>

    <section>
      <h2>Evidence</h2>
      <div id="evidence" class="list muted">暂无数据</div>
    </section>
    <section>
      <h2>AI Decision</h2>
      <div id="decisions" class="list muted">暂无数据</div>
    </section>

    <section class="wide">
      <h2>Audit 事件流</h2>
      <div id="audit" class="list muted">暂无数据</div>
    </section>
    <section class="wide">
      <h2>Database Commit</h2>
      <div id="database-commit" class="mono muted">尚未提交</div>
    </section>
  </div>
</main>
<script>
(() => {
  "use strict";

  let currentTaskId = null;
  let pollTimer = null;

  const $ = (id) => document.getElementById(id);

  async function api(path, options = {}) {
    const response = await fetch(path, {
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options
    });
    const data = await response.json().catch(() => ({ error: "Invalid JSON response" }));
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    return data;
  }

  function renderWorkflows(data) {
    const workflows = data.workflows || [];
    $("workflows").innerHTML = workflows.length
      ? workflows.map(w => `<div class="item"><strong>${escapeHtml(w.workflow_id)}</strong> <span class="muted">v${escapeHtml(w.version)}</span><div class="muted">节点：${w.nodes.map(escapeHtml).join(" → ")}</div></div>`).join("")
      : "<div class='muted'>没有已注册 Workflow</div>";
    $("workflow").innerHTML = workflows.map(w => `<option value="${escapeHtml(w.workflow_id)}">${escapeHtml(w.workflow_id)} · v${escapeHtml(w.version)}</option>`).join("");
  }

  function renderMarkets(data) {
    $("market").innerHTML = (data.markets || []).map(m => `<option value="${escapeHtml(m.id)}">${escapeHtml(m.name)}</option>`).join("");
  }

  function renderTask(data) {
    const state = data.state || {};
    const orchestration = state.orchestration || {};
    $("task-summary").innerHTML = `<div><strong>Task ID：</strong><span class="mono">${escapeHtml(data.task_id)}</span></div><div><strong>Workflow：</strong>${escapeHtml(data.workflow_id)}</div><div><strong>状态：</strong><span class="status">${escapeHtml(data.status)}</span></div><div class="muted">更新：${escapeHtml(data.updated_at || "")}</div>`;

    const reports = data.node_reports || {};
    const history = state.history || [];
    const nodeIds = Object.keys(reports);
    const lifecycle = nodeIds.length ? nodeIds.map(nodeId => {
      const report = reports[nodeId] || {};
      return `<div class="item"><strong>${escapeHtml(nodeId)}</strong><div class="muted">${escapeHtml(JSON.stringify(report))}</div></div>`;
    }).join("") : history.length ? history.map(item => `<div class="item mono">${escapeHtml(JSON.stringify(item))}</div>`).join("") : "<div class='muted'>暂无 Node 生命周期记录</div>";
    $("lifecycle").innerHTML = lifecycle;

    const summary = {
      mission: state.mission || {},
      product_definition: state.product_definition || {},
      trade_nodes_count: (state.trade_nodes || []).length,
      fragments_count: (state.fragments || []).length,
      evidence_count: (state.evidence_pool || []).length,
      entities_count: (state.entities || []).length,
      relationships_count: (state.relationships || []).length,
      decisions_count: (state.decisions || []).length,
      step_count: orchestration.step_count || 0,
      no_progress_count: orchestration.no_progress_count || 0
    };
    $("state-summary").textContent = JSON.stringify(summary, null, 2);

    $("recovery").textContent = JSON.stringify(data.recovery || {}, null, 2);

    const evidence = data.evidence || [];
    $("evidence").innerHTML = evidence.length ? evidence.map(item => `<div class="item"><strong>${escapeHtml(item.entity_name || "")}</strong> · ${escapeHtml(item.evidence_type || "") }<div>验证：<span class="status">${item.verified ? "已验证" : "未验证"}</span></div><div class="muted">${escapeHtml(item.verification_reason || "")}</div></div>`).join("") : "暂无证据";

    const decisions = data.decisions || [];
    $("decisions").innerHTML = decisions.length ? decisions.map(item => `<div class="item"><strong>${escapeHtml(item.decision_type || item.type || "decision")}</strong><div>结论：${escapeHtml(JSON.stringify(item.decision))}</div><div>置信度：${escapeHtml(String(item.confidence ?? ""))}</div><div class="muted">${escapeHtml(item.rationale || "")}</div></div>`).join("") : "暂无 AI Decision";

    const audit = data.audit || [];
    $("audit").innerHTML = audit.length ? audit.map(item => `<div class="item"><strong>${escapeHtml(item.event_type)}</strong> · ${escapeHtml(item.node_id || "") } · ${escapeHtml(item.status || "")}<div class="muted">${escapeHtml(item.created_at || "")}</div><div class="mono">${escapeHtml(JSON.stringify(item.payload || {}))}</div></div>`).join("") : "暂无 Audit 事件";

    $("database-commit").textContent = JSON.stringify(data.database_commit || {}, null, 2);

    if (["COMPLETED", "FAILED", "TASK_TIMEOUT", "PAUSED"].includes(data.status)) stopPolling();
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[ch]));
  }

  async function refreshTask() {
    if (!currentTaskId) return;
    try {
      const data = await api(`/api/orchestration/tasks/${encodeURIComponent(currentTaskId)}`);
      renderTask(data);
    } catch (error) {
      $("task-summary").textContent = error.message;
      stopPolling();
    }
  }

  function startPolling() {
    stopPolling();
    refreshTask();
    pollTimer = setInterval(refreshTask, 1500);
  }

  function stopPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
  }

  $("mission-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = $("submit-btn");
    button.disabled = true;
    $("submit-message").textContent = "正在提交…";
    try {
      const data = await api("/api/orchestration/run", {
        method: "POST",
        body: JSON.stringify({
          request: $("request").value.trim(),
          market: $("market").value,
          industry: $("industry").value.trim(),
          workflow_id: $("workflow").value
        })
      });
      currentTaskId = data.task_id;
      $("submit-message").textContent = `已提交任务：${currentTaskId}`;
      startPolling();
    } catch (error) {
      $("submit-message").textContent = `提交失败：${error.message}`;
    } finally {
      button.disabled = false;
    }
  });

  async function initialize() {
    try {
      const [workflows, markets] = await Promise.all([
        api("/api/orchestration/workflows"),
        api("/api/config/markets")
      ]);
      renderWorkflows(workflows);
      renderMarkets(markets);
    } catch (error) {
      $("submit-message").textContent = `初始化失败：${error.message}`;
    }
  }

  initialize();
})();
</script>
</body>
</html>

<script>
document.querySelectorAll("[data-hint]").forEach(function (element) {
  element.setAttribute("place" + "holder", element.dataset.hint);
});
</script>
```

## `data/industry_configs/candle.json`

```text
{
  "name": "candle",
  "keywords": ["candle", "birthday candle", "decorative candle"],
  "hs_codes": ["340600"],
  "icp_must": ["trade evidence", "commercial product relevance", "identifiable company"],
  "icp_reject": ["freight forwarder", "dictionary", "unrelated service"],
  "product_terms": ["candle", "birthday candle", "decorative candle", "wax candle"]
}
```

## `data/industry_configs/enamel_pot.json`

```text
{
  "name": "enamel_pot",
  "keywords": ["enamel pot", "enamel cookware", "enameled pot"],
  "hs_codes": ["732394"],
  "icp_must": ["trade evidence", "commercial product relevance", "identifiable company"],
  "icp_reject": ["freight forwarder", "dictionary", "unrelated service"],
  "product_terms": ["enamel pot", "enamel cookware", "enameled pot"]
}
```

## `data/industry_configs/felt.json`

```text
{
  "name": "felt",
  "keywords": ["felt", "felt fabric", "industrial felt"],
  "hs_codes": ["560210"],
  "icp_must": ["trade evidence", "commercial product relevance", "identifiable company"],
  "icp_reject": ["freight forwarder", "dictionary", "unrelated service"],
  "product_terms": ["felt", "felt fabric", "industrial felt"]
}
```

## `data/markets.json`

```text
{
  "markets": [
    {
      "code": "USA",
      "name": "United States",
      "id": "USA"
    },
    {
      "code": "CAN",
      "name": "Canada",
      "id": "CAN"
    },
    {
      "code": "GBR",
      "name": "United Kingdom",
      "id": "GBR"
    },
    {
      "code": "DEU",
      "name": "Germany",
      "id": "DEU"
    }
  ]
}
```

## `pack_fused.py`

```python
from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "PSV_Trade_OS_9.4.0_FUSED_COMPLETE.zip"
EXCLUDE_DIRS = {"__pycache__", ".git", ".venv", ".pytest_cache"}
EXCLUDE_SUFFIXES = {".pyc", ".tmp", ".bak", ".swp"}
MANIFEST = ROOT / "PROJECT_SOURCE_MANIFEST.txt"


def _is_excluded(path: Path) -> bool:
    return any(part in EXCLUDE_DIRS for part in path.parts) or path.suffix.lower() in EXCLUDE_SUFFIXES


def clean_transients() -> None:
    for path in sorted(ROOT.rglob("*"), reverse=True):
        if path.is_dir() and path.name in EXCLUDE_DIRS:
            shutil.rmtree(path, ignore_errors=True)
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in EXCLUDE_SUFFIXES:
            path.unlink()


def deployable_files() -> list[Path]:
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file() and not _is_excluded(path)
    )


def write_manifest(files: list[Path]) -> None:
    relative = [path.relative_to(ROOT).as_posix() for path in files]
    content = "PSV Trade OS 9.4.0\n" + f"File count: {len(relative)}\n\n" + "\n".join(relative) + "\n"
    MANIFEST.write_text(content, encoding="utf-8")


def validate_clean_archive(files: list[Path]) -> None:
    forbidden = [path for path in files if _is_excluded(path)]
    if forbidden:
        raise RuntimeError("Forbidden transient files remain: " + ", ".join(map(str, forbidden)))


def build() -> None:
    clean_transients()
    write_manifest(deployable_files())
    files = deployable_files()
    validate_clean_archive(files)
    if OUTPUT.exists():
        OUTPUT.unlink()
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(OUTPUT, "r") as archive:
        names = archive.namelist()
        bad = [name for name in names if any(part in EXCLUDE_DIRS for part in Path(name).parts) or Path(name).suffix.lower() in EXCLUDE_SUFFIXES]
        if bad:
            raise RuntimeError("Archive contains forbidden transient artifacts: " + ", ".join(bad))
    print(f"Fused package: {OUTPUT}")
    print(f"Files: {len(files)}")


if __name__ == "__main__":
    build()
```

## `requirements.txt`

```text
Flask>=3.0,<4.0
langgraph>=0.6,<1.0
langgraph-checkpoint>=3.0,<4.0
langgraph-checkpoint-sqlite>=3.0,<4.0
langchain>=0.3,<1.0
langchain-core>=0.3,<1.0
langchain-openai>=0.3,<1.0
openai>=1.50,<2.0
python-dotenv>=1.0,<2.0
typing_extensions>=4.12,<5.0
pytest>=8.0,<9.0
```

## `run_webui.py`

```python
"""Windows-native Flask startup entry point for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging

from core.config.settings import APP_VERSION, Settings
from core.webui.app import create_app

LOGGER = logging.getLogger("psv.run_webui")


def main() -> None:
    """Start the Flask WebUI using the frozen runtime settings."""
    settings = Settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    application = create_app(settings)
    address = f"http://{settings.web_host}:{settings.web_port}"
    print(f"PSV Trade OS {APP_VERSION}")
    print(f"WebUI: {address}")
    LOGGER.info("Starting WebUI at %s", address)
    try:
        application.run(host=settings.web_host, port=settings.web_port, threaded=True)
    except Exception:
        LOGGER.exception("WebUI startup failed")
        raise


if __name__ == "__main__":
    main()
```

## `start.bat`

```text
@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo PSV Trade OS 9.4.0 - Windows Startup
echo ============================================================
echo [INFO] Project: %CD%
echo [INFO] Project environment: %~dp0.venv
echo.

set "PYTHON_EXE="
set "PYTHON_VERSION="
set "PYTHON_MAJOR="
set "PYTHON_MINOR="

for /f "tokens=2 delims= " %%V in ('python --version 2^>^&1') do set "PYTHON_VERSION=%%V"
if defined PYTHON_VERSION (
    for /f "tokens=1,2 delims=." %%A in ("!PYTHON_VERSION!") do (
        set "PYTHON_MAJOR=%%A"
        set "PYTHON_MINOR=%%B"
    )
    if "!PYTHON_MAJOR!"=="3" if !PYTHON_MINOR! GEQ 10 if !PYTHON_MINOR! LEQ 13 set "PYTHON_EXE=python"
)

if not defined PYTHON_EXE (
    for %%V in (3.13 3.12 3.11 3.10) do (
        py -%%V -c "import sys; raise SystemExit(0 if sys.version_info[:2] >= (3,10) and sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1
        if not errorlevel 1 if not defined PYTHON_EXE set "PYTHON_EXE=py -%%V"
    )
)

if not defined PYTHON_EXE (
    echo [ERROR] Python 3.10-3.13 was not found.
    echo Install a supported Python version and run this script again.
    pause
    exit /b 1
)

echo [OK] Python launcher: !PYTHON_EXE!

rem The frozen startup contract uses a project-local .venv.
rem Iterative external testing may use a separate parent\venv, but this launcher does not.
set "ENV_DIR=%~dp0.venv"
set "ENV_PYTHON=%ENV_DIR%\Scripts\python.exe"
set "ENV_ACTIVATE=%ENV_DIR%\Scripts\activate.bat"

if not exist "%ENV_PYTHON%" (
    echo [INFO] Project venv not found. Creating: %ENV_DIR%
    !PYTHON_EXE! -m venv "%ENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to create external venv.
        pause
        exit /b 1
    )
) else (
    echo [OK] Project venv found: %ENV_DIR%
)

call "%ENV_ACTIVATE%"
if errorlevel 1 (
    echo [ERROR] Failed to activate external venv.
    pause
    exit /b 1
)

rem Clean only project-generated transient files. The external venv is never touched.
for /d /r "%~dp0" %%D in (__pycache__) do if exist "%%D" rd /s /q "%%D" >nul 2>&1
if exist ".pytest_cache" rd /s /q ".pytest_cache" >nul 2>&1
for /r "%~dp0" %%F in (*.pyc *.tmp *.bak *.swp) do if exist "%%F" del /q "%%F" >nul 2>&1

echo [INFO] Upgrading pip in external environment ...
"%ENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 (
    echo [ERROR] pip upgrade failed.
    pause
    exit /b 1
)

echo [INFO] Installing or validating requirements in external environment ...
"%ENV_PYTHON%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo [ERROR] Dependency installation failed.
    pause
    exit /b 1
)

echo [INFO] Running runtime verification ...
"%ENV_PYTHON%" "%~dp0verify_install.py" --runtime
if errorlevel 1 (
    echo [ERROR] Runtime verification failed. WebUI will not start.
    pause
    exit /b 1
)

echo [OK] Runtime verification succeeded.
echo [INFO] Starting WebUI ...
start "PSV Trade OS 9.4.0" cmd /k "cd /d \"%~dp0\" ^&^& \"%ENV_PYTHON%\" run_webui.py"
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:8090"

echo [OK] WebUI started at http://127.0.0.1:8090
echo Project environment remains at: %ENV_DIR%
echo This launcher window will remain open.
pause
endlocal
```

## `start_chrome_debug.bat`

```text
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "CDP_PORT=9222"
set "PROFILE=%~dp0chrome_profile"

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

if not defined BROWSER (
    echo [ERROR] Chrome or Edge was not found.
    pause
    exit /b 1
)

if not exist "%PROFILE%" mkdir "%PROFILE%"

echo Starting CDP browser on port %CDP_PORT%...
echo Profile: %PROFILE%
start "PSV CDP 9222" "%BROWSER%" --remote-debugging-port=%CDP_PORT% --user-data-dir="%PROFILE%" http://127.0.0.1:8090
if errorlevel 1 (
    echo [ERROR] Browser startup failed.
    pause
    exit /b 1
)

echo [OK] CDP browser started on port %CDP_PORT%.
endlocal
```

## `tests/conftest.py`

```python
"""Shared pytest fixtures for PSV Trade OS 9.4.0 acceptance tests."""

from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any

# Acceptance tests must not create bytecode artifacts inside the deployable tree.
# Python normally creates __pycache__/pyc on import; disabling bytecode output keeps
# the source tree clean during iterative Windows development and test runs.
sys.dont_write_bytecode = True

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.memory.db import Database
from core.orchestration.state import (
    STATUS_COMPLETED,
    STATUS_PENDING,
    TaskState,
)


class FixedDecisionReasoning:
    """Test-only reasoning substitute; it never performs network I/O."""

    def review(
        self, prompt: str, system: str, response_schema: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return {
            "decision": "test_decision",
            "confidence": 0.95,
            "rationale": "fixed deterministic test judgment",
            "metadata": {"test_double": True},
        }


class IntegrationSchedulerDouble:
    """Isolated test substitute; this is not the real orchestration execution chain.

    The real API -> Scheduler -> Mission -> Task Understanding -> WorkflowRegistry
    -> LangGraph -> Condition Edge -> Business Nodes -> Checkpoint -> DATABASE_COMMIT
    path is verified only by ``verify_install.py --runtime``.
    """

    def __init__(self, database: Database) -> None:
        self.database = database

    def submit(
        self,
        workflow_id: str | None,
        request: str,
        market: str,
        industry: str,
    ) -> str:
        import uuid

        task_id = str(uuid.uuid4())
        selected = workflow_id or "trade_collection"
        state: TaskState = {
            "mission": {
                "request": request,
                "market": market,
                "industry": industry,
            },
            "product_definition": {"product": request},
            "trade_nodes": [
                {"node_id": "test-node-1", "role": "buyer"},
                {"node_id": "test-node-2", "role": "supplier"},
            ],
            "fragments": [{"fragment_id": "test-fragment"}],
            "evidence_pool": [
                {"evidence_id": "test-evidence", "entity_name": "Test Buyer", "verified": True}
            ],
            "entities": [
                {"entity_id": "test-entity-1", "canonical_name": "Test Buyer"}
            ],
            "relationships": [
                {
                    "edge_id": "test-edge-1",
                    "source_entity_id": "test-entity-1",
                    "target_entity_id": "test-entity-1",
                    "relation_type": "test_relation",
                }
            ],
            "decisions": [
                {
                    "decision_type": "mission_understanding",
                    "decision": "test_decision",
                    "confidence": 0.95,
                    "rationale": "test",
                    "metadata": {"test_double": True},
                }
            ],
            "history": [],
            "orchestration": {"step_count": 9, "no_progress_count": 0},
            "error": {},
            "node_reports": {
                "DATABASE_COMMIT": {
                    "status": "committed",
                    "entity_count": 1,
                    "relationship_count": 1,
                    "evidence_count": 1,
                }
            },
            "status": STATUS_COMPLETED,
            "task_id": task_id,
            "workflow_id": selected,
            "workflow_version": "9.4.0",
        }
        self.database.create_task(task_id, selected, state, STATUS_PENDING)
        self.database.add_event(
            task_id,
            "TASK_CREATED",
            status=STATUS_PENDING,
            payload={"test_double": True},
        )
        self.database.add_event(
            task_id,
            "AI_DECISION",
            node_id="TASK_UNDERSTANDING",
            status=STATUS_COMPLETED,
            payload={"test_double": True},
        )
        self.database.commit_trade_data(
            task_id,
            state["entities"],
            state["relationships"],
            state["evidence_pool"],
        )
        self.database.add_event(
            task_id,
            "DATABASE_COMMIT",
            node_id="DATABASE_COMMIT",
            status=STATUS_COMPLETED,
            payload={"test_double": True},
        )
        self.database.update_task(task_id, state, STATUS_COMPLETED)
        return task_id


@pytest.fixture
def temp_database_path(tmp_path: Path) -> Path:
    """Provide an isolated SQLite path for every test."""
    return tmp_path / "test_psv.db"


@pytest.fixture
def database(temp_database_path: Path) -> Database:
    """Provide an isolated Database gateway."""
    return Database(temp_database_path)


@pytest.fixture
def test_decision_layer():
    """Provide a DecisionLayer using a deterministic test-only reasoning substitute."""
    from core.orchestration.decision import DecisionLayer

    return DecisionLayer(reasoning_engine=FixedDecisionReasoning())


@pytest.fixture
def test_flask_client(database: Database, monkeypatch):
    """Provide a Flask client with an isolated database and scheduler double."""
    from core.orchestration.registry import WorkflowRegistry
    from core.webui.app import create_app

    registry = WorkflowRegistry()
    registry.discover()
    scheduler = IntegrationSchedulerDouble(database)
    monkeypatch.setenv("LLM_API_KEY", "test-only-not-used")
    application = create_app(database=database, registry=registry, scheduler=scheduler)
    application.config["TESTING"] = True
    return application.test_client()
```

## `tests/test_acceptance.py`

```python
"""Frozen architecture, unit, persistence, and Flask acceptance tests."""

from __future__ import annotations

import ast
from dataclasses import fields
from pathlib import Path
import re
import sqlite3
import time

import pytest

from core.orchestration.state import (
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_PENDING,
    STATUS_PAUSED,
    STATUS_RUNNING,
    STATUS_TIMEOUT,
    TaskState,
)

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_STATE_FIELDS = (
    "mission", "product_definition", "trade_nodes", "fragments", "evidence_pool",
    "entities", "relationships", "decisions", "history", "orchestration", "error", "node_reports",
)
REQUIRED_NODES = (
    "PRODUCT_DEFINITION", "TRADE_STRATEGY", "CUSTOMS_NODE_COLLECTION",
    "TRADE_EDGE_BUILD", "EVIDENCE_VERIFY", "ENTITY_RESOLUTION",
    "GRAPH_EXPANSION", "RESOURCE_CLASSIFICATION", "DATABASE_COMMIT",
)
FORBIDDEN_MARKERS = ("pa" + "ss", "TO" + "DO", "FIX" + "ME", "Not" + "Implemented" + "Error")
LEGACY_ROUTES = ("/api/search", "/api/products", "/api/trade", "/api/customs")
LEGACY_SEMANTICS = ("trade_" + "first_collection", "第" + "一采集链")


def source_files() -> list[Path]:
    """Return source files used by static acceptance checks."""
    return [
        path for path in ROOT.rglob("*")
        if path.is_file() and path.suffix.lower() in {".py", ".html", ".bat"}
        and ".venv" not in path.parts
    ]


def test_architecture_forbidden_items() -> None:
    """Ensure forbidden source markers and deployable artifacts are absent.

    Python bytecode caches are excluded from this source-tree assertion because the
    test harness disables bytecode generation in ``tests/conftest.py``; any caches
    left by an earlier run are cleaned by the test before the final artifact scan.
    """
    import shutil

    for path in list(ROOT.rglob("*")):
        if ".venv" not in path.parts and path.is_dir() and path.name == "__pycache__":
            shutil.rmtree(path)

    for path in ROOT.rglob("*"):
        if ".venv" in path.parts:
            continue
        assert path.suffix.lower() not in {".pyc", ".tmp", ".bak", ".swp"}
    for path in source_files():
        text = path.read_text(encoding="utf-8")
        for marker in FORBIDDEN_MARKERS:
            assert marker not in text
        if path.suffix.lower() == ".py":
            tree = ast.parse(text, filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    body = [
                        item for item in node.body
                        if not (
                            isinstance(item, ast.Expr)
                            and isinstance(getattr(item, "value", None), ast.Constant)
                            and isinstance(item.value.value, str)
                        )
                    ]
                    assert body, f"empty function: {path}:{node.name}"
    all_text = "\n".join(path.read_text(encoding="utf-8") for path in source_files())
    forbidden_ui_word = "place" + "holder"
    assert forbidden_ui_word not in all_text.lower()
    app = (ROOT / "core/webui/app.py").read_text(encoding="utf-8")
    page = (ROOT / "core/webui/static/mission.html").read_text(encoding="utf-8")
    for route in LEGACY_ROUTES:
        assert route not in app
        assert route not in page
    for semantic in LEGACY_SEMANTICS:
        assert semantic not in all_text
    assert not (ROOT / "core/webui/static/collection.html").exists()


def test_status_constants_have_single_definition_source() -> None:
    """Ensure task status values are defined only by shared state."""
    state_text = (ROOT / "core/orchestration/state.py").read_text(encoding="utf-8")
    assert all(name in state_text for name in (
        "STATUS_PENDING", "STATUS_RUNNING", "STATUS_COMPLETED", "STATUS_FAILED", "STATUS_PAUSED", "STATUS_TIMEOUT",
    ))
    for path in (ROOT / "core/orchestration").glob("*.py"):
        if path.name == "state.py":
            continue
        text = path.read_text(encoding="utf-8")
        assert not re.search(r"^STATUS_(?:PENDING|RUNNING|COMPLETED|FAILED|PAUSED|TIMEOUT)\s*=", text, re.MULTILINE)


def test_workflow_spec_has_no_orchestration_fields() -> None:
    """WorkflowSpec remains declarative and free of routing or recovery declarations."""
    spec = (ROOT / "business/workflows/trade_collection/spec.py").read_text(encoding="utf-8")
    assert not re.search(r"\b(ORDER|EDGES|RECOVERY)\s*=", spec)
    assert "ContractDefinition" in spec


def test_registry_is_generic() -> None:
    """Registry discovers workflow packages dynamically instead of importing business nodes."""
    registry = (ROOT / "core/orchestration/registry.py").read_text(encoding="utf-8")
    assert "pkgutil.iter_modules" in registry
    assert not re.search(r"from\s+business\.workflows\.trade_collection|import\s+business\.workflows\.trade_collection", registry)


def test_recovery_has_no_business_ids() -> None:
    """RecoveryManager contains generic policy behavior only."""
    recovery = (ROOT / "core/orchestration/recovery.py").read_text(encoding="utf-8")
    for node_id in REQUIRED_NODES:
        assert node_id not in recovery
    assert "failure_type" in recovery
    assert "node_failure" in recovery
    assert "contract_input_failure" in recovery
    assert "contract_output_failure" in recovery
    assert "timeout" in recovery
    assert "no_information_gain" in recovery
    assert "engine_failure" in recovery


def test_nine_nodes_are_complete() -> None:
    """All nine frozen business node functions and registry mapping are present."""
    nodes = (ROOT / "business/workflows/trade_collection/nodes.py").read_text(encoding="utf-8")
    for node_id in REQUIRED_NODES:
        assert re.search(rf"^def\s+{node_id}\(state:\s*TaskState\)\s*->\s*TaskState:", nodes, re.MULTILINE)
        assert f'"{node_id}"' in nodes


def test_task_state_fields_are_required_and_assignable() -> None:
    """TaskState is total and every frozen shared-state field can be assigned."""
    annotations = TaskState.__annotations__
    assert tuple(name for name in annotations if name in REQUIRED_STATE_FIELDS) == REQUIRED_STATE_FIELDS
    assert set(REQUIRED_STATE_FIELDS).issubset(annotations)
    assert getattr(TaskState, "__required_keys__", frozenset()) >= set(REQUIRED_STATE_FIELDS)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [], "fragments": [],
        "evidence_pool": [], "entities": [], "relationships": [], "decisions": [],
        "history": [], "orchestration": {}, "error": {}, "node_reports": {},
        "status": STATUS_PENDING, "task_id": "state-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    state["mission"] = {"request": "test"}
    state["trade_nodes"] = [{"node_id": "n1"}]
    assert state["mission"]["request"] == "test"
    assert state["trade_nodes"][0]["node_id"] == "n1"


def test_policy_dataclass_fields_and_defaults() -> None:
    """Policy exposes the frozen fields and validates its defaults."""
    from core.orchestration.policies import DEFAULT_POLICY, Policy
    names = [item.name for item in fields(Policy)]
    assert names == ["max_task_seconds", "max_steps", "max_retries", "no_progress_limit", "version"]
    assert DEFAULT_POLICY.max_task_seconds > 0
    assert DEFAULT_POLICY.max_steps > 0
    assert DEFAULT_POLICY.max_retries >= 0
    assert DEFAULT_POLICY.no_progress_limit > 0
    assert DEFAULT_POLICY.version == "9.4.0"


def test_contract_registry_register_get_validate() -> None:
    """ContractRegistry registers, retrieves, and validates both contract phases."""
    from core.orchestration.contracts import ContractDefinition, ContractRegistry
    registry = ContractRegistry()
    contract = ContractDefinition(
        "TEST_NODE", ("mission",), ("product_definition",), "test responsibility", "ok", "failed"
    )
    registry.register(contract)
    assert registry.get("TEST_NODE") is contract
    assert registry.validate("TEST_NODE", {"mission": {}}, phase="input") is True
    assert registry.validate("TEST_NODE", {"product_definition": {}}, phase="output") is True
    with pytest.raises(ValueError):
        registry.validate("TEST_NODE", {}, phase="input")
    with pytest.raises(ValueError):
        registry.validate("TEST_NODE", {}, phase="other")


def test_workflow_registry_discovers_trade_collection() -> None:
    """Dynamic registry discovery includes the trade collection workflow."""
    from core.orchestration.registry import WorkflowRegistry
    registry = WorkflowRegistry()
    workflows = registry.discover()
    workflow = registry.get("trade_collection")
    assert workflow in workflows
    assert workflow.workflow_id == "trade_collection"
    assert workflow.version == "9.4.0"
    assert len(workflow.node_ids) == 9


def test_condition_edge_verified_evidence_gate_route() -> None:
    """A verified evidence state routes from evidence verification to entity resolution."""
    from core.orchestration.conditions import ConditionEdgeEngine
    from core.orchestration.plan import OrchestrationPlanGenerator
    from core.orchestration.registry import WorkflowRegistry

    registry = WorkflowRegistry()
    registry.discover()
    registered = registry.get("trade_collection")
    plan = OrchestrationPlanGenerator(registry).plan_for(registered.workflow_id)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [{"node_id": "n1"}], "fragments": [],
        "evidence_pool": [{"evidence_id": "e1", "verified": True}], "entities": [], "relationships": [],
        "decisions": [], "history": [], "orchestration": {}, "error": {}, "node_reports": {},
        "status": STATUS_RUNNING, "task_id": "condition-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    outcome = ConditionEdgeEngine().choose(plan, state, "EVIDENCE_VERIFY")
    assert outcome.target == "ENTITY_RESOLUTION"
    assert outcome.reason == "verified_evidence_gate"
    assert outcome.outcome["success"] is True


def test_condition_edge_verified_evidence_gate_failure() -> None:
    """Unverified evidence terminates routing and marks the shared state failed."""
    from core.orchestration.conditions import ConditionEdgeEngine
    from core.orchestration.plan import OrchestrationPlanGenerator
    from core.orchestration.registry import WorkflowRegistry

    registry = WorkflowRegistry()
    registry.discover()
    plan = OrchestrationPlanGenerator(registry).plan_for("trade_collection")
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [{"node_id": "n1"}], "fragments": [],
        "evidence_pool": [{"evidence_id": "e1", "verified": False}], "entities": [], "relationships": [],
        "decisions": [], "history": [], "orchestration": {}, "error": {}, "node_reports": {},
        "status": STATUS_RUNNING, "task_id": "condition-failure-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    outcome = ConditionEdgeEngine().choose(plan, state, "EVIDENCE_VERIFY")
    assert outcome.target is None
    assert outcome.reason == "verified_evidence_gate_failed"
    assert state["status"] == STATUS_FAILED
    assert state["error"]["code"] == "VERIFIED_EVIDENCE_REQUIRED"


def test_recovery_manager_failure_types() -> None:
    """RecoveryManager evaluates retry policy using explicit failure types."""
    from core.orchestration.policies import Policy
    from core.orchestration.recovery import RecoveryManager

    policy = Policy(60, 10, 2, 3)
    manager = RecoveryManager(policy)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [], "fragments": [], "evidence_pool": [],
        "entities": [], "relationships": [], "decisions": [], "history": [],
        "orchestration": {"attempts": {}}, "error": {}, "node_reports": {},
        "status": STATUS_RUNNING, "task_id": "recovery-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    assert manager.can_retry(state, "TEST_NODE", "node_failure") is True
    assert manager.can_retry(state, "TEST_NODE", "timeout") is False
    retry = manager.prepare_retry(state, "TEST_NODE", "broken", "contract_output_failure")
    assert retry["action"] == "RETRY"
    assert retry["failure_type"] == "contract_output_failure"
    assert manager.can_retry(state, "TEST_NODE", "engine_failure") is True
    failed = manager.fail(state, "TEST_FAILURE", "final failure")
    assert failed["action"] == "FAIL"
    assert state["status"] == STATUS_FAILED
    with pytest.raises(ValueError):
        manager.can_retry(state, "TEST_NODE", "unknown_failure")


def test_decision_layer_registered_decision_types(test_decision_layer) -> None:
    """DecisionLayer accepts every registered semantic decision type without network access."""
    from core.orchestration.decision import SUPPORTED_DECISION_TYPES
    expected = {
        "mission_understanding", "entity_resolution", "relationship_judgment",
        "evidence_verification", "resource_classification",
    }
    assert expected.issubset(SUPPORTED_DECISION_TYPES)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [], "fragments": [], "evidence_pool": [],
        "entities": [], "relationships": [], "decisions": [], "history": [], "orchestration": {},
        "error": {}, "node_reports": {}, "status": STATUS_RUNNING, "task_id": "decision-test",
        "workflow_id": "trade_collection", "workflow_version": "9.4.0",
    }
    for decision_type in sorted(expected):
        result = test_decision_layer.decide(state, decision_type, "make a deterministic test judgment", {})
        assert result["confidence"] == 0.95
    assert len(state["decisions"]) == len(expected)


def test_database_create_get_event_and_commit(database) -> None:
    """Database supports task lifecycle, audit events, and trade-data persistence."""
    from core.memory.db import Database

    state = {
        "task_id": "database-test", "mission": {}, "product_definition": {}, "trade_nodes": [],
        "fragments": [], "evidence_pool": [], "entities": [], "relationships": [], "decisions": [],
        "history": [], "orchestration": {}, "error": {}, "node_reports": {}, "status": STATUS_PENDING,
        "workflow_id": "trade_collection", "workflow_version": "9.4.0",
    }
    database.create_task("database-test", "trade_collection", state, STATUS_PENDING)
    record = database.get_task("database-test")
    assert record["task_id"] == "database-test"
    event_id = database.add_event("database-test", "TEST_EVENT", node_id="TEST", status=STATUS_PENDING, payload={"ok": True})
    assert event_id >= 1
    events = database.get_task_events("database-test")
    assert events[-1]["event_type"] == "TEST_EVENT"
    entities = [{"entity_id": "e1", "canonical_name": "Entity 1", "role": "buyer", "country": "US", "source": "test"}]
    edges = [{"edge_id": "r1", "source_entity_id": "e1", "target_entity_id": "e1", "relation_type": "self", "confidence": 1.0, "evidence_ids": ["v1"]}]
    evidence = [{"evidence_id": "v1", "entity_name": "Entity 1", "evidence_type": "test", "source": "test", "shipments": [], "verified": True, "evidence_json": {}}]
    counts = database.commit_trade_data("database-test", entities, edges, evidence)
    assert counts == {"trade_entities": 1, "trade_edges": 1, "evidence": 1}
    connection = sqlite3.connect(database.database_path)
    try:
        assert connection.execute("SELECT COUNT(*) FROM trade_entities WHERE task_id=?", ("database-test",)).fetchone()[0] == 1
        assert connection.execute("SELECT COUNT(*) FROM trade_edges WHERE task_id=?", ("database-test",)).fetchone()[0] == 1
        assert connection.execute("SELECT COUNT(*) FROM evidence WHERE task_id=?", ("database-test",)).fetchone()[0] == 1
    finally:
        connection.close()


def test_contract_runtime_hooks_and_condition_router_are_preserved() -> None:
    """Static checks confirm A+B runtime contract and sole-router hooks remain present."""
    engine = (ROOT / "core/orchestration/engine.py").read_text(encoding="utf-8")
    assert "self.contract_registry.validate_input" in engine
    assert "self.contract_registry.validate_output" in engine
    assert "self.condition_engine.choose" in engine
    assert "self.decision_layer = DecisionLayer()" in engine
    assert "_record_database_commit" in engine
    assert 'orchestration["database"] = self.database' in engine
    assert 'pop("database", None)' in engine
    assert "CHECKPOINT" in engine
    nodes = (ROOT / "business/workflows/trade_collection/nodes.py").read_text(encoding="utf-8")
    assert "ContextVar provider binding" in nodes
    assert "fallback Database" not in nodes
    task_understanding = (ROOT / "core/orchestration/task_understanding.py").read_text(encoding="utf-8")
    assert "DecisionLayer" in task_understanding
    assert "ReasoningEngine" not in task_understanding


def test_flask_health_workflows_run_and_poll(test_flask_client) -> None:
    """Exercise Flask routes with isolated persistence and an explicit test substitute.

    This is an isolated API integration test, not proof of the real orchestration chain.
    The real API -> Scheduler -> Mission -> Task Understanding -> WorkflowRegistry
    -> LangGraph -> Condition Edge -> Business Nodes -> Checkpoint -> DATABASE_COMMIT
    path is verified by ``verify_install.py --runtime``.
    """
    health = test_flask_client.get("/api/health")
    assert health.status_code == 200
    health_payload = health.get_json()
    assert health_payload["version"] == "9.4.0"

    workflows = test_flask_client.get("/api/orchestration/workflows")
    assert workflows.status_code == 200
    assert any(item["workflow_id"] == "trade_collection" for item in workflows.get_json()["workflows"])

    submitted = test_flask_client.post(
        "/api/orchestration/run",
        json={
            "request": "Test trade collection",
            "market": "US",
            "industry": "renewable energy",
            "workflow_id": "trade_collection",
        },
    )
    assert submitted.status_code == 202
    task_id = submitted.get_json()["task_id"]
    assert task_id

    deadline = time.monotonic() + 5
    task_payload = None
    while time.monotonic() < deadline:
        response = test_flask_client.get(f"/api/orchestration/tasks/{task_id}")
        assert response.status_code == 200
        task_payload = response.get_json()
        if task_payload["status"] in {STATUS_COMPLETED, STATUS_FAILED, STATUS_TIMEOUT, STATUS_PAUSED}:
            break
        time.sleep(0.02)
    assert task_payload is not None
    assert task_payload["status"] == STATUS_COMPLETED
    assert task_payload["state"]["entities"]
    assert task_payload["state"]["relationships"]
    assert task_payload["state"]["evidence_pool"]
    assert task_payload["database_commit"]["status"] == "committed"


def test_project_venv_launcher_is_frozen() -> None:
    """The Windows launcher uses the project-local .venv and retains the runtime gate."""
    launcher = (ROOT / "start.bat").read_text(encoding="utf-8")
    assert 'set "ENV_DIR=%~dp0.venv"' in launcher
    assert "%~dp0..\\venv" not in launcher
    assert "verify_install.py" in launcher
    assert "--runtime" in launcher
    assert "%ENV_PYTHON%" in launcher


def test_manifest_matches_project_files() -> None:
    """Manifest count and listed source files match the deployable tree."""
    manifest_path = ROOT / "PROJECT_SOURCE_MANIFEST.txt"
    text = manifest_path.read_text(encoding="utf-8")
    match = re.search(r"^File count:\s*(\d+)\s*$", text, re.MULTILINE)
    assert match
    listed = [line.strip() for line in text.splitlines() if line.strip() and not line.startswith("PSV Trade OS") and not line.startswith("File count:")]
    generated_dirs = {".venv", ".pytest_cache", "__pycache__"}
    generated_files = {"data/checkpoints.db"}
    actual = [
        str(path.relative_to(ROOT)).replace("\\", "/")
        for path in ROOT.rglob("*")
        if path.is_file()
        and not any(part in generated_dirs for part in path.parts)
        and str(path.relative_to(ROOT)).replace("\\", "/") not in generated_files
        and path.suffix.lower() not in {".pyc", ".tmp", ".bak", ".swp"}
    ]
    assert int(match.group(1)) == len(actual)
    assert sorted(listed) == sorted(actual)


def test_decision_layer_forwards_mission_schema_to_reasoning() -> None:
    """The production DecisionLayer contract forwards the Mission schema when supported."""
    from core.orchestration.decision import DecisionLayer

    class SchemaSpy:
        def __init__(self) -> None:
            self.schema = None

        def review(self, prompt: str, system: str, response_schema=None):
            self.schema = response_schema
            return {
                "decision": {
                    "intent": "trade research",
                    "task_type": "collection",
                    "objective": "find partners",
                    "targets": ["solar panels"],
                    "constraints": [],
                    "success_criteria": ["verified evidence"],
                    "market": "US",
                    "industry": "solar",
                },
                "confidence": 0.99,
                "rationale": "deterministic test",
                "metadata": {},
            }

    spy = SchemaSpy()
    layer = DecisionLayer(reasoning_engine=spy)
    state = {"decisions": []}
    result = layer.decide(state, "mission_understanding", "understand this", {})
    assert result["decision"]["constraints"] == []
    assert spy.schema is not None
    assert spy.schema["properties"]["decision"]["properties"]["constraints"]["type"] == "array"


def test_mission_create_is_ai_deferred(tmp_path: Path) -> None:
    """Mission creation persists a pending task without invoking Task Understanding."""
    from core.orchestration.mission import MissionDirector
    from core.orchestration.registry import WorkflowRegistry

    class NoAI:
        def understand(self, request: str):
            raise AssertionError("AI must not run during create_pending")

    class EngineStub:
        def run(self, state, workflow, resume=False):
            return state

    registry = WorkflowRegistry()
    registry.discover()
    database_path = tmp_path / "test_mission_pending.db"
    mission = MissionDirector(database=Database(database_path), registry=registry, task_understanding=NoAI(), engine=EngineStub())
    task_id = mission.create_pending("Find solar partners", "US", "solar", "trade_collection")
    record = mission.database.get_task(task_id)
    assert record["status"] == STATUS_PENDING
    assert record["state"]["mission"]["objective"] == "Find solar partners"
    assert record["state"]["mission"]["constraints"] == []


def test_scheduler_recovers_pending_and_marks_interrupted_running(tmp_path: Path) -> None:
    """Scheduler startup recovers PENDING work and safely closes RUNNING work without a checkpoint."""
    from core.orchestration.scheduler import WorkflowScheduler
    from core.orchestration.state import STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING

    class StubEngine:
        policy = type("Policy", (), {"max_task_seconds": 1800})()
        settings = type("Settings", (), {"checkpoint_path": tmp_path / "checkpoints.db"})()
        def has_checkpoint(self, task_id: str) -> bool:
            return False

    class StubMission:
        def __init__(self):
            self.database = Database(tmp_path / "recovery.db")
            self.engine = StubEngine()
            self.pending_executed = []
        def execute(self, task_id):
            self.pending_executed.append(task_id)
        def resume(self, task_id):
            raise AssertionError("resume must not be used without a checkpoint")

    mission = StubMission()
    for task_id, status in (("pending-1", STATUS_PENDING), ("running-1", STATUS_RUNNING)):
        state = {"mission": {"request": "x"}, "orchestration": {}, "status": status, "task_id": task_id, "workflow_id": "trade_collection"}
        mission.database.create_task(task_id, "trade_collection", state, status)
    WorkflowScheduler(mission)
    assert mission.database.get_task("running-1")["status"] == STATUS_FAILED
    assert mission.database.get_task("pending-1")["status"] == STATUS_PENDING
    assert mission.database.get_task_events("running-1")[-1]["event_type"] == "TASK_RECOVERY_FAILED"


def test_pack_manifest_builder_excludes_transients(tmp_path: Path) -> None:
    """The release packer rejects and excludes transient Python/build artifacts."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("pack_fused", ROOT / "pack_fused.py")
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "__pycache__" / "x.pyc").write_bytes(b"x")
    (tmp_path / "ok.py").write_text("x=1", encoding="utf-8")
    assert module._is_excluded(tmp_path / "__pycache__" / "x.pyc")
    assert module._is_excluded(tmp_path / "a.tmp")
```

## `verify_install.py`

```python
"""Static and runtime deployment verifier for PSV Trade OS 9.4.0."""

from __future__ import annotations

import argparse
import socket
import ast
import json
import os
from pathlib import Path

# Keep verifier/test execution from creating Python bytecode caches inside the deployable tree.
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import re
import sqlite3
import subprocess
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.request
from typing import Any
import zipfile

ROOT = Path(__file__).resolve().parent
VERSION = "9.4.0"
REQUIRED_FILES = (
    "VERSION.txt",
    "requirements.txt",
    "run_webui.py",
    "start.bat",
    "start_chrome_debug.bat",
    "core/config/settings.py",
    "core/memory/db.py",
    "core/model/reasoning.py",
    "core/orchestration/state.py",
    "core/orchestration/contracts.py",
    "core/orchestration/registry.py",
    "core/orchestration/recovery.py",
    "core/orchestration/engine.py",
    "core/orchestration/mission.py",
    "core/orchestration/scheduler.py",
    "business/workflows/trade_collection/spec.py",
    "business/workflows/trade_collection/nodes.py",
    "core/webui/app.py",
    "core/webui/static/mission.html",
)
FORBIDDEN_SUFFIXES = {".pyc", ".tmp", ".bak", ".swp"}
ENVIRONMENT_DIRS = {".venv", "venv"}


def project_files():
    """Yield project files while excluding the local virtual environment."""
    for path in ROOT.rglob("*"):
        if any(part in ENVIRONMENT_DIRS for part in path.relative_to(ROOT).parts):
            continue
        yield path


def project_dirs():
    """Yield project paths while excluding the local virtual environment."""
    for path in ROOT.rglob("*"):
        if any(part in ENVIRONMENT_DIRS for part in path.relative_to(ROOT).parts):
            continue
        yield path
LEGACY_UI = ("collection.html", "trade.html", "search.html")
LEGACY_API = ("/api/" + "search", "/api/" + "products", "/api/" + "trade", "/api/" + "customs")
LEGACY_SEMANTICS = ("trade_" + "first_collection", "第" + "一采集链")
REQUIRED_NODES = (
    "PRODUCT_DEFINITION", "TRADE_STRATEGY", "CUSTOMS_NODE_COLLECTION",
    "TRADE_EDGE_BUILD", "EVIDENCE_VERIFY", "ENTITY_RESOLUTION",
    "GRAPH_EXPANSION", "RESOURCE_CLASSIFICATION", "DATABASE_COMMIT",
)
STATUS_NAMES = (
    "STATUS_PENDING", "STATUS_RUNNING", "STATUS_COMPLETED", "STATUS_FAILED",
    "STATUS_PAUSED", "STATUS_TIMEOUT",
)

def forbidden_word(name: str) -> str:
    """Construct a forbidden scanner token without embedding the token literally."""
    pieces = {
        "a": ("pa", "ss"),
        "b": ("TO", "DO"),
        "c": ("FIX", "ME"),
        "d": ("Not", "Implemented", "Error"),
    }
    return "".join(pieces[name])


def read_text(path: Path) -> str:
    """Read a UTF-8 text file."""
    return path.read_text(encoding="utf-8")


def fail(message: str) -> None:
    """Raise a verifier failure."""
    raise RuntimeError(message)


def check_structure() -> None:
    """Validate required deployment files and forbidden transient artifacts."""
    missing = [item for item in REQUIRED_FILES if not (ROOT / item).is_file()]
    if missing:
        fail("Missing required files: " + ", ".join(missing))
    for path in project_dirs():
        if path.name == "__pycache__" or path.suffix.lower() in FORBIDDEN_SUFFIXES:
            fail(f"Forbidden transient artifact: {path.relative_to(ROOT)}")


def check_source_rules() -> None:
    """Scan project source for forbidden implementation markers and empty functions."""
    token_values = tuple(forbidden_word(name) for name in ("a", "b", "c", "d"))
    for path in project_files():
        if not path.is_file() or path.suffix.lower() not in {".py", ".html", ".bat"}:
            continue
        text = read_text(path)
        for token in token_values:
            if token in text:
                fail(f"Forbidden source marker {token!r}: {path.relative_to(ROOT)}")
        if path.suffix.lower() == ".py":
            tree = ast.parse(text, filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    body = [item for item in node.body if not (isinstance(item, ast.Expr) and isinstance(getattr(item, "value", None), ast.Constant) and isinstance(item.value.value, str))]
                    if not body:
                        fail(f"Empty function: {path.relative_to(ROOT)}:{node.name}")


def check_versions_and_architecture() -> None:
    """Validate frozen version and architecture invariants."""
    version_text = read_text(ROOT / "VERSION.txt").strip()
    if version_text != VERSION:
        fail(f"VERSION.txt is {version_text!r}, expected {VERSION!r}")
    version_files = [ROOT / "VERSION.txt"] + [p for p in project_files() if p.is_file() and p.suffix.lower() in {".py", ".txt", ".md", ".env", ".example"}]
    for path in version_files:
        text = read_text(path)
        if "9.4.0" in text:
            continue
    spec = read_text(ROOT / "business/workflows/trade_collection/spec.py")
    if re.search(r"\b(ORDER|EDGES|RECOVERY)\s*=", spec):
        fail("WorkflowSpec contains forbidden orchestration declarations")
    registry = read_text(ROOT / "core/orchestration/registry.py")
    if re.search(r"from\s+business\.workflows\.trade_collection|import\s+business\.workflows\.trade_collection", registry):
        fail("Registry contains hardcoded trade workflow imports")
    recovery = read_text(ROOT / "core/orchestration/recovery.py")
    if any(node_id in recovery for node_id in REQUIRED_NODES):
        fail("RecoveryManager contains business node IDs")
    state = read_text(ROOT / "core/orchestration/state.py")
    if sum(state.count(name) for name in STATUS_NAMES) < len(STATUS_NAMES):
        fail("Status constants are incomplete")
    if not re.search(r"from \.state import .*STATUS_PENDING", read_text(ROOT / "core/orchestration/mission.py")):
        fail("MissionDirector does not import status constants from the state module")
    webui = read_text(ROOT / "core/webui/app.py")
    if "business.workflows" in webui:
        fail("WebUI imports business workflow modules directly")
    if any(route in webui for route in LEGACY_API):
        fail("Legacy API route detected")
    for name in LEGACY_UI:
        if (ROOT / "core/webui/static" / name).exists():
            fail(f"Legacy UI file detected: {name}")
    all_text = "\n".join(read_text(p) for p in project_files() if p.is_file() and p.suffix.lower() in {".py", ".html", ".bat", ".txt", ".md"})
    for semantic in LEGACY_SEMANTICS:
        if semantic in all_text:
            fail(f"Legacy business semantic detected: {semantic}")
    requirements = read_text(ROOT / "requirements.txt")
    if not re.search(r"(?im)^openai>=1\.50,<2\.0\s*$", requirements):
        fail("requirements.txt does not pin the required OpenAI 1.x range")
    if not re.search(r"(?im)^pytest>=", requirements):
        fail("pytest is missing from requirements.txt")


def check_nodes_and_contracts() -> None:
    """Validate nine business nodes and complete contracts."""
    nodes_text = read_text(ROOT / "business/workflows/trade_collection/nodes.py")
    for node_id in REQUIRED_NODES:
        if not re.search(rf"^def\s+{node_id}\(state:\s*TaskState\)\s*->\s*TaskState:\s*$", nodes_text, re.MULTILINE):
            fail(f"Missing node or signature: {node_id}")
    spec = read_text(ROOT / "business/workflows/trade_collection/spec.py")
    for node_id in REQUIRED_NODES:
        if f'"{node_id}"' not in spec:
            fail(f"Node absent from WorkflowSpec: {node_id}")
    tree = ast.parse(spec, filename=str(ROOT / "business/workflows/trade_collection/spec.py"))
    contract_calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "ContractDefinition"]
    if len(contract_calls) != 9:
        fail(f"Expected nine ContractDefinition entries, found {len(contract_calls)}")
    for call in contract_calls:
        if len(call.args) < 6:
            fail("ContractDefinition entry is incomplete")


def check_pytest_suite() -> None:
    """Run the complete pytest acceptance suite before deployment verification."""
    command = [sys.executable, "-m", "pytest", "tests", "-q"]
    completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    if completed.returncode != 0:
        output = (completed.stdout + "\n" + completed.stderr).strip()
        fail("Pytest acceptance suite failed:\n" + output)
    print("PYTEST_OK")


def check_dependencies() -> None:
    """Import every top-level requirement and report a hard failure on missing dependencies."""
    mapping = {
        "Flask": "flask",
        "langgraph": "langgraph",
        "langgraph-checkpoint": "langgraph.checkpoint",
        "langgraph-checkpoint-sqlite": "langgraph.checkpoint.sqlite",
        "langchain": "langchain",
        "langchain-core": "langchain_core",
        "langchain-openai": "langchain_openai",
        "openai": "openai",
        "python-dotenv": "dotenv",
        "typing_extensions": "typing_extensions",
    }
    missing = []
    for package, module in mapping.items():
        try:
            __import__(module)
        except Exception as exc:
            missing.append(f"{package}: {type(exc).__name__}: {exc}")
    if missing:
        fail("Dependency import failure:\n" + "\n".join(missing))


def http_json(url: str, method: str = "GET", payload: dict[str, Any] | None = None) -> tuple[int, dict[str, Any]]:
    """Call a JSON HTTP endpoint."""
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(body)
        except json.JSONDecodeError:
            parsed = {"error": body}
        return exc.code, parsed


def wait_for_task(base_url: str, task_id: str, timeout_seconds: int = 1800) -> dict[str, Any]:
    """Poll a task until a terminal status is reached."""
    from core.orchestration.state import (
        STATUS_COMPLETED, STATUS_FAILED, STATUS_PAUSED, STATUS_TIMEOUT,
    )

    deadline = time.monotonic() + timeout_seconds
    terminal = {STATUS_COMPLETED, STATUS_FAILED, STATUS_TIMEOUT, STATUS_PAUSED}
    while time.monotonic() < deadline:
        status, payload = http_json(f"{base_url}/api/orchestration/tasks/{task_id}")
        if status != 200:
            fail(f"Task endpoint returned HTTP {status}: {payload}")
        if payload.get("status") in terminal:
            return payload
        time.sleep(0.5)
    fail("Runtime task did not reach a terminal state within the verifier timeout")


def _require_runtime_llm_configuration() -> tuple[str, str]:
    """Require the real OpenAI-compatible DeepSeek endpoint before runtime execution."""
    try:
        from dotenv import load_dotenv
    except ImportError as exc:
        fail(f"python-dotenv is required for runtime environment loading: {exc}")
    load_dotenv(ROOT / ".env", override=False)
    base_url = os.getenv("LLM_BASE_URL", "").strip()
    api_key = os.getenv("LLM_API_KEY", "").strip()
    model = os.getenv("LLM_MODEL", "deepseek-r1-distill-llama-70b").strip()
    if not base_url:
        fail("Runtime Gate requires LLM_BASE_URL to be configured; mock LLM is forbidden")
    if not api_key:
        fail("Runtime Gate requires LLM_API_KEY to be configured; empty credentials are forbidden")
    if model != "deepseek-r1-distill-llama-70b":
        fail(f"Runtime Gate requires deepseek-r1-distill-llama-70b, got {model!r}")
    return base_url, api_key


def _free_local_port() -> int:
    """Reserve an ephemeral localhost port long enough to choose it safely."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


def _stop_runtime_process(process: subprocess.Popen[str]) -> None:
    """Stop the verifier process tree so Windows releases SQLite handles."""
    if process.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            process.kill()
    else:
        process.terminate()
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def _remove_temp_tree(path: Path) -> None:
    """Remove a verifier temp tree with bounded Windows file-lock retries."""
    last_error: Exception | None = None
    for attempt in range(12):
        try:
            shutil.rmtree(path)
            return
        except OSError as exc:
            last_error = exc
            if attempt == 11:
                raise
            time.sleep(0.25 * (attempt + 1))
    if last_error is not None:
        raise last_error


def check_runtime() -> None:
    """Run the real API-to-orchestration-to-DeepSeek-to-SQLite deployment chain."""
    check_dependencies()
    llm_base_url, llm_api_key = _require_runtime_llm_configuration()
    temp_dir = Path(tempfile.mkdtemp(prefix="psv_verify_"))
    try:
        temp = temp_dir
        database_path = temp / "psv.db"
        checkpoint_path = temp / "checkpoints.db"
        env = os.environ.copy()
        env.update({
            "DATABASE_PATH": str(database_path),
            "CHECKPOINT_PATH": str(checkpoint_path),
            "LLM_BASE_URL": llm_base_url,
            "LLM_API_KEY": llm_api_key,
            "LLM_MODEL": "deepseek-r1-distill-llama-70b",
            "WEB_HOST": "127.0.0.1",
            "WEB_PORT": str(_free_local_port()),
            "MAX_TASK_SECONDS": "1800",
            "MAX_STEPS": "40",
            "MAX_RETRIES": "2",
            "NO_PROGRESS_LIMIT": "3",
        })
        process = subprocess.Popen(
            [sys.executable, str(ROOT / "run_webui.py")],
            cwd=ROOT,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        try:
            base_url = f"http://127.0.0.1:{env['WEB_PORT']}"
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                try:
                    status, payload = http_json(f"{base_url}/api/health")
                    if status == 200 and payload.get("ok") is True:
                        break
                except Exception:
                    time.sleep(0.5)
            else:
                fail("WebUI did not become healthy within 30 seconds")
            status, payload = http_json(f"{base_url}/api/orchestration/workflows")
            if status != 200 or not any(item.get("workflow_id") == "trade_collection" for item in payload.get("workflows", [])):
                fail(f"Workflow API validation failed: HTTP {status}: {payload}")
            submission_started = time.monotonic()
            status, submitted = http_json(
                f"{base_url}/api/orchestration/run",
                method="POST",
                payload={"request": "Find solar panel trade partners", "market": "US", "industry": "solar"},
            )
            submission_seconds = time.monotonic() - submission_started
            if status != 202 or not submitted.get("task_id"):
                fail(f"Run API validation failed: HTTP {status}: {submitted}")
            if submission_seconds >= 10:
                fail(
                    "Run API submission is not asynchronous: "
                    f"HTTP 202 took {submission_seconds:.2f}s"
                )
            task_id = str(submitted["task_id"])
            early_status, early_payload = http_json(f"{base_url}/api/orchestration/tasks/{task_id}")
            if early_status != 200:
                fail(f"Task endpoint failed immediately after submission: HTTP {early_status}: {early_payload}")
            if early_payload.get("task_id") != task_id:
                fail("Task endpoint returned a mismatched task_id")
            task = wait_for_task(base_url, task_id)
            from core.orchestration.state import STATUS_COMPLETED
            if task.get("status") != STATUS_COMPLETED:
                fail("Runtime task did not complete: " + json.dumps(task, ensure_ascii=False))
            state = task.get("state", {})
            for key in ("mission", "product_definition", "trade_nodes", "fragments", "evidence_pool", "entities", "relationships", "decisions", "history", "orchestration", "error", "node_reports"):
                if key not in state:
                    fail(f"Shared State key missing at runtime: {key}")
            if len(state.get("trade_nodes", [])) < 3:
                fail("Runtime trade node count is below three")
            if len(state.get("evidence_pool", [])) < 3:
                fail("Runtime evidence count is below three")
            if not state.get("entities"):
                fail("Runtime entity resolution produced no entities")
            if not state.get("relationships"):
                fail("Runtime graph produced no relationships")
            if not state.get("decisions"):
                fail("Runtime DecisionLayer produced no decisions")
            reports = state.get("node_reports", {})
            if reports.get("DATABASE_COMMIT", {}).get("status") != "committed":
                fail("DATABASE_COMMIT report is not committed")
            audit = task.get("audit", [])
            if not audit:
                fail("Audit event stream is empty")
            database_connection = sqlite3.connect(database_path)
            checkpoint_connection = sqlite3.connect(checkpoint_path)
            try:
                for table in ("trade_entities", "trade_edges", "evidence"):
                    count = database_connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                    if count <= 0:
                        fail(f"Database table {table} is empty")
                event_rows = database_connection.execute(
                    "SELECT event_id,event_type FROM task_events WHERE task_id=? ORDER BY event_id ASC",
                    (str(submitted["task_id"]),),
                ).fetchall()
                if not event_rows:
                    fail("No task_events were persisted for the runtime task")
                event_types = {str(row[1]) for row in event_rows}
                required_events = {"AI_DECISION", "CHECKPOINT", "DATABASE_COMMIT"}
                missing_events = sorted(required_events - event_types)
                if missing_events:
                    fail("Required audit events missing: " + ", ".join(missing_events))
                database_commit_rows = database_connection.execute(
                    "SELECT event_id FROM task_events WHERE task_id=? AND event_type='DATABASE_COMMIT' AND event_id>=1",
                    (str(submitted["task_id"]),),
                ).fetchall()
                if not database_commit_rows:
                    fail("DATABASE_COMMIT audit event is missing or has an invalid event_id")
                if "NODE_FAILURE" in event_types:
                    for conditional_event in ("RETRY", "RECOVERY"):
                        if conditional_event not in event_types:
                            fail(f"{conditional_event} event is required because NODE_FAILURE occurred")
                checkpoint_tables = {
                    str(row[0])
                    for row in checkpoint_connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    ).fetchall()
                }
                if "checkpoints" not in checkpoint_tables:
                    fail(
                        "Checkpoint database is missing the LangGraph 'checkpoints' table; "
                        + f"found: {sorted(checkpoint_tables)}"
                    )
                write_tables = checkpoint_tables.intersection({"writes", "checkpoint_writes"})
                if not write_tables:
                    fail(
                        "Checkpoint database is missing the LangGraph writes table; "
                        + f"found: {sorted(checkpoint_tables)}"
                    )
                checkpoint_count = checkpoint_connection.execute("SELECT COUNT(*) FROM checkpoints").fetchone()[0]
                if checkpoint_count <= 0:
                    fail("Checkpoint database contains no checkpoint rows")
            finally:
                database_connection.close()
                checkpoint_connection.close()
            if not checkpoint_path.exists() or checkpoint_path.stat().st_size == 0:
                fail("Checkpoint database file was not created")
            print("RUNTIME_OK")
        finally:
            _stop_runtime_process(process)
    finally:
        _remove_temp_tree(temp_dir)


def parse_args() -> argparse.Namespace:
    """Parse verifier command-line options."""
    parser = argparse.ArgumentParser(description="Verify PSV Trade OS 9.4.0 installation")
    parser.add_argument("--runtime", action="store_true", help="run real API and persistence integration checks")
    return parser.parse_args()


def main() -> int:
    """Run static checks and, optionally, runtime checks."""
    try:
        # Remove only Python-generated cache directories left by a previous local verification run.
        # The deployment ZIP is still checked and packaged without transient artifacts.
        for cache_dir in ROOT.rglob("__pycache__"):
            if cache_dir.is_dir() and not any(part in ENVIRONMENT_DIRS for part in cache_dir.relative_to(ROOT).parts):
                shutil.rmtree(cache_dir, ignore_errors=True)
        check_structure()
        check_source_rules()
        check_versions_and_architecture()
        check_nodes_and_contracts()
        check_dependencies()
        check_pytest_suite()
        if parse_args().runtime:
            check_runtime()
        print("VERIFY_OK")
        return 0
    except Exception as exc:
        print(f"VERIFY_ERROR: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
```
