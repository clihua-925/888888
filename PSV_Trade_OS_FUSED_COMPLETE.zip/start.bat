@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo PSV Trade OS 9.4.0 - Windows Startup
echo ============================================================
echo [INFO] Project: %CD%
echo [INFO] Project environment: %~dp0.venv
echo.

set "PYTHON_EXE="
set "PYTHON_VERSION="
set "PYTHON_MAJOR="
set "PYTHON_MINOR="

for /f "tokens=2 delims= " %%V in ('python --version 2^>^&1') do set "PYTHON_VERSION=%%V"
if defined PYTHON_VERSION (
    for /f "tokens=1,2 delims=." %%A in ("!PYTHON_VERSION!") do (
        set "PYTHON_MAJOR=%%A"
        set "PYTHON_MINOR=%%B"
    )
    if "!PYTHON_MAJOR!"=="3" if !PYTHON_MINOR! GEQ 10 if !PYTHON_MINOR! LEQ 13 set "PYTHON_EXE=python"
)

if not defined PYTHON_EXE (
    for %%V in (3.13 3.12 3.11 3.10) do (
        py -%%V -c "import sys; raise SystemExit(0 if sys.version_info[:2] >= (3,10) and sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1
        if not errorlevel 1 if not defined PYTHON_EXE set "PYTHON_EXE=py -%%V"
    )
)

if not defined PYTHON_EXE (
    echo [ERROR] Python 3.10-3.13 was not found.
    echo Install a supported Python version and run this script again.
    pause
    exit /b 1
)

echo [OK] Python launcher: !PYTHON_EXE!

rem The frozen startup contract uses a project-local .venv.
rem Iterative external testing may use a separate parent\venv, but this launcher does not.
set "ENV_DIR=%~dp0.venv"
set "ENV_PYTHON=%ENV_DIR%\Scripts\python.exe"
set "ENV_ACTIVATE=%ENV_DIR%\Scripts\activate.bat"

if not exist "%ENV_PYTHON%" (
    echo [INFO] Project venv not found. Creating: %ENV_DIR%
    !PYTHON_EXE! -m venv "%ENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to create external venv.
        pause
        exit /b 1
    )
) else (
    echo [OK] Project venv found: %ENV_DIR%
)

call "%ENV_ACTIVATE%"
if errorlevel 1 (
    echo [ERROR] Failed to activate external venv.
    pause
    exit /b 1
)

rem Clean only project-generated transient files. The external venv is never touched.
for /d /r "%~dp0" %%D in (__pycache__) do if exist "%%D" rd /s /q "%%D" >nul 2>&1
if exist ".pytest_cache" rd /s /q ".pytest_cache" >nul 2>&1
for /r "%~dp0" %%F in (*.pyc *.tmp *.bak *.swp) do if exist "%%F" del /q "%%F" >nul 2>&1

echo [INFO] Upgrading pip in external environment ...
"%ENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 (
    echo [ERROR] pip upgrade failed.
    pause
    exit /b 1
)

echo [INFO] Installing or validating requirements in external environment ...
"%ENV_PYTHON%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo [ERROR] Dependency installation failed.
    pause
    exit /b 1
)

echo [INFO] Running static verification (no runtime gate at startup) ...
"%ENV_PYTHON%" "%~dp0verify_install.py"
if errorlevel 1 (
    echo [ERROR] Static verification failed. WebUI will not start.
    pause
    exit /b 1
)

echo [OK] Static verification succeeded.
echo [INFO] Full Runtime Gate is NOT run at startup.
echo        Run it manually when needed:
echo          "%ENV_PYTHON%" "%~dp0verify_install.py" --runtime
echo [INFO] Starting WebUI ...
start "PSV Trade OS WebUI" cmd /k "\"%ENV_PYTHON%\" \"%~dp0run_webui.py\""

echo [INFO] Waiting for WebUI readiness on http://127.0.0.1:8090 ...
set "WEBUI_READY="
for /l %%N in (1,1,30) do (
    "%ENV_PYTHON%" -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8090/', timeout=1).read(1)" >nul 2>&1
    if not errorlevel 1 (
        set "WEBUI_READY=1"
        goto :webui_ready
    )
    timeout /t 1 /nobreak >nul
)

if not defined WEBUI_READY (
    echo [ERROR] WebUI did not become ready within 30 seconds.
    echo [INFO] Keep the WebUI window open and inspect its first Python traceback.
    pause
    endlocal
    exit /b 1
)

:webui_ready
echo [OK] WebUI is responding at http://127.0.0.1:8090
echo [INFO] Starting AI/CDP browser ...
call "%~dp0start_chrome_debug.bat"
if errorlevel 1 (
    echo [WARN] AI/CDP browser did not start. WebUI is still running.
    echo [INFO] You can run start_chrome_debug.bat manually.
) else (
    echo [OK] AI/CDP browser startup requested on port 9222.
)
echo Project environment remains at: %ENV_DIR%
echo This launcher window will remain open.
pause
endlocal
