# -*- coding: utf-8 -*-
"""Customs Graph 网络扩张：有限预算、可重复执行、双向收割、永不无限循环。"""
import re,time
from core.config import settings
from core.memory.db import DB
from core.tools import suppliers as sup

def slug(name):
    return re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',str(name or '').lower())).strip('-')

def run_network(task_id=None,seed_norms=None,depth=None,max_new=None,buyers_per=None,suppliers_per=None,customers_per=None):
    db=DB();depth=int(depth or settings.NETWORK_EXPANSION_DEPTH);max_new=int(max_new or settings.NETWORK_EXPANSION_MAX_NEW);buyers_per=int(buyers_per or settings.NETWORK_EXPANSION_BUYERS);suppliers_per=int(suppliers_per or settings.NETWORK_EXPANSION_SUPPLIERS);customers_per=int(customers_per or settings.NETWORK_EXPANSION_CUSTOMERS)
    seeds=[]
    if seed_norms:
        for n in seed_norms:
            l=db.get_lead(n)
            if l:seeds.append(l)
    else: seeds=db.list_leads(kind='importer',limit=buyers_per)
    have={x['norm'] for x in db.list_leads(limit=10000)};stats={'depths':[],'new_leads':0,'buyers_scanned':0,'suppliers_scanned':0,'errors':[],'stopped_by_budget':False}
    frontier=seeds[:buyers_per]
    try:
        from core.tools import iy_web
        if not iy_web.available():return {**stats,'error':'ImportYeti网页未就绪'}
        with iy_web.IYWeb() as w:
            # v30.3：与主链一致的节点渗透方式——携带的 URL 优先，缺失时按名搜索解析主页，
            # 绝不猜 slug；连续失败熔断保住页访预算；节点注册表跨任务去重。
            from core.trade_graph import iy_network as iyn
            budget=iyn.PageBudget(); fails=0
            for d in range(1,depth+1):
                if not frontier or stats['new_leads']>=max_new or fails>=2:break
                next_frontier=[];depth_new=0;bs=ss=0
                for buyer in frontier[:buyers_per]:
                    if stats['new_leads']>=max_new or fails>=2:break
                    bn_=sup.norm(buyer['name'])
                    if iyn.node_fresh(bn_,'company'):continue
                    try:
                        burl=str((buyer.get('evidence') or {}).get('url') or '') if isinstance(buyer.get('evidence'),dict) else ''
                        if '/company/' not in burl: burl=iyn.node_url(bn_,'company')
                        if '/company/' not in burl:
                            if not budget.take('search:'+str(buyer['name'])[:40]):break
                            burl=w.company_page_for(buyer['name']) or ''
                        if not burl:
                            fails+=1; stats['errors'].append(f'{buyer["name"]}: 未解析到 ImportYeti 公司主页'); continue
                        if not budget.take('page:'+burl[-60:]):break
                        rows=w.relationships(burl,'Suppliers')[:suppliers_per];bs+=1
                        if not rows and w.last_error: fails+=1; continue
                        fails=0
                        iyn.mark_node(bn_,'company',slug=burl.rstrip('/').split('/')[-1],url=burl,run_id=task_id or '')
                        sup_entries=[]
                        for r in rows:
                            nm=r.get('name') or '';sn=sup.norm(nm)
                            if not sn:continue
                            sup_entries.append({'norm':sn,'name':nm,'slug':r.get('url','').rstrip('/').split('/')[-1] if r.get('url') else '','shipments':r.get('shipments') or 0,'last_seen':time.time(),'via':f'expand:d{d}:{buyer["name"]}'})
                        if sup_entries:sup.upsert_pool(sup_entries)
                        for se in sup_entries:
                            if stats['new_leads']>=max_new:break
                            s_norm=se['norm']
                            if iyn.node_fresh(s_norm,'supplier'):continue
                            url='https://www.importyeti.com/supplier/'+se['slug'] if se.get('slug') else iyn.node_url(s_norm,'supplier')
                            if not url:
                                if not budget.take('search:'+str(se['name'])[:40]):break
                                url=w.supplier_page_for(se['name']) or ''
                            if not url: stats['errors'].append(f'{se["name"]}: 未解析到 ImportYeti 供应商主页'); continue
                            if not budget.take('page:'+url[-60:]):break
                            try:
                                custs=w.relationships(url,'Customers')[:customers_per];ss+=1
                                iyn.mark_node(s_norm,'supplier',slug=se.get('slug') or url.rstrip('/').split('/')[-1],url=url,run_id=task_id or '')
                                added=0
                                for c in custs:
                                    nm=c.get('name') or '';cn=DB._norm(nm)
                                    if not cn or cn in have:continue
                                    have.add(cn);item={'name':nm,'country':'USA','kind':'importer','segment':'','shipments':c.get('shipments') or 0,'desc_sample':(c.get('products') or '')[:300],'source':f'network_expand:d{d}','evidence':{'customs':True,'trade_evidence':True,'shipments':c.get('shipments') or 0,'url':c.get('url') or url,'iy_verified':True}};db.upsert_leads([item]);db.mark_frontier(cn,'pending',depth=d+1,task_id=task_id);next_frontier.append(db.get_lead(cn));added+=1;stats['new_leads']+=1;depth_new+=1
                                    db.add_relationship(task_id,se['name'],'supplier',nm,'buyer','supplier_to_customer',{'shipments':c.get('shipments'),'products':c.get('products') or '','url':url},'importyeti_web',confidence=.9 if c.get('shipments') else .75,depth=d+1)
                                sup.mark_harvested(s_norm,len(custs));sup.log_harvest(task_id or '',se.get('slug') or '',se['name'],'network_expand','ok',len(custs),f'depth={d};new={added}')
                            except Exception as e:stats['errors'].append(f'{se["name"]}:{str(e)[:80]}')
                    except Exception as e:
                        fails+=1; stats['errors'].append(f'{buyer["name"]}:{str(e)[:80]}')
                db.add_expansion_run(task_id or '',d,bs,ss,depth_new,max_new);stats['depths'].append({'depth':d,'buyers':bs,'suppliers':ss,'new':depth_new});stats['buyers_scanned']+=bs;stats['suppliers_scanned']+=ss
                frontier=next_frontier
            if stats['new_leads']>=max_new:stats['stopped_by_budget']=True
    except Exception as e:stats['errors'].append(str(e)[:160])
    return stats

def run(limit_buyers=None,customers_per=None,max_new=None):
    return run_network(max_new=max_new,buyers_per=limit_buyers,customers_per=customers_per)
