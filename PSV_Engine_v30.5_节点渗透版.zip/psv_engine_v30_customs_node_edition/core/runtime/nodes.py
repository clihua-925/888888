# -*- coding: utf-8 -*-
"""v30 Customs Node Edition：第一采集链恢复为海关节点中心。

关键词 → 海关贸易数据节点 → 确定 importer/supplier/shipper 节点 → 保存贸易证据
→ 从节点展开关联企业 → 贸易关系图谱。
第一阶段只建完整贸易节点图（简单净化，不评分）；第二阶段才做客户价值判断。"""
import json, re, sqlite3, time
import requests
from pathlib import Path
from core.config import settings
from core.config.industry import load_industry
from core.model.reasoning import ReasoningEngine
from core.runtime import experts
from core.tools.data_sources.manager import DataSourceManager, Evolution, gate_check, norm, noise, identity_valid, hard_evidence
from core.tools import suppliers as sup
from core.tools import apify_client as apify
from core.tools import expand as expand_tool
from core.tools import trade_filter
from core.trade_graph import customs_node_pipeline as cnp

# v10 恢复：第一链查询词必须携带的贸易证据信号（定位贸易节点，而不是找联系方式）
TRADE_EVIDENCE_SIGNALS = ('importer of record', 'customs data', 'bill of lading',
                          'import records', 'hs code', 'shipment', 'shipper',
                          'consignee', 'importer', 'supplier')

BAD = re.compile(r'on behalf of|freight|forwarder|logistics|express|cargo|shipping|customs broker|packaging|consulting|翻译|词典|物流|货代', re.I)
_engine = None

def _eng():
    global _engine
    if _engine is None:
        _engine = ReasoningEngine()
    return _engine

def _report(state, node, rep):
    nr = dict(state.get('node_reports') or {})
    nr[node] = rep
    return nr

def _ev(c):
    e = c.get('evidence') or {}
    bits = []
    if e.get('shipments'):
        bits.append(f"shipments={e['shipments']}")
    if e.get('score'):
        bits.append(f"score={e['score']}")
    if e.get('last_seen'):
        bits.append(f"last_seen={e['last_seen']}")
    return (' [' + ', '.join(str(b) for b in bits) + ']') if bits else ''

def _brief(cs, n=12):
    return '\n'.join('- ' + c.get('name','') + ' | ' + str(c.get('country','')) + ' | ' + str(c.get('source','')) + _ev(c) for c in (cs or [])[:n])

# ---------- 1. ICP 客户画像师 ----------
def n_icp(state):
    ind = state['industry']
    icp = None
    industry_cfg = load_industry(ind)
    # 优先使用配置中的 ICP，避免不必要的 LLM 调用
    if settings.EXPERT_MODE and _eng().available:
        icp = _eng().review(
            f'市场:{state["market"]} 行业:{ind}\n生成客户画像契约JSON：'
            '{"must":["必收信号3-5条"],"reject":["拒收信号3-5条"],"keywords":["英文关键词5-8个"],"hs":["相关HS编码"]}',
            system='你是资深外贸客户画像师，只输出JSON')
    if not icp or not icp.get('must'):
        icp = {'must': industry_cfg.get('icp_must', ['USA company', 'import or trade evidence']),
               'reject': industry_cfg.get('icp_reject', ['dictionary', 'marketplace retail page', 'freight forwarder']),
               'keywords': industry_cfg.get('keywords', [ind]),
               'hs': industry_cfg.get('hs_codes', [])}
    rep = experts.review('ICP', '契约：\n' + json.dumps(icp, ensure_ascii=False),
                         [('含必收信号', bool(icp.get('must')), 'must 非空' if icp.get('must') else 'must 缺失'),
                          ('含拒收信号', bool(icp.get('reject')), 'reject 非空' if icp.get('reject') else 'reject 缺失'),
                          ('关键词与行业相关', bool(icp.get('keywords')), ','.join((icp.get('keywords') or [])[:5]))],
                         critical={'含必收信号','含拒收信号'})
    return {'icp': icp, 'node_reports': _report(state, 'ICP', rep), '_note': '客户画像契约已锁定'}

# ---------- 2. STRATEGY 贸易节点定位策略师：第一次搜索的目标是定位贸易节点 ----------
def n_strategy(state):
    industry_cfg = load_industry(state.get('industry'))
    plan = Evolution().plan(state['market'], state['industry'])
    # 生产模式固定为“海关多源并行 + 增量轮换”，不能因为某个源首轮返回足量就停止后续硬源。
    configured=list(industry_cfg.get('search_terms') or [])
    keywords=list(industry_cfg.get('keywords') or [])
    defaults=[]
    for q in configured + [f"{x} importer" for x in keywords[:3]]:
        if q and q not in defaults: defaults.append(q)
    base=[v for v in (state.get('query_override') or defaults or [state['industry']]) if v][:6]
    # v10 恢复：第一链查询词必须携带贸易证据信号，使命是“定位贸易节点”而非“找联系方式”。
    sig_q=[]
    for kw in (keywords[:2] or [state['industry']]):
        for sig in ('importer of record','bill of lading','hs code'):
            qq=f'{kw} {sig}'
            if qq not in sig_q: sig_q.append(qq)
    queries=(base+[q for q in sig_q if q not in base])[:8]
    hs_codes=industry_cfg.get('hs_codes') or cnp.resolve_hs_codes(state.get('industry'), state.get('icp'))
    rationale=('第一采集链以海关贸易数据节点为中心：关键词→HS编码→海关/提单数据源→'
               '确定 importer/supplier/shipper 节点并保存贸易证据；不使用通用搜索引擎结果；'
               '每次运行做增量 delta + 历史轮换；已有客户只合并新证据，新客户才进入开发池；'
               '展会/普通网络仅后置补充验证（第二阶段）')
    strategy={'queries':queries,'source_queries':{x:queries for x in ('customs','importyeti','importyeti_web')},
              'sources':['hs_finder','customs_bulk','customs_raw','importyeti','importyeti_web','customs_web'],
              'secondary_sources':['public_crawler','exhibition','web_verify'],'hs_codes':hs_codes,
              'objective':'locate_trade_nodes','first_chain':'customs_node_centric',
              'rationale':rationale,'evolution':plan,'incremental':True,'fanout_hard_sources':True}
    rep=experts.review('STRATEGY','查询参数：'+json.dumps(queries,ensure_ascii=False)+'\nHS：'+','.join(hs_codes or [])+'\n策略：'+rationale,
                       [('至少2个产品/行业查询变体',len(queries)>=2,f'{len(queries)}个'),
                        ('主证据源为海关贸易源',True,'hs_finder + customs fan-out'),
                        ('查询词含贸易证据信号',any(any(sig in q.lower() for sig in TRADE_EVIDENCE_SIGNALS) for q in queries),'已包含'),
                        ('增量运行已启用',True,'delta + rotating window')],critical={'主证据源为海关贸易源','查询词含贸易证据信号','增量运行已启用'})
    return {'strategy':strategy,'node_reports':_report(state,'STRATEGY',rep),'_note':f'贸易节点定位：查询{len(queries)}个·HS{len(hs_codes or [])}个·海关多源并行·增量轮换'}

# ---------- 3. A_COLLECT 贸易节点采集（海关节点中心；确定性通过，保留简单净化） ----------
def n_collect(state):
    # v30：第一采集链 = CustomsNodePipeline（关键词→HS→海关源 fan-out→节点识别）。
    pipe=cnp.CustomsNodePipeline()
    qs=(state.get('strategy') or {}).get('queries'); sq=(state.get('strategy') or {}).get('source_queries')
    companies,used,errors,gate,graph,node_stats=pipe.run(
        state['market'],state['industry'],state['quantity'],
        queries=qs,source_queries=sq,icp=state.get('icp'),task_id=state.get('task_id',''))
    mgr=pipe  # last_evolution 兼容（下方读取 mgr.last_evolution）
    # 保存贸易证据：节点级证据事件落盘（图谱关系边由 SUPPLIER_MINING/REVERSE_HARVEST 展开后保存）。
    try: cnp.save_graph(graph,state.get('task_id',''),depth=0)
    except Exception: pass
    state['trade_graph']=graph.to_dict()
    # RAW 保留：这里不因资料缺失淘汰客户。明确非客户才进入 quarantine。
    raw=list(companies); identity=[]; quarantine=[]
    # v30 第一轮简单净化：删除百科/新闻/词典/翻译/广告目录/明显错误企业；
    # 保留一切带贸易节点信号（importer/exporter/supplier/manufacturer/shipper/
    # consignee/notify party/HS/shipment/BOL/trade evidence）的候选。不评分。
    purified,dropped=trade_filter.purify(raw)
    quarantine.extend(c for c,_r in dropped)
    for c in purified:
        if not identity_valid(c):
            quarantine.append(c)
        else:
            identity.append(c)
    stats={'raw':len(raw),'clean':len(identity),'noise':len(quarantine),'duplicate':0,'identity_only':0,'hard_evidence':sum(1 for c in identity if (c.get('evidence') or {}).get('shipments') or (c.get('evidence') or {}).get('customs') or (c.get('evidence') or {}).get('trade_evidence')),
           'new_candidates':int(gate.get('new_candidates') or 0),'existing_enriched':int(gate.get('existing_enriched') or 0),'source_fanout':True,'incremental':True,
           'trade_nodes':node_stats.get('nodes',0),'node_roles':node_stats.get('by_role',{}),'hs_codes':node_stats.get('hs_codes',[])}
    stats['noise_ratio']=stats['noise']/max(1,stats['raw']);stats['clean_ratio']=stats['clean']/max(1,stats['raw'])
    for c in identity:
        e=c.setdefault('evidence',{}); is_hard=any(e.get(k) for k in ('shipments','customs','trade_evidence','bill_of_lading','supplier_relation'))
        e.setdefault('evidence_level','hard_trade' if is_hard else 'identity_only')
        if not is_hard: stats['identity_only']+=1
    rep={'verdict':'pass' if identity else 'fail','role':'SOURCE_COLLECTOR','criteria':[{'name':'有身份即保留','ok':bool(identity),'detail':f'{len(identity)}家'},{'name':'明确垃圾隔离','ok':True,'detail':f'{len(quarantine)}家'}], 'notes':f'RAW {len(raw)} · clean候选 {len(identity)} · quarantine {len(quarantine)}'}
    try:
        from core.memory.db import DB; DB().save_clean_batch(state.get('task_id',''),'collect',stats)
    except Exception:pass
    pen=node_stats.get('penetration') or {}
    pen_note=(f" · 节点渗透 {pen.get('nodes',0)} 节点/关系 {pen.get('relations',0)} 条/页访 {pen.get('pages',0)}" if pen.get('nodes') else '')
    return {'raw_companies':raw,'companies':identity,'quarantine':quarantine,'source':'+'.join(used) if used else 'none','source_errors':errors,'collect_gate':gate,'clean_stats':stats,'evolution':mgr.last_evolution,'node_reports':_report(state,'A_COLLECT',rep),'_success':bool(identity),'_note':f'增量采集 {len(raw)} · 新候选 {stats["new_candidates"]} · 已有客户补充 {stats["existing_enriched"]} · 隔离 {len(quarantine)}{pen_note}'}

def n_clean_pass1(state):
    """第一轮简单净化（v30）：只做删除清单 + 去重，不评分、不过度过滤。"""
    companies=list(state.get('companies') or []); out=[];seen=set();dups=0;identity_only=0
    purified,_dropped=trade_filter.purify(companies)
    for c in purified:
        n=norm(c.get('name'))
        if not n or noise(c.get('name')):continue
        if n in seen:dups+=1;continue
        seen.add(n);e=c.setdefault('evidence',{})
        if not any(e.get(k) for k in ('shipments','customs','trade_evidence','bill_of_lading','supplier_relation')):identity_only+=1
        out.append(c)
    prev=state.get('clean_stats') or {}
    raw_total=int(prev.get('raw',len(companies)));noise_total=int(prev.get('noise',0));dup_total=int(prev.get('duplicate',0))+dups
    stats={'raw':raw_total,'clean':len(out),'noise':noise_total,'duplicate':dup_total,'identity_only':identity_only,'hard_evidence':sum(1 for c in out if hard_evidence_local(c))}
    stats['noise_ratio']=noise_total/max(1,raw_total);stats['clean_ratio']=len(out)/max(1,raw_total)
    try:
        from core.memory.db import DB;DB().save_clean_batch(state.get('task_id',''),'pass1',stats)
    except Exception:pass
    rep=experts.review('CLEAN_PASS1',f'首轮清洗 {len(companies)}→{len(out)}，重复{dups}，仅身份{identity_only}',[('公司身份有效',len(out)>0,f'{len(out)}家'),('重复隔离',dups>=0,f'{dups}家')],critical={'公司身份有效'})
    return {'task_data':out,'companies':out,'clean_stats':stats,'node_reports':_report(state,'CLEAN_PASS1',rep),'_success':bool(out),'_note':f'首轮清洗 {len(companies)}→{len(out)} · 仅姓名保留 {identity_only}'}

def hard_evidence_local(c):
    e=c.get('evidence') or {};return bool(e.get('shipments') or e.get('customs') or e.get('trade_evidence') or e.get('bill_of_lading') or e.get('supplier_relation'))

def n_clean_quality_gate(state):
    st=state.get('clean_stats') or {}; raw=int(st.get('raw',0));clean=int(st.get('clean',0));noise_r=float(st.get('noise_ratio',0));dup_r=float(st.get('duplicate',0))/max(1,raw);hard_r=float(st.get('hard_evidence',0))/max(1,clean)
    ok=bool(clean>=settings.RAW_MIN_CLEAN and noise_r<=settings.RAW_MAX_NOISE_RATIO and dup_r<=settings.RAW_MAX_DUP_RATIO)
    gate={'ok':ok,'raw':raw,'clean':clean,'noise_ratio':noise_r,'duplicate_ratio':dup_r,'hard_evidence_ratio':hard_r,'reason':'clean数据有效占比达标' if ok else '未清洗数据/重复数据占比过高'}
    rep=experts.review('CLEAN_QUALITY_GATE',json.dumps(gate,ensure_ascii=False),[('有效数据存在',clean>=settings.RAW_MIN_CLEAN,f'{clean}'),('垃圾率不过高',noise_r<=settings.RAW_MAX_NOISE_RATIO,f'{noise_r:.1%}'),('重复率不过高',dup_r<=settings.RAW_MAX_DUP_RATIO,f'{dup_r:.1%}')],critical={'有效数据存在','垃圾率不过高'})
    return {'clean_quality_gate':gate,'node_reports':_report(state,'CLEAN_QUALITY_GATE',rep),'_success':ok,'_note':f'清洗质量 {'PASS' if ok else 'FAIL'} · 有效{clean} · 垃圾率{noise_r:.1%}'}

def n_seed_buyers(state):
    cs=list(state.get('task_data') or state.get('companies') or []);seeds=[]
    for c in cs:
        # seed必须尽量来自硬贸易源；身份-only也保留，但作为低证据种子
        c=dict(c);c['seed_role']='buyer_seed';seeds.append(c)
    # 关系图应覆盖本轮全部有效客户；外部网页补缺由 SUPPLIER_MINING_BUYERS 控制。
    seeds=seeds[:max(1, min(len(seeds), int(state.get('quantity') or settings.SEED_BUYERS_PER_TASK)))]
    rep=experts.review('SEED_BUYERS',f'种子客户{len(seeds)}家', [('种子存在',bool(seeds),str(len(seeds)))],critical={'种子存在'})
    return {'seed_buyers':seeds,'companies':seeds,'node_reports':_report(state,'SEED_BUYERS',rep),'_success':bool(seeds),'_note':f'形成种子客户 {len(seeds)} 家'}

def n_supplier_mining(state):
    """客户→供应商：第一优先级必须来自海关贸易记录；ImportYeti网页仅作为同类海关数据源补充。"""
    # 本地 customs_raw 没有逐票成本，第一轮清洗通过的客户全部进入关系图；
    # SUPPLIER_MINING_BUYERS 只限制需要访问 ImportYeti 网页补缺的外部客户数，避免免费额度被浪费。
    seeds=list(state.get('seed_buyers') or state.get('companies') or [])
    results=[]; supplier_rows=[]; relations=[]; errors=[]
    try:
        from core.tools.customs_graph import buyer_to_suppliers
        supplier_rows, relations = buyer_to_suppliers(seeds, settings.IY_WEB_MAX_SUPPLIERS)
        for rel in relations:
            try:
                from core.memory.db import DB
                DB().add_relationship(state.get('task_id'), rel['from_name'], rel['from_type'], rel['to_name'], rel['to_type'], rel['relation'], rel['evidence'], rel['source'], rel['confidence'], 1)
            except Exception: pass
        results.append({'source':'customs_raw','buyers':len(seeds),'suppliers':len(supplier_rows),'relations':len(relations)})
    except Exception as e:
        errors.append('customs_raw:'+str(e)[:160])
    # 如果本地原始海关库没有覆盖某个种子，再使用 ImportYeti 这一同类海关数据网站的免费网页关系。
    covered={x['norm'] for x in supplier_rows}
    missing=[b for b in seeds if not any(norm(r.get('from_name'))==norm(b.get('name')) for r in relations)]
    if missing and settings.IY_WEB_ENABLED:
        missing=missing[:settings.SUPPLIER_MINING_BUYERS]
        try:
            from core.tools import iy_web
            if iy_web.available():
                with iy_web.IYWeb() as w:
                    # v10 渗透方式：买家节点携带第一搜索时拿到的公司主页 URL（evidence.url），
                    # 直接透视该页的 Suppliers 区；缺 URL 时按名搜索解析主页，绝不猜 slug。
                    # v30.3 防资源枯竭：节点注册表 NODE_REVISIT_DAYS 内已访问过的买家页不再重复访问；
                    # 页访预算 IY_PAGE_BUDGET 耗尽即停止开新页（已挖到的关系全部保留）。
                    from core.trade_graph import iy_network as iyn
                    budget=iyn.PageBudget(); fails=0; skipped_fresh=0
                    for buyer in sorted(missing[:int(getattr(settings,'IY_WEB_TOP_BUYERS',settings.SUPPLIER_MINING_BUYERS))],
                                        key=lambda b:-int((b.get('evidence') or {}).get('shipments') or 0)):
                        if fails>=2: break  # v10 熔断：连续2个节点失败即停，保住浏览器配额
                        bn=norm(buyer.get('name'))
                        if iyn.node_fresh(bn,'company'):
                            skipped_fresh+=1; continue  # 该节点近期已渗透，供应商已在池中，不重复烧页访
                        try:
                            url=str((buyer.get('evidence') or {}).get('url') or '') or iyn.node_url(bn,'company')
                            if '/company/' not in url:
                                if not budget.take('search:'+str(buyer.get('name'))[:40]): break
                                url=w.company_page_for(buyer.get('name','')) or ''
                            if not url:
                                fails+=1; errors.append(f"{buyer.get('name')}: 未解析到 ImportYeti 公司主页"); continue
                            if not budget.take('page:'+url[-60:]): break
                            rows=w.relationships(url,'Suppliers')[:settings.IY_WEB_MAX_SUPPLIERS]
                            if not rows and w.last_error: fails+=1
                            else:
                                fails=0
                                iyn.mark_node(bn,'company',slug=url.rstrip('/').split('/')[-1],url=url,
                                              shipments=int((buyer.get('evidence') or {}).get('shipments') or 0),run_id=state.get('task_id',''))
                            for r in rows:
                                nm=r.get('name') or ''; sn=norm(nm)
                                if not sn: continue
                                e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'products':r.get('products') or '', 'hs':r.get('hs') or [], 'supplier_relation':buyer.get('name'),'url':r.get('url') or ''}
                                supplier_rows.append({'norm':sn,'name':nm,'slug':r.get('url','').rstrip('/').split('/')[-1] if r.get('url') else '', 'shipments':r.get('shipments') or 0,'last_seen':time.time(),'harvested':False,'bol_fetched':0,'via':'importyeti_web','evidence':e})
                                relations.append({'from_name':buyer.get('name'),'from_type':'buyer','to_name':nm,'to_type':'supplier','relation':'buyer_to_supplier','evidence':e,'source':'importyeti_web','confidence':.95})
                                try:
                                    from core.memory.db import DB; DB().add_relationship(state.get('task_id'),buyer.get('name',''),'buyer',nm,'supplier','buyer_to_supplier',e,'importyeti_web',.95,1)
                                except Exception: pass
                            results.append({'source':'importyeti_web','buyer':buyer.get('name'),'suppliers':len(rows)})
                        except Exception as e:
                            fails+=1; errors.append(f"{buyer.get('name')}: {str(e)[:100]}")
                    if skipped_fresh or budget.spent_on:
                        results.append({'source':'importyeti_web','summary':budget.note()+f'·注册表命中跳过{skipped_fresh}个已渗透节点'})
        except Exception as e: errors.append('importyeti_web:'+str(e)[:160])
    # 第三层：ImportKey公开海关公司页。仅补没有本地/ImportYeti覆盖的种子；不做普通搜索。
    if missing and settings.IMPORTKEY_ENABLED:
        try:
            from core.tools.data_sources.sources import ImportKeyPublicSource
            ik=ImportKeyPublicSource()
            for buyer in missing[:settings.SUPPLIER_MINING_BUYERS]:
                rows=ik.company_relationships(buyer.get('name',''),'suppliers',settings.IMPORTKEY_MAX_RELATIONS)
                for r in rows:
                    nm=r.get('name') or ''; sn=norm(nm)
                    if not sn: continue
                    e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'supplier_relation':buyer.get('name'),'url':r.get('url') or ''}
                    supplier_rows.append({'norm':sn,'name':nm,'slug':'','shipments':r.get('shipments') or 0,'last_seen':time.time(),'harvested':False,'bol_fetched':0,'via':'importkey_public','evidence':e})
                    relations.append({'from_name':buyer.get('name'),'from_type':'buyer','to_name':nm,'to_type':'supplier','relation':'buyer_to_supplier','evidence':e,'source':'importkey_public','confidence':.9})
                    try:
                        from core.memory.db import DB; DB().add_relationship(state.get('task_id'),buyer.get('name',''),'buyer',nm,'supplier','buyer_to_supplier',e,'importkey_public',.9,1)
                    except Exception: pass
                if rows: results.append({'source':'importkey_public','buyer':buyer.get('name'),'suppliers':len(rows)})
        except Exception as e: errors.append('importkey_public:'+str(e)[:160])
    # 去重但不丢失“来自多个客户”的关系证据
    merged={}
    for x in supplier_rows:
        n=x.get('norm') or norm(x.get('name'))
        if not n: continue
        if n not in merged: merged[n]=dict(x)
        else:
            merged[n]['shipments']=max(int(merged[n].get('shipments') or 0),int(x.get('shipments') or 0))
            if not merged[n].get('slug') and x.get('slug'): merged[n]['slug']=x['slug']
            merged[n]['via']=merged[n].get('via','')+'+'+x.get('via','')
    # v30 节点渗透：第一搜索/HS榜单落池的 supplier 节点必须进入反查链。
    # 搜索页命中的每个节点，其关联信息（供应商→客户）都要被继续挖出来，而不是只留在池里。
    try:
        for s in (sup.pool(days=365,min_shipments=0) or []):
            n=s.get('norm') or norm(s.get('name'))
            if not n or n in merged: continue
            merged[n]={'norm':n,'name':s.get('name'),'slug':s.get('slug') or '',
                       'shipments':int(s.get('shipments') or 0),'last_seen':s.get('last_seen') or time.time(),
                       'harvested':bool(s.get('harvested')),'bol_fetched':s.get('bol_fetched') or 0,
                       'via':'supplier_pool+'+str(s.get('via') or ''),
                       'evidence':{'customs':True,'trade_evidence':True,'shipments':int(s.get('shipments') or 0)}}
    except Exception: pass
    # v30：全部供应商节点落池（sup.norm 为供应商池统一身份），收割状态可持久化
    try:
        sup.upsert_pool([{'norm':sup.norm(x.get('name')),'name':x.get('name'),
                          'slug':x.get('slug') or sup.slugify(x.get('name')),
                          'shipments':int(x.get('shipments') or 0),
                          'last_seen':x.get('last_seen') or time.time()} for x in merged.values() if x.get('name')])
    except Exception: pass
    # v30：用 suppliers 表的持久收割状态回填，已渗透节点下一轮不再重复反查
    try:
        conn=sqlite3.connect(settings.DATABASE_PATH,timeout=10)
        done={r[0] for r in conn.execute("SELECT supplier_norm FROM suppliers WHERE harvested_at IS NOT NULL AND harvested_at!=''")}
        conn.close()
        for n,x in merged.items():
            if sup.norm(x.get('name')) in done: x['harvested']=True
    except Exception: pass
    p=sorted(merged.values(),key=lambda x:-int(x.get('shipments') or 0))[:settings.SUPPLIER_MINING_MAX_SUPPLIERS]
    new=[x for x in p if not x.get('harvested')]
    # v30：供应商节点与 buyer→supplier 边合并进贸易关系图谱（第一阶段建图，不评分）
    try:
        g=cnp.TradeGraph()
        for x in p:
            nd=cnp.TradeNode(x.get('name'),'supplier',x.get('via') or '')
            if x.get('evidence'): nd.add_evidence(x['evidence'])
            g.add_node(nd)
        for e in cnp.relations_to_edges(relations,1): g.add_edge(e)
        trade_graph=cnp.merge_graph_into_state(state,g,depth=1)
    except Exception:
        trade_graph=state.get('trade_graph')
    rep=experts.review('SUPPLIER_MINING',f'客户→供应商：种子{len(seeds)}，海关关系{len(p)}，未收割{len(new)}，错误{len(errors)}', [('关系链存在',bool(p) or bool(errors),f'{len(p)}家')])
    ok=bool(p) or (not seeds) or (not settings.HARVEST_ENABLED)
    return {'suppliers':p,'supplier_new':new,'trade_graph':trade_graph,'supplier_mining':{'buyers':results,'errors':errors,'relation_source_policy':'customs_trade_only'},'node_reports':_report(state,'SUPPLIER_MINING',rep),'_success':ok,'_note':f'客户→供应商 {len(p)} 家·新工厂 {len(new)} 家·海关关系优先'}


def n_reverse_harvest(state):
    """供应商→客户：优先从 customs_raw 反查；无本地覆盖时才使用 ImportYeti 海关网页关系。"""
    if not settings.HARVEST_ENABLED:
        return {'harvest':{'mode':'disabled'},'_success':True,'_note':'收割禁用'}
    new=state.get('supplier_new') or []; merged=list(state.get('companies') or []); have={norm(c.get('name')) for c in merged}; results=[]; errors=[]; added_total=0
    if not new:
        return {'harvest':{'mode':'idle','results':[]},'node_reports':_report(state,'REVERSE_HARVEST',experts.review('REVERSE_HARVEST','供应商已收割完毕，正常终态')),'_success':True,'_note':'本轮无新工厂可收割'}
    # 第一层：本地海关原始记录
    profiled=0
    try:
        from core.tools.customs_graph import supplier_to_buyers
        buyers, relations=supplier_to_buyers(new[:settings.NETWORK_EXPANSION_SUPPLIERS], settings.IY_WEB_MAX_CUSTOMERS)
        for c in buyers:
            rn=norm(c.get('name'))
            if not rn: continue
            if rn not in have:
                have.add(rn); merged.append(c); added_total+=1
        for rel in relations:
            try:
                from core.memory.db import DB
                DB().add_relationship(state.get('task_id'),rel['from_name'],rel['from_type'],rel['to_name'],rel['to_type'],rel['relation'],rel['evidence'],rel['source'],rel['confidence'],2)
            except Exception: pass
        results.append({'source':'customs_raw','suppliers':len(new),'customers':len(buyers),'new':added_total})
        # v30.4 单点彻底性：本地提单覆盖的供应商，立即把“这个供应商分析清楚了没有”落成画像
        # （产品结构/档次推断/供应能力/客户覆盖），数据全部来自真实提单，推断如实标注。
        try:
            from core.trade_graph import supplier_profile as sprof
            local_customers={}
            for rel in relations:
                local_customers.setdefault(rel['from_name'],0)
                local_customers[rel['from_name']]+=1
            for s in new[:settings.NETWORK_EXPANSION_SUPPLIERS]:
                if norm(s.get('name')) in {norm(r.get('from_name')) for r in relations}:
                    if sprof.profile_supplier(s.get('name'),customers_found=local_customers.get(s.get('name'),0),run_id=state.get('task_id','')):
                        profiled+=1
        except Exception: pass
    except Exception as e:
        errors.append('customs_raw:'+str(e)[:160])
    # 第二层：ImportYeti，同样是海关/提单关系源；仅补没有本地海关覆盖的供应商
    covered_supplier_names={norm(x.get('from_name')) for x in relations} if 'relations' in locals() else set()
    # v30：本地海关层已渗透过的供应商同样标记，避免后续运行重复收割同一节点
    for s in new[:settings.NETWORK_EXPANSION_SUPPLIERS]:
        if norm(s.get('name')) in covered_supplier_names:
            try: sup.mark_harvested(sup.norm(s.get('name')),0)
            except Exception: pass
    fallback=[s for s in new[:settings.NETWORK_EXPANSION_SUPPLIERS] if norm(s.get('name')) not in covered_supplier_names]
    if fallback and settings.IY_WEB_ENABLED:
        try:
            from core.tools import iy_web
            if iy_web.available():
                with iy_web.IYWeb() as w:
                    # v10 渗透方式：落池时带真实 slug 的直接拼主页；没有的按名搜索解析主页，
                    # 绝不猜 slug；连续2个节点失败即熔断，保住浏览器配额。
                    # v30.3 防资源枯竭：供应商节点注册表去重 + 页访预算； harvested 标记之外
                    # 再加 NODE_REVISIT_DAYS 保护，避免同一节点页被反复打开。
                    from core.trade_graph import iy_network as iyn
                    budget=iyn.PageBudget(); fails=0; skipped_fresh=0
                    for s in fallback:
                        if fails>=2: break
                        sn_=sup.norm(s.get('name'))
                        if iyn.node_fresh(sn_,'supplier'):
                            skipped_fresh+=1
                            try: sup.mark_harvested(sn_,0)
                            except Exception: pass
                            continue
                        try:
                            if s.get('slug'):
                                url='https://www.importyeti.com/supplier/'+s['slug']
                            else:
                                url=iyn.node_url(sn_,'supplier')
                                if not url:
                                    if not budget.take('search:'+str(s.get('name'))[:40]): break
                                    url=w.supplier_page_for(s.get('name','')) or ''
                            if not url:
                                fails+=1; errors.append(f"{s.get('name')}: 未解析到 ImportYeti 供应商主页"); continue
                            if not budget.take('page:'+url[-60:]): break
                            rows=w.relationships(url,'Customers')[:settings.IY_WEB_MAX_CUSTOMERS]
                            if not rows and w.last_error:
                                fails+=1
                                try: sup.log_harvest(state.get('task_id'),s.get('slug') or '',s.get('name'),'importyeti_web','fail',0,str(w.last_error)[:120])
                                except Exception: pass
                                continue
                            fails=0
                            iyn.mark_node(sn_,'supplier',slug=s.get('slug') or url.rstrip('/').split('/')[-1],url=url,
                                          shipments=int(s.get('shipments') or 0),run_id=state.get('task_id',''))
                            # v30.4：该供应商的单点画像——产品档次/供应能力/客户覆盖度（拿到多少、页面共多少）
                            try:
                                from core.trade_graph import supplier_profile as sprof
                                if sprof.profile_supplier(s.get('name'),page_total=int(getattr(w,'last_total',0) or 0),
                                                          customers_found=len(rows),run_id=state.get('task_id','')):
                                    profiled+=1
                            except Exception: pass
                            added=0
                            for r in rows:
                                nm=r.get('name') or '';rn=norm(nm)
                                if not rn:continue
                                e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'products':r.get('products') or '', 'hs':r.get('hs') or [], 'supplier_relation':s.get('name'),'url':url}
                                c={'name':nm,'country':'USA','industry':state.get('industry',''),'type':'importer','website':'','source':'importyeti_reverse','strength':5,'evidence':e}
                                if rn not in have:
                                    have.add(rn);merged.append(c);added+=1;added_total+=1
                                try:
                                    from core.memory.db import DB;DB().add_relationship(state.get('task_id'),s.get('name',''),'supplier',nm,'buyer','supplier_to_customer',e,'importyeti_web',.95,2)
                                except Exception: pass
                            results.append({'source':'importyeti_web','supplier':s.get('name'),'customers':len(rows),'new':added})
                            # v30：渗透完成后标记已收割，下一轮从其他节点继续，不重复挖同一节点
                            try:
                                sup.mark_harvested(sup.norm(s.get('name')),len(rows))
                                _tot=int(getattr(w,'last_total',0) or 0)
                                sup.log_harvest(state.get('task_id'),s.get('slug') or '',s.get('name'),'importyeti_web','ok',len(rows),
                                                f'客户覆盖 {len(rows)}/{_tot}' if _tot else '')
                            except Exception: pass
                        except Exception as e:
                            fails+=1; errors.append(f"{s.get('name')}: {str(e)[:100]}")
                    if skipped_fresh or budget.spent_on:
                        results.append({'source':'importyeti_web','summary':budget.note()+f'·注册表命中跳过{skipped_fresh}个已渗透节点'})
        except Exception as e: errors.append('importyeti_web:'+str(e)[:160])
    # 第三层：ImportKey公开海关公司页，补没有本地/ImportYeti覆盖的供应商反向客户。
    if fallback and settings.IMPORTKEY_ENABLED:
        try:
            from core.tools.data_sources.sources import ImportKeyPublicSource
            ik=ImportKeyPublicSource()
            for s in fallback[:settings.NETWORK_EXPANSION_SUPPLIERS]:
                rows=ik.company_relationships(s.get('name',''),'buyers',settings.IMPORTKEY_MAX_RELATIONS)
                added=0
                for r in rows:
                    nm=r.get('name') or ''; rn=norm(nm)
                    if not rn: continue
                    e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'supplier_relation':s.get('name'),'url':r.get('url') or ''}
                    c={'name':nm,'country':'USA','industry':state.get('industry',''),'type':'importer','website':'','source':'importkey_public','strength':5,'evidence':e}
                    if rn not in have: have.add(rn); merged.append(c); added+=1; added_total+=1
                    try:
                        from core.memory.db import DB; DB().add_relationship(state.get('task_id'),s.get('name',''),'supplier',nm,'buyer','supplier_to_customer',e,'importkey_public',.9,2)
                    except Exception: pass
                if rows: results.append({'source':'importkey_public','supplier':s.get('name'),'customers':len(rows),'new':added})
        except Exception as e: errors.append('importkey_public:'+str(e)[:160])
    # v30：supplier→customer 边与新买家节点合并进贸易关系图谱
    try:
        g=cnp.TradeGraph()
        for c in merged:
            nd=cnp.TradeNode(c.get('name'),c.get('node_role') or c.get('type') or 'importer',c.get('source') or '')
            if c.get('evidence'): nd.add_evidence(c['evidence'])
            g.add_node(nd)
        for e in cnp.relations_to_edges(relations if 'relations' in locals() else [],2): g.add_edge(e)
        trade_graph=cnp.merge_graph_into_state(state,g,depth=2)
    except Exception:
        trade_graph=state.get('trade_graph')
    # v30.4：图谱待展开节点可见化——反复运行即可完善贸易图谱，进度可度量
    try:
        from core.trade_graph import supplier_profile as sprof
        graph_pending=sprof.pending_graph_nodes()
    except Exception: graph_pending={}
    rep=experts.review('REVERSE_HARVEST',f'供应商→客户：透视{len(new)}家，新客户{added_total}，供应商画像{profiled}份，错误{len(errors)}',[('双向海关关系执行',added_total>0 or not errors,f'{added_total}家新增'),('供应商单点画像',profiled>0 or not new,f'{profiled}份')])
    return {'harvest':{'mode':'customs_graph','results':results,'errors':errors,'policy':'customs_only_relationships','suppliers_profiled':profiled},'companies':merged,'trade_graph':trade_graph,'graph_pending':graph_pending,'reverse_new':[x for x in merged if norm(x.get('name')) not in {norm(c.get('name')) for c in state.get('companies',[])}],'node_reports':_report(state,'REVERSE_HARVEST',rep),'_success':True,'_note':f'反向收割 {len(new)} 家工厂·新增客户 {added_total}·供应商画像 {profiled} 份·待展开节点 {graph_pending.get("unharvested_suppliers",0)} 家·全部关系来自海关数据源'}

def n_clean_verify(state):
    companies=list(state.get('companies') or []);out=[];seen=set();dropped=0;known=0;identity_only=0;new_entities=[];existing_entities=[]
    from core.memory.db import DB
    db=DB()
    for x in companies:
        nm=(x.get('name') or '').strip();n=norm(nm)
        if not n or noise(nm):dropped+=1;continue
        if n in seen:continue
        seen.add(n)
        old=db.get_lead(n)
        if old: known+=1; existing_entities.append(x)
        else: new_entities.append(x)
        if not hard_evidence_local(x):identity_only+=1
        out.append(x)
    # 这里故意不写 leads。CLEAN_VERIFY 只负责“识别已有/新实体”，
    # 真正的画像合并与业务分区必须由最后的 DISCOVERY_COMMIT 原子完成。
    # 否则新客户会在这里提前进入 leads，最后节点再看时就会被误判成“已有客户”，
    # 从而出现“采集有结果、开发池却没有客户”的生产级逻辑错误。
    rep=experts.review('CLEAN_VERIFY',f'二轮清洗 输入{len(companies)}→{len(out)}·已有{known}·新增{len(new_entities)}·隔离{dropped}·仅身份{identity_only}',
                       [('计数可解释',len(out)+dropped<=len(companies),f'{len(out)}+{dropped}'),
                        ('增量身份已区分',known+len(new_entities)==len(out),f'已有{known}+新增{len(new_entities)}={len(out)}'),
                        ('身份客户不因缺字段删除',True,'policy locked')],critical={'计数可解释','增量身份已区分'})
    return {'task_data':out,'companies':out,'new_companies':new_entities,'new_entity_companies':new_entities,'existing_enriched_companies':existing_entities,
            'known_count':known,'new_entity_count':len(new_entities),'dropped_count':dropped,'identity_only_count':identity_only,
            'node_reports':_report(state,'CLEAN_VERIFY',rep),'_success':True,'_note':f'二轮清洗 {len(out)} 家·新增 {len(new_entities)}·已有补充 {known}'}

def n_gate(state):
    cs=list(state.get('companies') or state.get('task_data') or []);accepted=[];rejects=[];judgments=[]
    for c in cs:
        e=c.get('evidence') or {}; hard=hard_evidence_local(c); relation=bool(e.get('supplier_relation'))
        # 客户身份和证据强度分离：只有明确非客户才剔除；低完整度客户进入 pending，而不是 reject。
        if noise(c.get('name')):
            decision='reject';reason='明确非客户/服务商'
            rejects.append({'name':c.get('name'),'reason':reason})
        else:
            decision='accept';reason='硬贸易证据' if hard else ('反向供应链关系' if relation else '身份候选（待画像补全）')
            accepted.append(c)
        judgments.append({'name':c.get('name'),'decision':decision,'reason':reason,'hard_evidence':hard})
    strong=sum(1 for c in accepted if hard_evidence_local(c));g={'ok':len(accepted)>=settings.GATE_MIN_QUALIFIED,'raw':len(cs),'qualified':len(accepted),'strong':strong,'rejects':rejects,'judgments':judgments,'qualified_companies':accepted,'identity_only':sum(1 for c in accepted if not hard_evidence_local(c))}
    rep=experts.review('A_GATE',f'候选{len(cs)}·放行{len(accepted)}·强证据{strong}·仅身份{g["identity_only"]}',[('逐家有结论',len(judgments)==len(cs),f'{len(judgments)}/{len(cs)}'),('数量达标',g['ok'],f'{len(accepted)}/{settings.GATE_MIN_QUALIFIED}')],critical={'逐家有结论','数量达标'})
    prior_new={norm(c.get('name')) for c in (state.get('new_companies') or [])}
    new_qualified=[c for c in accepted if norm(c.get('name')) in prior_new]
    g['new_qualified']=len(new_qualified); g['existing_refresh']=len(accepted)-len(new_qualified)
    return {'gate':g,'qualified_companies':accepted,'new_companies':new_qualified,'node_reports':_report(state,'A_GATE',rep),'_success':g['ok'],'_note':f'证据资格：放行{len(accepted)}·新增开发{len(new_qualified)}·已有画像刷新{len(accepted)-len(new_qualified)}·强证据{strong}'}

# ============================================================
# 【旧流程死代码，勿新增调用】以下 n_reflect / n_contact / n_audit / n_correct /
# n_score / n_usitc / n_rank / n_profile / n_analysis / n_outreach / n_learn
# 均不在 graph.ORDER / graph.FN 主编排中（REFLECT 虽在 FN 注册但 _recovery 已不调用）。
# 注意：n_reflect 会设置 abort/query_override 干预流程走向——这是“节点当小编排器”的
# 反模式残留。当前架构：graph.py 唯一拥有流程控制权，节点只拥有执行权。
# 保留仅为兼容历史引用；新功能一律走 ORDER 编排 + 执行工具分层。
# ============================================================
def n_reflect(state):
    fail_node = state.get('_reflect') or 'A_GATE'
    ref = dict(state.get('reflection') or {}); hist = list(ref.get('history') or []); count = int(ref.get('count') or 0)
    last = (state.get('node_reports') or {}).get(fail_node) or {}
    ctx = json.dumps({'industry': state.get('industry'), 'market': state.get('market'),
                      'queries': (state.get('strategy') or {}).get('queries'),
                      'sources': (state.get('strategy') or {}).get('sources') or ['customs','importyeti'],
                      'gate': {k:v for k,v in (state.get('gate') or {}).items() if k in ('raw','qualified','strong')},
                      'companies': len(state.get('companies') or []),
                      'evidence_samples': [{'name':c.get('name'),'source':c.get('source'),'evidence':c.get('evidence') or {}} for c in (state.get('companies') or [])[:5]],
                      'errors': (state.get('source_errors') or [])[:5]}, ensure_ascii=False)
    d = experts.diagnose(fail_node, json.dumps(last, ensure_ascii=False)[:1500], ctx)
    if count >= 1 and settings.WEBAI_ENABLED:
        try:
            from core.tools import web_ai
            ans = web_ai.solve(
                '你是外贸客户采集系统的诊断专家。管线在 %s 节点连续验收失败，本地AI已反思%d轮未解。'
                '请给出：1) 最可能的根因一句话；2) 可执行的纠正建议一句话；3) 3个新的英文搜索查询词。'
                '只输出JSON：{"diagnosis":"","advice":"","new_queries":[]}' % (fail_node, count),
                context='节点报告:\n' + json.dumps(last, ensure_ascii=False)[:1200] + '\n全局:\n' + ctx, timeout=180)
            if ans:
                from core.utils import jsonutil
                j = jsonutil.j(ans)
                if j and j.get('diagnosis'):
                    d = {'diagnosis': '[网页AI] ' + str(j['diagnosis'])[:150],
                         'advice': str(j.get('advice') or d.get('advice') or '')[:200],
                         'new_queries': [str(x)[:80] for x in (j.get('new_queries') or [])][:4] or d.get('new_queries'),
                         'by': 'webai'}
        except Exception as e:
            print('[reflect] webai failed:', str(e)[:60])
    rep = experts.review('REFLECT', f"诊断：{d['diagnosis']}\n处方：{d['advice']}\n新查询词：{d['new_queries']}",
                         [('诊断非空', bool(d.get('diagnosis')), d.get('by',''))])
    hist.append({'round': count+1, 'at_node': fail_node, 'diagnosis': d['diagnosis'], 'advice': d['advice'],
                 'new_queries': d['new_queries'], 'by': d.get('by'), 'ts': time.time()})
    ref = {'count': count+1, 'history': hist}
    up = {'reflection': ref, 'node_reports': _report(state, 'REFLECT', rep),
          '_note': f"第{count+1}轮复盘：{d['diagnosis'][:60]}"}
    if count+1 >= settings.REFLECT_MAX_ROUNDS:
        up['abort'] = 'failed' if fail_node == 'A_COLLECT' else 'failed_gate'
        up['error'] = (state.get('error') or '验收未通过') + f"（已反思{count+1}轮仍不达标，终止。最后诊断：{d['diagnosis']}）"
        up['_reflect'] = None
    else:
        up['_reflect'] = None
        if d['new_queries']:
            up['query_override'] = d['new_queries']
        else:
            up['query_override'] = None
        up.pop('error', None)
    return up

# ---------- 8. CONTACT 联系方式提取员 ----------
def n_contact(state):
    if not settings.CONTACT_ENABLED:
        return {'_success': True, '_note': '联系方式提取已禁用', 'node_reports': _report(state, 'CONTACT', experts.review('CONTACT', '已禁用'))}
    from core.memory.db import DB
    from core.tools import contact_finder, scoring
    db = DB()
    cs = (state.get('new_companies') or [])[:settings.CONTACT_TOP_N]
    leads = []
    for c in cs:
        l = db.get_lead(norm(c.get('name')))
        if l and l.get('kind') == 'importer':
            leads.append(l)
    todo = [l for l in leads if not (l.get('website') or l.get('emails'))]
    ok = 0
    errs = []
    if todo:
        f = contact_finder.ContactFinder()
        try:
            f._launch()
            for l in todo:
                try:
                    r = f.enrich(l, do_audit=False)
                    if r.get('ok'):
                        ok += 1
                except Exception as e:
                    errs.append(str(e)[:60])
                time.sleep(1)
        except Exception as e:
            errs.append('浏览器未就绪: ' + str(e)[:80])
        finally:
            f.close()
    graded = []
    for l in leads:
        l = db.get_lead(l['norm']) or l
        sc, gr, why = scoring.score_lead(l)
        db.lead_update(l['norm'], score=sc, grade=gr)
        graded.append('- %s | %s级 %.1f | 邮箱%s | %s' % (l['name'], gr, sc, '有' if l.get('emails') else '无', why[:60]))
    rep = experts.review('CONTACT',
                         '目标%d家·待补%d家·补全%d家\n评分落库：\n%s' % (len(leads), len(todo), ok, '\n'.join(graded[:12])) +
                         ('\n失败：' + '; '.join(errs[:3]) if errs else ''),
                         [('评分已落库', bool(graded), '%d家' % len(graded)),
                          ('有可用联系方式', ok > 0 or not todo, '补全%d家' % ok if todo else '均已有联系方式')])
    contact_leads = []
    for l in leads:
        fresh = db.get_lead(l['norm'])
        contact_leads.append(fresh if fresh else l)
    return {'node_reports': _report(state, 'CONTACT', rep), '_success': True,
            '_note': f'联系方式补全{ok}/{len(todo)}家·评分{len(graded)}家落库',
            'contact_leads': contact_leads,
            'audit_retry_count': 0,
            'audit_max_retries': 3}

# ---------- 9. AUDIT 资料审核员 ----------
def n_audit(state):
    from core.tools import auditor
    from core.memory.db import DB
    db = DB()
    leads = state.get('contact_leads') or []
    if not leads:
        return {'_success': True, '_note': '无待审核客户', 'audit_pass': True,
                'audit_results': {}, 'corrections': {}, 'audit_retry_count': 0}
    audit_results = {}
    all_pass = True
    suggestions = {}
    updated_leads = []
    for lead in leads:
        updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=state.get('_webai_instance'))
        updated_leads.append(updated)
        audit_results[updated['norm']] = rep
        if rep['verdict'] != 'pass':
            all_pass = False
        if rep.get('ai', {}).get('suggest'):
            suggestions[updated['norm']] = rep['ai']['suggest']
    fail_count = sum(1 for r in audit_results.values() if r['verdict'] != 'pass')
    return {'contact_leads': updated_leads,
            'audit_results': audit_results,
            'corrections': suggestions,
            'audit_pass': all_pass,
            'audit_retry_count': state.get('audit_retry_count', 0),
            '_success': True,
            '_note': '审核通过' if all_pass else f'审核不通过 {fail_count}家'}

# ---------- 10. CORRECT 资料修正员 ----------
def n_correct(state):
    from core.memory.db import DB
    from core.tools import auditor
    db = DB()
    leads = state.get('contact_leads') or []
    audit_results = state.get('audit_results') or {}
    retry = state.get('audit_retry_count', 0) + 1

    updated_leads = []
    for lead in leads:
        updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=state.get('_webai_instance'))
        updated_leads.append(updated)
        audit_results[updated['norm']] = rep

    passed = [l for l in updated_leads if audit_results.get(l['norm'], {}).get('verdict') == 'pass']
    failed = [l for l in updated_leads if audit_results.get(l['norm'], {}).get('verdict') != 'pass']

    if retry >= state.get('audit_max_retries', 3):
        return {
            'contact_leads': passed,
            'audit_results': audit_results,
            'audit_retry_count': retry,
            'audit_pass': True,
            'new_companies': [c for c in state.get('new_companies') or [] if norm(c.get('name')) in [l['norm'] for l in passed]],
            '_success': True,
            '_note': f'第{retry}次修正完成，通过{len(passed)}家，剔除{len(failed)}家'
        }

    all_pass = len(failed) == 0
    return {
        'contact_leads': passed,
        'audit_results': audit_results,
        'audit_retry_count': retry,
        'audit_pass': all_pass,
        'new_companies': state.get('new_companies') if all_pass else [c for c in state.get('new_companies') if norm(c.get('name')) in [l['norm'] for l in passed]],
        '_success': True,
        '_note': f'第{retry}次修正完成，通过{len(passed)}家' + ('' if all_pass else f'，剩余{len(failed)}家')
    }

# ---------- 11. SCORE 评分专家 ----------
def n_score(state):
    from core.memory.db import DB
    from core.tools import scoring
    db = DB()
    scored = 0
    for lead in (state.get('contact_leads') or state.get('new_companies') or []):
        lead_norm = lead.get('norm') or norm(lead.get('name'))
        fresh = db.get_lead(lead_norm) or lead
        try:
            sc, gr, why = scoring.score_lead(fresh)
            db.lead_update(lead_norm, score=sc, grade=gr)
            scored += 1
        except Exception as e:
            print(f'[score] 评分失败 {fresh.get("name")}: {str(e)[:60]}')
    rep = experts.review('SCORE', f'评分完成 {scored} 家',
                         [('评分覆盖', scored > 0, f'{scored}家')])
    return {'node_reports': _report(state, 'SCORE', rep), '_success': True,
            '_note': f'评分完成 {scored} 家'}

# ---------- 阶段二占位节点（兼容 graph.py） ----------
def n_usitc(state):
    return {'_success': True, '_note': '阶段二关闭，跳过',
            'node_reports': _report(state, 'USITC', experts.review('USITC', '跳过'))}

def n_rank(state):
    cs = sorted(state.get('new_companies') or [], key=lambda c: (c.get('strength') or 0), reverse=True)
    return {'new_companies': cs,
            'node_reports': _report(state, 'RANK', experts.review('RANK', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_profile(state):
    return {'profiles': [],
            'node_reports': _report(state, 'B_PROFILE', experts.review('B_PROFILE', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_analysis(state):
    return {'analyses': [],
            'node_reports': _report(state, 'C_ANALYSIS', experts.review('C_ANALYSIS', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_outreach(state):
    return {'letters': [],
            'node_reports': _report(state, 'D_OUTREACH', experts.review('D_OUTREACH', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_learn(state):
    return {'_success': True, '_note': '学习模块已移至后台进化引擎', 'learn_summary': {}}

# ---------- Discovery commit：第一流程只负责把真实客户安全送入客户数据库 ----------
def n_discovery_commit(state):
    from core.memory.db import DB
    db=DB(); accepted=state.get('new_companies') or []
    created=0; updated=0; pending=0; failed=[]; unchanged=0
    for c in accepted:
        e=c.get('evidence') or {}
        hard=bool(e.get('shipments') or e.get('bill_of_lading') or e.get('customs') or e.get('trade_evidence'))
        zone='dev' if hard else 'pending'
        before=db.get_lead(db._norm(c.get('name')))
        result=db.commit_discovery_lead(c,zone=zone)
        if not result.get('ok'):
            failed.append((c.get('name') or '')[:120])
        elif result.get('created'):
            if zone=='dev': created+=1
            else: pending+=1
        elif result.get('changed'):
            updated+=1
        else:
            unchanged+=1
        if result.get('ok'):
            try:
                db.add_evidence_event(state.get('task_id',''), db._norm(c.get('name')), 'customs_incremental', c.get('source') or 'customs', json.dumps(e, ensure_ascii=False)[:1800], 1.0 if hard else 0.5)
            except Exception:
                pass
    ok=(len(failed)==0 and len(accepted)==created+pending+updated+unchanged)
    rep=experts.review('DISCOVERY_COMMIT',f'增量入库{len(accepted)}·新客户开发池{created}·已有画像更新{updated}·无变化{unchanged}·待验证{pending}·失败{len(failed)}',
                       [('候选已可靠入库',ok,f'{len(accepted)}=新{created}+更新{updated}+无变化{unchanged}+待验证{pending}，失败{len(failed)}')],critical={'候选已可靠入库'})
    return {'discovery_commit':{'accepted':len(accepted),'dev':created,'updated':updated,'unchanged':unchanged,'pending':pending,'failed':failed,
                                'policy':'new_only_to_dev; existing_only_merge_evidence'},
            'node_reports':_report(state,'DISCOVERY_COMMIT',rep),'_success':ok,
            '_note':f'增量入库完成：新开发池{created}·已有客户补充{updated}·无变化{unchanged}·待验证{pending}' if ok else f'客户入库失败 {len(failed)} 家：{failed[:3]}'}

