# v30 升级说明（Customs Node Edition）

## 升级目标
基于 v29 trade_graph_customs 作为主版本，恢复并强化 v10 的第一采集链逻辑：
**第一采集链以海关节点为中心，而不是搜索引擎结果为中心。**

## 第一采集链（恢复后的正确方向）
```
关键词
  ↓
海关贸易数据节点（HS 编码 → 海关/提单数据源 fan-out）
  ↓
确定 importer / supplier / shipper / consignee / notify party 节点
  ↓
保存贸易证据（BOL / HS / shipments / 日期 / 来源 → evidence_events / relationships）
  ↓
从节点展开关联企业（buyer→supplier、supplier→customer，customs_graph）
  ↓
贸易关系图谱（state['trade_graph'] + relationships 表）
```

## 本次修改的模块（只改影响采集方向的模块）
1. `core/trade_graph/trade_node.py`（新实现，原为占位）
   - TradeNode / TradeEdge / TradeEvidence / TradeGraph；贸易角色归一与证据结构。
2. `core/trade_graph/customs_node_pipeline.py`（新）
   - CustomsNodePipeline：TRADE_ENTRY → NODE_IDENTIFY → NETWORK_EXPAND → GRAPH_SAVE。
3. `customs/evidence.py`（新实现，原为占位）
   - CustomsEvidence：边必须带 shipment 证据、来源、日期、HS/产品映射与置信度。
4. `engine/trade_graph/{trade_entry,network_expand,supplier_verify,customer_reverse}.py`
   （新实现，原为占位）——四阶段真实逻辑，委托 customs_graph。
5. `core/tools/trade_filter.py`（新）：第一轮简单净化器。
   - 删除：百度百科类页面、无贸易关系网页、新闻、词典、翻译页面、广告目录、明显错误企业。
   - 保留：importer/exporter/supplier/manufacturer/shipper/consignee/notify party/
     HS code/shipment/BOL/trade evidence。不评分、不过度过滤。
6. `core/tools/data_sources/manager.py`
   - 恢复 v10 入口：HS_FINDER 作为第一链第 0 步（关键词→HS→ImportYeti 海关榜单，
     importer 节点 + 页底提单 shipper 种子入池）。
   - 合并候选标注 node_role；identity_valid 保留全部贸易角色。
7. `core/runtime/nodes.py`
   - STRATEGY：恢复 v10“查询词必须含贸易证据信号”约束；目标改为“定位贸易节点”。
   - A_COLLECT：改走 CustomsNodePipeline，产出贸易节点图并保存证据。
   - CLEAN_PASS1：改用 trade_filter 简单净化。
   - SUPPLIER_MINING / REVERSE_HARVEST：关系边合并进 state['trade_graph']。

## 保留不变
数据库（schema/增量入库 DISCOVERY_COMMIT）、WebUI、邮件、AI 能力、
v27/v29 已验证的 customs_graph 双向关系提取、A_GATE/SCORING（第二阶段价值判断）。

## 两阶段边界
- 第一阶段：建立完整贸易节点图（简单净化、不评分、不过滤）。
- 第二阶段：A_GATE / SCORING / CONTACT 做客户价值判断与开发。

## v30.1 修正（针对生产任务 c8594d98 采集为 0 的失败）

失败根因：第一链全部压到 ImportYeti 网页采集，而 iy_web 解析器对页面结构变化失效
（source_errors: 页面0条解析结果），导致 A_COLLECT 三次重试均为 0。

1. 第一搜索必须在 ImportYeti 网站（manager fan-out 顺序调整）：
   importyeti_web 搜索 → hs_finder(HS榜单) → 本地 customs_bulk/customs_raw →
   importyeti API → customs_web。该站结果都是海关记录，天然有效。
2. iy_web 解析层重写（宽松节点定位）：
   - 搜索页：等待结果锚点出现；以 /company/ /supplier/ 链接为节点锚，
     出货量等证据尽量解析、缺字段不丢节点；动态锚失败时从原始 HTML 兜底提取。
   - 关系页：改为 DOM 区域解析（定位 's Suppliers / 's Customers 区域抓关系链接），
     旧文本行解析降级为兜底；区分“真实空区(No results)”与“解析失败”，
     真实空不再误报 parse_empty、不再落调试快照。
   - _shipments_from 兼容 "Total Shipments\n12,345" / "12,345 Shipments" /
     "Total Shipments: 56" 等写法。
3. 节点渗透补全：
   - 搜索/HS榜单落池的 supplier 节点并入 SUPPLIER_MINING 反查链
     （之前只落池不消费，节点关联信息被浪费）。
   - 全部供应商节点落池（sup.norm 统一身份），收割状态持久化：
     已渗透节点下一轮不再重复反查，新节点优先。
   - REVERSE_HARVEST 每层渗透完成后 mark_harvested。
4. 宽松保留不变：第一轮只删明显错误（百科/新闻/词典/翻译/广告目录/货代），
   直接或间接能连上客户信息的碎片全部保留（trade_filter）。

新增测试：test_v30_iy_parsers.py（解析器/渗透链/fan-out 顺序）。
