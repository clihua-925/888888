"""v30 第一采集链回归：海关节点中心 + 第一轮简单净化。

验证：
1. 第一链数据源仅海关类（hs_finder 已恢复为入口），搜索引擎不得进入。
2. 候选被识别为贸易节点（importer/supplier/shipper 角色）并携带贸易证据。
3. 净化器删除百科/新闻/词典/翻译/广告目录/明显错误企业，保留贸易信号候选。
4. 贸易图谱（nodes+edges）在 A_COLLECT→SUPPLIER_MINING→REVERSE_HARVEST 后形成。
"""
import os, sys, time, sqlite3, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
fd, DBPATH = tempfile.mkstemp(suffix='.db'); os.close(fd)
os.environ['DATABASE_PATH'] = DBPATH
os.environ['EXPERT_MODE'] = 'false'; os.environ['MISSION_DIRECTOR_ENABLED'] = 'false'
os.environ['WEBAI_ENABLED'] = 'false'; os.environ['IY_WEB_ENABLED'] = 'false'
os.environ['IMPORTYETI_ENABLED'] = 'false'; os.environ['HS_FINDER_ENABLED'] = 'false'
os.environ['IMPORTKEY_ENABLED'] = 'false'; os.environ['HARVEST_ENABLED'] = 'true'
os.environ['SCHEDULER_ENABLED'] = 'false'
os.environ['GATE_MIN_QUALIFIED'] = '1'   # 测试库规模小，放宽闸门数量（第二阶段策略不在本测试范围）

from core.config import settings
settings.DATABASE_PATH = DBPATH
for k in ('EXPERT_MODE','MISSION_DIRECTOR_ENABLED','WEBAI_ENABLED','IY_WEB_ENABLED',
          'IMPORTYETI_ENABLED','HS_FINDER_ENABLED','IMPORTKEY_ENABLED','SCHEDULER_ENABLED'):
    setattr(settings, k, False)
settings.HARVEST_ENABLED = True
settings.GATE_MIN_QUALIFIED = 1

from core.memory.db import DB
DB()

# 造本地海关原始库：Buyer A ← Supplier X；Buyer B ← Supplier X；Buyer C ← Supplier Y
now = time.time()
with sqlite3.connect(DBPATH) as c:
    rows = [
        ('1','BOL1',now,'Buyer A','buyera','Supplier X','Notify P','3406','birthday candles',1,1,0,'CN','NGB','LAX','t'),
        ('2','BOL2',now-10,'Buyer A','buyera','Supplier X','','3406','number candles',1,1,0,'CN','NGB','LAX','t'),
        ('3','BOL3',now-20,'Buyer B','buyerb','Supplier X','','3406','spiral candles',1,1,0,'CN','NGB','LAX','t'),
        ('4','BOL4',now-30,'Buyer C','buyerc','Supplier Y','','3406','jar candles',1,1,0,'CN','SHA','OAK','t'),
    ]
    c.executemany('INSERT INTO customs_raw(id,bol,ts,importer,importer_norm,shipper,notify,hs,descr,qty,weight,teu,origin,port_load,port_discharge,source_file) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', rows)


def test_purifier():
    from core.tools import trade_filter
    bad = [
        {'name':'蜡烛_百度百科','website':'https://baike.baidu.com/item/x'},
        {'name':'candle meaning in english','website':'https://dictionary.cambridge.org/x'},
        {'name':'candle news today market report','website':'https://somenews.com/a'},
        {'name':'candle translation french','website':'https://www.wordreference.com/x'},
        {'name':'wholesale candle ads','website':'https://www.alibaba.com/showroom/candle.html'},
        {'name':'Fast Freight Forwarding LLC'},   # 明显错误企业（货代）
        {'name':'How to choose the best birthday candles for your party'},  # 无贸易关系网页
        {'name':''},
    ]
    good = [
        {'name':'Acme Candle Imports LLC','type':'importer','evidence':{'shipments':12}},
        {'name':'Ningbo Wax Manufacturer Co','type':'manufacturer','evidence':{}},
        {'name':'Pacific Consignee Group Inc','type':'consignee','evidence':{}},
        {'name':'Qingdao Shipper Trading Ltd','type':'shipper','evidence':{'bol':'BOL9'}},
        {'name':'Plain Buyer LLC','type':'importer','evidence':{}},  # 仅身份也保留
    ]
    kept, dropped = trade_filter.purify(bad + good)
    assert len(kept) == len(good), [x.get('name') for x in kept]
    assert len(dropped) == len(bad), [(c.get('name'), r) for c, r in dropped]
    print('PURIFIER_OK', len(kept), 'kept /', len(dropped), 'dropped')


def test_node_pipeline():
    from core.trade_graph import customs_node_pipeline as cnp
    from core.trade_graph.trade_node import TradeNode, TradeGraph
    cands = [
        {'name':'Buyer A','type':'importer','source':'customs_raw','evidence':{'shipments':2,'hs':['3406'],'customs':True}},
        {'name':'Supplier X','kind':'supplier','source':'customs_raw','evidence':{'shipments':5}},
    ]
    g = cnp.build_trade_nodes(cands)
    st = g.stats()
    assert st['nodes'] == 2 and st['by_role'].get('importer') == 1 and st['by_role'].get('supplier') == 1
    # 从 Buyer A 展开：必须命中 Supplier X；再反查得到 Buyer B
    g2, rels = cnp.expand_from_nodes(['Buyer A'], task_id='t30')
    names = {n.name for n in g2.nodes.values()}
    assert 'Supplier X' in names and {'Buyer A','Buyer B'} <= names, names
    assert all(r['source'] == 'customs_raw' for r in rels)
    # 图谱保存
    out = cnp.save_graph(g2, task_id='t30')
    assert out['relations_saved'] >= 3, out
    # engine 层四阶段
    from engine.trade_graph.trade_entry import TradeEntryNode
    from engine.trade_graph.network_expand import expand_trade_node
    from engine.trade_graph.supplier_verify import verify_supplier
    from engine.trade_graph.customer_reverse import reverse_customers
    e = TradeEntryNode.create('candle', industry='candle')
    assert e.hs_codes and e.evidence_required
    assert verify_supplier({'name':'Supplier X','evidence':{}}) is True   # 本地 customs_raw 兜底命中
    assert verify_supplier({'name':'Nobody','evidence':{}}) is False
    rev = reverse_customers('Supplier X')
    assert {b['name'] for b in rev['buyers']} == {'Buyer A','Buyer B'}
    r = expand_trade_node('Buyer A')
    assert r['status'] == 'ok' and r['edges']
    print('NODE_PIPELINE_OK', st, 'rels:', len(rels))


def test_full_first_chain():
    import core.tools.data_sources.manager as mgr
    def fake_search(self, market, industry, quantity, variants_override=None, source_queries=None, hs_codes=None):
        assert hs_codes is not None  # v30：HS 编码必须传入第一链
        return ([{'name':'Buyer A','country':market,'industry':industry,'type':'importer',
                  'source':'customs_raw','strength':5,'evidence':{'shipments':2,'hs':['3406'],'customs':True,'trade_evidence':True}}],
                ['customs_raw'], [], {'ok':True,'raw':1,'qualified':1,'strong':1,'new_candidates':1,'existing_enriched':0})
    mgr.DataSourceManager.search = fake_search
    from core.runtime.orchestrator import Orchestrator
    orch = Orchestrator()
    out = orch.run('v30 chain test', 'USA', 'candle', 3, task_id='v30-chain')
    assert out.get('success') is True, out.get('error')
    tg = out.get('trade_graph') or {}
    stats = (tg.get('stats') or {})
    assert stats.get('nodes', 0) >= 2, stats           # Buyer A + Supplier X（+Buyer B 反查）
    assert stats.get('edges', 0) >= 1, stats
    roles = stats.get('by_role') or {}
    assert roles.get('supplier', 0) >= 1, roles        # 供应商节点已识别
    assert out.get('source') == 'customs_raw', out.get('source')  # 第一链来源是海关节点
    print('FIRST_CHAIN_OK', stats)


if __name__ == '__main__':
    test_purifier()
    test_node_pipeline()
    test_full_first_chain()
    print('V30_CUSTOMS_NODE_CHAIN_ALL_OK')
