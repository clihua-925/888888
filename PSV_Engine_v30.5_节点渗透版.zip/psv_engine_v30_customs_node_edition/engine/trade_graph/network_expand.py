# -*- coding: utf-8 -*-
"""NETWORK_EXPAND：从已确定的贸易节点展开关联企业。

只使用海关关系（本地 customs_raw 双向提取），
不从普通网页结果猜测客户关系。
"""
from core.trade_graph.customs_node_pipeline import expand_from_nodes
from core.trade_graph.trade_node import TradeNode


def expand_trade_node(node, task_id='', per_supplier=None, per_customer=None):
    """展开单个节点：buyer→其 supplier；supplier→其 customer。
    node 可以是 TradeNode / dict(含 name) / 纯名字符串。"""
    if isinstance(node, TradeNode):
        name = node.name
    elif isinstance(node, dict):
        name = node.get('name') or node.get('company') or ''
    else:
        name = str(node or '')
    if not name.strip():
        return {'parent': name, 'edges': [], 'nodes': 0, 'status': 'empty_node'}
    graph, relations = expand_from_nodes([name], task_id, per_supplier, per_customer)
    return {'parent': name, 'edges': [e.to_dict() for e in graph.edges],
            'nodes': len(graph.nodes), 'relations': relations,
            'status': 'ok' if graph.edges else 'no_customs_coverage'}
