# -*- coding: utf-8 -*-
"""TRADE_ENTRY：关键词 → 海关贸易数据节点 的入口定义。

第一次搜索的目标不是找联系方式，而是定位贸易节点：
关键词先解析为 HS 编码 + 海关源查询变体，再交给海关数据源 fan-out。
"""
from core.trade_graph.customs_node_pipeline import resolve_hs_codes


class TradeEntryNode:
    """贸易入口节点：携带关键词、HS 编码与“必须带贸易证据”的约束。"""

    def __init__(self, keyword, source='customs', hs_codes=None):
        self.keyword = str(keyword or '').strip()
        self.source = source
        self.hs_codes = list(hs_codes or [])
        self.evidence_required = True   # 无贸易证据不成为节点

    @classmethod
    def create(cls, keyword, source='customs', industry=None, icp=None):
        return cls(keyword, source=source,
                   hs_codes=resolve_hs_codes(industry or keyword, icp))

    def to_dict(self):
        return {'node_type': 'trade_entry', 'keyword': self.keyword,
                'source': self.source, 'hs_codes': self.hs_codes,
                'evidence_required': self.evidence_required}
