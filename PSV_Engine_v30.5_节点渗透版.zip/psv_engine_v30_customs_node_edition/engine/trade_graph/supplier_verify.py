# -*- coding: utf-8 -*-
"""SUPPLIER_VERIFY：供应商节点的海关证据核验。

只认海关贸易证据（shipments / BOL / customs_raw 原始记录），
不接受网页介绍作为供应商身份证明。
"""
import sqlite3

from core.config import settings
from core.trade_graph.trade_node import norm_name


def verify_supplier(record):
    """record: dict（含 name/evidence）。返回 True=有海关证据支撑。"""
    ev = (record or {}).get('evidence') or {}
    if ev.get('customs') or ev.get('trade_evidence') or ev.get('shipments') \
            or ev.get('bill_of_lading') or ev.get('bol'):
        return True
    name = (record or {}).get('name') or ''
    if not name.strip():
        return False
    # 兜底：本地海关原始库里是否存在该发货人记录
    try:
        with sqlite3.connect(settings.DATABASE_PATH, timeout=10) as c:
            rows = c.execute(
                "SELECT shipper FROM customs_raw WHERE shipper IS NOT NULL AND TRIM(shipper)!=''"
            ).fetchall()
        target = norm_name(name)
        return any(norm_name(r[0]) == target for r in rows)
    except Exception:
        return False
