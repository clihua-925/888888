# -*- coding: utf-8 -*-
"""CUSTOMER_REVERSE：供应商 → 买家 反查（只走海关关系）。"""
from core.tools.customs_graph import supplier_to_buyers


def reverse_customers(supplier, limit_per=None):
    """supplier: dict(含 name) 或名字符串。返回 {'supplier':..., 'buyers':[...], 'relations':[...]}。"""
    name = supplier.get('name') if isinstance(supplier, dict) else str(supplier or '')
    if not name.strip():
        return {'supplier': name, 'buyers': [], 'relations': []}
    buyers, relations = supplier_to_buyers(
        [{'name': name}], limit_per)
    return {'supplier': name, 'buyers': buyers, 'relations': relations}
