# -*- coding: utf-8 -*-
"""v30 海关贸易证据对象。

约束（见 schema.md）：贸易边必须带有 shipment 证据、来源、日期、HS/产品映射与置信度。
任何“网页看起来像”都不能构造 CustomsEvidence。
"""


class CustomsEvidence:
    """一票/一组海关交易证据。缺来源或无出货信息时 is_valid=False。"""

    __slots__ = ('source', 'shipment', 'hs', 'date', 'products', 'bol',
                 'importer', 'shipper', 'notify_party', 'confidence')

    def __init__(self, source, shipment=None, hs=None, date=None, products=None,
                 bol='', importer='', shipper='', notify_party='', confidence=1.0):
        self.source = str(source or '')
        self.shipment = int(shipment or 0)
        self.hs = str(hs or '')
        self.date = date
        self.products = str(products or '')
        self.bol = str(bol or '')
        self.importer = str(importer or '')
        self.shipper = str(shipper or '')
        self.notify_party = str(notify_party or '')
        self.confidence = float(confidence or 0)

    @property
    def is_valid(self):
        """证据成立的最低条件：有来源，且有出货数/提单号/HS+日期 之一。"""
        if not self.source:
            return False
        return bool(self.shipment or self.bol or (self.hs and self.date))

    def involves(self, name):
        from core.trade_graph.trade_node import norm_name
        n = norm_name(name)
        return bool(n) and n in {norm_name(self.importer), norm_name(self.shipper),
                                 norm_name(self.notify_party)}

    def to_dict(self):
        return {'source': self.source, 'shipment': self.shipment, 'hs': self.hs,
                'date': self.date, 'products': self.products, 'bol': self.bol,
                'importer': self.importer, 'shipper': self.shipper,
                'notify_party': self.notify_party, 'confidence': self.confidence,
                'customs': True, 'trade_evidence': True}
