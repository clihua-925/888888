# PSV Trade Intelligence OS v3.0.0

## 系统定位

**PSV = 外贸智能业务系统**

**LangGraph 编排智能体 = 系统核心运行引擎**

基于原始 **v45.14 DeepSeek70B LayeredCollection** 系统重构升级，保留全部业务逻辑，以 LangGraph 状态图重新编排。

---

## 架构演进

### 原始系统 (v45.14)
```
Flask + 自定义状态机
├── 9节点采集链 (PRODUCT_DEFINITION → DATABASE_COMMIT)
├── 6种网络扩张策略
├── 6节点业务执行中心
├── 瀑布式 enrichment (web_ai → customs_graph → iy_web → suppliers)
├── AI Judge 自动审核
└── 统一实体表 + 贸易关系边
```

### 新架构 (v3.0.0)
```
FastAPI + LangGraph StateGraph
├── LangGraph 编排引擎 (8个Agent节点)
├── 原始系统适配层 (legacy/ 完整保留)
├── Contract 契约层 (AgentRequest/AgentResponse)
├── Audit 审计层 (全链路追踪)
├── Recovery 恢复机制 (检查点)
├── 新数据库模型 (兼容原始表结构)
└── 双API体系 (新架构 + 原始兼容)
```

---

## 目录结构

```
PSV Trade Intelligence OS/
├── app/                    # FastAPI 统一入口
│   └── main.py             # 兼容原始系统 API + 新架构 API
├── legacy/                 # 原始 v45.14 系统完整保留 (79个文件)
│   ├── core/
│   │   ├── system.py       # PSVSystem 主编排器
│   │   ├── memory/
│   │   │   └── db.py       # 统一实体数据库 (87KB)
│   │   ├── runtime/
│   │   │   ├── graph.py    # 9节点采集状态图
│   │   │   └── orchestrator.py
│   │   ├── business_execution/
│   │   │   └── execution_center.py  # 6节点业务执行
│   │   ├── tools/
│   │   │   ├── expand.py   # 网络扩张 (6种策略)
│   │   │   ├── web_ai.py   # CDP浏览器AI采集
│   │   │   ├── customs_graph.py
│   │   │   ├── iy_web.py   # ImportYeti
│   │   │   ├── suppliers.py
│   │   │   ├── trade_filter.py
│   │   │   └── hs_finder.py
│   │   ├── intelligence/
│   │   │   ├── ai_router.py    # AI路由 (本地+网页AI)
│   │   │   ├── waterfall.py    # 瀑布enrichment
│   │   │   └── local_judge.py  # 本地LLM审核
│   │   ├── webui/          # Flask WebUI (7个页面)
│   │   ├── config/         # 行业/市场配置
│   │   └── trade_graph/
│   └── data/
│       └── industry_configs/   # candle/enamel_pot/felt
├── orchestrator/           # LangGraph 核心编排引擎
│   ├── graph.py            # StateGraph + 原始系统适配
│   ├── state.py            # TradeGraphState TypedDict
│   ├── planner.py          # TradePlannerAgent
│   ├── supervisor.py       # SupervisorAgent
│   ├── router.py           # 条件路由
│   ├── executor.py         # 节点执行引擎
│   ├── checkpoint.py       # 检查点持久化
│   └── recovery.py         # 中断恢复
├── agents/                 # 8个专业Agent
├── business/               # 业务层 (采集/enrichment/评分/策略/分析)
├── contracts/              # 契约层
├── shared/                 # 共享层 (Memory/State/Knowledge/Config/Cache)
├── audit/                  # 审计层
├── database/               # SQLAlchemy 模型 (兼容原始表结构)
├── platform/               # 平台服务
│   ├── llm_service.py
│   ├── search_service.py
│   ├── scraper_service.py
│   ├── email_service.py
│   └── adapter.py          # 原始系统适配层 ⭐
├── webui/                  # Streamlit 新界面
└── tests/                  # 测试
```

---

## 核心流程

```
用户外贸目标
    ↓
Trade Intent 输入层
    ↓
LangGraph Orchestrator (新架构)
    ↓
Agent 工作流系统
    ↓
原始系统适配层 (legacy/)
    ↓
9节点采集链 / 6种扩张策略 / 瀑布enrichment
    ↓
客户池 / 企业画像 / 商业机会
    ↓
数据库持久化 (兼容原始表结构)
    ↓
审计追踪
```

---

## 安装

```bash
pip install -r requirements.txt
cp .env.example .env
# 编辑 .env 填入配置
```

---

## 启动

### API 模式
```bash
python app/main.py
# 访问 http://localhost:8000/docs
```

### WebUI 模式
```bash
streamlit run webui/app.py
# 访问 http://localhost:8501
```

---

## API 接口

### 新架构 API
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/trade/execute` | LangGraph执行外贸任务 |
| GET | `/trade/status/{task_id}` | 任务状态+审计 |
| GET | `/trade/tasks` | 任务列表 |
| POST | `/trade/recover/{workflow_id}` | 恢复中断任务 |
| GET | `/trade/companies` | 企业列表 |
| GET | `/trade/leads` | 线索列表 |

### 原始系统兼容 API
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/collect` | 9节点采集链 |
| POST | `/api/expand` | 网络扩张 |
| GET | `/api/entity/{norm}` | 实体查询 |
| GET | `/api/entities` | 实体列表 |
| GET | `/api/trade_edges` | 贸易关系 |
| GET | `/api/intelligence/{norm}` | 情报查询 |
| GET | `/api/tasks` | 任务列表 |
| GET | `/api/leads` | 线索列表 |
| GET | `/api/industries` | 行业配置 |
| GET | `/api/markets` | 市场列表 |

---

## 核心特性

- ✅ **LangGraph 驱动全过程** - 8个Agent节点条件路由
- ✅ **原始系统完整保留** - `legacy/` 目录79个文件，业务逻辑零丢失
- ✅ **适配层桥接** - `platform/adapter.py` 懒加载原始系统
- ✅ **双API体系** - 新架构API + 原始系统兼容API
- ✅ **Contract 契约层** - AgentRequest/AgentResponse 标准化通信
- ✅ **Audit 审计层** - 全链路追踪
- ✅ **Recovery 恢复机制** - 检查点保存/加载
- ✅ **兼容原始数据库** - entities/trade_edges/evidence/contacts 等核心表
- ✅ **行业配置保留** - candle/enamel_pot/felt JSON配置
- ✅ **WebUI 业务导向** - 市场/客户池/画像/机会/报告

---

## 环境变量

```bash
# 原始系统配置
INDUSTRY=candle
LLM_BASE_URL=http://192.168.1.26:8081/v1
LLM_MODEL=deepseek-r1-distill-llama-70b
DATABASE_PATH=./data/psv.db

# 新架构配置
LLM_PROVIDER=openai
LLM_MODEL_NEW=gpt-4o
LLM_API_KEY_NEW=sk-xxx
SEARCH_ENGINE=duckduckgo
DATABASE_URL=sqlite:///psv_trade_os.db
```

---

## 测试

```bash
pytest tests/unit/
pytest tests/integration/
```

---

**PSV Trade Intelligence OS v3.0.0**
*以 LangGraph 多智能体编排系统为核心，以外贸客户开发为业务目标的外贸智能操作系统*
*兼容 v45.14 DeepSeek70B LayeredCollection 全部业务逻辑*
