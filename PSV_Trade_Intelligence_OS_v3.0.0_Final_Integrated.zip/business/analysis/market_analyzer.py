"""
business/analysis/market_analyzer.py - 市场分析引擎
"""
import time
from typing import Dict, Any
from dataclasses import dataclass, field

from platform.llm_service import LLMService
from platform.search_service import SearchService

@dataclass
class MarketAnalysisResult:
    market_report: Dict[str, Any] = field(default_factory=dict)
    competitor_list: list = field(default_factory=list)
    trend_analysis: Dict[str, Any] = field(default_factory=dict)
    duration_ms: int = 0

class MarketAnalyzer:
    """市场分析引擎"""

    def __init__(self):
        self.llm = LLMService()
        self.search = SearchService()

    def analyze(self, product: str, market: str) -> MarketAnalysisResult:
        """分析市场"""
        start = time.time()

        # 1. 搜索市场信息
        search_queries = [
            f"{product} market size {market} 2024",
            f"{product} import data {market}",
            f"{product} industry trends {market}",
        ]

        search_data = []
        for q in search_queries:
            results = self.search.search(q, num_results=5)
            search_data.extend([r.to_dict() for r in results])

        # 2. LLM分析
        prompt = f"""Analyze the {product} market in {market} based on this search data.

Search Results:
{chr(10).join([f"- {s.get('title', '')}: {s.get('snippet', '')[:200]}" for s in search_data[:10]])}

Generate a comprehensive market analysis JSON:
- market_size: estimated market size and growth
- key_players: list of major competitors (name, country, strength)
- demand_trends: current demand trends (growing/stable/declining)
- price_range: typical price range indicators
- entry_barriers: challenges for new entrants
- opportunities: specific opportunities for a new supplier
- seasonality: any seasonal patterns
- regulatory_notes: important regulations

Return valid JSON only."""

        llm_result = self.llm.json_complete(prompt)

        if "error" in llm_result:
            llm_result = self._fallback_analysis(product, market)

        # 3. 提取竞争对手
        competitors = llm_result.get("key_players", [])

        return MarketAnalysisResult(
            market_report=llm_result,
            competitor_list=competitors,
            trend_analysis={
                "demand": llm_result.get("demand_trends", "unknown"),
                "seasonality": llm_result.get("seasonality", "unknown"),
            },
            duration_ms=int((time.time() - start) * 1000),
        )

    def _fallback_analysis(self, product: str, market: str) -> Dict[str, Any]:
        return {
            "market_size": f"{market} {product} market is significant with steady demand",
            "key_players": [],
            "demand_trends": "stable",
            "price_range": "mid-range",
            "entry_barriers": ["Quality standards", "Logistics"],
            "opportunities": ["Growing e-commerce channel", "Sustainability trend"],
            "seasonality": "Q4 peak season",
            "regulatory_notes": "Standard import regulations apply",
        }
