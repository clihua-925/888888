"""
business/collection/company_collector.py - 企业采集引擎
负责：全球企业发现、买家发现、进口商发现、经销商发现、供应商发现
"""
import time
from typing import List, Dict, Any
from dataclasses import dataclass, field

from platform.search_service import SearchService
from platform.scraper_service import ScraperService
from contracts.data_contract import CompanyProfile, CompanySize

@dataclass
class CollectionResult:
    companies: List[CompanyProfile] = field(default_factory=list)
    raw_results: List[Dict[str, Any]] = field(default_factory=list)
    duration_ms: int = 0
    error: str = None

class CompanyCollector:
    """企业采集引擎"""

    def __init__(self):
        self.search = SearchService()
        self.scraper = ScraperService()

    def collect(self, product: str, market: str, target_type: str = "importer", 
                max_results: int = 50) -> CollectionResult:
        """采集企业"""
        start = time.time()

        # 1. 搜索
        search_results = self.search.search_companies(product, market, target_type, max_results * 2)

        # 2. 去重并访问网站
        companies = []
        seen_domains = set()

        for sr in search_results:
            domain = self._extract_domain(sr.url)
            if domain in seen_domains or not domain:
                continue
            seen_domains.add(domain)

            # 快速抓取
            info = self.scraper.extract_company_info(sr.url)

            if info.get("success"):
                company = self._build_profile(sr, info, market)
                companies.append(company)

            if len(companies) >= max_results:
                break

        return CollectionResult(
            companies=companies,
            raw_results=[r.to_dict() for r in search_results],
            duration_ms=int((time.time() - start) * 1000),
        )

    def _extract_domain(self, url: str) -> str:
        from urllib.parse import urlparse
        try:
            parsed = urlparse(url)
            return parsed.netloc.lower().replace("www.", "")
        except:
            return ""

    def _build_profile(self, search_result, info: Dict[str, Any], market: str) -> CompanyProfile:
        """构建企业画像"""
        return CompanyProfile(
            name=info.get("title", search_result.title)[:200],
            country=market,
            website=search_result.url,
            industry=", ".join(info.get("industry_hints", []))[:200] or None,
            main_products=info.get("products_hints", []),
            credibility_score=30.0,  # 基础可信度
            source="search_engine",
            metadata={
                "search_snippet": search_result.snippet,
                "scraped_text_length": len(info.get("text", "")),
            }
        )
