"""
business/collection/__init__.py
"""
from .company_collector import CompanyCollector, CollectionResult

__all__ = ["CompanyCollector", "CollectionResult"]
