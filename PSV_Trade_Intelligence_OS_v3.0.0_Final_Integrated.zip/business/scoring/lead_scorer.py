"""
business/scoring/lead_scorer.py - 线索评分引擎
"""
import time
from typing import List, Dict, Any
from dataclasses import dataclass, field

from platform.llm_service import LLMService
from contracts.data_contract import CompanyProfile, CustomerIntelligence, CustomerLevel, LeadStatus

@dataclass
class ScoringResult:
    scored: List[CustomerIntelligence] = field(default_factory=list)
    duration_ms: int = 0

class LeadScorer:
    """线索评分引擎"""

    def __init__(self):
        self.llm = LLMService()

    def score_batch(self, companies: List[CompanyProfile], product: str = "") -> ScoringResult:
        """批量评分"""
        start = time.time()
        scored = []

        for company in companies:
            score = self._calculate_score(company, product)
            scored.append(score)

        # 按分数排序
        scored.sort(key=lambda x: x.value_score + x.match_score + x.deal_probability, reverse=True)

        return ScoringResult(
            scored=scored,
            duration_ms=int((time.time() - start) * 1000),
        )

    def _calculate_score(self, company: CompanyProfile, product: str) -> CustomerIntelligence:
        """计算单个企业评分"""

        # 1. 企业实力分 (0-40)
        strength_score = self._company_strength(company)

        # 2. 采购可能性 (0-30)
        procurement_score = self._procurement_likelihood(company, product)

        # 3. 匹配程度 (0-20)
        match_score = self._match_degree(company, product)

        # 4. 成交概率 (0-10)
        deal_score = self._deal_probability(company)

        total = strength_score + procurement_score + match_score + deal_score

        # 确定客户等级
        level = CustomerLevel.COLD
        if total >= 80:
            level = CustomerLevel.VIP
        elif total >= 65:
            level = CustomerLevel.HOT
        elif total >= 45:
            level = CustomerLevel.WARM

        return CustomerIntelligence(
            company_id=company.company_id,
            level=level,
            value_score=round(total, 1),
            match_score=round(match_score * 5, 1),  # 放大到100分制
            deal_probability=round(deal_score * 10, 1),
            development_priority=min(10, max(1, int(total / 10))),
            follow_up_status=LeadStatus.NEW,
        )

    def _company_strength(self, company: CompanyProfile) -> float:
        """企业实力评分 0-40"""
        score = 0

        # 网站质量
        score += min(15, company.credibility_score / 6.67)

        # 企业规模
        size_scores = {
            CompanySize.STARTUP: 5,
            CompanySize.SMALL: 8,
            CompanySize.MEDIUM: 12,
            CompanySize.LARGE: 15,
            CompanySize.ENTERPRISE: 18,
        }
        score += size_scores.get(company.company_size, 5)

        # 联系信息完整度
        if company.contacts:
            score += min(7, len(company.contacts) * 2)

        return min(40, score)

    def _procurement_likelihood(self, company: CompanyProfile, product: str) -> float:
        """采购可能性 0-30"""
        score = 10  # 基础分

        # 如果明确提到采购方向
        if company.procurement_direction:
            for direction in company.procurement_direction:
                if product.lower() in direction.lower():
                    score += 15
                    break
            else:
                score += 5

        # 进口商/经销商类型加分
        if company.industry:
            ind = company.industry.lower()
            if any(k in ind for k in ["import", "trade", "distribution", "wholesale"]):
                score += 8

        return min(30, score)

    def _match_degree(self, company: CompanyProfile, product: str) -> float:
        """匹配程度 0-20"""
        score = 5

        if product and company.main_products:
            product_lower = product.lower()
            for mp in company.main_products:
                if product_lower in mp.lower() or mp.lower() in product_lower:
                    score += 10
                    break

        return min(20, score)

    def _deal_probability(self, company: CompanyProfile) -> float:
        """成交概率 0-10"""
        score = 3

        # 有邮箱加分
        has_email = any(c.get("type") == "email" for c in company.contacts)
        if has_email:
            score += 4

        # 有电话加分
        has_phone = any(c.get("type") == "phone" for c in company.contacts)
        if has_phone:
            score += 2

        # 有社交媒体加分
        if company.metadata.get("social_links"):
            score += 1

        return min(10, score)
