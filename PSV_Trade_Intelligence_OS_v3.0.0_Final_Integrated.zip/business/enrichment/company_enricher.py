"""
business/enrichment/company_enricher.py - 企业信息补全引擎
"""
import time
from typing import List, Dict, Any
from dataclasses import dataclass, field

from platform.scraper_service import ScraperService
from platform.llm_service import LLMService
from contracts.data_contract import CompanyProfile, CompanySize

@dataclass
class EnrichmentResult:
    enriched: List[CompanyProfile] = field(default_factory=list)
    failed: List[str] = field(default_factory=list)
    duration_ms: int = 0

class CompanyEnricher:
    """企业信息补全引擎"""

    def __init__(self):
        self.scraper = ScraperService()
        self.llm = LLMService()

    def enrich_batch(self, companies: List[CompanyProfile]) -> EnrichmentResult:
        """批量补全企业信息"""
        start = time.time()
        enriched = []
        failed = []

        for company in companies:
            try:
                result = self.enrich_single(company)
                if result:
                    enriched.append(result)
                else:
                    failed.append(company.company_id)
            except Exception as e:
                failed.append(company.company_id)

        return EnrichmentResult(
            enriched=enriched,
            failed=failed,
            duration_ms=int((time.time() - start) * 1000),
        )

    def enrich_single(self, company: CompanyProfile) -> CompanyProfile:
        """补单单个企业"""
        if not company.website:
            return company

        # 1. 深度抓取
        info = self.scraper.extract_company_info(company.website)
        if not info.get("success"):
            return company

        # 2. LLM分析
        prompt = f"""Analyze this company information and extract structured data.

Website Title: {info.get("title", "")}
Description: {info.get("description", "")[:500]}
Text Snippets: {info.get("text", "")[:1500]}

Extract and return JSON with these fields:
- industry: primary industry
- main_products: list of main products or services (max 5)
- procurement_direction: what they likely buy/import (max 3)
- company_size: one of [startup, small, medium, large, enterprise, unknown]
- country: country if detectable
- credibility_assessment: score 0-100 based on website professionalism

Return valid JSON only."""

        llm_result = self.llm.json_complete(prompt)

        if "error" not in llm_result:
            if llm_result.get("industry"):
                company.industry = llm_result["industry"]
            if llm_result.get("main_products"):
                company.main_products = llm_result["main_products"]
            if llm_result.get("procurement_direction"):
                company.procurement_direction = llm_result["procurement_direction"]
            if llm_result.get("company_size"):
                try:
                    company.company_size = CompanySize(llm_result["company_size"].lower())
                except:
                    pass
            if llm_result.get("country") and not company.country:
                company.country = llm_result["country"]
            if llm_result.get("credibility_assessment"):
                company.credibility_score = max(company.credibility_score, float(llm_result["credibility_assessment"]))

        # 3. 更新联系信息
        if info.get("emails"):
            for email in info["emails"][:3]:
                company.contacts.append({
                    "type": "email",
                    "value": email,
                    "source": "website",
                })

        if info.get("phones"):
            for phone in info["phones"][:2]:
                company.contacts.append({
                    "type": "phone",
                    "value": phone,
                    "source": "website",
                })

        if info.get("social_links"):
            company.metadata["social_links"] = info["social_links"]

        company.credibility_score = min(100, company.credibility_score + 10)
        company.last_updated = __import__("datetime").datetime.now().isoformat()

        return company
