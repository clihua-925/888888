"""
business/strategy/__init__.py
"""
from .sales_strategy_generator import SalesStrategyGenerator, StrategyResult

__all__ = ["SalesStrategyGenerator", "StrategyResult"]
