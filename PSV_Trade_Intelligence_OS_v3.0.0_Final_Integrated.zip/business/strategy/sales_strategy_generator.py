"""
business/strategy/sales_strategy_generator.py - 销售策略生成引擎
"""
import time
from typing import List, Dict, Any
from dataclasses import dataclass, field

from platform.llm_service import LLMService
from contracts.data_contract import CompanyProfile, CustomerIntelligence

@dataclass
class StrategyResult:
    strategies: List[Dict[str, Any]] = field(default_factory=list)
    duration_ms: int = 0

class SalesStrategyGenerator:
    """销售策略生成引擎"""

    def __init__(self):
        self.llm = LLMService()

    def generate_batch(self, leads: List[CustomerIntelligence], 
                       companies: List[CompanyProfile], product: str = "") -> StrategyResult:
        """批量生成策略"""
        start = time.time()
        strategies = []

        # 建立company_id映射
        company_map = {c.company_id: c for c in companies}

        for lead in leads:
            company = company_map.get(lead.company_id)
            if not company:
                continue

            strategy = self._generate_single(lead, company, product)
            strategies.append(strategy)

        return StrategyResult(
            strategies=strategies,
            duration_ms=int((time.time() - start) * 1000),
        )

    def _generate_single(self, lead: CustomerIntelligence, company: CompanyProfile, 
                         product: str) -> Dict[str, Any]:
        """为单个客户生成策略"""

        # 使用LLM生成策略
        prompt = f"""Generate a sales development strategy for this prospect.

Company: {company.name}
Country: {company.country}
Industry: {company.industry or "Unknown"}
Products: {", ".join(company.main_products) if company.main_products else "Unknown"}
Our Product: {product}
Match Score: {lead.match_score}/100
Deal Probability: {lead.deal_probability}%

Generate JSON with:
- approach_strategy: best approach method (email/linkedin/cold_call/trade_show)
- email_subject: compelling email subject line (English)
- email_body: short personalized email body (3-4 sentences, English)
- key_talking_points: list of 3 key points to mention
- follow_up_plan: list of follow-up actions with timing
- risk_factors: list of potential objections and responses
- priority_reason: why this lead is priority

Return valid JSON only."""

        llm_result = self.llm.json_complete(prompt)

        if "error" in llm_result:
            # 回退到模板策略
            return self._fallback_strategy(lead, company, product)

        return {
            "company_id": company.company_id,
            "company_name": company.name,
            "lead_level": lead.level.value,
            "score": lead.value_score,
            "strategy": llm_result,
            "generated_at": __import__("datetime").datetime.now().isoformat(),
        }

    def _fallback_strategy(self, lead: CustomerIntelligence, company: CompanyProfile, 
                           product: str) -> Dict[str, Any]:
        """模板策略回退"""
        return {
            "company_id": company.company_id,
            "company_name": company.name,
            "lead_level": lead.level.value,
            "score": lead.value_score,
            "strategy": {
                "approach_strategy": "email",
                "email_subject": f"Quality {product} supplier - partnership opportunity",
                "email_body": f"Hi, I noticed {company.name} is active in the {company.industry or 'market'}. We specialize in {product} and would love to explore a partnership.",
                "key_talking_points": ["Quality assurance", "Competitive pricing", "Fast delivery"],
                "follow_up_plan": [
                    {"day": 1, "action": "Send initial email"},
                    {"day": 4, "action": "Follow-up email"},
                    {"day": 8, "action": "LinkedIn connection"},
                ],
                "risk_factors": ["No response", "Already has supplier"],
                "priority_reason": f"High match score ({lead.match_score})",
            },
            "generated_at": __import__("datetime").datetime.now().isoformat(),
        }
