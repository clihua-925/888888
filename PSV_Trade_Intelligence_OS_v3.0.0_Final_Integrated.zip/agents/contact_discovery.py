"""
Contact Discovery Agent - 联系人发现Agent
负责：寻找联系人、职位、邮箱、销售入口
"""
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from platform.scraper_service import ScraperService
from platform.email_service import EmailService
from contracts.data_contract import CompanyProfile

class ContactDiscoveryAgent:
    """联系人发现Agent"""

    def __init__(self):
        self.scraper = ScraperService()
        self.email = EmailService()

    def __call__(self, request: AgentRequest) -> AgentResponse:
        companies_data = request.input_data.get("companies", [])
        companies = [CompanyProfile.from_dict(c) if isinstance(c, dict) else c for c in companies_data]

        contacts_found = []

        try:
            for company in companies:
                if not company.website:
                    continue

                # 尝试访问contact/about页面
                contact_urls = [
                    f"{company.website.rstrip('/')}/contact",
                    f"{company.website.rstrip('/')}/about",
                    f"{company.website.rstrip('/')}/team",
                ]

                for url in contact_urls:
                    info = self.scraper.fetch(url)
                    if info.get("success"):
                        emails = self.email.find_emails(info.get("text", ""), 
                                                        domain_filter=self._get_domain(company.website))
                        for em in emails:
                            contacts_found.append({
                                "company_id": company.company_id,
                                "company_name": company.name,
                                "email": em,
                                "source_url": url,
                                "verified": self.email.verify_format(em),
                            })
                        if emails:
                            break

                # 也检查主站
                if not any(c["company_id"] == company.company_id for c in contacts_found):
                    main_info = self.scraper.fetch(company.website)
                    if main_info.get("success"):
                        emails = self.email.find_emails(main_info.get("text", ""),
                                                        domain_filter=self._get_domain(company.website))
                        for em in emails:
                            contacts_found.append({
                                "company_id": company.company_id,
                                "company_name": company.name,
                                "email": em,
                                "source_url": company.website,
                                "verified": self.email.verify_format(em),
                            })

            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="contact_discovery",
                agent_id="contact_discovery_001",
                result={
                    "contacts": contacts_found,
                    "count": len(contacts_found),
                },
                confidence=0.70,
                evidence=[{"source": "website_scrape", "contacts_found": len(contacts_found)}],
                next_action="score_leads",
                next_agent="lead_scoring",
                status=AgentStatus.COMPLETED,
                duration_ms=0,
                tools_called=["scraper_service", "email_service"],
            )
        except Exception as e:
            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="contact_discovery",
                status=AgentStatus.FAILED,
                error=str(e),
                error_details={"retryable": True},
            )

    def _get_domain(self, url: str) -> str:
        from urllib.parse import urlparse
        try:
            return urlparse(url).netloc
        except:
            return ""
