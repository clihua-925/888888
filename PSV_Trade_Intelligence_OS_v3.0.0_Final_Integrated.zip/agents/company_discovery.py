"""
Company Discovery Agent - 企业发现Agent
负责：寻找进口商、买家、经销商、渠道商
"""
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from business.collection.company_collector import CompanyCollector

class CompanyDiscoveryAgent:
    """企业发现Agent"""

    def __init__(self):
        self.collector = CompanyCollector()

    def __call__(self, request: AgentRequest) -> AgentResponse:
        market = request.input_data.get("market", "US")
        product = request.input_data.get("product", "")
        target_type = request.input_data.get("target_type", "importer")
        max_results = request.input_data.get("max_results", 30)

        try:
            result = self.collector.collect(product, market, target_type, max_results)

            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="company_discovery",
                agent_id="company_discovery_001",
                result={
                    "companies": [c.to_dict() for c in result.companies],
                    "count": len(result.companies),
                },
                confidence=0.80,
                evidence=[{"source": "search_engine", "companies_found": len(result.companies)}],
                next_action="enrich_companies",
                next_agent="company_enrichment",
                status=AgentStatus.COMPLETED,
                duration_ms=result.duration_ms,
                tools_called=["search_service", "scraper_service"],
            )
        except Exception as e:
            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="company_discovery",
                status=AgentStatus.FAILED,
                error=str(e),
                error_details={"retryable": True},
            )
