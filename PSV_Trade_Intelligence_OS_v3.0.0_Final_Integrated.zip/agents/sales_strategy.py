"""
Sales Strategy Agent - 销售策略Agent
"""
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from contracts.data_contract import CompanyProfile, CustomerIntelligence
from business.strategy.sales_strategy_generator import SalesStrategyGenerator

class SalesStrategyAgent:
    """销售策略Agent"""

    def __init__(self):
        self.generator = SalesStrategyGenerator()

    def __call__(self, request: AgentRequest) -> AgentResponse:
        leads_data = request.input_data.get("top_leads", [])
        companies_data = request.input_data.get("companies", [])
        product = request.input_data.get("product", "")

        leads = []
        for ld in leads_data:
            if isinstance(ld, dict):
                leads.append(CustomerIntelligence(
                    customer_id=ld.get("customer_id", ""),
                    company_id=ld.get("company_id", ""),
                    level=ld.get("level", "cold"),
                    value_score=ld.get("value_score", 0),
                    match_score=ld.get("match_score", 0),
                    deal_probability=ld.get("deal_probability", 0),
                ))

        companies = [CompanyProfile.from_dict(c) if isinstance(c, dict) else c for c in companies_data]

        try:
            result = self.generator.generate_batch(leads, companies, product)

            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="sales_strategy",
                agent_id="sales_strategy_001",
                result={
                    "strategies": result.strategies,
                    "count": len(result.strategies),
                },
                confidence=0.78,
                evidence=[{"source": "llm+template", "strategies_generated": len(result.strategies)}],
                next_action="generate_report",
                next_agent="report_agent",
                status=AgentStatus.COMPLETED,
                duration_ms=result.duration_ms,
                tools_called=["llm_service"],
            )
        except Exception as e:
            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="sales_strategy",
                status=AgentStatus.FAILED,
                error=str(e),
                error_details={"retryable": True},
            )
