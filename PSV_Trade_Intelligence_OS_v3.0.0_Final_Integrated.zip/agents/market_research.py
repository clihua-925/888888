"""
Market Research Agent - 市场研究Agent
负责：国家市场分析、产品趋势、行业分析、市场机会
"""
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from business.analysis.market_analyzer import MarketAnalyzer

class MarketResearchAgent:
    """市场研究Agent"""

    def __init__(self):
        self.analyzer = MarketAnalyzer()

    def __call__(self, request: AgentRequest) -> AgentResponse:
        market = request.input_data.get("market", "US")
        product = request.input_data.get("product", "")

        try:
            result = self.analyzer.analyze(product, market)

            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="market_research",
                agent_id="market_research_001",
                result={
                    "market_report": result.market_report,
                    "competitor_list": result.competitor_list,
                    "trend_analysis": result.trend_analysis,
                },
                confidence=0.85,
                evidence=[{"source": "search+llm", "data_points": len(result.competitor_list)}],
                next_action="discover_companies",
                next_agent="company_discovery",
                status=AgentStatus.COMPLETED,
                duration_ms=result.duration_ms,
                tools_called=["search_service", "llm_service"],
            )
        except Exception as e:
            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="market_research",
                status=AgentStatus.FAILED,
                error=str(e),
                error_details={"retryable": True},
            )
