"""
Company Enrichment Agent - 企业信息补全Agent
"""
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from contracts.data_contract import CompanyProfile
from business.enrichment.company_enricher import CompanyEnricher

class CompanyEnrichmentAgent:
    """企业信息补全Agent"""

    def __init__(self):
        self.enricher = CompanyEnricher()

    def __call__(self, request: AgentRequest) -> AgentResponse:
        companies_data = request.input_data.get("companies", [])

        # 重建CompanyProfile对象
        companies = [CompanyProfile.from_dict(c) if isinstance(c, dict) else c for c in companies_data]

        try:
            result = self.enricher.enrich_batch(companies)

            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="company_enrichment",
                agent_id="company_enrichment_001",
                result={
                    "profiles": [c.to_dict() for c in result.enriched],
                    "enriched_count": len(result.enriched),
                    "failed_count": len(result.failed),
                },
                confidence=0.75,
                evidence=[{"source": "website_scrape+llm", "enriched": len(result.enriched)}],
                next_action="find_contacts",
                next_agent="contact_discovery",
                status=AgentStatus.COMPLETED,
                duration_ms=result.duration_ms,
                tools_called=["scraper_service", "llm_service"],
            )
        except Exception as e:
            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="company_enrichment",
                status=AgentStatus.FAILED,
                error=str(e),
                error_details={"retryable": True},
            )
