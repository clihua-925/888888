"""
Lead Scoring Agent - 线索评分Agent
"""
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from contracts.data_contract import CompanyProfile
from business.scoring.lead_scorer import LeadScorer

class LeadScoringAgent:
    """线索评分Agent"""

    def __init__(self):
        self.scorer = LeadScorer()

    def __call__(self, request: AgentRequest) -> AgentResponse:
        companies_data = request.input_data.get("companies", [])
        product = request.input_data.get("product", "")

        companies = [CompanyProfile.from_dict(c) if isinstance(c, dict) else c for c in companies_data]

        try:
            result = self.scorer.score_batch(companies, product)

            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="lead_scoring",
                agent_id="lead_scoring_001",
                result={
                    "scored_leads": [s.to_dict() for s in result.scored],
                    "top_leads": [s.to_dict() for s in result.scored[:10]],
                    "count": len(result.scored),
                },
                confidence=0.82,
                evidence=[{"source": "scoring_algorithm", "leads_scored": len(result.scored)}],
                next_action="generate_strategy",
                next_agent="sales_strategy",
                status=AgentStatus.COMPLETED,
                duration_ms=result.duration_ms,
                tools_called=["scoring_engine"],
            )
        except Exception as e:
            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_type="lead_scoring",
                status=AgentStatus.FAILED,
                error=str(e),
                error_details={"retryable": True},
            )
