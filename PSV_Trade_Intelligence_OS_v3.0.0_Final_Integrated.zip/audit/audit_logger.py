"""
Audit Layer - 所有智能行为必须可追踪
必须能够回答：
- 哪个Agent执行？
- 为什么执行？
- 调用什么工具？
- 产生什么结果？
- 哪里失败？
"""
import json
import sqlite3
from typing import Optional, List, Dict, Any
from datetime import datetime
from dataclasses import dataclass, field
import uuid

from contracts.event_contract import SystemEvent, EventType, EventSeverity

@dataclass
class AuditRecord:
    """审计记录"""
    audit_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    # 关联标识
    task_id: Optional[str] = None
    workflow_id: Optional[str] = None
    agent_id: Optional[str] = None
    agent_type: Optional[str] = None

    # 执行信息
    input_data: Optional[Dict[str, Any]] = None
    output_data: Optional[Dict[str, Any]] = None
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)

    # 性能信息
    duration_ms: int = 0
    tokens_used: int = 0

    # 状态
    status: str = "success"                # success/failed/partial
    error: Optional[str] = None
    error_trace: Optional[str] = None

    # 元数据
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    ip_address: Optional[str] = None
    user_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "audit_id": self.audit_id,
            "task_id": self.task_id,
            "workflow_id": self.workflow_id,
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "input_data": self.input_data,
            "output_data": self.output_data,
            "tool_calls": self.tool_calls,
            "duration_ms": self.duration_ms,
            "tokens_used": self.tokens_used,
            "status": self.status,
            "error": self.error,
            "error_trace": self.error_trace,
            "timestamp": self.timestamp,
            "ip_address": self.ip_address,
            "user_id": self.user_id,
        }

class AuditLogger:
    """审计日志器 - 全链路审计"""

    def __init__(self, db_path: str = "psv_audit.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # 主审计表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                audit_id TEXT PRIMARY KEY,
                task_id TEXT,
                workflow_id TEXT,
                agent_id TEXT,
                agent_type TEXT,
                input_json TEXT,
                output_json TEXT,
                tool_calls_json TEXT,
                duration_ms INTEGER,
                tokens_used INTEGER,
                status TEXT NOT NULL,
                error TEXT,
                error_trace TEXT,
                timestamp TEXT NOT NULL,
                ip_address TEXT,
                user_id TEXT
            )
        """)

        # 索引
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_task ON audit_log(task_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_workflow ON audit_log(workflow_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_agent ON audit_log(agent_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_status ON audit_log(status)")

        # 事件表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                task_id TEXT,
                agent_id TEXT,
                workflow_id TEXT,
                message TEXT,
                details_json TEXT,
                timestamp TEXT NOT NULL
            )
        """)

        cursor.execute("CREATE INDEX IF NOT EXISTS idx_event_task ON audit_events(task_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_event_type ON audit_events(event_type)")

        conn.commit()
        conn.close()

    def log_agent_execution(self, record: AuditRecord) -> str:
        """记录Agent执行"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO audit_log 
            (audit_id, task_id, workflow_id, agent_id, agent_type,
             input_json, output_json, tool_calls_json, duration_ms, tokens_used,
             status, error, error_trace, timestamp, ip_address, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            record.audit_id,
            record.task_id,
            record.workflow_id,
            record.agent_id,
            record.agent_type,
            json.dumps(record.input_data, ensure_ascii=False) if record.input_data else None,
            json.dumps(record.output_data, ensure_ascii=False) if record.output_data else None,
            json.dumps(record.tool_calls, ensure_ascii=False) if record.tool_calls else None,
            record.duration_ms,
            record.tokens_used,
            record.status,
            record.error,
            record.error_trace,
            record.timestamp,
            record.ip_address,
            record.user_id,
        ))
        conn.commit()
        conn.close()
        return record.audit_id

    def log_event(self, event: SystemEvent) -> str:
        """记录系统事件"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO audit_events 
            (event_id, event_type, severity, task_id, agent_id, workflow_id, message, details_json, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event.event_id,
            event.event_type.value,
            event.severity.value,
            event.task_id,
            event.agent_id,
            event.workflow_id,
            event.message,
            json.dumps(event.details, ensure_ascii=False) if event.details else None,
            event.timestamp,
        ))
        conn.commit()
        conn.close()
        return event.event_id

    def query_by_task(self, task_id: str) -> List[AuditRecord]:
        """查询任务的所有审计记录"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM audit_log WHERE task_id = ? ORDER BY timestamp ASC
        """, (task_id,))
        rows = cursor.fetchall()
        conn.close()
        return [self._row_to_record(row) for row in rows]

    def query_by_workflow(self, workflow_id: str) -> List[AuditRecord]:
        """查询工作流的所有审计记录"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM audit_log WHERE workflow_id = ? ORDER BY timestamp ASC
        """, (workflow_id,))
        rows = cursor.fetchall()
        conn.close()
        return [self._row_to_record(row) for row in rows]

    def query_by_agent(self, agent_id: str, limit: int = 100) -> List[AuditRecord]:
        """查询Agent的执行历史"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM audit_log WHERE agent_id = ? ORDER BY timestamp DESC LIMIT ?
        """, (agent_id, limit))
        rows = cursor.fetchall()
        conn.close()
        return [self._row_to_record(row) for row in rows]

    def get_task_summary(self, task_id: str) -> Dict[str, Any]:
        """获取任务执行摘要 - 回答审计问题"""
        records = self.query_by_task(task_id)

        if not records:
            return {"error": "No audit records found for task"}

        agents_executed = []
        tools_called = []
        total_duration = 0
        errors = []

        for r in records:
            if r.agent_type and r.agent_type not in agents_executed:
                agents_executed.append(r.agent_type)
            if r.tool_calls:
                tools_called.extend([t.get("tool_name", "unknown") for t in r.tool_calls])
            total_duration += r.duration_ms
            if r.error:
                errors.append({
                    "agent": r.agent_type,
                    "error": r.error,
                    "timestamp": r.timestamp,
                })

        return {
            "task_id": task_id,
            "agents_executed": agents_executed,
            "agents_count": len(agents_executed),
            "tools_called": list(set(tools_called)),
            "tools_count": len(tools_called),
            "total_duration_ms": total_duration,
            "records_count": len(records),
            "errors": errors,
            "success_rate": (len(records) - len(errors)) / len(records) * 100 if records else 0,
        }

    def _row_to_record(self, row) -> AuditRecord:
        """数据库行转AuditRecord"""
        return AuditRecord(
            audit_id=row[0],
            task_id=row[1],
            workflow_id=row[2],
            agent_id=row[3],
            agent_type=row[4],
            input_data=json.loads(row[5]) if row[5] else None,
            output_data=json.loads(row[6]) if row[6] else None,
            tool_calls=json.loads(row[7]) if row[7] else [],
            duration_ms=row[8] or 0,
            tokens_used=row[9] or 0,
            status=row[10],
            error=row[11],
            error_trace=row[12],
            timestamp=row[13],
            ip_address=row[14],
            user_id=row[15],
        )

# 便捷函数
def create_audit_logger(db_path: str = "psv_audit.db") -> AuditLogger:
    """创建审计日志器"""
    return AuditLogger(db_path)
