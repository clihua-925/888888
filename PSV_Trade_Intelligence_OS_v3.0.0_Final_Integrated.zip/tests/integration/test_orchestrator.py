"""
tests/integration/test_orchestrator.py - 编排器集成测试
"""
import pytest
from contracts.task_contract import TradeTask
from orchestrator.graph import TradeOrchestrator
from orchestrator.planner import TradePlannerAgent

def test_planner_generates_sequence():
    planner = TradePlannerAgent()
    task = TradeTask(objective="开发美国生日蜡烛进口商", product="生日蜡烛", market="US")
    plan = planner.plan(task)

    assert "execution_sequence" in plan
    assert len(plan["execution_sequence"]) == 7  # 7个步骤
    assert plan["parsed_intent"]["market"] == "US"

def test_planner_validation():
    planner = TradePlannerAgent()
    valid_plan = {
        "plan_id": "test",
        "parsed_intent": {},
        "execution_sequence": [{"step": 1}],
        "agent_pipeline": ["a"],
    }
    assert planner.validate_plan(valid_plan)

    invalid_plan = {"plan_id": "test"}
    assert not planner.validate_plan(invalid_plan)
