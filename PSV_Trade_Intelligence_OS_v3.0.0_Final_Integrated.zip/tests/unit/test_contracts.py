"""
tests/unit/test_contracts.py - 契约层单元测试
"""
import pytest
from contracts.task_contract import TradeTask, TaskStatus
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from contracts.data_contract import CompanyProfile, CustomerIntelligence

def test_trade_task_creation():
    task = TradeTask(objective="开发美国蜡烛进口商", product="蜡烛", market="US")
    assert task.objective == "开发美国蜡烛进口商"
    assert task.status == TaskStatus.PENDING
    assert task.task_id is not None

def test_agent_response_success():
    resp = AgentResponse(
        request_id="req_001",
        task_id="task_001",
        agent_type="market_research",
        result={"data": "test"},
        confidence=0.9,
        status=AgentStatus.COMPLETED,
    )
    assert resp.is_success()
    assert resp.confidence == 0.9

def test_company_profile():
    company = CompanyProfile(name="Test Corp", country="US", website="https://test.com")
    assert company.name == "Test Corp"
    assert company.credibility_score == 0.0
