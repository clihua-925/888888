"""
database/models.py - SQLAlchemy 外贸业务模型
整合原始 v45.14 系统核心表结构 + 新架构扩展表
"""
from sqlalchemy import create_engine, Column, String, Float, Integer, DateTime, Text, JSON, ForeignKey, Boolean, REAL
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import datetime
import uuid

Base = declarative_base()

# ========== 原始系统核心表 (v45.14 统一实体架构) ==========

class Entity(Base):
    """统一实体表 - 原始系统核心"""
    __tablename__ = "entities"
    entity_id = Column(String(36), primary_key=True)
    norm = Column(String(500), unique=True, nullable=False)
    name = Column(String(500))
    original_name = Column(String(500))
    country = Column(String(100))
    address = Column(Text)
    website = Column(String(500))
    phone = Column(String(100))
    enterprise_type = Column(String(100))
    industry = Column(String(200))
    product_categories = Column(Text)
    brand = Column(String(200))
    entity_status = Column(String(50), default="active")
    data_source = Column(String(200))
    info_completeness = Column(REAL, default=0)
    value_score_total = Column(REAL, default=0)
    dev_qualified = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

class EntityRole(Base):
    """实体角色 - customer/supplier/dual"""
    __tablename__ = "entity_roles"
    entity_id = Column(String(36), ForeignKey("entities.entity_id"), primary_key=True)
    role = Column(String(50), primary_key=True)  # customer/supplier/dual
    assigned_at = Column(DateTime, default=datetime.now)

class EntityCategory(Base):
    """实体品类关联"""
    __tablename__ = "entity_categories"
    entity_id = Column(String(36), ForeignKey("entities.entity_id"), primary_key=True)
    category_id = Column(String(100), primary_key=True)
    assigned_at = Column(DateTime, default=datetime.now)

class TradeEdge(Base):
    """贸易关系边 - 原始系统核心"""
    __tablename__ = "trade_edges"
    edge_id = Column(String(36), primary_key=True)
    from_entity_id = Column(String(36), ForeignKey("entities.entity_id"))
    from_norm = Column(String(500))
    to_entity_id = Column(String(36), ForeignKey("entities.entity_id"))
    to_norm = Column(String(500))
    relation = Column(String(50))  # supplier_of/customer_of/trades_with
    product = Column(String(255))
    hs_code = Column(String(50))
    shipment_count = Column(Integer, default=0)
    first_trade = Column(DateTime)
    last_trade = Column(DateTime)
    evidence = Column(Text)
    source_type = Column(String(100))
    confidence = Column(REAL, default=0)
    category_id = Column(String(100))
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

class Evidence(Base):
    """证据表"""
    __tablename__ = "evidence"
    evidence_id = Column(String(36), primary_key=True)
    entity_id = Column(String(36), ForeignKey("entities.entity_id"))
    source_type = Column(String(100))
    source = Column(String(500))
    evidence = Column(Text)
    confidence = Column(REAL, default=0)
    priority = Column(Integer, default=0)
    discovered_at = Column(DateTime, default=datetime.now)
    verified_at = Column(DateTime)

class Contact(Base):
    """联系人表"""
    __tablename__ = "contacts"
    contact_id = Column(String(36), primary_key=True)
    entity_id = Column(String(36), ForeignKey("entities.entity_id"))
    name = Column(String(200))
    title = Column(String(200))
    email = Column(String(300))
    phone = Column(String(100))
    linkedin = Column(String(500))
    verified = Column(Integer, default=0)
    source = Column(String(200))
    discovered_at = Column(DateTime, default=datetime.now)

class EntityDataClaim(Base):
    """实体数据声明"""
    __tablename__ = "entity_data_claims"
    claim_id = Column(String(36), primary_key=True)
    entity_id = Column(String(36), ForeignKey("entities.entity_id"))
    norm = Column(String(500))
    field = Column(String(100))
    value = Column(Text)
    normalized_value = Column(Text)
    source = Column(String(200))
    source_url = Column(String(500))
    status = Column(String(50), default="candidate")  # candidate/verified/rejected
    confidence = Column(REAL, default=0)
    expert_review = Column(Text)
    metadata_json = Column(Text)
    created_at = Column(DateTime, default=datetime.now)
    last_seen = Column(DateTime, default=datetime.now)

class LifecycleHistory(Base):
    """生命周期历史"""
    __tablename__ = "lifecycle_history"
    history_id = Column(String(36), primary_key=True)
    entity_id = Column(String(36), ForeignKey("entities.entity_id"))
    from_state = Column(String(50))
    to_state = Column(String(50))
    reason = Column(Text)
    changed_by = Column(String(100))
    changed_at = Column(DateTime, default=datetime.now)

# ========== 原始系统采集链表 ==========

class CustomsRaw(Base):
    """海关原始数据"""
    __tablename__ = "customs_raw"
    id = Column(Integer, primary_key=True, autoincrement=True)
    row_hash = Column(String(64), unique=True)
    bol = Column(String(100))
    ts = Column(REAL)
    importer = Column(Text)
    importer_norm = Column(String(500))
    shipper = Column(Text)
    notify = Column(Text)
    hs = Column(String(50))
    descr = Column(Text)
    qty = Column(REAL)
    weight = Column(REAL)
    teu = Column(REAL)
    origin = Column(String(100))
    port_load = Column(String(100))
    port_discharge = Column(String(100))
    source_file = Column(String(200))
    direct_importer = Column(Integer)
    created_at = Column(REAL)

class Buyer90d(Base):
    """90天买家汇总"""
    __tablename__ = "buyers_90d"
    importer_norm = Column(String(500), primary_key=True)
    importer = Column(Text)
    first_seen = Column(REAL)
    last_seen = Column(REAL)
    shipments = Column(Integer)
    total_weight = Column(REAL)
    total_qty = Column(REAL)
    total_teu = Column(REAL)
    supplier_count = Column(Integer)
    origins = Column(Text)
    ports = Column(Text)
    sample_desc = Column(Text)
    score = Column(REAL)
    reasons = Column(Text)
    updated_at = Column(REAL)

class Supplier(Base):
    """供应商表"""
    __tablename__ = "suppliers"
    supplier_norm = Column(String(500), primary_key=True)
    name = Column(Text)
    slug = Column(String(200))
    shipments = Column(Integer)
    first_seen = Column(REAL)
    last_seen = Column(REAL)
    harvested_at = Column(REAL)
    bol_fetched = Column(Integer)
    updated_at = Column(REAL)

# ========== 新架构扩展表 ==========

class TradeTask(Base):
    """任务表"""
    __tablename__ = "trade_tasks"
    task_id = Column(String(36), primary_key=True)
    objective = Column(Text, nullable=False)
    product = Column(String(255))
    market = Column(String(100))
    target_customer = Column(String(200))
    category_id = Column(String(100))
    constraints = Column(JSON)
    workflow = Column(JSON)
    status = Column(String(50), default="pending")
    priority = Column(Integer, default=2)
    current_stage = Column(String(100))
    current_node = Column(String(100))
    progress_pct = Column(Integer, default=0)
    run_status = Column(String(50))
    failure_reason = Column(Text)
    created_at = Column(DateTime, default=datetime.now)
    completed_at = Column(DateTime)

class TradeWorkflow(Base):
    """工作流状态"""
    __tablename__ = "trade_workflows"
    workflow_id = Column(String(36), primary_key=True)
    task_id = Column(String(36), ForeignKey("trade_tasks.task_id"))
    current_node = Column(String(100))
    status = Column(String(50), default="running")
    context = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

class AgentExecutionLog(Base):
    """Agent执行日志"""
    __tablename__ = "agent_execution_logs"
    log_id = Column(String(36), primary_key=True)
    task_id = Column(String(36))
    workflow_id = Column(String(36))
    agent_id = Column(String(100))
    agent_type = Column(String(100))
    input_json = Column(JSON)
    output_json = Column(JSON)
    tool_calls = Column(JSON)
    duration_ms = Column(Integer)
    tokens_used = Column(Integer)
    status = Column(String(50))
    error = Column(Text)
    timestamp = Column(DateTime, default=datetime.now)

class AuditEvent(Base):
    """审计事件"""
    __tablename__ = "audit_events"
    event_id = Column(String(36), primary_key=True)
    event_type = Column(String(100))
    severity = Column(String(50))
    task_id = Column(String(36))
    agent_id = Column(String(100))
    workflow_id = Column(String(36))
    message = Column(Text)
    details = Column(JSON)
    timestamp = Column(DateTime, default=datetime.now)

class MemoryStore(Base):
    """记忆存储"""
    __tablename__ = "memory_store"
    memory_id = Column(String(36), primary_key=True)
    memory_type = Column(String(50))
    scope = Column(String(50))
    task_id = Column(String(36))
    key = Column(String(500))
    value = Column(JSON)
    summary = Column(Text)
    importance = Column(REAL, default=0.5)
    tags = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)
    expires_at = Column(DateTime)

class ExpansionTask(Base):
    """网络扩张任务"""
    __tablename__ = "expansion_tasks"
    task_id = Column(String(36), primary_key=True)
    parent_task_id = Column(String(36))
    category_id = Column(String(100))
    strategy = Column(String(100))
    status = Column(String(50), default="pending")
    depth = Column(Integer, default=0)
    new_leads = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)
    completed_at = Column(DateTime)

class SourceQuota(Base):
    """数据源配额"""
    __tablename__ = "source_quota"
    source = Column(String(100), primary_key=True)
    day = Column(String(20), primary_key=True)
    count = Column(Integer, default=0)

class TaskLog(Base):
    """任务日志"""
    __tablename__ = "task_logs"
    log_id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(36))
    stage = Column(String(100))
    message = Column(Text)
    timestamp = Column(DateTime, default=datetime.now)

class PostFlowCheckpoint(Base):
    """后采集流检查点"""
    __tablename__ = "postflow_checkpoints"
    checkpoint_id = Column(String(36), primary_key=True)
    task_id = Column(String(36))
    stage = Column(String(100))
    status = Column(String(50))
    progress_pct = Column(Integer)
    shared_data = Column(JSON)
    message = Column(Text)
    created_at = Column(DateTime, default=datetime.now)

# 初始化
def init_db(database_url: str = "sqlite:///psv_trade_os.db"):
    engine = create_engine(database_url)
    Base.metadata.create_all(engine)
    return engine
