"""
platform/adapter.py - 原始系统适配层
桥接 v45.14 核心逻辑与新 LangGraph 架构
"""
import sys
import os
from pathlib import Path

# 将 legacy 目录加入 Python 路径
LEGACY_ROOT = Path(__file__).resolve().parents[1] / "legacy"
if str(LEGACY_ROOT) not in sys.path:
    sys.path.insert(0, str(LEGACY_ROOT))

class LegacyAdapter:
    """原始系统适配器 - 懒加载避免循环依赖"""

    _instance = None
    _system = None
    _db = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def init(self):
        """初始化原始系统"""
        if self._initialized:
            return

        try:
            # 设置原始系统的 PROJECT_ROOT
            os.environ.setdefault("PROJECT_ROOT", str(LEGACY_ROOT))

            # 延迟导入原始系统模块
            from core.memory.db import DB
            from core.system import PSVSystem

            self._db = DB()
            self._system = PSVSystem(self._db)
            self._initialized = True
            print("✅ Legacy system initialized")
        except Exception as e:
            print(f"⚠️ Legacy system init failed: {e}")
            self._db = None
            self._system = None
            self._initialized = True

    @property
    def system(self):
        if not self._initialized:
            self.init()
        return self._system

    @property
    def db(self):
        if not self._initialized:
            self.init()
        return self._db

    # ========== 采集链适配 ==========
    def run_collection(self, request: str, market: str = "USA", industry: str = "candle",
                       quantity: int = 20, task_id: str = None, auto_expand: bool = True) -> dict:
        """调用原始系统的9节点采集链"""
        if self.system is None:
            return {"error": "Legacy system not available", "status": "failed"}
        try:
            return self.system.run_collection(
                request=request,
                market=market,
                industry=industry,
                quantity=quantity,
                task_id=task_id,
                auto_expand=auto_expand,
            )
        except Exception as e:
            return {"error": str(e), "status": "failed"}

    # ========== 网络扩张适配 ==========
    def expand_network(self, category_id: str, parent_task_id: str = None, 
                       strategies: list = None, max_depth: int = 2) -> dict:
        """调用原始系统的网络扩张"""
        if self.system is None:
            return {"error": "Legacy system not available"}
        try:
            # 使用原始系统的 expand_network_batch
            return self.system.expand_network_batch(
                category_id=category_id,
                parent_task_id=parent_task_id,
                strategies=strategies,
                max_depth=max_depth,
            )
        except Exception as e:
            return {"error": str(e)}

    # ========== Enrichment 适配 ==========
    def enrich_entity(self, norm: str, category_id: str = None, 
                      force: bool = False, task_id: str = None) -> dict:
        """调用原始系统的实体信息补全"""
        if self.system is None:
            return {"error": "Legacy system not available"}
        try:
            return self.system.enrich_entity(
                norm=norm,
                category_id=category_id,
                force=force,
                task_id=task_id,
            )
        except Exception as e:
            return {"error": str(e)}

    # ========== 业务执行适配 ==========
    def execute_business(self, lead_norm: str, category_id: str = None,
                         our_product: str = None, our_company: str = None,
                         mode: str = "draft", task_id: str = None) -> dict:
        """调用原始系统的业务执行中心"""
        if self.system is None:
            return {"error": "Legacy system not available"}
        try:
            return self.system.execution_center.execute_business_flow(
                lead_norm=lead_norm,
                category_id=category_id,
                our_product=our_product,
                our_company=our_company,
                mode=mode,
                task_id=task_id,
            )
        except Exception as e:
            return {"error": str(e)}

    # ========== 数据库查询适配 ==========
    def get_entity(self, norm: str) -> dict:
        """获取实体"""
        if self.db is None:
            return None
        try:
            return self.db.get_entity(norm)
        except Exception:
            return None

    def list_entities(self, category_id: str = None, role: str = None, 
                      limit: int = 100) -> list:
        """列实体"""
        if self.db is None:
            return []
        try:
            return self.db.list_entities(category_id=category_id, role=role, limit=limit)
        except Exception:
            return []

    def list_trade_edges(self, norm: str = None, category_id: str = None) -> list:
        """列贸易边"""
        if self.db is None:
            return []
        try:
            return self.db.list_trade_edges(norm=norm, category_id=category_id)
        except Exception:
            return []

    def get_intelligence(self, norm: str) -> dict:
        """获取情报"""
        if self.db is None:
            return {}
        try:
            return self.db.get_intelligence(norm)
        except Exception:
            return {}

    def get_task(self, task_id: str) -> dict:
        """获取任务"""
        if self.db is None:
            return None
        try:
            return self.db.get_task(task_id)
        except Exception:
            return None

    def list_tasks(self, limit: int = 50) -> list:
        """列任务"""
        if self.db is None:
            return []
        try:
            return self.db.list_tasks(limit=limit)
        except Exception:
            return []

    def get_lead(self, norm: str) -> dict:
        """获取线索"""
        if self.db is None:
            return None
        try:
            return self.db.get_lead(norm)
        except Exception:
            return None

    def list_leads(self, zone: str = None, category_id: str = None, 
                   limit: int = 100) -> list:
        """列线索"""
        if self.db is None:
            return []
        try:
            return self.db.list_leads(zone=zone, category_id=category_id, limit=limit)
        except Exception:
            return []

    # ========== 行业配置适配 ==========
    def load_industry(self, key: str = None) -> dict:
        """加载行业配置"""
        try:
            from core.config.industry import load_industry
            return load_industry(key)
        except Exception as e:
            return {"error": str(e)}

    def list_industries(self) -> list:
        """列行业"""
        try:
            from core.config.industry import list_industries
            return list_industries()
        except Exception:
            return []

    def load_markets(self) -> list:
        """加载市场"""
        try:
            from core.config.markets import load_markets
            return load_markets()
        except Exception:
            return [{"code": "USA", "name": "美国"}]

# 全局适配器实例
_legacy_adapter: LegacyAdapter = None

def get_legacy_adapter() -> LegacyAdapter:
    """获取原始系统适配器"""
    global _legacy_adapter
    if _legacy_adapter is None:
        _legacy_adapter = LegacyAdapter()
        _legacy_adapter.init()
    return _legacy_adapter
