"""
platform/search_service.py - 搜索服务
支持：Google Custom Search / SerpAPI / DuckDuckGo
"""
import os
import time
import urllib.parse
from typing import List, Dict, Any, Optional
import httpx

class SearchResult:
    def __init__(self, title: str, url: str, snippet: str, source: str = ""):
        self.title = title
        self.url = url
        self.snippet = snippet
        self.source = source

    def to_dict(self) -> Dict[str, Any]:
        return {"title": self.title, "url": self.url, "snippet": self.snippet, "source": self.source}

class SearchService:
    """搜索服务"""

    def __init__(self, engine: str = None, api_key: str = None):
        self.engine = engine or os.getenv("SEARCH_ENGINE", "serpapi")
        self.api_key = api_key or os.getenv("SEARCH_API_KEY", "")
        self.timeout = 30

    def search(self, query: str, num_results: int = 10, 
               market: str = "us", language: str = "en") -> List[SearchResult]:
        """执行搜索"""
        if self.engine == "serpapi":
            return self._search_serpapi(query, num_results, market, language)
        elif self.engine == "google":
            return self._search_google_cse(query, num_results)
        elif self.engine == "duckduckgo":
            return self._search_duckduckgo(query, num_results)
        else:
            return self._search_duckduckgo(query, num_results)

    def _search_serpapi(self, query: str, num: int, market: str, language: str) -> List[SearchResult]:
        url = "https://serpapi.com/search"
        params = {
            "q": query,
            "api_key": self.api_key,
            "engine": "google",
            "num": min(num, 20),
            "gl": market.lower(),
            "hl": language,
        }
        try:
            r = httpx.get(url, params=params, timeout=self.timeout)
            data = r.json()
            results = []
            for item in data.get("organic_results", [])[:num]:
                results.append(SearchResult(
                    title=item.get("title", ""),
                    url=item.get("link", ""),
                    snippet=item.get("snippet", ""),
                    source="serpapi",
                ))
            return results
        except Exception as e:
            print(f"SerpAPI search error: {e}")
            return []

    def _search_google_cse(self, query: str, num: int) -> List[SearchResult]:
        """Google Custom Search Engine"""
        cx = os.getenv("GOOGLE_CX", "")
        url = "https://www.googleapis.com/customsearch/v1"
        params = {"q": query, "key": self.api_key, "cx": cx, "num": min(num, 10)}
        try:
            r = httpx.get(url, params=params, timeout=self.timeout)
            data = r.json()
            results = []
            for item in data.get("items", [])[:num]:
                results.append(SearchResult(
                    title=item.get("title", ""),
                    url=item.get("link", ""),
                    snippet=item.get("snippet", ""),
                    source="google_cse",
                ))
            return results
        except Exception as e:
            print(f"Google CSE error: {e}")
            return []

    def _search_duckduckgo(self, query: str, num: int) -> List[SearchResult]:
        """DuckDuckGo免费搜索（通过html scrape）"""
        try:
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                results = []
                for r in ddgs.text(query, region="us-en", max_results=num):
                    results.append(SearchResult(
                        title=r.get("title", ""),
                        url=r.get("href", ""),
                        snippet=r.get("body", ""),
                        source="duckduckgo",
                    ))
                return results
        except Exception as e:
            print(f"DDG search error: {e}")
            return []

    def search_companies(self, product: str, market: str, target_type: str = "importer", 
                         num_results: int = 20) -> List[SearchResult]:
        """专门搜索企业"""
        queries = [
            f'{product} {target_type} in {market}',
            f'{product} {target_type} company {market}',
            f'buy {product} {market} wholesale distributor',
            f'{product} supplier directory {market}',
        ]
        all_results = []
        seen_urls = set()
        for q in queries:
            for r in self.search(q, num_results=num_results // len(queries)):
                if r.url not in seen_urls:
                    seen_urls.add(r.url)
                    all_results.append(r)
        return all_results[:num_results]
