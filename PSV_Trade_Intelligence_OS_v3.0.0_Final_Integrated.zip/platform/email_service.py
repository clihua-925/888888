"""
platform/email_service.py - 邮箱验证与邮件服务
"""
import re
import smtplib
import dns.resolver
from typing import Dict, Any

class EmailService:
    """邮箱服务"""

    def verify_format(self, email: str) -> bool:
        """验证邮箱格式"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))

    def verify_domain(self, email: str) -> Dict[str, Any]:
        """验证域名MX记录"""
        domain = email.split("@")[1]
        try:
            records = dns.resolver.resolve(domain, "MX")
            mx_records = [str(r.exchange) for r in records]
            return {"valid": True, "mx_records": mx_records, "domain": domain}
        except Exception as e:
            return {"valid": False, "error": str(e), "domain": domain}

    def verify_smtp(self, email: str, from_email: str = "verify@example.com") -> Dict[str, Any]:
        """SMTP验证（谨慎使用，可能被限流）"""
        domain = email.split("@")[1]
        try:
            records = dns.resolver.resolve(domain, "MX")
            mx_host = str(records[0].exchange)

            server = smtplib.SMTP(mx_host, timeout=10)
            server.ehlo()
            server.mail(from_email)
            code, _ = server.rcpt(email)
            server.quit()

            return {"valid": code == 250, "code": code, "method": "smtp"}
        except Exception as e:
            return {"valid": False, "error": str(e), "method": "smtp"}

    def full_verify(self, email: str) -> Dict[str, Any]:
        """完整验证"""
        result = {"email": email, "format_valid": self.verify_format(email)}

        if not result["format_valid"]:
            result["valid"] = False
            return result

        domain_check = self.verify_domain(email)
        result["domain_valid"] = domain_check["valid"]
        result["mx_records"] = domain_check.get("mx_records", [])

        result["valid"] = result["format_valid"] and result["domain_valid"]
        return result

    def find_emails(self, text: str, domain_filter: str = None) -> list:
        """从文本中提取邮箱"""
        pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        emails = list(set(re.findall(pattern, text)))
        if domain_filter:
            emails = [e for e in emails if domain_filter.lower() in e.lower()]
        return emails
