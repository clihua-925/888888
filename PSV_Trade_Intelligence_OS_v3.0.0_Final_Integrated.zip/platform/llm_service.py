"""
platform/llm_service.py - LLM统一调用服务
支持多Provider切换：OpenAI / DeepSeek / 本地模型
"""
import os
import time
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

@dataclass
class LLMResponse:
    content: str = ""
    tokens_used: int = 0
    model: str = ""
    duration_ms: int = 0
    error: Optional[str] = None

class LLMService:
    """LLM统一服务"""

    def __init__(self, provider: str = None, model: str = None, api_key: str = None, base_url: str = None):
        self.provider = provider or os.getenv("LLM_PROVIDER", "openai")
        self.model = model or os.getenv("LLM_MODEL", "gpt-4o")
        self.api_key = api_key or os.getenv("LLM_API_KEY", "")
        self.base_url = base_url or os.getenv("LLM_BASE_URL", "")
        self.temperature = float(os.getenv("LLM_TEMPERATURE", "0.3"))
        self.max_tokens = int(os.getenv("LLM_MAX_TOKENS", "4096"))
        self._client = None

    def _get_client(self):
        if self._client is None:
            if self.provider == "openai":
                try:
                    from openai import OpenAI
                    kwargs = {"api_key": self.api_key}
                    if self.base_url:
                        kwargs["base_url"] = self.base_url
                    self._client = OpenAI(**kwargs)
                except ImportError:
                    raise ImportError("pip install openai")
            elif self.provider == "deepseek":
                try:
                    from openai import OpenAI
                    kwargs = {"api_key": self.api_key, "base_url": self.base_url or "https://api.deepseek.com/v1"}
                    self._client = OpenAI(**kwargs)
                except ImportError:
                    raise ImportError("pip install openai")
            else:
                raise ValueError(f"Unsupported provider: {self.provider}")
        return self._client

    def chat(self, messages: List[Dict[str, str]], system_prompt: str = None, 
             temperature: float = None, max_tokens: int = None) -> LLMResponse:
        """对话调用"""
        start = time.time()
        try:
            client = self._get_client()

            formatted = []
            if system_prompt:
                formatted.append({"role": "system", "content": system_prompt})
            for m in messages:
                formatted.append({"role": m.get("role", "user"), "content": m.get("content", "")})

            resp = client.chat.completions.create(
                model=self.model,
                messages=formatted,
                temperature=temperature or self.temperature,
                max_tokens=max_tokens or self.max_tokens,
            )

            content = resp.choices[0].message.content if resp.choices else ""
            tokens = resp.usage.total_tokens if resp.usage else 0

            return LLMResponse(
                content=content,
                tokens_used=tokens,
                model=self.model,
                duration_ms=int((time.time() - start) * 1000),
            )
        except Exception as e:
            return LLMResponse(
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )

    def complete(self, prompt: str, system_prompt: str = None, 
                 temperature: float = None, max_tokens: int = None) -> LLMResponse:
        """单轮补全"""
        return self.chat([{"role": "user", "content": prompt}], system_prompt, temperature, max_tokens)

    def json_complete(self, prompt: str, system_prompt: str = None) -> Dict[str, Any]:
        """返回JSON格式"""
        sp = system_prompt or ""
        sp += "\n\nYou must respond with valid JSON only. No markdown, no explanation."
        resp = self.complete(prompt, sp, temperature=0.1)
        if resp.error:
            return {"error": resp.error}
        try:
            import json
            return json.loads(resp.content)
        except:
            return {"raw": resp.content, "error": "JSON parse failed"}
