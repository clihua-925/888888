"""
platform/scraper_service.py - 网页采集服务
"""
import time
from typing import Optional, Dict, Any
import httpx
from bs4 import BeautifulSoup

class ScraperService:
    """网页采集服务"""

    def __init__(self, timeout: int = 30, max_content_length: int = 50000):
        self.timeout = timeout
        self.max_content_length = max_content_length
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

    def fetch(self, url: str) -> Dict[str, Any]:
        """获取网页内容"""
        start = time.time()
        try:
            r = httpx.get(url, headers=self.headers, timeout=self.timeout, follow_redirects=True)
            r.raise_for_status()

            soup = BeautifulSoup(r.text, "lxml")

            # 提取关键信息
            title = soup.title.string.strip() if soup.title else ""

            # 移除脚本和样式
            for tag in soup(["script", "style", "nav", "footer"]):
                tag.decompose()

            text = soup.get_text(separator="\n", strip=True)
            text = text[:self.max_content_length]

            # 提取联系信息
            emails = self._extract_emails(text)
            phones = self._extract_phones(text)

            # 提取社交媒体
            social = self._extract_social_links(soup, url)

            return {
                "url": url,
                "title": title,
                "text": text,
                "emails": emails,
                "phones": phones,
                "social_links": social,
                "status_code": r.status_code,
                "duration_ms": int((time.time() - start) * 1000),
                "success": True,
            }
        except Exception as e:
            return {
                "url": url,
                "error": str(e),
                "duration_ms": int((time.time() - start) * 1000),
                "success": False,
            }

    def _extract_emails(self, text: str) -> list:
        import re
        pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        return list(set(re.findall(pattern, text)))

    def _extract_phones(self, text: str) -> list:
        import re
        pattern = r'[+]?[0-9\s\-\(\)]{7,20}'
        phones = re.findall(pattern, text)
        return list(set([p.strip() for p in phones if len(p.strip()) >= 7]))[:5]

    def _extract_social_links(self, soup, base_url: str) -> Dict[str, str]:
        social = {}
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if "linkedin.com" in href:
                social["linkedin"] = href
            elif "twitter.com" in href or "x.com" in href:
                social["twitter"] = href
            elif "facebook.com" in href:
                social["facebook"] = href
        return social

    def extract_company_info(self, url: str) -> Dict[str, Any]:
        """提取公司信息"""
        result = self.fetch(url)
        if not result.get("success"):
            return result

        text = result.get("text", "")

        # 简单规则提取
        info = {
            "url": url,
            "title": result.get("title", ""),
            "description": self._extract_description(text),
            "industry_hints": self._extract_industry(text),
            "products_hints": self._extract_products(text),
            "emails": result.get("emails", []),
            "phones": result.get("phones", []),
            "social_links": result.get("social_links", {}),
        }
        return info

    def _extract_description(self, text: str) -> str:
        lines = [l.strip() for l in text.split("\n") if len(l.strip()) > 20]
        return lines[0] if lines else ""

    def _extract_industry(self, text: str) -> list:
        keywords = ["manufacturing", "import", "export", "wholesale", "distribution", 
                    "retail", "trading", "logistics", "supply chain"]
        found = [k for k in keywords if k.lower() in text.lower()]
        return found

    def _extract_products(self, text: str) -> list:
        # 简化：找大写的产品名或引号中的词
        import re
        products = re.findall(r'["']([A-Z][a-zA-Z\s]{3,30})["']', text)
        return list(set(products))[:10]
