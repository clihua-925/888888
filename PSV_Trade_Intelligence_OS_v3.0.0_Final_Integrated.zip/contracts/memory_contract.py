"""
Memory Contract - 短期/长期记忆标准化
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid
from datetime import datetime

class MemoryType(Enum):
    SHORT_TERM = "short_term"      # 当前任务状态
    LONG_TERM = "long_term"        # 历史任务/行业知识
    EPISODIC = "episodic"          # 具体执行经验
    SEMANTIC = "semantic"          # 行业/产品/市场知识
    PROCEDURAL = "procedural"      # 执行流程知识

class MemoryScope(Enum):
    TASK = "task"                  # 任务级别
    WORKFLOW = "workflow"          # 工作流级别
    SESSION = "session"            # 会话级别
    GLOBAL = "global"              # 全局级别

@dataclass
class MemoryEntry:
    """记忆条目"""
    memory_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    memory_type: MemoryType = MemoryType.SHORT_TERM
    scope: MemoryScope = MemoryScope.TASK
    task_id: Optional[str] = None
    workflow_id: Optional[str] = None
    agent_id: Optional[str] = None

    # 内容
    key: str = ""                  # 记忆键
    value: Any = None              # 记忆值
    summary: str = ""              # 摘要

    # 元数据
    importance: float = 0.5        # 重要性 0-1
    access_count: int = 0          # 访问次数
    last_accessed: str = field(default_factory=lambda: datetime.now().isoformat())
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    expires_at: Optional[str] = None  # 过期时间（短期记忆可设置）
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id": self.memory_id,
            "memory_type": self.memory_type.value,
            "scope": self.scope.value,
            "task_id": self.task_id,
            "workflow_id": self.workflow_id,
            "agent_id": self.agent_id,
            "key": self.key,
            "value": self.value,
            "summary": self.summary,
            "importance": self.importance,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "tags": self.tags,
        }
