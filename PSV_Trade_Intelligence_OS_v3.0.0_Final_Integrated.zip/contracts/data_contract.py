"""
Data Contract - 外贸业务数据实体标准化
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid
from datetime import datetime

class CompanySize(Enum):
    UNKNOWN = "unknown"
    STARTUP = "startup"          # < 10人
    SMALL = "small"              # 10-50人
    MEDIUM = "medium"            # 50-200人
    LARGE = "large"              # 200-1000人
    ENTERPRISE = "enterprise"    # > 1000人

class CustomerLevel(Enum):
    COLD = "cold"                # 冷客户
    WARM = "warm"                # 温客户
    HOT = "hot"                  # 热客户
    VIP = "vip"                  # 重点客户

class LeadStatus(Enum):
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"

@dataclass
class CompanyProfile:
    """企业画像 - 核心数据实体"""
    company_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    country: str = ""
    website: Optional[str] = None
    industry: Optional[str] = None
    main_products: List[str] = field(default_factory=list)
    procurement_direction: List[str] = field(default_factory=list)
    company_size: CompanySize = CompanySize.UNKNOWN
    supply_chain_relations: List[Dict[str, Any]] = field(default_factory=list)

    # 联系人
    contacts: List[Dict[str, Any]] = field(default_factory=list)

    # 评分
    credibility_score: float = 0.0         # 可信度 0-100
    procurement_probability: float = 0.0   # 采购可能性 0-100
    match_score: float = 0.0               # 匹配度 0-100

    # 元数据
    source: str = ""                       # 数据来源
    discovered_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_updated: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "company_id": self.company_id,
            "name": self.name,
            "country": self.country,
            "website": self.website,
            "industry": self.industry,
            "main_products": self.main_products,
            "procurement_direction": self.procurement_direction,
            "company_size": self.company_size.value,
            "supply_chain_relations": self.supply_chain_relations,
            "contacts": self.contacts,
            "credibility_score": self.credibility_score,
            "procurement_probability": self.procurement_probability,
            "match_score": self.match_score,
            "source": self.source,
            "discovered_at": self.discovered_at,
            "last_updated": self.last_updated,
            "metadata": self.metadata,
        }

@dataclass
class CustomerIntelligence:
    """客户智能池条目"""
    customer_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    company_id: str = ""
    level: CustomerLevel = CustomerLevel.COLD
    value_score: float = 0.0               # 客户价值 0-100
    match_score: float = 0.0               # 匹配程度 0-100
    deal_probability: float = 0.0          # 成交概率 0-100
    development_priority: int = 0          # 开发优先级 1-10
    follow_up_status: LeadStatus = LeadStatus.NEW
    assigned_to: Optional[str] = None      # 分配给哪个销售/Agent
    notes: List[Dict[str, Any]] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class TradeOpportunity:
    """商业机会"""
    opportunity_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str = ""
    company_id: str = ""
    product: str = ""
    market: str = ""
    opportunity_type: str = ""             # 机会类型：新市场/新客户/复购等
    estimated_value: Optional[float] = None
    confidence: float = 0.0
    strategy_recommendation: str = ""
    status: str = "open"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
