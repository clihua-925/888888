"""
Task Contract - 统一任务格式
所有外贸任务的标准化输入定义
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid
from datetime import datetime

class TaskStatus(Enum):
    PENDING = "pending"
    PLANNING = "planning"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    RECOVERING = "recovering"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

@dataclass
class TradeTask:
    """外贸任务标准格式"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    objective: str = ""                    # 任务目标：如"开发美国生日蜡烛进口商"
    product: str = ""                      # 产品
    market: str = ""                       # 目标市场/国家
    target_customer: str = ""              # 目标客户类型
    constraints: Dict[str, Any] = field(default_factory=dict)  # 约束条件
    workflow: List[str] = field(default_factory=list)          # 执行工作流
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority = TaskPriority.MEDIUM
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: Optional[str] = None
    completed_at: Optional[str] = None
    parent_task_id: Optional[str] = None   # 支持子任务
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "objective": self.objective,
            "product": self.product,
            "market": self.market,
            "target_customer": self.target_customer,
            "constraints": self.constraints,
            "workflow": self.workflow,
            "status": self.status.value,
            "priority": self.priority.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "completed_at": self.completed_at,
            "parent_task_id": self.parent_task_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TradeTask":
        return cls(
            task_id=data.get("task_id", str(uuid.uuid4())),
            objective=data.get("objective", ""),
            product=data.get("product", ""),
            market=data.get("market", ""),
            target_customer=data.get("target_customer", ""),
            constraints=data.get("constraints", {}),
            workflow=data.get("workflow", []),
            status=TaskStatus(data.get("status", "pending")),
            priority=TaskPriority(data.get("priority", 2)),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at"),
            completed_at=data.get("completed_at"),
            parent_task_id=data.get("parent_task_id"),
            metadata=data.get("metadata", {}),
        )
