"""
Tool Contract - 所有外部工具/API调用的标准化契约
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid
from datetime import datetime

class ToolType(Enum):
    SEARCH = "search"              # 搜索引擎
    SCRAPER = "scraper"          # 网页采集
    API = "api"                  # 第三方API
    LLM = "llm"                  # LLM调用
    DATABASE = "database"        # 数据库操作
    BROWSER = "browser"          # 浏览器自动化
    EMAIL = "email"              # 邮件服务
    ANALYSIS = "analysis"        # 分析工具

class ToolStatus(Enum):
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    RATE_LIMITED = "rate_limited"
    PARTIAL = "partial"

@dataclass
class ToolRequest:
    """工具调用请求"""
    tool_call_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tool_name: str = ""
    tool_type: ToolType = ToolType.API
    parameters: Dict[str, Any] = field(default_factory=dict)
    timeout_seconds: int = 30
    retry_count: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class ToolResponse:
    """工具调用响应"""
    tool_call_id: str = ""
    tool_name: str = ""
    tool_type: ToolType = ToolType.API
    status: ToolStatus = ToolStatus.SUCCESS
    data: Dict[str, Any] = field(default_factory=dict)
    raw_output: Optional[str] = None
    error_message: Optional[str] = None
    duration_ms: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
