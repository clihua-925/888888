"""
Agent Contract - 所有Agent的标准化输入输出
禁止Agent之间直接调用内部变量，必须通过此契约通信
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid
from datetime import datetime

class AgentStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    WAITING = "waiting"

class ConfidenceLevel(Enum):
    VERY_LOW = 0.2
    LOW = 0.4
    MEDIUM = 0.6
    HIGH = 0.8
    VERY_HIGH = 1.0

@dataclass
class AgentRequest:
    """Agent标准输入"""
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str = ""                      # 关联的任务ID
    agent_type: str = ""                   # Agent类型
    input_data: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)  # 上下文信息
    memory_refs: List[str] = field(default_factory=list)   # 引用的记忆ID
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "task_id": self.task_id,
            "agent_type": self.agent_type,
            "input_data": self.input_data,
            "context": self.context,
            "memory_refs": self.memory_refs,
            "timestamp": self.timestamp,
        }

@dataclass
class AgentResponse:
    """Agent标准输出 - 必须包含所有审计字段"""
    response_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    request_id: str = ""                   # 对应的请求ID
    task_id: str = ""                      # 关联的任务ID
    agent_type: str = ""                   # Agent类型
    agent_id: str = ""                     # 具体Agent实例ID

    # 核心结果
    result: Dict[str, Any] = field(default_factory=dict)

    # 可信度与证据
    confidence: float = 0.0                # 0.0 - 1.0
    evidence: List[Dict[str, Any]] = field(default_factory=list)  # 证据链

    # 下一步行动
    next_action: Optional[str] = None      # 建议的下一步
    next_agent: Optional[str] = None       # 建议调用的下一个Agent

    # 状态
    status: AgentStatus = AgentStatus.IDLE
    error: Optional[str] = None
    error_details: Optional[Dict[str, Any]] = None

    # 执行信息
    duration_ms: int = 0                   # 执行耗时
    tools_called: List[str] = field(default_factory=list)  # 调用的工具列表
    tokens_used: int = 0                   # LLM token消耗

    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "response_id": self.response_id,
            "request_id": self.request_id,
            "task_id": self.task_id,
            "agent_type": self.agent_type,
            "agent_id": self.agent_id,
            "result": self.result,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "next_action": self.next_action,
            "next_agent": self.next_agent,
            "status": self.status.value,
            "error": self.error,
            "error_details": self.error_details,
            "duration_ms": self.duration_ms,
            "tools_called": self.tools_called,
            "tokens_used": self.tokens_used,
            "timestamp": self.timestamp,
        }

    def is_success(self) -> bool:
        return self.status == AgentStatus.COMPLETED and self.error is None

    def is_retryable(self) -> bool:
        """判断是否可以重试"""
        if self.error_details and self.error_details.get("retryable", False):
            return True
        return self.status == AgentStatus.FAILED and self.confidence < 0.5
