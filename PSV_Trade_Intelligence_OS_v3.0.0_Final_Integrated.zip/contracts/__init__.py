"""
PSV Trade Intelligence OS - Contract Layer
所有模块间通信的标准化契约
"""
from .task_contract import TradeTask, TaskStatus, TaskPriority
from .agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from .tool_contract import ToolRequest, ToolResponse, ToolType, ToolStatus
from .data_contract import CompanyProfile, CustomerIntelligence, TradeOpportunity, CompanySize, CustomerLevel, LeadStatus
from .event_contract import SystemEvent, EventType, EventSeverity
from .memory_contract import MemoryEntry, MemoryType, MemoryScope

__all__ = [
    "TradeTask", "TaskStatus", "TaskPriority",
    "AgentRequest", "AgentResponse", "AgentStatus", "ConfidenceLevel",
    "ToolRequest", "ToolResponse", "ToolType", "ToolStatus",
    "CompanyProfile", "CustomerIntelligence", "TradeOpportunity",
    "CompanySize", "CustomerLevel", "LeadStatus",
    "SystemEvent", "EventType", "EventSeverity",
    "MemoryEntry", "MemoryType", "MemoryScope",
]
