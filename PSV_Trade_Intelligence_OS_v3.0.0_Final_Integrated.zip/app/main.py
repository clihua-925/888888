"""
app/main.py - PSV Trade Intelligence OS v3.0.0 统一入口
兼容原始 v45.14 系统 API + 新架构 API
"""
import os
import sys
from pathlib import Path

# 确保 legacy 在路径中
LEGACY_ROOT = Path(__file__).resolve().parents[1] / "legacy"
if str(LEGACY_ROOT) not in sys.path:
    sys.path.insert(0, str(LEGACY_ROOT))

from fastapi import FastAPI, BackgroundTasks, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

from contracts.task_contract import TradeTask, TaskStatus
from orchestrator.graph import TradeOrchestrator
from database.models import init_db, TradeTask as DBTask, TradeCompany, TradeCustomerPool, TradeWorkflow
from shared.config import get_config
from platform.adapter import get_legacy_adapter

app = FastAPI(
    title="PSV Trade Intelligence OS",
    version="3.0.0",
    description="以 LangGraph 多智能体编排为核心的外贸智能操作系统 (兼容 v45.14)",
)

# 初始化
config = get_config()
engine = create_engine(config.database_url)
init_db(config.database_url)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

orchestrator = None
legacy_adapter = None

@app.on_event("startup")
async def startup():
    global orchestrator, legacy_adapter
    orchestrator = TradeOrchestrator()
    legacy_adapter = get_legacy_adapter()
    recovered = orchestrator.recovery.auto_recover()
    print(f"✅ PSV Trade OS v3.0.0 started")
    print(f"   LangGraph Orchestrator: ready")
    print(f"   Legacy Adapter: {'ready' if legacy_adapter.system else 'fallback mode'}")
    print(f"   Auto-recovered: {len(recovered)} tasks")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ========== 新架构 API 模型 ==========
class TradeRequest(BaseModel):
    objective: str
    product: Optional[str] = None
    market: Optional[str] = None
    target_customer: Optional[str] = None

class TaskResponse(BaseModel):
    task_id: str
    status: str
    message: str

# ========== 新架构 API 路由 ==========
@app.post("/trade/execute", response_model=TaskResponse)
async def execute_trade_task(request: TradeRequest, background: BackgroundTasks):
    """执行外贸开发任务（LangGraph编排）"""
    task = TradeTask(
        objective=request.objective,
        product=request.product or "",
        market=request.market or "",
        target_customer=request.target_customer or "importer",
    )

    db = SessionLocal()
    db_task = DBTask(
        task_id=task.task_id,
        objective=task.objective,
        product=task.product,
        market=task.market,
        target_customer=task.target_customer,
        status="pending",
        priority=task.priority.value,
    )
    db.add(db_task)
    db.commit()
    db.close()

    background.add_task(_execute_task, task)

    return TaskResponse(
        task_id=task.task_id,
        status="accepted",
        message="Trade task queued for LangGraph execution",
    )

def _execute_task(task: TradeTask):
    """后台执行任务"""
    db = SessionLocal()
    try:
        db_task = db.query(DBTask).filter(DBTask.task_id == task.task_id).first()
        if db_task:
            db_task.status = "running"
            db.commit()

        result = orchestrator.run(task)

        db_task = db.query(DBTask).filter(DBTask.task_id == task.task_id).first()
        if db_task:
            db_task.status = "completed"
            db_task.completed_at = __import__("datetime").datetime.now()
            db.commit()
    except Exception as e:
        db_task = db.query(DBTask).filter(DBTask.task_id == task.task_id).first()
        if db_task:
            db_task.status = "failed"
            db.commit()
        print(f"Task {task.task_id} failed: {e}")
    finally:
        db.close()

@app.get("/trade/status/{task_id}")
async def get_task_status(task_id: str):
    """查询任务执行状态和审计摘要"""
    summary = orchestrator.audit.get_task_summary(task_id)

    db = SessionLocal()
    db_task = db.query(DBTask).filter(DBTask.task_id == task_id).first()
    db.close()

    if db_task:
        summary["task_info"] = {
            "objective": db_task.objective,
            "product": db_task.product,
            "market": db_task.market,
            "status": db_task.status,
            "created_at": db_task.created_at.isoformat() if db_task.created_at else None,
        }

    return summary

@app.get("/trade/tasks")
async def list_tasks(limit: int = 50):
    """列出所有任务"""
    db = SessionLocal()
    tasks = db.query(DBTask).order_by(DBTask.created_at.desc()).limit(limit).all()
    db.close()

    return [{
        "task_id": t.task_id,
        "objective": t.objective,
        "market": t.market,
        "status": t.status,
        "priority": t.priority,
        "created_at": t.created_at.isoformat() if t.created_at else None,
    } for t in tasks]

@app.post("/trade/recover/{workflow_id}")
async def recover_task(workflow_id: str):
    """恢复中断的任务"""
    result = orchestrator.resume(workflow_id)
    return result

@app.get("/trade/companies")
async def list_companies(limit: int = 100):
    """列出发现的企业"""
    db = SessionLocal()
    companies = db.query(TradeCompany).limit(limit).all()
    db.close()

    return [{
        "company_id": c.company_id,
        "name": c.name,
        "country": c.country,
        "website": c.website,
        "industry": c.industry,
        "credibility_score": c.credibility_score,
        "match_score": c.match_score,
    } for c in companies]

@app.get("/trade/leads")
async def list_leads(limit: int = 100):
    """列出评分线索"""
    db = SessionLocal()
    leads = db.query(TradeCustomerPool).limit(limit).all()
    db.close()

    return [{
        "customer_id": l.customer_id,
        "company_id": l.company_id,
        "level": l.level,
        "value_score": l.value_score,
        "match_score": l.match_score,
        "deal_probability": l.deal_probability,
        "priority": l.development_priority,
        "status": l.follow_up_status,
    } for l in leads]

# ========== 原始系统兼容 API ==========
@app.post("/api/collect")
async def legacy_collect(request: Request):
    """兼容原始系统的采集接口"""
    data = await request.json()
    result = legacy_adapter.run_collection(
        request=data.get("request", ""),
        market=data.get("market", "USA"),
        industry=data.get("industry", "candle"),
        quantity=data.get("quantity", 20),
        task_id=data.get("task_id"),
        auto_expand=data.get("auto_expand", True),
    )
    return result

@app.post("/api/expand")
async def legacy_expand(request: Request):
    """兼容原始系统的扩张接口"""
    data = await request.json()
    result = legacy_adapter.expand_network(
        category_id=data.get("category_id", "candle"),
        parent_task_id=data.get("parent_task_id"),
        strategies=data.get("strategies"),
        max_depth=data.get("max_depth", 2),
    )
    return result

@app.get("/api/entity/{norm}")
async def legacy_get_entity(norm: str):
    """兼容原始系统的实体查询"""
    entity = legacy_adapter.get_entity(norm)
    if entity:
        return entity
    raise HTTPException(status_code=404, detail="Entity not found")

@app.get("/api/entities")
async def legacy_list_entities(category_id: str = None, role: str = None, limit: int = 100):
    """兼容原始系统的实体列表"""
    return legacy_adapter.list_entities(category_id=category_id, role=role, limit=limit)

@app.get("/api/trade_edges")
async def legacy_list_edges(norm: str = None, category_id: str = None):
    """兼容原始系统的贸易边列表"""
    return legacy_adapter.list_trade_edges(norm=norm, category_id=category_id)

@app.get("/api/intelligence/{norm}")
async def legacy_intelligence(norm: str):
    """兼容原始系统的情报查询"""
    return legacy_adapter.get_intelligence(norm)

@app.get("/api/tasks")
async def legacy_list_tasks(limit: int = 50):
    """兼容原始系统的任务列表"""
    return legacy_adapter.list_tasks(limit=limit)

@app.get("/api/task/{task_id}")
async def legacy_get_task(task_id: str):
    """兼容原始系统的任务查询"""
    task = legacy_adapter.get_task(task_id)
    if task:
        return task
    raise HTTPException(status_code=404, detail="Task not found")

@app.get("/api/leads")
async def legacy_list_leads(zone: str = None, category_id: str = None, limit: int = 100):
    """兼容原始系统的线索列表"""
    return legacy_adapter.list_leads(zone=zone, category_id=category_id, limit=limit)

@app.get("/api/lead/{norm}")
async def legacy_get_lead(norm: str):
    """兼容原始系统的线索查询"""
    lead = legacy_adapter.get_lead(norm)
    if lead:
        return lead
    raise HTTPException(status_code=404, detail="Lead not found")

@app.get("/api/industries")
async def legacy_list_industries():
    """兼容原始系统的行业列表"""
    return legacy_adapter.list_industries()

@app.get("/api/industry/{key}")
async def legacy_load_industry(key: str):
    """兼容原始系统的行业配置"""
    return legacy_adapter.load_industry(key)

@app.get("/api/markets")
async def legacy_load_markets():
    """兼容原始系统的市场列表"""
    return legacy_adapter.load_markets()

# ========== 健康检查 ==========
@app.get("/health")
async def health():
    """健康检查"""
    return {
        "status": "healthy",
        "system": "PSV Trade Intelligence OS v3.0.0",
        "engine": "LangGraph Multi-Agent Orchestrator",
        "legacy_adapter": "active" if legacy_adapter and legacy_adapter.system else "fallback",
    }

# ========== 原始系统 WebUI 静态文件 ==========
# 如果 legacy/core/webui/static 存在，挂载它
legacy_static = LEGACY_ROOT / "core" / "webui" / "static"
if legacy_static.exists():
    app.mount("/static", StaticFiles(directory=str(legacy_static)), name="static")

@app.get("/", response_class=HTMLResponse)
async def root():
    """根路径重定向到 WebUI"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>PSV Trade Intelligence OS v3.0.0</title>
        <meta charset="utf-8">
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 0; padding: 40px; background: #0f172a; color: #e2e8f0; }
            .container { max-width: 900px; margin: 0 auto; }
            h1 { color: #38bdf8; font-size: 2.5em; margin-bottom: 10px; }
            .subtitle { color: #94a3b8; font-size: 1.1em; margin-bottom: 40px; }
            .card { background: #1e293b; border-radius: 12px; padding: 24px; margin-bottom: 20px; border: 1px solid #334155; }
            .card h2 { color: #38bdf8; margin-top: 0; font-size: 1.3em; }
            .card p { color: #cbd5e1; line-height: 1.6; }
            .links { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-top: 20px; }
            .link { display: block; background: #0ea5e9; color: white; padding: 12px 20px; border-radius: 8px; text-decoration: none; text-align: center; font-weight: 500; transition: background 0.2s; }
            .link:hover { background: #0284c7; }
            .link.secondary { background: #334155; }
            .link.secondary:hover { background: #475569; }
            .badge { display: inline-block; background: #10b981; color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.85em; font-weight: 500; }
            .badge.warn { background: #f59e0b; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🌐 PSV Trade Intelligence OS</h1>
            <p class="subtitle">v3.0.0 · LangGraph 多智能体编排引擎 · 兼容 v45.14</p>

            <div class="card">
                <h2>系统状态</h2>
                <p><span class="badge">LangGraph 编排器</span> 运行中</p>
                <p><span class="badge">原始系统适配层</span> 已加载</p>
                <p><span class="badge">审计追踪</span> 启用</p>
                <p><span class="badge">检查点恢复</span> 启用</p>
            </div>

            <div class="card">
                <h2>快速入口</h2>
                <div class="links">
                    <a href="/docs" class="link">📚 API 文档 (Swagger)</a>
                    <a href="/redoc" class="link secondary">📖 API 文档 (ReDoc)</a>
                </div>
            </div>

            <div class="card">
                <h2>核心能力</h2>
                <p>✅ 9节点采集链 (PRODUCT_DEFINITION → DATABASE_COMMIT)</p>
                <p>✅ 6种网络扩张策略 (customer_suppliers → cross_market_entity)</p>
                <p>✅ 6节点业务执行 (PROFILE_AUDIT → COMPLETED)</p>
                <p>✅ 瀑布式 enrichment (web_ai → customs_graph → iy_web → suppliers)</p>
                <p>✅ AI Judge 自动审核</p>
                <p>✅ 检查点恢复机制</p>
            </div>
        </div>
    </body>
    </html>
    """

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
