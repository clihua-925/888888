"""PSV Trade Intelligence OS - App Layer
"""
from .main import app

__all__ = ["app"]
