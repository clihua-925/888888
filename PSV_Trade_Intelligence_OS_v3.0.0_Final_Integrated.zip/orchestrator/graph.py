"""
graph.py - LangGraph 工作流图定义
核心引擎：新架构编排 + 原始系统业务逻辑（通过适配层）
"""
from typing import Dict, Any
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver

from orchestrator.state import TradeGraphState
from orchestrator.router import WorkflowRouter
from orchestrator.executor import WorkflowExecutor
from orchestrator.planner import TradePlannerAgent
from orchestrator.supervisor import SupervisorAgent
from orchestrator.checkpoint import CheckpointManager
from orchestrator.recovery import RecoveryManager
from shared.state import StateManager
from audit.audit_logger import AuditLogger
from platform.adapter import get_legacy_adapter

# Import all agents
from agents.market_research import MarketResearchAgent
from agents.company_discovery import CompanyDiscoveryAgent
from agents.company_enrichment import CompanyEnrichmentAgent
from agents.contact_discovery import ContactDiscoveryAgent
from agents.lead_scoring import LeadScoringAgent
from agents.sales_strategy import SalesStrategyAgent
from agents.report_agent import ReportAgent

class TradeOrchestrator:
    """PSV 贸易智能编排器 - v3.0.0"""

    def __init__(self, db_path: str = "psv_orchestrator.db"):
        self.audit = AuditLogger()
        self.state_manager = StateManager(db_path)
        self.checkpoint_manager = CheckpointManager(self.state_manager)
        self.recovery = RecoveryManager(self.checkpoint_manager, self.state_manager, self.audit)
        self.router = WorkflowRouter()
        self.executor = WorkflowExecutor(self.audit)
        self.planner = TradePlannerAgent()
        self.supervisor = SupervisorAgent(self.audit, self.state_manager)

        # 原始系统适配器
        self.legacy = get_legacy_adapter()

        # 注册所有业务Agent
        self._register_agents()

        # 构建图
        self.graph = self._build_graph()
        self.app = self.graph.compile(checkpointer=SqliteSaver.from_conn_string(db_path))

    def _register_agents(self):
        """注册所有业务Agent"""
        self.supervisor.register_agent("market_research", MarketResearchAgent())
        self.supervisor.register_agent("company_discovery", CompanyDiscoveryAgent())
        self.supervisor.register_agent("company_enrichment", CompanyEnrichmentAgent())
        self.supervisor.register_agent("contact_discovery", ContactDiscoveryAgent())
        self.supervisor.register_agent("lead_scoring", LeadScoringAgent())
        self.supervisor.register_agent("sales_strategy", SalesStrategyAgent())
        self.supervisor.register_agent("report_agent", ReportAgent())

    def _build_graph(self) -> StateGraph:
        """构建LangGraph状态图"""
        builder = StateGraph(TradeGraphState)

        builder.add_node("trade_planner", self._node_planner)
        builder.add_node("market_research", self._node_market_research)
        builder.add_node("company_discovery", self._node_company_discovery)
        builder.add_node("company_enrichment", self._node_company_enrichment)
        builder.add_node("contact_discovery", self._node_contact_discovery)
        builder.add_node("lead_scoring", self._node_lead_scoring)
        builder.add_node("sales_strategy", self._node_sales_strategy)
        builder.add_node("report_agent", self._node_report)
        builder.add_node("error_handler", self._node_error_handler)

        builder.set_entry_point("trade_planner")

        builder.add_conditional_edges(
            "trade_planner",
            self.router.route_after_planner,
            {"market_research": "market_research", "planner_retry": "trade_planner"}
        )

        for agent in ["market_research", "company_discovery", "company_enrichment",
                      "contact_discovery", "lead_scoring", "sales_strategy"]:
            builder.add_conditional_edges(
                agent, self.router.route_after_agent,
                {a: a for a in ["market_research", "company_discovery", "company_enrichment",
                                "contact_discovery", "lead_scoring", "sales_strategy",
                                "report_agent", "retry", "error_handler"]}
            )

        builder.add_conditional_edges(
            "error_handler", self.router.route_after_error,
            {"market_research": "market_research", "company_discovery": "company_discovery",
             "report_agent": "report_agent"}
        )

        builder.add_edge("report_agent", END)
        return builder

    def _node_planner(self, state: TradeGraphState) -> TradeGraphState:
        task = state["task"]
        plan = self.planner.plan(task)
        state["plan"] = plan
        state["plan_validated"] = self.planner.validate_plan(plan)
        state["current_agent"] = "trade_planner"
        if state["plan_validated"]:
            state["should_continue"] = True
        return state

    def _node_market_research(self, state: TradeGraphState) -> TradeGraphState:
        """市场研究 - 调用原始系统的行业配置和市场数据"""
        task = state["task"]

        # 通过适配层获取原始系统的行业配置
        industry_config = self.legacy.load_industry(task.product or "candle")
        markets = self.legacy.load_markets()

        plan_step = {
            "agent": "market_research",
            "action": "analyze_market",
            "inputs": {
                "market": task.market,
                "product": task.product,
                "industry_config": industry_config,
                "markets": markets,
            }
        }

        response = self.supervisor.execute_step(task, plan_step, state.get("plan", {}))
        state["current_agent"] = "market_research"

        if response.is_success():
            state["market_analysis"] = response.result
            state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        else:
            state["error"] = response.error
            state["retry_count"] = state.get("retry_count", 0) + 1

        self.checkpoint_manager.save_checkpoint(state.get("task_id", ""), state)
        return state

    def _node_company_discovery(self, state: TradeGraphState) -> TradeGraphState:
        """企业发现 - 调用原始系统的9节点采集链"""
        task = state["task"]

        # 通过适配层调用原始系统的采集链
        if self.legacy.system:
            try:
                collection_result = self.legacy.run_collection(
                    request=task.objective,
                    market=task.market or "USA",
                    industry=task.product or "candle",
                    quantity=20,
                    task_id=task.task_id,
                    auto_expand=True,
                )

                # 从原始系统数据库读取发现的企业
                category_id = task.product or "candle"
                entities = self.legacy.list_entities(
                    category_id=category_id,
                    role="customer",
                    limit=50
                )

                from contracts.data_contract import CompanyProfile
                companies = []
                for ent in entities:
                    companies.append(CompanyProfile(
                        name=ent.get("name", ""),
                        country=ent.get("country", ""),
                        website=ent.get("website"),
                        industry=ent.get("industry"),
                        main_products=ent.get("product_categories", []),
                        credibility_score=ent.get("info_completeness", 0) * 100,
                        source="legacy_collection",
                    ))

                state["companies_discovered"] = state.get("companies_discovered", []) + companies
                state["agent_history"] = state.get("agent_history", []) + [{
                    "agent_type": "company_discovery",
                    "status": "completed",
                    "result": {"companies_count": len(companies), "collection_status": collection_result.get("status")},
                }]
            except Exception as e:
                state["error"] = str(e)
                state["retry_count"] = state.get("retry_count", 0) + 1
        else:
            # 回退到新架构的采集逻辑
            plan_step = {"agent": "company_discovery", "action": "discover_companies",
                         "inputs": {"market": task.market, "product": task.product, "target_type": task.target_customer or "importer"}}
            response = self.supervisor.execute_step(task, plan_step, state.get("plan", {}))
            if response.is_success():
                from contracts.data_contract import CompanyProfile
                companies_data = response.result.get("companies", [])
                companies = [CompanyProfile.from_dict(c) if isinstance(c, dict) else c for c in companies_data]
                state["companies_discovered"] = state.get("companies_discovered", []) + companies
            else:
                state["error"] = response.error
                state["retry_count"] = state.get("retry_count", 0) + 1

        state["current_agent"] = "company_discovery"
        self.checkpoint_manager.save_checkpoint(state.get("task_id", ""), state)
        return state

    def _node_company_enrichment(self, state: TradeGraphState) -> TradeGraphState:
        """企业信息补全 - 调用原始系统的 waterfall enrichment"""
        task = state["task"]
        companies = state.get("companies_discovered", [])

        enriched = []
        for company in companies:
            # 通过适配层调用原始系统的 enrichment
            if self.legacy.system:
                try:
                    result = self.legacy.enrich_entity(
                        norm=company.name,
                        category_id=task.product or "candle",
                        task_id=task.task_id,
                    )
                    # 从原始系统读取 enrichment 结果
                    entity = self.legacy.get_entity(company.name)
                    if entity:
                        company.industry = entity.get("industry", company.industry)
                        company.website = entity.get("website", company.website)
                        company.phone = entity.get("phone", company.phone)
                        company.credibility_score = entity.get("info_completeness", 0) * 100
                        company.last_updated = __import__("datetime").datetime.now().isoformat()
                    enriched.append(company)
                except Exception:
                    enriched.append(company)
            else:
                enriched.append(company)

        state["companies_enriched"] = state.get("companies_enriched", []) + enriched
        state["current_agent"] = "company_enrichment"
        self.checkpoint_manager.save_checkpoint(state.get("task_id", ""), state)
        return state

    def _node_contact_discovery(self, state: TradeGraphState) -> TradeGraphState:
        """联系人发现 - 从原始系统读取 contacts"""
        task = state["task"]
        companies = state.get("companies_enriched", []) or state.get("companies_discovered", [])

        contacts = []
        if self.legacy.db:
            for company in companies:
                try:
                    entity = self.legacy.get_entity(company.name)
                    if entity:
                        entity_id = entity.get("entity_id")
                        # 从原始系统读取 contacts
                        legacy_contacts = self.legacy.db.list_contacts(entity_id=entity_id)
                        for lc in legacy_contacts:
                            contacts.append({
                                "company_id": company.company_id,
                                "company_name": company.name,
                                "name": lc.get("name", ""),
                                "title": lc.get("title", ""),
                                "email": lc.get("email", ""),
                                "phone": lc.get("phone", ""),
                                "linkedin": lc.get("linkedin", ""),
                                "verified": lc.get("verified", 0),
                                "source": lc.get("source", "legacy"),
                            })
                except Exception:
                    pass

        # 如果原始系统没有 contacts，回退到新逻辑
        if not contacts:
            plan_step = {"agent": "contact_discovery", "action": "find_contacts",
                         "inputs": {"companies": [c.to_dict() for c in companies]}}
            response = self.supervisor.execute_step(task, plan_step, state.get("plan", {}))
            if response.is_success():
                contacts = response.result.get("contacts", [])

        state["contacts_found"] = state.get("contacts_found", []) + contacts
        state["current_agent"] = "contact_discovery"
        self.checkpoint_manager.save_checkpoint(state.get("task_id", ""), state)
        return state

    def _node_lead_scoring(self, state: TradeGraphState) -> TradeGraphState:
        """线索评分 - 结合原始系统的 value_score_total"""
        task = state["task"]
        companies = state.get("companies_enriched", []) or state.get("companies_discovered", [])

        scored = []
        for company in companies:
            # 从原始系统读取评分
            if self.legacy.db:
                try:
                    entity = self.legacy.get_entity(company.name)
                    if entity:
                        company.credibility_score = entity.get("value_score_total", 0)
                        company.match_score = entity.get("info_completeness", 0) * 100
                except Exception:
                    pass

            from contracts.data_contract import CustomerIntelligence, CustomerLevel, LeadStatus

            total = company.credibility_score + company.match_score
            level = CustomerLevel.COLD
            if total >= 150: level = CustomerLevel.VIP
            elif total >= 120: level = CustomerLevel.HOT
            elif total >= 80: level = CustomerLevel.WARM

            scored.append(CustomerIntelligence(
                company_id=company.company_id,
                level=level,
                value_score=round(total / 2, 1),
                match_score=company.match_score,
                deal_probability=round(company.credibility_score / 10, 1),
                development_priority=min(10, max(1, int(total / 30))),
                follow_up_status=LeadStatus.NEW,
            ))

        state["leads_scored"] = state.get("leads_scored", []) + scored
        state["current_agent"] = "lead_scoring"
        self.checkpoint_manager.save_checkpoint(state.get("task_id", ""), state)
        return state

    def _node_sales_strategy(self, state: TradeGraphState) -> TradeGraphState:
        """销售策略 - 调用原始系统的业务执行中心"""
        task = state["task"]
        leads = state.get("leads_scored", [])
        companies = state.get("companies_enriched", []) or state.get("companies_discovered", [])

        strategies = []
        if self.legacy.system and leads:
            top_lead = leads[0]
            company = next((c for c in companies if c.company_id == top_lead.company_id), None)
            if company:
                try:
                    result = self.legacy.execute_business(
                        lead_norm=company.name,
                        category_id=task.product or "candle",
                        our_product=task.product,
                        mode="draft",
                        task_id=task.task_id,
                    )
                    strategies.append({
                        "company_id": company.company_id,
                        "company_name": company.name,
                        "legacy_result": result,
                    })
                except Exception:
                    pass

        # 回退到新策略生成
        if not strategies:
            plan_step = {"agent": "sales_strategy", "action": "generate_strategy",
                         "inputs": {"top_leads": [l.to_dict() for l in leads[:20]],
                                    "companies": [c.to_dict() for c in companies],
                                    "product": task.product}}
            response = self.supervisor.execute_step(task, plan_step, state.get("plan", {}))
            if response.is_success():
                strategies = response.result.get("strategies", [])

        state["sales_strategies"] = state.get("sales_strategies", []) + strategies
        state["current_agent"] = "sales_strategy"
        self.checkpoint_manager.save_checkpoint(state.get("task_id", ""), state)
        return state

    def _node_report(self, state: TradeGraphState) -> TradeGraphState:
        """报告生成"""
        task = state["task"]

        # 从原始系统读取统计数据
        legacy_stats = {}
        if self.legacy.db:
            try:
                category_id = task.product or "candle"
                entities = self.legacy.list_entities(category_id=category_id, limit=1000)
                edges = self.legacy.list_trade_edges(category_id=category_id)
                legacy_stats = {
                    "legacy_entities_count": len(entities),
                    "legacy_edges_count": len(edges),
                    "legacy_category": category_id,
                }
            except Exception:
                pass

        plan_step = {"agent": "report_agent", "action": "generate_report",
                     "inputs": {"context": {
                         "objective": task.objective,
                         "market": task.market,
                         "product": task.product,
                         "market_analysis": state.get("market_analysis", {}),
                         "companies": [c.to_dict() for c in state.get("companies_enriched", state.get("companies_discovered", []))],
                         "contacts": state.get("contacts_found", []),
                         "scored_leads": [l.to_dict() for l in state.get("leads_scored", [])],
                         "strategies": state.get("sales_strategies", []),
                         "legacy_stats": legacy_stats,
                     }}}

        response = self.supervisor.execute_step(task, plan_step, state.get("plan", {}))
        state["current_agent"] = "report_agent"

        if response.is_success():
            state["final_report"] = response.result.get("report", {})
            state["status"] = "completed"
            state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        else:
            state["error"] = response.error
            state["status"] = "failed"

        self.checkpoint_manager.save_checkpoint(state.get("task_id", ""), state)
        return state

    def _node_error_handler(self, state: TradeGraphState) -> TradeGraphState:
        state["status"] = "failed"
        return state

    def run(self, task) -> Dict[str, Any]:
        """执行外贸任务"""
        initial_state = {
            "task": task, "task_id": task.task_id,
            "plan": {}, "plan_validated": False,
            "current_agent": "", "agent_history": [],
            "market_analysis": None,
            "companies_discovered": [], "companies_enriched": [],
            "contacts_found": [], "leads_scored": [],
            "sales_strategies": [], "opportunities": [],
            "next_step": None, "should_continue": True,
            "error": None, "retry_count": 0,
            "execution_log": [], "final_report": None,
            "status": "running",
        }

        config = {"configurable": {"thread_id": task.task_id}}
        result = self.app.invoke(initial_state, config)
        return result.get("final_report", {})

    def resume(self, workflow_id: str) -> Dict[str, Any]:
        """恢复中断的任务"""
        recovered_state = self.recovery.recover_task(workflow_id)
        if not recovered_state:
            return {"error": "Cannot recover workflow"}

        config = {"configurable": {"thread_id": recovered_state["task_id"]}}
        result = self.app.invoke(recovered_state, config)
        return result.get("final_report", {})
