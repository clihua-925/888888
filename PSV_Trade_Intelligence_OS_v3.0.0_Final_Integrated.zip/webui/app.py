"""
webui/app.py - Streamlit 主应用
展示：市场分析、客户池、企业画像、开发任务、商业机会、供应链关系、智能报告
禁止展示：Node1, Node2, Runtime, Queue
"""
import streamlit as st
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from contracts.task_contract import TradeTask
from orchestrator.graph import TradeOrchestrator
from database.models import init_db, TradeTask as DBTask, TradeCompany, TradeCustomerPool
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

st.set_page_config(
    page_title="PSV Trade Intelligence OS",
    page_icon="🌐",
    layout="wide",
    initial_sidebar_state="expanded",
)

# 初始化
@st.cache_resource
def get_orchestrator():
    return TradeOrchestrator()

@st.cache_resource
def get_db_session():
    engine = create_engine("sqlite:///psv_trade_os.db")
    init_db("sqlite:///psv_trade_os.db")
    Session = sessionmaker(bind=engine)
    return Session()

orc = get_orchestrator()
db = get_db_session()

# 侧边栏导航
st.sidebar.title("🌐 PSV Trade OS")
page = st.sidebar.radio("导航", [
    "🏠 首页",
    "🎯 新建开发任务",
    "📊 市场分析",
    "🏢 客户池",
    "🔍 企业画像",
    "💡 商业机会",
    "📋 智能报告",
    "⚙️ 任务管理",
])

# ========== 首页 ==========
if page == "🏠 首页":
    st.title("PSV Trade Intelligence OS v3.0.0")
    st.markdown("""
    ### 外贸智能操作系统

    基于 **LangGraph 多智能体编排** 的外贸客户开发引擎。

    **核心能力：**
    - 🎯 智能任务规划
    - 📊 全球市场分析
    - 🔍 企业自动发现与画像
    - 📧 联系人挖掘
    - ⭐ 客户智能评分
    - 💡 开发策略生成
    - 📋 完整开发报告

    **当前状态：**
    """)

    col1, col2, col3, col4 = st.columns(4)

    try:
        total_tasks = db.query(DBTask).count()
        total_companies = db.query(TradeCompany).count()
        total_leads = db.query(TradeCustomerPool).count()
        active_tasks = db.query(DBTask).filter(DBTask.status.in_(["running", "pending"])).count()

        col1.metric("总任务数", total_tasks)
        col2.metric("发现企业", total_companies)
        col3.metric("评分线索", total_leads)
        col4.metric("进行中", active_tasks)
    except Exception as e:
        col1.metric("总任务数", 0)
        col2.metric("发现企业", 0)
        col3.metric("评分线索", 0)
        col4.metric("进行中", 0)

# ========== 新建开发任务 ==========
elif page == "🎯 新建开发任务":
    st.title("🎯 新建外贸开发任务")

    with st.form("trade_task_form"):
        objective = st.text_input("开发目标", placeholder="例如：开发美国生日蜡烛进口商")
        product = st.text_input("产品", placeholder="例如：生日蜡烛 / Birthday Candles")
        market = st.selectbox("目标市场", ["US", "EU", "UK", "DE", "JP", "AU", "CA", "Other"])
        target_customer = st.selectbox("客户类型", [
            "importer", "distributor", "wholesaler", "retailer", "buyer"
        ])

        submitted = st.form_submit_button("🚀 启动智能开发", use_container_width=True)

        if submitted and objective:
            task = TradeTask(
                objective=objective,
                product=product or "",
                market=market if market != "Other" else "",
                target_customer=target_customer,
            )

            with st.spinner("LangGraph 编排引擎正在执行..."):
                # 这里实际应该后台执行，简化演示同步执行
                result = orc.run(task)

            st.success(f"任务完成！Task ID: {task.task_id}")

            if result:
                st.subheader("📋 执行结果")
                st.json(result)

# ========== 市场分析 ==========
elif page == "📊 市场分析":
    st.title("📊 市场分析")
    st.info("查看已执行任务的市场分析结果")

    try:
        tasks = db.query(DBTask).filter(DBTask.status == "completed").order_by(DBTask.created_at.desc()).limit(10).all()
        if tasks:
            task_options = {t.task_id: f"{t.objective[:50]}... ({t.market})" for t in tasks}
            selected = st.selectbox("选择任务", list(task_options.keys()), format_func=lambda x: task_options[x])

            # 这里应该从state或agent_history中加载市场分析
            st.markdown("市场分析报告将在此处展示")
        else:
            st.warning("暂无已完成的市场分析任务")
    except:
        st.warning("数据库暂无数据")

# ========== 客户池 ==========
elif page == "🏢 客户池":
    st.title("🏢 Customer Intelligence Pool")

    try:
        leads = db.query(TradeCustomerPool).join(TradeCompany).limit(100).all()
        if leads:
            data = []
            for lead in leads:
                company = db.query(TradeCompany).filter(TradeCompany.company_id == lead.company_id).first()
                data.append({
                    "客户ID": lead.customer_id,
                    "企业名称": company.name if company else "Unknown",
                    "国家": company.country if company else "",
                    "等级": lead.level,
                    "价值分": lead.value_score,
                    "匹配度": lead.match_score,
                    "成交概率": lead.deal_probability,
                    "优先级": lead.development_priority,
                    "跟进状态": lead.follow_up_status,
                })

            st.dataframe(data, use_container_width=True)

            # 可视化
            col1, col2 = st.columns(2)
            with col1:
                st.subheader("客户等级分布")
                level_counts = {}
                for d in data:
                    level_counts[d["等级"]] = level_counts.get(d["等级"], 0) + 1
                st.bar_chart(level_counts)

            with col2:
                st.subheader("成交概率分布")
                prob_ranges = {"0-30%": 0, "30-60%": 0, "60-80%": 0, "80-100%": 0}
                for d in data:
                    p = d["成交概率"]
                    if p < 30:
                        prob_ranges["0-30%"] += 1
                    elif p < 60:
                        prob_ranges["30-60%"] += 1
                    elif p < 80:
                        prob_ranges["60-80%"] += 1
                    else:
                        prob_ranges["80-100%"] += 1
                st.bar_chart(prob_ranges)
        else:
            st.info("客户池为空，请先执行开发任务")
    except Exception as e:
        st.error(f"加载客户池失败: {e}")

# ========== 企业画像 ==========
elif page == "🔍 企业画像":
    st.title("🔍 企业画像")

    try:
        companies = db.query(TradeCompany).limit(50).all()
        if companies:
            for company in companies:
                with st.expander(f"🏢 {company.name} ({company.country})"):
                    col1, col2 = st.columns(2)
                    with col1:
                        st.write(f"**行业:** {company.industry or 'Unknown'}")
                        st.write(f"**网站:** {company.website or 'N/A'}")
                        st.write(f"**规模:** {company.company_size}")
                        st.write(f"**主营产品:** {', '.join(company.main_products) if company.main_products else 'N/A'}")
                    with col2:
                        st.write(f"**可信度:** {company.credibility_score}/100")
                        st.write(f"**采购可能性:** {company.procurement_probability}/100")
                        st.write(f"**匹配度:** {company.match_score}/100")
                        if company.contacts:
                            st.write("**联系方式:**")
                            for c in company.contacts[:3]:
                                st.write(f"- {c.get('type', '')}: {c.get('value', '')}")
        else:
            st.info("暂无企业数据")
    except:
        st.info("暂无企业数据")

# ========== 商业机会 ==========
elif page == "💡 商业机会":
    st.title("💡 商业机会")
    st.info("基于AI分析识别的商业机会")
    st.markdown("""
    #### 机会类型
    - 🆕 新市场进入机会
    - 📈 复购潜力客户
    - 🔗 供应链优化机会
    - 🎯 高匹配度客户
    """)

# ========== 智能报告 ==========
elif page == "📋 智能报告":
    st.title("📋 智能报告")

    try:
        tasks = db.query(DBTask).filter(DBTask.status == "completed").order_by(DBTask.created_at.desc()).limit(20).all()
        if tasks:
            for task in tasks:
                with st.expander(f"📄 {task.objective[:60]}..."):
                    st.write(f"**目标市场:** {task.market}")
                    st.write(f"**产品:** {task.product}")
                    st.write(f"**完成时间:** {task.completed_at}")
                    st.write(f"**状态:** ✅ 已完成")
        else:
            st.info("暂无报告，请先执行开发任务")
    except:
        st.info("暂无报告数据")

# ========== 任务管理 ==========
elif page == "⚙️ 任务管理":
    st.title("⚙️ 任务管理")

    try:
        tasks = db.query(DBTask).order_by(DBTask.created_at.desc()).limit(50).all()
        if tasks:
            data = []
            for t in tasks:
                data.append({
                    "任务ID": t.task_id,
                    "目标": t.objective[:40] + "...",
                    "市场": t.market,
                    "状态": t.status,
                    "优先级": t.priority,
                    "创建时间": t.created_at.strftime("%Y-%m-%d %H:%M") if t.created_at else "",
                })
            st.dataframe(data, use_container_width=True)
        else:
            st.info("暂无任务")
    except:
        st.info("数据库连接中...")

    st.divider()
    st.subheader("🔄 中断恢复")
    workflow_id = st.text_input("输入 Workflow ID 恢复任务")
    if st.button("恢复执行") and workflow_id:
        with st.spinner("正在恢复..."):
            result = orc.resume(workflow_id)
        st.json(result)
