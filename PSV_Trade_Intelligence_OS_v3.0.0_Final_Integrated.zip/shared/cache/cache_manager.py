"""
Shared Cache - 统一缓存管理
"""
import time
import hashlib
import json
from typing import Optional, Any, Dict
from datetime import datetime, timedelta

class CacheManager:
    """缓存管理器 - 支持内存缓存，可扩展为Redis"""

    def __init__(self, ttl: int = 3600):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._ttl = ttl

    def _make_key(self, *args, **kwargs) -> str:
        """生成缓存键"""
        key_data = json.dumps({"args": args, "kwargs": kwargs}, sort_keys=True, ensure_ascii=False)
        return hashlib.md5(key_data.encode()).hexdigest()

    def get(self, key: str) -> Optional[Any]:
        """获取缓存"""
        if key not in self._cache:
            return None

        entry = self._cache[key]
        if datetime.now().timestamp() > entry["expires_at"]:
            del self._cache[key]
            return None

        return entry["value"]

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """设置缓存"""
        expires = datetime.now().timestamp() + (ttl or self._ttl)
        self._cache[key] = {
            "value": value,
            "expires_at": expires,
            "created_at": datetime.now().isoformat(),
        }

    def delete(self, key: str):
        """删除缓存"""
        if key in self._cache:
            del self._cache[key]

    def clear(self):
        """清空缓存"""
        self._cache.clear()

    def cleanup(self) -> int:
        """清理过期缓存，返回清理数量"""
        now = datetime.now().timestamp()
        expired = [k for k, v in self._cache.items() if v["expires_at"] < now]
        for k in expired:
            del self._cache[k]
        return len(expired)

    def cached(self, ttl: Optional[int] = None):
        """装饰器 - 自动缓存函数结果"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                cache_key = self._make_key(func.__name__, *args, **kwargs)
                cached_value = self.get(cache_key)
                if cached_value is not None:
                    return cached_value

                result = func(*args, **kwargs)
                self.set(cache_key, result, ttl)
                return result
            return wrapper
        return decorator
