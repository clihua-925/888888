"""
Shared State - LangGraph Workflow 状态管理
支持：暂停、恢复、继续执行
"""
import json
import sqlite3
from typing import Optional, Dict, Any, List
from datetime import datetime
from dataclasses import dataclass, field
import uuid

from contracts.task_contract import TradeTask, TaskStatus

@dataclass
class WorkflowState:
    """工作流状态 - LangGraph State"""
    workflow_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str = ""
    current_node: str = ""                 # 当前执行到的节点
    completed_nodes: List[str] = field(default_factory=list)
    pending_nodes: List[str] = field(default_factory=list)

    # 状态数据
    context: Dict[str, Any] = field(default_factory=dict)      # 共享上下文
    node_outputs: Dict[str, Any] = field(default_factory=dict) # 各节点输出

    # 控制状态
    status: str = "running"                # running/paused/completed/failed
    pause_reason: Optional[str] = None
    error: Optional[str] = None

    # 时间戳
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    resumed_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "workflow_id": self.workflow_id,
            "task_id": self.task_id,
            "current_node": self.current_node,
            "completed_nodes": self.completed_nodes,
            "pending_nodes": self.pending_nodes,
            "context": self.context,
            "node_outputs": self.node_outputs,
            "status": self.status,
            "pause_reason": self.pause_reason,
            "error": self.error,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "resumed_at": self.resumed_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowState":
        return cls(
            workflow_id=data.get("workflow_id", str(uuid.uuid4())),
            task_id=data.get("task_id", ""),
            current_node=data.get("current_node", ""),
            completed_nodes=data.get("completed_nodes", []),
            pending_nodes=data.get("pending_nodes", []),
            context=data.get("context", {}),
            node_outputs=data.get("node_outputs", {}),
            status=data.get("status", "running"),
            pause_reason=data.get("pause_reason"),
            error=data.get("error"),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
            resumed_at=data.get("resumed_at"),
        )

class StateManager:
    """状态管理器 - 持久化工作流状态"""

    def __init__(self, db_path: str = "psv_state.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS workflow_states (
                workflow_id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                state_json TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_state_task ON workflow_states(task_id)
        """)
        conn.commit()
        conn.close()

    def save(self, state: WorkflowState) -> str:
        """保存状态"""
        state.updated_at = datetime.now().isoformat()
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO workflow_states 
            (workflow_id, task_id, state_json, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            state.workflow_id,
            state.task_id,
            json.dumps(state.to_dict(), ensure_ascii=False),
            state.status,
            state.created_at,
            state.updated_at,
        ))
        conn.commit()
        conn.close()
        return state.workflow_id

    def load(self, workflow_id: str) -> Optional[WorkflowState]:
        """加载状态"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT state_json FROM workflow_states WHERE workflow_id = ?", (workflow_id,))
        row = cursor.fetchone()
        conn.close()

        if row:
            return WorkflowState.from_dict(json.loads(row[0]))
        return None

    def load_by_task(self, task_id: str) -> Optional[WorkflowState]:
        """通过任务ID加载最新状态"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT state_json FROM workflow_states 
            WHERE task_id = ? 
            ORDER BY updated_at DESC LIMIT 1
        """, (task_id,))
        row = cursor.fetchone()
        conn.close()

        if row:
            return WorkflowState.from_dict(json.loads(row[0]))
        return None

    def list_active(self) -> List[WorkflowState]:
        """列出所有活跃状态"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT state_json FROM workflow_states 
            WHERE status IN ('running', 'paused')
            ORDER BY updated_at DESC
        """)
        rows = cursor.fetchall()
        conn.close()

        return [WorkflowState.from_dict(json.loads(row[0])) for row in rows]

    def delete(self, workflow_id: str):
        """删除状态"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM workflow_states WHERE workflow_id = ?", (workflow_id,))
        conn.commit()
        conn.close()
