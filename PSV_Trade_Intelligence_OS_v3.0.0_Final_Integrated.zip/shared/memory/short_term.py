from .store import MemoryStore
from contracts.memory_contract import MemoryEntry, MemoryType, MemoryScope
from datetime import datetime, timedelta
from typing import Optional, Any

:
    """短期记忆 - 当前任务状态"""

    def __init__(self, store: MemoryStore):
        self.store = store

    def save_task_state(self, task_id: str, key: str, value: Any, summary: str = ""):
        """保存任务状态"""
        entry = MemoryEntry(
            memory_type=MemoryType.SHORT_TERM,
            scope=MemoryScope.TASK,
            task_id=task_id,
            key=key,
            value=value,
            summary=summary,
            expires_at=(datetime.now() + timedelta(hours=24)).isoformat(),
        )
        self.store.save(entry)

    def get_task_state(self, task_id: str, key: str) -> Optional[Any]:
        """获取任务状态"""
        results = self.store.query(
            memory_type=MemoryType.SHORT_TERM,
            task_id=task_id,
            key_pattern=key,
            limit=1
        )
        if results:
            return results[0].value
        return None

    def clear_task_memory(self, task_id: str):
        """清理任务记忆"""
        # 实际实现中需要delete方法
        pass