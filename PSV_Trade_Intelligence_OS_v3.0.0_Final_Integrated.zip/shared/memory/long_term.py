from .store import MemoryStore
from contracts.memory_contract import MemoryEntry, MemoryType, MemoryScope
from datetime import datetime
from typing import List, Dict, Any

:
    """长期记忆 - 历史任务、行业知识、客户数据、执行经验"""

    def __init__(self, store: MemoryStore):
        self.store = store

    def save_knowledge(self, key: str, value: Any, summary: str, 
                       knowledge_type: MemoryType = MemoryType.SEMANTIC,
                       tags: List[str] = None):
        """保存知识"""
        entry = MemoryEntry(
            memory_type=knowledge_type,
            scope=MemoryScope.GLOBAL,
            key=key,
            value=value,
            summary=summary,
            tags=tags or [],
        )
        self.store.save(entry)

    def recall(self, query: str, limit: int = 10) -> List[MemoryEntry]:
        """回忆相关知识"""
        return self.store.query(
            memory_type=MemoryType.LONG_TERM,
            key_pattern=query,
            limit=limit
        ) + self.store.query(
            memory_type=MemoryType.SEMANTIC,
            key_pattern=query,
            limit=limit
        )

    def save_experience(self, task_summary: str, outcome: Dict[str, Any], 
                        lessons: str, tags: List[str] = None):
        """保存执行经验"""
        entry = MemoryEntry(
            memory_type=MemoryType.EPISODIC,
            scope=MemoryScope.GLOBAL,
            key=f"experience_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            value={"task_summary": task_summary, "outcome": outcome},
            summary=lessons,
            tags=tags or ["experience"],
        )
        self.store.save(entry)