"""
Shared Memory - 统一记忆管理
支持短期记忆（任务级）和长期记忆（知识/经验级）
"""
import json
import sqlite3
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
import threading

from contracts.memory_contract import MemoryEntry, MemoryType, MemoryScope

class MemoryStore:
    """统一记忆存储 - 使用SQLite作为后端"""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls, db_path: str = "psv_memory.db"):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self, db_path: str = "psv_memory.db"):
        if self._initialized:
            return
        self.db_path = db_path
        self._init_db()
        self._initialized = True

    def _init_db(self):
        """初始化记忆数据库"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memory_store (
                memory_id TEXT PRIMARY KEY,
                memory_type TEXT NOT NULL,
                scope TEXT NOT NULL,
                task_id TEXT,
                workflow_id TEXT,
                agent_id TEXT,
                key TEXT NOT NULL,
                value TEXT,
                summary TEXT,
                importance REAL DEFAULT 0.5,
                access_count INTEGER DEFAULT 0,
                last_accessed TEXT,
                created_at TEXT NOT NULL,
                expires_at TEXT,
                tags TEXT
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_memory_task ON memory_store(task_id)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_memory_type ON memory_store(memory_type)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_memory_key ON memory_store(key)
        """)
        conn.commit()
        conn.close()

    def save(self, entry: MemoryEntry) -> str:
        """保存记忆"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO memory_store 
            (memory_id, memory_type, scope, task_id, workflow_id, agent_id, key, value, summary,
             importance, access_count, last_accessed, created_at, expires_at, tags)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            entry.memory_id, entry.memory_type.value, entry.scope.value,
            entry.task_id, entry.workflow_id, entry.agent_id,
            entry.key, json.dumps(entry.value, ensure_ascii=False) if entry.value is not None else None,
            entry.summary, entry.importance, entry.access_count,
            entry.last_accessed, entry.created_at, entry.expires_at,
            json.dumps(entry.tags, ensure_ascii=False) if entry.tags else "[]"
        ))
        conn.commit()
        conn.close()
        return entry.memory_id

    def get(self, memory_id: str) -> Optional[MemoryEntry]:
        """获取记忆"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM memory_store WHERE memory_id = ?", (memory_id,))
        row = cursor.fetchone()
        conn.close()

        if row:
            return self._row_to_entry(row)
        return None

    def query(self, 
              memory_type: Optional[MemoryType] = None,
              scope: Optional[MemoryScope] = None,
              task_id: Optional[str] = None,
              key_pattern: Optional[str] = None,
              tags: Optional[List[str]] = None,
              limit: int = 100) -> List[MemoryEntry]:
        """查询记忆"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        conditions = []
        params = []

        if memory_type:
            conditions.append("memory_type = ?")
            params.append(memory_type.value)
        if scope:
            conditions.append("scope = ?")
            params.append(scope.value)
        if task_id:
            conditions.append("task_id = ?")
            params.append(task_id)
        if key_pattern:
            conditions.append("key LIKE ?")
            params.append(f"%{key_pattern}%")
        if tags:
            for tag in tags:
                conditions.append("tags LIKE ?")
                params.append(f"%{tag}%")

        where_clause = " AND ".join(conditions) if conditions else "1=1"

        cursor.execute(f"""
            SELECT * FROM memory_store 
            WHERE {where_clause}
            ORDER BY importance DESC, last_accessed DESC
            LIMIT ?
        """, params + [limit])

        rows = cursor.fetchall()
        conn.close()

        return [self._row_to_entry(row) for row in rows]

    def get_task_memory(self, task_id: str) -> List[MemoryEntry]:
        """获取任务相关的短期记忆"""
        return self.query(
            memory_type=MemoryType.SHORT_TERM,
            task_id=task_id,
            limit=1000
        )

    def get_long_term_knowledge(self, key_pattern: str, limit: int = 20) -> List[MemoryEntry]:
        """获取长期知识"""
        return self.query(
            memory_type=MemoryType.LONG_TERM,
            key_pattern=key_pattern,
            limit=limit
        )

    def delete_expired(self) -> int:
        """删除过期记忆，返回删除数量"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        cursor.execute("""
            DELETE FROM memory_store 
            WHERE expires_at IS NOT NULL AND expires_at < ?
        """, (now,))
        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        return deleted

    def _row_to_entry(self, row) -> MemoryEntry:
        """数据库行转MemoryEntry"""
        return MemoryEntry(
            memory_id=row[0],
            memory_type=MemoryType(row[1]),
            scope=MemoryScope(row[2]),
            task_id=row[3],
            workflow_id=row[4],
            agent_id=row[5],
            key=row[6],
            value=json.loads(row[7]) if row[7] else None,
            summary=row[8] or "",
            importance=row[9] or 0.5,
            access_count=row[10] or 0,
            last_accessed=row[11] or datetime.now().isoformat(),
            created_at=row[12],
            expires_at=row[13],
            tags=json.loads(row[14]) if row[14] else [],
        )