"""PSV Shared Config
"""
from .settings import PSVConfig, get_config, set_config

__all__ = ["PSVConfig", "get_config", "set_config"]
