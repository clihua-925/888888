"""
shared/config/settings.py - 统一配置
整合原始 v45.14 系统配置 + 新架构配置
"""
import os
from pathlib import Path
from typing import Dict, Any
from dataclasses import dataclass, field

PROJECT_ROOT = Path(__file__).resolve().parents[3]

def _load_env():
    """加载 .env 文件"""
    env_path = PROJECT_ROOT / ".env"
    if env_path.exists():
        try:
            with open(env_path, "r", encoding="utf-8-sig") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        os.environ.setdefault(k.strip(), v.strip())
        except Exception:
            pass

_load_env()

@dataclass
class PSVConfig:
    """PSV系统主配置 - 兼容 v45.14 + 新架构"""

    # ===== 原始系统配置 =====
    VERSION: str = "v3.0.0"
    INDUSTRY: str = field(default_factory=lambda: os.getenv("INDUSTRY", "candle"))

    # 节点状态机
    NODE_STATUS: tuple = ("PENDING", "RUNNING", "SUCCESS", "FAILED", "BLOCKED", "SKIPPED", "CANCELLED")
    DEBUG_MODE: bool = field(default_factory=lambda: os.getenv("DEBUG_MODE", "false").lower() == "true")

    # 数字口径语义
    COUNT_SEMANTICS: Dict[str, str] = field(default_factory=lambda: {
        "trade_nodes": "CUSTOMS_NODE_COLLECTION 登记的贸易图谱候选节点数",
        "companies": "GRAPH_EXPANSION 扩张后的实体集合",
        "classified_entities": "RESOURCE_CLASSIFICATION 分类实体数",
        "relationships": "DATABASE_COMMIT 唯一写库出口的正式关系边",
        "leads": "leads 表实体资产",
    })

    # LLM配置（兼容原始系统本地模型 + 新架构多Provider）
    LLM_BASE_URL: str = field(default_factory=lambda: os.getenv("LLM_BASE_URL", "http://192.168.1.26:8081/v1"))
    LLM_MODEL: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "deepseek-r1-distill-llama-70b"))
    LLM_API_KEY: str = field(default_factory=lambda: os.getenv("LLM_API_KEY", "not-needed"))
    LLM_TIMEOUT: int = field(default_factory=lambda: int(os.getenv("LLM_TIMEOUT", "480")))
    LLM_MAX_TOKENS: int = field(default_factory=lambda: int(os.getenv("LLM_MAX_TOKENS", "4096")))

    # AI Judge配置
    AI_JUDGE_ENABLED: bool = field(default_factory=lambda: os.getenv("AI_JUDGE_ENABLED", "true").lower() == "true")
    AI_JUDGE_TIMEOUT: int = field(default_factory=lambda: int(os.getenv("AI_JUDGE_TIMEOUT", "900")))
    AI_JUDGE_MAX_TOKENS: int = field(default_factory=lambda: int(os.getenv("AI_JUDGE_MAX_TOKENS", "1800")))
    AI_JUDGE_BATCH_SIZE: int = field(default_factory=lambda: int(os.getenv("AI_JUDGE_BATCH_SIZE", "1")))
    AI_JUDGE_QUEUE_RETRIES: int = field(default_factory=lambda: int(os.getenv("AI_JUDGE_QUEUE_RETRIES", "2")))

    # 数据库
    DATABASE_PATH: str = field(default_factory=lambda: str(Path(os.getenv("DATABASE_PATH", str(PROJECT_ROOT / "data" / "psv.db"))).expanduser().resolve()))
    DATA_ROOT: str = field(default_factory=lambda: str(Path(os.getenv("DATABASE_PATH", str(PROJECT_ROOT / "data" / "psv.db"))).parent))
    IMPORT_DIR: str = field(default_factory=lambda: str(PROJECT_ROOT / "data" / "imports"))
    CUSTOMS_DIR: str = field(default_factory=lambda: str(PROJECT_ROOT / "data" / "customs"))

    # WebUI
    WEB_HOST: str = field(default_factory=lambda: os.getenv("WEB_HOST", "0.0.0.0"))
    WEB_PORT: int = field(default_factory=lambda: int(os.getenv("WEB_PORT", "8090")))

    # 采集配置
    SOURCE_PER_LIMIT: int = field(default_factory=lambda: int(os.getenv("SOURCE_PER_LIMIT", "30")))
    AGGREGATE_MIN_RESULTS: int = field(default_factory=lambda: int(os.getenv("AGGREGATE_MIN_RESULTS", "25")))
    PROFILE_TOP_N: int = field(default_factory=lambda: int(os.getenv("PROFILE_TOP_N", "10")))
    ANALYSIS_TOP_N: int = field(default_factory=lambda: int(os.getenv("ANALYSIS_TOP_N", "10")))
    LETTER_TOP_N: int = field(default_factory=lambda: int(os.getenv("LETTER_TOP_N", "5")))

    # ImportYeti
    IMPORTYETI_ENABLED: bool = field(default_factory=lambda: os.getenv("IMPORTYETI_ENABLED", "false").lower() == "true")
    IMPORTYETI_SEARCH_URL: str = field(default_factory=lambda: os.getenv("IMPORTYETI_SEARCH_URL", "https://www.importyeti.com/api/search"))
    IMPORTYETI_DAILY_QUOTA: int = field(default_factory=lambda: int(os.getenv("IMPORTYETI_DAILY_QUOTA", "25")))
    IMPORTYETI_QUOTA_RESERVE: int = field(default_factory=lambda: int(os.getenv("IMPORTYETI_QUOTA_RESERVE", "5")))
    IMPORTYETI_MAX_PAGES: int = field(default_factory=lambda: int(os.getenv("IMPORTYETI_MAX_PAGES", "1")))

    # Bing
    BING_CN_ENABLED: bool = field(default_factory=lambda: os.getenv("BING_CN_ENABLED", "false").lower() == "true")

    # HS编码
    HS_FINDER_ENABLED: bool = field(default_factory=lambda: os.getenv("HS_FINDER_ENABLED", "true").lower() == "true")
    HS_CODES: str = field(default_factory=lambda: os.getenv("HS_CODES", "3406"))

    # 联系人
    CONTACT_ENABLED: bool = field(default_factory=lambda: os.getenv("CONTACT_ENABLED", "true").lower() == "true")
    CONTACT_TOP_N: int = field(default_factory=lambda: int(os.getenv("CONTACT_TOP_N", "10")))
    CONTACT_HARD_STD: bool = field(default_factory=lambda: os.getenv("CONTACT_HARD_STD", "true").lower() == "true")
    CONTACT_MODE: str = field(default_factory=lambda: os.getenv("CONTACT_MODE", "webai_first"))

    # 审计
    AUDIT_ENABLED: bool = field(default_factory=lambda: os.getenv("AUDIT_ENABLED", "true").lower() == "true")
    AUDIT_AI_MODE: str = field(default_factory=lambda: os.getenv("AUDIT_AI_MODE", "always"))
    AUDIT_AI_PER_RUN: int = field(default_factory=lambda: int(os.getenv("AUDIT_AI_PER_RUN", "30")))

    # 邮件
    MAIL_PROVIDER: str = field(default_factory=lambda: os.getenv("MAIL_PROVIDER", "outlook"))
    SMTP_HOST: str = field(default_factory=lambda: os.getenv("SMTP_HOST", "smtp-mail.outlook.com"))
    SMTP_PORT: int = field(default_factory=lambda: int(os.getenv("SMTP_PORT", "587")))
    SMTP_USER: str = field(default_factory=lambda: os.getenv("SMTP_USER", ""))
    SMTP_PASS: str = field(default_factory=lambda: os.getenv("SMTP_PASS", ""))
    SMTP_FROM: str = field(default_factory=lambda: os.getenv("SMTP_FROM", ""))

    # 网页AI (CDP浏览器)
    WEBAI_ENABLED: bool = field(default_factory=lambda: os.getenv("WEBAI_ENABLED", "true").lower() == "true")
    WEBAI_ENGINE: str = field(default_factory=lambda: os.getenv("WEBAI_ENGINE", "deepseek"))
    WEBAI_DAILY_MAX: int = field(default_factory=lambda: int(os.getenv("WEBAI_DAILY_MAX", "200")))
    WEBAI_MIN_INTERVAL: int = field(default_factory=lambda: int(os.getenv("WEBAI_MIN_INTERVAL", "15")))
    WEBAI_TIMEOUT: int = field(default_factory=lambda: int(os.getenv("WEBAI_TIMEOUT", "150")))
    WEBAI_PER_RUN: int = field(default_factory=lambda: int(os.getenv("WEBAI_PER_RUN", "50")))

    # CDP浏览器
    IY_WEB_CDP_ENABLED: bool = field(default_factory=lambda: os.getenv("IY_WEB_CDP_ENABLED", "false").lower() == "true")
    IY_WEB_CDP_URL: str = field(default_factory=lambda: os.getenv("IY_WEB_CDP_URL", "http://127.0.0.1:9222"))

    # AI Provider Chain
    AI_PROVIDER_CHAIN: str = field(default_factory=lambda: os.getenv("AI_PROVIDER_CHAIN", ""))
    AI_PRIMARY: str = field(default_factory=lambda: os.getenv("AI_PRIMARY", "local"))

    # Outlook自动发送
    OUTLOOK_AUTO_SEND: bool = field(default_factory=lambda: os.getenv("OUTLOOK_AUTO_SEND", "true").lower() == "true")
    OUTLOOK_CDP_URL: str = field(default_factory=lambda: os.getenv("OUTLOOK_CDP_URL", os.getenv("IY_WEB_CDP_URL", "http://127.0.0.1:9222")))

    # 署名
    SENDER_NAME: str = field(default_factory=lambda: os.getenv("SENDER_NAME", ""))
    SENDER_NAME_EN: str = field(default_factory=lambda: os.getenv("SENDER_NAME_EN", ""))
    SENDER_PHONE: str = field(default_factory=lambda: os.getenv("SENDER_PHONE", ""))
    SENDER_EMAIL: str = field(default_factory=lambda: os.getenv("SENDER_EMAIL", ""))

    # ===== 新架构配置 =====
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "openai"))
    llm_model_new: str = field(default_factory=lambda: os.getenv("LLM_MODEL_NEW", "gpt-4o"))
    llm_api_key_new: str = field(default_factory=lambda: os.getenv("LLM_API_KEY_NEW", ""))
    llm_base_url_new: str = field(default_factory=lambda: os.getenv("LLM_BASE_URL_NEW", ""))
    llm_temperature: float = field(default_factory=lambda: float(os.getenv("LLM_TEMPERATURE", "0.3")))
    llm_max_tokens_new: int = field(default_factory=lambda: int(os.getenv("LLM_MAX_TOKENS_NEW", "4096")))

    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///psv_trade_os.db"))
    checkpoint_dir: str = field(default_factory=lambda: os.getenv("CHECKPOINT_DIR", "./checkpoints"))
    max_retries: int = field(default_factory=lambda: int(os.getenv("MAX_RETRIES", "3")))
    retry_delay: int = field(default_factory=lambda: int(os.getenv("RETRY_DELAY", "2")))

    search_engine: str = field(default_factory=lambda: os.getenv("SEARCH_ENGINE", "duckduckgo"))
    search_api_key: str = field(default_factory=lambda: os.getenv("SEARCH_API_KEY", ""))
    scraper_timeout: int = field(default_factory=lambda: int(os.getenv("SCRAPER_TIMEOUT", "30")))
    max_concurrent_scrapes: int = field(default_factory=lambda: int(os.getenv("MAX_CONCURRENT_SCRAPES", "5")))

    audit_enabled: bool = field(default_factory=lambda: os.getenv("AUDIT_ENABLED_NEW", "true").lower() == "true")
    audit_retention_days: int = field(default_factory=lambda: int(os.getenv("AUDIT_RETENTION_DAYS", "365")))

    cache_type: str = field(default_factory=lambda: os.getenv("CACHE_TYPE", "memory"))
    cache_ttl: int = field(default_factory=lambda: int(os.getenv("CACHE_TTL", "3600")))

    default_market: str = field(default_factory=lambda: os.getenv("DEFAULT_MARKET", "US"))
    default_product: str = field(default_factory=lambda: os.getenv("DEFAULT_PRODUCT", ""))
    scoring_threshold: float = field(default_factory=lambda: float(os.getenv("SCORING_THRESHOLD", "60.0")))

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}

# 全局配置实例
_config: PSVConfig = None

def get_config() -> PSVConfig:
    """获取全局配置（单例）"""
    global _config
    if _config is None:
        _config = PSVConfig()
    return _config

def set_config(config: PSVConfig):
    """设置全局配置"""
    global _config
    _config = config
