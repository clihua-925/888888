"""
Shared Knowledge - 行业知识库
保存：行业知识、市场知识、产品知识、企业知识
"""
import json
import sqlite3
from typing import List, Dict, Any, Optional
from datetime import datetime

from contracts.memory_contract import MemoryEntry, MemoryType
from shared.memory import MemoryStore

class KnowledgeBase:
    """知识库 - 行业/市场/产品/企业知识统一管理"""

    def __init__(self, store: MemoryStore):
        self.store = store

    def add_industry_knowledge(self, industry: str, knowledge: Dict[str, Any], source: str = ""):
        """添加行业知识"""
        entry = MemoryEntry(
            memory_type=MemoryType.SEMANTIC,
            key=f"industry:{industry}",
            value=knowledge,
            summary=f"Industry knowledge for {industry}",
            tags=["industry", industry, source],
        )
        self.store.save(entry)

    def add_market_knowledge(self, market: str, product: str, 
                             knowledge: Dict[str, Any], source: str = ""):
        """添加市场知识"""
        entry = MemoryEntry(
            memory_type=MemoryType.SEMANTIC,
            key=f"market:{market}:{product}",
            value=knowledge,
            summary=f"Market knowledge for {product} in {market}",
            tags=["market", market, product, source],
        )
        self.store.save(entry)

    def add_product_knowledge(self, product: str, 
                              knowledge: Dict[str, Any], source: str = ""):
        """添加产品知识"""
        entry = MemoryEntry(
            memory_type=MemoryType.SEMANTIC,
            key=f"product:{product}",
            value=knowledge,
            summary=f"Product knowledge for {product}",
            tags=["product", product, source],
        )
        self.store.save(entry)

    def add_company_knowledge(self, company_name: str, 
                              knowledge: Dict[str, Any], source: str = ""):
        """添加企业知识"""
        entry = MemoryEntry(
            memory_type=MemoryType.SEMANTIC,
            key=f"company:{company_name}",
            value=knowledge,
            summary=f"Company knowledge for {company_name}",
            tags=["company", company_name, source],
        )
        self.store.save(entry)

    def query(self, query_type: str, key: str, limit: int = 10) -> List[MemoryEntry]:
        """查询知识"""
        pattern = f"{query_type}:{key}"
        return self.store.query(
            memory_type=MemoryType.SEMANTIC,
            key_pattern=pattern,
            limit=limit
        )

    def get_industry_insights(self, industry: str) -> Optional[Dict[str, Any]]:
        """获取行业洞察"""
        results = self.query("industry", industry, limit=1)
        if results:
            return results[0].value
        return None

    def get_market_insights(self, market: str, product: str) -> Optional[Dict[str, Any]]:
        """获取市场洞察"""
        results = self.store.query(
            memory_type=MemoryType.SEMANTIC,
            key_pattern=f"market:{market}:{product}",
            limit=1
        )
        if results:
            return results[0].value
        return None
