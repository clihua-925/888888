"""PSV Shared Knowledge
"""
from .knowledge_base import KnowledgeBase

__all__ = ["KnowledgeBase"]
