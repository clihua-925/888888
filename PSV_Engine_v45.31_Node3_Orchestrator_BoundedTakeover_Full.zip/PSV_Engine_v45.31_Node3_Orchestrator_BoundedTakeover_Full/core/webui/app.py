# -*- coding: utf-8 -*-
"""PSV Engine Web UI API (FULL)

三个页面职责彻底分离：
- /intelligence/*  → 客户情报中心
- /graph/*         → 贸易图谱
- /business/*      → 业务中心

禁止新旧路由并存。
所有按钮必须有真实后台功能。
"""
import json, time
from pathlib import Path
from flask import Flask, request, jsonify
from core.memory.db import DB
from core.system import PSVSystem
from core.config import markets as market_config
from core.config import industry as industry_config

app = Flask(__name__)
system = PSVSystem()


# ========== UI 页面（单一 Flask 入口） ==========
STATIC_DIR = Path(__file__).resolve().parent / 'static'

@app.route('/', methods=['GET'])
def index_page():
    return app.send_static_file('intelligence.html')

@app.route('/intelligence', methods=['GET'])
def intelligence_page():
    return app.send_static_file('intelligence.html')

@app.route('/network', methods=['GET'])
def network_page():
    return app.send_static_file('network.html')

@app.route('/enrichment', methods=['GET'])
def enrichment_page():
    return app.send_static_file('enrichment.html')

@app.route('/graph', methods=['GET'])
def graph_page():
    return app.send_static_file('graph.html')

@app.route('/business', methods=['GET'])
def business_page():
    return app.send_static_file('business.html')

@app.route('/collection', methods=['GET'])
def collection_page():
    return app.send_static_file('collection.html')

@app.route('/settings', methods=['GET'])
def settings_page():
    return app.send_static_file('settings.html')


# ========== 配置中心 API（恢复原设置入口） ==========
@app.route('/api/config/markets', methods=['GET'])
def get_markets():
    return jsonify({'ok': True, 'markets': market_config.load_markets()})

@app.route('/api/config/markets', methods=['POST'])
def save_market():
    data = request.get_json() or {}
    code = str(data.get('code') or '').strip().upper()
    name = str(data.get('name') or '').strip()
    if not code or not name:
        return jsonify({'ok': False, 'error': 'code and name are required'}), 400
    if not market_config.save_market({'code': code, 'name': name}):
        return jsonify({'ok': False, 'error': 'invalid market'}), 400
    return jsonify({'ok': True, 'markets': market_config.load_markets()})

@app.route('/api/config/markets/<code>', methods=['DELETE'])
def remove_market(code):
    code = str(code or '').strip().upper()
    markets = market_config.load_markets()
    if len(markets) <= 1 and any(str(m.get('code','')).upper() == code for m in markets):
        return jsonify({'ok': False, 'error': '至少保留一个市场区域'}), 400
    market_config.delete_market(code)
    return jsonify({'ok': True, 'markets': market_config.load_markets()})

@app.route('/api/config/industries', methods=['GET'])
def get_industries():
    return jsonify({'ok': True, 'industries': industry_config.list_industries()})

@app.route('/api/config/industries', methods=['POST'])
def save_industry():
    data = request.get_json() or {}
    if not industry_config.save_industry(data):
        return jsonify({'ok': False, 'error': 'invalid industry configuration'}), 400
    return jsonify({'ok': True, 'industries': industry_config.list_industries()})

# ========== 一次性定时任务 API ==========
@app.route('/api/scheduler/tasks', methods=['GET'])
def list_scheduler_tasks():
    return jsonify({'ok': True, 'tasks': system.db.list_scheduled_tasks()})

@app.route('/api/scheduler/tasks', methods=['POST'])
def create_scheduler_task():
    data=request.get_json() or {}
    from datetime import datetime
    name=str(data.get('task_name') or data.get('request') or '定时第一采集链任务').strip()
    request_text=str(data.get('request') or '').strip()
    market=str(data.get('market') or 'USA').strip()
    industry=str(data.get('industry') or 'candle').strip().lower()
    quantity=max(1,min(300,int(data.get('quantity') or 20)))
    raw=str(data.get('run_at') or '').strip()
    if not raw: return jsonify({'ok':False,'error':'run_at is required'}),400
    try:
        dt=datetime.fromisoformat(raw.replace('Z','+00:00'))
        run_at=dt.timestamp()
    except Exception:
        return jsonify({'ok':False,'error':'run_at must be ISO local datetime, e.g. 2026-09-03T09:30'}),400
    if run_at <= time.time(): return jsonify({'ok':False,'error':'定时开始时间必须晚于当前时间'}),400
    allowed={str(x.get('key')) for x in industry_config.list_industries()}
    if industry not in allowed: return jsonify({'ok':False,'error':f'未知产品品类：{industry}'}),400
    item=system.scheduler.add(name,request_text,market,industry,quantity,run_at)
    return jsonify({'ok':True,'task':item})

@app.route('/api/scheduler/tasks/<schedule_id>', methods=['DELETE'])
def delete_scheduler_task(schedule_id):
    if not system.db.delete_scheduled_task(schedule_id):
        return jsonify({'ok':False,'error':'只能删除等待中的一次性定时任务，或任务不存在'}),404
    return jsonify({'ok':True,'tasks':system.db.list_scheduled_tasks()})

@app.route('/api/config/industries/<key>', methods=['DELETE'])
def remove_industry(key):
    industries = industry_config.list_industries()
    if len(industries) <= 1 and any(str(x.get('key')) == str(key) for x in industries):
        return jsonify({'ok': False, 'error': '至少保留一个品类'}), 400
    if not industry_config.delete_industry(key):
        return jsonify({'ok': False, 'error': 'industry not found'}), 404
    return jsonify({'ok': True, 'industries': industry_config.list_industries()})

# ========== 健康检查 ==========
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'version': settings.VERSION, 'timestamp': time.time()})


# ========== 第一采集链 API（冻结链） ==========
@app.route('/api/collection/run', methods=['POST'])
def run_collection():
    """Start the frozen nine-node collection chain as an independent background task.

    The browser is only an observer: navigating to another page, refreshing, or closing
    the collection page must not cancel the server-side worker.
    """
    data = request.get_json() or {}
    task_id = data.get('task_id') or ('col-' + __import__('uuid').uuid4().hex[:8])
    req = data.get('request') or ''
    market = data.get('market', 'USA')
    industry = data.get('industry', 'candle')
    quantity = int(data.get('quantity', 20) or 20)
    auto_expand = bool(data.get('auto_expand', False))
    category_id = {'birthday candles':'candle','candle':'candle','enamel pot':'enamel_pot','felt':'felt'}.get(str(industry).lower(), str(industry))

    existing = system.db.get_task(task_id)
    if existing and existing.get('run_status') in ('pending','running'):
        return jsonify({'ok': True, 'task_id': task_id, 'status': existing.get('run_status'), 'accepted': False, 'already_running': True})

    system.db.create_task(task_id, req or f'第一采集链：{industry} / {market}', 'collection', category_id, None)
    system.db.update_task(task_id, run_status='running', current_stage='MISSION_DIRECTOR', current_node='MISSION_DIRECTOR', progress_pct=0)
    system.db.save_task_log(task_id, 'webui', '第一采集链已进入独立后台任务；页面切换不会停止任务。')

    def worker():
        try:
            system.run_collection(req, market=market, industry=industry, quantity=quantity, task_id=task_id, auto_expand=auto_expand)
        except Exception as e:
            system.db.update_task(task_id, run_status='failed', failure_reason=str(e)[:500], completed_at=__import__('time').time())
            system.db.save_task_log(task_id, 'collection_worker', f'第一采集链后台异常：{str(e)[:500]}')

    system._executor.submit(worker)
    return jsonify({'ok': True, 'task_id': task_id, 'status': 'running', 'accepted': True})

@app.route('/api/collection/tasks', methods=['GET'])
def collection_tasks():
    limit = min(int(request.args.get('limit', 20) or 20), 100)
    tasks = system.db.list_tasks(task_type='collection')[:limit]
    return jsonify({'ok': True, 'tasks': tasks})

@app.route('/api/collection/tasks/<task_id>', methods=['GET'])
def collection_task(task_id):
    task=system.db.get_task(task_id)
    if not task: return jsonify({'ok':False,'error':'Task not found'}),404
    resume = task.get('resume_state')
    if isinstance(resume, str):
        try: resume = json.loads(resume)
        except Exception: resume = {}
    return jsonify({'ok':True,'task':task,'state':resume or {},'logs':system.db.get_task_logs(task_id, limit=120)})



# ========== 情报中心 API ==========
@app.route('/api/intelligence/<norm>', methods=['GET'])
def get_intelligence(norm):
    """获取完整情报档案"""
    result = system.intelligence_center.get_intelligence(norm)
    return jsonify(result)

@app.route('/api/intelligence/<norm>/enrich', methods=['POST'])
def enrich_intelligence(norm):
    """触发独立信息补全队列；HTTP请求不等待瀑布/网页专家。"""
    data = request.get_json() or {}
    category_id = data.get('category_id')
    return jsonify(system.queue_enrichment([norm], category_id=category_id, limit=1))

@app.route('/api/intelligence/enrich-batch', methods=['POST'])
def enrich_intelligence_batch():
    data = request.get_json() or {}
    norms = data.get('norms') or []
    if not isinstance(norms, list) or not norms:
        return jsonify({'ok': False, 'error': 'norms must be a non-empty list'}), 400
    category_id = data.get('category_id')
    limit=min(int(data.get('limit',100) or 100),500)
    return jsonify(system.queue_enrichment(norms, category_id=category_id, limit=limit))

@app.route('/api/intelligence/enrichment/queue', methods=['GET'])
def enrichment_queue_status():
    category_id=request.args.get('category_id') or None
    limit=min(int(request.args.get('limit',100) or 100),500)
    return jsonify({'ok':True,'queue':system.enrichment_queue(category_id=category_id,limit=limit)})

@app.route('/api/intelligence/enrichment/start', methods=['POST'])
def enrichment_queue_start():
    data=request.get_json() or {}
    return jsonify(system.start_enrichment_worker(category_id=data.get('category_id') or None))

@app.route('/api/intelligence/enrichment/queue', methods=['POST'])
def enrichment_queue_add():
    data=request.get_json() or {}
    norms=data.get('norms')
    if norms is not None and not isinstance(norms,list):
        return jsonify({'ok':False,'error':'norms must be a list'}),400
    category_id=data.get('category_id') or None
    limit=min(int(data.get('limit',100) or 100),500)
    return jsonify(system.queue_enrichment(norms=norms,category_id=category_id,limit=limit))

@app.route('/api/intelligence/<norm>/validate', methods=['POST'])
def validate_intelligence(norm):
    """AI 验证中心"""
    result = system.intelligence_center.ai_validate(norm)
    return jsonify(result)

@app.route('/api/intelligence/<norm>/gaps', methods=['GET'])
def get_gaps(norm):
    """获取信息缺口和下一步建议"""
    intel = system.intelligence_center.get_intelligence(norm)
    if not intel['ok']:
        return jsonify(intel)
    return jsonify({
        'ok': True,
        'gaps': intel['data'].get('gaps', []),
        'next_steps': intel['data'].get('next_steps', []),
    })


# ========== 贸易图谱 API ==========
@app.route('/api/graph', methods=['GET'])
def get_graph():
    """获取贸易图谱"""
    center = request.args.get('center')
    category_id = request.args.get('category_id')
    depth = int(request.args.get('depth', 1))
    result = system.trade_graph.get_graph(center_norm=center, category_id=category_id, depth=depth)
    return jsonify(result)

@app.route('/api/graph/node/<norm>', methods=['GET'])
def get_node_detail(norm):
    """节点详情"""
    result = system.trade_graph.get_node_detail(norm)
    return jsonify(result)

@app.route('/api/graph/edge/<edge_id>', methods=['GET'])
def get_edge_detail(edge_id):
    """边详情"""
    result = system.trade_graph.get_edge_detail(edge_id)
    return jsonify(result)

@app.route('/api/graph/expansion-path/<norm>', methods=['GET'])
def get_expansion_path(norm):
    """节点扩张路径"""
    task_id = request.args.get('task_id')
    result = system.trade_graph.get_expansion_path(norm, task_id=task_id)
    return jsonify(result)


# ========== 网络扩张 API ==========
@app.route('/api/network/expand/batch', methods=['POST'])
def expand_network_batch():
    """第二核心链：客户全集→供应商全集→客户全集，两轮批量去重扩张。"""
    data=request.get_json() or {}
    category_id=data.get('category_id')
    seed_norms=data.get('seed_norms')
    if seed_norms is not None and not isinstance(seed_norms,list):
        return jsonify({'ok':False,'error':'seed_norms must be a list'}),400
    try:
        result=system.expand_network_batch(
            seed_norms=seed_norms, category_id=category_id,
            buyers_per=data.get('buyers_per'), suppliers_per=data.get('suppliers_per'),
            customers_per=data.get('customers_per'), max_new=data.get('max_new'),
            root_domain=data.get('root_domain')
        )
        return jsonify({'ok':True,'result':result})
    except Exception as e:
        return jsonify({'ok':False,'error':str(e)}),500

@app.route('/api/network/expand/batch/<task_id>/status', methods=['GET'])
def get_batch_expansion_status(task_id):
    task=system.get_task_status(task_id)
    if not task: return jsonify({'ok':False,'error':'Task not found'}),404
    resume=task.get('resume_state')
    if isinstance(resume,str):
        try: resume=json.loads(resume)
        except Exception: resume={}
    return jsonify({'ok':True,'task':task,'state':resume or {},'logs':system.db.get_task_logs(task_id,limit=100)})



# ========== 业务中心 API ==========
@app.route('/api/business/customers', methods=['GET'])
def business_customers():
    category_id=request.args.get('category_id')
    q=request.args.get('q')
    limit=min(int(request.args.get('limit',500) or 500),1000)
    customers=system.db.list_business_customers(category_id=category_id,q=q,limit=limit)
    return jsonify({'ok':True,'customers':customers})

@app.route('/api/business/qualify', methods=['POST'])
def qualify_lead():
    """检查开发资格"""
    data = request.get_json() or {}
    norm = data.get('norm')
    if not norm:
        return jsonify({'ok': False, 'error': 'norm is required'}), 400
    result = system.execution_center.qualify_for_development(norm)
    return jsonify({'ok': True, 'result': result})

@app.route('/api/business/queue', methods=['GET'])
def business_queue_status():
    category_id=request.args.get('category_id') or None
    limit=min(int(request.args.get('limit',200) or 200),1000)
    return jsonify({'ok':True,'queue':system.business_queue(category_id=category_id,limit=limit)})

@app.route('/api/business/queue', methods=['POST'])
def business_queue_add():
    data=request.get_json() or {}
    norms=data.get('norms')
    if norms is not None and not isinstance(norms,list): return jsonify({'ok':False,'error':'norms must be a list'}),400
    norm=data.get('norm')
    if norm and norms is None: norms=[norm]
    return jsonify(system.queue_business(norms=norms,category_id=data.get('category_id'),mode=data.get('mode') or 'draft',our_product=data.get('our_product'),our_company=data.get('our_company'),limit=min(int(data.get('limit',100) or 100),500)))

@app.route('/api/business/queue/start', methods=['POST'])
def business_queue_start():
    data=request.get_json() or {}
    return jsonify(system.start_business_worker(category_id=data.get('category_id') or None))

@app.route('/api/business/execute', methods=['POST'])
def execute_business_flow():
    """业务中心完整执行链：资料审核→详细画像→补全→资格→开发信→草稿/发送。"""
    data = request.get_json() or {}
    norm = str(data.get('norm') or data.get('lead') or '').strip()
    if not norm:
        return jsonify({'ok': False, 'error': 'norm is required'}), 400
    category_id = data.get('category_id')
    mode = data.get('mode') or 'draft'
    try:
        result = system.execute_business_flow(
            norm, category_id=category_id, mode=mode,
            our_product=data.get('our_product'), our_company=data.get('our_company')
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'ok': False, 'stage': 'api_exception', 'error': str(e)[:500]}), 500

@app.route('/api/development/start', methods=['POST'])
def start_development():
    data = request.get_json() or {}
    norm = data.get('norm') or data.get('lead')
    if not norm:
        return jsonify({'ok': False, 'error': 'norm is required'}), 400
    result = system.start_development(norm, our_product=data.get('our_product'), our_company=data.get('our_company'))
    return jsonify(result)

@app.route('/api/business/development-letter', methods=['POST'])
def generate_letter():
    """生成开发信"""
    data = request.get_json() or {}
    norm = data.get('norm')
    our_product = data.get('our_product')
    our_company = data.get('our_company')
    if not norm:
        return jsonify({'ok': False, 'error': 'norm is required'}), 400
    result = system.execution_center.generate_development_letter(
        norm, our_product=our_product, our_company=our_company
    )
    return jsonify(result)

@app.route('/api/business/send', methods=['POST'])
def send_email():
    """执行发送"""
    data = request.get_json() or {}
    record_id = data.get('record_id')
    if not record_id:
        return jsonify({'ok': False, 'error': 'record_id is required'}), 400
    result = system.execution_center.open_outlook_and_send(record_id)
    return jsonify(result)

@app.route('/api/business/records', methods=['GET'])
def list_records():
    """获取执行记录"""
    entity_id = request.args.get('entity_id')
    status = request.args.get('status')
    records = system.db.get_execution_records(entity_id=entity_id, status=status)
    return jsonify({'ok': True, 'records': records})


# ========== 资源池 API ==========
@app.route('/api/pools/customers', methods=['GET'])
def list_customer_pool():
    category_id = request.args.get('category_id')
    pool = system.db.list_customer_pool(category_id=category_id)
    return jsonify({'ok': True, 'pool': pool})

@app.route('/api/pools/suppliers', methods=['GET'])
def list_supplier_pool():
    category_id = request.args.get('category_id')
    pool = system.db.list_supplier_pool(category_id=category_id)
    return jsonify({'ok': True, 'pool': pool})


# ========== 任务面板 API ==========
@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    status = request.args.get('status')
    task_type = request.args.get('type')
    category_id = request.args.get('category_id')
    tasks = system.db.list_tasks(status=status, task_type=task_type, category_id=category_id)
    return jsonify({'ok': True, 'tasks': tasks})

@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    task = system.get_task_status(task_id)
    if not task:
        return jsonify({'ok': False, 'error': 'Task not found'}), 404
    logs = system.db.get_task_logs(task_id)
    return jsonify({'ok': True, 'task': task, 'logs': logs})

@app.route('/api/tasks/<task_id>/pause', methods=['POST'])
def pause_task(task_id):
    system.pause_task(task_id)
    return jsonify({'ok': True})

@app.route('/api/tasks/<task_id>/resume', methods=['POST'])
def resume_task(task_id):
    system.resume_task(task_id)
    return jsonify({'ok': True})


# ========== 信息增益 API ==========
@app.route('/api/info-gain/<task_id>', methods=['GET'])
def get_info_gain(task_id):
    curve = system.db.get_info_gain_curve(task_id)
    return jsonify({'ok': True, 'curve': curve})

@app.route('/api/info-gain/<task_id>/latest', methods=['GET'])
def get_latest_info_gain(task_id):
    n = int(request.args.get('n', 3))
    latest = system.db.get_latest_info_gain(task_id, n_rounds=n)
    return jsonify({'ok': True, 'latest': latest})


# ========== 启动 ==========
def run(host=None, port=None):
    app.run(host=host or '0.0.0.0', port=port or 8090, debug=False)

if __name__ == '__main__':
    run()
