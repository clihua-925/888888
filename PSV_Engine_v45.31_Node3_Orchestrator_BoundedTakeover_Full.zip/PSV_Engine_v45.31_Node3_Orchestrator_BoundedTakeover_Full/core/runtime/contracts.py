# -*- coding: utf-8 -*-
"""current Node Contract Registry：每个正式节点的唯一契约定义 + 真实校验。

契约八要素：INPUT / RESPONSIBILITY / OUTPUT / SUCCESS / FAILURE / BLOCKING /
ALLOWED SIDE EFFECTS / DATABASE WRITE AUTHORITY。

校验原则：
- OUTPUT 校验是硬校验：必需字段缺失/空/类型错误 ⇒ 节点判定失败（accepted=false），
  不允许"空字段冒充成功"，不允许为了 accepted=true 降低标准。
- INPUT 校验是软校验：上游契约缺失记录为 warnings（单独调试执行时上游为空属正常）。
- 校验只认真实业务数据（列表非空/关键键存在且非空），不认统计数字本身。
"""
from core.runtime import experts

# ---------- 契约要素工具 ----------

def _nonempty_list(x):
    return isinstance(x, list) and len(x) > 0


def _nonempty_dict(x):
    return isinstance(x, dict) and len(x) > 0


# ---------- Node Contract Registry ----------

CONTRACTS = {
    'PRODUCT_DEFINITION': {
        'input': ['market', 'industry'],
        'responsibility': '16 维产品语义矩阵 + 产品域键；不做采集、不做过滤决策',
        'output': {'icp': _nonempty_dict, 'product_profile': _nonempty_dict, 'product_domain': _nonempty_dict},
        'success': 'icp/product_profile/product_domain 三件套齐备且非空',
        'failure': '任一产物缺失或为空',
        'blocking': '无（产物为纯内存对象）',
        'side_effects': 'none',
        'db_write': 'none',
        'data_semantics': 'product_domain.key=产品域唯一键（蜡烛/珐琅锅/毛毡严格隔离）；query_plan=16维矩阵产出的动态查询计划（含 qtype/role/pri）',
    },
    'TRADE_STRATEGY': {
        'input': ['icp', 'product_domain'],
        'responsibility': '12 要素贸易定位策略（含 expansion_policy/evidence_policy/动态查询计划）',
        'output': {'strategy': _nonempty_dict},
        'success': 'strategy 含 12 要素且 hs_strategy.policy=strong_signal_not_hard_filter',
        'failure': 'strategy 缺失或要素不全',
        'blocking': '无',
        'side_effects': 'none',
        'db_write': 'none',
        'data_semantics': 'strategy.expansion_policy.max_depth=纯安全上限（非质量终止条件）；precision_recall_split=精度/召回查询配比计量',
    },
    'CUSTOMS_NODE_COLLECTION': {
        'input': ['strategy', 'icp'],
        'responsibility': '高召回采集原始贸易数据 + 直接贸易关系观察 + 企业身份锚点解析 + 产品边界轻过滤；明确无关才隔离，不做目标客户/最终角色判断',
        'output': {'companies': _nonempty_list, 'trade_nodes': _nonempty_list},
        'success': '至少产生 1 个身份有效候选；trade_nodes 候选池非空',
        'failure': '零候选（采集链失效）',
        'blocking': '零候选时编排层进入恢复机制；有节点但无直接观察时标记WARN，由MISSION_DIRECTOR决定回采/继续，不由Node 3自行选路',
        'side_effects': 'trade_nodes 候选池登记、evidence_events 候选审计、query_stats 计量',
        'db_write': 'candidate-pool-only（禁止写 relationships/leads）',
        'data_semantics': 'Node 3 输出 TRADE_NODE_DISCOVERY；ImportYeti 仅接受精确 /company/ 或 /supplier/ 作为已解析实体锚点，/location/... 仅作上下文；无实体主页但有贸易事实的关系行进入 UNRESOLVED_TRADE_NODE，不伪造成公司；只追踪直接关系层，递归网络扩张归 GRAPH_EXPANSION；每条直接关系形成可回放 trade_observation；主源只有节点没有直接关系时，可执行一次有界公共贸易证据回退（当前 ImportKey），无精确实体锚点的回退关系保持 UNRESOLVED；Node 3 不判断 target fit/customer role。Node 3 WARN 后由 MISSION_DIRECTOR 决定重采/换策略/继续，节点不选路。filter_result∈{RELEVANT,UNCERTAIN,IRRELEVANT}，仅明确边界才IRRELEVANT。',
    },
    'TRADE_EDGE_BUILD': {
        'input': ['trade_graph'],
        'responsibility': '构建候选贸易事实：fragment分组、共享数据复用、字段标准化、实体/方向预解析；不要求一次性完美恢复',
        'output': {'trade_edges': lambda v: isinstance(v, list), 'candidate_trade_facts': lambda v: isinstance(v, list), 'edges_built': lambda v: isinstance(v, int)},
        'success': 'trade_edges 为真实内存标准边列表（每条含 evidence_level/标准字段）；空列表仅在图谱无边时合法',
        'failure': '字段缺失或类型错误（有图谱边但标准边为空属数据事实，由 EVIDENCE_VERIFY 核验证据面）',
        'blocking': '无',
        'side_effects': 'trade_nodes 端点候选池登记',
        'db_write': 'candidate-pool-only（relationships 写库唯一出口是 DATABASE_COMMIT）',
        'data_semantics': 'candidate_trade_facts是Node 4单一产物；状态∈{COMPLETE,PARTIAL,AMBIGUOUS,UNRESOLVED,DUPLICATE};grouping按来源/时间/端点/产品等关键字段，限制组合规模；不直接判最终商业角色',
    },
    'EVIDENCE_VERIFY': {
        'input': ['trade_edges'],
        'responsibility': '验证候选贸易事实 + 交叉验证 + 识别关键证据缺口 + 生成结构化补证请求；必要时通过条件边回Node 2/3/4',
        'output': {'evidence_verify': _nonempty_dict, 'verified_trade_facts': lambda v: isinstance(v, list), 'verification_gaps': lambda v: isinstance(v, list), 'evidence_requests': lambda v: isinstance(v, list)},
        'success': 'evidence_verify 含四级计数；全量边完成分级即成功（弱证据=降权保留，绝不判存亡/阻断主链）',
        'failure': 'evidence_verify 产物缺失或为空（未执行分级）',
        'blocking': '无（证据等级只决定 confidence/development_status/resource_priority）',
        'side_effects': '存量 relationships 等级补判（同一判定函数的对账，不是第二套逻辑）',
        'db_write': 'reconcile-only（UPDATE 存量边的等级/置信度，不 INSERT 新边）',
        'data_semantics': '区分同一trade fact字段冲突与同一主体多关系并存；verification_gaps/evidence_requests记录缺失字段、搜索维度、已尝试来源；相同gap fingerprint不重复回环；route由固定规则决定，不由模型决定',
    },
    'ENTITY_RESOLUTION': {
        'input': ['companies'],
        'responsibility': '企业实体标准化/去重/合并 + TARGET_FIT；消费Node 3公开信息/Node 5证据，不自行规划搜索',
        'output': {'company_entities': _nonempty_list, 'entity_resolution': _nonempty_dict, 'expansion_gate': _nonempty_dict},
        'success': '每个输入实体都有唯一 entity_id 与角色；伪实体（国家/城市/地址）不得成为公司实体',
        'failure': '有输入实体但解析结果为空',
        'blocking': '无（UNKNOWN 保留不删）',
        'side_effects': 'none',
        'db_write': 'none',
        'data_semantics': 'company_entities=唯一标准实体；target_fit=TARGET_RELEVANT/NON_TARGET/UNCERTAIN；该字段表示目标客户适配性，不等于最终Customer/Supplier角色；expansion_gate 是 Node 7 的强前置条件，只有 TARGET_RELEVANT 才允许成为扩张种子，UNCERTAIN/缺失均不得绕过条件进入网络扩张',
    },
    'GRAPH_EXPANSION': {
        'input': ['companies', 'strategy', 'expansion_gate'],
        'responsibility': '受控双向价值扩张；Level 1必做、Level 2默认、Level 3条件执行；Expansion Value + budget + information gain + 全局轮数共同收敛',
        'output': {'graph_expansion': _nonempty_dict, 'companies': _nonempty_list},
        'success': 'Target Fit 已完成且实体集合不丢；有扩张时记录每轮信息增益；无目标种子/无可执行入口时允许正常终态；不允许无限递归',
        'failure': '扩张前置 Target Fit 未完成，或扩张结果丢失输入实体（召回率破坏）',
        'blocking': '无（零新增/frontier耗尽=正常终态，不是失败）',
        'side_effects': 'suppliers 池收割标记、supplier_profiles 画像、trade_nodes 候选池',
        'db_write': 'candidate-pool-only（禁止写 relationships）',
        'data_semantics': 'depths[]记录new_entities/new_target_relevant/new_target_edges/duplicate_rate/information_gain；stopped_by∈{frontier_drained,no_new_entities,low_information_gain,max_depth,round_limit,executor_error,no_target_eligible_seeds,no_expandable_source};只有TARGET_RELEVANT可成为种子，UNCERTAIN/NON_TARGET禁止扩张；新贸易事实/新实体回到4/5/6由Orchestrator路由',
    },
    'RESOURCE_CLASSIFICATION': {
        'input': ['companies'],
        'responsibility': '最终商业角色闸门：综合Verified Trade Facts + Entity + Target Fit，判断 CUSTOMER / SUPPLIER / CUSTOMER_AND_SUPPLIER / NEITHER',
        'output': {'classified_entities': _nonempty_list, 'classification': _nonempty_dict},
        'success': '分类数 ≥ 输入实体数 - 纯贸易节点数；每条含 classification_reason',
        'failure': '有输入但零分类输出',
        'blocking': '无（DISCOVERED/UNKNOWN 不淘汰）',
        'side_effects': 'none',
        'db_write': 'none',
        'data_semantics': 'classified_entities 每条含最终 entity_role×trade_status×development_status×classification_reason；Node 8 才是最终商业角色语义闸门，禁止用有贸易证据规则直接代替最终判断',
    },
    'DATABASE_COMMIT': {
        'input': ['classified_entities'],
        'responsibility': '唯一写库出口：Entity(leads) + Edge(relationships) + Evidence(evidence_events) 三类资产；数量恒等；回读自证',
        'output': {'database_commit': _nonempty_dict, 'commit_verify': _nonempty_dict},
        'success': '数量恒等式成立 + 同库回读 probe_ok',
        'failure': '写入失败非零或回读不可见',
        'blocking': '数量恒等式破坏 / 回读失败',
        'side_effects': 'leads/relationships/evidence_events/trade_nodes 正式写入',
        'db_write': 'SOLE-WRITER（relationships 与 leads 的唯一正式写库出口）',
        'data_semantics': 'database_commit=三类资产写入计数（Entity/Edge/Evidence）；commit_verify=同库回读自证；数量恒等式见 funnel 各 stage 的 in/out/drop_reasons',
    },
}

STRATEGY_12 = ('product_domain', 'buyer_types', 'supplier_types', 'target_roles', 'target_hs',
               'hs_strategy', 'target_countries', 'query_plan', 'precision_recall_split',
               'expansion_policy', 'evidence_policy', 'collection_budget')

GEO_FORBIDDEN_NOTE = 'geo/non-company name must never become a company entity'


def validate(node, out, state):
    """硬校验 OUTPUT 契约 + 软校验 INPUT 契约。
    返回 (ok, issues, warnings)。ok=False ⇒ 节点失败（不允许空字段冒充成功）。"""
    c = CONTRACTS.get(node)
    if not c:
        return True, [], [f'no contract registered for {node}']
    out = out or {}
    state = state or {}
    issues = []
    warnings = []
    # INPUT（软）：上游契约缺失只警告——调试单独执行时上游为空属正常
    for k in c['input']:
        v = state.get(k)
        if v is None or v == [] or v == {}:
            warnings.append(f'input[{k}] empty')
    # OUTPUT（硬）
    for k, pred in c['output'].items():
        v = out.get(k)
        try:
            good = pred(v)
        except Exception:
            good = False
        if not good:
            issues.append(f'output[{k}] missing/empty/wrong-type')
    # 节点特有成功准则
    if node == 'TRADE_STRATEGY' and not issues:
        s = out.get('strategy') or {}
        missing = [k for k in STRATEGY_12 if k not in s]
        if missing:
            issues.append('strategy missing elements: %s' % ','.join(missing))
    if node == 'DATABASE_COMMIT' and not issues:
        v = (out.get('commit_verify') or {})
        if v.get('probe_ok') is False:
            issues.append('commit readback probe failed')
    if node == 'GRAPH_EXPANSION' and not issues:
        gx = out.get('graph_expansion') or {}
        if gx.get('stopped_by') not in ('no_new_entities', 'declining_new_rate', 'max_depth',
                                        'frontier_drained', 'consecutive_low_gain', 'low_information_gain', 'budget_exhausted', 'round_limit', 'executor_error', 'no_target_eligible_seeds', 'no_expandable_source'):
            issues.append('illegal stopped_by: %s' % gx.get('stopped_by'))
    return (not issues), issues, warnings


def registry_snapshot():
    """供 UI/报告读取的契约注册表快照（唯一事实源）。"""
    return {n: {'input': c['input'], 'output': list(c['output']),
                'responsibility': c['responsibility'], 'success': c['success'],
                'failure': c['failure'], 'blocking': c['blocking'],
                'side_effects': c['side_effects'], 'db_write': c['db_write'],
                'data_semantics': c.get('data_semantics', '')}
            for n, c in CONTRACTS.items()}
