# PSV Engine v45.27

## 定位
PSV Engine 是基于编排智能体的贸易数据采集、网络扩张、信息补全与业务执行系统。

## 固定架构
1. **第一采集链（冻结九节点）**
   PRODUCT_DEFINITION → TRADE_STRATEGY → CUSTOMS_NODE_COLLECTION → TRADE_EDGE_BUILD → EVIDENCE_VERIFY → ENTITY_RESOLUTION → GRAPH_EXPANSION → RESOURCE_CLASSIFICATION → DATABASE_COMMIT
2. 九节点完成后，通过条件边启动后续任务；第一采集链本身不增加网络扩张或信息补全节点。
3. **网络扩张**：客户 → 供应商 → 客户，连续两轮；直接共享统一实体与贸易关系数据库，不设置独立去重节点。重复发现写入 `expansion_logs` 留痕。
4. **信息补全**：独立异步队列，不阻塞采集或网络扩张；确定性瀑布先收集候选，再由单一 WebAI Worker 复用 CDP 会话访问网页版 DeepSeek 做真实性核验。
5. 海关/提单数据只作为贸易事实来源；网页 AI 只负责资料真伪判断，不得凭 AI 推断创建贸易关系。
6. 同一客户的多个邮箱、联系人、电话等来源值通过 `entity_data_claims` 并存，不覆盖原始事实；冲突和明显错误保留审计痕迹。

## Windows 启动
推荐双击 **`启动PSV.bat`**。命令行入口为 **`start.bat`**。

启动脚本会：
- 使用项目目录内的 `venv`；不存在时自动创建；
- 安装 `requirements.txt`；
- 安装 Playwright Chromium；
- 检查 8090 端口，避免误连旧 PSV 实例；
- 检查 9222，必要时启动带远程调试的 Chrome/Edge；
- 启动 WebUI 并打开 `http://127.0.0.1:8090/`。

## 配置
- 产品品类：`data/industry_configs/*.json`
- 市场区域：`data/markets.json`
- 数据库：默认 `data/psv.db`
- 一次性定时任务：SQLite `scheduled_tasks`
- 网页 AI：`.env` 中配置 `WEBAI_*` 与 CDP 地址

## 部署验证
运行：`python verify_install.py`。
验证内容包括 Python 编译、SQLite 初始化、品类配置、贸易图谱服务以及旧模块残留引用扫描。


## Current workflow
- First collection chain remains frozen at nine nodes. Network expansion is exposed as a post-chain function, not a collection node.
- Network expansion no longer waits for or starts information enrichment.
- Information enrichment is a separate explicit queue with manual start; queue colors distinguish pending/running/completed/degraded/failed.
- Business execution is a sequential queue; each customer completes the independent enrichment queue first, then runs the business flow and Outlook draft/send.
- Shared entity/trade data remains the handoff contract; duplicate discovery is logged rather than handled by a separate deduplication node.


## Shared judgment incremental validation

共享判断作为事实缓存使用：判断一次，多节点继承；新证据冲突才重判。
- CUSTOMS_NODE_COLLECTION：高召回采集/初分层，不做最终价值裁决。
- EVIDENCE_VERIFY：强证据确定项规则复用，不重复调用模型；只深判不确定/冲突边。
- ENTITY_RESOLUTION：复用节点3高置信企业判断，只处理身份歧义与同名合并问题。
- GRAPH_EXPANSION：跨深度复用扩张判断；已确认、多票贸易节点可规则直通，其余 frontier 才深判。
- RESOURCE_CLASSIFICATION：复用实体/证据状态，只有未知或冲突才深判。
共享判断记录位于 `judgment_registry`，随任务 state/checkpoint 一起保存，便于恢复和审计。


## 架构边界
一个总编排智能体控制系统，九个节点负责执行。Node 3 不做客户价值筛选；Node 4 承接碎片；Node 6 判断目标客户适配性；Node 8 做最终商业角色判断；Node 9 不重做商业语义。任务状态、任务面板、共享State、handoff契约、重试、恢复、checkpoint、条件边与停止条件均由总编排器统一控制。
