# -*- coding: utf-8 -*-
import os, tempfile, json
os.environ['AI_JUDGE_ENABLED']='false'
fd,dbpath=tempfile.mkstemp(prefix='psv_v4528_',suffix='.db'); os.close(fd)
os.environ['DATABASE_PATH']=dbpath
from core.runtime import nodes as N
from core.trade_graph.trade_node import TradeGraph, TradeNode, TradeEdge
from core.tools.iy_web import is_trade_entity_url

assert is_trade_entity_url('https://www.importyeti.com/company/acme')
assert is_trade_entity_url('https://www.importyeti.com/supplier/acme')
assert not is_trade_entity_url('https://www.importyeti.com/location/company/united-states/city/x')
assert not is_trade_entity_url('https://www.importyeti.com/company/acme/foo')

g=TradeGraph(); a=TradeNode('Acme Importer','importer','test'); a.add_evidence({'customs':True,'trade_evidence':True,'shipments':10,'products':'Birthday Candles','hs':['3406'],'url':'https://www.importyeti.com/company/acme'}); g.add_node(a)
g.add_edge(TradeEdge('Acme Importer','buyer','Unknown Supplier Address 12F','unresolved_trade_node','buyer_to_supplier',{'customs':True,'trade_evidence':True,'shipments':3,'products':'Candles','hs':['3406'],'url':''},'importyeti_penetration',.95,1,'Acme Importer','Acme Importer','Acme Importer→Unknown Supplier Address 12F'))
old=N.n_collect
N.n_collect=lambda state:{'raw_companies':[{'name':'Acme Importer'}], 'companies':[{'name':'Acme Importer','type':'buyer','country':'US','source':'test','evidence':{'customs':True,'trade_evidence':True,'shipments':10,'products':'Birthday Candles','hs':['3406'],'url':'https://www.importyeti.com/company/acme','query':'birthday candles'}}], 'raw_fragments':[], 'collect_gate':{'query_telemetry':{'birthday candles':{'query':'birthday candles','attempted':True,'sources':['test'],'raw_rows':1}}}, 'penetration_stats':{'search':[]}, 'trade_graph':g.to_dict(), '_note':'test', 'node_reports':{}}
try:
    st={'task_id':'test','market':'USA','industry':'candle','quantity':10,'product_domain':{'key':'BIRTHDAY_CANDLES','version':'test','hs_candidates':['3406'],'query_plan':[{'query':'birthday candles','query_type':'core','stage':0}]},'product_profile':{},'funnel':[]}
    out=N.n_customs_node_collection(st)
    assert len(out['trade_nodes'])==1, out['trade_nodes']
    assert len(out['trade_observations'])==1, out['trade_observations']
    print(out['trade_observations']); assert out['trade_observations'][0]['identity_status']=='UNRESOLVED'
    assert out['query_stats'][0]['execution_status']=='executed'
    print('NODE3 TEST PASS')
finally:
    N.n_collect=old
    try: os.remove(dbpath)
    except OSError: pass
