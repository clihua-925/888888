# -*- coding: utf-8 -*-
"""Trade Planner Agent — 贸易规划智能体

职责：
- 理解外贸目标（自然语言）
- 生成：任务目标、执行计划、Agent 调用顺序
- 输出标准化 execution_plan
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.task_contract import TaskContract, TaskType
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import LLMClient
from shared.config.settings import settings


class TradePlannerAgent(BaseAgent):
    """Trade Planner Agent — 任务规划中心。"""

    WORKFLOW_TEMPLATES = {
        "full_development": [
            "market_research", "company_discovery", "company_enrichment",
            "contact_discovery", "lead_scoring", "sales_strategy", "report",
        ],
        "market_only": ["market_research", "report"],
        "discovery_only": ["company_discovery", "company_enrichment", "report"],
        "enrichment_only": ["company_enrichment", "contact_discovery", "lead_scoring", "report"],
        "quick_leads": ["company_discovery", "contact_discovery", "lead_scoring", "report"],
    }

    def __init__(self):
        super().__init__("trade_planner")
        self.llm = LLMClient()

    def run(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()

        task_data = {
            "task_id": request.task_id,
            "objective": request.objective,
            "product": request.input_data.get("product", ""),
            "market": request.input_data.get("market", ""),
            "target_customer": request.input_data.get("target_customer", "importer"),
            "constraints": request.input_data.get("constraints", []),
        }
        task = TaskContract.from_dict(task_data)

        valid, errors = task.validate()
        if not valid:
            return AgentResponse(
                task_id=task.task_id, agent_name=self.agent_name,
                status=AgentStatus.FAILED,
                error=f"Task validation failed: {'; '.join(errors)}",
                duration_ms=int((time.time() - t0) * 1000),
            )

        if self.llm.is_available():
            plan = self._llm_plan(task)
        else:
            plan = self._rule_plan(task)

        return AgentResponse(
            task_id=task.task_id, agent_name=self.agent_name,
            result={
                "execution_plan": plan,
                "workflow_type": plan.get("workflow_type", "full_development"),
                "estimated_steps": len(plan.get("agent_sequence", [])),
            },
            confidence=ConfidenceLevel.STRONG,
            evidence=["基于任务类型自动选择工作流模板", "计划包含 Agent 调用顺序和依赖关系"],
            next_action="supervisor_execute", status=AgentStatus.SUCCESS,
            duration_ms=int((time.time() - t0) * 1000),
        )

    def plan(self, task: TaskContract) -> AgentResponse:
        """兼容旧接口的调用方式。"""
        request = AgentRequest(
            task_id=task.task_id, agent_name="trade_planner",
            objective=task.objective,
            input_data={
                "product": task.product, "market": task.market,
                "target_customer": task.target_customer, "constraints": task.constraints,
            }
        )
        return self.run(request)

    def _rule_plan(self, task: TaskContract) -> Dict[str, Any]:
        workflow = self._select_workflow(task)
        return self._build_plan(task, workflow)

    def _llm_plan(self, task: TaskContract) -> Dict[str, Any]:
        try:
            prompt = f"""你是 PSV Trade Intelligence OS 的规划专家。
请为以下外贸任务生成执行计划：

目标: {task.objective}
产品: {task.product}
市场: {task.market}
目标客户: {task.target_customer}
约束: {task.constraints}

可用 Agent:
- market_research: 市场分析
- company_discovery: 企业发现
- company_enrichment: 企业画像补全
- contact_discovery: 联系人发现
- lead_scoring: 客户评分
- sales_strategy: 销售策略
- report: 报告生成

请返回 JSON:
{{"workflow_type": "full_development|market_only|discovery_only|enrichment_only|quick_leads",
  "agent_sequence": ["..."],
  "reasoning": "..."}}"""

            result = self.llm.generate_json(prompt, max_tokens=500)
            workflow = result.get("workflow_type", "full_development")
            sequence = result.get("agent_sequence", self.WORKFLOW_TEMPLATES["full_development"])

            plan = self._build_plan(task, workflow)
            plan["agent_sequence"] = sequence
            plan["llm_reasoning"] = result.get("reasoning", "")
            return plan
        except Exception:
            return self._rule_plan(task)

    def _select_workflow(self, task: TaskContract) -> str:
        objective = task.objective.lower()
        if any(k in objective for k in ["开发", "develop", "客户开发", "full"]):
            return "full_development"
        if any(k in objective for k in ["市场", "market", "分析", "趋势", "trend"]):
            return "market_only"
        if any(k in objective for k in ["发现", "discover", "寻找", "find", "搜索"]):
            return "discovery_only"
        if any(k in objective for k in ["补全", "enrich", "完善", "补充", "contact"]):
            return "enrichment_only"
        if any(k in objective for k in ["快速", "quick", "线索", "leads"]):
            return "quick_leads"
        return "full_development"

    def _build_plan(self, task: TaskContract, workflow_type: str) -> Dict[str, Any]:
        agent_sequence = self.WORKFLOW_TEMPLATES.get(workflow_type, self.WORKFLOW_TEMPLATES["full_development"])
        return {
            "plan_id": f"plan-{task.task_id}",
            "version": 1,
            "objective": task.objective,
            "product": task.product,
            "market": task.market,
            "target_customer": task.target_customer,
            "workflow_type": workflow_type,
            "agent_sequence": agent_sequence,
            "dependencies": self._build_dependencies(agent_sequence),
            "constraints": task.constraints,
            "expected_outputs": self._expected_outputs(agent_sequence),
            "fallback_strategy": {
                "on_agent_failure": "skip_and_continue",
                "on_partial_data": "continue_with_available",
                "max_total_retries": settings.MAX_AGENT_RETRIES * len(agent_sequence),
            },
        }

    def _build_dependencies(self, sequence: List[str]) -> Dict[str, List[str]]:
        deps = {}
        for i, agent in enumerate(sequence):
            deps[agent] = [] if i == 0 else [sequence[i - 1]]
        return deps

    def _expected_outputs(self, sequence: List[str]) -> Dict[str, str]:
        output_map = {
            "market_research": "market_analysis",
            "company_discovery": "company_pool",
            "company_enrichment": "company_profiles",
            "contact_discovery": "contacts",
            "lead_scoring": "customer_pool",
            "sales_strategy": "opportunities",
            "report": "final_report",
        }
        return {agent: output_map.get(agent, "unknown") for agent in sequence}

    def replan(self, task_id: str, current_state: Dict[str, Any], failure_reason: str) -> AgentResponse:
        t0 = time.time()
        current_plan = current_state.get("execution_plan", {})
        current_version = current_state.get("plan_version", 1)
        failed_agent = current_state.get("current_agent", "")
        sequence = current_plan.get("agent_sequence", [])
        new_sequence = [a for a in sequence if a != failed_agent]

        new_plan = {
            **current_plan,
            "plan_id": f"plan-{task_id}-v{current_version + 1}",
            "version": current_version + 1,
            "agent_sequence": new_sequence,
            "replan_reason": failure_reason,
            "skipped_agents": [failed_agent] if failed_agent else [],
        }

        return AgentResponse(
            task_id=task_id, agent_name=self.agent_name,
            result={"execution_plan": new_plan, "replanned": True},
            confidence=ConfidenceLevel.MEDIUM,
            evidence=[f"原计划在 Agent [{failed_agent}] 失败，已重新规划"],
            next_action="supervisor_execute", status=AgentStatus.SUCCESS,
            duration_ms=int((time.time() - t0) * 1000),
        )
