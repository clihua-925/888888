# -*- coding: utf-8 -*-
"""Recovery — 任务中断恢复

核心能力：
- 检测中断任务
- 从 checkpoint 恢复 workflow state
- 继续执行（不重新开始整个任务）
- 支持电脑关闭后重启恢复
"""
import time
import json
import os
from typing import Dict, List, Any, Optional

from orchestrator.checkpoint import PSVCheckpointBackend
from orchestrator.state import PSVGraphState, create_initial_state
from shared.config.settings import settings


class RecoveryManager:
    """恢复管理器。"""

    def __init__(self, backend: PSVCheckpointBackend = None):
        self.backend = backend or PSVCheckpointBackend()

    def scan_interrupted_tasks(self) -> List[Dict[str, Any]]:
        """扫描所有中断的任务。"""
        interrupted = []
        all_tasks = self._get_all_thread_ids()

        for thread_id in all_tasks:
            checkpoints = self.backend.list_checkpoints(thread_id, limit=1)
            if not checkpoints:
                continue

            latest = self.backend.load(thread_id)
            if not latest:
                continue

            state = latest["state"]
            status = state.get("status", "")
            last_time = latest["timestamp"]

            if status not in ("completed", "failed"):
                elapsed = time.time() - last_time
                if elapsed > 30:
                    interrupted.append({
                        "task_id": state.get("task_id", thread_id),
                        "thread_id": thread_id,
                        "checkpoint_id": latest["checkpoint_id"],
                        "status": status,
                        "current_agent": state.get("current_agent", ""),
                        "current_node": state.get("current_node", ""),
                        "last_active": last_time,
                        "elapsed_seconds": int(elapsed),
                        "can_recover": True,
                    })
                else:
                    interrupted.append({
                        "task_id": state.get("task_id", thread_id),
                        "thread_id": thread_id,
                        "checkpoint_id": latest["checkpoint_id"],
                        "status": status,
                        "current_agent": state.get("current_agent", ""),
                        "current_node": state.get("current_node", ""),
                        "last_active": last_time,
                        "elapsed_seconds": int(elapsed),
                        "can_recover": False,
                        "note": "任务可能仍在运行中",
                    })

        return interrupted

    def _get_all_thread_ids(self) -> List[str]:
        import sqlite3
        db_path = self.backend.db_path
        if not os.path.exists(db_path):
            return []

        with sqlite3.connect(db_path) as conn:
            rows = conn.execute(
                "SELECT DISTINCT thread_id FROM checkpoints"
            ).fetchall()
            return [r[0] for r in rows]

    def recover_state(self, task_id: str, thread_id: str = None, checkpoint_id: str = None) -> Optional[PSVGraphState]:
        """恢复任务状态。"""
        tid = thread_id or task_id

        checkpoint_data = self.backend.load(tid, checkpoint_id)
        if not checkpoint_data:
            return None

        state = checkpoint_data["state"]
        state["status"] = "recovering"
        state["checkpoint_id"] = checkpoint_data["checkpoint_id"]
        state["updated_at"] = time.time()

        state["audit_trail"] = state.get("audit_trail", []) + [{
            "event": "state_recovered",
            "timestamp": time.time(),
            "checkpoint_id": checkpoint_data["checkpoint_id"],
            "recovered_from_node": state.get("current_node", "unknown"),
        }]

        return state

    def resume_workflow(self, graph, task_id: str, thread_id: str = None, checkpoint_id: str = None) -> Dict[str, Any]:
        """恢复并继续执行 workflow。"""
        state = self.recover_state(task_id, thread_id, checkpoint_id)
        if not state:
            raise ValueError(f"无法恢复任务: {task_id}")

        config = {
            "configurable": {
                "thread_id": thread_id or task_id,
                "checkpoint_id": checkpoint_id,
            }
        }

        final_state = None
        for event in graph.stream(state, config, stream_mode="values"):
            final_state = event

        return final_state

    def purge_completed(self, days: int = 7) -> int:
        return 0
