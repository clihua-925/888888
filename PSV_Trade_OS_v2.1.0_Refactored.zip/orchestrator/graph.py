# -*- coding: utf-8 -*-
"""Graph — LangGraph 主编排图

PSV Trade Intelligence OS 的核心运行引擎。
修复：消除死循环，统一审计，规范数据流。

流程：
    INIT → PLANNER → SUPERVISOR → [AGENT LOOP] → REPORT → PERSIST → END
                     ↑____________↓
    AGENT → CHECKPOINT → SUPERVISOR (循环)
"""
import time
from typing import Dict, Any
from langgraph.graph import StateGraph, END

from orchestrator.state import PSVGraphState, create_initial_state
from orchestrator.planner import TradePlannerAgent
from orchestrator.supervisor import SupervisorAgent
from orchestrator.router import PSVRouter
from orchestrator.checkpoint import PSVCheckpointer
from contracts.task_contract import TaskContract
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.config.settings import settings

from agents.market_research.agent import MarketResearchAgent
from agents.company_discovery.agent import CompanyDiscoveryAgent
from agents.company_enrichment.agent import CompanyEnrichmentAgent
from agents.contact_discovery.agent import ContactDiscoveryAgent
from agents.lead_scoring.agent import LeadScoringAgent
from agents.sales_strategy.agent import SalesStrategyAgent
from agents.report.agent import ReportAgent

from platform.database.models import PSVDatabase, get_session
from platform.audit.logger import AuditLogger


class PSVGraphBuilder:
    """PSV 主图构建器 —— 外贸智能操作系统核心引擎。"""

    def __init__(self):
        self.planner = TradePlannerAgent()
        self.supervisor = SupervisorAgent()
        self.router = PSVRouter(supervisor=self.supervisor)
        self.checkpointer = PSVCheckpointer()
        self.db = PSVDatabase()
        self.audit = AuditLogger()

        self.agents = {
            "market_research": MarketResearchAgent(),
            "company_discovery": CompanyDiscoveryAgent(),
            "company_enrichment": CompanyEnrichmentAgent(),
            "contact_discovery": ContactDiscoveryAgent(),
            "lead_scoring": LeadScoringAgent(),
            "sales_strategy": SalesStrategyAgent(),
            "report": ReportAgent(),
        }

    def build(self) -> StateGraph:
        builder = StateGraph(PSVGraphState)

        builder.add_node("init", self._node_init)
        builder.add_node("planner", self._node_planner)
        builder.add_node("supervisor", self._node_supervisor)
        builder.add_node("market_research", self._make_agent_node("market_research"))
        builder.add_node("company_discovery", self._make_agent_node("company_discovery"))
        builder.add_node("company_enrichment", self._make_agent_node("company_enrichment"))
        builder.add_node("contact_discovery", self._make_agent_node("contact_discovery"))
        builder.add_node("lead_scoring", self._make_agent_node("lead_scoring"))
        builder.add_node("sales_strategy", self._make_agent_node("sales_strategy"))
        builder.add_node("report", self._node_report)
        builder.add_node("checkpoint", self._node_checkpoint)
        builder.add_node("persist", self._node_persist)

        builder.set_entry_point("init")
        builder.add_edge("init", "planner")

        builder.add_conditional_edges(
            "planner",
            self.router.route_after_planner,
            {"supervisor": "supervisor", "end": END}
        )

        builder.add_conditional_edges(
            "supervisor",
            self.router.route_after_supervisor,
            {
                "market_research": "market_research",
                "company_discovery": "company_discovery",
                "company_enrichment": "company_enrichment",
                "contact_discovery": "contact_discovery",
                "lead_scoring": "lead_scoring",
                "sales_strategy": "sales_strategy",
                "report": "report",
                "planner": "planner",
                "end": END,
            }
        )

        for agent_node in [
            "market_research", "company_discovery", "company_enrichment",
            "contact_discovery", "lead_scoring", "sales_strategy",
        ]:
            builder.add_edge(agent_node, "checkpoint")

        builder.add_conditional_edges("checkpoint", self.router.route_after_checkpoint, {"supervisor": "supervisor"})

        builder.add_edge("report", "persist")
        builder.add_edge("persist", END)

        graph = builder.compile(checkpointer=self.checkpointer)
        return graph

    def _audit(self, state: PSVGraphState, event_type: str, details: Dict = None):
        """统一审计记录。"""
        entry = {
            "task_id": state.get("task_id"),
            "workflow_id": state.get("workflow_id"),
            "node": state.get("current_node"),
            "agent": state.get("current_agent"),
            "event_type": event_type,
            "details": details or {},
            "timestamp": time.time(),
            "status": state.get("status"),
        }
        state["audit_trail"] = state.get("audit_trail", []) + [entry]
        self.audit.log(entry)

    def _node_init(self, state: PSVGraphState) -> Dict[str, Any]:
        state["status"] = "planning"
        state["current_node"] = "init"
        state["routing_path"] = state.get("routing_path", []) + ["init"]
        self._audit(state, "task_initialized", {"intent": state.get("trade_intent")})
        return state

    def _node_planner(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "planner"
        state["current_agent"] = "trade_planner"

        task_contract = state.get("task_contract", {})
        task = TaskContract.from_dict(task_contract)
        response = self.planner.plan(task)

        if response.is_success():
            state["execution_plan"] = response.result.get("execution_plan", {})
            state["plan_version"] = response.result.get("execution_plan", {}).get("version", 1)
            state["status"] = "executing"
            self._audit(state, "plan_generated", {
                "workflow_type": response.result.get("workflow_type"),
                "agent_sequence": response.result.get("execution_plan", {}).get("agent_sequence"),
            })
        else:
            state["status"] = "failed"
            state["error_log"] = state.get("error_log", []) + [{
                "node": "planner", "error": response.error, "timestamp": time.time(),
            }]
            self._audit(state, "plan_failed", {"error": response.error})

        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        state["routing_path"] = state.get("routing_path", []) + ["planner"]
        state["updated_at"] = time.time()
        return state

    def _node_supervisor(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "supervisor"
        state["current_agent"] = "supervisor"
        state["routing_path"] = state.get("routing_path", []) + ["supervisor"]
        self._audit(state, "supervisor_invoked")
        return state

    def _make_agent_node(self, agent_name: str):
        """工厂函数：创建统一的 Agent 执行节点。"""
        def _node(state: PSVGraphState) -> Dict[str, Any]:
            state["current_node"] = agent_name
            state["current_agent"] = agent_name
            state["routing_path"] = state.get("routing_path", []) + [agent_name]

            t0 = time.time()
            agent = self.agents.get(agent_name)

            if not agent:
                error_msg = f"Agent {agent_name} not found"
                state["error_log"] = state.get("error_log", []) + [{
                    "node": agent_name, "error": error_msg, "timestamp": time.time()
                }]
                self._audit(state, "agent_not_found", {"agent": agent_name})
                return state

            context = self._build_agent_context(state, agent_name)
            request = AgentRequest(
                task_id=state.get("task_id", ""),
                agent_name=agent_name,
                objective=state.get("trade_intent", {}).get("objective", ""),
                input_data=self._build_agent_input(state, agent_name),
                context=context,
            )

            try:
                response = agent.run(request)
                duration = int((time.time() - t0) * 1000)
                response.duration_ms = duration

                if response.is_success():
                    self._update_state_from_agent(state, agent_name, response)

                state["agent_results"] = {**state.get("agent_results", {}), agent_name: response.to_dict()}
                state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]

                self._audit(state, "agent_executed", {
                    "agent": agent_name, "success": response.is_success(),
                    "duration_ms": duration,
                    "confidence": response.confidence.value if hasattr(response.confidence, 'value') else str(response.confidence),
                })

            except Exception as e:
                error_msg = str(e)
                state["error_log"] = state.get("error_log", []) + [{
                    "node": agent_name, "error": error_msg, "timestamp": time.time()
                }]
                self._audit(state, "agent_exception", {"agent": agent_name, "error": error_msg})

            state["updated_at"] = time.time()
            return state

        return _node

    def _build_agent_input(self, state: PSVGraphState, agent_name: str) -> Dict[str, Any]:
        intent = state.get("trade_intent", {})
        inputs = {
            "market_research": {
                "product": intent.get("product"), "market": intent.get("market"),
                "target_customer": intent.get("target_customer"),
            },
            "company_discovery": {
                "product": intent.get("product"), "market": intent.get("market"),
                "target_customer": intent.get("target_customer", "importer"),
            },
            "company_enrichment": {
                "company_pool": state.get("company_pool", []), "product": intent.get("product"),
            },
            "contact_discovery": {
                "company_profiles": state.get("company_profiles", {}), "product": intent.get("product"),
            },
            "lead_scoring": {
                "company_profiles": state.get("company_profiles", {}),
                "contacts": state.get("contacts", []), "product": intent.get("product"),
            },
            "sales_strategy": {
                "customer_pool": state.get("customer_pool", []),
                "company_profiles": state.get("company_profiles", {}), "product": intent.get("product"),
            },
        }
        return inputs.get(agent_name, {})

    def _build_agent_context(self, state: PSVGraphState, agent_name: str) -> Dict[str, Any]:
        context = {}
        if agent_name in ["company_discovery", "lead_scoring", "sales_strategy"]:
            context["market_analysis"] = state.get("market_analysis", {})
        if agent_name == "sales_strategy":
            context["contacts"] = state.get("contacts", [])
        return context

    def _update_state_from_agent(self, state: PSVGraphState, agent_name: str, response: AgentResponse):
        result = response.result or {}
        mapping = {
            "market_research": "market_analysis",
            "company_discovery": "company_pool",
            "company_enrichment": "company_profiles",
            "contact_discovery": "contacts",
            "lead_scoring": "customer_pool",
            "sales_strategy": "opportunities",
        }
        key = mapping.get(agent_name)
        if key and key in result:
            state[key] = result[key]

    def _node_checkpoint(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "checkpoint"
        cp_id = f"cp-{state.get('task_id', '')}-{int(time.time()*1000)}"
        state["checkpoint_id"] = cp_id
        state["checkpoint_history"] = state.get("checkpoint_history", []) + [cp_id]
        state["routing_path"] = state.get("routing_path", []) + ["checkpoint"]
        self._audit(state, "checkpoint_saved", {"checkpoint_id": cp_id})
        state["updated_at"] = time.time()
        return state

    def _node_persist(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "persist"
        task_id = state.get("task_id", "")

        try:
            session = get_session()

            for entity_id, profile in state.get("company_profiles", {}).items():
                self.db.upsert_company(session, profile)

            for customer in state.get("customer_pool", []):
                self.db.upsert_customer_pool(session, customer)

            for opp in state.get("opportunities", []):
                self.db.upsert_opportunity(session, opp)

            self.db.upsert_task(session, {
                "task_id": task_id,
                "objective": state.get("trade_intent", {}).get("objective", ""),
                "product": state.get("trade_intent", {}).get("product", ""),
                "market": state.get("trade_intent", {}).get("market", ""),
                "target_customer": state.get("trade_intent", {}).get("target_customer", ""),
                "status": state.get("status", ""),
                "execution_plan": state.get("execution_plan", {}),
                "final_report": state.get("final_report", {}),
                "routing_path": state.get("routing_path", []),
                "updated_at": time.time(),
            })

            session.commit()
            session.close()

            self._audit(state, "data_persisted", {
                "companies": len(state.get("company_profiles", {})),
                "customers": len(state.get("customer_pool", [])),
                "opportunities": len(state.get("opportunities", [])),
            })

        except Exception as e:
            error_msg = str(e)
            state["error_log"] = state.get("error_log", []) + [{
                "node": "persist", "error": error_msg, "timestamp": time.time()
            }]
            self._audit(state, "persist_failed", {"error": error_msg})

        state["routing_path"] = state.get("routing_path", []) + ["persist"]
        state["updated_at"] = time.time()
        return state

    def _node_report(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "report"
        state["current_agent"] = "report"
        state["status"] = "reporting"
        state["routing_path"] = state.get("routing_path", []) + ["report"]

        t0 = time.time()
        agent = self.agents.get("report")

        request = AgentRequest(
            task_id=state.get("task_id", ""),
            agent_name="report",
            objective=state.get("trade_intent", {}).get("objective", ""),
            input_data={
                "market_analysis": state.get("market_analysis", {}),
                "company_pool": state.get("company_pool", []),
                "company_profiles": state.get("company_profiles", {}),
                "customer_pool": state.get("customer_pool", []),
                "contacts": state.get("contacts", []),
                "opportunities": state.get("opportunities", []),
            },
            context={
                "task_contract": state.get("task_contract", {}),
                "agent_history": state.get("agent_history", []),
                "routing_path": state.get("routing_path", []),
            }
        )

        try:
            response = agent.run(request)
            if response.is_success():
                state["final_report"] = response.result.get("final_report", {})
                state["status"] = "completed"
                state["output_delivered"] = True
            else:
                state["status"] = "failed"

            state["agent_results"] = {**state.get("agent_results", {}), "report": response.to_dict()}
            state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]

            self._audit(state, "report_generated", {
                "success": response.is_success(),
                "duration_ms": int((time.time() - t0) * 1000),
            })
        except Exception as e:
            state["status"] = "failed"
            state["error_log"] = state.get("error_log", []) + [{
                "node": "report", "error": str(e), "timestamp": time.time()
            }]
            self._audit(state, "report_failed", {"error": str(e)})

        state["updated_at"] = time.time()
        return state


_graph_builder = None


def get_graph() -> StateGraph:
    global _graph_builder
    if _graph_builder is None:
        _graph_builder = PSVGraphBuilder()
    return _graph_builder.build()


def run_trade_task(task_contract: Dict[str, Any]) -> Dict[str, Any]:
    graph = get_graph()
    initial_state = create_initial_state(task_contract)
    config = {"configurable": {"thread_id": task_contract.get("task_id", "default")}}

    final_state = None
    for event in graph.stream(initial_state, config, stream_mode="values"):
        final_state = event

    return final_state


def resume_trade_task(task_id: str, checkpoint_id: str = None) -> Dict[str, Any]:
    from orchestrator.recovery import RecoveryManager

    graph = get_graph()
    recovery = RecoveryManager()
    return recovery.resume_workflow(graph, task_id, task_id, checkpoint_id)
