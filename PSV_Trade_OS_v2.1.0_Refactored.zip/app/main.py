# -*- coding: utf-8 -*-
"""PSV Trade Intelligence OS — 统一入口

一个系统。一个入口。一个 Agent 编排体系。
"""
import sys
import argparse
import json

from orchestrator.graph import run_trade_task, resume_trade_task
from orchestrator.recovery import RecoveryManager
from contracts.task_contract import TaskContract
from platform.database.models import init_database


def main():
    parser = argparse.ArgumentParser(description="PSV Trade Intelligence OS")
    parser.add_argument("command", choices=["run", "resume", "scan", "init"],
                       help="命令: run(执行任务), resume(恢复任务), scan(扫描中断任务), init(初始化数据库)")
    parser.add_argument("--task-id", help="任务ID")
    parser.add_argument("--objective", "-o", help="外贸目标，例如: 开发美国生日蜡烛进口商")
    parser.add_argument("--product", "-p", help="产品")
    parser.add_argument("--market", "-m", help="目标市场/国家")
    parser.add_argument("--target", "-t", default="importer", help="目标客户类型")
    parser.add_argument("--checkpoint", "-c", help="Checkpoint ID（恢复时用）")

    args = parser.parse_args()

    if args.command == "init":
        init_database()
        print("✓ 数据库初始化完成")
        return

    if args.command == "scan":
        rm = RecoveryManager()
        tasks = rm.scan_interrupted_tasks()
        if tasks:
            print(f"发现 {len(tasks)} 个中断任务:")
            for t in tasks:
                print(f"  - {t['task_id']}: {t['status']} @ {t['current_agent']} "
                      f"(已中断 {t['elapsed_seconds']}s) [可恢复: {t['can_recover']}]")
        else:
            print("未发现中断任务")
        return

    if args.command == "resume":
        if not args.task_id:
            print("错误: 恢复任务需要 --task-id")
            sys.exit(1)
        print(f"正在恢复任务: {args.task_id}")
        result = resume_trade_task(args.task_id, args.checkpoint)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.command == "run":
        if not args.objective:
            print("错误: 执行任务需要 --objective")
            sys.exit(1)

        task = TaskContract(
            task_id=args.task_id or f"task-{__import__('time').time():.0f}",
            objective=args.objective,
            product=args.product or "",
            market=args.market or "",
            target_customer=args.target,
        )

        print(f"启动外贸智能任务: {args.objective}")
        print(f"产品: {task.product or '未指定'} | 市场: {task.market or '未指定'} | 客户: {task.target_customer}")
        print("-" * 60)

        result = run_trade_task(task.to_dict())

        print("-" * 60)
        print("任务完成!")
        print(f"状态: {result.get('status')}")
        print(f"执行路径: {' -> '.join(result.get('routing_path', []))}")

        if result.get('final_report'):
            print("\n=== 智能报告 ===")
            print(json.dumps(result['final_report'], ensure_ascii=False, indent=2)[:2000])

        if result.get('customer_pool'):
            print(f"\n发现 {len(result['customer_pool'])} 个潜在客户")

        return


if __name__ == "__main__":
    main()
