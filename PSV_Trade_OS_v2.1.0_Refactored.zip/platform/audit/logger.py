# -*- coding: utf-8 -*-
"""Audit Logger — 全链路审计追踪

必须能够回答：
- 哪个 Agent 执行？
- 为什么执行？
- 调用什么工具？
- 产生什么结果？
- 哪里失败？
"""
import time
import uuid
import json
from typing import Dict, List, Any, Optional
from datetime import datetime

from platform.database.models import get_session, AuditEvent


class AuditLogger:
    """审计日志记录器 —— 所有智能行为必须可追踪。"""

    def __init__(self):
        self.buffer = []
        self.buffer_size = 10

    def log(self, entry: Dict[str, Any]):
        event = AuditEvent(
            id=str(uuid.uuid4()),
            task_id=entry.get("task_id"),
            workflow_id=entry.get("workflow_id"),
            agent_id=entry.get("agent"),
            node=entry.get("node"),
            event_type=entry.get("event_type"),
            input_data=entry.get("details", {}),
            output_data=entry.get("output", {}),
            tool_call=entry.get("tool_call"),
            duration_ms=entry.get("duration_ms"),
            status=entry.get("status"),
            error=entry.get("error"),
            timestamp=datetime.utcnow(),
        )
        session = get_session()
        session.add(event)
        session.commit()
        session.close()

    def log_agent_execution(self, task_id: str, workflow_id: str, agent_name: str,
                           input_data: Dict, output_data: Dict, duration_ms: int,
                           status: str, error: str = None, tool_calls: List = None):
        self.log({
            "task_id": task_id, "workflow_id": workflow_id, "agent": agent_name,
            "event_type": "agent_execution",
            "details": input_data, "output": output_data,
            "tool_call": {"tools": tool_calls} if tool_calls else None,
            "duration_ms": duration_ms, "status": status, "error": error,
        })

    def log_tool_call(self, task_id: str, agent_name: str, tool_name: str,
                     parameters: Dict, result: Any, duration_ms: int, success: bool):
        self.log({
            "task_id": task_id, "agent": agent_name,
            "event_type": "tool_call",
            "details": {"tool": tool_name, "parameters": parameters},
            "output": {"result": result},
            "tool_call": {"tool": tool_name, "params": parameters},
            "duration_ms": duration_ms,
            "status": "success" if success else "failed",
        })

    def log_decision(self, task_id: str, agent_name: str, decision: str,
                    reason: str, context: Dict = None):
        self.log({
            "task_id": task_id, "agent": agent_name,
            "event_type": "decision",
            "details": {"decision": decision, "reason": reason, "context": context or {}},
            "status": "success",
        })

    def query_by_task(self, task_id: str, limit: int = 100) -> List[Dict]:
        session = get_session()
        events = session.query(AuditEvent).filter_by(task_id=task_id)\
            .order_by(AuditEvent.timestamp.asc()).limit(limit).all()
        session.close()
        return [
            {
                "timestamp": e.timestamp.isoformat(),
                "node": e.node, "agent": e.agent_id,
                "event_type": e.event_type,
                "status": e.status,
                "duration_ms": e.duration_ms,
                "error": e.error,
            }
            for e in events
        ]

    def generate_trace_report(self, task_id: str) -> str:
        events = self.query_by_task(task_id)
        lines = [f"=== Audit Trace for Task: {task_id} ===\n"]
        for e in events:
            lines.append(f"[{e['timestamp']}] {e['node']} | {e['agent']} | {e['event_type']} | {e['status']}")
            if e['error']:
                lines.append(f"  ERROR: {e['error']}")
        return "\n".join(lines)
