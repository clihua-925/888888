# -*- coding: utf-8 -*-
"""NETWORK_EXPANSION v41：网络扩张引擎（客户情报中心核心能力）。

从单一客户出发，沿多个维度扩张贸易网络。
扩张结果自动进入：新客户、新供应商、新贸易边。
"""
import json
from typing import List, Dict, Any, Optional
from core.memory.db import DB
from core.intelligence import ai_gateway


# ========== 扩张方向定义 ==========

EXPANSION_DIRECTIONS = {
    'customer_to_supplier': {
        'label': '客户→供应商',
        'description': '寻找当前供应商的其他客户',
        'logic': '_expand_customer_supplier_others'
    },
    'supplier_to_customer': {
        'label': '供应商→客户',
        'description': '寻找工厂的其他买家',
        'logic': '_expand_supplier_other_buyers'
    },
    'customer_to_customer': {
        'label': '客户→客户',
        'description': '寻找同类采购商',
        'logic': '_expand_similar_buyers'
    },
    'product': {
        'label': '产品扩张',
        'description': '寻找同产品进口商',
        'logic': '_expand_same_product_importers'
    },
    'enterprise': {
        'label': '企业关联扩张',
        'description': '寻找同地址/同品牌/同集团/同联系人企业',
        'logic': '_expand_enterprise_associations'
    }
}


# ========== 扩张引擎 ==========

class NetworkExpander:
    def __init__(self):
        self.db = DB()

    def expand(self, norm: str, direction: str, profile: Dict = None) -> Dict:
        """执行指定方向的扩张。"""
        if direction not in EXPANSION_DIRECTIONS:
            return {'ok': False, 'error': f'未知扩张方向: {direction}'}

        if profile is None:
            from core.intelligence.account_intelligence_center import AccountIntelligenceCenter
            profile = AccountIntelligenceCenter().build_profile(norm)

        method_name = EXPANSION_DIRECTIONS[direction]['logic']
        method = getattr(self, method_name)
        new_leads, new_edges = method(norm, profile)

        return {
            'ok': True,
            'direction': direction,
            'direction_label': EXPANSION_DIRECTIONS[direction]['label'],
            'new_leads': new_leads,
            'new_edges': new_edges,
            'new_leads_count': len(new_leads),
            'new_edges_count': len(new_edges)
        }

    # ---------- 方向1: 客户→供应商（找供应商的其他客户）----------

    def _expand_customer_supplier_others(self, norm: str, profile) -> (List[Dict], List[Dict]):
        """当前客户的供应商，还供应给哪些其他客户。"""
        new_leads = []
        new_edges = []

        # 获取当前客户的所有供应商
        suppliers = profile.trade.current_suppliers if hasattr(profile, 'trade') else []
        if not suppliers and hasattr(profile, 'trade_network'):
            suppliers = [s['name'] for s in profile.trade_network.get('suppliers', [])]

        for supplier_name in suppliers[:10]:
            # 从海关数据找该供应商的其他客户
            try:
                with self.db.c() as c:
                    rows = c.execute('''
                        SELECT DISTINCT importer_norm, importer, COUNT(*) as cnt
                        FROM customs_raw
                        WHERE shipper = ? AND importer_norm != ?
                        GROUP BY importer_norm
                        ORDER BY cnt DESC
                        LIMIT 20
                    ''', (supplier_name, norm)).fetchall()

                    for row in rows:
                        importer_norm = row['importer_norm'] or self._normalize(row['importer'])
                        if not importer_norm or importer_norm == norm:
                            continue

                        lead = {
                            'norm': importer_norm,
                            'name': row['importer'] or importer_norm,
                            'type': 'buyer',
                            'source': f'expansion:supplier_others({supplier_name})',
                            'shipments': row['cnt']
                        }
                        new_leads.append(lead)

                        edge = {
                            'from_norm': supplier_name,
                            'to_norm': importer_norm,
                            'relation': 'supplier_to_customer',
                            'evidence': {'type': 'customs', 'shipments': row['cnt'], 'shared_supplier': supplier_name},
                            'source': 'network_expansion'
                        }
                        new_edges.append(edge)
            except Exception:
                continue

        return new_leads, new_edges

    # ---------- 方向2: 供应商→客户（找工厂的其他买家）----------

    def _expand_supplier_other_buyers(self, norm: str, profile) -> (List[Dict], List[Dict]):
        """当前客户作为供应商时，找他的其他买家。"""
        new_leads = []
        new_edges = []

        # 从关系表找当前客户作为供应商的出口对象
        try:
            with self.db.c() as c:
                rows = c.execute('''
                    SELECT DISTINCT to_norm, to_name, relation, evidence
                    FROM relationships
                    WHERE from_norm = ? AND relation IN ('supplier_to', 'ships_to', 'exports_to')
                    LIMIT 30
                ''', (norm,)).fetchall()

                for row in rows:
                    to_norm = row['to_norm']
                    if not to_norm: continue

                    lead = {
                        'norm': to_norm,
                        'name': row['to_name'] or to_norm,
                        'type': 'buyer',
                        'source': f'expansion:supplier_buyers({norm})'
                    }
                    new_leads.append(lead)

                    edge = {
                        'from_norm': norm,
                        'to_norm': to_norm,
                        'relation': 'supplier_to_customer',
                        'evidence': {'type': 'relationship_db', 'relation': row['relation']},
                        'source': 'network_expansion'
                    }
                    new_edges.append(edge)
        except Exception:
            pass

        return new_leads, new_edges

    # ---------- 方向3: 客户→客户（同类采购商）----------

    def _expand_similar_buyers(self, norm: str, profile) -> (List[Dict], List[Dict]):
        """找与当前客户采购同类产品的其他进口商。"""
        new_leads = []
        new_edges = []

        hs_codes = profile.trade.hs_codes if hasattr(profile, 'trade') else []
        products = profile.trade.products if hasattr(profile, 'trade') else []

        # 用 HS 编码找同类采购商
        for hs in hs_codes[:3]:
            try:
                with self.db.c() as c:
                    rows = c.execute('''
                        SELECT DISTINCT importer_norm, importer, COUNT(*) as cnt
                        FROM customs_raw
                        WHERE hs = ? AND importer_norm != ? AND importer_norm IS NOT NULL
                        GROUP BY importer_norm
                        ORDER BY cnt DESC
                        LIMIT 15
                    ''', (hs, norm)).fetchall()

                    for row in rows:
                        lead = {
                            'norm': row['importer_norm'],
                            'name': row['importer'] or row['importer_norm'],
                            'type': 'buyer',
                            'source': f'expansion:similar_hs({hs})',
                            'shipments': row['cnt']
                        }
                        new_leads.append(lead)

                        edge = {
                            'from_norm': norm,
                            'to_norm': row['importer_norm'],
                            'relation': 'similar_buyer',
                            'evidence': {'type': 'customs', 'shared_hs': hs, 'shipments': row['cnt']},
                            'source': 'network_expansion'
                        }
                        new_edges.append(edge)
            except Exception:
                continue

        return new_leads, new_edges

    # ---------- 方向4: 产品扩张（同产品进口商）----------

    def _expand_same_product_importers(self, norm: str, profile) -> (List[Dict], List[Dict]):
        """找进口相同/相似产品的企业。"""
        new_leads = []
        new_edges = []

        products = profile.trade.products if hasattr(profile, 'trade') else []
        country = profile.enterprise.country if hasattr(profile, 'enterprise') else ''

        # 用产品描述关键词匹配
        for product in products[:2]:
            keyword = product.split()[0] if ' ' in product else product
            if len(keyword) < 3: continue

            try:
                with self.db.c() as c:
                    rows = c.execute('''
                        SELECT DISTINCT importer_norm, importer, country, COUNT(*) as cnt
                        FROM customs_raw
                        WHERE (descr LIKE ? OR hs LIKE ?) AND importer_norm != ? AND importer_norm IS NOT NULL
                        GROUP BY importer_norm
                        ORDER BY cnt DESC
                        LIMIT 15
                    ''', (f'%{keyword}%', f'%{keyword}%', norm)).fetchall()

                    for row in rows:
                        lead = {
                            'norm': row['importer_norm'],
                            'name': row['importer'] or row['importer_norm'],
                            'country': row['country'] or '',
                            'type': 'buyer',
                            'source': f'expansion:product({keyword})',
                            'shipments': row['cnt']
                        }
                        new_leads.append(lead)

                        edge = {
                            'from_norm': norm,
                            'to_norm': row['importer_norm'],
                            'relation': 'same_product',
                            'evidence': {'type': 'customs', 'shared_product': keyword, 'shipments': row['cnt']},
                            'source': 'network_expansion'
                        }
                        new_edges.append(edge)
            except Exception:
                continue

        return new_leads, new_edges

    # ---------- 方向5: 企业关联扩张 ----------

    def _expand_enterprise_associations(self, norm: str, profile) -> (List[Dict], List[Dict]):
        """同地址/同品牌/同集团/同联系人。"""
        new_leads = []
        new_edges = []

        # 同地址
        address = profile.enterprise.address if hasattr(profile, 'enterprise') else ''
        if address and len(address) > 5:
            try:
                with self.db.c() as c:
                    rows = c.execute('''
                        SELECT norm, name, country
                        FROM leads
                        WHERE address LIKE ? AND norm != ?
                        LIMIT 10
                    ''', (f'%{address[:30]}%', norm)).fetchall()

                    for row in rows:
                        lead = {
                            'norm': row['norm'],
                            'name': row['name'],
                            'country': row['country'] or '',
                            'type': 'associated',
                            'source': 'expansion:same_address'
                        }
                        new_leads.append(lead)

                        edge = {
                            'from_norm': norm,
                            'to_norm': row['norm'],
                            'relation': 'same_address',
                            'evidence': {'type': 'address_match', 'address': address[:30]},
                            'source': 'network_expansion'
                        }
                        new_edges.append(edge)
            except Exception:
                pass

        # 同品牌
        brand = profile.enterprise.brand_info if hasattr(profile, 'enterprise') else ''
        if brand and len(brand) > 2:
            try:
                with self.db.c() as c:
                    rows = c.execute('''
                        SELECT norm, name, country
                        FROM leads
                        WHERE brand_info LIKE ? AND norm != ?
                        LIMIT 10
                    ''', (f'%{brand}%', norm)).fetchall()

                    for row in rows:
                        lead = {
                            'norm': row['norm'],
                            'name': row['name'],
                            'country': row['country'] or '',
                            'type': 'associated',
                            'source': 'expansion:same_brand'
                        }
                        new_leads.append(lead)

                        edge = {
                            'from_norm': norm,
                            'to_norm': row['norm'],
                            'relation': 'same_brand',
                            'evidence': {'type': 'brand_match', 'brand': brand},
                            'source': 'network_expansion'
                        }
                        new_edges.append(edge)
            except Exception:
                pass

        return new_leads, new_edges

    # ---------- 工具方法 ----------

    def _normalize(self, name: str) -> str:
        if not name: return ''
        return name.lower().strip().replace(' ', '_').replace('.', '_')[:64]


# ---------- 便捷函数 ----------
def expand_from_lead(norm: str, direction: str = 'product', profile: Any = None) -> Dict:
    return NetworkExpander().expand(norm, direction, profile)