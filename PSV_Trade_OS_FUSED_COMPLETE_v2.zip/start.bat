@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo PSV Trade OS 9.4.0 - Windows Startup
echo ============================================================
echo [INFO] Project: %CD%

rem --- 0. Ensure .env exists (never shipped inside the package) ---
if not exist "%~dp0.env" (
    if exist "%~dp0.env.example" (
        echo [INFO] .env not found. Creating from .env.example ...
        copy /y "%~dp0.env.example" "%~dp0.env" >nul
    )
)

rem --- 1. Resolve Python interpreter ---
set "ENV_PYTHON="
set "ENV_DIR=%~dp0.venv"
set "ENV_MODE="

rem 1a. Project-local .venv has top priority (fully self-contained).
if exist "%ENV_DIR%\Scripts\python.exe" (
    set "ENV_PYTHON=%ENV_DIR%\Scripts\python.exe"
    set "ENV_MODE=project"
    echo [OK] Using project venv: %ENV_DIR%
    goto :interpreter_done
)

rem 1b. No project venv yet: look for a system Python 3.10-3.13 to create one.
set "PYTHON_EXE="
for /f "tokens=2 delims= " %%V in ('python --version 2^>^&1') do set "PYTHON_VERSION=%%V"
if defined PYTHON_VERSION (
    for /f "tokens=1,2 delims=." %%A in ("!PYTHON_VERSION!") do (
        if "%%A"=="3" if %%B GEQ 10 if %%B LEQ 13 set "PYTHON_EXE=python"
    )
)
if not defined PYTHON_EXE (
    for %%V in (3.13 3.12 3.11 3.10) do (
        py -%%V -c "import sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1
        if not errorlevel 1 if not defined PYTHON_EXE set "PYTHON_EXE=py -%%V"
    )
)

if defined PYTHON_EXE (
    echo [INFO] Creating project venv with !PYTHON_EXE! ...
    !PYTHON_EXE! -m venv "%ENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to create project venv.
        pause
        exit /b 1
    )
    set "ENV_PYTHON=%ENV_DIR%\Scripts\python.exe"
    set "ENV_MODE=project"
    echo [OK] Project venv created: %ENV_DIR%
    goto :interpreter_done
)

rem 1c. No system Python: fall back to an existing sibling venv (e.g. D:\chang\venv).
for %%C in ("%~dp0..\venv" "%~dp0..\..\venv") do (
    if not defined ENV_PYTHON (
        if exist "%%~fC\Scripts\python.exe" (
            set "ENV_PYTHON=%%~fC\Scripts\python.exe"
            set "ENV_MODE=external"
        )
    )
)
if defined ENV_PYTHON (
    echo [OK] No system Python found. Reusing existing venv: %ENV_PYTHON%
    goto :interpreter_done
)

echo [ERROR] No usable Python found.
echo [INFO] Tried: project .venv, system python/py launcher, parent folder venv.
echo [INFO] Install Python 3.10-3.13 or place a venv next to the project folder.
pause
exit /b 1

:interpreter_done
echo [OK] Python: %ENV_PYTHON%

rem --- 2. Clean transient files (never touches venvs) ---
for /d /r "%~dp0" %%D in (__pycache__) do (
    echo %%~fD | findstr /i /c:"\.venv\" /c:"\venv\" >nul
    if errorlevel 1 if exist "%%D" rd /s /q "%%D" >nul 2>&1
)
if exist ".pytest_cache" rd /s /q ".pytest_cache" >nul 2>&1
for /r "%~dp0" %%F in (*.pyc *.tmp *.bak *.swp) do (
    echo %%~fF | findstr /i /c:"\.venv\" /c:"\venv\" >nul
    if errorlevel 1 if exist "%%F" del /q "%%F" >nul 2>&1
)

rem --- 3. Validate/install dependencies ---
echo [INFO] Validating dependencies (langgraph 1.2.11 stack, Flask, openai) ...
if "%ENV_MODE%"=="project" (
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip >nul
)
"%ENV_PYTHON%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo [ERROR] Dependency installation failed. Check network, then retry.
    pause
    exit /b 1
)

rem --- 3a. Ensure optional-but-critical collection dependency (self-heal regardless of requirements drift) ---
"%ENV_PYTHON%" -c "import playwright" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing playwright for browser-session collection ...
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check "playwright>=1.40,<2.0"
    if errorlevel 1 ( echo [WARN] playwright install failed; browser collection source will be skipped. )
) else (
    echo [OK] playwright available.
)
"%ENV_PYTHON%" -c "import curl_cffi" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing curl_cffi for higher API success rate ...
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check "curl_cffi>=0.7,<0.8"
    if errorlevel 1 ( echo [WARN] curl_cffi install failed; anonymous HTTP source will use plain urllib. )
) else (
    echo [OK] curl_cffi available.
)

rem --- 3b. Native runtime smoke check (Windows App Control / AV may block fresh .pyd files) ---
echo [INFO] Checking native runtime extensions ...
"%ENV_PYTHON%" -c "from uuid_utils.compat import uuid7; from langgraph.checkpoint.base import BaseCheckpointSaver; print('NATIVE_OK')" >nul 2>&1
if errorlevel 1 (
    echo [WARN] Native extension check failed ^(uuid-utils / langgraph^). Reinstalling uuid-utils...
    "%ENV_PYTHON%" -m pip install --force-reinstall --no-cache-dir uuid-utils
    "%ENV_PYTHON%" -c "from uuid_utils.compat import uuid7; from langgraph.checkpoint.base import BaseCheckpointSaver; print('NATIVE_OK')" >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Native extension is blocked by Windows App Control / antivirus.
        echo [INFO] Manual fix: right-click .venv\Lib\site-packages\uuid_utils\_uuid_utils*.pyd - Properties - Unblock,
        echo          or add an allow rule for your .venv folder in your security product.
        echo [INFO] Re-run this script after fixing.
        pause
        exit /b 1
    )
)
echo [OK] Native runtime extensions loaded.

rem --- 4. Static verification ---
echo [INFO] Running static verification (no runtime gate at startup) ...
"%ENV_PYTHON%" "%~dp0verify_install.py"
if errorlevel 1 (
    echo [ERROR] Static verification failed. WebUI will not start.
    pause
    exit /b 1
)
echo [OK] Static verification succeeded.
echo [INFO] Full Runtime Gate is NOT run at startup. Run manually when needed:
echo          "%ENV_PYTHON%" "%~dp0verify_install.py" --runtime

rem --- 5. Start WebUI ---
echo [INFO] Starting WebUI ...
start "PSV Trade OS WebUI" cmd /k ""%ENV_PYTHON%" "%~dp0run_webui.py""

echo [INFO] Waiting for WebUI readiness on http://127.0.0.1:8090 ...
set /a TRIES=0
:wait_loop
"%ENV_PYTHON%" -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8090/', timeout=1).read(1)" >nul 2>&1
if not errorlevel 1 goto :webui_ready
set /a TRIES+=1
if !TRIES! lss 60 (
    timeout /t 1 /nobreak >nul
    goto :wait_loop
)
echo [ERROR] WebUI did not become ready within 60 seconds.
echo [INFO] Keep the WebUI window open and inspect its first Python traceback.
pause
endlocal
exit /b 1

:webui_ready
echo [OK] WebUI is responding at http://127.0.0.1:8090
echo [INFO] Reminder: log in to importyeti.com in the CDP browser before submitting collection tasks.
echo [INFO] Starting AI/CDP browser ...
call "%~dp0start_chrome_debug.bat"
if errorlevel 1 (
    echo [WARN] AI/CDP browser did not start. WebUI is still running.
) else (
    echo [OK] AI/CDP browser startup requested on port 9222.
)
echo [INFO] Python used: %ENV_PYTHON%
echo This launcher window will remain open.
pause
endlocal
