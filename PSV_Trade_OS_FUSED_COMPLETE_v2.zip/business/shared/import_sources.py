"""Shared multi-source import-record loader (local first, IY human-like browser session, IY API, graceful degrade)."""
from __future__ import annotations

import json
import os
import re
import urllib.parse
import urllib.request
from pathlib import Path

_TIMEOUT = 15


def _load_local(market: str, industry: str) -> list:
    m = str(market or "").strip().lower().replace(" ", "_")
    ind = str(industry or "").strip().lower()
    candidates = []
    if m and ind:
        candidates.append(Path("data/imports") / f"{m}_{ind}.json")
    candidates.append(Path("data/imports/records.json"))
    for path in candidates:
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    return [x for x in data if isinstance(x, dict)]
        except Exception:
            continue
    return []


_JS_EXTRACT = """() => {
    const out = []; const seen = new Set();
    const okLine = (t) => {
        t = (t || '').trim();
        if (t.length < 3 || t.length > 80) return false;
        const c0 = t.charCodeAt(0);
        if (c0 < 65 || c0 > 90) return false;
        let letters = 0;
        for (let i = 0; i < t.length; i++) {
            const c = t.charCodeAt(i);
            if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) letters++;
        }
        return letters >= 3;
    };
    const grab = (el) => {
        const raw = (el.innerText || el.textContent || '').split(String.fromCharCode(10));
        for (const line of raw) {
            const t = (line || '').trim();
            if (okLine(t) && !seen.has(t)) { seen.add(t); out.push(t); break; }
        }
    };
    document.querySelectorAll('a[href*="/company/"]').forEach(grab);
    if (out.length === 0) document.querySelectorAll('[class*="company"], [class*="result"] li, table tr td:first-child').forEach(grab);
    if (out.length === 0) document.querySelectorAll('h2, h3, strong').forEach(grab);
    if (out.length === 0) document.querySelectorAll('a').forEach(grab);
    return out.slice(0, 80);
}"""


def _human_search_once(page, query: str, diag: dict) -> list:
    """单查询仿人工操作：聚焦→点框→逐字输入→回车→等渲染→滚动两屏→逐级自适应提取。"""
    import time as _time
    box = page.query_selector('input[type="search"], input[placeholder*="earch"], input[name="q"], input[aria-label*="earch"]')
    if box is None:
        diag["browser_error"] = "no_search_box"
        return []
    box.click()
    box.fill("")
    box.type(query, delay=60)
    page.keyboard.press("Enter")
    try:
        page.wait_for_selector('a[href*="/company/"]', timeout=15000)
    except Exception:
        page.wait_for_timeout(5000)
    found = list(page.evaluate(_JS_EXTRACT) or [])
    for _ in range(2):
        try:
            page.mouse.wheel(0, 900)
            page.wait_for_timeout(1500)
            for name in list(page.evaluate(_JS_EXTRACT) or []):
                if name not in found:
                    found.append(name)
        except Exception:
            break
    diag["browser_error"] = "" if found else diag.get("browser_error", "empty_extraction")
    return found


def _fetch_importyeti_browser(market: str, industry: str, limit: int = 60,
                              queries: list | None = None, diag: dict | None = None) -> list:
    """仿人工浏览器采集主循环：多查询轮询（策略来自方案节点），全程可见（IY_BROWSER_VISIBLE=0 关闭）。"""
    import time as _time
    if diag is None:
        diag = {}
    def _fail(reason: str) -> list:
        diag["browser_error"] = reason
        return []
    if not (queries or industry or market):
        return _fail("empty_query")
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return _fail("playwright_missing")
    try:
        cdp = os.environ.get("OUTLOOK_CDP_URL", "http://127.0.0.1:9222")
        visible = os.environ.get("IY_BROWSER_VISIBLE", "1").strip() != "0"
        with sync_playwright() as pw:
            try:
                browser = pw.chromium.connect_over_cdp(cdp)
            except Exception as exc:
                return _fail(f"cdp_unreachable: {type(exc).__name__}")
            context = browser.contexts[0] if browser.contexts else None
            if context is None:
                return _fail("no_browser_context")
            page = None
            for pg in context.pages:
                if "importyeti.com" in (pg.url or ""):
                    page = pg
                    break
            if page is None:
                page = context.new_page()
                page.goto("https://www.importyeti.com/", timeout=60000)
            if visible:
                try:
                    page.bring_to_front()
                except Exception:
                    visible_failed = True
            seen_names = set()
            out = []
            qi = 0
            for qi, query in enumerate(list(queries or [f"{industry} {market}".strip()])[:4], start=1):
                if len(out) >= limit:
                    break
                names = _human_search_once(page, query, diag)
                for name in names:
                    if name in seen_names or len(out) >= limit:
                        continue
                    seen_names.add(name)
                    out.append({
                        "node_id": f"IYB_{len(out)+1:04d}",
                        "name": name,
                        "role": "buyer",
                        "country": market,
                        "shipments": 0,
                        "industry": industry,
                        "source": "importyeti_browser",
                        "metadata": {"query": query},
                    })
                _time.sleep(1.2)
            if not out:
                return _fail(diag.get("browser_error") or "empty_extraction")
            diag["browser_queries"] = qi
            diag["browser_error"] = ""
            return out
    except Exception as exc:
        return _fail(f"exception: {type(exc).__name__}: {str(exc)[:120]}")


def _fetch_importyeti(market: str, industry: str, diag: dict | None = None) -> list:
    """ImportYeti 公开摘要 API（v45 原版同款端点，匿名免 key，curl_cffi Chrome 指纹优先）。"""
    def _fail(reason: str) -> list:
        if diag is not None:
            diag["http_error"] = reason
        return []
    if str(market).strip().lower() not in ("us", "usa", "united states", "america", "\u7f8e\u56fd", ""):
        return _fail("unsupported_market")
    query = f"{industry}".strip()
    if not query:
        return _fail("empty_query")
    try:
        from core.config.industry import load_industry
        profile = load_industry(industry) or {}
        for word in (profile.get("keywords") or []) + (profile.get("product_terms") or []):
            word = str(word).strip()
            if word and re.search(r"[A-Za-z]", word):
                query = word
                break
    except Exception:
        query = query
    try:
        url = "https://www.importyeti.com/api/search?q=" + urllib.parse.quote(query) + "&page=1"
        payload = None
        try:
            from curl_cffi import requests as creq
            resp = creq.get(url, impersonate="chrome", timeout=_TIMEOUT,
                            headers={"Referer": "https://www.importyeti.com/"})
            if resp.status_code == 200:
                payload = resp.json()
            else:
                return _fail(f"http_{resp.status_code}")
        except ImportError:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
                "Accept": "application/json, text/plain, */*",
                "Referer": "https://www.importyeti.com/",
            })
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                payload = json.loads(resp.read().decode("utf-8", "replace"))
        rows = []
        if isinstance(payload, dict):
            rows = payload.get("searchResults") or payload.get("results") or payload.get("data") or []
        if not isinstance(rows, list) or not rows:
            return _fail("empty_results")
        if diag is not None:
            diag["http_error"] = ""
        out = []
        for idx, item in enumerate(rows[:50], start=1):
            if not isinstance(item, dict):
                continue
            name = item.get("title") or item.get("name") or item.get("companyName") or ""
            name = str(name).strip()
            if len(name) < 2:
                continue
            try:
                shipments = int(item.get("totalShipments") or 0)
            except (TypeError, ValueError):
                shipments = 0
            out.append({
                "node_id": f"IY_{idx:04d}",
                "name": name,
                "role": "buyer",
                "country": "United States",
                "shipments": shipments,
                "industry": industry,
                "source": "importyeti",
                "metadata": {"website": item.get("website") or "", "address": item.get("address") or ""},
            })
        if not out:
            return _fail("no_valid_rows")
        return out
    except Exception as exc:
        return _fail(f"exception: {type(exc).__name__}: {str(exc)[:120]}")


def fetch_comtrade_flows(hs_code: str = "", reporter: str = "USA", partner: str = "World",
                         period: str = "2024", max_records: int = 50) -> list:
    """UN Comtrade 宏观贸易流校验（免费 key，注册即得，免费档 500 次/日）。"""
    key = os.environ.get("COMTRADE_API_KEY", "").strip()
    if not key or not hs_code:
        return []
    try:
        url = (
            "https://comtradeapi.un.org/public/v1/preview/C/A/HS"
            f"?reporterCode={reporter}&partnerCode={partner}&period={period}"
            f"&cmdCode={hs_code}&maxRecords={max_records}"
        )
        req = urllib.request.Request(url, headers={"Ocp-Apim-Subscription-Key": key, "User-Agent": "PSV-Trade-OS/9.4"})
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            payload = json.loads(resp.read().decode("utf-8", "replace"))
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            return []
        return [{
            "reporter": item.get("reporterDesc", ""),
            "partner": item.get("partnerDesc", ""),
            "flow": item.get("flowDesc", ""),
            "hs": item.get("cmdCode", ""),
            "value_usd": item.get("primaryValue", 0),
            "period": item.get("period", ""),
        } for item in data[:max_records] if isinstance(item, dict)]
    except Exception:
        return []


def load_import_records_diag(market: str = "", industry: str = "", queries: list | None = None) -> tuple:
    """级联加载并返回各源条数诊断：本地 → 浏览器会话(仿人工多查询) → 匿名HTTP。"""
    diag = {"local": 0, "browser": 0, "http": 0, "used": "none"}
    records = _load_local(market, industry)
    diag["local"] = len(records)
    if records:
        diag["used"] = "local"
        return records, diag
    if os.environ.get("IY_BROWSER_ENABLED", "1").strip() == "1":
        browser_records = _fetch_importyeti_browser(market, industry, diag=diag, queries=queries) or []
        diag["browser"] = len(browser_records)
        if browser_records:
            diag["used"] = "browser"
            return browser_records, diag
    if os.environ.get("IY_FETCH_ENABLED", "1").strip() == "1":
        http_records = _fetch_importyeti(market, industry, diag=diag) or []
        diag["http"] = len(http_records)
        if http_records:
            diag["used"] = "http"
            return http_records, diag
    return [], diag


def load_import_records(market: str = "", industry: str = "") -> list:
    """多源级联：本地文件 → IY 已登录浏览器会话 → IY 匿名 HTTP → 空（由节点合成回退）。"""
    records, _ = load_import_records_diag(market, industry)
    return records
