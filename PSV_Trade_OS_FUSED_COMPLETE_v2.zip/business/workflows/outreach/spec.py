"""Outreach workflow spec - planning and contracts only, no logic."""
from __future__ import annotations

from core.contracts.nodes import ContractDefinition

WORKFLOW_ID = "outreach"
WORKFLOW_VERSION = "9.4.0"
PAYLOAD_KEYS = {
    "mission": ("mission",),
    "outreach_planning": ("fragments",),
    "lead_selection": ("trade_nodes",),
    "profile_enrichment": ("entities", "evidence_pool"),
    "qualification": ("decisions", "trade_nodes"),
    "letter_composition": ("evidence_pool", "decisions"),
    "draft_review": ("evidence_pool",),
    "database_commit": ("node_reports",),
}
NODE_IDS = (
    "OUTREACH_PLAN", "LEAD_SELECTION", "PROFILE_ENRICHMENT", "QUALIFICATION",
    "LETTER_COMPOSITION", "DRAFT_REVIEW_GATE", "OUTREACH_SEND", "DATABASE_COMMIT",
)
NODE_SPECS = {
    "OUTREACH_PLAN": {"node_id": "OUTREACH_PLAN", "responsibility": "Plan lead criteria, letter standards and sender profile from the mission.", "capabilities": ("mission_understanding", "outreach_planning")},
    "LEAD_SELECTION": {"node_id": "LEAD_SELECTION", "responsibility": "Select candidate leads by standard (pool first, standard synthesis as fallback).", "capabilities": ("lead_selection",)},
    "PROFILE_ENRICHMENT": {"node_id": "PROFILE_ENRICHMENT", "responsibility": "Aggregate evidence into lead profiles.", "capabilities": ("profile_enrichment",)},
    "QUALIFICATION": {"node_id": "QUALIFICATION", "responsibility": "Loose qualification by rule score; AI may veto, degradation-safe.", "capabilities": ("qualification", "ai_assisted")},
    "LETTER_COMPOSITION": {"node_id": "LETTER_COMPOSITION", "responsibility": "Compose personalized development letters with AI, template fallback.", "capabilities": ("letter_composition", "ai_assisted")},
    "DRAFT_REVIEW_GATE": {"node_id": "DRAFT_REVIEW_GATE", "responsibility": "Rule review gate (length/placeholder/banned words); revise via safe template.", "capabilities": ("draft_review",)},
    "OUTREACH_SEND": {"node_id": "OUTREACH_SEND", "responsibility": "Auto-send reviewed letters via the injected mail sender; degrade to skipped when unconfigured.", "capabilities": ("auto_send",)},
    "DATABASE_COMMIT": {"node_id": "DATABASE_COMMIT", "responsibility": "Persist qualified leads and development letters.", "capabilities": ("database_commit", "database_write")},
}
CONTRACTS = (
    ContractDefinition("OUTREACH_PLAN", ("mission",), ("fragments", "product_definition"), "Plan outreach from mission inputs.", "Outreach plan is available.", "Outreach plan cannot be established."),
    ContractDefinition("LEAD_SELECTION", ("fragments",), ("trade_nodes",), "Select standard candidate leads.", "Candidate leads are available.", "Lead selection cannot complete."),
    ContractDefinition("PROFILE_ENRICHMENT", ("fragments",), ("entities", "evidence_pool"), "Enrich lead profiles from evidence.", "Lead profiles are available.", "Profile enrichment cannot complete."),
    ContractDefinition("QUALIFICATION", ("entities", "fragments"), ("decisions", "trade_nodes"), "Qualify leads by loose rules.", "Qualification results are available.", "Qualification cannot complete."),
    ContractDefinition("LETTER_COMPOSITION", ("entities", "fragments"), ("evidence_pool", "decisions"), "Compose development letters.", "Draft letters are available.", "Letter composition cannot complete."),
    ContractDefinition("DRAFT_REVIEW_GATE", ("evidence_pool",), ("evidence_pool", "decisions"), "Review drafts against letter standards.", "Reviewed letters are available.", "Draft review cannot complete."),
    ContractDefinition("OUTREACH_SEND", ("evidence_pool",), ("decisions",), "Send reviewed letters through the mail sender channel.", "Letters are dispatched or explicitly skipped.", "Letter dispatch cannot complete."),
    ContractDefinition("DATABASE_COMMIT", ("evidence_pool",), ("node_reports",), "Persist leads and letters.", "Outreach results are committed.", "Outreach results cannot be committed.", side_effects=("database_write",), database_write_authority=True),
)
CAPABILITIES = ("mission_understanding", "outreach_planning", "lead_selection", "profile_enrichment", "qualification", "letter_composition", "draft_send", "database_commit", "database_write", "ai_assisted")
