"""Outreach nodes - AI-assisted development-letter pipeline with rule fallback.

业务与编排解耦：仅依赖 core.contracts；AI 经 decision provider 注入，任何 AI 失败
自动降级为确定性规则/模板，保证流程先跑通。
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping

from core.contracts.context import get_data_provider, get_decision_provider, get_mail_sender
from core.contracts.state import TaskState
from business.shared.text_utils import market_name as _market_name, hs_chapter as _hs_chapter

_STD_ROLES = {"buyer", "supplier", "importer", "exporter"}
_BANNED_WORDS = ("guarantee", "100%", "free money", "urgent", "risk-free")


def _plan(state: Mapping[str, Any]) -> Mapping[str, Any]:
    for f in state.get("fragments", []) or []:
        if isinstance(f, Mapping) and f.get("plan") == "outreach":
            return f
    return {}


def _ai_decide(state: Mapping[str, Any], decision_type: str, prompt: str) -> Mapping[str, Any]:
    """AI 决策统一入口：provider 缺失或异常时返回空 dict（调用方走规则降级）。"""
    try:
        provider = get_decision_provider()
        decide = getattr(provider, "decide", None)
        if not callable(decide):
            return {}
        outcome = decide(state, decision_type, prompt, {})
        return (outcome or {}) if isinstance(outcome, Mapping) else {}
    except Exception:
        return {}


def _template_letter(lead: Mapping[str, Any], plan: Mapping[str, Any]) -> dict:
    name = str(lead.get("canonical_name") or lead.get("name") or "there")
    industry = str(lead.get("industry") or "your industry")
    product = str(plan.get("our_product") or "our products")
    return {
        "subject": f"Supplier partnership for {industry} - {product}",
        "body": (
            f"Dear {name} team,\n\n"
            f"We are a manufacturer supplying {product}. Noting your activity in {industry}, "
            f"we would like to explore a supply partnership and share our catalog and quotations.\n\n"
            f"May I send you our product list for review?\n\n"
            f"Best regards,\n{plan.get('sender_name', 'Sales Team')}\n{plan.get('sender_company', 'Our Company')}"
        ),
    }


def OUTREACH_PLAN(state: TaskState) -> TaskState:
    """方案规划：潜客标准 + 开发信标准 + 发送人档案（与执行分离）。"""
    result = deepcopy(state)
    mission = result.get("mission") if isinstance(result.get("mission"), Mapping) else {}
    request = str(mission.get("request", "") or "")
    market = _market_name(mission.get("market", "")) or "United States"
    industry = str(mission.get("industry", "")).strip() or "general"
    words = [w.strip(".,;:!?").lower() for w in request.split()]
    _noise = ("\u91c7\u96c6", "\u6d77\u5173", "\u6570\u636e", "\u56fe\u8c31", "\u5ba2\u6237\u5173\u7cfb", "\u5e76\u6784\u5efa", "procurement", "purchasing", "buyer", "supplier")
    keywords = sorted({w for w in words if len(w) >= 2 and not any(x in w for x in _noise)})[:8]
    result["product_definition"] = {
        "product_name": keywords[0] if keywords else industry,
        "keywords": keywords, "market": market, "industry": industry,
        "target_customer_type": "qualified_leads",
    }
    result["fragments"] = [{
        "plan": "outreach",
        "lead_criteria": {"roles": sorted(_STD_ROLES), "min_shipments": 5, "keywords": keywords, "market": market},
        "letter_standard": {"language": "en", "min_chars": 80, "max_chars": 1500, "banned_words": list(_BANNED_WORDS)},
        "sender_name": "Sales Team",
        "sender_company": "Our Company",
        "our_product": keywords[0] if keywords else "relevant products",
    }]
    return result


def LEAD_SELECTION(state: TaskState) -> TaskState:
    """业务执行：候选潜客（节点池 > 标准合成）。"""
    result = deepcopy(state)
    plan = _plan(result)
    criteria = plan.get("lead_criteria") if isinstance(plan.get("lead_criteria"), Mapping) else {}
    min_ship = int(criteria.get("min_shipments", 5) or 5)
    pool = [n for n in result.get("trade_nodes", []) if isinstance(n, Mapping)
            and str(n.get("role", "")).lower() in _STD_ROLES and int(n.get("shipments", 0) or 0) >= min_ship]
    pool.sort(key=lambda n: int(n.get("shipments", 0) or 0), reverse=True)
    leads = pool[:3]
    if not leads:
        product = result.get("product_definition") if isinstance(result.get("product_definition"), Mapping) else {}
        market = str(product.get("market", "United States"))
        industry = str(product.get("industry", "general"))
        leads = [
            {"node_id": "LEAD_001", "name": f"{market} {industry} Lead A".strip(), "role": "buyer", "country": market,
             "industry": industry, "shipments": 20, "source": "synthetic", "metadata": {"lead": True}},
            {"node_id": "LEAD_002", "name": f"{market} {industry} Lead B".strip(), "role": "importer", "country": market,
             "industry": industry, "shipments": 12, "source": "synthetic", "metadata": {"lead": True}},
        ]
    existing = {str(n.get("node_id")) for n in result.get("trade_nodes", [])}
    nodes = list(result.get("trade_nodes", []))
    for lead in leads:
        lid = str(lead.get("node_id"))
        if lid in existing:
            for n in nodes:
                if str(n.get("node_id")) == lid and isinstance(n.get("metadata"), Mapping):
                    n["metadata"] = dict(n["metadata"], lead=True)
            continue
        node = dict(lead)
        node["metadata"] = dict(node.get("metadata") or {}, lead=True)
        nodes.append(node)
        existing.add(lid)
    result["trade_nodes"] = nodes
    return result


def PROFILE_ENRICHMENT(state: TaskState) -> TaskState:
    """业务执行：按证据汇总潜客画像（确定性，补齐阶段不接 AI）。"""
    result = deepcopy(state)
    evidence = [e for e in result.get("evidence_pool", []) if isinstance(e, Mapping)]
    entities = []
    for node in result.get("trade_nodes", []):
        if not isinstance(node, Mapping) or not (node.get("metadata") or {}).get("lead"):
            continue
        name = str(node.get("name", ""))
        related = [e for e in evidence if str(e.get("entity_name", "")) == name]
        entities.append({
            "entity_id": str(node.get("node_id")),
            "canonical_name": name,
            "country": str(node.get("country", "")),
            "industry": str(node.get("industry", "")),
            "shipments": int(node.get("shipments", 0) or 0),
            "profile": {
                "evidence_count": len(related),
                "sources": sorted({str(e.get("source", "")) for e in related})[:5],
                "role": str(node.get("role", "")),
            },
        })
    result["entities"] = entities
    return result


def QUALIFICATION(state: TaskState) -> TaskState:
    """业务执行：宽松资格判断（规则评分 >=50 合格；AI 仅可否决，异常忽略）。"""
    result = deepcopy(state)
    plan = _plan(result)
    criteria = plan.get("lead_criteria") if isinstance(plan.get("lead_criteria"), Mapping) else {}
    keywords = set(criteria.get("keywords") or [])
    market = str(criteria.get("market", ""))
    min_ship = int(criteria.get("min_shipments", 5) or 5)

    decisions = list(result.get("decisions", []))
    nodes = list(result.get("trade_nodes", []))
    for entity in result.get("entities", []):
        if not isinstance(entity, Mapping):
            continue
        score, reasons = 0, []
        if int(entity.get("shipments", 0) or 0) >= min_ship:
            score += 20; reasons.append("shipments")
        if (entity.get("profile") or {}).get("evidence_count", 0) >= 1:
            score += 30; reasons.append("evidence")
        if keywords and any(k in str(entity.get("canonical_name", "")).lower() for k in keywords):
            score += 30; reasons.append("product_match")
        if market and _market_name(entity.get("country")) == market:
            score += 20; reasons.append("market")
        qualified = score >= 50
        ai_out = _ai_decide(result, "lead_qualification",
                            f"Lead: {entity.get('canonical_name')} ({entity.get('country')}, {entity.get('industry')}). "
                            f"Rule score {score}/100. Should we send a development letter? Return a JSON object with a boolean field 'qualified'.")
        ai_decision = (ai_out.get("decision") or {}) if ai_out else {}
        if ai_decision.get("qualified") is False:
            qualified = False
            reasons.append("ai_veto")
        for node in nodes:
            if str(node.get("node_id")) == str(entity.get("entity_id")) and isinstance(node.get("metadata"), Mapping):
                node["metadata"] = dict(node["metadata"], qualified=qualified, qual_score=score)
        decisions.append({"decision_type": "lead_qualification",
                          "decision": {"lead": entity.get("canonical_name"), "score": score,
                                       "qualified": qualified, "reasons": reasons},
                          "confidence": (ai_out.get("confidence") if ai_out else None) or 0.6})
    result["decisions"] = decisions
    result["trade_nodes"] = nodes
    return result


def LETTER_COMPOSITION(state: TaskState) -> TaskState:
    """业务执行：AI 撰写个性化开发信；AI 不可用/失败 -> 安全模板（标记 composed_by）。"""
    result = deepcopy(state)
    plan = _plan(result)
    qualified = {str(n.get("node_id")): n for n in result.get("trade_nodes", [])
                 if isinstance(n, Mapping) and (n.get("metadata") or {}).get("qualified")}
    evidence = [e for e in result.get("evidence_pool", []) if isinstance(e, Mapping)]
    existing_ids = {str(e.get("evidence_id")) for e in evidence}
    decisions = list(result.get("decisions", []))
    entities = {str(e.get("entity_id")): e for e in result.get("entities", []) if isinstance(e, Mapping)}
    serial = len(existing_ids)
    for node_id, node in qualified.items():
        entity = entities.get(node_id, {})
        lead_name = str(entity.get("canonical_name") or node.get("name"))
        prompt = (
            f"Write a personalized English business development email.\n"
            f"Customer: {lead_name}, {entity.get('country', '')}, {entity.get('industry', '')}, shipments={entity.get('shipments', 0)}.\n"
            f"Sender: {plan.get('sender_name', 'Sales Team')} at {plan.get('sender_company', 'Our Company')}, "
            f"product: {plan.get('our_product', 'relevant products')}.\n"
            f"Requirements: natural, professional, concise, clear call-to-action, no hype words. "
            f"Return a JSON object with string fields 'subject' and 'body' in English."
        )
        ai_out = _ai_decide(result, "development_letter", prompt)
        ai_decision = (ai_out.get("decision") or {}) if ai_out else {}
        subject = str(ai_decision.get("subject", "")).strip()
        body = str(ai_decision.get("body", "")).strip()
        composed_by = "ai"
        if len(body) < 40:
            fallback = _template_letter({"canonical_name": lead_name, "industry": entity.get("industry")}, plan)
            subject, body, composed_by = fallback["subject"], fallback["body"], "template"
        serial += 1
        eid = f"LETTER_{serial:03d}"
        if eid in existing_ids:
            continue
        evidence.append({
            "evidence_id": eid, "entity_name": lead_name, "evidence_type": "development_letter",
            "source": str(node.get("source", "outreach")), "shipments": 0, "verified": False,
            "evidence_json": {"lead_node_id": node_id, "subject": subject, "body": body,
                              "language": "en", "composed_by": composed_by, "review_status": "pending",
                              "recipient": str((node.get("metadata") or {}).get("email")
                                               or (node.get("metadata") or {}).get("contact") or "")},
        })
        existing_ids.add(eid)
        decisions.append({"decision_type": "development_letter",
                          "decision": {"lead": lead_name, "composed_by": composed_by},
                          "confidence": (ai_out.get("confidence") if ai_out else None) or 0.5})
    result["evidence_pool"] = evidence
    result["decisions"] = decisions
    return result


def DRAFT_REVIEW_GATE(state: TaskState) -> TaskState:
    """业务执行：规则审查门（长度/占位符/违禁词），不合格回退安全模板。"""
    result = deepcopy(state)
    plan = _plan(result)
    std = plan.get("letter_standard") if isinstance(plan.get("letter_standard"), Mapping) else {}
    min_chars = int(std.get("min_chars", 80) or 80)
    max_chars = int(std.get("max_chars", 1500) or 1500)
    banned = tuple(std.get("banned_words") or _BANNED_WORDS)
    for item in result.get("evidence_pool", []):
        if not isinstance(item, Mapping) or item.get("evidence_type") != "development_letter":
            continue
        payload = item.get("evidence_json") if isinstance(item.get("evidence_json"), Mapping) else {}
        body = str(payload.get("body", ""))
        subject = str(payload.get("subject", ""))
        issues = []
        if not (min_chars <= len(body) <= max_chars):
            issues.append("length")
        if "{" in body or "}" in body or not subject:
            issues.append("placeholder_or_subject")
        if any(w in body.lower() for w in banned):
            issues.append("banned_word")
        if issues:
            safe = _template_letter({"canonical_name": item.get("entity_name"), "industry": ""}, plan)
            payload = dict(payload, subject=safe["subject"], body=safe["body"],
                           review_status="revised", review_issues=issues)
        else:
            payload = dict(payload, review_status="passed", review_issues=[])
        item["evidence_json"] = payload
    return result


def DATABASE_COMMIT(state: TaskState) -> TaskState:
    """数据持久化：合格潜客与开发信经 data provider 落库。"""
    result = deepcopy(state)
    database = get_data_provider()
    if not callable(getattr(database, "commit_trade_data", None)):
        raise RuntimeError("DATABASE_COMMIT runtime database gateway is invalid")
    task_id = str(result.get("task_id", "")).strip()
    if not task_id:
        raise ValueError("DATABASE_COMMIT requires state['task_id']")
    qualified = [{
        "entity_id": str(n.get("node_id")),
        "canonical_name": str(n.get("name", "")),
        "role": str(n.get("role", "")),
        "country": str(n.get("country", "")),
        "source": str(n.get("source", "outreach")),
        "metadata": dict(n.get("metadata") or {}),
    } for n in result.get("trade_nodes", [])
        if isinstance(n, Mapping) and (n.get("metadata") or {}).get("qualified")]
    letters, other_evidence = [], []
    for item in result.get("evidence_pool", []):
        if not isinstance(item, Mapping):
            continue
        if item.get("evidence_type") == "development_letter":
            payload = item.get("evidence_json") if isinstance(item.get("evidence_json"), Mapping) else {}
            letters.append({
                "letter_id": str(item.get("evidence_id")),
                "lead_node_id": str(payload.get("lead_node_id", "")),
                "entity_name": str(item.get("entity_name", "")),
                "subject": payload.get("subject"),
                "body": payload.get("body"),
                "review_status": payload.get("review_status"),
                "composed_by": payload.get("composed_by"),
                "language": payload.get("language", "en"),
                "send_status": payload.get("send_status"),
                "send_reason": payload.get("send_reason"),
                "sent_at": payload.get("sent_at"),
            })
        else:
            other_evidence.append(item)
    counts = {}
    commit_letters = getattr(database, "commit_outreach_letters", None)
    if callable(commit_letters) and letters:
        counts.update(commit_letters(task_id, letters) or {})
    counts.update(database.commit_trade_data(task_id, qualified, [], other_evidence) or {})
    reports = dict(result.get("node_reports", {}))
    reports["DATABASE_COMMIT"] = {"status": "committed", "authority": True, "report": dict(counts or {})}
    result["node_reports"] = reports
    return result


def OUTREACH_SEND(state: TaskState) -> TaskState:
    """业务执行：审查通过的信件经注入的 mail sender 自动发送。

    无发送通道/无收件人/发送失败均降级为 skipped/failed 记录，绝不让
    投递基础设施阻塞流程（开发与解耦边界：业务只依赖 MailSender 协议）。
    """
    result = deepcopy(state)
    sender = get_mail_sender()
    decisions = list(result.get("decisions", []))
    sent = skipped = failed = 0
    for item in result.get("evidence_pool", []):
        if not isinstance(item, Mapping) or item.get("evidence_type") != "development_letter":
            continue
        payload = item.get("evidence_json") if isinstance(item.get("evidence_json"), Mapping) else {}
        if payload.get("review_status") != "passed":
            payload = dict(payload, send_status="skipped", send_reason="review_not_passed")
            item["evidence_json"] = payload
            skipped += 1
            continue
        recipient = str(payload.get("recipient", "") or "").strip()
        if sender is None:
            payload = dict(payload, send_status="skipped", send_reason="no_mail_sender")
            item["evidence_json"] = payload
            skipped += 1
            continue
        try:
            outcome = sender.send_letter({
                "letter_id": str(item.get("evidence_id")),
                "recipient": recipient,
                "entity_name": str(item.get("entity_name", "")),
                "subject": payload.get("subject"),
                "body": payload.get("body"),
            }) or {}
        except Exception as exc:  # 投递异常不得阻塞流程
            outcome = {"status": "failed", "reason": f"sender_error: {exc}"}
        status = str(outcome.get("status", "failed"))
        payload = dict(payload, send_status=status, send_reason=outcome.get("reason", ""),
                       sent_at=outcome.get("sent_at", ""))
        item["evidence_json"] = payload
        sent += int(status == "sent")
        failed += int(status == "failed")
        decisions.append({"decision_type": "outreach_send",
                          "decision": {"letter_id": item.get("evidence_id"), "entity_name": item.get("entity_name"),
                                       "status": status, "reason": payload.get("send_reason", "")},
                          "confidence": 1.0 if status == "sent" else 0.5})
    result["decisions"] = decisions
    reports = dict(result.get("node_reports", {}))
    reports["OUTREACH_SEND"] = {"status": "ok", "sent": sent, "skipped": skipped, "failed": failed}
    result["node_reports"] = reports
    return result


_NODE_FUNCTIONS = {
    "OUTREACH_PLAN": OUTREACH_PLAN,
    "LEAD_SELECTION": LEAD_SELECTION,
    "PROFILE_ENRICHMENT": PROFILE_ENRICHMENT,
    "QUALIFICATION": QUALIFICATION,
    "LETTER_COMPOSITION": LETTER_COMPOSITION,
    "DRAFT_REVIEW_GATE": DRAFT_REVIEW_GATE,
    "OUTREACH_SEND": OUTREACH_SEND,
    "DATABASE_COMMIT": DATABASE_COMMIT,
}


def get_node_function(node_id: str):
    return _NODE_FUNCTIONS.get(node_id)
