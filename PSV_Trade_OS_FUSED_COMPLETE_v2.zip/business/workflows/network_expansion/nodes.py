"""Network expansion nodes - planning -> seeds -> fan-out -> standard filter -> commit.

业务与编排解耦：仅依赖 core.contracts；数据源为本地导入记录（缺失时确定性合成）。
"""
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping

from core.contracts.context import get_data_provider
from core.contracts.state import TaskState
from business.shared.text_utils import market_name as _market_name, hs_chapter as _hs_chapter

_STD_ROLES = {"buyer", "supplier", "importer", "exporter"}
_HOP_LIMIT = 2
_MAX_NODES = 40
_MAX_EDGES = 60


def _load_records(state: Mapping) -> list:
    """多源加载：本地 imports 优先，IY 联网抓取兜底（共享加载器，任何失败降级为空）。"""
    product = state.get("product_definition") if isinstance(state.get("product_definition"), Mapping) else {}
    from business.shared.import_sources import load_import_records
    return load_import_records(str(product.get("market", "")), str(product.get("industry", "")))

def _std_node(node_id, name, role, country, industry, shipments, source, meta) -> dict:
    return {
        "node_id": str(node_id), "name": str(name).strip(), "role": str(role).lower(),
        "country": _market_name(country) or "Unknown", "industry": str(industry).strip(),
        "shipments": int(shipments or 0), "source": str(source), "metadata": dict(meta),
    }


def _is_standard(item: Mapping) -> bool:
    name = str(item.get("name", "")).strip()
    if len(name) < 2 or name.lower() in {"unknown", "n/a", "null"}:
        return False
    return str(item.get("role", "")).strip().lower() in _STD_ROLES


def EXPANSION_PLAN(state: TaskState) -> TaskState:
    """方案规划：由需求确立扩张标准，与执行分离。"""
    result = deepcopy(state)
    mission = result.get("mission") if isinstance(result.get("mission"), Mapping) else {}
    request = str(mission.get("request", "") or "")
    market = _market_name(mission.get("market", "")) or "United States"
    industry = str(mission.get("industry", "")).strip() or "general"
    words = [w.strip(".,;:!?").lower() for w in request.split()]
    _noise = ("\u91c7\u96c6", "\u6d77\u5173", "\u6570\u636e", "\u56fe\u8c31", "\u5ba2\u6237\u5173\u7cfb", "\u5e76\u6784\u5efa", "procurement", "purchasing", "buyer", "supplier")
    keywords = sorted({w for w in words if len(w) >= 2 and not any(x in w for x in _noise)})[:8]
    result["product_definition"] = {
        "product_name": keywords[0] if keywords else (industry or "target product"),
        "keywords": keywords, "hs_code_guess": "", "market": market, "industry": industry,
        "target_customer_type": "trade_network",
    }
    result["fragments"] = [{
        "plan": "expansion", "target_market": market, "industry": industry,
        "hop_limit": _HOP_LIMIT, "seed_count": 3, "keywords": keywords,
    }]
    return result


def SEED_SELECTION(state: TaskState) -> TaskState:
    """业务执行：选定种子节点（现有 trade_nodes > 本地记录 > 标准合成）。"""
    result = deepcopy(state)
    product = result.get("product_definition") if isinstance(result.get("product_definition"), Mapping) else {}
    market = _market_name(product.get("market", "")) or "United States"
    industry = str(product.get("industry", "")).strip()
    keywords = set(product.get("keywords") or [])

    seeds = [n for n in result.get("trade_nodes", [])
             if isinstance(n, Mapping) and (n.get("metadata") or {}).get("seed")]
    if not seeds:
        records = sorted(_load_records(result), key=lambda r: int(r.get("shipments") or 0), reverse=True)
        seeds = []
        for i, r in enumerate(records, start=1):
            if len(seeds) >= 3 or not _is_standard(r):
                continue
            meta = r.get("metadata") if isinstance(r.get("metadata"), Mapping) else {}
            seeds.append(_std_node(
                r.get("node_id") or f"SEED_{i:03d}", r.get("name") or r.get("company") or "",
                r.get("role") or "buyer", r.get("country") or market,
                r.get("industry") or industry, r.get("shipments") or 0,
                r.get("source") or "local_import",
                {"hop": 0, "seed": True, "hs_chapter": _hs_chapter(meta.get("hs_code")),
                 "keywords": [k for k in keywords if k in str(r.get("name", "")).lower()][:3]}))
    if not seeds:
        seeds = [
            _std_node("SEED_001", f"{market} {industry} Buyer Anchor".strip(), "buyer", market, industry, 20, "synthetic", {"hop": 0, "seed": True, "hs_chapter": "", "keywords": sorted(keywords)[:3]}),
            _std_node("SEED_002", f"{market} {industry} Supplier Anchor".strip(), "supplier", "China", industry, 30, "synthetic", {"hop": 0, "seed": True, "hs_chapter": "", "keywords": sorted(keywords)[:3]}),
        ]

    existing = {str(n.get("node_id")) for n in result.get("trade_nodes", [])}
    nodes = list(result.get("trade_nodes", []))
    for seed in seeds:
        if seed["node_id"] not in existing:
            nodes.append(seed)
            existing.add(seed["node_id"])
    result["trade_nodes"] = nodes[:_MAX_NODES]
    return result


def RELATION_FANOUT(state: TaskState) -> TaskState:
    """业务执行：沿种子多跳扇出（共享行业/HS/市场信号），产出邻居与扩张边。"""
    result = deepcopy(state)
    plan = {}
    for f in result.get("fragments", []):
        if isinstance(f, Mapping) and f.get("plan") == "expansion":
            plan = f
    hop_limit = int(plan.get("hop_limit", _HOP_LIMIT) or _HOP_LIMIT)
    market = _market_name((result.get("product_definition") or {}).get("market", "")) or "United States"
    industry = str((result.get("product_definition") or {}).get("industry", "")).strip()
    records = _load_records(result)

    nodes = [dict(n) for n in result.get("trade_nodes", [])]
    edges = [dict(e) for e in result.get("relationships", []) if isinstance(e, Mapping)]
    node_ids = {str(n.get("node_id")) for n in nodes}
    edge_keys = {(str(e.get("source")), str(e.get("target"))) for e in edges}
    serial = len(nodes)

    frontier = [n for n in nodes if (n.get("metadata") or {}).get("seed")]
    for hop in range(1, hop_limit + 1):
        next_frontier = []
        for parent in frontier:
            if len(nodes) >= _MAX_NODES or len(edges) >= _MAX_EDGES:
                break
            p_meta = parent.get("metadata") if isinstance(parent.get("metadata"), Mapping) else {}
            p_ind = str(parent.get("industry", "")).lower()
            p_hs = str(p_meta.get("hs_chapter", ""))
            p_country = str(parent.get("country", ""))
            matched = []
            for r in records:
                if not _is_standard(r):
                    continue
                rid = str(r.get("node_id") or r.get("name"))
                if rid in node_ids:
                    continue
                r_meta = r.get("metadata") if isinstance(r.get("metadata"), Mapping) else {}
                r_hs = _hs_chapter(r_meta.get("hs_code"))
                signals = int(bool(p_ind and str(r.get("industry", "")).lower() == p_ind)) \
                    + int(bool(p_hs and r_hs == p_hs)) \
                    + int(_market_name(r.get("country")) == p_country)
                if signals >= 1:
                    matched.append((signals, r, r_hs, r_meta))
            matched.sort(key=lambda x: (x[0], int(x[1].get("shipments") or 0)), reverse=True)
            picked = 0
            for signals, r, r_hs, r_meta in matched[:4]:
                if len(nodes) >= _MAX_NODES or len(edges) >= _MAX_EDGES:
                    break
                nid = str(r.get("node_id") or f"EXP_{serial + 1:03d}")
                if nid in node_ids:
                    continue
                serial += 1
                by = []
                if p_ind and str(r.get("industry", "")).lower() == p_ind:
                    by.append("industry")
                if p_hs and r_hs == p_hs:
                    by.append("hs_chapter")
                if _market_name(r.get("country")) == p_country:
                    by.append("country")
                node = _std_node(nid, r.get("name") or r.get("company") or "", r.get("role") or "buyer",
                                 r.get("country") or market, r.get("industry") or industry,
                                 r.get("shipments") or 0, r.get("source") or "local_import",
                                 {"hop": hop, "seed": False, "seed_ref": parent.get("node_id"),
                                  "hs_chapter": r_hs, "matched_by": by})
                nodes.append(node)
                node_ids.add(nid)
                key = (str(parent.get("node_id")), nid)
                if key not in edge_keys:
                    edges.append({"edge_id": f"EXP_EDGE_{len(edges) + 1:03d}", "source": key[0],
                                  "target": key[1], "relation_type": "network_expansion",
                                  "confidence": round(0.5 + 0.1 * signals, 2), "evidence_ids": []})
                    edge_keys.add(key)
                next_frontier.append(node)
                picked += 1
            if picked == 0 and hop < hop_limit:
                for k in range(2):
                    if len(nodes) >= _MAX_NODES or len(edges) >= _MAX_EDGES:
                        break
                    serial += 1
                    nid = f"EXP_SYN_{serial:03d}"
                    node = _std_node(nid, f"{parent['name']} Partner {k + 1}",
                                     "supplier" if parent.get("role") == "buyer" else "buyer",
                                     "China" if parent.get("country") == market else market,
                                     str(parent.get("industry") or industry), 5 + k, "synthetic",
                                     {"hop": hop, "seed": False, "seed_ref": parent.get("node_id"),
                                      "matched_by": ["synthetic_fanout"]})
                    nodes.append(node)
                    node_ids.add(nid)
                    key = (str(parent.get("node_id")), nid)
                    if key not in edge_keys:
                        edges.append({"edge_id": f"EXP_EDGE_{len(edges) + 1:03d}", "source": key[0],
                                      "target": key[1], "relation_type": "network_expansion",
                                      "confidence": 0.4, "evidence_ids": []})
                        edge_keys.add(key)
                    next_frontier.append(node)
        frontier = next_frontier[:6]

    result["trade_nodes"] = nodes[:_MAX_NODES]
    result["relationships"] = edges[:_MAX_EDGES]
    return result


def EXPANSION_FILTER(state: TaskState) -> TaskState:
    """业务执行：宽松判断 + 标准化；仅保留标准节点/边，碎片不保留。"""
    result = deepcopy(state)
    product = result.get("product_definition") if isinstance(result.get("product_definition"), Mapping) else {}
    market = _market_name(product.get("market", "")) or "United States"
    industry = str(product.get("industry", "")).strip().lower()

    kept, seen = [], set()
    for node in result.get("trade_nodes", []):
        if not isinstance(node, Mapping) or not _is_standard(node):
            continue
        nid = str(node.get("node_id"))
        if nid in seen:
            continue
        meta = node.get("metadata") if isinstance(node.get("metadata"), Mapping) else {}
        hop = int(meta.get("hop", 0) or 0)
        matched = list(meta.get("matched_by") or [])
        if hop and not matched and str(node.get("industry", "")).lower() != industry \
                and _market_name(node.get("country")) != market:
            continue
        seen.add(nid)
        node["metadata"] = {k: v for k, v in meta.items()
                            if k in ("hop", "seed", "seed_ref", "hs_chapter", "keywords", "matched_by")}
        kept.append(node)

    node_ids = {str(n.get("node_id")) for n in kept}
    edges = [dict(e) for e in result.get("relationships", [])
             if isinstance(e, Mapping) and str(e.get("source")) in node_ids and str(e.get("target")) in node_ids]

    evidence = [e for e in result.get("evidence_pool", []) if isinstance(e, Mapping)]
    have = {str(e.get("evidence_id")) for e in evidence}
    for i, node in enumerate(kept, start=1):
        eid = f"EXP_EVIDENCE_{i:03d}"
        if eid in have:
            continue
        meta = node.get("metadata") if isinstance(node.get("metadata"), Mapping) else {}
        evidence.append({
            "evidence_id": eid, "entity_name": str(node.get("name", "")),
            "evidence_type": "expansion_record", "source": str(node.get("source", "expansion")),
            "shipments": int(node.get("shipments", 0) or 0), "verified": False,
            "evidence_json": {"node_id": node.get("node_id"), "hop": meta.get("hop", 0),
                              "seed_ref": meta.get("seed_ref", ""),
                              "matched_by": list(meta.get("matched_by") or [])},
        })
        have.add(eid)

    result["trade_nodes"] = kept
    result["relationships"] = edges
    result["evidence_pool"] = evidence
    result["fragments"] = []
    return result


def DATABASE_COMMIT(state: TaskState) -> TaskState:
    """数据持久化：标准节点/关系/证据经 data provider 落库。"""
    result = deepcopy(state)
    database = get_data_provider()
    if not callable(getattr(database, "commit_trade_data", None)):
        raise RuntimeError("DATABASE_COMMIT runtime database gateway is invalid")
    task_id = str(result.get("task_id", "")).strip()
    if not task_id:
        raise ValueError("DATABASE_COMMIT requires state['task_id']")
    entities = [{
        "entity_id": str(n.get("node_id")),
        "canonical_name": str(n.get("name", "")),
        "role": str(n.get("role", "")),
        "country": str(n.get("country", "")),
        "source": str(n.get("source", "expansion")),
        "metadata": dict(n.get("metadata") or {}),
    } for n in result.get("trade_nodes", []) if isinstance(n, Mapping)]
    edges = [{
        "edge_id": str(e.get("edge_id")),
        "source_entity_id": str(e.get("source")),
        "target_entity_id": str(e.get("target")),
        "relation_type": str(e.get("relation_type", "network_expansion")),
        "confidence": e.get("confidence"),
        "evidence_ids": list(e.get("evidence_ids") or []),
        "metadata": {},
    } for e in result.get("relationships", []) if isinstance(e, Mapping)]
    counts = database.commit_trade_data(task_id, entities, edges, list(result.get("evidence_pool", [])))
    reports = dict(result.get("node_reports", {}))
    reports["DATABASE_COMMIT"] = {"status": "committed", "authority": True, "report": dict(counts or {})}
    result["node_reports"] = reports
    return result


_NODE_FUNCTIONS = {
    "EXPANSION_PLAN": EXPANSION_PLAN,
    "SEED_SELECTION": SEED_SELECTION,
    "RELATION_FANOUT": RELATION_FANOUT,
    "EXPANSION_FILTER": EXPANSION_FILTER,
    "DATABASE_COMMIT": DATABASE_COMMIT,
}


def get_node_function(node_id: str):
    return _NODE_FUNCTIONS.get(node_id)
