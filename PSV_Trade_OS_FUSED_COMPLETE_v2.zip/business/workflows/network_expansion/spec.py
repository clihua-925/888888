"""Network expansion workflow spec - planning and contracts only, no logic."""
from __future__ import annotations

from core.contracts.nodes import ContractDefinition

WORKFLOW_ID = "network_expansion"
WORKFLOW_VERSION = "9.4.0"
PAYLOAD_KEYS = {
    "mission": ("mission",),
    "expansion_planning": ("fragments",),
    "seed_selection": ("trade_nodes",),
    "relation_fanout": ("trade_nodes", "relationships"),
    "standard_filtering": ("trade_nodes", "relationships", "evidence_pool"),
    "database_commit": ("node_reports",),
}
NODE_IDS = (
    "EXPANSION_PLAN", "SEED_SELECTION", "RELATION_FANOUT", "EXPANSION_FILTER", "DATABASE_COMMIT",
)
NODE_SPECS = {
    "EXPANSION_PLAN": {"node_id": "EXPANSION_PLAN", "responsibility": "Establish expansion targets, hop limits and seed standards from the mission.", "capabilities": ("mission_understanding", "expansion_planning")},
    "SEED_SELECTION": {"node_id": "SEED_SELECTION", "responsibility": "Select standard seed nodes (local records first, standard synthesis as fallback).", "capabilities": ("seed_selection",)},
    "RELATION_FANOUT": {"node_id": "RELATION_FANOUT", "responsibility": "Fan out multi-hop neighbour candidates and expansion edges from seeds.", "capabilities": ("relation_fanout",)},
    "EXPANSION_FILTER": {"node_id": "EXPANSION_FILTER", "responsibility": "Loose judgment plus standardization; keep only standard-schema nodes and edges.", "capabilities": ("standard_filtering",)},
    "DATABASE_COMMIT": {"node_id": "DATABASE_COMMIT", "responsibility": "Persist standard nodes, relationships and evidence.", "capabilities": ("database_commit", "database_write")},
}
CONTRACTS = (
    ContractDefinition("EXPANSION_PLAN", ("mission",), ("fragments", "product_definition"), "Plan the expansion from mission inputs.", "Expansion plan is available.", "Expansion plan cannot be established."),
    ContractDefinition("SEED_SELECTION", ("fragments", "product_definition"), ("trade_nodes",), "Select standard seed nodes.", "Seed nodes are available.", "Seed selection cannot complete."),
    ContractDefinition("RELATION_FANOUT", ("fragments",), ("trade_nodes", "relationships"), "Fan out neighbours and expansion edges.", "Expansion candidates are available.", "Relation fan-out cannot complete."),
    ContractDefinition("EXPANSION_FILTER", ("product_definition",), ("trade_nodes", "relationships", "evidence_pool"), "Filter and standardize expansion results.", "Standard expansion results are available.", "Expansion filtering cannot complete."),
    ContractDefinition("DATABASE_COMMIT", ("evidence_pool",), ("node_reports",), "Persist expansion results.", "Expansion results are committed.", "Expansion results cannot be committed.", side_effects=("database_write",), database_write_authority=True),
)
CAPABILITIES = ("mission_understanding", "expansion_planning", "seed_selection", "relation_fanout", "standard_filtering", "database_commit", "database_write")
