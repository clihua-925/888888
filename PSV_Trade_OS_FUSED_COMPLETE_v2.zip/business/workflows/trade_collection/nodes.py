"""Real deterministic and AI-assisted business nodes for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import logging
import re
from copy import deepcopy
from difflib import SequenceMatcher
from typing import Any, Mapping

from core.config.industry import load_industry
from core.config.settings import ROOT
from core.contracts.state import TaskState
from core.contracts.context import get_data_provider, get_decision_provider
from business.shared.text_utils import market_name as _market_name, hs_chapter as _hs_chapter

LOGGER = logging.getLogger(__name__)

REPORT_STATUS_COMMITTED = "committed"

# Decision labels are business input values; the decision service itself is injected by orchestration.
DECISION_ENTITY_RESOLUTION = "entity_resolution"
DECISION_RELATIONSHIP_JUDGMENT = "relationship_judgment"
DECISION_EVIDENCE_VERIFICATION = "evidence_verification"
DECISION_RESOURCE_CLASSIFICATION = "resource_classification"


_PRODUCT_RULES: tuple[tuple[tuple[str, ...], str, str, tuple[str, ...]], ...] = (
    (("solar", "photovoltaic", "pv"), "Solar photovoltaic equipment", "8501", ("solar", "photovoltaic", "pv")),
    (("battery", "energy storage", "storage"), "Energy storage equipment", "8507", ("battery", "energy storage", "storage")),
    (("inverter", "inverters"), "Power inverter equipment", "8504", ("inverter", "power conversion")),
    (("semiconductor", "chip", "chips", "integrated circuit"), "Semiconductor components", "8542", ("semiconductor", "chip", "integrated circuit")),
    (("steel", "stainless steel", "steel product"), "Steel products", "7200", ("steel", "metal", "industrial")),
    (("aluminum", "aluminium"), "Aluminum products", "7600", ("aluminum", "metal", "industrial")),
    (("coffee", "cocoa", "cacao", "tea"), "Agricultural beverage products", "0900", ("agricultural", "beverage", "food")),
    (("machinery", "machine", "equipment", "industrial equipment"), "Industrial machinery and equipment", "8400", ("machinery", "equipment", "industrial")),
    (("textile", "apparel", "garment", "clothing"), "Textile and apparel products", "6100", ("textile", "apparel", "garment")),
    (("plastic", "polymer", "resin"), "Plastic and polymer products", "3900", ("plastic", "polymer", "resin")),
)


_COUNTRY_BY_MARKET = {
    "us": "United States",
    "usa": "United States",
    "united states": "United States",
    "china": "China",
    "cn": "China",
    "germany": "Germany",
    "de": "Germany",
    "japan": "Japan",
    "jp": "Japan",
    "south korea": "South Korea",
    "korea": "South Korea",
    "uk": "United Kingdom",
    "united kingdom": "United Kingdom",
    "france": "France",
    "italy": "Italy",
    "singapore": "Singapore",
    "india": "India",
    "vietnam": "Vietnam",
    "australia": "Australia",
    "canada": "Canada",
    "mexico": "Mexico",
    "brazil": "Brazil",
}


def _industry_profile(industry: str) -> Mapping[str, Any]:
    """Load optional bundled industry metadata without affecting orchestration."""
    try:
        profile = load_industry(industry)
    except (OSError, ValueError, TypeError):
        return {}
    return profile if isinstance(profile, Mapping) else {}


def _load_import_records(state: Mapping) -> list:
    """多源加载：本地 imports 优先，IY 联网抓取兜底（共享加载器，任何失败降级为空）。"""
    product = state.get("product_definition") if isinstance(state.get("product_definition"), Mapping) else {}
    from business.shared.import_sources import load_import_records
    return load_import_records(str(product.get("market", "")), str(product.get("industry", "")))

def _mission_text(mission: Mapping[str, Any]) -> str:
    values = [
        mission.get("objective", ""),
        mission.get("task_type", ""),
        mission.get("intent", ""),
        mission.get("industry", ""),
        mission.get("market", ""),
    ]
    targets = mission.get("targets", [])
    if isinstance(targets, (list, tuple)):
        values.extend(str(item) for item in targets)
    return " ".join(str(item) for item in values if item).strip()


def _target_values(mission: Mapping[str, Any]) -> list[str]:
    targets = mission.get("targets", [])
    if isinstance(targets, str):
        candidates = re.split(r"[,;|/]+", targets)
    elif isinstance(targets, (list, tuple, set)):
        candidates = [str(item) for item in targets]
    else:
        candidates = []
    cleaned = [item.strip() for item in candidates if item and item.strip()]
    return list(dict.fromkeys(cleaned))


def _keywords_for_product(text: str, industry: str) -> list[str]:
    lowered = text.lower()
    keywords: list[str] = []
    for triggers, _, _, rule_keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            keywords.extend(rule_keywords)
    if industry:
        keywords.append(industry.strip().lower())
    if not keywords:
        words = re.findall(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}", lowered)
        keywords.extend(words[:6])
    return list(dict.fromkeys(keyword for keyword in keywords if keyword))[:12]


def _product_rule(text: str) -> tuple[str, str, tuple[str, ...]]:
    lowered = text.lower()
    for triggers, product_name, hs_code, keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            return product_name, hs_code, keywords
    targets = _target_values({"targets": [text]})
    product_name = targets[0] if targets else "Target trade product"
    return product_name, "UNSPECIFIED", ()


def _decision_provider(state: TaskState) -> Any:
    """Return the process-local orchestration decision service."""
    candidate = get_decision_provider()
    if not callable(getattr(candidate, "decide", None)):
        raise RuntimeError("Decision provider runtime context is invalid")
    return candidate


def _decision_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, Mapping):
        for key in ("verified", "merge", "related", "match", "relevant", "approve"):
            if key in value:
                return bool(value[key])
        return False
    if isinstance(value, str):
        return value.strip().lower() in {"true", "yes", "verified", "merge", "related", "match", "approve"}
    return bool(value) if isinstance(value, (int, float)) else False


def _decision_text(value: Any, default: str = "") -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        for key in ("rationale", "verification_reason", "canonical_name", "resource_class"):
            item = value.get(key)
            if item:
                return str(item)
    return default


def _decision_value(result: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    decision = result.get("decision")
    if isinstance(decision, Mapping):
        for key in keys:
            if key in decision:
                return decision[key]
    metadata = result.get("metadata")
    if isinstance(metadata, Mapping):
        for key in keys:
            if key in metadata:
                return metadata[key]
    for key in keys:
        if key in result:
            return result[key]
    return default


def _normalize_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _entity_id_for_node(node: Mapping[str, Any], index: int) -> str:
    existing = str(node.get("entity_id", "")).strip()
    if existing:
        return existing
    node_id = str(node.get("node_id", "")).strip()
    if node_id:
        return f"ENTITY_{node_id}"
    return f"ENTITY_{index + 1}"


def _entity_map(entities: list[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    return {
        str(entity.get("entity_id")): entity
        for entity in entities
        if entity.get("entity_id")
    }


def PRODUCT_DEFINITION(state: TaskState) -> TaskState:
    """Build a deterministic product definition from the Mission payload."""
    result = deepcopy(state)
    mission = dict(result.get("mission", {}))
    targets = _target_values(mission)
    mission_text = _mission_text(mission)
    industry = str(mission.get("industry", "")).strip()
    market = _market_name(mission.get("market", ""))
    _country_lookup = {str(k).strip().lower(): v for k, v in _COUNTRY_BY_MARKET.items()}
    _market_key = str(market).strip().lower()
    if _market_key in _country_lookup:
        market = _country_lookup[_market_key]

    target_text = " ".join(targets) if targets else mission_text
    product_name, hs_code, rule_keywords = _product_rule(target_text)
    profile = _industry_profile(industry)
    profile_keywords = [str(item).strip() for item in profile.get("keywords", []) if str(item).strip()]
    profile_hs_codes = [str(item).strip() for item in profile.get("hs_codes", []) if str(item).strip()]
    if (product_name == "Target trade product" or product_name == target_text.strip()) and profile.get("name"):
        product_name = str(profile["name"])  # 规则未命中时禁止把整句请求当产品名
    if hs_code == "UNSPECIFIED" and profile_hs_codes:
        hs_code = profile_hs_codes[0]
    keywords = _keywords_for_product(target_text, industry)
    keywords.extend(rule_keywords)
    keywords.extend(profile_keywords)
    keywords = list(dict.fromkeys(keywords))[:12]

    description = (
        f"Trade product definition for {product_name} in the {market or 'target'} "
        f"market, serving the {industry or 'specified'} industry."
    )

    target_customer = "business buyers"
    lowered = mission_text.lower()
    if any(word in lowered for word in ("consumer", "retail", "ecommerce", "end user")):
        target_customer = "consumer and retail buyers"
    elif any(word in lowered for word in ("manufacturer", "factory", "industrial")):
        target_customer = "manufacturers and industrial buyers"
    elif any(word in lowered for word in ("distributor", "wholesaler", "importer")):
        target_customer = "importers, distributors, and wholesalers"

    result["product_definition"] = {
        "product_name": product_name,
        "description": description,
        "keywords": keywords,
        "hs_code_guess": hs_code,
        "market": market,
        "industry": industry,
        "target_customer_type": target_customer,
        "source_targets": targets,
        "industry_profile": dict(profile),
    }
    return result


def TRADE_STRATEGY(state: TaskState) -> TaskState:
    """Generate deterministic trade-search strategy fragments."""
    result = deepcopy(state)
    product = dict(result.get("product_definition", {}))
    market = str(product.get("market", "")).strip()
    keywords = list(product.get("keywords", []))
    product_name = str(product.get("product_name", "Target trade product"))

    keyword_text = list(dict.fromkeys([product_name.lower(), *[str(item) for item in keywords]]))
    fragments = [
        {
            "type": "buyer_search",
            "market": market,
            "keywords": keyword_text[:10],
            "priority": 1,
        },
        {
            "type": "supplier_search",
            "market": market,
            "keywords": keyword_text[:10],
            "priority": 1,
        },
        {
            "type": "market_entry",
            "market": market,
            "keywords": keyword_text[:8],
            "priority": 2,
        },
    ]

    # 市场真实性锚点（可选，免费 Comtrade；无 key/失败静默跳过，不改变碎片结构）
    try:
        from business.shared.import_sources import fetch_comtrade_flows
        digits_h = "".join(ch for ch in str(product.get("hs_code_guess", "") or "") if ch.isdigit())
        chapter = digits_h[:2]
        market_key = market.strip().lower()
        reporter = "USA" if ("united" in market_key or market_key in {"us", "usa"}) else ""
        flows = fetch_comtrade_flows(hs_code=chapter, reporter=reporter, partner="World", period="2024", max_records=10) if (chapter and reporter) else []
        result["product_definition"] = dict(product, market_validation={
            "checked": bool(flows),
            "hs_chapter": chapter,
            "flows": len(flows),
            "value_usd": sum(int(item.get("value_usd", 0) or 0) for item in flows),
        })
    except Exception:
        result["product_definition"] = dict(product, market_validation={"checked": False})

    result["fragments"] = fragments
    return result


def _std_keywords(product: Mapping) -> set:
    """采集标准-产品词：来自 PRODUCT_DEFINITION（产品名 + 关键词 + 行业画像）。"""
    words = set()
    for source in (product.get("keywords"), (product.get("industry_profile") or {}).get("keywords") if isinstance(product.get("industry_profile"), Mapping) else None):
        for item in source or []:
            w = str(item).strip().lower()
            if len(w) >= 2:
                words.add(w)
    name = str(product.get("product_name", "")).strip().lower()
    if len(name) >= 2:
        words.add(name)
    return words


def _std_hs_chapters(product: Mapping) -> set:
    """采集标准-HS 章（2 位，宽松粒度）：hs_code_guess + 行业画像 HS 列表。"""
    codes = set()
    candidates = [product.get("hs_code_guess")]
    if isinstance(product.get("industry_profile"), Mapping):
        candidates.extend(list(product["industry_profile"].get("hs_codes") or []))
    for item in candidates:
        digits = "".join(ch for ch in str(item or "") if ch.isdigit())
        if len(digits) >= 2:
            codes.add(digits[:2])
    return codes


def _record_hs_chapter(item: Mapping) -> str:
    meta = item.get("metadata") if isinstance(item.get("metadata"), Mapping) else {}
    raw = meta.get("hs_code") or meta.get("hs") or item.get("hs_code") or ""
    digits = "".join(ch for ch in str(raw or "") if ch.isdigit())
    return digits[:2] if len(digits) >= 2 else ""


def CUSTOMS_NODE_COLLECTION(state: TaskState) -> TaskState:
    """按前两个环节确立采集标准，宽松判断后只保留标准化客户/供应商信息。

    简化版：PRODUCT_DEFINITION + TRADE_STRATEGY 的产物在此被消费为采集标准
    （产品词 / HS 章 / 市场 / 行业 / 标准角色）；本地记录宽松匹配后仅保留
    标准 schema 的实体；策略碎片不再向下游传递。
    """
    result = deepcopy(state)
    product = dict(result.get("product_definition", {}))
    market = _market_name(product.get("market", "")) or "Target market"
    industry = str(product.get("industry", "")).strip()
    product_name = str(product.get("product_name", "Target trade product"))

    # 1) 采集标准（来自前两个环节）
    std_keywords = _std_keywords(product)
    std_hs = _std_hs_chapters(product)
    std_roles = {"buyer", "supplier", "importer", "exporter"}

    existing_nodes = list(result.get("trade_nodes", []))
    existing_evidence = list(result.get("evidence_pool", []))
    existing_node_ids = {str(item.get("node_id")) for item in existing_nodes}
    existing_evidence_ids = {str(item.get("evidence_id")) for item in existing_evidence}

    from business.shared.import_sources import load_import_records_diag
    records, source_diag = load_import_records_diag(str(product.get("market", "")), str(product.get("industry", "")))

    # 2) 标准化 + 宽松判断：任一信号命中即保留；碎片名/非标准角色/无信号记录丢弃
    source_nodes: list[dict[str, Any]] = []
    for index, item in enumerate(records, start=1):
        if not isinstance(item, Mapping):
            continue
        name = str(item.get("name") or item.get("company") or "").strip()
        if len(name) < 2 or name.lower() in {"unknown", "n/a", "null"}:
            continue  # 碎片名不保留
        role = str(item.get("role") or "").strip().lower()
        if role not in std_roles:
            continue  # 非标准角色不保留
        country = _market_name(item.get("country") or market)
        rec_industry = str(item.get("industry") or industry).strip()
        hs_chapter = _record_hs_chapter(item)

        meta = item.get("metadata") if isinstance(item.get("metadata"), Mapping) else {}
        meta_text = " ".join(str(v).lower() for v in meta.values())

        matched_by: list[str] = []
        if country == market:
            matched_by.append("market")
        if hs_chapter and hs_chapter in std_hs:
            matched_by.append("hs_chapter")
        if std_keywords and any(k in name.lower() or k in meta_text for k in std_keywords):
            matched_by.append("product_keyword")
        if industry and rec_industry.lower() == industry.lower():
            matched_by.append("industry")
        if not matched_by:
            continue  # 宽松判断：与采集标准无任何信号关联 → 视为碎片，丢弃

        source_nodes.append({
            "node_id": str(item.get("node_id") or f"IMPORT_NODE_{index:03d}"),
            "name": name,
            "role": role,
            "country": country,
            "source": str(item.get("source") or "local_import"),
            "shipments": int(item.get("shipments") or 0),
            "industry": rec_industry,
            "metadata": {
                "hs_code": hs_chapter,
                "product_keywords": sorted(k for k in std_keywords if k in name.lower() or k in meta_text)[:5],
                "matched_by": matched_by,
            },
        })

    # 3) 无可用记录时按标准生成标准合成实体（简化：客户 + 供应商两类，不带碎片字段）
    if not source_nodes:
        fb = {
            "hs_code": next(iter(std_hs), ""),
            "product_keywords": sorted(std_keywords)[:5],
            "matched_by": ["standard_fallback"],
        }
        source_nodes = [
            {"node_id": "SYNTHETIC_BUYER_001", "name": f"{product_name} Buyer Group A", "role": "buyer", "country": market, "source": "synthetic", "shipments": 18, "industry": industry, "metadata": dict(fb)},
            {"node_id": "SYNTHETIC_SUPPLIER_001", "name": f"{product_name} Supplier Group A", "role": "supplier", "country": "China", "source": "synthetic", "shipments": 26, "industry": industry, "metadata": dict(fb)},
        ]

    for node in source_nodes:
        node_id = str(node.get("node_id") or "").strip()
        if not node_id or node_id in existing_node_ids:
            continue
        existing_nodes.append(node)
        existing_node_ids.add(node_id)

    # 4) 标准证据（不再携带 strategy_fragments）
    for index, node in enumerate(existing_nodes, start=1):
        node_id = str(node.get("node_id") or f"TRADE_NODE_{index:03d}")
        node["node_id"] = node_id
        evidence_id = f"EVIDENCE_{index:03d}"
        if evidence_id in existing_evidence_ids:
            continue
        meta = node.get("metadata") if isinstance(node.get("metadata"), Mapping) else {}
        existing_evidence.append({
            "evidence_id": evidence_id,
            "entity_name": str(node.get("name", "")),
            "evidence_type": "trade_record",
            "source": str(node.get("source", "local_import")),
            "shipments": int(node.get("shipments", 0) or 0),
            "verified": False,
            "evidence_json": {
                "node_id": node_id,
                "product": product_name,
                "market": market,
                "hs_code": str(meta.get("hs_code", "")),
                "matched_by": list(meta.get("matched_by", [])),
            },
        })
        existing_evidence_ids.add(evidence_id)

    result["trade_nodes"] = existing_nodes
    result["evidence_pool"] = existing_evidence
    result["fragments"] = []  # 碎片已被采集标准消费，不再向下游传递
    reports = dict(result.get("node_reports", {}))
    reports["CUSTOMS_NODE_COLLECTION"] = {"status": "ok", "sources": source_diag,
                                          "nodes": len(existing_nodes), "synthetic": not records}
    result["node_reports"] = reports
    return result

_RELATION_TYPE_WHITELIST = {
    "buyer-seller", "buyer-supplier", "supplier-customer", "supplier-buyer",
    "importer-exporter", "importer-supplier", "customer-supplier",
    "trade_partner_candidate", "trade_partner", "network_expansion", "trade",
}


def TRADE_EDGE_BUILD(state: TaskState) -> TaskState:
    """Use the decision provider to judge candidate buyer-seller relationships."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence = list(result.get("evidence_pool", []))
    relationships = list(result.get("relationships", []))
    entities = list(result.get("entities", []))
    ai = _decision_provider(result)
    skipped_edges = 0
    entity_by_id = _entity_map(entities)
    node_to_entity: dict[str, Mapping[str, Any]] = {}
    for entity in entities:
        metadata = entity.get("metadata", {})
        if isinstance(metadata, Mapping):
            for source_node_id in metadata.get("merged_from", []):
                node_to_entity[str(source_node_id)] = entity

    role_pairs = {
        ("buyer", "supplier"),
        ("buyer", "exporter"),
        ("importer", "supplier"),
        ("importer", "exporter"),
    }

    existing_edges = {str(item.get("edge_id")) for item in relationships}
    evidence_by_name = {
        str(item.get("entity_name", "")): item
        for item in evidence
    }

    for left_index, left in enumerate(nodes):
        for right_index in range(left_index + 1, len(nodes)):
            right = nodes[right_index]
            pair = (
                str(left.get("role", "")).lower(),
                str(right.get("role", "")).lower(),
            )
            reverse_pair = (pair[1], pair[0])
            if pair not in role_pairs and reverse_pair not in role_pairs:
                continue

            left_node_id = str(left.get("node_id") or f"SYNTHETIC_NODE_{left_index + 1:03d}")
            right_node_id = str(right.get("node_id") or f"SYNTHETIC_NODE_{right_index + 1:03d}")
            left_entity_record = node_to_entity.get(left_node_id)
            right_entity_record = node_to_entity.get(right_node_id)
            left_id = str(
                left_entity_record.get("entity_id")
                if left_entity_record
                else _entity_id_for_node(left, left_index)
            )
            right_id = str(
                right_entity_record.get("entity_id")
                if right_entity_record
                else _entity_id_for_node(right, right_index)
            )
            left_entity = entity_by_id.get(left_id, left)
            right_entity = entity_by_id.get(right_id, right)
            prompt = (
                "Judge whether these two trade entities have a commercially plausible "
                "buyer-seller or importer-exporter relationship. Use the supplied roles, "
                "countries, shipment counts, and evidence. Do not infer a relationship "
                "solely because both entities exist."
            )
            payload = {
                "source": left_entity or left,
                "target": right_entity or right,
                "source_role": left.get("role"),
                "target_role": right.get("role"),
                "source_country": left.get("country"),
                "target_country": right.get("country"),
                "source_shipments": left.get("shipments", 0),
                "target_shipments": right.get("shipments", 0),
                "source_evidence": evidence_by_name.get(str(left.get("name", "")), {}),
                "target_evidence": evidence_by_name.get(str(right.get("name", "")), {}),
            }
            decision = ai.decide(
                result,
                DECISION_RELATIONSHIP_JUDGMENT,
                prompt,
                payload,
            )
            accepted = _decision_bool(decision.get("decision"))
            confidence = float(decision.get("confidence", 0.0))
            if not accepted or confidence < 0.5:
                continue

            if left_id == right_id:
                continue  # 自环边无业务含义（同一实体不与自己构成买卖关系）
            edge_id = f"EDGE_{left_id}_{right_id}"
            if edge_id in existing_edges:
                continue

            relation_type = _decision_value(
                decision,
                "relation_type",
                "relationship_type",
                default="trade_partner_candidate",
            )
            # schema 校验层：关系类型受控词表 + 置信度归一（前沿做法：LLM 输出视为候选，过校验才入库）
            if str(relation_type).lower() not in _RELATION_TYPE_WHITELIST:
                skipped_edges += 1
                continue
            try:
                confidence = min(1.0, max(0.0, float(confidence)))
            except (TypeError, ValueError):
                confidence = 0.5
            rationale = str(
                decision.get(
                    "rationale",
                    _decision_text(decision.get("decision")),
                )
            )
            evidence_ids = []
            for node in (left, right):
                evidence_item = evidence_by_name.get(str(node.get("name", "")))
                if evidence_item and evidence_item.get("evidence_id"):
                    evidence_ids.append(str(evidence_item["evidence_id"]))

            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": left_id,
                    "target_entity_id": right_id,
                    "relation_type": str(relation_type),
                    "confidence": confidence,
                    "evidence_ids": evidence_ids,
                    "rationale": rationale,
                    "source_node_id": left_node_id,
                    "target_node_id": right_node_id,
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result


def EVIDENCE_VERIFY(state: TaskState) -> TaskState:
    """Use the decision provider to verify every evidence item in the shared pool."""
    result = deepcopy(state)
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_provider(result)

    # 批量核验优先：本地推理模型调用昂贵，N 条一次调用；返回不合规则逐条回退
    batch_verdicts: dict[int, Mapping] = {}
    try:
        batch = ai.decide(
            result,
            DECISION_EVIDENCE_VERIFICATION,
            (
                "Verify every evidence item in the provided list for internal coherence and "
                "whether it supports the stated trade entity. Return a JSON object with a "
                "'verdicts' array; each element must contain: index (integer, 0-based), "
                "verified (boolean), verification_reason (string), issues (array of strings). "
                "Also include top-level 'verified': true and 'issues': [] to satisfy the schema."
            ),
            {"evidence_items": evidence_pool, "trade_nodes": result.get("trade_nodes", [])},
        )
        if isinstance(batch, Mapping):
            raw = batch.get("decision")
            if isinstance(raw, Mapping) and isinstance(raw.get("verdicts"), list):
                for item in raw["verdicts"]:
                    if isinstance(item, Mapping) and isinstance(item.get("index"), int):
                        batch_verdicts[item["index"]] = item
    except Exception:
        batch_verdicts = {}

    def _apply_verdict(evidence: dict, verified: Any, confidence: float, reason: Any, issues: Any) -> None:
        if isinstance(verified, str):
            verified = verified.strip().lower() in {"true", "yes", "verified"}
        if isinstance(issues, str):
            issues = [issues]
        elif not isinstance(issues, list):
            issues = [str(issues)] if issues else []
        evidence["verified"] = bool(verified)
        evidence["verification_confidence"] = float(confidence)
        evidence["verification_reason"] = str(reason or "")
        evidence["issues"] = issues

    for index, evidence in enumerate(evidence_pool):
        if index in batch_verdicts:
            verdict = batch_verdicts[index]
            _apply_verdict(
                evidence,
                verdict.get("verified", False),
                0.8,
                verdict.get("verification_reason", ""),
                verdict.get("issues", []),
            )
            continue
        prompt = (
            "Verify whether this evidence is internally coherent and sufficiently supports "
            "the stated trade entity. Return a boolean verification judgment, a confidence "
            "score, a concise verification reason, and any material issues."
        )
        decision = ai.decide(
            result,
            DECISION_EVIDENCE_VERIFICATION,
            prompt,
            {
                "evidence": evidence,
                "trade_nodes": result.get("trade_nodes", []),
            },
        )
        verified = _decision_value(
            decision,
            "verified",
            default=_decision_bool(decision.get("decision")),
        )
        if isinstance(verified, str):
            verified = verified.strip().lower() in {"true", "yes", "verified"}

        issues = _decision_value(
            decision,
            "issues",
            default=decision.get("metadata", {}).get("issues", [])
            if isinstance(decision.get("metadata"), Mapping)
            else [],
        )
        if isinstance(issues, str):
            issues = [issues]
        elif not isinstance(issues, list):
            issues = [str(issues)] if issues else []

        reason = _decision_value(
            decision,
            "verification_reason",
            default=decision.get("rationale", ""),
        )
        _apply_verdict(evidence, verified, float(decision.get("confidence", 0.0)), reason, issues)

    result["evidence_pool"] = evidence_pool
    return result


def ENTITY_RESOLUTION(state: TaskState) -> TaskState:
    """Resolve similar trade nodes into canonical entities using AI judgment."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_provider(result)

    parent: dict[str, str] = {}
    node_records: dict[str, dict[str, Any]] = {}

    for index, node in enumerate(nodes):
        node_id = str(node.get("node_id") or f"SYNTHETIC_NODE_{index + 1:03d}")
        node_records[node_id] = node
        parent[node_id] = node_id

    def find(node_id: str) -> str:
        current = node_id
        while parent[current] != current:
            parent[current] = parent[parent[current]]
            current = parent[current]
        return current

    def merge(first: str, second: str) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parent[second_root] = first_root

    candidates: list[tuple[str, str]] = []
    resolution_overrides: dict[str, dict[str, Any]] = {}
    for left_index, left in enumerate(nodes):
        left_name = _normalize_name(left.get("name"))
        for right in nodes[left_index + 1 :]:
            right_name = _normalize_name(right.get("name"))
            if not left_name or not right_name:
                continue
            similarity = SequenceMatcher(None, left_name, right_name).ratio()
            same_country = str(left.get("country", "")).lower() == str(right.get("country", "")).lower()
            same_role = str(left.get("role", "")).lower() == str(right.get("role", "")).lower()
            if similarity >= 0.65 or (same_country and same_role and similarity >= 0.45):
                candidates.append((str(left.get("node_id")), str(right.get("node_id"))))

    for left_id, right_id in candidates:
        left = node_records[left_id]
        right = node_records[right_id]
        decision = ai.decide(
            result,
            DECISION_ENTITY_RESOLUTION,
            (
                "Determine whether the two supplied trade records represent the same "
                "underlying entity. If they are duplicates, provide a canonical name. "
                "Use name similarity, role, country, and evidence context."
            ),
            {
                "left": left,
                "right": right,
                "evidence_pool": evidence_pool,
            },
        )
        should_merge = _decision_value(
            decision,
            "merge",
            default=_decision_bool(decision.get("decision")),
        )
        if isinstance(should_merge, str):
            should_merge = should_merge.strip().lower() in {"true", "yes", "merge"}
        if bool(should_merge) and float(decision.get("confidence", 0.0)) >= 0.5:
            root_left, root_right = find(left_id), find(right_id)
            if root_left != root_right:
                left_group = sum(1 for nid in parent if find(nid) == root_left)
                right_group = sum(1 for nid in parent if find(nid) == root_right)
                if left_group > 1 or right_group > 1:
                    # verified merge：跨既有簇合并必须二次确认（前沿教训：单条假阳性经传递闭包污染全团）
                    confirm = ai.decide(
                        result,
                        DECISION_ENTITY_RESOLUTION,
                        (
                            "Re-examine carefully: these two groups of trade records are about to be "
                            "merged into one entity. Confirm ONLY if you are confident they are the same "
                            "real-world company. Answer merge=true only with strong evidence."
                        ),
                        {"left": left, "right": right,
                         "left_group_size": left_group, "right_group_size": right_group},
                    )
                    if not isinstance(confirm, Mapping):
                        continue  # 确认调用失败/无响应：保守跳过合并
                    confirm_merge = _decision_value(confirm, "merge", default=False)
                    if isinstance(confirm_merge, str):
                        confirm_merge = confirm_merge.strip().lower() in {"true", "yes", "merge"}
                    if not bool(confirm_merge):
                        continue
            merge(left_id, right_id)
            canonical_name = _decision_value(decision, "canonical_name", default="")
            if canonical_name:
                resolution_overrides[find(left_id)] = {
                    "canonical_name": str(canonical_name).strip(),
                    "confidence": float(decision.get("confidence", 0.0)),
                    "rationale": str(decision.get("rationale", "")),
                }

    groups: dict[str, list[dict[str, Any]]] = {}
    for node_id, node in node_records.items():
        groups.setdefault(find(node_id), []).append(node)

    entities: list[dict[str, Any]] = []
    for index, group in enumerate(groups.values(), start=1):
        canonical = max(
            group,
            key=lambda item: int(item.get("shipments", 0) or 0),
        )
        merged_from = [str(item.get("node_id")) for item in group]
        confidence = 1.0 if len(group) == 1 else 0.75
        root_id = find(str(group[0].get("node_id")))
        override = resolution_overrides.get(root_id, {})
        canonical_name = str(override.get("canonical_name", "")).strip() or str(canonical.get("name", "")).strip()
        if override.get("confidence") is not None:
            confidence = float(override["confidence"])
        entity_id = f"ENTITY_{index:03d}"
        entities.append(
            {
                "entity_id": entity_id,
                "canonical_name": canonical_name,
                "role": canonical.get("role"),
                "country": canonical.get("country"),
                "source": canonical.get("source", "synthetic"),
                "metadata": {
                    "confidence": confidence,
                    "merged_from": merged_from,
                    "shipments": sum(int(item.get("shipments", 0) or 0) for item in group),
                    "resolution_rationale": str(override.get("rationale", "")),
                },
            }
        )

    node_to_entity: dict[str, str] = {}
    for entity in entities:
        for source_id in entity["metadata"]["merged_from"]:
            node_to_entity[source_id] = entity["entity_id"]

    for relationship in result.get("relationships", []):
        source_id = str(relationship.get("source_node_id", ""))
        target_id = str(relationship.get("target_node_id", ""))
        if source_id in node_to_entity:
            relationship["source_entity_id"] = node_to_entity[source_id]
        if target_id in node_to_entity:
            relationship["target_entity_id"] = node_to_entity[target_id]

    result["entities"] = entities
    return result


def GRAPH_EXPANSION(state: TaskState) -> TaskState:
    """Add deterministic expanded relationships from existing canonical entities."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    existing_edges = {str(item.get("edge_id")) for item in relationships}

    for left_index, left in enumerate(entities):
        for right in entities[left_index + 1 :]:
            if not left.get("entity_id") or not right.get("entity_id"):
                continue
            same_country = str(left.get("country", "")).strip().lower() == str(right.get("country", "")).strip().lower()
            same_role = str(left.get("role", "")).strip().lower() == str(right.get("role", "")).strip().lower()
            if not same_country and not same_role:
                continue
            source_id = str(left["entity_id"])
            target_id = str(right["entity_id"])
            edge_id = f"EXPANDED_{source_id}_{target_id}"
            if edge_id in existing_edges:
                continue
            relation_type = "same_country_partner" if same_country else "same_role_network"
            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": source_id,
                    "target_entity_id": target_id,
                    "relation_type": relation_type,
                    "confidence": 0.55,
                    "evidence_ids": [],
                    "rationale": "Deterministic graph expansion from shared entity attributes.",
                    "metadata": {"expansion": "expanded"},
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result


def RESOURCE_CLASSIFICATION(state: TaskState) -> TaskState:
    """Classify every canonical entity with the decision provider."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_provider(result)

    for entity in entities:
        decision = ai.decide(
            result,
            DECISION_RESOURCE_CLASSIFICATION,
            (
                "Classify this trade entity by commercial resource value. Return a resource "
                "class, a priority value, confidence, and rationale. Consider role, country, "
                "relationship count, shipments, and verified evidence."
            ),
            {
                "entity": entity,
                "relationships": relationships,
                "evidence_pool": evidence_pool,
            },
        )
        resource_class = _decision_value(
            decision,
            "resource_class",
            "class",
            default="unclassified_resource",
        )
        priority = _decision_value(
            decision,
            "priority",
            default=decision.get("metadata", {}).get("priority", 3)
            if isinstance(decision.get("metadata"), Mapping)
            else 3,
        )
        entity.setdefault("metadata", {})
        entity["metadata"]["resource_class"] = str(resource_class)
        entity["metadata"]["priority"] = priority
        entity["metadata"]["classification_confidence"] = float(decision.get("confidence", 0.0))
        entity["metadata"]["classification_rationale"] = str(decision.get("rationale", ""))

    result["entities"] = entities
    return result


def DATABASE_COMMIT(state: TaskState) -> TaskState:
    """Commit finalized entities, relationships, and evidence through the data provider."""
    result = deepcopy(state)
    database = get_data_provider()
    if not callable(getattr(database, "commit_trade_data", None)):
        raise RuntimeError("DATABASE_COMMIT runtime database gateway is invalid")

    task_id = str(result.get("task_id", "")).strip()
    if not task_id:
        raise ValueError("DATABASE_COMMIT requires state['task_id']")

    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    evidence_pool = list(result.get("evidence_pool", []))

    counts = database.commit_trade_data(task_id, entities, relationships, evidence_pool)

    reports = dict(result.get("node_reports", {}))
    reports["DATABASE_COMMIT"] = {
        "status": REPORT_STATUS_COMMITTED,
        "entity_count": counts.get("trade_entities", len(entities)),
        "relationship_count": counts.get("trade_edges", len(relationships)),
        "evidence_count": counts.get("evidence", len(evidence_pool)),
    }
    result["node_reports"] = reports
    return result


NODE_FUNCTIONS = {
    "PRODUCT_DEFINITION": PRODUCT_DEFINITION,
    "TRADE_STRATEGY": TRADE_STRATEGY,
    "CUSTOMS_NODE_COLLECTION": CUSTOMS_NODE_COLLECTION,
    "TRADE_EDGE_BUILD": TRADE_EDGE_BUILD,
    "EVIDENCE_VERIFY": EVIDENCE_VERIFY,
    "ENTITY_RESOLUTION": ENTITY_RESOLUTION,
    "GRAPH_EXPANSION": GRAPH_EXPANSION,
    "RESOURCE_CLASSIFICATION": RESOURCE_CLASSIFICATION,
    "DATABASE_COMMIT": DATABASE_COMMIT,
}


def get_node_function(node_id: str):
    """Return a registered business node callable."""
    try:
        return NODE_FUNCTIONS[node_id]
    except KeyError as exc:
        raise KeyError(f"Unknown business node: {node_id}") from exc
