# 架构说明（Rev.3 清理后）

## 分层

```
run_webui.py / start.bat                 ← 入口
core/webui/app.py        Flask 6 路由    ← 展示层（未改动的冻结面）
core/orchestration/      调度/执行/恢复/条件路由/专家质检/发送器
  scheduler.py           线程池 + spawn worker（daemon 双守卫修复）
  engine.py              LangGraph 组装 + 节点包装（质检挂钩/provider 注入）
  plan.py                契约拓扑排序（累加字段不申报输入）
  conditions.py          条件边路由（EVIDENCE_VERIFY 门 + 默认后继）
  experts.py             专家质检层（LLM 验收 + 规则兜底）
  outlook_sender.py      Playwright/Outlook 发送器（懒加载/env 门控）
core/contracts/          TaskState(16字段)/Contract/NodeSpec/Provider 协议/上下文
core/memory/db.py        SQLite（tasks/events/trade_entities/trade_edges/evidence/outreach_letters）
core/config/             设置与行业画像
business/workflows/      三个声明式工作流（spec 契约 + nodes 实现，各自 *_PLAN 方案节点打头）
business/shared/         import_sources 多源加载 + text_utils 归一化
```

## 协作契约（解耦三件套）

1. **registry 动态发现**：`business/workflows/<pkg>/spec.py`（WORKFLOW_ID/NODE_IDS/NODE_SPECS/CONTRACTS/PAYLOAD_KEYS/CAPABILITIES），`nodes.py` 暴露 `get_node_function`。唯一 sanctioned 的 core→business 接触点。
2. **provider 注入**：`context.push_providers(decision, data, mail)`；business 只调 `get_decision_provider().decide(state, decision_type, prompt, payload)` / `get_data_provider().commit_trade_data(...)` / `get_mail_sender()`，全部可降级。
3. **TaskState 16 字段共享状态**：累加字段（trade_nodes/evidence_pool/decisions/relationships）被多节点更新，**契约中不得声明为输入**（plan 解析器会把输入解析为全部生产者的依赖→环），原地改写节点不得申报产出该池。

## 数据落点

- trade_collection / network_expansion → trade_entities / trade_edges / evidence
- outreach → outreach_letters（专用表）+ trade_entities（合格潜客）
- 运行审计 → task_events；断点 → langgraph checkpoint sqlite
