"""Industry configuration loader for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
from typing import Any

from core.config.settings import ROOT


_INDUSTRY_ALIASES = {
    "毛毡": "felt", "毡": "felt", "无纺布": "felt", "felt": "felt",
    "蜡烛": "candle", "烛": "candle", "candle": "candle",
    "搪瓷锅": "enamel_pot", "搪瓷": "enamel_pot", "enamel": "enamel_pot", "enamel pot": "enamel_pot",
    "太阳能": "solar", "光伏": "solar", "solar": "solar",
}

_CONFIG_DIR = ROOT / "data" / "industry_configs"


def _profile_names() -> list:
    try:
        return sorted(p.stem for p in _CONFIG_DIR.glob("*.json"))
    except Exception:
        return []


def load_industry(name: str | None) -> dict[str, Any]:
    """Load a named industry profile.

    Resolution order: exact file name → alias map (中文/英文) → keyword containment
    scan across bundled profiles → candle fallback (last resort, logged).
    """
    raw = str(name or "").strip()
    safe = raw.lower()
    candidates = []
    if safe:
        candidates.append(safe)
        if raw in _INDUSTRY_ALIASES:
            candidates.append(_INDUSTRY_ALIASES[raw])
        if safe in _INDUSTRY_ALIASES:
            candidates.append(_INDUSTRY_ALIASES[safe])
    for candidate in candidates:
        path = _CONFIG_DIR / f"{candidate}.json"
        if path.exists():
            return _read_profile(path, candidate)
    # 关键词包含匹配：输入词出现在某画像关键词中，或画像名出现在输入中
    if raw:
        for stem in _profile_names():
            if stem in safe or safe in stem:
                path = _CONFIG_DIR / f"{stem}.json"
                if path.exists():
                    return _read_profile(path, stem)
        for stem in _profile_names():
            try:
                profile = _read_profile(_CONFIG_DIR / f"{stem}.json", stem)
            except Exception:
                continue
            words = [str(w).lower() for w in (profile.get("keywords") or []) + (profile.get("product_terms") or [])]
            if any(raw in w or w in safe for w in words if len(w) >= 2):
                return profile
    import logging
    logging.getLogger(__name__).warning("Industry profile not found for %r; falling back to candle", raw)
    path = _CONFIG_DIR / "candle.json"
    if path.exists():
        return _read_profile(path, "candle")
    return {"name": safe or "candle", "keywords": [], "hs_codes": [], "product_terms": [], "icp_reject": []}


def _read_profile(path, name: str) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Industry profile must be an object: {path}")
    return payload
