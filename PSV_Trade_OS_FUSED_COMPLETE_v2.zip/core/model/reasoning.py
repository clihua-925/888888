"""OpenAI-compatible reasoning engine for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import logging
from typing import Any

try:
    from openai import OpenAI
except ImportError as exc:
    OpenAI = None  # type: ignore[assignment]
    _OPENAI_IMPORT_ERROR = exc
else:
    _OPENAI_IMPORT_ERROR = None

from core.config.settings import Settings, settings

LOGGER = logging.getLogger(__name__)
EXPECTED_REASONING_MODEL = "deepseek-r1-distill-llama-70b"


class ReasoningEngineError(RuntimeError):
    """Base error for reasoning-engine failures."""


class ReasoningResponseError(ReasoningEngineError):
    """Raised when the model response cannot be parsed as JSON."""


class ReasoningEngine:
    """Call the configured OpenAI-compatible reasoning endpoint."""

    def __init__(self, runtime_settings: Settings = settings) -> None:
        self.settings = runtime_settings
        configured_model = (self.settings.llm_model or "").strip()
        if configured_model != EXPECTED_REASONING_MODEL:
            message = (
                "Unsupported reasoning model: "
                f"{configured_model!r}. PSV Trade OS 9.4.0 requires "
                f"{EXPECTED_REASONING_MODEL!r}."
            )
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        base_url = (self.settings.llm_base_url or "").strip()
        if not base_url:
            message = "LLM_BASE_URL must not be empty"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        api_key = (self.settings.llm_api_key or "").strip()
        if not api_key:
            LOGGER.warning(
                "LLM_API_KEY is empty; using a local-compatible runtime credential"
            )
            api_key = "local-runtime"

        if OpenAI is None:
            message = (
                "The installed openai package does not provide the OpenAI client. "
                "PSV Trade OS 9.4.0 requires openai>=1.50,<2.0. "
                "Run `python -m pip install -r requirements.txt` in a fresh virtual environment."
            )
            if _OPENAI_IMPORT_ERROR is not None:
                message += f" Import detail: {_OPENAI_IMPORT_ERROR}"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        try:
            self._client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=600.0,   # 本地推理模型单次调用上限 10 分钟（70B 批量核验实测 327s）；超时抛错走节点重试/质检降级
                max_retries=1,
            )
        except Exception as exc:
            LOGGER.exception("Failed to initialize OpenAI-compatible reasoning client")
            raise ReasoningEngineError(
                f"Failed to initialize reasoning client: {exc}"
            ) from exc

    def review(
        self,
        prompt: str,
        system: str = "",
        response_schema: dict[str, Any] | None = None,
        max_tokens: int | None = None,
    ) -> dict[str, Any]:
        """Send a reasoning request and return its JSON response."""
        normalized_prompt = prompt.strip() if isinstance(prompt, str) else ""
        normalized_system = system.strip() if isinstance(system, str) else ""
        if not normalized_prompt:
            message = "Reasoning prompt must not be empty"
            LOGGER.error(message)
            raise ReasoningEngineError(message)

        messages: list[dict[str, str]] = []
        if normalized_system:
            messages.append({"role": "system", "content": normalized_system})
        messages.append({"role": "user", "content": normalized_prompt})

        effective_max_tokens = max_tokens if max_tokens is not None else 2048
        if isinstance(effective_max_tokens, bool) or not isinstance(effective_max_tokens, int) or effective_max_tokens <= 0:
            raise ReasoningEngineError("max_tokens must be a positive integer")

        try:
            request_kwargs: dict[str, Any] = {
                "model": self.settings.llm_model,
                "messages": messages,
                "temperature": 0.0,
                "max_tokens": effective_max_tokens,
            }
            if response_schema is not None:
                request_kwargs["response_format"] = {
                    "type": "json_object",
                    "schema": response_schema,
                }
            else:
                request_kwargs["response_format"] = {"type": "json_object"}
            response = self._client.chat.completions.create(**request_kwargs)
        except Exception as exc:
            LOGGER.exception("Reasoning API request failed")
            raise ReasoningEngineError(
                f"Reasoning API request failed: {exc}"
            ) from exc

        try:
            content = response.choices[0].message.content
        except (AttributeError, IndexError, TypeError) as exc:
            LOGGER.exception("Reasoning API returned an invalid response structure")
            raise ReasoningResponseError(
                f"Invalid reasoning response structure: {exc}"
            ) from exc

        if not isinstance(content, str):
            message = "Reasoning API returned non-text content"
            LOGGER.error(message)
            raise ReasoningResponseError(message)
        if not content.strip():
            message = "LLM returned empty message.content"
            LOGGER.error(message)
            raise ReasoningResponseError(message)

        normalized_content = self._normalize_json_content(content)
        try:
            parsed = json.loads(normalized_content)
        except json.JSONDecodeError as exc:
            LOGGER.error("Reasoning model returned invalid JSON: %s", content)
            raise ReasoningResponseError(f"LLM returned invalid JSON: {exc}") from exc

        if not isinstance(parsed, dict):
            message = "Reasoning model JSON response must be an object"
            LOGGER.error("%s: %r", message, parsed)
            raise ReasoningResponseError(message)
        return parsed

    @staticmethod
    def _normalize_json_content(content: str) -> str:
        """Normalize common JSON code-fence formatting."""
        normalized = content.strip()
        if normalized.startswith("```json") and normalized.endswith("```"):
            normalized = normalized[len("```json") :].strip()
            normalized = normalized[:-len("```")].strip()
        elif normalized.startswith("```") and normalized.endswith("```"):
            normalized = normalized[len("```") :].strip()
            normalized = normalized[:-len("```")].strip()
        return normalized
