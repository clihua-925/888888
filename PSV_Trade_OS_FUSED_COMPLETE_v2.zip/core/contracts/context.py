"""Provider binding context for PSV Trade OS 9.4.0.

ContextVar is the dependency-binding mechanism between Orchestration and Business.
Business reads only DecisionProvider / DataProvider through this module.
"""

from __future__ import annotations

import contextvars
from typing import Any

from .providers import DataProvider, DecisionProvider, MailSender

_PROVIDER_CONTEXT: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar(
    "psv_provider_context", default={}
)


def push_providers(decision_provider: DecisionProvider, data_provider: DataProvider, mail_sender: MailSender | None = None):
    """Bind providers to the current execution context; returns a token."""
    return _PROVIDER_CONTEXT.set({"decision": decision_provider, "data": data_provider, "mail": mail_sender})


def pop_providers(token: Any) -> None:
    """Restore the previous provider binding."""
    _PROVIDER_CONTEXT.reset(token)


def get_decision_provider() -> DecisionProvider:
    """Fetch the decision provider bound by the orchestration engine."""
    context = _PROVIDER_CONTEXT.get()
    if "decision" not in context:
        raise RuntimeError("Provider context is not active.")
    return context["decision"]


def get_data_provider() -> DataProvider:
    """Fetch the data provider bound by the orchestration engine."""
    context = _PROVIDER_CONTEXT.get()
    if "data" not in context:
        raise RuntimeError("Provider context is not active.")
    return context["data"]


def get_mail_sender() -> MailSender | None:
    """Fetch the optional mail sender bound by the orchestration engine (None if unbound)."""
    return _PROVIDER_CONTEXT.get().get("mail")
