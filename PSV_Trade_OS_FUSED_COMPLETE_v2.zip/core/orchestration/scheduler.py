"""Asynchronous workflow scheduler for PSV Trade OS 9.4.0.

The scheduler owns task worker lifecycle: it spawns one worker PROCESS per task,
monitors a duplex pipe with a hard deadline, and terminates the worker on timeout.
Workers self-initialize all runtime objects (Settings, Database, DecisionLayer,
Registry, ConditionEngine, RecoveryManager, WorkflowEngine, checkpoint saver) and
only receive / send serializable data across the process boundary.
"""

from __future__ import annotations

import logging
import multiprocessing as mp
import os
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .mission import MissionDirector
from .state import STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING, STATUS_TIMEOUT

LOGGER = logging.getLogger(__name__)

_SELFTEST_SLEEP_MODE = "__selftest_sleep__"


def _task_worker(task_id: str, mode: str, settings_values: dict[str, Any], child_conn: Any) -> None:
    """Worker process entry: self-initialize, execute, report, release resources."""
    if mode == _SELFTEST_SLEEP_MODE:
        try:
            time.sleep(int(settings_values.get("sleep_seconds", 60)))
        finally:
            try:
                child_conn.send({"ok": False, "error": "slept"})
            except Exception:
                ...
            child_conn.close()
        return
    engine = None
    try:
        from core.config.settings import Settings
        from core.memory.db import Database
        from .conditions import ConditionEdgeEngine
        from .decision import DecisionLayer
        from .engine import WorkflowEngine
        from .policies import Policy
        from .recovery import RecoveryManager
        from .registry import WorkflowRegistry

        settings = Settings(
            app_version=str(settings_values["app_version"]),
            web_host=str(settings_values["web_host"]),
            web_port=int(settings_values["web_port"]),
            llm_base_url=str(settings_values["llm_base_url"]),
            llm_api_key=str(settings_values["llm_api_key"]),
            llm_model=str(settings_values["llm_model"]),
            database_path=Path(settings_values["database_path"]),
            checkpoint_path=Path(settings_values["checkpoint_path"]),
            log_level=str(settings_values["log_level"]),
            max_task_seconds=int(settings_values["max_task_seconds"]),
            max_steps=int(settings_values["max_steps"]),
            max_retries=int(settings_values["max_retries"]),
            no_progress_limit=int(settings_values["no_progress_limit"]),
        )
        database = Database(str(settings.database_path))
        registry = WorkflowRegistry()
        registry.discover()
        policy = Policy(
            max_task_seconds=settings.max_task_seconds,
            max_steps=settings.max_steps,
            max_retries=settings.max_retries,
            no_progress_limit=settings.no_progress_limit,
            version=settings.app_version,
        )
        engine = WorkflowEngine(
            registry,
            ConditionEdgeEngine(),
            RecoveryManager(policy),
            policy,
            database,
            settings,
        )
        from core.orchestration.task_understanding import TaskUnderstanding
        mission = MissionDirector(database, registry, TaskUnderstanding(), engine)
        if mode == "resume":
            final = mission.resume(task_id)
        else:
            final = mission.execute(task_id)
        child_conn.send({"ok": True, "status": str(final.get("status", STATUS_FAILED))})
    except Exception as exc:
        LOGGER.exception("Task worker failed: task_id=%s", task_id)
        try:
            child_conn.send({"ok": False, "error": str(exc)})
        except Exception:
            ...
    finally:
        try:
            if engine is not None:
                engine.close()
        except Exception:
            LOGGER.exception("Failed to close worker engine: task_id=%s", task_id)
        try:
            child_conn.close()
        except Exception:
            ...


class WorkflowScheduler:
    """Submit Missions to monitored worker processes without controlling business nodes."""

    _PROCESS_ACTIVE_TASK_IDS: set[str] = set()
    _PROCESS_ACTIVE_LOCK = threading.Lock()

    def __init__(self, mission_director: MissionDirector) -> None:
        self.mission_director = mission_director
        self._threads: dict[str, threading.Thread] = {}
        self._lock = threading.Lock()
        self._process_id = os.getpid()
        self._worker_token = uuid.uuid4().hex
        self._startup_time = datetime.now(timezone.utc)
        self._active_task_ids: set[str] = set()
        self._recovery_scan_completed = False
        self._run_startup_recovery_once()

    def _run_startup_recovery_once(self) -> None:
        if self._recovery_scan_completed:
            return
        self._recovery_scan_completed = True
        current = mp.current_process()
        if current.daemon or current.name != "MainProcess":
            LOGGER.warning(
                "Skip persisted-task recovery outside the main process: pid=%s name=%s",
                os.getpid(), current.name,
            )
            return
        self._recover_persisted_tasks()

    def _recover_persisted_tasks(self) -> None:
        """Recover only persisted work that predates this scheduler process."""
        try:
            tasks = self.mission_director.database.get_tasks_by_status((STATUS_PENDING, STATUS_RUNNING))
        except Exception:
            LOGGER.exception("Failed to scan persisted tasks during scheduler startup")
            return
        for task in tasks:
            task_id = str(task["task_id"])
            if task["status"] == STATUS_RUNNING:
                if self._belongs_to_current_scheduler(task):
                    continue
                if self._is_owned_by_live_process(task):
                    continue
                if self.mission_director.engine.has_checkpoint(task_id):
                    self._start_thread(task_id, self._resume_task, "psv-recover-resume")
                else:
                    state = dict(task["state"])
                    state["status"] = STATUS_FAILED
                    state["error"] = {
                        "code": "PROCESS_RESTART_INTERRUPTED",
                        "message": "Task was RUNNING when the scheduler process restarted and has no durable checkpoint",
                    }
                    self.mission_director.database.update_task(task_id, state, STATUS_FAILED)
                    self.mission_director.database.add_event(
                        task_id, "TASK_RECOVERY_FAILED", status=STATUS_FAILED, payload=state["error"]
                    )
                    LOGGER.warning("Marked interrupted RUNNING task failed: task_id=%s", task_id)
            else:
                self._start_thread(task_id, self._execute_task, "psv-recover")

    def _is_owned_by_live_process(self, task: dict[str, Any]) -> bool:
        state = task.get("state")
        if not isinstance(state, dict):
            return False
        orchestration = state.get("orchestration")
        if not isinstance(orchestration, dict):
            return False
        worker_token = str(orchestration.get("scheduler_worker_token") or "").strip()
        if not worker_token:
            return False
        try:
            worker_pid = int(orchestration.get("scheduler_worker_pid"))
        except (TypeError, ValueError):
            return False
        if worker_pid == self._process_id:
            return False
        return self._is_process_alive(worker_pid)

    @staticmethod
    def _is_process_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False

    def _belongs_to_current_scheduler(self, task: dict[str, Any]) -> bool:
        state = task.get("state")
        if not isinstance(state, dict):
            return False
        orchestration = state.get("orchestration")
        if not isinstance(orchestration, dict):
            return False
        worker_token = str(orchestration.get("scheduler_worker_token") or "").strip()
        worker_pid = orchestration.get("scheduler_worker_pid")
        task_id = str(task.get("task_id") or "")
        with self._lock:
            if task_id in self._active_task_ids:
                thread = self._threads.get(task_id)
                if thread is None or thread.is_alive():
                    return True
        with self._PROCESS_ACTIVE_LOCK:
            if task_id in self._PROCESS_ACTIVE_TASK_IDS:
                return True
        for thread in threading.enumerate():
            if thread.is_alive() and thread.name.endswith(f"-{task_id}"):
                return True
        if worker_token == self._worker_token:
            return True
        try:
            return bool(worker_token) and int(worker_pid) == self._process_id
        except (TypeError, ValueError):
            return False

    def _claim_task_worker(self, task_id: str) -> None:
        try:
            task = self.mission_director.database.get_task(task_id)
            state = dict(task.get("state") or {})
            orchestration = dict(state.get("orchestration") or {})
            orchestration["scheduler_worker_pid"] = self._process_id
            orchestration["scheduler_worker_token"] = self._worker_token
            state["orchestration"] = orchestration
            self.mission_director.database.update_task(
                task_id, state, str(task.get("status") or STATUS_PENDING)
            )
        except Exception:
            LOGGER.exception("Failed to persist scheduler worker ownership: task_id=%s", task_id)
            raise

    def _start_thread(self, task_id: str, target: Any, name_prefix: str) -> None:
        with self._lock:
            existing = self._threads.get(task_id)
            if existing is not None and existing.is_alive():
                return
            self._active_task_ids.add(task_id)
            with self._PROCESS_ACTIVE_LOCK:
                self._PROCESS_ACTIVE_TASK_IDS.add(task_id)
            thread = threading.Thread(
                target=target, args=(task_id,), name=f"{name_prefix}-{task_id}", daemon=True
            )
            try:
                self._claim_task_worker(task_id)
                self._threads[task_id] = thread
            except Exception:
                self._active_task_ids.discard(task_id)
                with self._PROCESS_ACTIVE_LOCK:
                    self._PROCESS_ACTIVE_TASK_IDS.discard(task_id)
                raise
        thread.start()

    def submit(self, workflow_id: str | None, request: str, market: str, industry: str) -> str:
        """Create a task and return immediately; execution runs in a worker process."""
        task_id = self.mission_director.create_pending(
            request=request, market=market, industry=industry, workflow_id=workflow_id
        )
        self._start_thread(task_id, self._execute_task, "psv-task")
        LOGGER.info("Workflow submitted asynchronously: task_id=%s", task_id)
        return task_id

    def submit_resume(self, task_id: str) -> str:
        self._start_thread(task_id, self._resume_task, "psv-resume")
        LOGGER.info("Workflow resume submitted asynchronously: task_id=%s", task_id)
        return task_id

    def _run_task_in_worker(self, task_id: str, mode: str, deadline_seconds: int | None = None) -> None:
        """Spawn one worker process, monitor its pipe, hard-terminate on deadline."""
        current = mp.current_process()
        if current.daemon:
            raise RuntimeError(
                f"Refusing to spawn a task worker from a daemonic process: pid={os.getpid()} name={current.name}"
            )
        settings_values = self.mission_director._settings_values()
        parent_conn, child_conn = mp.Pipe(duplex=False)
        ctx = mp.get_context("spawn")
        process = ctx.Process(
            target=_task_worker,
            args=(task_id, mode, settings_values, child_conn),
            name=f"psv-worker-{task_id}",
            daemon=True,
        )
        process.start()
        child_conn.close()
        limit = deadline_seconds or int(self.mission_director.engine.policy.max_task_seconds)
        deadline = time.monotonic() + max(1, limit)
        message: dict[str, Any] | None = None
        timed_out = False
        while time.monotonic() < deadline:
            if parent_conn.poll(1):
                try:
                    message = parent_conn.recv()
                except EOFError:
                    message = None
                break
            if not process.is_alive() and not parent_conn.poll():
                break
        if message is None and process.is_alive():
            timed_out = True
            process.terminate()
            process.join(10)
            if process.is_alive():
                LOGGER.error("Worker resisted terminate: task_id=%s pid=%s", task_id, process.pid)
                if hasattr(process, "kill"):
                    process.kill()
                process.join(5)
        else:
            process.join(10)
        try:
            parent_conn.close()
        except Exception:
            ...
        if timed_out:
            self._persist_timeout(task_id)
            LOGGER.warning("Task worker hard-terminated on deadline: task_id=%s", task_id)
        elif message is None and not process.is_alive():
            self._persist_worker_death(task_id)
            LOGGER.error("Task worker died without result: task_id=%s", task_id)
        elif message is not None and not message.get("ok"):
            if message.get("error") != "slept":
                LOGGER.error("Task worker reported failure: task_id=%s error=%s", task_id, message.get("error"))


    def _persist_worker_death(self, task_id: str) -> None:
        """Persist a worker crash so the task never stays RUNNING forever."""
        try:
            record = self.mission_director.database.get_task(task_id)
            status = str(record.get("status") or STATUS_RUNNING)
            if status in {"COMPLETED", "FAILED", "TASK_TIMEOUT"}:
                return
            state = dict(record.get("state") or {})
            state["status"] = STATUS_FAILED
            state["error"] = {"code": "WORKER_DIED", "message": "Task worker process exited without a result"}
            self.mission_director.database.update_task(task_id, state, STATUS_FAILED)
            self.mission_director.database.add_event(
                task_id, "TASK_EXECUTION_FAILED", status=STATUS_FAILED, payload=state["error"]
            )
        except Exception:
            LOGGER.exception("Failed to persist worker death: task_id=%s", task_id)

    def _persist_timeout(self, task_id: str) -> None:
        try:
            record = self.mission_director.database.get_task(task_id)
            state = dict(record.get("state") or {})
            self.mission_director._fail_timeout(
                task_id, state, int(self.mission_director.engine.policy.max_task_seconds)
            )
        except Exception:
            LOGGER.exception("Failed to persist worker timeout: task_id=%s", task_id)

    def _execute_task(self, task_id: str) -> None:
        try:
            self._run_task_in_worker(task_id, "execute")
        except Exception:
            LOGGER.exception("Background workflow execution failed: task_id=%s", task_id)
        finally:
            with self._lock:
                self._threads.pop(task_id, None)
                self._active_task_ids.discard(task_id)
                with self._PROCESS_ACTIVE_LOCK:
                    self._PROCESS_ACTIVE_TASK_IDS.discard(task_id)

    def _resume_task(self, task_id: str) -> None:
        try:
            self._run_task_in_worker(task_id, "resume")
        except Exception:
            LOGGER.exception("Background workflow resume failed: task_id=%s", task_id)
        finally:
            with self._lock:
                self._threads.pop(task_id, None)
                self._active_task_ids.discard(task_id)
                with self._PROCESS_ACTIVE_LOCK:
                    self._PROCESS_ACTIVE_TASK_IDS.discard(task_id)
