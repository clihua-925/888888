# -*- coding: utf-8 -*-
"""Company Discovery — 全球企业/买家/进口商/经销商/供应商发现

集成多数据源：
- 海关数据
- 搜索引擎
- 行业目录
- B2B 平台
"""
import time
from typing import Dict, List, Any

from shared.llm.client import get_llm
from shared.cache.manager import CacheManager


class DiscoveryEngine:
    """企业发现引擎。"""

    def __init__(self):
        self.llm = get_llm()
        self.cache = CacheManager(ttl_seconds=86400)

    def discover(self, product: str, market: str, customer_type: str) -> List[Dict[str, Any]]:
        """发现目标企业。"""
        cache_key = f"{product}:{market}:{customer_type}"
        cached = self.cache.get("discovery", cache_key)
        if cached:
            return cached

        # 1. 尝试从知识库加载行业配置
        from shared.knowledge.industry import IndustryKnowledge
        industry_info = IndustryKnowledge.get(product)
        hs_codes = IndustryKnowledge.get_hs_codes(product)
        keywords = IndustryKnowledge.get_keywords(product)

        # 2. 多源发现
        results = []

        # 2.1 LLM 生成候选（基础层，未来可替换为真实数据源）
        llm_results = self._llm_discover(product, market, customer_type, keywords)
        results.extend(llm_results)

        # 2.2 模拟海关数据发现（Phase 2 占位，Phase 3 接入真实 API）
        customs_results = self._mock_customs_discover(product, market, customer_type, hs_codes)
        results.extend(customs_results)

        # 去重
        seen = set()
        unique = []
        for r in results:
            key = r.get("name", "").lower().strip()
            if key and key not in seen:
                seen.add(key)
                unique.append(r)

        self.cache.set("discovery", cache_key, unique)
        return unique

    def _llm_discover(self, product: str, market: str, customer_type: str, keywords: List[str]) -> List[Dict]:
        """使用 LLM 生成候选企业。"""
        kw_str = ", ".join(keywords) if keywords else product
        prompt = f"""请列出在 {market} 市场从事以下产品进口/分销的 {customer_type} 类型企业：

产品：{product}
关键词：{kw_str}

请输出 5-10 家企业的结构化信息：
[
  {{
    "name": "公司全称",
    "country": "{market}",
    "website": "www.example.com",
    "industry": "行业分类",
    "main_products": ["主营产品1", "主营产品2"],
    "company_size": "medium",
    "supply_chain_role": "{customer_type}"
  }}
]

注意：只输出 JSON 数组，不要其他内容。"""

        result = self.llm.chat(prompt=prompt, model_preference=["deepseek", "qwen", "openai"], temperature=0.5)

        if result["success"] and result["parsed_json"]:
            data = result["parsed_json"]
            if isinstance(data, list):
                return data
        return []

    def _mock_customs_discover(self, product: str, market: str, customer_type: str, hs_codes: List[str]) -> List[Dict]:
        """模拟海关数据发现（Phase 3 接入真实海关 API）。"""
        # Phase 2: 返回空，避免混淆真实数据与模拟数据
        return []
