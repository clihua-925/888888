# -*- coding: utf-8 -*-
"""Website Intelligence — 企业网站信息采集

功能：
- 网站内容分析
- 产品目录提取
- 联系页面发现
- 社交媒体链接
"""
import re
import time
from typing import Dict, Any
from urllib.parse import urljoin, urlparse


class WebsiteIntelligence:
    """网站情报采集器。"""

    def analyze(self, website_url: str) -> Dict[str, Any]:
        """分析企业网站。"""
        if not website_url:
            return {}

        # 标准化 URL
        if not website_url.startswith(("http://", "https://")):
            website_url = "https://" + website_url

        intel = {
            "url": website_url,
            "domain": urlparse(website_url).netloc,
            "analyzed_at": time.time(),
            "pages_found": [],
            "products_mentioned": [],
            "emails_found": [],
            "social_links": [],
            "contact_pages": [],
            "about_summary": "",
        }

        # Phase 2: 基础版，使用 URL 模式推断
        # Phase 3: 接入 Playwright/Selenium 真实爬虫
        intel["contact_pages"] = [
            urljoin(website_url, "/contact"),
            urljoin(website_url, "/contact-us"),
            urljoin(website_url, "/about"),
        ]

        return intel

    def extract_emails(self, text: str) -> list:
        """从文本中提取邮箱。"""
        pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        return list(set(re.findall(pattern, text)))
