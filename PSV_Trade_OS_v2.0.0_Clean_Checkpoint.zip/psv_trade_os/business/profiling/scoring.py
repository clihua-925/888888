# -*- coding: utf-8 -*-
"""Scoring Engine — 企业评分引擎

评分维度：
- 企业实力 (credibility_score)
- 采购可能性 (purchase_probability)
- 匹配程度 (match_score)
- 成交概率 (deal_probability)
"""
from typing import Dict, Any


class ScoringEngine:
    """评分引擎。"""

    def score(self, company_profile: Dict[str, Any]) -> Dict[str, float]:
        """对企业进行多维度评分。"""
        scores = {
            "credibility_score": self._score_credibility(company_profile),
            "purchase_probability": self._score_purchase_probability(company_profile),
            "match_score": company_profile.get("match_score", 0),
            "deal_probability": 0,
        }

        # 成交概率 = 加权组合
        scores["deal_probability"] = (
            scores["credibility_score"] * 0.25 +
            scores["purchase_probability"] * 0.35 +
            scores["match_score"] * 0.40
        )

        return {k: round(v, 1) for k, v in scores.items()}

    def _score_credibility(self, profile: Dict) -> float:
        """评估企业可信度。"""
        score = 30  # 基础分

        # 有官网加分
        if profile.get("website"):
            score += 15

        # 有行业信息加分
        if profile.get("industry"):
            score += 10

        # 有主营产品加分
        if profile.get("main_products"):
            score += 10

        # 企业规模
        size = profile.get("company_size", "unknown")
        size_scores = {"enterprise": 20, "large": 15, "medium": 10, "small": 5, "unknown": 0}
        score += size_scores.get(size, 0)

        # 供应链角色
        role = profile.get("supply_chain_role", "").lower()
        if role in ("importer", "distributor"):
            score += 15
        elif role == "retailer":
            score += 10

        return min(score, 100)

    def _score_purchase_probability(self, profile: Dict) -> float:
        """评估采购可能性。"""
        score = 20  # 基础分

        # 采购方向明确加分
        purchase_direction = profile.get("purchase_direction", [])
        if purchase_direction:
            score += 30

        # 有联系人加分
        contacts = profile.get("contacts", [])
        if contacts:
            score += 15

        # 匹配度影响
        match = profile.get("match_score", 0)
        score += match * 0.35

        return min(score, 100)
