# -*- coding: utf-8 -*-
"""Customer Pool Manager — 客户池管理

功能：
- 添加客户到池
- 按等级/优先级筛选
- 生命周期追踪
"""
import time
from typing import Dict, List, Any

from contracts.data_contract import CustomerPoolEntry, CustomerTier
from platform.database.models import PSVDatabase


class CustomerPoolManager:
    """客户池管理器。"""

    def __init__(self, db: PSVDatabase = None):
        self.db = db or PSVDatabase()

    def add(self, entry: CustomerPoolEntry) -> bool:
        """添加客户到池。"""
        return self.db.insert_customer_pool(entry.to_dict())

    def add_batch(self, entries: List[CustomerPoolEntry]) -> int:
        """批量添加客户。"""
        count = 0
        for entry in entries:
            if self.add(entry):
                count += 1
        return count

    def list_by_tier(self, tier: CustomerTier, limit: int = 100) -> List[Dict]:
        """按等级列出客户。"""
        return self.db.query_customer_pool(tier=tier.value, limit=limit)

    def list_priority(self, min_priority: int = 50, limit: int = 100) -> List[Dict]:
        """按优先级列出客户。"""
        # 使用 raw SQL 查询
        import sqlite3
        with sqlite3.connect(self.db.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM trade_customer_pool WHERE development_priority >= ? ORDER BY development_priority DESC LIMIT ?",
                (min_priority, limit)
            ).fetchall()
            return [dict(r) for r in rows]

    def update_status(self, pool_id: str, new_status: str) -> bool:
        """更新客户跟进状态。"""
        import sqlite3
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                conn.execute(
                    "UPDATE trade_customer_pool SET follow_up_status = ?, updated_at = ? WHERE pool_id = ?",
                    (new_status, time.time(), pool_id)
                )
            return True
        except Exception:
            return False
