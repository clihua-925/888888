# -*- coding: utf-8 -*-
"""Orchestrator State — LangGraph 统一状态定义

这是整个系统的核心状态机。
所有 Agent、所有节点共享此状态。
"""
from typing import TypedDict, Annotated, List, Dict, Any, Optional
from operator import add


def merge_dicts(a: Dict, b: Dict) -> Dict:
    result = a.copy()
    result.update(b)
    return result


def append_unique(a: List, b: List) -> List:
    result = list(a)
    for item in b:
        if item not in result:
            result.append(item)
    return result


class PSVGraphState(TypedDict):
    """PSV Trade Intelligence OS — LangGraph 统一状态。"""

    task_id: str
    workflow_id: str

    trade_intent: Dict[str, Any]
    task_contract: Dict[str, Any]

    execution_plan: Dict[str, Any]
    plan_version: int

    current_agent: str
    agent_history: Annotated[List[Dict], add]
    agent_results: Annotated[Dict[str, Any], merge_dicts]

    market_analysis: Dict[str, Any]
    company_pool: Annotated[List[Dict], append_unique]
    company_profiles: Annotated[Dict[str, Any], merge_dicts]
    customer_pool: Annotated[List[Dict], append_unique]
    contacts: Annotated[List[Dict], append_unique]
    trade_graph: Dict[str, Any]
    opportunities: Annotated[List[Dict], add]

    supervisor_decisions: Annotated[List[Dict], add]
    routing_path: Annotated[List[str], add]

    final_report: Dict[str, Any]
    output_delivered: bool

    status: str
    retry_count: int
    checkpoint_id: str
    error_log: Annotated[List[Dict], add]

    audit_trail: Annotated[List[Dict], add]


def create_initial_state(task_contract: Dict[str, Any]) -> PSVGraphState:
    """从任务契约创建初始状态。"""
    return {
        "task_id": task_contract.get("task_id", ""),
        "workflow_id": f"wf-{task_contract.get('task_id', '')}",
        "trade_intent": {
            "objective": task_contract.get("objective", ""),
            "product": task_contract.get("product", ""),
            "market": task_contract.get("market", ""),
            "target_customer": task_contract.get("target_customer", ""),
        },
        "task_contract": task_contract,
        "execution_plan": {},
        "plan_version": 1,
        "current_agent": "",
        "agent_history": [],
        "agent_results": {},
        "market_analysis": {},
        "company_pool": [],
        "company_profiles": {},
        "customer_pool": [],
        "contacts": [],
        "trade_graph": {"nodes": [], "edges": []},
        "opportunities": [],
        "supervisor_decisions": [],
        "routing_path": [],
        "final_report": {},
        "output_delivered": False,
        "status": "pending",
        "retry_count": 0,
        "checkpoint_id": "",
        "error_log": [],
        "audit_trail": [],
    }
