# -*- coding: utf-8 -*-
"""Trade Planner Agent — 贸易规划智能体

职责：
- 理解外贸目标（自然语言）
- 生成：任务目标、执行计划、Agent 调用顺序
- 输出标准化 execution_plan
"""
import time
from typing import Dict, List, Any

from contracts.task_contract import TaskContract, TaskType
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.config.settings import settings


class TradePlannerAgent:
    """Trade Planner Agent。"""

    WORKFLOW_TEMPLATES = {
        "full_development": [
            "market_research",
            "company_discovery",
            "company_enrichment",
            "contact_discovery",
            "lead_scoring",
            "sales_strategy",
            "report",
        ],
        "market_only": [
            "market_research",
            "report",
        ],
        "discovery_only": [
            "company_discovery",
            "company_enrichment",
            "report",
        ],
        "enrichment_only": [
            "company_enrichment",
            "contact_discovery",
            "report",
        ],
    }

    def __init__(self):
        self.agent_name = "trade_planner"

    def plan(self, task: TaskContract) -> AgentResponse:
        t0 = time.time()

        valid, errors = task.validate()
        if not valid:
            return AgentResponse(
                task_id=task.task_id,
                agent_name=self.agent_name,
                status=AgentStatus.FAILED,
                error=f"Task validation failed: {'; '.join(errors)}",
                duration_ms=int((time.time() - t0) * 1000),
            )

        workflow = self._select_workflow(task)
        plan = self._build_plan(task, workflow)

        return AgentResponse(
            task_id=task.task_id,
            agent_name=self.agent_name,
            result={
                "execution_plan": plan,
                "workflow_type": workflow,
                "estimated_steps": len(plan.get("agent_sequence", [])),
            },
            confidence=ConfidenceLevel.STRONG,
            evidence=["基于任务类型和目标客户自动选择工作流模板", "计划包含明确的 Agent 调用顺序和依赖关系"],
            next_action="supervisor_execute",
            status=AgentStatus.SUCCESS,
            duration_ms=int((time.time() - t0) * 1000),
        )

    def _select_workflow(self, task: TaskContract) -> str:
        objective = task.objective.lower()

        if any(k in objective for k in ["开发", "develop", "开发客户", "客户开发", "full"]):
            return "full_development"
        if any(k in objective for k in ["市场", "market", "分析", "analysis", "趋势", "trend"]):
            return "market_only"
        if any(k in objective for k in ["发现", "discover", "寻找", "find", "搜索", "search"]):
            return "discovery_only"
        if any(k in objective for k in ["补全", "enrich", "完善", "补充", "contact"]):
            return "enrichment_only"

        return "full_development"

    def _build_plan(self, task: TaskContract, workflow_type: str) -> Dict[str, Any]:
        agent_sequence = self.WORKFLOW_TEMPLATES.get(workflow_type, self.WORKFLOW_TEMPLATES["full_development"])

        plan = {
            "plan_id": f"plan-{task.task_id}",
            "version": 1,
            "objective": task.objective,
            "product": task.product,
            "market": task.market,
            "target_customer": task.target_customer,
            "agent_sequence": agent_sequence,
            "dependencies": self._build_dependencies(agent_sequence),
            "constraints": task.constraints,
            "expected_outputs": self._expected_outputs(agent_sequence),
            "fallback_strategy": {
                "on_agent_failure": "skip_and_continue",
                "on_partial_data": "continue_with_available",
                "max_total_retries": settings.MAX_AGENT_RETRIES * len(agent_sequence),
            },
        }
        return plan

    def _build_dependencies(self, sequence: List[str]) -> Dict[str, List[str]]:
        deps = {}
        for i, agent in enumerate(sequence):
            if i == 0:
                deps[agent] = []
            else:
                deps[agent] = [sequence[i - 1]]
        return deps

    def _expected_outputs(self, sequence: List[str]) -> Dict[str, str]:
        output_map = {
            "market_research": "market_analysis",
            "company_discovery": "company_pool",
            "company_enrichment": "company_profiles",
            "contact_discovery": "contacts",
            "lead_scoring": "customer_pool",
            "sales_strategy": "opportunities",
            "report": "final_report",
        }
        return {agent: output_map.get(agent, "unknown") for agent in sequence}

    def replan(self, task_id: str, current_state: Dict[str, Any], failure_reason: str) -> AgentResponse:
        t0 = time.time()

        current_plan = current_state.get("execution_plan", {})
        current_version = current_state.get("plan_version", 1)

        failed_agent = current_state.get("current_agent", "")
        sequence = current_plan.get("agent_sequence", [])
        new_sequence = [a for a in sequence if a != failed_agent]

        new_plan = {
            **current_plan,
            "plan_id": f"plan-{task_id}-v{current_version + 1}",
            "version": current_version + 1,
            "agent_sequence": new_sequence,
            "replan_reason": failure_reason,
            "skipped_agents": [failed_agent] if failed_agent else [],
        }

        return AgentResponse(
            task_id=task_id,
            agent_name=self.agent_name,
            result={"execution_plan": new_plan, "replanned": True},
            confidence=ConfidenceLevel.MEDIUM,
            evidence=[f"原计划在 Agent [{failed_agent}] 失败，已重新规划", f"跳过失败 Agent，继续执行剩余 {len(new_sequence)} 个 Agent"],
            next_action="supervisor_execute",
            status=AgentStatus.SUCCESS,
            duration_ms=int((time.time() - t0) * 1000),
        )
