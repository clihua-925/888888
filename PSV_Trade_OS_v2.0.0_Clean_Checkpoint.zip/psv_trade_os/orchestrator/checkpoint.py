# -*- coding: utf-8 -*-
"""Checkpoint — 状态检查点持久化

基于 LangGraph 的 checkpointer 接口实现。
支持：
- 自动保存每个节点的状态
- 任务中断后恢复
- 多版本状态历史
"""
import json
import os
import time
import uuid
from pathlib import Path
from typing import Dict, List, Any, Optional

from shared.config.settings import settings


class PSVCheckpoint:
    """PSV 检查点管理器。"""

    def __init__(self, checkpoint_dir: str = None):
        self.checkpoint_dir = Path(checkpoint_dir or settings.CHECKPOINT_DIR)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def _get_path(self, task_id: str, checkpoint_id: str = None) -> Path:
        cid = checkpoint_id or f"cp-{int(time.time() * 1000)}"
        dir_path = self.checkpoint_dir / task_id[:8]
        dir_path.mkdir(exist_ok=True)
        return dir_path / f"{cid}.json"

    def save(self, task_id: str, state: Dict[str, Any], checkpoint_id: str = None) -> str:
        cid = checkpoint_id or f"cp-{uuid.uuid4().hex[:8]}"
        path = self._get_path(task_id, cid)

        checkpoint_data = {
            "checkpoint_id": cid,
            "task_id": task_id,
            "timestamp": time.time(),
            "state": state,
            "version": settings.SYSTEM_VERSION,
        }

        with open(path, "w", encoding="utf-8") as f:
            json.dump(checkpoint_data, f, ensure_ascii=False, indent=2)

        return cid

    def load(self, task_id: str, checkpoint_id: str = None) -> Optional[Dict[str, Any]]:
        task_dir = self.checkpoint_dir / task_id[:8]
        if not task_dir.exists():
            return None

        if checkpoint_id:
            path = task_dir / f"{checkpoint_id}.json"
            if path.exists():
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            return None

        files = sorted(task_dir.glob("cp-*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not files:
            return None

        with open(files[0], "r", encoding="utf-8") as f:
            return json.load(f)

    def list_checkpoints(self, task_id: str) -> List[Dict[str, Any]]:
        task_dir = self.checkpoint_dir / task_id[:8]
        if not task_dir.exists():
            return []

        checkpoints = []
        for path in sorted(task_dir.glob("cp-*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                checkpoints.append({
                    "checkpoint_id": data.get("checkpoint_id"),
                    "timestamp": data.get("timestamp"),
                    "version": data.get("version"),
                })
        return checkpoints

    def delete(self, task_id: str, checkpoint_id: str = None) -> bool:
        task_dir = self.checkpoint_dir / task_id[:8]
        if not task_dir.exists():
            return False

        if checkpoint_id:
            path = task_dir / f"{checkpoint_id}.json"
            if path.exists():
                path.unlink()
                return True
            return False

        for path in task_dir.glob("*.json"):
            path.unlink()
        task_dir.rmdir()
        return True


class LangGraphCheckpointerAdapter:
    """适配 LangGraph 的 checkpointer 接口。"""

    def __init__(self):
        self.backend = PSVCheckpoint()

    def put(self, config: Dict, checkpoint: Dict, metadata: Dict) -> None:
        task_id = config.get("configurable", {}).get("thread_id", "unknown")
        self.backend.save(task_id, checkpoint)

    def get(self, config: Dict) -> Optional[Dict]:
        task_id = config.get("configurable", {}).get("thread_id", "unknown")
        return self.backend.load(task_id)

    def list(self, config: Dict, limit: int = 10) -> List[Dict]:
        task_id = config.get("configurable", {}).get("thread_id", "unknown")
        return self.backend.list_checkpoints(task_id)[:limit]
