# -*- coding: utf-8 -*-
"""Supervisor Agent — 监督智能体

职责：
- 接收 Trade Planner 的执行计划
- 按顺序调用不同业务 Agent
- 监控每个 Agent 的执行结果
- 决定：继续 / 重试 / 跳过 / 重规划 / 终止
"""
import time
from typing import Dict, List, Any, Optional

from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.config.settings import settings


class SupervisorAgent:
    """Supervisor Agent。"""

    def __init__(self):
        self.agent_name = "supervisor"
        self.decision_history: List[Dict] = []

    def supervise(self, state: Dict[str, Any], agent_results: Dict[str, AgentResponse]) -> Dict[str, Any]:
        plan = state.get("execution_plan", {})
        sequence = plan.get("agent_sequence", [])
        current = state.get("current_agent", "")
        status = state.get("status", "pending")

        completed = [a for a in sequence if a in agent_results and agent_results[a].is_success()]
        if len(completed) == len(sequence):
            return self._decision("complete", "", "所有 Agent 执行成功，任务完成")

        next_agent = self._get_next_agent(sequence, completed, current)

        if current and current in agent_results:
            result = agent_results[current]
            if not result.is_success():
                retry_count = state.get("retry_count", 0)
                if retry_count < settings.MAX_AGENT_RETRIES:
                    return self._decision("retry", current, f"Agent [{current}] 失败，第 {retry_count + 1} 次重试")
                else:
                    fallback = plan.get("fallback_strategy", {}).get("on_agent_failure", "skip_and_continue")
                    if fallback == "skip_and_continue":
                        return self._decision("skip", next_agent, f"Agent [{current}] 超过最大重试次数，跳过并继续")
                    elif fallback == "abort":
                        return self._decision("abort", "", f"Agent [{current}] 失败且策略为 abort，终止任务")
                    else:
                        return self._decision("replan", next_agent, f"Agent [{current}] 失败，触发重规划")

        if next_agent:
            return self._decision("continue", next_agent, f"执行下一个 Agent: [{next_agent}]")

        if sequence:
            return self._decision("complete", "", "所有 Agent 已执行（部分可能失败），进入报告生成")

        return self._decision("complete", "", "无执行计划，直接完成")

    def _get_next_agent(self, sequence: List[str], completed: List[str], current: str) -> str:
        if not sequence:
            return ""

        if current and current in sequence:
            idx = sequence.index(current)
            if idx + 1 < len(sequence):
                return sequence[idx + 1]
            return ""
        else:
            for agent in sequence:
                if agent not in completed:
                    return agent
            return ""

    def _decision(self, decision: str, next_agent: str, reason: str) -> Dict[str, Any]:
        record = {
            "timestamp": time.time(),
            "decision": decision,
            "next_agent": next_agent,
            "reason": reason,
        }
        self.decision_history.append(record)
        return record

    def evaluate_agent_result(self, agent_name: str, response: AgentResponse) -> Dict[str, Any]:
        evaluation = {
            "agent_name": agent_name,
            "status": response.status.value,
            "success": response.is_success(),
            "confidence": response.confidence.value,
            "has_result": bool(response.result),
            "has_evidence": len(response.evidence) > 0,
            "has_next_action": bool(response.next_action),
            "duration_ms": response.duration_ms,
        }

        score = 0
        if response.is_success():
            score += 40
        if response.confidence in (ConfidenceLevel.STRONG, ConfidenceLevel.MEDIUM):
            score += 30
        if response.result:
            score += 20
        if response.evidence:
            score += 10

        evaluation["quality_score"] = score
        evaluation["quality_level"] = "high" if score >= 80 else "medium" if score >= 50 else "low"

        return evaluation
