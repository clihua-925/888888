# -*- coding: utf-8 -*-
"""Router — LangGraph 条件边路由函数

所有条件路由逻辑集中在此。
"""
from typing import Dict, List, Any, Literal

from orchestrator.supervisor import SupervisorAgent
from contracts.agent_contract import AgentResponse


RouteDecision = Literal[
    "planner",
    "market_research",
    "company_discovery",
    "company_enrichment",
    "contact_discovery",
    "lead_scoring",
    "sales_strategy",
    "report",
    "supervisor",
    "checkpoint",
    "recovery",
    "end",
]


class PSVRouter:
    """PSV 路由管理器。"""

    def __init__(self):
        self.supervisor = SupervisorAgent()

    def route_after_init(self, state: Dict[str, Any]) -> RouteDecision:
        return "planner"

    def route_after_planner(self, state: Dict[str, Any]) -> RouteDecision:
        plan = state.get("execution_plan", {})
        if not plan or not plan.get("agent_sequence"):
            return "end"
        return "supervisor"

    def route_after_supervisor(self, state: Dict[str, Any]) -> RouteDecision:
        agent_results = state.get("agent_results", {})
        decision = self.supervisor.supervise(state, agent_results)

        action = decision.get("decision", "complete")
        next_agent = decision.get("next_agent", "")

        if "supervisor_decisions" not in state:
            state["supervisor_decisions"] = []
        state["supervisor_decisions"].append(decision)

        if action == "complete":
            sequence = state.get("execution_plan", {}).get("agent_sequence", [])
            if "report" in sequence and "report" not in agent_results:
                return "report"
            return "end"

        if action == "abort":
            state["status"] = "failed"
            return "end"

        if action == "replan":
            return "planner"

        if action in ("continue", "retry", "skip"):
            agent_map = {
                "market_research": "market_research",
                "company_discovery": "company_discovery",
                "company_enrichment": "company_enrichment",
                "contact_discovery": "contact_discovery",
                "lead_scoring": "lead_scoring",
                "sales_strategy": "sales_strategy",
                "report": "report",
            }
            return agent_map.get(next_agent, "supervisor")

        return "end"

    def route_after_agent(self, state: Dict[str, Any]) -> RouteDecision:
        return "supervisor"

    def route_after_report(self, state: Dict[str, Any]) -> RouteDecision:
        state["status"] = "completed"
        state["output_delivered"] = True
        return "end"

    def route_recovery(self, state: Dict[str, Any]) -> RouteDecision:
        current_agent = state.get("current_agent", "")
        if current_agent:
            agent_map = {
                "market_research": "market_research",
                "company_discovery": "company_discovery",
                "company_enrichment": "company_enrichment",
                "contact_discovery": "contact_discovery",
                "lead_scoring": "lead_scoring",
                "sales_strategy": "sales_strategy",
                "report": "report",
            }
            return agent_map.get(current_agent, "supervisor")
        return "supervisor"
