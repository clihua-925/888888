# -*- coding: utf-8 -*-
"""Graph — LangGraph 主编排图

PSV Trade Intelligence OS 的核心运行引擎。
使用 LangGraph 的 StateGraph 构建。

流程：
    INIT → PLANNER → SUPERVISOR → [AGENT LOOP] → REPORT → END
                     ↑____________↓
"""
import time
from typing import Dict, Any
from langgraph.graph import StateGraph, END

from orchestrator.state import PSVGraphState, create_initial_state
from orchestrator.planner import TradePlannerAgent
from orchestrator.supervisor import SupervisorAgent
from orchestrator.router import PSVRouter
from orchestrator.checkpoint import LangGraphCheckpointerAdapter
from contracts.task_contract import TaskContract
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.config.settings import settings

# Import real agents
from agents.market_research.agent import MarketResearchAgent
from agents.company_discovery.agent import CompanyDiscoveryAgent
from agents.company_enrichment.agent import CompanyEnrichmentAgent
from agents.contact_discovery.agent import ContactDiscoveryAgent
from agents.lead_scoring.agent import LeadScoringAgent
from agents.sales_strategy.agent import SalesStrategyAgent
from agents.report.agent import ReportAgent

# Import persistence
from platform.database.models import PSVDatabase
from platform.audit.logger import AuditLogger
from contracts.event_contract import EventContract, EventType
import json
import sqlite3


class PSVGraphBuilder:
    """PSV 主图构建器。"""

    def __init__(self):
        self.planner = TradePlannerAgent()
        self.supervisor = SupervisorAgent()
        self.router = PSVRouter()
        self.checkpointer = LangGraphCheckpointerAdapter()
        self.db = PSVDatabase()
        self.audit = AuditLogger()

        # Initialize real agents
        self.agents = {
            "market_research": MarketResearchAgent(),
            "company_discovery": CompanyDiscoveryAgent(),
            "company_enrichment": CompanyEnrichmentAgent(),
            "contact_discovery": ContactDiscoveryAgent(),
            "lead_scoring": LeadScoringAgent(),
            "sales_strategy": SalesStrategyAgent(),
            "report": ReportAgent(),
        }

    def build(self) -> StateGraph:
        builder = StateGraph(PSVGraphState)

        builder.add_node("init", self._node_init)
        builder.add_node("planner", self._node_planner)
        builder.add_node("supervisor", self._node_supervisor)
        builder.add_node("market_research", self._node_market_research)
        builder.add_node("company_discovery", self._node_company_discovery)
        builder.add_node("company_enrichment", self._node_company_enrichment)
        builder.add_node("contact_discovery", self._node_contact_discovery)
        builder.add_node("lead_scoring", self._node_lead_scoring)
        builder.add_node("sales_strategy", self._node_sales_strategy)
        builder.add_node("report", self._node_report)
        builder.add_node("checkpoint", self._node_checkpoint)
        builder.add_node("persist", self._node_persist)

        builder.set_entry_point("init")
        builder.add_edge("init", "planner")

        builder.add_conditional_edges(
            "planner",
            self.router.route_after_planner,
            {"supervisor": "supervisor", "end": END}
        )

        builder.add_conditional_edges(
            "supervisor",
            self.router.route_after_supervisor,
            {
                "market_research": "market_research",
                "company_discovery": "company_discovery",
                "company_enrichment": "company_enrichment",
                "contact_discovery": "contact_discovery",
                "lead_scoring": "lead_scoring",
                "sales_strategy": "sales_strategy",
                "report": "report",
                "planner": "planner",
                "end": END,
            }
        )

        for agent_node in [
            "market_research", "company_discovery", "company_enrichment",
            "contact_discovery", "lead_scoring", "sales_strategy",
        ]:
            builder.add_edge(agent_node, "checkpoint")

        builder.add_edge("checkpoint", "persist")
        builder.add_edge("persist", "supervisor")
        builder.add_edge("report", "persist")
        builder.add_edge("persist", END)

        graph = builder.compile(checkpointer=self.checkpointer)
        return graph

    def _node_init(self, state: PSVGraphState) -> Dict[str, Any]:
        state["status"] = "planning"
        state["routing_path"] = state.get("routing_path", []) + ["init"]
        audit_entry = {
            "event": "task_initialized",
            "task_id": state.get("task_id"),
            "timestamp": time.time(),
        }
        state["audit_trail"] = state.get("audit_trail", []) + [audit_entry]
        return state

    def _node_planner(self, state: PSVGraphState) -> Dict[str, Any]:
        task_contract = state.get("task_contract", {})
        task = TaskContract.from_dict(task_contract)
        response = self.planner.plan(task)

        if response.is_success():
            state["execution_plan"] = response.result.get("execution_plan", {})
            state["plan_version"] = response.result.get("execution_plan", {}).get("version", 1)
            state["status"] = "executing"
        else:
            state["status"] = "failed"
            state["error_log"] = state.get("error_log", []) + [{
                "node": "planner",
                "error": response.error,
                "timestamp": time.time(),
            }]

        state["current_agent"] = "trade_planner"
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        state["routing_path"] = state.get("routing_path", []) + ["planner"]
        return state

    def _node_supervisor(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "supervisor"
        state["routing_path"] = state.get("routing_path", []) + ["supervisor"]
        return state

    def _node_checkpoint(self, state: PSVGraphState) -> Dict[str, Any]:
        state["checkpoint_id"] = f"cp-{state.get('task_id', '')}-{time.time()}"
        state["routing_path"] = state.get("routing_path", []) + ["checkpoint"]
        return state

    def _node_persist(self, state: PSVGraphState) -> Dict[str, Any]:
        """数据持久化节点：将业务数据写入数据库。"""
        task_id = state.get("task_id", "")

        # 持久化企业数据
        for entity_id, profile in state.get("company_profiles", {}).items():
            self.db.insert_company(profile)

        # 持久化客户池
        for customer in state.get("customer_pool", []):
            self.db.insert_customer_pool(customer)

        # 记录任务状态
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO trade_task (task_id, objective, product, market, target_customer, status, execution_plan, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    task_id,
                    state.get("trade_intent", {}).get("objective", ""),
                    state.get("trade_intent", {}).get("product", ""),
                    state.get("trade_intent", {}).get("market", ""),
                    state.get("trade_intent", {}).get("target_customer", ""),
                    state.get("status", ""),
                    json.dumps(state.get("execution_plan", {}), ensure_ascii=False),
                    time.time(),
                ))
        except Exception as e:
            print(f"[Persist] Task record error: {e}")

        state["routing_path"] = state.get("routing_path", []) + ["persist"]
        return state

    def _run_agent(self, state: PSVGraphState, agent_name: str, input_data: Dict[str, Any], context: Dict[str, Any] = None) -> AgentResponse:
        """通用 Agent 执行封装。"""
        agent = self.agents.get(agent_name)
        if not agent:
            return AgentResponse(
                task_id=state.get("task_id", ""),
                agent_name=agent_name,
                status=AgentStatus.FAILED,
                error=f"Agent {agent_name} not found",
            )

        request = AgentRequest(
            task_id=state.get("task_id", ""),
            agent_name=agent_name,
            objective=state.get("trade_intent", {}).get("objective", ""),
            input_data=input_data,
            context=context or {},
        )

        return agent.run(request)

    def _node_market_research(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "market_research"
        state["routing_path"] = state.get("routing_path", []) + ["market_research"]

        response = self._run_agent(
            state, "market_research",
            input_data={
                "product": state.get("trade_intent", {}).get("product", ""),
                "market": state.get("trade_intent", {}).get("market", ""),
            }
        )

        if response.is_success():
            state["market_analysis"] = response.result.get("market_analysis", {})

        state["agent_results"] = {**state.get("agent_results", {}), "market_research": response.to_dict()}
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        return state

    def _node_company_discovery(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "company_discovery"
        state["routing_path"] = state.get("routing_path", []) + ["company_discovery"]

        response = self._run_agent(
            state, "company_discovery",
            input_data={
                "product": state.get("trade_intent", {}).get("product", ""),
                "market": state.get("trade_intent", {}).get("market", ""),
                "target_customer": state.get("trade_intent", {}).get("target_customer", "importer"),
            },
            context={"market_analysis": state.get("market_analysis", {})}
        )

        if response.is_success():
            state["company_pool"] = response.result.get("company_pool", [])

        state["agent_results"] = {**state.get("agent_results", {}), "company_discovery": response.to_dict()}
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        return state

    def _node_company_enrichment(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "company_enrichment"
        state["routing_path"] = state.get("routing_path", []) + ["company_enrichment"]

        response = self._run_agent(
            state, "company_enrichment",
            input_data={
                "company_pool": state.get("company_pool", []),
                "product": state.get("trade_intent", {}).get("product", ""),
            }
        )

        if response.is_success():
            state["company_profiles"] = response.result.get("company_profiles", {})

        state["agent_results"] = {**state.get("agent_results", {}), "company_enrichment": response.to_dict()}
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        return state

    def _node_contact_discovery(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "contact_discovery"
        state["routing_path"] = state.get("routing_path", []) + ["contact_discovery"]

        response = self._run_agent(
            state, "contact_discovery",
            input_data={
                "company_profiles": state.get("company_profiles", {}),
                "product": state.get("trade_intent", {}).get("product", ""),
            }
        )

        if response.is_success():
            state["contacts"] = response.result.get("contacts", [])

        state["agent_results"] = {**state.get("agent_results", {}), "contact_discovery": response.to_dict()}
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        return state

    def _node_lead_scoring(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "lead_scoring"
        state["routing_path"] = state.get("routing_path", []) + ["lead_scoring"]

        response = self._run_agent(
            state, "lead_scoring",
            input_data={
                "company_profiles": state.get("company_profiles", {}),
                "contacts": state.get("contacts", []),
                "product": state.get("trade_intent", {}).get("product", ""),
            },
            context={"market_analysis": state.get("market_analysis", {})}
        )

        if response.is_success():
            state["customer_pool"] = response.result.get("customer_pool", [])

        state["agent_results"] = {**state.get("agent_results", {}), "lead_scoring": response.to_dict()}
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        return state

    def _node_sales_strategy(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "sales_strategy"
        state["routing_path"] = state.get("routing_path", []) + ["sales_strategy"]

        response = self._run_agent(
            state, "sales_strategy",
            input_data={
                "customer_pool": state.get("customer_pool", []),
                "company_profiles": state.get("company_profiles", {}),
                "product": state.get("trade_intent", {}).get("product", ""),
            },
            context={"market_analysis": state.get("market_analysis", {})}
        )

        if response.is_success():
            state["opportunities"] = response.result.get("opportunities", [])

        state["agent_results"] = {**state.get("agent_results", {}), "sales_strategy": response.to_dict()}
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        return state

    def _node_report(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_agent"] = "report"
        state["status"] = "completed"
        state["output_delivered"] = True
        state["routing_path"] = state.get("routing_path", []) + ["report"]

        response = self._run_agent(
            state, "report",
            input_data={
                "market_analysis": state.get("market_analysis", {}),
                "company_pool": state.get("company_pool", []),
                "company_profiles": state.get("company_profiles", {}),
                "customer_pool": state.get("customer_pool", []),
                "contacts": state.get("contacts", []),
                "opportunities": state.get("opportunities", []),
            },
            context={
                "task_contract": state.get("task_contract", {}),
                "agent_history": state.get("agent_history", []),
                "routing_path": state.get("routing_path", []),
            }
        )

        if response.is_success():
            state["final_report"] = response.result.get("final_report", {})

        state["agent_results"] = {**state.get("agent_results", {}), "report": response.to_dict()}
        state["agent_history"] = state.get("agent_history", []) + [response.to_dict()]
        return state


_graph_builder = None


def get_graph() -> StateGraph:
    global _graph_builder
    if _graph_builder is None:
        _graph_builder = PSVGraphBuilder()
    return _graph_builder.build()


def run_trade_task(task_contract: Dict[str, Any]) -> Dict[str, Any]:
    graph = get_graph()
    initial_state = create_initial_state(task_contract)
    config = {"configurable": {"thread_id": task_contract.get("task_id", "default")}}

    final_state = None
    for event in graph.stream(initial_state, config, stream_mode="values"):
        final_state = event

    return final_state
