# -*- coding: utf-8 -*-
"""Recovery — 任务中断恢复

核心能力：
- 检测中断任务
- 从 checkpoint 恢复 workflow state
- 继续执行（不重新开始整个任务）
"""
import time
from typing import Dict, List, Any, Optional

from orchestrator.checkpoint import PSVCheckpoint
from orchestrator.state import PSVGraphState, create_initial_state
from shared.config.settings import settings


class RecoveryManager:
    """恢复管理器。"""

    def __init__(self, checkpoint: PSVCheckpoint = None):
        self.checkpoint = checkpoint or PSVCheckpoint()

    def scan_interrupted_tasks(self) -> List[Dict[str, Any]]:
        """扫描所有中断的任务。"""
        interrupted = []
        checkpoint_dir = self.checkpoint.checkpoint_dir

        if not checkpoint_dir.exists():
            return interrupted

        for task_dir in checkpoint_dir.iterdir():
            if not task_dir.is_dir():
                continue

            checkpoints = sorted(task_dir.glob("cp-*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            if not checkpoints:
                continue

            latest = checkpoints[0]
            try:
                with open(latest, "r", encoding="utf-8") as f:
                    data = json.load(f)

                state = data.get("state", {})
                status = state.get("status", "")
                last_time = data.get("timestamp", 0)

                if status not in ("completed", "failed"):
                    elapsed = time.time() - last_time
                    if elapsed < settings.TASK_TIMEOUT_SECONDS:
                        interrupted.append({
                            "task_id": state.get("task_id", ""),
                            "checkpoint_id": data.get("checkpoint_id"),
                            "status": status,
                            "current_agent": state.get("current_agent", ""),
                            "last_active": last_time,
                            "elapsed_seconds": int(elapsed),
                        })
            except Exception:
                continue

        return interrupted

    def recover_state(self, task_id: str, checkpoint_id: str = None) -> Optional[PSVGraphState]:
        """恢复任务状态。"""
        checkpoint_data = self.checkpoint.load(task_id, checkpoint_id)
        if not checkpoint_data:
            return None

        state = checkpoint_data.get("state")
        if not state:
            return None

        required_fields = ["task_id", "task_contract", "status"]
        for field in required_fields:
            if field not in state:
                return None

        state["status"] = "recovering"
        state["error_log"] = state.get("error_log", []) + [{
            "type": "recovery",
            "message": f"State recovered from checkpoint {checkpoint_data.get('checkpoint_id')}",
            "timestamp": time.time(),
        }]

        return state

    def can_recover(self, task_id: str) -> bool:
        """判断任务是否可以恢复。"""
        checkpoint_data = self.checkpoint.load(task_id)
        if not checkpoint_data:
            return False

        state = checkpoint_data.get("state", {})
        status = state.get("status", "")
        return status not in ("completed", "failed")

    def get_recovery_point(self, task_id: str) -> Dict[str, Any]:
        """获取恢复点信息。"""
        checkpoint_data = self.checkpoint.load(task_id)
        if not checkpoint_data:
            return {"recoverable": False, "reason": "no_checkpoint"}

        state = checkpoint_data.get("state", {})
        return {
            "recoverable": True,
            "task_id": task_id,
            "checkpoint_id": checkpoint_data.get("checkpoint_id"),
            "status": state.get("status"),
            "current_agent": state.get("current_agent"),
            "routing_path": state.get("routing_path", []),
            "agent_history_count": len(state.get("agent_history", [])),
            "company_pool_count": len(state.get("company_pool", [])),
            "timestamp": checkpoint_data.get("timestamp"),
        }
