# -*- coding: utf-8 -*-
"""Executor — Agent 执行器

负责：
- 调用具体 Agent 的执行逻辑
- 管理 Agent 的生命周期
- 处理超时、重试、异常
"""
import time
from typing import Dict, Any, Callable

from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.config.settings import settings


class AgentExecutor:
    """Agent 执行器。"""

    def __init__(self):
        self._agents: Dict[str, Callable] = {}

    def register(self, agent_name: str, handler: Callable[[AgentRequest], AgentResponse]):
        """注册 Agent 处理器。"""
        self._agents[agent_name] = handler

    def execute(self, request: AgentRequest) -> AgentResponse:
        """执行 Agent。"""
        handler = self._agents.get(request.agent_name)
        if not handler:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=request.agent_name,
                status=AgentStatus.FAILED,
                error=f"Agent [{request.agent_name}] 未注册",
            )

        t0 = time.time()
        try:
            response = handler(request)
            response.duration_ms = int((time.time() - t0) * 1000)
            return response
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=request.agent_name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
