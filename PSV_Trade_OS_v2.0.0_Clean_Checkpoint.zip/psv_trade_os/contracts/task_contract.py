# -*- coding: utf-8 -*-
"""Task Contract — 统一任务格式

所有进入系统的任务必须遵循此契约。
禁止模块直接构造字典，必须通过 TaskContract 创建。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import uuid
import time


class TaskType(str, Enum):
    MARKET_RESEARCH = "market_research"
    COMPANY_DISCOVERY = "company_discovery"
    COMPANY_ENRICHMENT = "company_enrichment"
    CONTACT_DISCOVERY = "contact_discovery"
    LEAD_SCORING = "lead_scoring"
    SALES_STRATEGY = "sales_strategy"
    FULL_DEVELOPMENT = "full_development"


class TaskPriority(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"


@dataclass
class TaskContract:
    """统一任务契约。"""
    task_id: str = field(default_factory=lambda: f"task-{uuid.uuid4().hex[:12]}")
    objective: str = ""
    product: str = ""
    market: str = ""
    target_customer: str = ""
    constraints: Dict[str, Any] = field(default_factory=dict)
    workflow: List[str] = field(default_factory=list)
    priority: TaskPriority = TaskPriority.NORMAL
    created_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "objective": self.objective,
            "product": self.product,
            "market": self.market,
            "target_customer": self.target_customer,
            "constraints": self.constraints,
            "workflow": self.workflow,
            "priority": self.priority.value,
            "created_at": self.created_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TaskContract":
        return cls(
            task_id=data.get("task_id", ""),
            objective=data.get("objective", ""),
            product=data.get("product", ""),
            market=data.get("market", ""),
            target_customer=data.get("target_customer", ""),
            constraints=data.get("constraints", {}),
            workflow=data.get("workflow", []),
            priority=TaskPriority(data.get("priority", "normal")),
            created_at=data.get("created_at", time.time()),
            metadata=data.get("metadata", {}),
        )

    def validate(self) -> tuple[bool, List[str]]:
        errors = []
        if not self.objective or len(self.objective) < 5:
            errors.append("objective: 外贸目标描述不能为空且至少5个字符")
        if not self.product:
            errors.append("product: 目标产品不能为空")
        if not self.market:
            errors.append("market: 目标市场不能为空")
        if not self.target_customer:
            errors.append("target_customer: 目标客户类型不能为空")
        return len(errors) == 0, errors
