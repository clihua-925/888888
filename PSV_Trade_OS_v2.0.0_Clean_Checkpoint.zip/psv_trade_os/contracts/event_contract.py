# -*- coding: utf-8 -*-
"""Event Contract — 系统事件统一格式

用于审计、追踪、恢复。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import time


class EventType(str, Enum):
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    TASK_RECOVERED = "task_recovered"
    AGENT_INVOKED = "agent_invoked"
    AGENT_COMPLETED = "agent_completed"
    AGENT_FAILED = "agent_failed"
    TOOL_CALLED = "tool_called"
    TOOL_COMPLETED = "tool_completed"
    DATA_PERSISTED = "data_persisted"
    CHECKPOINT_SAVED = "checkpoint_saved"
    CHECKPOINT_RESTORED = "checkpoint_restored"
    DECISION_MADE = "decision_made"


@dataclass
class EventContract:
    """事件契约。"""
    event_id: str = ""
    event_type: EventType = EventType.TASK_STARTED
    task_id: str = ""
    workflow_id: str = ""
    agent_id: str = ""
    node_id: str = ""
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    tool_call: Dict[str, Any] = field(default_factory=dict)
    duration_ms: int = 0
    status: str = ""
    error: str = ""
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "task_id": self.task_id,
            "workflow_id": self.workflow_id,
            "agent_id": self.agent_id,
            "node_id": self.node_id,
            "input_data": self.input_data,
            "output_data": self.output_data,
            "tool_call": self.tool_call,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "error": self.error,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }
