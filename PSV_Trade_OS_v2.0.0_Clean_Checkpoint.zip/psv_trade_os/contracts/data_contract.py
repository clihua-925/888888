# -*- coding: utf-8 -*-
"""Data Contract — 外贸业务数据统一格式

所有业务数据（企业、联系人、市场等）必须遵循此契约。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum


class CompanySize(str, Enum):
    UNKNOWN = "unknown"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    ENTERPRISE = "enterprise"


class CustomerTier(str, Enum):
    S = "S"
    A = "A"
    B = "B"
    C = "C"
    D = "D"


@dataclass
class CompanyProfile:
    """企业画像契约。"""
    entity_id: str = ""
    name: str = ""
    country: str = ""
    website: str = ""
    industry: str = ""
    main_products: List[str] = field(default_factory=list)
    purchase_direction: List[str] = field(default_factory=list)
    company_size: CompanySize = CompanySize.UNKNOWN
    supply_chain_role: str = ""
    contacts: List[Dict[str, Any]] = field(default_factory=list)
    contact_methods: Dict[str, Any] = field(default_factory=dict)
    credibility_score: float = 0.0
    purchase_probability: float = 0.0
    match_score: float = 0.0
    evidence: List[str] = field(default_factory=list)
    raw_data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "name": self.name,
            "country": self.country,
            "website": self.website,
            "industry": self.industry,
            "main_products": self.main_products,
            "purchase_direction": self.purchase_direction,
            "company_size": self.company_size.value,
            "supply_chain_role": self.supply_chain_role,
            "contacts": self.contacts,
            "contact_methods": self.contact_methods,
            "credibility_score": self.credibility_score,
            "purchase_probability": self.purchase_probability,
            "match_score": self.match_score,
            "evidence": self.evidence,
            "raw_data": self.raw_data,
        }


@dataclass
class CustomerPoolEntry:
    """客户池条目契约。"""
    entity_id: str = ""
    company_profile: Dict[str, Any] = field(default_factory=dict)
    tier: CustomerTier = CustomerTier.C
    customer_value: float = 0.0
    match_degree: float = 0.0
    deal_probability: float = 0.0
    development_priority: int = 0
    follow_up_status: str = "new"
    lead_source: str = ""
    assigned_agent: str = ""
    tags: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    created_at: float = 0.0
    updated_at: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "company_profile": self.company_profile,
            "tier": self.tier.value,
            "customer_value": self.customer_value,
            "match_degree": self.match_degree,
            "deal_probability": self.deal_probability,
            "development_priority": self.development_priority,
            "follow_up_status": self.follow_up_status,
            "lead_source": self.lead_source,
            "assigned_agent": self.assigned_agent,
            "tags": self.tags,
            "notes": self.notes,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
