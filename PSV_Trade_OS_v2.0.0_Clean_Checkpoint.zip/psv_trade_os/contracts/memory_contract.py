# -*- coding: utf-8 -*-
"""Memory Contract — 记忆存储统一契约

短期记忆：当前任务状态
长期记忆：历史任务、行业知识、客户数据、执行经验
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import time


class MemoryType(str, Enum):
    SHORT_TERM = "short_term"
    LONG_TERM = "long_term"


class MemoryCategory(str, Enum):
    TASK = "task"
    INDUSTRY = "industry"
    MARKET = "market"
    PRODUCT = "product"
    COMPANY = "company"
    EXPERIENCE = "experience"
    WORKFLOW = "workflow"


@dataclass
class MemoryEntry:
    """记忆条目契约。"""
    memory_id: str = ""
    memory_type: MemoryType = MemoryType.SHORT_TERM
    category: MemoryCategory = MemoryCategory.TASK
    key: str = ""
    value: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    hits: int = 0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id": self.memory_id,
            "memory_type": self.memory_type.value,
            "category": self.category.value,
            "key": self.key,
            "value": self.value,
            "hits": self.hits,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
