# -*- coding: utf-8 -*-
"""Tool Contract — 工具调用统一契约

所有工具（搜索引擎、海关数据、浏览器自动化等）必须遵循此契约。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum


class ToolType(str, Enum):
    SEARCH = "search"
    BROWSER = "browser"
    API = "api"
    DATABASE = "database"
    LLM = "llm"
    SCRAPER = "scraper"


class ToolStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    RATE_LIMITED = "rate_limited"


@dataclass
class ToolRequest:
    """工具调用请求。"""
    tool_name: str = ""
    tool_type: ToolType = ToolType.SEARCH
    params: Dict[str, Any] = field(default_factory=dict)
    timeout_ms: int = 30000
    retry_count: int = 0


@dataclass
class ToolResponse:
    """工具调用响应。"""
    tool_name: str = ""
    status: ToolStatus = ToolStatus.SUCCESS
    data: Dict[str, Any] = field(default_factory=dict)
    raw_output: str = ""
    error: str = ""
    duration_ms: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
