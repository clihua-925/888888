# -*- coding: utf-8 -*-
"""Agent Contract — 所有 Agent 的输入输出统一契约

禁止 Agent 直接返回任意字典。
所有 Agent 输入必须是 AgentRequest，输出必须是 AgentResponse。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import time


class AgentStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"


class ConfidenceLevel(str, Enum):
    STRONG = "strong"
    MEDIUM = "medium"
    WEAK = "weak"
    UNKNOWN = "unknown"


@dataclass
class AgentRequest:
    """Agent 输入契约。"""
    task_id: str = ""
    agent_name: str = ""
    objective: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    input_data: Dict[str, Any] = field(default_factory=dict)
    constraints: Dict[str, Any] = field(default_factory=dict)
    memory_refs: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "agent_name": self.agent_name,
            "objective": self.objective,
            "context": self.context,
            "input_data": self.input_data,
            "constraints": self.constraints,
            "memory_refs": self.memory_refs,
        }


@dataclass
class AgentResponse:
    """Agent 输出契约。"""
    task_id: str = ""
    agent_name: str = ""
    result: Dict[str, Any] = field(default_factory=dict)
    confidence: ConfidenceLevel = ConfidenceLevel.UNKNOWN
    evidence: List[str] = field(default_factory=list)
    next_action: str = ""
    status: AgentStatus = AgentStatus.PENDING
    error: str = ""
    duration_ms: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "agent_name": self.agent_name,
            "result": self.result,
            "confidence": self.confidence.value,
            "evidence": self.evidence,
            "next_action": self.next_action,
            "status": self.status.value,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentResponse":
        return cls(
            task_id=data.get("task_id", ""),
            agent_name=data.get("agent_name", ""),
            result=data.get("result", {}),
            confidence=ConfidenceLevel(data.get("confidence", "unknown")),
            evidence=data.get("evidence", []),
            next_action=data.get("next_action", ""),
            status=AgentStatus(data.get("status", "pending")),
            error=data.get("error", ""),
            duration_ms=data.get("duration_ms", 0),
            timestamp=data.get("timestamp", time.time()),
        )

    def is_success(self) -> bool:
        return self.status in (AgentStatus.SUCCESS, AgentStatus.PARTIAL)

    def is_terminal(self) -> bool:
        return self.status in (AgentStatus.SUCCESS, AgentStatus.FAILED, AgentStatus.SKIPPED)
