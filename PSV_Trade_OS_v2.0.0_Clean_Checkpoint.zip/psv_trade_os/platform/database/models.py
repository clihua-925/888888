# -*- coding: utf-8 -*-
"""Database Models — 外贸业务核心表

核心原则：
- 表必须围绕外贸业务设计
- 禁止只围绕采集任务设计
"""
import sqlite3
import time
import uuid
import json
from typing import Dict, List, Any, Optional
from pathlib import Path

from shared.config.settings import settings


class PSVDatabase:
    """PSV 外贸业务数据库。"""

    def __init__(self, db_path: str = None):
        self.db_path = db_path or settings.DATABASE_PATH
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _conn(self):
        return sqlite3.connect(self.db_path, timeout=10, check_same_thread=False)

    def _init_schema(self):
        with self._conn() as conn:
            conn.executescript(self._get_schema_sql())

    def _get_schema_sql(self) -> str:
        return """
        CREATE TABLE IF NOT EXISTS trade_company (
            entity_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            normalized_name TEXT UNIQUE,
            country TEXT,
            website TEXT,
            industry TEXT,
            main_products TEXT,
            purchase_direction TEXT,
            company_size TEXT,
            supply_chain_role TEXT,
            credibility_score REAL DEFAULT 0,
            purchase_probability REAL DEFAULT 0,
            match_score REAL DEFAULT 0,
            evidence TEXT,
            raw_data TEXT,
            created_at REAL,
            updated_at REAL
        );
        CREATE INDEX IF NOT EXISTS idx_company_country ON trade_company(country);
        CREATE INDEX IF NOT EXISTS idx_company_industry ON trade_company(industry);
        CREATE INDEX IF NOT EXISTS idx_company_score ON trade_company(match_score DESC);

        CREATE TABLE IF NOT EXISTS trade_contact (
            contact_id TEXT PRIMARY KEY,
            entity_id TEXT NOT NULL,
            name TEXT,
            title TEXT,
            email TEXT,
            phone TEXT,
            linkedin TEXT,
            department TEXT,
            is_decision_maker INTEGER DEFAULT 0,
            verified INTEGER DEFAULT 0,
            source TEXT,
            created_at REAL,
            FOREIGN KEY (entity_id) REFERENCES trade_company(entity_id)
        );
        CREATE INDEX IF NOT EXISTS idx_contact_entity ON trade_contact(entity_id);
        CREATE INDEX IF NOT EXISTS idx_contact_email ON trade_contact(email);

        CREATE TABLE IF NOT EXISTS trade_product (
            product_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT,
            hs_code TEXT,
            description TEXT,
            target_markets TEXT,
            competitors TEXT,
            created_at REAL
        );

        CREATE TABLE IF NOT EXISTS trade_market (
            market_id TEXT PRIMARY KEY,
            country TEXT NOT NULL,
            region TEXT,
            market_size TEXT,
            growth_rate TEXT,
            entry_difficulty TEXT,
            key_channels TEXT,
            regulations TEXT,
            analysis_data TEXT,
            updated_at REAL
        );

        CREATE TABLE IF NOT EXISTS trade_customer_pool (
            pool_id TEXT PRIMARY KEY,
            entity_id TEXT NOT NULL,
            tier TEXT DEFAULT 'C',
            customer_value REAL DEFAULT 0,
            match_degree REAL DEFAULT 0,
            deal_probability REAL DEFAULT 0,
            development_priority INTEGER DEFAULT 0,
            follow_up_status TEXT DEFAULT 'new',
            lead_source TEXT,
            assigned_agent TEXT,
            tags TEXT,
            notes TEXT,
            created_at REAL,
            updated_at REAL,
            FOREIGN KEY (entity_id) REFERENCES trade_company(entity_id)
        );
        CREATE INDEX IF NOT EXISTS idx_pool_tier ON trade_customer_pool(tier);
        CREATE INDEX IF NOT EXISTS idx_pool_priority ON trade_customer_pool(development_priority DESC);
        CREATE INDEX IF NOT EXISTS idx_pool_status ON trade_customer_pool(follow_up_status);

        CREATE TABLE IF NOT EXISTS trade_opportunity (
            opportunity_id TEXT PRIMARY KEY,
            entity_id TEXT NOT NULL,
            title TEXT,
            description TEXT,
            estimated_value REAL,
            probability REAL,
            strategy TEXT,
            recommended_actions TEXT,
            status TEXT DEFAULT 'open',
            created_at REAL,
            updated_at REAL,
            FOREIGN KEY (entity_id) REFERENCES trade_company(entity_id)
        );

        CREATE TABLE IF NOT EXISTS trade_task (
            task_id TEXT PRIMARY KEY,
            objective TEXT,
            product TEXT,
            market TEXT,
            target_customer TEXT,
            status TEXT DEFAULT 'pending',
            execution_plan TEXT,
            result_summary TEXT,
            created_at REAL,
            completed_at REAL
        );

        CREATE TABLE IF NOT EXISTS trade_workflow (
            workflow_id TEXT PRIMARY KEY,
            task_id TEXT,
            agent_sequence TEXT,
            current_agent TEXT,
            routing_path TEXT,
            status TEXT,
            created_at REAL,
            updated_at REAL
        );

        CREATE TABLE IF NOT EXISTS agent_execution_log (
            log_id TEXT PRIMARY KEY,
            task_id TEXT,
            workflow_id TEXT,
            agent_name TEXT,
            request_data TEXT,
            response_data TEXT,
            confidence TEXT,
            duration_ms INTEGER,
            status TEXT,
            error TEXT,
            timestamp REAL
        );
        CREATE INDEX IF NOT EXISTS idx_agent_log_task ON agent_execution_log(task_id);
        CREATE INDEX IF NOT EXISTS idx_agent_log_time ON agent_execution_log(timestamp);

        CREATE TABLE IF NOT EXISTS memory_store (
            memory_id TEXT PRIMARY KEY,
            memory_type TEXT,
            category TEXT,
            key TEXT,
            value TEXT,
            embedding TEXT,
            hits INTEGER DEFAULT 0,
            created_at REAL,
            updated_at REAL
        );
        CREATE INDEX IF NOT EXISTS idx_memory_type ON memory_store(memory_type);
        CREATE INDEX IF NOT EXISTS idx_memory_category ON memory_store(category);
        """

    def insert_company(self, data: Dict[str, Any]) -> bool:
        sql = """
            INSERT OR REPLACE INTO trade_company (
                entity_id, name, normalized_name, country, website, industry,
                main_products, purchase_direction, company_size, supply_chain_role,
                credibility_score, purchase_probability, match_score,
                evidence, raw_data, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        now = time.time()
        try:
            with self._conn() as conn:
                conn.execute(sql, (
                    data.get("entity_id", str(uuid.uuid4())),
                    data.get("name", ""),
                    data.get("normalized_name", ""),
                    data.get("country", ""),
                    data.get("website", ""),
                    data.get("industry", ""),
                    json.dumps(data.get("main_products", []), ensure_ascii=False),
                    json.dumps(data.get("purchase_direction", []), ensure_ascii=False),
                    data.get("company_size", "unknown"),
                    data.get("supply_chain_role", ""),
                    data.get("credibility_score", 0),
                    data.get("purchase_probability", 0),
                    data.get("match_score", 0),
                    json.dumps(data.get("evidence", []), ensure_ascii=False),
                    json.dumps(data.get("raw_data", {}), ensure_ascii=False),
                    data.get("created_at", now),
                    now,
                ))
            return True
        except Exception as e:
            print(f"[DB] insert_company error: {e}")
            return False

    def insert_customer_pool(self, data: Dict[str, Any]) -> bool:
        sql = """
            INSERT OR REPLACE INTO trade_customer_pool (
                pool_id, entity_id, tier, customer_value, match_degree,
                deal_probability, development_priority, follow_up_status,
                lead_source, assigned_agent, tags, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        now = time.time()
        try:
            with self._conn() as conn:
                conn.execute(sql, (
                    data.get("pool_id", str(uuid.uuid4())),
                    data.get("entity_id", ""),
                    data.get("tier", "C"),
                    data.get("customer_value", 0),
                    data.get("match_degree", 0),
                    data.get("deal_probability", 0),
                    data.get("development_priority", 0),
                    data.get("follow_up_status", "new"),
                    data.get("lead_source", ""),
                    data.get("assigned_agent", ""),
                    json.dumps(data.get("tags", []), ensure_ascii=False),
                    json.dumps(data.get("notes", []), ensure_ascii=False),
                    data.get("created_at", now),
                    now,
                ))
            return True
        except Exception as e:
            print(f"[DB] insert_customer_pool error: {e}")
            return False

    def query_companies(self, filters: Dict[str, Any] = None, limit: int = 100) -> List[Dict]:
        where = []
        params = []
        if filters:
            if filters.get("country"):
                where.append("country = ?")
                params.append(filters["country"])
            if filters.get("industry"):
                where.append("industry = ?")
                params.append(filters["industry"])
            if filters.get("min_score"):
                where.append("match_score >= ?")
                params.append(filters["min_score"])

        sql = "SELECT * FROM trade_company"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += f" ORDER BY match_score DESC LIMIT {limit}"

        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql, params).fetchall()
            return [dict(r) for r in rows]

    def query_customer_pool(self, tier: str = None, limit: int = 100) -> List[Dict]:
        sql = "SELECT * FROM trade_customer_pool"
        params = []
        if tier:
            sql += " WHERE tier = ?"
            params.append(tier)
        sql += f" ORDER BY development_priority DESC LIMIT {limit}"

        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql, params).fetchall()
            return [dict(r) for r in rows]
