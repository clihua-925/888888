# -*- coding: utf-8 -*-
"""Database Connection — 数据库连接管理

统一的数据库连接管理，支持 SQLite（未来可扩展 PostgreSQL）。
"""
import sqlite3
from typing import Optional
from shared.config.settings import settings


class DatabaseConnection:
    """数据库连接管理器。"""

    def __init__(self, db_path: str = None):
        self.db_path = db_path or settings.DATABASE_PATH

    def get_connection(self):
        return sqlite3.connect(self.db_path, timeout=10, check_same_thread=False)

    def execute(self, sql: str, params: tuple = ()):
        with self.get_connection() as conn:
            return conn.execute(sql, params)

    def executescript(self, sql: str):
        with self.get_connection() as conn:
            conn.executescript(sql)
