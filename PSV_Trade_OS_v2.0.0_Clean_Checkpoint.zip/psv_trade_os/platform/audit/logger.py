# -*- coding: utf-8 -*-
"""Audit Logger — 全链路审计

必须能够回答：
- 哪个 Agent 执行？
- 为什么执行？
- 调用什么工具？
- 产生什么结果？
- 哪里失败？
"""
import time
import json
import sqlite3
from typing import Dict, List, Any, Optional

from shared.config.settings import settings
from contracts.event_contract import EventContract, EventType


class AuditLogger:
    """审计日志管理器。"""

    def __init__(self, db_path: str = None):
        self.db_path = db_path or settings.DATABASE_PATH
        self.enabled = settings.AUDIT_ENABLED
        self._init_table()

    def _init_table(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    task_id TEXT,
                    workflow_id TEXT,
                    agent_id TEXT,
                    node_id TEXT,
                    input_data TEXT,
                    output_data TEXT,
                    tool_call TEXT,
                    duration_ms INTEGER,
                    status TEXT,
                    error TEXT,
                    timestamp REAL,
                    metadata TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_audit_task ON audit_log(task_id);
                CREATE INDEX IF NOT EXISTS idx_audit_agent ON audit_log(agent_id);
                CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(timestamp);
            """)

    def log(self, event: EventContract) -> bool:
        if not self.enabled:
            return False
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT INTO audit_log (
                        event_id, event_type, task_id, workflow_id, agent_id, node_id,
                        input_data, output_data, tool_call, duration_ms, status, error,
                        timestamp, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    event.event_id,
                    event.event_type.value,
                    event.task_id,
                    event.workflow_id,
                    event.agent_id,
                    event.node_id,
                    json.dumps(event.input_data, ensure_ascii=False),
                    json.dumps(event.output_data, ensure_ascii=False),
                    json.dumps(event.tool_call, ensure_ascii=False),
                    event.duration_ms,
                    event.status,
                    event.error,
                    event.timestamp,
                    json.dumps(event.metadata, ensure_ascii=False),
                ))
            return True
        except Exception as e:
            print(f"[Audit] 记录失败: {e}")
            return False

    def query_by_task(self, task_id: str, limit: int = 100) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM audit_log WHERE task_id = ? ORDER BY timestamp DESC LIMIT ?",
                (task_id, limit)
            ).fetchall()
            return [dict(r) for r in rows]

    def query_by_agent(self, agent_id: str, limit: int = 100) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM audit_log WHERE agent_id = ? ORDER BY timestamp DESC LIMIT ?",
                (agent_id, limit)
            ).fetchall()
            return [dict(r) for r in rows]

    def get_task_summary(self, task_id: str) -> Dict[str, Any]:
        records = self.query_by_task(task_id, limit=1000)
        agents = {}
        tools = []
        errors = []
        timeline = []

        for r in records:
            agent = r.get("agent_id") or r.get("node_id")
            if agent:
                agents[agent] = agents.get(agent, 0) + 1
            if r.get("tool_call"):
                try:
                    tc = json.loads(r["tool_call"])
                    tools.append({"time": r["timestamp"], "tool": tc.get("tool_name", "unknown"), "params": tc.get("params", {})})
                except:
                    pass
            if r.get("error"):
                errors.append({"time": r["timestamp"], "agent": agent, "error": r["error"]})
            timeline.append({"time": r["timestamp"], "type": r["event_type"], "agent": agent, "status": r["status"]})

        return {
            "task_id": task_id,
            "total_events": len(records),
            "agents_involved": agents,
            "tools_called": tools,
            "failures": errors,
            "timeline": timeline,
        }
