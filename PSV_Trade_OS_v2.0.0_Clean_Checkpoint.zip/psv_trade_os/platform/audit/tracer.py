# -*- coding: utf-8 -*-
"""Tracer — 链路追踪

追踪任务在系统中的完整执行链路。
"""
from typing import Dict, List, Any
import time


class Tracer:
    """链路追踪器。"""

    def __init__(self):
        self._traces: Dict[str, List[Dict]] = {}

    def start_trace(self, task_id: str) -> None:
        self._traces[task_id] = [{"event": "trace_started", "timestamp": time.time()}]

    def append(self, task_id: str, event: Dict[str, Any]) -> None:
        if task_id not in self._traces:
            self.start_trace(task_id)
        event["timestamp"] = time.time()
        self._traces[task_id].append(event)

    def get_trace(self, task_id: str) -> List[Dict]:
        return self._traces.get(task_id, [])

    def get_last_event(self, task_id: str) -> Dict:
        trace = self._traces.get(task_id, [])
        return trace[-1] if trace else {}
