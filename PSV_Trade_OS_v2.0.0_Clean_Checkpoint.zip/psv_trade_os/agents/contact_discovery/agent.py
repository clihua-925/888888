# -*- coding: utf-8 -*-
"""Contact Discovery Agent — 联系人发现智能体

负责：
- 寻找联系人
- 职位识别
- 邮箱发现
- 销售入口定位

输入：company_profiles
输出：contacts（联系人列表）
"""
import time
import re
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel


class ContactDiscoveryAgent(BaseAgent):
    """联系人发现 Agent。"""

    def __init__(self):
        super().__init__("contact_discovery")

    def execute(self, request: AgentRequest) -> AgentResponse:
        company_profiles = request.input_data.get("company_profiles", {})
        product = request.input_data.get("product", "")

        all_contacts = []
        discovery_log = []

        for entity_id, profile in company_profiles.items():
            name = profile.get("name", "")
            website = profile.get("website", "")

            # 1. 尝试从网站发现联系人
            web_contacts = self._discover_from_website(website, name)

            # 2. LLM 推测关键联系人
            llm_contacts = self._llm_infer_contacts(profile, product)

            # 3. 合并去重
            contacts = self._merge_contacts(web_contacts, llm_contacts, entity_id)
            all_contacts.extend(contacts)

            discovery_log.append({
                "entity_id": entity_id,
                "company": name,
                "contacts_found": len(contacts),
            })

        return AgentResponse(
            task_id=request.task_id,
            agent_name=self.agent_name,
            result={
                "contacts": all_contacts,
                "total_contacts": len(all_contacts),
                "discovery_log": discovery_log,
            },
            confidence=ConfidenceLevel.MEDIUM if len(all_contacts) > 0 else ConfidenceLevel.WEAK,
            evidence=[f"发现 {len(all_contacts)} 个联系人", "结合网站分析与 LLM 推测"],
            next_action="lead_scoring",
            status=AgentStatus.SUCCESS if len(all_contacts) > 0 else AgentStatus.PARTIAL,
        )

    def _discover_from_website(self, website: str, company_name: str) -> List[Dict]:
        """从网站发现联系人（Phase 2 基础版）。"""
        # Phase 2: 基础实现，未来可接入真实爬虫
        contacts = []
        if website and "linkedin.com" not in website:
            # 模拟发现通用联系邮箱
            domain = website.replace("https://", "").replace("http://", "").split("/")[0]
            if domain and "." in domain:
                contacts.append({
                    "name": "General Inquiry",
                    "title": "Sales/Procurement",
                    "email": f"info@{domain}",
                    "source": "website_pattern",
                    "verified": False,
                    "is_decision_maker": False,
                })
        return contacts

    def _llm_infer_contacts(self, profile: Dict, product: str) -> List[Dict]:
        """使用 LLM 推测关键联系人。"""
        prompt = f"""基于以下企业信息，推测该企业负责采购 {product} 的关键联系人职位和部门。

企业信息：
- 名称：{profile.get('name', '')}
- 行业：{profile.get('industry', '')}
- 规模：{profile.get('company_size', '')}
- 供应链角色：{profile.get('supply_chain_role', '')}

请输出 1-3 个最可能的关键联系人角色：
[
  {{"title": "职位名称", "department": "部门", "is_decision_maker": true/false, "likelihood": "high/medium/low"}}
]

用 JSON 数组格式输出。"""

        result = self.llm.chat(prompt=prompt, model_preference=["deepseek", "qwen", "openai"], temperature=0.4)

        contacts = []
        if result["success"] and result["parsed_json"]:
            roles = result["parsed_json"] if isinstance(result["parsed_json"], list) else []
            for role in roles:
                contacts.append({
                    "name": "",
                    "title": role.get("title", ""),
                    "email": "",
                    "department": role.get("department", ""),
                    "is_decision_maker": role.get("is_decision_maker", False),
                    "source": "llm_inference",
                    "verified": False,
                    "likelihood": role.get("likelihood", "medium"),
                })

        return contacts

    def _merge_contacts(self, web_contacts: List, llm_contacts: List, entity_id: str) -> List[Dict]:
        """合并并去重联系人。"""
        merged = []
        seen_titles = set()

        for c in web_contacts + llm_contacts:
            c["entity_id"] = entity_id
            c["contact_id"] = f"contact-{entity_id}-{hash(c.get('title', '')) & 0xFFFF}"

            key = f"{c.get('title', '')}-{c.get('email', '')}"
            if key not in seen_titles:
                seen_titles.add(key)
                merged.append(c)

        return merged
