# -*- coding: utf-8 -*-
"""Agent Base — 所有 Agent 的基类

定义统一的 Agent 生命周期：
- prepare: 准备输入
- execute: 执行核心逻辑
- validate: 验证输出
- persist: 持久化结果
"""
import time
from abc import ABC, abstractmethod
from typing import Dict, List, Any

from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import get_llm
from platform.audit.logger import AuditLogger
from contracts.event_contract import EventContract, EventType


class BaseAgent(ABC):
    """Agent 基类。"""

    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.llm = get_llm()
        self.audit = AuditLogger()

    @abstractmethod
    def execute(self, request: AgentRequest) -> AgentResponse:
        """执行 Agent 核心逻辑。子类必须实现。"""
        pass

    def run(self, request: AgentRequest) -> AgentResponse:
        """运行 Agent 完整生命周期。"""
        t0 = time.time()

        # 审计：Agent 被调用
        self._log_event(request, EventType.AGENT_INVOKED)

        try:
            # 执行
            response = self.execute(request)
            response.task_id = request.task_id
            response.agent_name = self.agent_name
            response.duration_ms = int((time.time() - t0) * 1000)

            # 审计：Agent 完成
            event_type = EventType.AGENT_COMPLETED if response.is_success() else EventType.AGENT_FAILED
            self._log_event(request, event_type, response=response)

            return response
        except Exception as e:
            response = AgentResponse(
                task_id=request.task_id,
                agent_name=self.agent_name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
            self._log_event(request, EventType.AGENT_FAILED, response=response)
            return response

    def _log_event(self, request: AgentRequest, event_type: EventType, response: AgentResponse = None):
        """记录审计事件。"""
        event = EventContract(
            event_type=event_type,
            task_id=request.task_id,
            agent_id=self.agent_name,
            input_data=request.to_dict(),
            output_data=response.to_dict() if response else {},
            status=response.status.value if response else "running",
            error=response.error if response else "",
        )
        self.audit.log(event)

    def _build_prompt(self, template: str, context: Dict[str, Any]) -> str:
        """使用模板构建 prompt。"""
        try:
            return template.format(**context)
        except KeyError as e:
            # 如果模板变量缺失，直接拼接
            prompt = template
            for k, v in context.items():
                prompt = prompt.replace(f"{{{k}}}", str(v))
            return prompt
