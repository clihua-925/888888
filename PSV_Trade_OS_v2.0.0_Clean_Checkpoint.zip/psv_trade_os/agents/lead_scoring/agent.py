# -*- coding: utf-8 -*-
"""Lead Scoring Agent — 线索评分智能体

负责：
- 企业实力评分
- 采购可能性评分
- 匹配程度评分
- 成交概率评分

输入：company_profiles, contacts, market_analysis
输出：customer_pool（评分后的客户池）
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from contracts.data_contract import CustomerPoolEntry, CustomerTier
from business.profiling.scoring import ScoringEngine


class LeadScoringAgent(BaseAgent):
    """线索评分 Agent。"""

    def __init__(self):
        super().__init__("lead_scoring")
        self.scoring_engine = ScoringEngine()

    def execute(self, request: AgentRequest) -> AgentResponse:
        company_profiles = request.input_data.get("company_profiles", {})
        contacts = request.input_data.get("contacts", [])
        market_analysis = request.context.get("market_analysis", {})
        product = request.input_data.get("product", "")

        customer_pool = []
        scoring_log = []

        for entity_id, profile in company_profiles.items():
            # 1. 多维度评分
            scores = self.scoring_engine.score(profile)

            # 2. LLM 增强评分
            llm_scores = self._llm_enhanced_scoring(profile, product, market_analysis)
            scores.update(llm_scores)

            # 3. 计算综合客户价值
            customer_value = self._calculate_customer_value(scores)

            # 4. 确定客户等级
            tier = self._determine_tier(scores)

            # 5. 计算开发优先级
            priority = self._calculate_priority(scores, tier)

            # 6. 关联联系人
            company_contacts = [c for c in contacts if c.get("entity_id") == entity_id]

            entry = CustomerPoolEntry(
                entity_id=entity_id,
                company_profile=profile,
                tier=tier,
                customer_value=customer_value,
                match_degree=scores.get("match_score", 0),
                deal_probability=scores.get("deal_probability", 0),
                development_priority=priority,
                follow_up_status="new",
                lead_source="psv_ai_discovery",
                assigned_agent="",
                tags=[product, profile.get("country", ""), profile.get("supply_chain_role", "")],
                notes=[f"联系人数量: {len(company_contacts)}"],
                created_at=time.time(),
                updated_at=time.time(),
            )

            customer_pool.append(entry.to_dict())
            scoring_log.append({
                "entity_id": entity_id,
                "name": profile.get("name", ""),
                "tier": tier.value,
                "customer_value": customer_value,
                "deal_probability": scores.get("deal_probability", 0),
            })

        # 按开发优先级排序
        customer_pool.sort(key=lambda x: x.get("development_priority", 0), reverse=True)

        return AgentResponse(
            task_id=request.task_id,
            agent_name=self.agent_name,
            result={
                "customer_pool": customer_pool,
                "total_scored": len(customer_pool),
                "tier_distribution": self._tier_distribution(customer_pool),
                "scoring_log": scoring_log,
            },
            confidence=ConfidenceLevel.STRONG if len(customer_pool) > 0 else ConfidenceLevel.WEAK,
            evidence=[f"评分 {len(customer_pool)} 家客户", "多维度评分模型 + LLM 增强"],
            next_action="sales_strategy",
            status=AgentStatus.SUCCESS,
        )

    def _llm_enhanced_scoring(self, profile: Dict, product: str, market_analysis: Dict) -> Dict[str, float]:
        """使用 LLM 进行增强评分。"""
        prompt = f"""请对以下企业进行外贸开发价值评分（0-100）：

企业：{profile.get('name', '')}
国家：{profile.get('country', '')}
行业：{profile.get('industry', '')}
主营产品：{profile.get('main_products', [])}
供应链角色：{profile.get('supply_chain_role', '')}
目标产品：{product}

请输出 JSON：
{{
  "deal_probability": 成交概率评分,
  "market_fit": 市场契合度,
  "purchasing_power": 采购实力,
  "reasoning": "评分理由"
}}"""

        result = self.llm.chat(prompt=prompt, model_preference=["deepseek", "qwen", "openai"], temperature=0.3)

        if result["success"] and result["parsed_json"]:
            parsed = result["parsed_json"]
            return {
                "deal_probability": float(parsed.get("deal_probability", 50)),
                "market_fit": float(parsed.get("market_fit", 50)),
                "purchasing_power": float(parsed.get("purchasing_power", 50)),
            }

        return {"deal_probability": 50, "market_fit": 50, "purchasing_power": 50}

    def _calculate_customer_value(self, scores: Dict[str, float]) -> float:
        """计算综合客户价值。"""
        weights = {
            "credibility_score": 0.2,
            "purchase_probability": 0.25,
            "match_score": 0.25,
            "deal_probability": 0.2,
            "purchasing_power": 0.1,
        }
        value = 0
        for key, weight in weights.items():
            value += scores.get(key, 0) * weight
        return round(value, 1)

    def _determine_tier(self, scores: Dict[str, float]) -> CustomerTier:
        """确定客户等级。"""
        deal_prob = scores.get("deal_probability", 0)
        match = scores.get("match_score", 0)
        credibility = scores.get("credibility_score", 0)

        if deal_prob >= 80 and match >= 80 and credibility >= 70:
            return CustomerTier.S
        elif deal_prob >= 65 and match >= 65:
            return CustomerTier.A
        elif deal_prob >= 50 and match >= 50:
            return CustomerTier.B
        elif deal_prob >= 30 and match >= 30:
            return CustomerTier.C
        else:
            return CustomerTier.D

    def _calculate_priority(self, scores: Dict[str, float], tier: CustomerTier) -> int:
        """计算开发优先级（1-100）。"""
        base = scores.get("deal_probability", 0) * 0.4 + scores.get("match_score", 0) * 0.4
        tier_bonus = {"S": 20, "A": 15, "B": 10, "C": 5, "D": 0}
        return min(int(base + tier_bonus.get(tier.value, 0)), 100)

    def _tier_distribution(self, pool: List[Dict]) -> Dict[str, int]:
        dist = {"S": 0, "A": 0, "B": 0, "C": 0, "D": 0}
        for entry in pool:
            tier = entry.get("tier", "C")
            dist[tier] = dist.get(tier, 0) + 1
        return dist
