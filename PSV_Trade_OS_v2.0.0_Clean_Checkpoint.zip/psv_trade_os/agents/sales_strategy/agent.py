# -*- coding: utf-8 -*-
"""Sales Strategy Agent — 销售策略智能体

负责：
- 生成开发策略
- 邮件方向建议
- 跟进建议
- 商业机会识别

输入：customer_pool, company_profiles, market_analysis
输出：opportunities（商业机会列表）
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel


class SalesStrategyAgent(BaseAgent):
    """销售策略 Agent。"""

    def __init__(self):
        super().__init__("sales_strategy")

    def execute(self, request: AgentRequest) -> AgentResponse:
        customer_pool = request.input_data.get("customer_pool", [])
        company_profiles = request.input_data.get("company_profiles", {})
        market_analysis = request.context.get("market_analysis", {})
        product = request.input_data.get("product", "")

        opportunities = []
        strategy_log = []

        # 只针对高价值客户生成策略
        high_value_customers = [c for c in customer_pool if c.get("tier") in ("S", "A", "B")]

        for customer in high_value_customers:
            entity_id = customer.get("entity_id", "")
            profile = company_profiles.get(entity_id, {})

            # 1. LLM 生成开发策略
            strategy = self._generate_strategy(profile, customer, product, market_analysis)

            # 2. 生成邮件建议
            email_draft = self._generate_email_draft(profile, customer, product)

            opportunity = {
                "opportunity_id": f"opp-{entity_id}-{int(time.time())}",
                "entity_id": entity_id,
                "company_name": profile.get("name", ""),
                "title": f"{profile.get('name', '')} - {product} 开发机会",
                "description": strategy.get("strategy_summary", ""),
                "estimated_value": strategy.get("estimated_value", 0),
                "probability": customer.get("deal_probability", 0),
                "strategy": strategy,
                "email_draft": email_draft,
                "recommended_actions": strategy.get("actions", []),
                "follow_up_plan": strategy.get("follow_up", []),
                "status": "open",
                "created_at": time.time(),
            }

            opportunities.append(opportunity)
            strategy_log.append({
                "entity_id": entity_id,
                "strategy_generated": True,
                "has_email_draft": bool(email_draft),
            })

        return AgentResponse(
            task_id=request.task_id,
            agent_name=self.agent_name,
            result={
                "opportunities": opportunities,
                "total_opportunities": len(opportunities),
                "strategy_log": strategy_log,
            },
            confidence=ConfidenceLevel.MEDIUM if len(opportunities) > 0 else ConfidenceLevel.WEAK,
            evidence=[f"为 {len(opportunities)} 家高价值客户生成策略", "包含开发信草稿与跟进计划"],
            next_action="report",
            status=AgentStatus.SUCCESS,
        )

    def _generate_strategy(self, profile: Dict, customer: Dict, product: str, market_analysis: Dict) -> Dict:
        """生成开发策略。"""
        prompt = f"""请为以下客户生成外贸开发策略：

客户：{profile.get('name', '')}
国家：{profile.get('country', '')}
行业：{profile.get('industry', '')}
供应链角色：{profile.get('supply_chain_role', '')}
客户等级：{customer.get('tier', '')}
成交概率：{customer.get('deal_probability', 0)}%

目标产品：{product}

请输出：
1. 策略概述（100字内）
2. 核心卖点（3-5条）
3. 建议首次接触方式（邮件/电话/LinkedIn）
4. 跟进计划（3个阶段）
5. 预估订单价值（USD）
6. 风险提示

用 JSON 格式输出。"""

        result = self.llm.chat(prompt=prompt, model_preference=["deepseek", "qwen", "openai"], temperature=0.5)

        if result["success"] and result["parsed_json"]:
            parsed = result["parsed_json"]
            return {
                "strategy_summary": parsed.get("策略概述", ""),
                "key_selling_points": parsed.get("核心卖点", []),
                "first_contact_method": parsed.get("建议首次接触方式", "email"),
                "actions": parsed.get("跟进计划", []),
                "estimated_value": self._parse_value(parsed.get("预估订单价值", "0")),
                "risk_factors": parsed.get("风险提示", []),
                "follow_up": [
                    "第1周：发送开发信并跟进",
                    "第2-3周：电话/视频会议沟通",
                    "第4周：发送样品或报价单",
                ],
            }

        # Fallback
        return {
            "strategy_summary": f"针对 {profile.get('name', '')} 的 {product} 开发策略",
            "key_selling_points": ["高质量产品", "有竞争力的价格", "快速交付"],
            "first_contact_method": "email",
            "actions": ["发送开发信", "跟进电话", "提供样品"],
            "estimated_value": 50000,
            "risk_factors": ["新客户信用风险", "文化差异"],
            "follow_up": ["第1周邮件", "第2周电话", "第4周样品"],
        }

    def _generate_email_draft(self, profile: Dict, customer: Dict, product: str) -> str:
        """生成开发信草稿。"""
        prompt = f"""请为以下客户撰写一封外贸开发信（英文）：

客户：{profile.get('name', '')}
国家：{profile.get('country', '')}
行业：{profile.get('industry', '')}

目标产品：{product}

要求：
1. 主题行吸引人但不过度推销
2. 正文 150-200 词
3. 突出产品优势
4. 包含明确的行动号召（CTA）
5. 专业但友好的语气

直接输出邮件内容。"""

        result = self.llm.chat(prompt=prompt, model_preference=["deepseek", "qwen", "openai"], temperature=0.6)

        if result["success"]:
            return result["content"]

        return f"Subject: Premium {product} Supplier - Partnership Opportunity\n\nDear Sir/Madam,\n\nWe are a leading manufacturer of {product}. We would like to explore partnership opportunities with {profile.get('name', 'your company')}.\n\nBest regards,"

    def _parse_value(self, value_str: str) -> float:
        """解析预估价值字符串。"""
        import re
        numbers = re.findall(r'[\d,]+', str(value_str))
        if numbers:
            return float(numbers[0].replace(",", ""))
        return 50000
