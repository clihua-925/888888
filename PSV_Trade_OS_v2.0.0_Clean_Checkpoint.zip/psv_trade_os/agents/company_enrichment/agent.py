# -*- coding: utf-8 -*-
"""Company Enrichment Agent — 企业补全智能体

负责：
- 企业信息补全
- 网站分析
- 产品匹配验证
- 采购方向确认

输入：company_pool
输出：company_profiles（补全后的企业画像）
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from contracts.data_contract import CompanyProfile
from business.collection.website_intel import WebsiteIntelligence


class CompanyEnrichmentAgent(BaseAgent):
    """企业补全 Agent。"""

    def __init__(self):
        super().__init__("company_enrichment")
        self.website_intel = WebsiteIntelligence()

    def execute(self, request: AgentRequest) -> AgentResponse:
        company_pool = request.input_data.get("company_pool", [])
        product = request.input_data.get("product", "")

        enriched_profiles = {}
        enrichment_log = []

        for company_data in company_pool:
            entity_id = company_data.get("entity_id", "")
            name = company_data.get("name", "")
            website = company_data.get("website", "")

            # 1. 网站情报采集
            web_intel = {}
            if website:
                web_intel = self.website_intel.analyze(website)

            # 2. LLM 补全分析
            enriched = self._enrich_by_llm(company_data, product, web_intel)

            # 3. 产品匹配度初步评估
            match_score = self._calculate_match_score(enriched, product)
            enriched["match_score"] = match_score

            enriched_profiles[entity_id] = enriched
            enrichment_log.append({
                "entity_id": entity_id,
                "name": name,
                "web_intel_found": bool(web_intel),
                "match_score": match_score,
            })

        return AgentResponse(
            task_id=request.task_id,
            agent_name=self.agent_name,
            result={
                "company_profiles": enriched_profiles,
                "enriched_count": len(enriched_profiles),
                "enrichment_log": enrichment_log,
            },
            confidence=ConfidenceLevel.MEDIUM,
            evidence=[f"补全 {len(enriched_profiles)} 家企业信息", "结合网站情报与 LLM 分析"],
            next_action="contact_discovery",
            status=AgentStatus.SUCCESS,
        )

    def _enrich_by_llm(self, company_data: Dict, product: str, web_intel: Dict) -> Dict:
        """使用 LLM 补全企业信息。"""
        prompt = f"""请基于以下企业信息，补全并验证该企业是否可能是 "{product}" 的采购方。

企业已知信息：
{company_data}

网站情报：
{web_intel}

请输出：
1. 企业主营产品（列表）
2. 采购方向（列表）
3. 供应链角色（importer/distributor/retailer/supplier）
4. 可信度评分（0-100）
5. 采购可能性评分（0-100）
6. 判断依据

用 JSON 格式输出。"""

        result = self.llm.chat(
            prompt=prompt,
            model_preference=["deepseek", "qwen", "openai"],
            temperature=0.3,
        )

        enriched = dict(company_data)

        if result["success"] and result["parsed_json"]:
            parsed = result["parsed_json"]
            enriched["main_products"] = parsed.get("main_products", company_data.get("main_products", []))
            enriched["purchase_direction"] = parsed.get("purchase_direction", [])
            enriched["supply_chain_role"] = parsed.get("supply_chain_role", company_data.get("supply_chain_role", ""))
            enriched["credibility_score"] = parsed.get("credibility_score", 50)
            enriched["purchase_probability"] = parsed.get("purchase_probability", 50)
            enriched["evidence"] = [parsed.get("判断依据", "")] if isinstance(parsed.get("判断依据"), str) else []
        else:
            # Fallback
            enriched["credibility_score"] = 30
            enriched["purchase_probability"] = 30
            enriched["evidence"] = ["信息不足，无法验证"]

        enriched["enriched_at"] = time.time()
        return enriched

    def _calculate_match_score(self, enriched: Dict, product: str) -> float:
        """计算产品匹配度。"""
        score = 0.0
        purchase_direction = enriched.get("purchase_direction", [])
        main_products = enriched.get("main_products", [])

        product_lower = product.lower()

        # 采购方向匹配
        for direction in purchase_direction:
            if product_lower in direction.lower() or any(w in direction.lower() for w in product_lower.split()):
                score += 40
                break

        # 主营产品相关
        for mp in main_products:
            if product_lower in mp.lower() or any(w in mp.lower() for w in product_lower.split()):
                score += 30
                break

        # 供应链角色加分
        role = enriched.get("supply_chain_role", "").lower()
        if role in ("importer", "distributor", "retailer"):
            score += 20

        # 基础分
        score += 10

        return min(score, 100)
