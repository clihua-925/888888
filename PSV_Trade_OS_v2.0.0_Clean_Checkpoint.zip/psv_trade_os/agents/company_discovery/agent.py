# -*- coding: utf-8 -*-
"""Company Discovery Agent — 企业发现智能体

负责：
- 寻找进口商
- 寻找买家
- 寻找经销商
- 寻找渠道商

输入：产品、市场、客户类型
输出：company_pool（企业候选列表）
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from contracts.data_contract import CompanyProfile, CompanySize
from business.collection.discovery import DiscoveryEngine


class CompanyDiscoveryAgent(BaseAgent):
    """企业发现 Agent。"""

    def __init__(self):
        super().__init__("company_discovery")
        self.discovery_engine = DiscoveryEngine()

    def execute(self, request: AgentRequest) -> AgentResponse:
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")
        customer_type = request.input_data.get("target_customer", "importer")
        market_analysis = request.context.get("market_analysis", {})

        # 1. 使用发现引擎搜索企业
        raw_companies = self.discovery_engine.discover(product, market, customer_type)

        # 2. 如果没有找到，使用 LLM 生成候选（模拟/补充）
        if not raw_companies:
            raw_companies = self._llm_generate_candidates(product, market, customer_type)

        # 3. 标准化为企业画像
        company_pool = []
        for raw in raw_companies:
            profile = self._to_company_profile(raw)
            company_pool.append(profile.to_dict())

        return AgentResponse(
            task_id=request.task_id,
            agent_name=self.agent_name,
            result={
                "company_pool": company_pool,
                "total_found": len(company_pool),
                "market": market,
                "customer_type": customer_type,
            },
            confidence=ConfidenceLevel.MEDIUM if len(company_pool) > 0 else ConfidenceLevel.WEAK,
            evidence=[f"发现 {len(company_pool)} 家候选企业", f"目标市场: {market}", f"客户类型: {customer_type}"],
            next_action="company_enrichment",
            status=AgentStatus.SUCCESS if len(company_pool) > 0 else AgentStatus.PARTIAL,
        )

    def _llm_generate_candidates(self, product: str, market: str, customer_type: str) -> List[Dict]:
        """使用 LLM 生成候选企业列表（当外部数据源不可用时）。"""
        prompt = f"""请列出在 {market} 市场从事 {product} 相关业务的 {customer_type} 类型企业。

请输出 5-10 家企业的基本信息，每家企业包含：
- 公司名称
- 国家
- 官网（如有）
- 行业
- 主营业务
- 企业规模（small/medium/large/enterprise）

请用 JSON 数组格式输出，格式如下：
[
  {{"name": "公司名", "country": "国家", "website": "", "industry": "", "main_products": [""], "company_size": "medium"}}
]"""

        result = self.llm.chat(
            prompt=prompt,
            model_preference=["deepseek", "qwen", "openai"],
            temperature=0.5,
        )

        if result["success"] and result["parsed_json"]:
            return result["parsed_json"] if isinstance(result["parsed_json"], list) else []

        # Fallback: 返回空列表
        return []

    def _to_company_profile(self, raw: Dict[str, Any]) -> CompanyProfile:
        """将原始数据转换为企业画像。"""
        return CompanyProfile(
            entity_id=raw.get("entity_id") or f"ent-{hash(raw.get('name', '')) & 0xFFFFFFFF}",
            name=raw.get("name", ""),
            country=raw.get("country", ""),
            website=raw.get("website", ""),
            industry=raw.get("industry", ""),
            main_products=raw.get("main_products", []),
            purchase_direction=raw.get("purchase_direction", []),
            company_size=CompanySize(raw.get("company_size", "unknown")),
            supply_chain_role=raw.get("supply_chain_role", ""),
            raw_data=raw,
        )
