# -*- coding: utf-8 -*-
"""Market Research Agent — 市场研究智能体

负责：
- 国家市场分析
- 产品趋势
- 行业分析
- 市场机会

输入：产品、目标市场
输出：market_analysis（市场规模、增长趋势、竞争格局、进入策略）
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.knowledge.market import MarketKnowledge
from shared.knowledge.product import ProductKnowledge
from shared.knowledge.industry import IndustryKnowledge


class MarketResearchAgent(BaseAgent):
    """市场研究 Agent。"""

    def __init__(self):
        super().__init__("market_research")

    def execute(self, request: AgentRequest) -> AgentResponse:
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")

        # 1. 加载知识库
        market_info = MarketKnowledge.get(market)
        product_info = ProductKnowledge.get(product)

        # 2. 构建分析 prompt
        prompt = self._build_analysis_prompt(product, market, market_info, product_info)

        # 3. 调用 LLM 分析
        llm_result = self.llm.chat(
            prompt=prompt,
            model_preference=["deepseek", "qwen", "openai"],
            system_prompt="你是一位资深外贸市场分析师。请基于提供的信息进行专业分析，输出结构化结果。",
            temperature=0.3,
        )

        # 4. 解析结果
        analysis = self._parse_analysis(llm_result.get("content", ""), product, market)

        # 5. 构建响应
        return AgentResponse(
            task_id=request.task_id,
            agent_name=self.agent_name,
            result={"market_analysis": analysis},
            confidence=ConfidenceLevel.MEDIUM if llm_result["success"] else ConfidenceLevel.WEAK,
            evidence=["基于知识库数据", "LLM 市场分析"] if llm_result["success"] else ["LLM 调用失败，使用基础分析"],
            next_action="company_discovery",
            status=AgentStatus.SUCCESS,
        )

    def _build_analysis_prompt(self, product: str, market: str,
                               market_info: Dict, product_info: Dict) -> str:
        return f"""请对以下外贸目标进行市场分析：

产品：{product}
目标市场：{market}

已知市场信息：{market_info or '暂无'}
已知产品信息：{product_info or '暂无'}

请输出以下维度的分析（用中文）：
1. 市场规模与容量
2. 市场增长趋势
3. 主要竞争对手
4. 进口政策与关税
5. 主要分销渠道
6. 目标客户画像
7. 市场进入建议
8. 风险因素

请用结构化格式输出。"""

    def _parse_analysis(self, content: str, product: str, market: str) -> Dict[str, Any]:
        """解析 LLM 输出为结构化分析。"""
        # 基础结构
        analysis = {
            "product": product,
            "market": market,
            "market_size": "",
            "growth_trend": "",
            "competitors": [],
            "import_policy": "",
            "distribution_channels": [],
            "target_customer_profile": {},
            "entry_recommendations": [],
            "risk_factors": [],
            "raw_analysis": content,
            "timestamp": time.time(),
        }

        # 简单解析（Phase 2 基础版，Phase 3 可增强为结构化解析）
        lines = content.split("\n")
        current_section = None

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if "市场规模" in line or "市场容量" in line:
                current_section = "market_size"
            elif "增长趋势" in line or "增长" in line:
                current_section = "growth_trend"
            elif "竞争对手" in line or "竞争" in line:
                current_section = "competitors"
            elif "进口政策" in line or "关税" in line:
                current_section = "import_policy"
            elif "渠道" in line:
                current_section = "distribution_channels"
            elif "客户画像" in line or "目标客户" in line:
                current_section = "target_customer_profile"
            elif "进入建议" in line or "建议" in line:
                current_section = "entry_recommendations"
            elif "风险" in line:
                current_section = "risk_factors"
            elif current_section and line and not line.startswith("#"):
                if current_section == "competitors":
                    analysis["competitors"].append(line.lstrip("- * 1234567890.").strip())
                elif current_section == "distribution_channels":
                    analysis["distribution_channels"].append(line.lstrip("- * 1234567890.").strip())
                elif current_section == "entry_recommendations":
                    analysis["entry_recommendations"].append(line.lstrip("- * 1234567890.").strip())
                elif current_section == "risk_factors":
                    analysis["risk_factors"].append(line.lstrip("- * 1234567890.").strip())
                elif current_section in ("market_size", "growth_trend", "import_policy"):
                    if not analysis[current_section]:
                        analysis[current_section] = line

        return analysis
