# -*- coding: utf-8 -*-
"""Report Agent — 报告生成智能体

负责：
- 汇总所有 Agent 结果
- 生成最终外贸开发报告
- 输出可执行的行动清单

输入：所有 Agent 结果
输出：final_report
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel


class ReportAgent(BaseAgent):
    """报告生成 Agent。"""

    def __init__(self):
        super().__init__("report")

    def execute(self, request: AgentRequest) -> AgentResponse:
        market_analysis = request.input_data.get("market_analysis", {})
        company_pool = request.input_data.get("company_pool", [])
        company_profiles = request.input_data.get("company_profiles", {})
        customer_pool = request.input_data.get("customer_pool", [])
        contacts = request.input_data.get("contacts", [])
        opportunities = request.input_data.get("opportunities", [])
        agent_history = request.context.get("agent_history", [])
        routing_path = request.context.get("routing_path", [])

        task_contract = request.context.get("task_contract", {})
        objective = task_contract.get("objective", "")
        product = task_contract.get("product", "")
        market = task_contract.get("market", "")

        # 1. 生成报告摘要
        summary = self._generate_summary(
            objective, product, market,
            market_analysis, company_pool, customer_pool,
            contacts, opportunities
        )

        # 2. 生成执行清单
        action_items = self._generate_action_items(opportunities, customer_pool)

        # 3. 生成风险提醒
        risk_alerts = self._generate_risk_alerts(market_analysis, customer_pool)

        # 4. 统计信息
        stats = {
            "total_companies_discovered": len(company_pool),
            "total_companies_enriched": len(company_profiles),
            "total_contacts_found": len(contacts),
            "total_customers_scored": len(customer_pool),
            "tier_s": sum(1 for c in customer_pool if c.get("tier") == "S"),
            "tier_a": sum(1 for c in customer_pool if c.get("tier") == "A"),
            "tier_b": sum(1 for c in customer_pool if c.get("tier") == "B"),
            "tier_c": sum(1 for c in customer_pool if c.get("tier") == "C"),
            "tier_d": sum(1 for c in customer_pool if c.get("tier") == "D"),
            "total_opportunities": len(opportunities),
            "estimated_total_value": sum(o.get("estimated_value", 0) for o in opportunities),
        }

        # 5. 构建最终报告
        final_report = {
            "report_id": f"report-{request.task_id}",
            "generated_at": time.time(),
            "task_summary": {
                "objective": objective,
                "product": product,
                "market": market,
                "execution_path": routing_path,
                "agents_executed": len(agent_history),
            },
            "executive_summary": summary,
            "market_overview": market_analysis,
            "top_customers": customer_pool[:10],
            "opportunities": opportunities,
            "action_items": action_items,
            "risk_alerts": risk_alerts,
            "statistics": stats,
            "appendix": {
                "full_company_list": company_pool,
                "full_contact_list": contacts,
                "agent_execution_log": agent_history,
            },
        }

        return AgentResponse(
            task_id=request.task_id,
            agent_name=self.agent_name,
            result={"final_report": final_report},
            confidence=ConfidenceLevel.STRONG,
            evidence=["汇总所有 Agent 结果", f"生成 {len(action_items)} 项行动建议"],
            next_action="deliver",
            status=AgentStatus.SUCCESS,
        )

    def _generate_summary(self, objective: str, product: str, market: str,
                          market_analysis: Dict, company_pool: List,
                          customer_pool: List, contacts: List, opportunities: List) -> str:
        """生成执行摘要。"""
        tier_s = sum(1 for c in customer_pool if c.get("tier") == "S")
        tier_a = sum(1 for c in customer_pool if c.get("tier") == "A")
        total_value = sum(o.get("estimated_value", 0) for o in opportunities)

        summary = f"""# 外贸开发报告摘要

## 任务目标
{objective}

## 关键发现
- **目标市场**：{market}
- **目标产品**：{product}
- **发现企业**：{len(company_pool)} 家
- **评分客户**：{len(customer_pool)} 家
- **战略级客户(S)**：{tier_s} 家
- **高价值客户(A)**：{tier_a} 家
- **发现联系人**：{len(contacts)} 个
- **商业机会**：{len(opportunities)} 个
- **预估总价值**：${total_value:,.0f}

## 市场概况
{market_analysis.get("market_size", "待补充")}

## 建议优先行动
1. 立即联系 S 级和 A 级客户
2. 发送定制开发信
3. 准备产品样品和报价单
4. 建立客户跟进计划
"""
        return summary

    def _generate_action_items(self, opportunities: List, customer_pool: List) -> List[Dict]:
        """生成可执行的行动清单。"""
        actions = []

        # 高优先级行动
        for opp in opportunities[:5]:
            actions.append({
                "priority": "high",
                "action": f"联系 {opp.get('company_name', '')}",
                "details": opp.get("description", ""),
                "deadline": "本周内",
                "owner": "sales_team",
                "status": "pending",
            })

        # 中优先级行动
        for customer in customer_pool:
            if customer.get("tier") == "B":
                actions.append({
                    "priority": "medium",
                    "action": f"评估 {customer.get('company_profile', {}).get('name', '')} 的潜力",
                    "details": "",
                    "deadline": "两周内",
                    "owner": "sales_team",
                    "status": "pending",
                })

        return actions

    def _generate_risk_alerts(self, market_analysis: Dict, customer_pool: List) -> List[Dict]:
        """生成风险提醒。"""
        alerts = []

        # 市场风险
        risks = market_analysis.get("risk_factors", [])
        for risk in risks[:3]:
            alerts.append({
                "type": "market",
                "level": "medium",
                "message": risk,
                "mitigation": "密切关注市场动态",
            })

        # 客户风险
        low_credibility = [c for c in customer_pool if c.get("company_profile", {}).get("credibility_score", 0) < 40]
        if low_credibility:
            alerts.append({
                "type": "customer",
                "level": "high",
                "message": f"{len(low_credibility)} 家客户可信度较低，需进一步验证",
                "mitigation": "要求提供公司注册信息、银行资信证明",
            })

        return alerts
