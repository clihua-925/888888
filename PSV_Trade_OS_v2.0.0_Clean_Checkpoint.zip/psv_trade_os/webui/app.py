# -*- coding: utf-8 -*-
"""WebUI — 外贸业务界面

界面必须围绕外贸业务：
- 市场分析
- 客户池
- 企业画像
- 开发任务
- 商业机会
- 供应链关系
- 智能报告

Phase 2 实现完整界面。
"""
from flask import Flask, render_template

app = Flask(__name__, template_folder="templates", static_folder="static")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/customer_pool")
def customer_pool():
    return render_template("customer_pool.html")


@app.route("/company_profile/<entity_id>")
def company_profile(entity_id: str):
    return render_template("company_profile.html", entity_id=entity_id)


@app.route("/tasks")
def tasks():
    return render_template("tasks.html")


@app.route("/opportunities")
def opportunities():
    return render_template("opportunities.html")


@app.route("/reports")
def reports():
    return render_template("reports.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
