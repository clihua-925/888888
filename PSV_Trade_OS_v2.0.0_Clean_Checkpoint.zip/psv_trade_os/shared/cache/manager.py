# -*- coding: utf-8 -*-
"""Cache Manager — 统一缓存管理

支持内存缓存和磁盘缓存。
"""
import time
import json
import hashlib
from typing import Dict, Any, Optional
from pathlib import Path

from shared.config.settings import settings


class CacheManager:
    """缓存管理器。"""

    def __init__(self, ttl_seconds: int = 3600):
        self._memory: Dict[str, Dict[str, Any]] = {}
        self.ttl = ttl_seconds
        self.disk_dir = Path(settings.CHECKPOINT_DIR) / "cache"
        self.disk_dir.mkdir(parents=True, exist_ok=True)

    def _key(self, namespace: str, identifier: str) -> str:
        raw = f"{namespace}:{identifier}"
        return hashlib.md5(raw.encode()).hexdigest()

    def _disk_path(self, key: str) -> Path:
        return self.disk_dir / f"{key}.json"

    def get(self, namespace: str, identifier: str) -> Optional[Any]:
        key = self._key(namespace, identifier)

        # 先查内存
        if key in self._memory:
            entry = self._memory[key]
            if time.time() - entry["ts"] < self.ttl:
                return entry["data"]
            del self._memory[key]

        # 再查磁盘
        path = self._disk_path(key)
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    entry = json.load(f)
                if time.time() - entry["ts"] < self.ttl:
                    self._memory[key] = entry
                    return entry["data"]
                path.unlink()
            except Exception:
                pass

        return None

    def set(self, namespace: str, identifier: str, data: Any) -> bool:
        key = self._key(namespace, identifier)
        entry = {"ts": time.time(), "data": data}
        self._memory[key] = entry

        try:
            with open(self._disk_path(key), "w", encoding="utf-8") as f:
                json.dump(entry, f, ensure_ascii=False)
            return True
        except Exception:
            return False

    def invalidate(self, namespace: str, identifier: str = None) -> bool:
        if identifier:
            key = self._key(namespace, identifier)
            self._memory.pop(key, None)
            path = self._disk_path(key)
            if path.exists():
                path.unlink()
        else:
            # 清除整个 namespace
            prefix = hashlib.md5(f"{namespace}:".encode()).hexdigest()[:8]
            for k in list(self._memory.keys()):
                if k.startswith(prefix):
                    del self._memory[k]
            for p in self.disk_dir.glob("*.json"):
                p.unlink()
        return True
