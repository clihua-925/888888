# -*- coding: utf-8 -*-
"""LLM Client — 统一大语言模型调用层

支持多模型路由：OpenAI / DeepSeek / Qwen
所有 Agent 通过此层调用 LLM，禁止直接调用 openai 库。
"""
import time
import json
from typing import Dict, List, Any, Optional

from shared.config.settings import settings


class LLMClient:
    """统一 LLM 客户端。"""

    def __init__(self):
        self._clients = {}
        self._init_clients()

    def _init_clients(self):
        """初始化各厂商客户端。"""
        try:
            from openai import OpenAI
            if settings.OPENAI_API_KEY:
                self._clients["openai"] = OpenAI(
                    api_key=settings.OPENAI_API_KEY,
                    base_url=settings.OPENAI_BASE_URL,
                )
            if settings.DEEPSEEK_API_KEY:
                self._clients["deepseek"] = OpenAI(
                    api_key=settings.DEEPSEEK_API_KEY,
                    base_url=settings.DEEPSEEK_BASE_URL,
                )
            if settings.QWEN_API_KEY:
                self._clients["qwen"] = OpenAI(
                    api_key=settings.QWEN_API_KEY,
                    base_url=settings.QWEN_BASE_URL,
                )
        except ImportError:
            pass

    def chat(self, prompt: str, model_preference: List[str] = None,
             system_prompt: str = None, temperature: float = 0.7,
             max_tokens: int = 2000, json_mode: bool = False) -> Dict[str, Any]:
        """统一聊天接口。

        Returns:
            {
                "success": bool,
                "content": str,
                "parsed_json": dict|None,
                "provider": str,
                "error": str,
            }
        """
        providers = model_preference or ["openai", "deepseek", "qwen"]

        for provider in providers:
            client = self._clients.get(provider)
            if not client:
                continue

            model_map = {
                "openai": settings.DEFAULT_LLM_MODEL,
                "deepseek": "deepseek-chat",
                "qwen": "qwen-max",
            }
            model = model_map.get(provider, settings.DEFAULT_LLM_MODEL)

            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})

            try:
                kwargs = {
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                }
                if json_mode and provider == "openai":
                    kwargs["response_format"] = {"type": "json_object"}

                t0 = time.time()
                resp = client.chat.completions.create(**kwargs)
                content = resp.choices[0].message.content or ""
                duration_ms = int((time.time() - t0) * 1000)

                parsed = None
                if json_mode:
                    try:
                        parsed = json.loads(content)
                    except:
                        pass

                return {
                    "success": True,
                    "content": content,
                    "parsed_json": parsed,
                    "provider": provider,
                    "model": model,
                    "duration_ms": duration_ms,
                    "error": "",
                }
            except Exception as e:
                continue

        return {
            "success": False,
            "content": "",
            "parsed_json": None,
            "provider": "",
            "error": f"All providers failed. Last error: {str(e)}",
        }

    def structured_output(self, prompt: str, schema: Dict[str, Any],
                          model_preference: List[str] = None) -> Dict[str, Any]:
        """获取结构化输出。"""
        system = f"You must respond with valid JSON matching this schema: {json.dumps(schema, ensure_ascii=False)}"
        return self.chat(prompt, model_preference, system_prompt=system, json_mode=True)


# 全局单例
_llm_client = None


def get_llm() -> LLMClient:
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client
