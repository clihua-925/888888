# -*- coding: utf-8 -*-
"""Market Knowledge — 市场知识库

保存各国家/地区的市场特征、法规、渠道、文化等。
"""
from typing import Dict, List, Any


class MarketKnowledge:
    """市场知识管理。"""

    _markets: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def load(cls, market_key: str, data: Dict[str, Any]) -> None:
        cls._markets[market_key] = data

    @classmethod
    def get(cls, market_key: str) -> Dict[str, Any]:
        return cls._markets.get(market_key, {})

    @classmethod
    def list_all(cls) -> List[str]:
        return list(cls._markets.keys())
