# -*- coding: utf-8 -*-
"""Product Knowledge — 产品知识库

保存产品特征、竞品、应用场景、目标客户画像等。
"""
from typing import Dict, List, Any


class ProductKnowledge:
    """产品知识管理。"""

    _products: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def load(cls, product_key: str, data: Dict[str, Any]) -> None:
        cls._products[product_key] = data

    @classmethod
    def get(cls, product_key: str) -> Dict[str, Any]:
        return cls._products.get(product_key, {})

    @classmethod
    def list_all(cls) -> List[str]:
        return list(cls._products.keys())
