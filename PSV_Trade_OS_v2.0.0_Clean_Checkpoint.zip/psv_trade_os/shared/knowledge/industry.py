# -*- coding: utf-8 -*-
"""Industry Knowledge — 行业知识库

保存各行业的特征、术语、供应链结构、关键玩家等。
"""
from typing import Dict, List, Any


class IndustryKnowledge:
    """行业知识管理。"""

    _industries: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def load(cls, industry_key: str, data: Dict[str, Any]) -> None:
        """加载行业配置。"""
        cls._industries[industry_key] = data

    @classmethod
    def get(cls, industry_key: str) -> Dict[str, Any]:
        """获取行业知识。"""
        return cls._industries.get(industry_key, {})

    @classmethod
    def list_all(cls) -> List[str]:
        """列出所有已加载行业。"""
        return list(cls._industries.keys())

    @classmethod
    def get_hs_codes(cls, industry_key: str) -> List[str]:
        """获取行业的 HS 编码。"""
        industry = cls._industries.get(industry_key, {})
        return industry.get("hs_codes", [])

    @classmethod
    def get_keywords(cls, industry_key: str) -> List[str]:
        """获取行业的关键词。"""
        industry = cls._industries.get(industry_key, {})
        return industry.get("keywords", [])
