# -*- coding: utf-8 -*-
"""Workflow State — LangGraph workflow 状态持久化

支持：
- 暂停
- 恢复
- 继续执行
"""
import json
import time
from typing import Dict, Any, Optional

from orchestrator.checkpoint import PSVCheckpoint


class WorkflowStateManager:
    """工作流状态管理器。"""

    def __init__(self):
        self.checkpoint = PSVCheckpoint()

    def save(self, task_id: str, state: Dict[str, Any]) -> str:
        """保存工作流状态。"""
        return self.checkpoint.save(task_id, state)

    def load(self, task_id: str) -> Optional[Dict[str, Any]]:
        """加载工作流状态。"""
        data = self.checkpoint.load(task_id)
        if data:
            return data.get("state")
        return None

    def pause(self, task_id: str, state: Dict[str, Any]) -> str:
        """暂停工作流，保存状态。"""
        state["status"] = "paused"
        return self.save(task_id, state)

    def resume(self, task_id: str) -> Optional[Dict[str, Any]]:
        """恢复工作流。"""
        state = self.load(task_id)
        if state:
            state["status"] = "resuming"
        return state
