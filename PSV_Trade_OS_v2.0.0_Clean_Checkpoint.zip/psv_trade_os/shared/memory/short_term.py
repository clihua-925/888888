# -*- coding: utf-8 -*-
"""Short-term Memory — 当前任务状态记忆

保存当前正在执行的任务的上下文、中间结果、Agent 状态。
生命周期：任务开始 → 任务结束（成功/失败）
"""
from typing import Dict, List, Any, Optional
import time


class ShortTermMemory:
    """短期记忆管理器。"""

    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}

    def create(self, task_id: str, initial_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """为任务创建短期记忆空间。"""
        self._store[task_id] = {
            "task_id": task_id,
            "created_at": time.time(),
            "data": initial_data or {},
            "agent_contexts": {},
        }
        return self._store[task_id]

    def get(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取任务的短期记忆。"""
        return self._store.get(task_id)

    def update(self, task_id: str, key: str, value: Any) -> bool:
        """更新短期记忆中的某个键。"""
        if task_id not in self._store:
            return False
        self._store[task_id]["data"][key] = value
        return True

    def set_agent_context(self, task_id: str, agent_name: str, context: Dict[str, Any]) -> bool:
        """设置 Agent 的上下文。"""
        if task_id not in self._store:
            return False
        self._store[task_id]["agent_contexts"][agent_name] = context
        return True

    def get_agent_context(self, task_id: str, agent_name: str) -> Optional[Dict[str, Any]]:
        """获取 Agent 的上下文。"""
        mem = self._store.get(task_id)
        if not mem:
            return None
        return mem["agent_contexts"].get(agent_name)

    def clear(self, task_id: str) -> bool:
        """清除任务的短期记忆。"""
        if task_id in self._store:
            del self._store[task_id]
            return True
        return False
