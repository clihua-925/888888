# -*- coding: utf-8 -*-
"""Long-term Memory — 长期记忆

保存：
- 历史任务经验
- 行业知识
- 市场知识
- 产品知识
- 企业知识

支持向量检索（未来扩展）。
"""
import sqlite3
import json
import time
import uuid
from typing import Dict, List, Any, Optional

from shared.config.settings import settings
from contracts.memory_contract import MemoryEntry, MemoryType, MemoryCategory


class LongTermMemory:
    """长期记忆管理器。"""

    def __init__(self, db_path: str = None):
        self.db_path = db_path or settings.DATABASE_PATH
        self._init_table()

    def _conn(self):
        return sqlite3.connect(self.db_path, timeout=10, check_same_thread=False)

    def _init_table(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS memory_store (
                    memory_id TEXT PRIMARY KEY,
                    memory_type TEXT,
                    category TEXT,
                    key TEXT,
                    value TEXT,
                    embedding TEXT,
                    hits INTEGER DEFAULT 0,
                    created_at REAL,
                    updated_at REAL
                );
                CREATE INDEX IF NOT EXISTS idx_memory_type ON memory_store(memory_type);
                CREATE INDEX IF NOT EXISTS idx_memory_category ON memory_store(category);
                CREATE INDEX IF NOT EXISTS idx_memory_key ON memory_store(key);
            """)

    def store(self, entry: MemoryEntry) -> bool:
        """存储记忆条目。"""
        entry.memory_id = entry.memory_id or str(uuid.uuid4())
        entry.updated_at = time.time()
        try:
            with self._conn() as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO memory_store
                    (memory_id, memory_type, category, key, value, embedding, hits, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entry.memory_id,
                    entry.memory_type.value,
                    entry.category.value,
                    entry.key,
                    json.dumps(entry.value, ensure_ascii=False),
                    json.dumps(entry.embedding) if entry.embedding else None,
                    entry.hits,
                    entry.created_at,
                    entry.updated_at,
                ))
            return True
        except Exception as e:
            print(f"[LongTermMemory] store error: {e}")
            return False

    def retrieve(self, category: MemoryCategory, key: str = None, limit: int = 10) -> List[MemoryEntry]:
        """检索记忆。"""
        sql = "SELECT * FROM memory_store WHERE memory_type = ? AND category = ?"
        params = [MemoryType.LONG_TERM.value, category.value]
        if key:
            sql += " AND key = ?"
            params.append(key)
        sql += " ORDER BY hits DESC, updated_at DESC LIMIT ?"
        params.append(limit)

        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql, params).fetchall()
            return [self._row_to_entry(r) for r in rows]

    def increment_hits(self, memory_id: str) -> bool:
        """增加记忆命中次数。"""
        try:
            with self._conn() as conn:
                conn.execute("UPDATE memory_store SET hits = hits + 1, updated_at = ? WHERE memory_id = ?",
                             (time.time(), memory_id))
            return True
        except Exception:
            return False

    def _row_to_entry(self, row) -> MemoryEntry:
        return MemoryEntry(
            memory_id=row["memory_id"],
            memory_type=MemoryType(row["memory_type"]),
            category=MemoryCategory(row["category"]),
            key=row["key"],
            value=json.loads(row["value"]) if row["value"] else {},
            embedding=json.loads(row["embedding"]) if row["embedding"] else None,
            hits=row["hits"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )
