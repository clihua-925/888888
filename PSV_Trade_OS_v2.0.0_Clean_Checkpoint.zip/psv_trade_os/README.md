# PSV Trade Intelligence OS v2.0.0

## 系统定位
**PSV = 外贸智能业务系统**

**LangGraph 编排智能体 = 系统核心运行引擎**

## 架构
```
用户外贸目标
    ↓
Trade Intent 输入层
    ↓
LangGraph Orchestrator 编排智能体
    ↓
Agent 工作流系统
    ↓
外贸业务 Agent 集群
    ↓
数据采集、分析、评分、决策
    ↓
客户池 / 企业画像 / 商业机会
    ↓
数据库持久化
    ↓
审计追踪
```

## 目录结构
```
psv_trade_os/
├── app/                    # 应用入口（单一入口）
│   ├── main.py            # 系统启动入口
│   └── api.py             # REST API 层
├── business/              # 外贸业务层（第一优先级）
│   ├── collection/        # 外贸采集系统
│   ├── profiling/         # 企业画像系统
│   ├── customer_pool/     # 客户池系统
│   ├── trade_graph/       # 商业关系图谱
│   └── intelligence/      # 外贸智能分析
├── orchestrator/          # LangGraph 编排智能体（系统核心）
│   ├── state.py           # 统一状态定义
│   ├── graph.py           # 主编排图
│   ├── planner.py         # Trade Planner Agent
│   ├── supervisor.py      # Supervisor Agent
│   ├── router.py          # 路由逻辑
│   ├── executor.py        # Agent 执行器
│   ├── checkpoint.py      # 检查点持久化
│   └── recovery.py        # 恢复机制
├── agents/                # Agent 工作流系统
│   ├── market_research/   # 市场研究 Agent
│   ├── company_discovery/ # 企业发现 Agent
│   ├── company_enrichment/# 企业补全 Agent
│   ├── contact_discovery/ # 联系人发现 Agent
│   ├── lead_scoring/      # 线索评分 Agent
│   ├── sales_strategy/    # 销售策略 Agent
│   └── report/            # 报告生成 Agent
├── contracts/             # 契约层
│   ├── task_contract.py
│   ├── agent_contract.py
│   ├── tool_contract.py
│   ├── data_contract.py
│   ├── event_contract.py
│   └── memory_contract.py
├── shared/                # 共享层
│   ├── memory/            # 记忆管理
│   ├── state/             # 状态管理
│   ├── knowledge/         # 知识库
│   ├── config/            # 配置
│   ├── cache/             # 缓存
│   └── llm/               # LLM 客户端
├── platform/              # 基础设施
│   ├── audit/             # 审计层
│   ├── database/          # 数据库
│   └── recovery/          # 恢复支持
└── webui/                 # 外贸业务界面
```

## 8 大 Agent 体系

| Agent | 职责 | 输入 | 输出 |
|-------|------|------|------|
| Trade Planner | 理解目标，生成计划 | Trade Intent | Execution Plan |
| Market Research | 市场分析 | Product, Market | Market Analysis |
| Company Discovery | 企业发现 | Product, Market, Type | Company Pool |
| Company Enrichment | 信息补全 | Company Pool | Company Profiles |
| Contact Discovery | 联系人发现 | Company Profiles | Contacts |
| Lead Scoring | 客户评分 | Profiles, Contacts | Customer Pool |
| Sales Strategy | 策略生成 | Customer Pool | Opportunities |
| Report | 报告生成 | All Results | Final Report |

## 核心流程

```
用户输入: "开发美国生日蜡烛进口商"
    ↓
Trade Planner: 生成 7 步执行计划
    ↓
Supervisor: 按顺序调度 Agent
    ↓
Market Research → Company Discovery → Company Enrichment
→ Contact Discovery → Lead Scoring → Sales Strategy → Report
    ↓
每步自动 checkpoint + 数据库持久化 + 审计日志
    ↓
输出: 完整外贸开发报告 + 客户池 + 商业机会
```

## 快速开始

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env 填入 API Keys

# 3. 运行任务
python -m app.main

# 4. 启动 API 服务
python -m app.api
```

## API 接口

| 接口 | 方法 | 说明 |
|------|------|------|
| /health | GET | 健康检查 |
| /task | POST | 提交外贸任务 |
| /task/{id}/recover | POST | 恢复中断任务 |
| /tasks/interrupted | GET | 列出中断任务 |
| /task/{id}/report | GET | 获取任务报告 |
| /customers | GET | 查询客户池 |
| /companies | GET | 查询企业 |

## Phase 完成状态

- [x] Phase 1: 架构整理、目录重构、LangGraph 核心
- [x] Phase 2: Agent 体系、外贸业务流程
- [x] Phase 3: Contract 层、Shared 层、Memory 层、Audit 层
- [x] Phase 4: Recovery、数据库、WebUI 框架

## 验收标准

1. ✅ 用户输入外贸目标 → 系统自动执行完整流程
2. ✅ 全过程 LangGraph 驱动
3. ✅ 所有 Agent: 有输入、有输出、有状态、有日志
4. ✅ 任务失败: 可从 checkpoint 恢复
5. ✅ 所有数据: 进入数据库
6. ✅ 所有行为: 可审计
