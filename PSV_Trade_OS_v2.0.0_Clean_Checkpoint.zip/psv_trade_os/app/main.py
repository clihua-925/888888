# -*- coding: utf-8 -*-
"""PSV Trade Intelligence OS — 系统主入口

单一入口原则：
- 所有任务通过此入口进入
- 禁止绕过 Orchestrator 直接调用业务模块
"""
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))

from orchestrator.graph import run_trade_task
from orchestrator.recovery import RecoveryManager
from contracts.task_contract import TaskContract
from shared.config.settings import settings
from platform.database.models import PSVDatabase


class PSVTradeOS:
    """PSV Trade Intelligence OS 主控类。"""

    def __init__(self):
        self.recovery = RecoveryManager()
        self.db = PSVDatabase()
        print(f"[PSV] {settings.SYSTEM_NAME} v{settings.SYSTEM_VERSION} 启动")
        print(f"[PSV] 核心引擎: LangGraph Orchestrator")
        print(f"[PSV] 系统代号: {settings.SYSTEM_CODENAME}")
        print(f"[PSV] 数据库: {settings.DATABASE_PATH}")

    def execute(self, objective: str, product: str, market: str,
                target_customer: str = "importer", **kwargs) -> dict:
        """执行外贸任务。这是系统的唯一业务入口。"""
        task = TaskContract(
            objective=objective,
            product=product,
            market=market,
            target_customer=target_customer,
            constraints=kwargs.get("constraints", {}),
            priority=kwargs.get("priority", "normal"),
        )

        valid, errors = task.validate()
        if not valid:
            return {
                "success": False,
                "error": "任务校验失败",
                "details": errors,
            }

        print(f"[PSV] 任务提交: {task.task_id}")
        print(f"[PSV] 目标: {objective}")
        print(f"[PSV] 产品: {product} | 市场: {market} | 客户类型: {target_customer}")

        final_state = run_trade_task(task.to_dict())

        # 提取关键结果
        final_report = final_state.get("final_report", {})
        stats = final_report.get("statistics", {})

        return {
            "success": final_state.get("status") == "completed",
            "task_id": task.task_id,
            "status": final_state.get("status"),
            "final_report": final_report,
            "routing_path": final_state.get("routing_path"),
            "agent_history": final_state.get("agent_history"),
            "audit_trail": final_state.get("audit_trail"),
            "summary": {
                "companies_discovered": stats.get("total_companies_discovered", 0),
                "customers_scored": stats.get("total_customers_scored", 0),
                "opportunities": stats.get("total_opportunities", 0),
                "estimated_value": stats.get("estimated_total_value", 0),
                "tier_s": stats.get("tier_s", 0),
                "tier_a": stats.get("tier_a", 0),
            }
        }

    def recover(self, task_id: str) -> dict:
        """恢复中断的任务。"""
        info = self.recovery.get_recovery_point(task_id)
        if not info.get("recoverable"):
            return {
                "success": False,
                "error": "任务不可恢复",
                "reason": info.get("reason"),
            }

        state = self.recovery.recover_state(task_id)
        if not state:
            return {
                "success": False,
                "error": "恢复状态失败",
            }

        print(f"[PSV] 恢复任务: {task_id}")
        print(f"[PSV] 恢复点: {info['checkpoint_id']}")
        print(f"[PSV] 当前 Agent: {info['current_agent']}")

        return {
            "success": True,
            "task_id": task_id,
            "recovered_state": state,
            "message": "状态已恢复，等待继续执行",
        }

    def list_interrupted(self) -> list:
        """列出所有可恢复的中断任务。"""
        return self.recovery.scan_interrupted_tasks()

    def get_task_report(self, task_id: str) -> dict:
        """获取任务报告。"""
        # 从数据库查询
        import sqlite3
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                conn.row_factory = sqlite3.Row
                row = conn.execute(
                    "SELECT * FROM trade_task WHERE task_id = ?", (task_id,)
                ).fetchone()
                if row:
                    return dict(row)
        except Exception:
            pass
        return {"error": "Task not found"}

    def query_customer_pool(self, tier: str = None, limit: int = 100) -> list:
        """查询客户池。"""
        return self.db.query_customer_pool(tier=tier, limit=limit)

    def query_companies(self, **filters) -> list:
        """查询企业。"""
        return self.db.query_companies(filters=filters)


if __name__ == "__main__":
    psv = PSVTradeOS()

    result = psv.execute(
        objective="开发美国生日蜡烛进口商",
        product="birthday candles",
        market="USA",
        target_customer="importer",
    )

    print("\n" + "=" * 60)
    print("执行结果:")
    print(f"成功: {result['success']}")
    print(f"任务ID: {result['task_id']}")
    print(f"状态: {result['status']}")
    print(f"执行路径: {' -> '.join(result['routing_path'])}")
    print(f"Agent历史: {len(result['agent_history'])} 条记录")
    print(f"发现企业: {result['summary']['companies_discovered']}")
    print(f"评分客户: {result['summary']['customers_scored']}")
    print(f"商业机会: {result['summary']['opportunities']}")
    print(f"预估价值: ${result['summary']['estimated_value']:,.0f}")
    print("=" * 60)
