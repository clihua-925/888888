"""
PSV Trade Intelligence OS - 应用入口
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from orchestrator.graph import TradeOrchestrator
from shared.config.settings import get_config
from database.repository import TradeDataService


def run_cli():
    """命令行模式"""
    config = get_config()
    print("=" * 60)
    print(f"  {config.system_name} v{config.version}")
    print("  LangGraph 多智能体编排外贸智能操作系统")
    print("=" * 60)
    print()

    # 初始化数据库
    from database.models import init_db
    init_db(config.database_url)
    print("✅ 数据库初始化完成")

    # 初始化编排器
    orchestrator = TradeOrchestrator()
    print("✅ LangGraph 编排引擎就绪")
    print()

    # 示例任务
    print("🎯 执行任务: 开发美国生日蜡烛进口商")
    print("-" * 60)

    result = orchestrator.run(
        objective="开发美国生日蜡烛进口商",
        product="生日蜡烛",
        market="美国",
        target_customer="进口商",
    )

    print()
    print("=" * 60)
    print("📋 执行结果")
    print("=" * 60)
    print(f"任务ID: {result['task_id']}")
    print(f"工作流ID: {result['workflow_id']}")
    print(f"执行状态: {result['status']}")
    print(f"执行步数: {result['total_steps']}")
    print()

    # 显示仪表盘数据
    data_service = TradeDataService()
    dashboard = data_service.get_dashboard_data()
    print("📊 当前数据概况:")
    print(f"   企业总数: {dashboard['total_companies']}")
    print(f"   客户池: {dashboard['total_customers']}")
    print(f"   商业机会: {dashboard['total_opportunities']}")
    print(f"   历史任务: {dashboard['total_tasks']}")
    print()

    # 显示Trade Graph统计
    from business.services.trade_graph import get_trade_graph
    tg = get_trade_graph()
    stats = tg.get_stats()
    print("🔗 Trade Graph 商业关系图谱:")
    print(f"   节点数: {stats['total_nodes']}")
    print(f"   关系数: {stats['total_edges']}")
    print(f"   节点类型: {stats['node_types']}")
    print()

    print("✅ 任务执行完成，所有数据已持久化")
    print()
    print("🌐 启动Web UI: python webui/app.py")
    print("   访问: http://localhost:8000")

    return result


def run_webui():
    """Web UI模式"""
    from database.models import init_db
    from shared.config.settings import get_config
    config = get_config()
    init_db(config.database_url)

    import uvicorn
    from webui.app import app
    print(f"🌐 启动 PSV Trade Intelligence OS Web UI")
    print(f"   访问: http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    """主入口"""
    import argparse
    parser = argparse.ArgumentParser(description="PSV Trade Intelligence OS")
    parser.add_argument("--mode", choices=["cli", "web", "test"], default="cli", help="运行模式")
    args = parser.parse_args()

    if args.mode == "web":
        run_webui()
    elif args.mode == "test":
        run_tests()
    else:
        run_cli()


def run_tests():
    """运行测试套件"""
    print("🧪 运行测试套件...")
    import subprocess
    tests = [
        "tests/test_contracts.py",
        "tests/test_memory.py",
        "tests/test_audit.py",
        "tests/test_orchestrator.py",
    ]
    for test in tests:
        print(f"\n📋 {test}")
        try:
            subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), "..", test)], check=True)
        except subprocess.CalledProcessError as e:
            print(f"❌ {test} 失败: {e}")
    print("\n✅ 测试完成")


if __name__ == "__main__":
    main()
