"""
WebUI - FastAPI 外贸业务界面
展示：市场分析、客户池、企业画像、开发任务、商业机会、供应链关系、智能报告
"""
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import uvicorn
import json

from orchestrator.graph import TradeOrchestrator
from shared.config.settings import get_config
from audit.logger import get_audit_logger
from database.repository import TradeDataService
from business.services.trade_graph import get_trade_graph

app = FastAPI(title="PSV Trade Intelligence OS", version="3.0.0")

# 全局实例
orchestrator = TradeOrchestrator()
audit = get_audit_logger()
data_service = TradeDataService()
trade_graph = get_trade_graph()


class TradeRequest(BaseModel):
    objective: str
    product: str
    market: str
    target_customer: str = ""


# ============== HTML 页面 ==============

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    """主仪表盘"""
    return _dashboard_html()


@app.get("/market-analysis", response_class=HTMLResponse)
async def market_analysis_page():
    """市场分析页面"""
    return _market_analysis_html()


@app.get("/customer-pool", response_class=HTMLResponse)
async def customer_pool_page():
    """客户池页面"""
    return _customer_pool_html()


@app.get("/company-profile/{company_id}", response_class=HTMLResponse)
async def company_profile_page(company_id: str):
    """企业画像页面"""
    return _company_profile_html(company_id)


@app.get("/tasks", response_class=HTMLResponse)
async def tasks_page():
    """开发任务页面"""
    return _tasks_html()


@app.get("/opportunities", response_class=HTMLResponse)
async def opportunities_page():
    """商业机会页面"""
    return _opportunities_html()


@app.get("/supply-chain", response_class=HTMLResponse)
async def supply_chain_page():
    """供应链关系页面"""
    return _supply_chain_html()


@app.get("/reports", response_class=HTMLResponse)
async def reports_page():
    """智能报告页面"""
    return _reports_html()


# ============== API 接口 ==============

@app.post("/api/trade/run")
async def run_trade_task(request: TradeRequest):
    """执行外贸开发任务"""
    try:
        result = orchestrator.run(
            objective=request.objective,
            product=request.product,
            market=request.market,
            target_customer=request.target_customer,
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/dashboard/stats")
async def get_dashboard_stats():
    """获取仪表盘统计数据"""
    return {"success": True, "data": data_service.get_dashboard_data()}


@app.get("/api/companies")
async def get_companies(limit: int = 100, country: str = None, min_score: float = 0):
    """获取企业列表"""
    if country:
        companies = data_service.company_repo.get_by_country(country, limit)
    elif min_score > 0:
        companies = data_service.company_repo.get_high_score(min_score, limit)
    else:
        companies = data_service.company_repo.list_all(limit)

    return {"success": True, "data": [{
        "company_id": c.company_id,
        "name": c.name,
        "country": c.country,
        "website": c.website,
        "industry": c.industry,
        "match_score": c.match_score,
        "credibility_score": c.credibility_score,
    } for c in companies]}


@app.get("/api/companies/{company_id}")
async def get_company_detail(company_id: str):
    """获取企业详情"""
    company = data_service.company_repo.get_by_id(company_id)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    return {"success": True, "data": {
        "company_id": company.company_id,
        "name": company.name,
        "country": company.country,
        "website": company.website,
        "industry": company.industry,
        "main_products": company.main_products,
        "procurement_direction": company.procurement_direction,
        "company_size": company.company_size,
        "contacts": company.contacts,
        "contact_info": company.contact_info,
        "credibility_score": company.credibility_score,
        "procurement_probability": company.procurement_probability,
        "match_score": company.match_score,
    }}


@app.get("/api/customers")
async def get_customers(grade: str = None, limit: int = 100):
    """获取客户池"""
    if grade:
        customers = data_service.customer_repo.get_by_grade(grade, limit)
    else:
        customers = data_service.customer_repo.list_all(limit)

    return {"success": True, "data": [{
        "customer_id": c.customer_id,
        "company_name": c.company_name,
        "customer_level": c.customer_level,
        "customer_value": c.customer_value,
        "match_degree": c.match_degree,
        "deal_probability": c.deal_probability,
        "development_priority": c.development_priority,
        "follow_up_status": c.follow_up_status,
        "last_contact": c.last_contact.isoformat() if c.last_contact else None,
        "tags": c.tags,
    } for c in customers]}


@app.get("/api/opportunities")
async def get_opportunities(stage: str = None, limit: int = 100):
    """获取商业机会"""
    if stage:
        opps = data_service.opportunity_repo.list_all(limit)
        opps = [o for o in opps if o.stage == stage]
    else:
        opps = data_service.opportunity_repo.list_all(limit)

    return {"success": True, "data": [{
        "opportunity_id": o.opportunity_id,
        "title": o.title,
        "description": o.description,
        "estimated_value": o.estimated_value,
        "probability": o.probability,
        "stage": o.stage,
        "expected_close_date": o.expected_close_date.isoformat() if o.expected_close_date else None,
    } for o in opps]}


@app.get("/api/tasks")
async def get_tasks(status: str = None, limit: int = 100):
    """获取任务列表"""
    if status:
        tasks = data_service.task_repo.get_by_status(status, limit)
    else:
        tasks = data_service.task_repo.list_all(limit)

    return {"success": True, "data": [{
        "task_id": t.task_id,
        "objective": t.objective,
        "product": t.product,
        "market": t.market,
        "status": t.status,
        "priority": t.priority,
        "created_at": t.created_at.isoformat() if t.created_at else "",
    } for t in tasks]}


@app.get("/api/audit/logs")
async def get_audit_logs(task_id: str = None, limit: int = 100):
    """查询审计日志"""
    logs = audit.query(task_id=task_id, limit=limit)
    return {"success": True, "data": logs}


@app.get("/api/audit/chain/{task_id}")
async def get_execution_chain(task_id: str):
    """获取任务执行链"""
    chain = audit.get_agent_execution_chain(task_id)
    return {"success": True, "data": chain}


@app.get("/api/trade-graph/stats")
async def get_trade_graph_stats():
    """获取贸易图谱统计"""
    return {"success": True, "data": trade_graph.get_stats()}


@app.get("/api/trade-graph/visualization")
async def get_trade_graph_viz():
    """获取贸易图谱可视化数据"""
    return {"success": True, "data": trade_graph.export_for_visualization()}


@app.get("/api/recovery/checkpoints")
async def list_checkpoints():
    """列出可恢复的检查点"""
    from shared.state.manager import get_state_manager
    sm = get_state_manager()
    checkpoints = sm.list_checkpoints()
    return {"success": True, "data": checkpoints}


# ============== HTML 模板 ==============

def _base_html(title: str, content: str) -> str:
    return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{title} - PSV Trade OS</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f0f2f5; color: #333; }}
        .header {{ background: linear-gradient(135deg, #1a237e 0%, #283593 100%); color: white; padding: 20px 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); }}
        .header h1 {{ font-size: 24px; font-weight: 600; }}
        .header p {{ opacity: 0.9; margin-top: 5px; font-size: 14px; }}
        .nav {{ background: white; padding: 0 30px; border-bottom: 1px solid #e0e0e0; display: flex; gap: 0; }}
        .nav a {{ color: #555; text-decoration: none; padding: 15px 20px; font-size: 14px; border-bottom: 3px solid transparent; transition: all 0.3s; }}
        .nav a:hover, .nav a.active {{ color: #1a237e; border-bottom-color: #1a237e; background: #f5f5f5; }}
        .container {{ padding: 30px; max-width: 1400px; margin: 0 auto; }}
        .card {{ background: white; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }}
        .card h2 {{ font-size: 18px; margin-bottom: 16px; color: #1a237e; }}
        .card h3 {{ font-size: 16px; margin-bottom: 12px; color: #333; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; }}
        .stat-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 24px; border-radius: 12px; text-align: center; }}
        .stat-card h3 {{ font-size: 32px; margin-bottom: 8px; }}
        .stat-card p {{ opacity: 0.9; font-size: 14px; }}
        .btn {{ background: #1a237e; color: white; padding: 12px 24px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; transition: background 0.3s; }}
        .btn:hover {{ background: #283593; }}
        .btn-success {{ background: #2e7d32; }}
        .btn-success:hover {{ background: #388e3c; }}
        input, select, textarea {{ padding: 10px 14px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; width: 100%; margin-bottom: 12px; }}
        input:focus, select:focus, textarea:focus {{ outline: none; border-color: #1a237e; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #f5f5f5; font-weight: 600; color: #555; font-size: 13px; text-transform: uppercase; }}
        tr:hover {{ background: #fafafa; }}
        .badge {{ padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; }}
        .badge-A {{ background: #e8f5e9; color: #2e7d32; }}
        .badge-B {{ background: #e3f2fd; color: #1565c0; }}
        .badge-C {{ background: #fff3e0; color: #e65100; }}
        .badge-D {{ background: #ffebee; color: #c62828; }}
        .badge-new {{ background: #e8f5e9; color: #2e7d32; }}
        .badge-contacted {{ background: #e3f2fd; color: #1565c0; }}
        .badge-quoted {{ background: #fff3e0; color: #e65100; }}
        .badge-negotiating {{ background: #f3e5f5; color: #6a1b9a; }}
        .badge-closed {{ background: #e0e0e0; color: #424242; }}
        .progress-bar {{ background: #e0e0e0; border-radius: 10px; height: 8px; overflow: hidden; }}
        .progress-fill {{ background: linear-gradient(90deg, #667eea, #764ba2); height: 100%; border-radius: 10px; transition: width 0.5s; }}
        .timeline {{ position: relative; padding-left: 30px; }}
        .timeline::before {{ content: ''; position: absolute; left: 8px; top: 0; bottom: 0; width: 2px; background: #e0e0e0; }}
        .timeline-item {{ position: relative; margin-bottom: 20px; padding: 16px; background: white; border-radius: 8px; border-left: 3px solid #1a237e; }}
        .timeline-item::before {{ content: ''; position: absolute; left: -26px; top: 20px; width: 12px; height: 12px; background: #1a237e; border-radius: 50%; }}
        .loading {{ display: none; text-align: center; padding: 40px; }}
        .loading.active {{ display: block; }}
        .result-box {{ background: #f5f5f5; padding: 20px; border-radius: 8px; margin-top: 20px; display: none; }}
        .result-box.active {{ display: block; }}
        pre {{ background: #263238; color: #aed581; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 13px; line-height: 1.5; }}
        .form-row {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>PSV Trade Intelligence OS</h1>
        <p>LangGraph 多智能体编排外贸智能操作系统 v3.0</p>
    </div>
    <div class="nav">
        <a href="/" class="{'active' if '仪表盘' in title else ''}">仪表盘</a>
        <a href="/market-analysis" class="{'active' if '市场分析' in title else ''}">市场分析</a>
        <a href="/customer-pool" class="{'active' if '客户池' in title else ''}">客户池</a>
        <a href="/tasks" class="{'active' if '开发任务' in title else ''}">开发任务</a>
        <a href="/opportunities" class="{'active' if '商业机会' in title else ''}">商业机会</a>
        <a href="/supply-chain" class="{'active' if '供应链' in title else ''}">供应链关系</a>
        <a href="/reports" class="{'active' if '智能报告' in title else ''}">智能报告</a>
    </div>
    <div class="container">
        {content}
    </div>
    <script>
        async function apiGet(url) {{
            const res = await fetch(url);
            return await res.json();
        }}
        async function apiPost(url, data) {{
            const res = await fetch(url, {{
                method: 'POST',
                headers: {{'Content-Type': 'application/json'}},
                body: JSON.stringify(data)
            }});
            return await res.json();
        }}
    </script>
</body>
</html>"""


def _dashboard_html() -> str:
    content = """
    <div class="grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <h3 id="stat-companies">0</h3>
            <p>发现企业</p>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
            <h3 id="stat-customers">0</h3>
            <p>客户池</p>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
            <h3 id="stat-opportunities">0</h3>
            <p>商业机会</p>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
            <h3 id="stat-tasks">0</h3>
            <p>执行任务</p>
        </div>
    </div>

    <div class="card">
        <h2>🎯 新建外贸开发任务</h2>
        <form id="taskForm" onsubmit="runTask(event)">
            <div class="form-row">
                <input type="text" id="objective" placeholder="任务目标，如：开发美国生日蜡烛进口商" required>
                <input type="text" id="product" placeholder="产品，如：生日蜡烛" required>
                <input type="text" id="market" placeholder="目标市场，如：美国" required>
                <input type="text" id="target_customer" placeholder="客户类型，如：进口商">
            </div>
            <button type="submit" class="btn btn-success">🚀 启动智能开发流程</button>
        </form>
        <div class="loading" id="loading">
            <p>⏳ LangGraph 编排引擎正在执行...</p>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">市场分析 → 企业发现 → 信息补全 → 联系人挖掘 → 智能评分 → 策略生成 → 报告输出</p>
        </div>
        <div class="result-box" id="resultBox">
            <h3>✅ 任务执行完成</h3>
            <pre id="resultContent"></pre>
        </div>
    </div>

    <div class="grid">
        <div class="card">
            <h2>📋 最近任务</h2>
            <div id="recentTasks"><p style="color: #999;">加载中...</p></div>
        </div>
        <div class="card">
            <h2>💎 高价值机会</h2>
            <div id="highValueOpps"><p style="color: #999;">加载中...</p></div>
        </div>
    </div>

    <script>
        async function loadDashboard() {
            const res = await apiGet('/api/dashboard/stats');
            if (res.success) {
                const d = res.data;
                document.getElementById('stat-companies').textContent = d.total_companies;
                document.getElementById('stat-customers').textContent = d.total_customers;
                document.getElementById('stat-opportunities').textContent = d.total_opportunities;
                document.getElementById('stat-tasks').textContent = d.total_tasks;

                // 最近任务
                const tasksHtml = d.recent_tasks.map(t => `
                    <div style="padding: 10px 0; border-bottom: 1px solid #eee;">
                        <strong>${t.objective}</strong>
                        <span class="badge badge-${t.status}" style="margin-left: 10px;">${t.status}</span>
                        <div style="font-size: 12px; color: #999; margin-top: 4px;">${t.created_at}</div>
                    </div>
                `).join('') || '<p style="color: #999;">暂无任务</p>';
                document.getElementById('recentTasks').innerHTML = tasksHtml;

                // 高价值机会
                const oppsHtml = d.high_value_opportunities.map(o => `
                    <div style="padding: 10px 0; border-bottom: 1px solid #eee;">
                        <strong>${o.title}</strong>
                        <div style="font-size: 12px; color: #666; margin-top: 4px;">
                            预估价值: $${o.estimated_value.toLocaleString()} | 概率: ${(o.probability * 100).toFixed(0)}% | 阶段: ${o.stage}
                        </div>
                    </div>
                `).join('') || '<p style="color: #999;">暂无机会</p>';
                document.getElementById('highValueOpps').innerHTML = oppsHtml;
            }
        }

        async function runTask(e) {
            e.preventDefault();
            document.getElementById('loading').classList.add('active');
            document.getElementById('resultBox').classList.remove('active');

            const data = {
                objective: document.getElementById('objective').value,
                product: document.getElementById('product').value,
                market: document.getElementById('market').value,
                target_customer: document.getElementById('target_customer').value,
            };

            const res = await apiPost('/api/trade/run', data);
            document.getElementById('loading').classList.remove('active');
            document.getElementById('resultBox').classList.add('active');
            document.getElementById('resultContent').textContent = JSON.stringify(res, null, 2);

            // 刷新仪表盘
            setTimeout(loadDashboard, 1000);
        }

        loadDashboard();
    </script>
    """
    return _base_html("仪表盘", content)


def _market_analysis_html() -> str:
    content = """
    <div class="card">
        <h2>📊 市场分析</h2>
        <p style="color: #666; margin-bottom: 20px;">基于AI智能分析的目标市场深度洞察</p>
        <div id="marketContent">
            <p style="color: #999;">请先在仪表盘创建任务以生成市场分析数据</p>
        </div>
    </div>
    <script>
        // 这里可以加载具体的市场分析数据
    </script>
    """
    return _base_html("市场分析", content)


def _customer_pool_html() -> str:
    content = """
    <div class="card">
        <h2>🏢 客户智能池</h2>
        <div style="margin-bottom: 20px;">
            <button class="btn" onclick="filterGrade('A')">A级客户</button>
            <button class="btn" onclick="filterGrade('B')" style="margin-left: 10px;">B级客户</button>
            <button class="btn" onclick="filterGrade('C')" style="margin-left: 10px;">C级客户</button>
            <button class="btn" onclick="filterGrade('')" style="margin-left: 10px;">全部</button>
        </div>
        <div id="customerTable">
            <p style="color: #999;">加载中...</p>
        </div>
    </div>
    <script>
        async function loadCustomers(grade = '') {
            const url = grade ? `/api/customers?grade=${grade}` : '/api/customers';
            const res = await apiGet(url);
            if (res.success) {
                const html = `
                    <table>
                        <tr>
                            <th>企业名称</th>
                            <th>等级</th>
                            <th>匹配度</th>
                            <th>成交概率</th>
                            <th>优先级</th>
                            <th>跟进状态</th>
                            <th>标签</th>
                        </tr>
                        ${res.data.map(c => `
                            <tr>
                                <td><strong>${c.company_name}</strong></td>
                                <td><span class="badge badge-${c.customer_level}">${c.customer_level}</span></td>
                                <td>${(c.match_degree * 100).toFixed(0)}%</td>
                                <td>${(c.deal_probability * 100).toFixed(0)}%</td>
                                <td>${c.development_priority}/10</td>
                                <td><span class="badge badge-${c.follow_up_status}">${c.follow_up_status}</span></td>
                                <td>${(c.tags || []).join(', ')}</td>
                            </tr>
                        `).join('')}
                    </table>
                `;
                document.getElementById('customerTable').innerHTML = html;
            }
        }
        function filterGrade(grade) { loadCustomers(grade); }
        loadCustomers();
    </script>
    """
    return _base_html("客户池", content)


def _company_profile_html(company_id: str) -> str:
    content = f"""
    <div class="card">
        <h2>🏭 企业画像</h2>
        <div id="companyDetail">
            <p style="color: #999;">加载企业 ID: {company_id} ...</p>
        </div>
    </div>
    <script>
        async function loadCompany() {{
            const res = await apiGet('/api/companies/{company_id}');
            if (res.success) {{
                const c = res.data;
                document.getElementById('companyDetail').innerHTML = `
                    <div class="grid">
                        <div class="card">
                            <h3>基本信息</h3>
                            <p><strong>名称:</strong> ${{c.name}}</p>
                            <p><strong>国家:</strong> ${{c.country}}</p>
                            <p><strong>行业:</strong> ${{c.industry}}</p>
                            <p><strong>规模:</strong> ${{c.company_size}}</p>
                            <p><strong>官网:</strong> <a href="${{c.website}}" target="_blank">${{c.website}}</a></p>
                        </div>
                        <div class="card">
                            <h3>评分</h3>
                            <p>可信度: ${{c.credibility_score}}</p>
                            <p>采购概率: ${{c.procurement_probability}}</p>
                            <p>匹配度: ${{c.match_score}}</p>
                        </div>
                        <div class="card">
                            <h3>产品</h3>
                            <p>主营: ${{c.main_products ? c.main_products.join(', ') : 'N/A'}}</p>
                            <p>采购方向: ${{c.procurement_direction ? c.procurement_direction.join(', ') : 'N/A'}}</p>
                        </div>
                        <div class="card">
                            <h3>联系人</h3>
                            <pre>${{JSON.stringify(c.contacts, null, 2)}}</pre>
                        </div>
                    </div>
                `;
            }}
        }}
        loadCompany();
    </script>
    """
    return _base_html("企业画像", content)


def _tasks_html() -> str:
    content = """
    <div class="card">
        <h2>📋 开发任务</h2>
        <div id="taskTable"><p style="color: #999;">加载中...</p></div>
    </div>
    <script>
        async function loadTasks() {
            const res = await apiGet('/api/tasks');
            if (res.success) {
                const html = `
                    <table>
                        <tr>
                            <th>任务ID</th>
                            <th>目标</th>
                            <th>产品</th>
                            <th>市场</th>
                            <th>状态</th>
                            <th>优先级</th>
                            <th>创建时间</th>
                        </tr>
                        ${res.data.map(t => `
                            <tr>
                                <td>${t.task_id}</td>
                                <td><strong>${t.objective}</strong></td>
                                <td>${t.product}</td>
                                <td>${t.market}</td>
                                <td><span class="badge badge-${t.status}">${t.status}</span></td>
                                <td>${t.priority}</td>
                                <td>${t.created_at}</td>
                            </tr>
                        `).join('')}
                    </table>
                `;
                document.getElementById('taskTable').innerHTML = html;
            }
        }
        loadTasks();
    </script>
    """
    return _base_html("开发任务", content)


def _opportunities_html() -> str:
    content = """
    <div class="card">
        <h2>💎 商业机会</h2>
        <div id="oppTable"><p style="color: #999;">加载中...</p></div>
    </div>
    <script>
        async function loadOpportunities() {
            const res = await apiGet('/api/opportunities');
            if (res.success) {
                const html = `
                    <table>
                        <tr>
                            <th>机会标题</th>
                            <th>预估价值</th>
                            <th>成交概率</th>
                            <th>阶段</th>
                            <th>预计成交</th>
                        </tr>
                        ${res.data.map(o => `
                            <tr>
                                <td><strong>${o.title}</strong></td>
                                <td>$${o.estimated_value.toLocaleString()}</td>
                                <td>
                                    <div class="progress-bar" style="width: 100px; display: inline-block; vertical-align: middle; margin-right: 8px;">
                                        <div class="progress-fill" style="width: ${o.probability * 100}%"></div>
                                    </div>
                                    ${(o.probability * 100).toFixed(0)}%
                                </td>
                                <td><span class="badge badge-${o.stage}">${o.stage}</span></td>
                                <td>${o.expected_close_date || '待定'}</td>
                            </tr>
                        `).join('')}
                    </table>
                `;
                document.getElementById('oppTable').innerHTML = html;
            }
        }
        loadOpportunities();
    </script>
    """
    return _base_html("商业机会", content)


def _supply_chain_html() -> str:
    content = """
    <div class="card">
        <h2>🔗 供应链关系图谱</h2>
        <p style="color: #666; margin-bottom: 20px;">基于Trade Graph构建的商业关系网络</p>
        <div class="grid">
            <div class="stat-card" style="background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);">
                <h3 id="graph-nodes">0</h3>
                <p>节点数</p>
            </div>
            <div class="stat-card" style="background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);">
                <h3 id="graph-edges">0</h3>
                <p>关系数</p>
            </div>
        </div>
        <div id="graphViz" style="margin-top: 20px;">
            <p style="color: #999;">加载图谱数据中...</p>
        </div>
    </div>
    <script>
        async function loadGraph() {
            const statsRes = await apiGet('/api/trade-graph/stats');
            if (statsRes.success) {
                document.getElementById('graph-nodes').textContent = statsRes.data.total_nodes;
                document.getElementById('graph-edges').textContent = statsRes.data.total_edges;
            }

            const vizRes = await apiGet('/api/trade-graph/visualization');
            if (vizRes.success) {
                document.getElementById('graphViz').innerHTML = `
                    <pre>${JSON.stringify(vizRes.data, null, 2)}</pre>
                `;
            }
        }
        loadGraph();
    </script>
    """
    return _base_html("供应链关系", content)


def _reports_html() -> str:
    content = """
    <div class="card">
        <h2>📑 智能报告</h2>
        <p style="color: #666; margin-bottom: 20px;">由Report Agent生成的完整外贸开发报告</p>
        <div id="reportList">
            <p style="color: #999;">报告将在任务执行完成后自动生成</p>
        </div>
    </div>
    <script>
        // 可以加载历史报告列表
    </script>
    """
    return _base_html("智能报告", content)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
