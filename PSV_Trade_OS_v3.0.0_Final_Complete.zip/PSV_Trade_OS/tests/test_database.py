"""
Test Database - 数据库集成测试
验证所有数据库模型的CRUD操作
"""
from database.models import init_db, get_session
from database.repository import (
    CompanyRepository, CustomerPoolRepository, TaskRepository,
    OpportunityRepository, WorkflowRepository, AgentLogRepository
)


def test_company_repository():
    """测试企业Repository"""
    repo = CompanyRepository()

    # Create
    company_data = {
        "company_id": "COMP_TEST_001",
        "name": "Test Import Corp",
        "country": "美国",
        "website": "https://test-import.com",
        "industry": "Import/Export",
        "main_products": ["candles", "decorations"],
        "credibility_score": 0.85,
        "match_score": 0.78,
    }
    company = repo.create(company_data)
    assert company.company_id == "COMP_TEST_001"
    print("✅ Company create test passed")

    # Read
    found = repo.get_by_id("COMP_TEST_001")
    assert found is not None
    assert found.name == "Test Import Corp"
    print("✅ Company read test passed")

    # Update
    repo.update("COMP_TEST_001", {"credibility_score": 0.90})
    updated = repo.get_by_id("COMP_TEST_001")
    assert updated.credibility_score == 0.90
    print("✅ Company update test passed")

    # Query
    us_companies = repo.get_by_country("美国")
    assert len(us_companies) > 0
    print("✅ Company query test passed")

    # High score
    high_score = repo.get_high_score(0.8)
    assert len(high_score) > 0
    print("✅ Company high score test passed")

    print("\n🎉 Company repository tests passed!")


def test_customer_pool_repository():
    """测试客户池Repository"""
    repo = CustomerPoolRepository()

    customer_data = {
        "customer_id": "CUST_TEST_001",
        "company_id": "COMP_TEST_001",
        "company_name": "Test Import Corp",
        "customer_level": "A",
        "customer_value": 85.0,
        "match_degree": 0.78,
        "deal_probability": 0.65,
        "development_priority": 8,
        "follow_up_status": "new",
    }
    customer = repo.create(customer_data)
    assert customer.customer_level == "A"
    print("✅ Customer create test passed")

    # Update status
    repo.update_status("CUST_TEST_001", "contacted")
    updated = repo.get_by_id("CUST_TEST_001")
    assert updated.follow_up_status == "contacted"
    print("✅ Customer status update test passed")

    # Grade filter
    a_customers = repo.get_by_grade("A")
    assert len(a_customers) > 0
    print("✅ Customer grade filter test passed")

    print("\n🎉 Customer pool repository tests passed!")


def test_task_repository():
    """测试任务Repository"""
    repo = TaskRepository()

    task_data = {
        "task_id": "TASK_TEST_001",
        "objective": "开发美国生日蜡烛进口商",
        "product": "生日蜡烛",
        "market": "美国",
        "target_customer": "进口商",
        "status": "pending",
        "priority": 3,
    }
    task = repo.create(task_data)
    assert task.task_id == "TASK_TEST_001"
    print("✅ Task create test passed")

    # Update status
    repo.update_status("TASK_TEST_001", "completed", "Test completed successfully")
    updated = repo.get_by_id("TASK_TEST_001")
    assert updated.status == "completed"
    print("✅ Task status update test passed")

    # Status filter
    completed_tasks = repo.get_by_status("completed")
    assert len(completed_tasks) > 0
    print("✅ Task status filter test passed")

    print("\n🎉 Task repository tests passed!")


def test_workflow_repository():
    """测试工作流Repository"""
    repo = WorkflowRepository()

    wf_data = {
        "workflow_id": "WF_TEST_001",
        "task_id": "TASK_TEST_001",
        "current_node": "start",
        "node_history": ["start"],
        "status": "running",
        "data": {"step": 0},
    }
    wf = repo.create(wf_data)
    assert wf.workflow_id == "WF_TEST_001"
    print("✅ Workflow create test passed")

    # Update
    repo.update_status("WF_TEST_001", "completed", "ReportAgent")
    updated = repo.get_by_id("WF_TEST_001")
    assert updated.status == "completed"
    assert updated.current_node == "ReportAgent"
    print("✅ Workflow update test passed")

    print("\n🎉 Workflow repository tests passed!")


def test_data_service():
    """测试统一数据服务"""
    from database.repository import TradeDataService

    service = TradeDataService()

    # Dashboard data
    dashboard = service.get_dashboard_data()
    assert "total_companies" in dashboard
    assert "total_customers" in dashboard
    print("✅ Dashboard data test passed")

    print("\n🎉 Data service tests passed!")


if __name__ == "__main__":
    # 初始化内存数据库用于测试
    init_db("sqlite:///:memory:")

    test_company_repository()
    test_customer_pool_repository()
    test_task_repository()
    test_workflow_repository()
    test_data_service()

    print("\n" + "=" * 50)
    print("🎉 All database integration tests passed!")
    print("=" * 50)
