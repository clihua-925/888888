"""
Test Recovery - 恢复机制测试
验证任务中断后能否正确恢复
"""
import time
import os
from orchestrator.recovery import RecoveryManager
from shared.state.manager import get_state_manager, WorkflowState


def test_recovery_manager():
    """测试恢复管理器"""
    rm = RecoveryManager()
    sm = get_state_manager()

    # 创建测试工作流状态
    workflow_id = "TEST_RECOVERY_001"
    sm.create_state(workflow_id, "TASK_TEST_001", "CompanyEnrichmentAgent")
    state = sm.get_state(workflow_id)
    state.status = "failed"
    state.data["recovery_attempt"] = 0
    state.data["current_step"] = 3
    state.data["graph_state"] = {
        "task_id": "TASK_TEST_001",
        "workflow_id": workflow_id,
        "current_step": 3,
        "current_agent": "CompanyEnrichmentAgent",
        "status": "failed",
    }
    sm._save_checkpoint(state)

    # 测试 can_recover
    assert rm.can_recover(workflow_id), "Should be able to recover"
    print("✅ can_recover test passed")

    # 测试 recover
    recovered = rm.recover(workflow_id)
    assert recovered is not None, "Recovery should return state"
    assert recovered.get("status") == "recovering", "Status should be recovering"
    assert recovered.get("recovery_attempt") == 1, "Recovery attempt should be 1"
    print("✅ recover test passed")

    # 测试恢复点信息
    point = rm.get_recovery_point(workflow_id)
    assert point["workflow_id"] == workflow_id
    assert point["last_node"] == "CompanyEnrichmentAgent"
    assert point["last_step"] == 3
    print("✅ get_recovery_point test passed")

    # 测试超过最大恢复次数
    state2 = sm.get_state(workflow_id)
    state2.data["recovery_attempt"] = 3
    sm._save_checkpoint(state2)
    assert not rm.can_recover(workflow_id), "Should not recover after max attempts"
    print("✅ max recovery attempts test passed")

    # 清理
    checkpoint_file = os.path.join(sm.checkpoint_dir, f"{workflow_id}.json")
    if os.path.exists(checkpoint_file):
        os.remove(checkpoint_file)

    print("\n🎉 All recovery tests passed!")


if __name__ == "__main__":
    test_recovery_manager()
