"""
Test Contracts - 契约层测试
"""
from contracts.task_contract import TaskContract, TaskStatus, TaskPriority
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus


def test_task_contract():
    task = TaskContract(
        objective="开发美国生日蜡烛进口商",
        product="生日蜡烛",
        market="美国",
        target_customer="进口商",
    )
    assert task.objective == "开发美国生日蜡烛进口商"
    assert task.status == TaskStatus.PENDING
    assert task.priority == TaskPriority.MEDIUM

    data = task.to_dict()
    restored = TaskContract.from_dict(data)
    assert restored.objective == task.objective
    print("✅ TaskContract test passed")


def test_agent_contract():
    req = AgentRequest(
        task_id="TASK_001",
        agent_name="TestAgent",
        input_data={"key": "value"},
    )
    assert req.task_id == "TASK_001"

    resp = AgentResponse(
        request_id=req.request_id,
        task_id=req.task_id,
        agent_name="TestAgent",
        result={"status": "ok"},
        confidence=0.9,
        status=AgentStatus.SUCCESS,
    )
    assert resp.confidence == 0.9
    print("✅ AgentContract test passed")


if __name__ == "__main__":
    test_task_contract()
    test_agent_contract()
