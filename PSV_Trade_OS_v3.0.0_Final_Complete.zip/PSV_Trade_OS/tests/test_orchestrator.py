"""
Test Orchestrator - 编排层测试
"""
from orchestrator.graph import TradeOrchestrator
from orchestrator.planner import TradePlanner
from orchestrator.supervisor import SupervisorAgent
from contracts.task_contract import TaskContract


def test_planner():
    planner = TradePlanner()
    task = TaskContract(
        objective="开发美国生日蜡烛进口商",
        product="生日蜡烛",
        market="美国",
        target_customer="进口商",
    )
    response = planner.plan(task)
    assert response.status.value == "success"
    assert len(response.result["workflow"]) == 7
    print("✅ TradePlanner test passed")


def test_orchestrator_run():
    orch = TradeOrchestrator()
    result = orch.run(
        objective="开发美国生日蜡烛进口商",
        product="生日蜡烛",
        market="美国",
        target_customer="进口商",
    )
    assert "task_id" in result
    assert "status" in result
    print(f"✅ TradeOrchestrator test passed: {result['status']}")


if __name__ == "__main__":
    test_planner()
    test_orchestrator_run()
