"""
Test Memory - 记忆层测试
"""
from shared.memory.short_term import get_short_term_memory
from shared.memory.long_term import get_long_term_memory


def test_short_term_memory():
    stm = get_short_term_memory()
    stm.set("TASK_TEST", "key1", "value1")
    assert stm.get("TASK_TEST", "key1") == "value1"
    assert stm.exists("TASK_TEST", "key1")
    stm.clear("TASK_TEST")
    assert not stm.exists("TASK_TEST", "key1")
    print("✅ ShortTermMemory test passed")


def test_long_term_memory():
    ltm = get_long_term_memory()
    mid = ltm.store("industry_knowledge", {"product": "candles", "market": "US"})
    results = ltm.retrieve("industry_knowledge", {"product": "candles"})
    assert len(results) > 0
    print("✅ LongTermMemory test passed")


if __name__ == "__main__":
    test_short_term_memory()
    test_long_term_memory()
