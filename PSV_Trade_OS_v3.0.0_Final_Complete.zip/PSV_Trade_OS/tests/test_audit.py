"""
Test Audit - 审计层测试
"""
from audit.logger import get_audit_logger


def test_audit_logging():
    logger = get_audit_logger()
    logger.log(
        task_id="TASK_AUDIT_TEST",
        workflow_id="WF_TEST",
        agent_id="TestAgent",
        input_data={"test": "input"},
        output_data={"test": "output"},
        tool_call="test_tool",
        duration_ms=100,
        status="success",
    )

    logs = logger.query(task_id="TASK_AUDIT_TEST")
    assert len(logs) > 0

    chain = logger.get_agent_execution_chain("TASK_AUDIT_TEST")
    assert len(chain) > 0
    print("✅ AuditLogger test passed")


if __name__ == "__main__":
    test_audit_logging()
