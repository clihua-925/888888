"""
Test Trade Graph - 商业关系图谱测试
"""
from business.services.trade_graph import TradeGraph, get_trade_graph


def test_trade_graph_basic():
    """测试Trade Graph基本功能"""
    tg = TradeGraph(storage_path="./data/test_trade_graph.json")

    # 添加节点
    n1 = tg.add_node("product", "生日蜡烛", {"category": "home_decor"})
    n2 = tg.add_node("company", "American Import Corp", {"country": "美国"})
    n3 = tg.add_node("country", "美国", {"region": "North America"})

    assert n1 in tg._nodes
    assert n2 in tg._nodes
    print("✅ Node creation test passed")

    # 添加边
    e1 = tg.add_edge(n2, n1, "procures", {"volume": "high"})
    e2 = tg.add_edge(n2, n3, "located_in", {})

    assert e1 in tg._edges
    assert e2 in tg._edges
    print("✅ Edge creation test passed")

    # 获取邻居
    neighbors = tg.get_neighbors(n2)
    assert len(neighbors) == 2
    print("✅ Neighbor query test passed")

    # 按关系类型过滤
    procures = tg.get_neighbors(n2, "procures")
    assert len(procures) == 1
    print("✅ Relation filter test passed")

    # 获取统计
    stats = tg.get_stats()
    assert stats["total_nodes"] == 3
    assert stats["total_edges"] == 2
    print("✅ Stats test passed")

    # 导出可视化
    viz = tg.export_for_visualization()
    assert len(viz["nodes"]) == 3
    assert len(viz["edges"]) == 2
    print("✅ Visualization export test passed")

    # 清理
    import os
    if os.path.exists("./data/test_trade_graph.json"):
        os.remove("./data/test_trade_graph.json")

    print("\n🎉 All Trade Graph tests passed!")


def test_trade_graph_build_from_task():
    """测试从任务构建图谱"""
    tg = TradeGraph(storage_path="./data/test_trade_graph2.json")

    companies = [
        {
            "company_id": "COMP_001",
            "name": "Test Corp A",
            "country": "美国",
            "website": "https://test-a.com",
            "industry": "Import",
            "contacts": [{"name": "John", "title": "Manager"}],
            "scores": {"overall_score": 0.85},
            "lead_grade": "A",
            "supply_chain_relations": [{"type": "supplier", "region": "China"}],
        },
        {
            "company_id": "COMP_002",
            "name": "Test Corp B",
            "country": "美国",
            "website": "https://test-b.com",
            "industry": "Distribution",
            "contacts": [],
            "scores": {"overall_score": 0.72},
            "lead_grade": "B",
            "supply_chain_relations": [],
        },
    ]

    result = tg.build_from_task("TASK_TEST", companies, "生日蜡烛", "美国")
    assert result["total_nodes"] > 0
    assert result["total_edges"] > 0
    print("✅ Build from task test passed")

    # 供应链查询
    supply_chain = tg.get_supply_chain(result["company_nodes"][0])
    assert "suppliers" in supply_chain
    print("✅ Supply chain query test passed")

    # 清理
    import os
    if os.path.exists("./data/test_trade_graph2.json"):
        os.remove("./data/test_trade_graph2.json")

    print("\n🎉 Build from task tests passed!")


if __name__ == "__main__":
    test_trade_graph_basic()
    test_trade_graph_build_from_task()
