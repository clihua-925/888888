"""
Test Integration - 综合集成测试
验证端到端业务流程
"""
from contracts.task_contract import TaskContract, TaskStatus
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from orchestrator.planner import TradePlanner
from orchestrator.supervisor import SupervisorAgent
from shared.memory.short_term import get_short_term_memory
from shared.memory.long_term import get_long_term_memory
from shared.state.manager import get_state_manager
from audit.logger import get_audit_logger
from business.services.trade_graph import get_trade_graph


def test_end_to_end_contract_flow():
    """测试端到端契约流"""
    # 1. 创建任务
    task = TaskContract(
        objective="开发美国生日蜡烛进口商",
        product="生日蜡烛",
        market="美国",
        target_customer="进口商",
    )
    assert task.status == TaskStatus.PENDING
    print("✅ Task creation passed")

    # 2. 任务序列化
    task_dict = task.to_dict()
    restored = TaskContract.from_dict(task_dict)
    assert restored.objective == task.objective
    print("✅ Task serialization passed")

    # 3. Agent请求
    request = AgentRequest(
        task_id=task.task_id,
        agent_name="TestAgent",
        input_data={"product": "生日蜡烛", "market": "美国"},
    )
    assert request.task_id == task.task_id
    print("✅ Agent request creation passed")

    # 4. Agent响应
    response = AgentResponse(
        request_id=request.request_id,
        task_id=task.task_id,
        agent_name="TestAgent",
        result={"companies": ["Company A", "Company B"]},
        confidence=0.85,
        status=AgentStatus.SUCCESS,
    )
    assert response.confidence == 0.85
    assert response.status == AgentStatus.SUCCESS
    print("✅ Agent response creation passed")

    print("\n🎉 End-to-end contract flow test passed!")


def test_memory_integration():
    """测试记忆系统集成"""
    stm = get_short_term_memory()
    ltm = get_long_term_memory()

    # 短期记忆
    stm.set("TASK_INT_001", "step", 3)
    assert stm.get("TASK_INT_001", "step") == 3
    print("✅ Short-term memory integration passed")

    # 长期记忆
    mid = ltm.store("test_knowledge", {"key": "value", "task": "integration"})
    results = ltm.retrieve("test_knowledge")
    assert len(results) > 0
    print("✅ Long-term memory integration passed")

    print("\n🎉 Memory integration test passed!")


def test_state_manager_integration():
    """测试状态管理器集成"""
    sm = get_state_manager()

    # 创建状态
    state = sm.create_state("WF_INT_001", "TASK_INT_001", "start")
    assert state.workflow_id == "WF_INT_001"
    print("✅ State creation passed")

    # 更新状态
    sm.update_state("WF_INT_001", "MarketResearchAgent", {"step": 1})
    updated = sm.get_state("WF_INT_001")
    assert updated.current_node == "MarketResearchAgent"
    print("✅ State update passed")

    # 暂停和恢复
    sm.pause_state("WF_INT_001")
    paused = sm.get_state("WF_INT_001")
    assert paused.status == "paused"
    print("✅ State pause passed")

    sm.resume_state("WF_INT_001")
    resumed = sm.get_state("WF_INT_001")
    assert resumed.status == "running"
    print("✅ State resume passed")

    # 清理
    import os
    checkpoint_file = os.path.join(sm.checkpoint_dir, "WF_INT_001.json")
    if os.path.exists(checkpoint_file):
        os.remove(checkpoint_file)

    print("\n🎉 State manager integration test passed!")


def test_audit_integration():
    """测试审计系统集成"""
    audit = get_audit_logger()

    # 记录日志
    audit.log(
        task_id="TASK_INT_001",
        workflow_id="WF_INT_001",
        agent_id="IntegrationTestAgent",
        input_data={"test": "input"},
        output_data={"test": "output"},
        tool_call="test_tool",
        duration_ms=150,
        status="success",
    )

    # 查询
    logs = audit.query(task_id="TASK_INT_001")
    assert len(logs) > 0
    print("✅ Audit log query passed")

    # 执行链
    chain = audit.get_agent_execution_chain("TASK_INT_001")
    assert len(chain) > 0
    print("✅ Audit execution chain passed")

    # 刷新缓冲区
    audit.close()
    print("\n🎉 Audit integration test passed!")


def test_planner_and_supervisor_integration():
    """测试Planner和Supervisor集成"""
    planner = TradePlanner()

    task = TaskContract(
        objective="开发美国生日蜡烛进口商",
        product="生日蜡烛",
        market="美国",
        target_customer="进口商",
    )

    # 生成计划
    plan_response = planner.plan(task)
    assert plan_response.status == AgentStatus.SUCCESS
    assert len(plan_response.result["workflow"]) == 7
    print("✅ Planner integration passed")

    # 重新规划
    replan_response = planner.replan(task.task_id, "network_error", {"current_agent": "CompanyDiscoveryAgent"})
    assert replan_response.status == AgentStatus.SUCCESS
    print("✅ Replan integration passed")

    print("\n🎉 Planner-Supervisor integration test passed!")


def test_full_agent_chain():
    """测试完整Agent链执行"""
    from agents.market_research import MarketResearchAgent
    from agents.company_discovery import CompanyDiscoveryAgent
    from agents.lead_scoring import LeadScoringAgent

    task_id = "TASK_CHAIN_001"

    # 市场研究
    mr = MarketResearchAgent()
    mr_req = AgentRequest(task_id=task_id, agent_name="MarketResearchAgent", input_data={"product": "生日蜡烛", "market": "美国"})
    mr_resp = mr.execute(mr_req)
    assert mr_resp.status == AgentStatus.SUCCESS
    print("✅ MarketResearchAgent execution passed")

    # 企业发现
    cd = CompanyDiscoveryAgent()
    cd_req = AgentRequest(task_id=task_id, agent_name="CompanyDiscoveryAgent", input_data={"product": "生日蜡烛", "market": "美国", "customer_type": "进口商"})
    cd_resp = cd.execute(cd_req)
    assert cd_resp.status == AgentStatus.SUCCESS
    assert cd_resp.result["discovered_count"] > 0
    print("✅ CompanyDiscoveryAgent execution passed")

    # 客户评分
    ls = LeadScoringAgent()
    ls_req = AgentRequest(task_id=task_id, agent_name="LeadScoringAgent", input_data={"leads": cd_resp.result})
    ls_resp = ls.execute(ls_req)
    assert ls_resp.status == AgentStatus.SUCCESS
    assert "grade_distribution" in ls_resp.result
    print("✅ LeadScoringAgent execution passed")

    print("\n🎉 Full agent chain test passed!")


if __name__ == "__main__":
    print("=" * 60)
    print("🧪 运行综合集成测试")
    print("=" * 60)

    test_end_to_end_contract_flow()
    test_memory_integration()
    test_state_manager_integration()
    test_audit_integration()
    test_planner_and_supervisor_integration()
    test_full_agent_chain()

    print("\n" + "=" * 60)
    print("🎉 所有综合集成测试通过！")
    print("=" * 60)
