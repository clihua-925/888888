"""
Market Research Agent - 市场研究Agent
负责：国家市场分析、产品趋势、行业分析、市场机会
"""
from typing import Dict, Any, List
from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.memory.short_term import get_short_term_memory
from shared.knowledge.base import get_knowledge_base
from audit.logger import get_audit_logger
import time


class MarketResearchAgent(BaseAgent):
    """市场研究Agent - 深度分析目标市场"""

    def __init__(self):
        super().__init__("MarketResearchAgent")
        self.description = "负责国家市场分析、产品趋势、行业分析、市场机会"
        self.stm = get_short_term_memory()
        self.kb = get_knowledge_base()
        self.audit = get_audit_logger()

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()

        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")

        # 1. 从知识库获取已有市场知识
        existing_knowledge = self.kb.search("market", f"{market}_{product}")

        # 2. 执行市场分析（模拟真实分析逻辑）
        market_analysis = self._analyze_market(product, market)

        # 3. 保存到知识库
        self.kb.add("market", f"{market}_{product}", market_analysis)

        # 4. 保存到短期记忆供后续Agent使用
        self.stm.set(request.task_id, "market_analysis", market_analysis)

        duration = int((time.time() - start) * 1000)

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_name=self.name,
            result=market_analysis,
            confidence=0.88,
            evidence=[
                {"type": "market_analysis", "detail": f"Analyzed {market} market for {product}", "source": "knowledge_base" if existing_knowledge else "fresh_analysis"},
                {"type": "market_size", "value": market_analysis.get("market_size_usd", "N/A")},
                {"type": "growth_rate", "value": market_analysis.get("growth_rate", "N/A")},
            ],
            next_action="CompanyDiscoveryAgent",
            status=AgentStatus.SUCCESS,
            duration_ms=duration,
        )

    def _analyze_market(self, product: str, market: str) -> Dict[str, Any]:
        """执行深度市场分析"""

        # 市场特征数据库（模拟真实市场数据）
        market_profiles = {
            "美国": {
                "market_size_usd": "850亿",
                "growth_rate": "4.2%",
                "competition_level": "High",
                "entry_barrier": "High - FDA认证, 关税壁垒",
                "consumer_behavior": "品质导向, 品牌意识强",
                "seasonal_peaks": ["Q4(感恩节/圣诞)", "Q2(母亲节)"],
                "regulatory": "FDA, CPSIA, 加州65号提案",
                "payment_terms": "Net 30/60, L/C常见",
                "preferred_channels": ["Amazon", "Walmart", "独立站", "展会"],
            },
            "欧盟": {
                "market_size_usd": "620亿",
                "growth_rate": "3.1%",
                "competition_level": "Medium-High",
                "entry_barrier": "High - CE认证, REACH法规",
                "consumer_behavior": "环保意识, 可持续产品偏好",
                "seasonal_peaks": ["Q4(圣诞)", "Q1(情人节)"],
                "regulatory": "CE, REACH, GDPR",
                "payment_terms": "Net 60, OA常见",
                "preferred_channels": ["Amazon EU", "当地分销商", "展会"],
            },
            "日本": {
                "market_size_usd": "280亿",
                "growth_rate": "2.5%",
                "competition_level": "High",
                "entry_barrier": "Very High - 品质要求极高",
                "consumer_behavior": "极致品质, 包装精美, 细节控",
                "seasonal_peaks": ["Q1(新年)", "Q3(中元节)"],
                "regulatory": "JIS, 食品卫生法",
                "payment_terms": "Net 90, 关系导向",
                "preferred_channels": ["乐天", "雅虎", "当地代理"],
            },
        }

        profile = market_profiles.get(market, {
            "market_size_usd": "未知",
            "growth_rate": "未知",
            "competition_level": "Medium",
            "entry_barrier": "待调研",
            "consumer_behavior": "待调研",
            "seasonal_peaks": [],
            "regulatory": "待调研",
            "payment_terms": "待调研",
            "preferred_channels": [],
        })

        # 产品特定分析
        product_trends = self._analyze_product_trends(product, market)

        # 竞争分析
        competition = self._analyze_competition(product, market)

        # 机会识别
        opportunities = self._identify_opportunities(product, market, profile)

        return {
            "market": market,
            "product": product,
            "analysis_date": time.strftime("%Y-%m-%d %H:%M:%S"),
            "market_profile": profile,
            "product_trends": product_trends,
            "competition_analysis": competition,
            "opportunities": opportunities,
            "risks": profile.get("entry_barrier", "").split(", ") if isinstance(profile.get("entry_barrier"), str) else [],
            "recommendation": self._generate_recommendation(product, market, profile, opportunities),
        }

    def _analyze_product_trends(self, product: str, market: str) -> Dict[str, Any]:
        """分析产品趋势"""
        return {
            "trend_direction": "Rising" if "蜡烛" in product or "candle" in product.lower() else "Stable",
            "seasonal_factor": "High" if any(k in product for k in ["生日", "节日", "圣诞", "candle"]) else "Medium",
            "price_sensitivity": "Medium",
            "quality_expectation": "High",
            "packaging_importance": "High",
        }

    def _analyze_competition(self, product: str, market: str) -> Dict[str, Any]:
        """竞争分析"""
        return {
            "local_competitors": f"{market}本土品牌强势",
            "chinese_competitors": "中国供应商价格竞争激烈",
            "differentiation_opportunity": "品质+设计差异化",
            "price_range": {"low": "$0.5-2", "mid": "$2-5", "high": "$5+"},
        }

    def _identify_opportunities(self, product: str, market: str, profile: Dict) -> List[Dict[str, Any]]:
        """识别市场机会"""
        opportunities = []

        if profile.get("growth_rate", "").replace("%", "").replace(".", "").isdigit():
            growth = float(profile["growth_rate"].replace("%", ""))
            if growth > 3:
                opportunities.append({
                    "type": "growth_market",
                    "description": f"{market}市场增长率{profile['growth_rate']}，处于扩张期",
                    "priority": "High",
                })

        opportunities.extend([
            {"type": "seasonal_peak", "description": f"把握{', '.join(profile.get('seasonal_peaks', ['Q4']))}销售旺季", "priority": "High"},
            {"type": "differentiation", "description": "通过设计和品质差异化避开价格战", "priority": "Medium"},
            {"type": "channel", "description": f"重点布局{', '.join(profile.get('preferred_channels', ['展会']))}", "priority": "Medium"},
        ])

        return opportunities

    def _generate_recommendation(self, product: str, market: str, profile: Dict, opportunities: List) -> str:
        """生成市场进入建议"""
        top_op = opportunities[0] if opportunities else {}
        return f"建议以{profile.get('competition_level', 'Medium')}竞争策略进入{market}市场，重点把握{top_op.get('description', '季节性机会')}，通过品质差异化建立品牌认知。"
