"""
Base Agent - 所有业务Agent的基类
"""
from abc import ABC, abstractmethod
from typing import Dict, Any
from contracts.agent_contract import AgentRequest, AgentResponse


class BaseAgent(ABC):
    """Agent基类"""

    def __init__(self, name: str):
        self.name = name
        self.version = "1.0"
        self.description = ""

    @abstractmethod
    def execute(self, request: AgentRequest) -> AgentResponse:
        """执行Agent逻辑 - 子类必须实现"""
        pass

    def validate_input(self, request: AgentRequest) -> bool:
        """验证输入"""
        return bool(request.task_id and request.input_data)

    def format_error(self, error: str) -> AgentResponse:
        """格式化错误响应"""
        return AgentResponse(
            request_id="",
            task_id="",
            agent_name=self.name,
            result={},
            confidence=0.0,
            status="failed",
            error=error,
        )
