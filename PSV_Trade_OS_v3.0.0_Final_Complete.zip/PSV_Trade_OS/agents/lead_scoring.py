"""
Lead Scoring Agent - 客户评分Agent
负责：企业实力评分、采购可能评分、匹配程度评分、成交概率评分
"""
from typing import Dict, Any, List
from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.memory.short_term import get_short_term_memory
from audit.logger import get_audit_logger
import time


class LeadScoringAgent(BaseAgent):
    """客户评分Agent - 多维度智能评分"""

    def __init__(self):
        super().__init__("LeadScoringAgent")
        self.description = "负责客户评分：企业实力、采购可能、匹配程度、成交概率"
        self.stm = get_short_term_memory()
        self.audit = get_audit_logger()

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()

        leads = request.input_data.get("leads", {}).get("companies_with_contacts", [])

        scored_leads = []
        for lead in leads:
            scored = self._score_lead(lead)
            scored_leads.append(scored)

        # 按综合评分排序
        scored_leads.sort(key=lambda x: x.get("scores", {}).get("overall_score", 0), reverse=True)

        # 分级
        for lead in scored_leads:
            score = lead.get("scores", {}).get("overall_score", 0)
            if score >= 0.8:
                lead["lead_grade"] = "A"
            elif score >= 0.65:
                lead["lead_grade"] = "B"
            elif score >= 0.5:
                lead["lead_grade"] = "C"
            else:
                lead["lead_grade"] = "D"

        # 保存到短期记忆
        self.stm.set(request.task_id, "scored_leads", scored_leads)

        duration = int((time.time() - start) * 1000)

        result = {
            "scored_count": len(scored_leads),
            "scored_leads": scored_leads,
            "grade_distribution": {
                "A": len([l for l in scored_leads if l.get("lead_grade") == "A"]),
                "B": len([l for l in scored_leads if l.get("lead_grade") == "B"]),
                "C": len([l for l in scored_leads if l.get("lead_grade") == "C"]),
                "D": len([l for l in scored_leads if l.get("lead_grade") == "D"]),
            },
            "top_lead": scored_leads[0] if scored_leads else None,
            "priority_queue": [l.get("name", "") for l in scored_leads[:3]],
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_name=self.name,
            result=result,
            confidence=0.90,
            evidence=[
                {"type": "lead_scoring", "detail": f"Scored {len(scored_leads)} leads", "method": "multi_factor_model"},
                {"type": "grade_distribution", "data": result["grade_distribution"]},
            ],
            next_action="SalesStrategyAgent",
            status=AgentStatus.SUCCESS,
            duration_ms=duration,
        )

    def _score_lead(self, lead: Dict[str, Any]) -> Dict[str, Any]:
        """多维度评分模型"""
        scored = dict(lead)

        # 1. 企业实力评分 (0-1)
        credibility = lead.get("credibility_score", 0.5)
        website_quality = 0.8 if lead.get("website_analysis", {}).get("ecommerce_enabled") else 0.5
        years_in_business = 0.8 if "5+" in lead.get("credit_rating", {}).get("years_in_business", "") else 0.6
        company_strength = (credibility * 0.4 + website_quality * 0.3 + years_in_business * 0.3)

        # 2. 采购可能性评分 (0-1)
        procurement_prob = lead.get("procurement_probability", 0.5)
        has_procurement_history = 1.0 if lead.get("procurement_history") else 0.5
        procurement_direction_match = 1.0 if any(lead.get("procurement_direction", [])) else 0.5
        procurement_likelihood = (procurement_prob * 0.5 + has_procurement_history * 0.3 + procurement_direction_match * 0.2)

        # 3. 匹配程度评分 (0-1)
        match_score = lead.get("match_score", 0.5)
        product_overlap = len(set(lead.get("main_products", [])) & set(lead.get("procurement_direction", [])))
        match_degree = (match_score * 0.6 + min(product_overlap * 0.2, 0.4))

        # 4. 成交概率 (综合)
        deal_probability = (company_strength * 0.35 + procurement_likelihood * 0.35 + match_degree * 0.30)

        # 5. 综合评分
        overall_score = deal_probability

        scored["scores"] = {
            "company_strength": round(company_strength, 2),
            "procurement_likelihood": round(procurement_likelihood, 2),
            "match_degree": round(match_degree, 2),
            "deal_probability": round(deal_probability, 2),
            "overall_score": round(overall_score, 2),
        }

        scored["scored_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        scored["scoring_version"] = "2.0"

        return scored
