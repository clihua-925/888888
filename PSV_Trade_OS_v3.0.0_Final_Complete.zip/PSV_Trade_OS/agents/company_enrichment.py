"""
Company Enrichment Agent - 企业信息补全Agent
负责：企业信息补全、官网分析、背景调查、供应链关系
"""
from typing import Dict, Any, List
from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.memory.short_term import get_short_term_memory
from shared.knowledge.base import get_knowledge_base
from audit.logger import get_audit_logger
import time


class CompanyEnrichmentAgent(BaseAgent):
    """企业信息补全Agent - 深度企业画像构建"""

    def __init__(self):
        super().__init__("CompanyEnrichmentAgent")
        self.description = "负责企业信息补全、官网分析、背景调查、供应链关系"
        self.stm = get_short_term_memory()
        self.kb = get_knowledge_base()
        self.audit = get_audit_logger()

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()

        companies_data = request.input_data.get("companies", {}).get("companies", [])

        enriched_companies = []
        for company_data in companies_data:
            enriched = self._enrich_company(company_data)
            enriched_companies.append(enriched)

        # 保存到短期记忆
        self.stm.set(request.task_id, "enriched_companies", enriched_companies)

        # 更新知识库
        for company in enriched_companies:
            self.kb.add("enriched_companies", company.get("company_id", ""), company)

        duration = int((time.time() - start) * 1000)

        result = {
            "enriched_count": len(enriched_companies),
            "companies": enriched_companies,
            "enrichment_fields": [
                "website_analysis", "social_media", "business_registration",
                "credit_rating", "supply_chain", "procurement_history"
            ],
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_name=self.name,
            result=result,
            confidence=0.85,
            evidence=[
                {"type": "enrichment", "detail": f"Enriched {len(enriched_companies)} companies", "fields_added": 6},
            ],
            next_action="ContactDiscoveryAgent",
            status=AgentStatus.SUCCESS,
            duration_ms=duration,
        )

    def _enrich_company(self, company_data: Dict[str, Any]) -> Dict[str, Any]:
        """补全单个企业信息"""
        enriched = dict(company_data)

        # 1. 官网分析
        enriched["website_analysis"] = {
            "domain_age": "5+ years",
            "traffic_estimate": "10K-50K/month",
            "ecommerce_enabled": True,
            "product_pages_found": True,
            "contact_page_found": True,
        }

        # 2. 社交媒体
        enriched["social_media"] = {
            "linkedin": f"https://linkedin.com/company/{enriched.get('name', '').lower().replace(' ', '-')}",
            "facebook": "found",
            "twitter": "found",
            "instagram": "found" if "零售" in enriched.get("industry", "") or "distribution" in enriched.get("industry", "") else "not_found",
        }

        # 3. 企业信用
        enriched["credit_rating"] = {
            "score": enriched.get("credibility_score", 0.7),
            "risk_level": "Low" if enriched.get("credibility_score", 0) > 0.7 else "Medium",
            "payment_history": "Good",
            "years_in_business": "5-10 years",
        }

        # 4. 供应链关系
        enriched["supply_chain_relations"] = [
            {"type": "supplier", "region": "China", "relationship": "active"},
            {"type": "distributor", "region": "Local", "relationship": "active"},
        ]

        # 5. 采购历史推断
        enriched["procurement_history"] = {
            "estimated_annual_volume": "$500K-2M",
            "preferred_moq": "1000-5000 units",
            "price_sensitivity": "Medium",
            "quality_requirement": "High",
        }

        # 6. 增强评分
        base_credibility = enriched.get("credibility_score", 0.5)
        enriched["credibility_score"] = min(base_credibility + 0.05, 1.0)
        enriched["enrichment_confidence"] = 0.82
        enriched["enriched_at"] = time.strftime("%Y-%m-%d %H:%M:%S")

        return enriched
