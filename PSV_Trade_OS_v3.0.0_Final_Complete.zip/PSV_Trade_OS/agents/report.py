"""
Report Agent - 报告生成Agent
负责：输出最终外贸开发报告、可视化数据、执行摘要
"""
from typing import Dict, Any, List
from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.memory.short_term import get_short_term_memory
from audit.logger import get_audit_logger
import time


class ReportAgent(BaseAgent):
    """报告生成Agent - 最终外贸开发报告"""

    def __init__(self):
        super().__init__("ReportAgent")
        self.description = "负责输出最终外贸开发报告、可视化数据、执行摘要"
        self.stm = get_short_term_memory()
        self.audit = get_audit_logger()

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()

        # 从短期记忆获取全流程数据
        task_id = request.task_id

        market_analysis = self.stm.get(task_id, "market_analysis") or {}
        company_pool = self.stm.get(task_id, "company_pool") or []
        enriched_companies = self.stm.get(task_id, "enriched_companies") or []
        scored_leads = self.stm.get(task_id, "scored_leads") or []
        strategies = self.stm.get(task_id, "sales_strategies") or []

        # 生成完整报告
        report = self._generate_full_report(
            task_id=task_id,
            objective=request.input_data.get("all_data", {}).get("objective", ""),
            market_analysis=market_analysis,
            company_pool=company_pool,
            enriched_companies=enriched_companies,
            scored_leads=scored_leads,
            strategies=strategies,
        )

        # 保存报告
        self.stm.set(task_id, "final_report", report)

        duration = int((time.time() - start) * 1000)

        return AgentResponse(
            request_id=request.request_id,
            task_id=task_id,
            agent_name=self.name,
            result=report,
            confidence=0.95,
            evidence=[
                {"type": "report_generation", "detail": "Complete trade development report generated", "sections": 8},
            ],
            next_action=None,
            status=AgentStatus.SUCCESS,
            duration_ms=duration,
        )

    def _generate_full_report(self, task_id: str, objective: str, market_analysis: Dict,
                              company_pool: List, enriched_companies: List,
                              scored_leads: List, strategies: List) -> Dict[str, Any]:
        """生成完整报告"""

        # 计算统计数据
        total_companies = len(company_pool)
        total_enriched = len(enriched_companies)
        total_scored = len(scored_leads)
        a_grade = len([l for l in scored_leads if l.get("lead_grade") == "A"])
        b_grade = len([l for l in scored_leads if l.get("lead_grade") == "B"])

        top_3_leads = scored_leads[:3] if scored_leads else []

        return {
            "report_metadata": {
                "report_id": f"RPT_{task_id}",
                "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "objective": objective,
                "system_version": "3.0.0",
                "total_agents_executed": 7,
            },
            "executive_summary": {
                "mission": objective,
                "market_analyzed": market_analysis.get("market", "N/A"),
                "product": market_analysis.get("product", "N/A"),
                "companies_discovered": total_companies,
                "companies_enriched": total_enriched,
                "leads_scored": total_scored,
                "a_grade_leads": a_grade,
                "b_grade_leads": b_grade,
                "key_finding": f"发现{total_companies}家目标企业，其中{a_grade}家被评为A级高价值客户，建议优先跟进。",
            },
            "market_analysis_summary": {
                "market_size": market_analysis.get("market_profile", {}).get("market_size_usd", "N/A"),
                "growth_rate": market_analysis.get("market_profile", {}).get("growth_rate", "N/A"),
                "competition_level": market_analysis.get("market_profile", {}).get("competition_level", "N/A"),
                "top_opportunities": [op.get("description", "") for op in market_analysis.get("opportunities", [])[:3]],
                "key_risks": market_analysis.get("risks", [])[:3],
                "market_entry_recommendation": market_analysis.get("recommendation", ""),
            },
            "top_leads": [
                {
                    "rank": i + 1,
                    "company": lead.get("name", ""),
                    "country": lead.get("country", ""),
                    "grade": lead.get("lead_grade", ""),
                    "overall_score": lead.get("scores", {}).get("overall_score", 0),
                    "deal_probability": lead.get("scores", {}).get("deal_probability", 0),
                    "contacts": len(lead.get("contacts", [])),
                    "decision_makers": len([c for c in lead.get("contacts", []) if c.get("is_decision_maker")]),
                    "website": lead.get("website", ""),
                }
                for i, lead in enumerate(top_3_leads)
            ],
            "strategy_summary": {
                "total_strategies": len(strategies),
                "priority_actions": [
                    "立即发送开发邮件给A级客户",
                    "LinkedIn建立专业连接",
                    "准备多语言产品资料和样品",
                    "建立CRM跟进机制",
                ],
                "follow_up_timeline": {
                    "week_1": "初次接触 + 邮件跟进",
                    "week_2": "LinkedIn互动 + 价值内容分享",
                    "week_3": "电话/视频会议邀约",
                    "week_4": "样品寄送或正式报价",
                    "month_2": "商务谈判推进",
                    "month_3": "合同签订或转入长期培育",
                },
            },
            "data_quality": {
                "enrichment_rate": f"{total_enriched}/{total_companies}" if total_companies > 0 else "N/A",
                "contact_discovery_rate": f"{sum(len(l.get('contacts', [])) for l in scored_leads)}/{total_companies}" if total_companies > 0 else "N/A",
                "average_score": round(sum(l.get("scores", {}).get("overall_score", 0) for l in scored_leads) / len(scored_leads), 2) if scored_leads else 0,
            },
            "next_steps": [
                {"priority": 1, "action": f"立即联系Top 3 leads（{', '.join(l.get('name', '') for l in top_3_leads)}", "owner": "Sales Team", "deadline": "3天内"},
                {"priority": 2, "action": "准备定制化产品资料和报价单", "owner": "Product Team", "deadline": "1周内"},
                {"priority": 3, "action": "建立CRM跟进记录，设置自动提醒", "owner": "Sales Team", "deadline": "1周内"},
                {"priority": 4, "action": "分析A级客户反馈，优化开发策略", "owner": "Strategy Team", "deadline": "2周内"},
            ],
            "appendix": {
                "full_company_list": [c.get("name", "") for c in company_pool],
                "full_scored_list": [{"name": l.get("name", ""), "grade": l.get("lead_grade", ""), "score": l.get("scores", {}).get("overall_score", 0)} for l in scored_leads],
                "audit_trail_available": True,
                "recovery_point_available": True,
            },
        }
