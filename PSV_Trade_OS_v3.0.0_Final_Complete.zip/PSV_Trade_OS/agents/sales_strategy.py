"""
Sales Strategy Agent - 销售策略Agent
负责：生成开发策略、邮件方向、跟进建议、话术模板
"""
from typing import Dict, Any, List
from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.memory.short_term import get_short_term_memory
from audit.logger import get_audit_logger
import time


class SalesStrategyAgent(BaseAgent):
    """销售策略Agent - 个性化开发策略生成"""

    def __init__(self):
        super().__init__("SalesStrategyAgent")
        self.description = "负责生成开发策略、邮件方向、跟进建议、话术模板"
        self.stm = get_short_term_memory()
        self.audit = get_audit_logger()

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()

        scored_leads_data = request.input_data.get("scored_leads", {})
        scored_leads = scored_leads_data.get("scored_leads", [])

        strategies = []
        for lead in scored_leads:
            strategy = self._generate_strategy(lead)
            strategies.append(strategy)

        # 保存到短期记忆
        self.stm.set(request.task_id, "sales_strategies", strategies)

        duration = int((time.time() - start) * 1000)

        result = {
            "strategy_count": len(strategies),
            "strategies": strategies,
            "general_advice": self._generate_general_advice(scored_leads),
            "follow_up_framework": {
                "day_3": "发送跟进邮件，确认收到",
                "day_7": "LinkedIn互动，建立连接",
                "day_14": "电话/视频会议邀约",
                "day_30": "提供样品或报价",
                "day_60": "最终跟进或转移 nurturing",
            },
        }

        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_name=self.name,
            result=result,
            confidence=0.87,
            evidence=[
                {"type": "strategy_generation", "detail": f"Generated {len(strategies)} personalized strategies"},
                {"type": "template_count", "email_templates": len(strategies), "follow_up_sequences": 5},
            ],
            next_action="ReportAgent",
            status=AgentStatus.SUCCESS,
            duration_ms=duration,
        )

    def _generate_strategy(self, lead: Dict[str, Any]) -> Dict[str, Any]:
        """为单个lead生成策略"""
        scores = lead.get("scores", {})
        grade = lead.get("lead_grade", "C")
        contacts = lead.get("contacts", [])
        decision_makers = [c for c in contacts if c.get("is_decision_maker")]

        # 根据评分等级调整策略
        if grade == "A":
            approach = "High-touch personalized approach"
            urgency = "Immediate"
            offer = "Exclusive partnership terms + sample program"
        elif grade == "B":
            approach = "Professional direct approach"
            urgency = "Within 3 days"
            offer = "Competitive pricing + flexible MOQ"
        else:
            approach = "Standard nurturing approach"
            urgency = "Within 1 week"
            offer = "Catalog + standard pricing"

        # 生成邮件模板
        product = lead.get("main_products", ["products"])[0] if lead.get("main_products") else "products"
        company_name = lead.get("name", "your company")

        email_template = {
            "subject": f"Premium {product} Supply - Partnership Opportunity with {company_name}",
            "opening": f"Dear {decision_makers[0].get('title', 'Manager') if decision_makers else 'Manager'},",
            "body": f"""I hope this email finds you well. My name is [Your Name] from [Your Company], a leading manufacturer of {product} based in China.

We have been researching the {lead.get('country', 'your')} market and noticed that {company_name} has an excellent reputation in {lead.get('industry', 'the industry')}.

Given your procurement focus on {', '.join(lead.get('procurement_direction', ['related products']))}, I believe there is a strong synergy between our offerings.

Key advantages we offer:
- Factory-direct competitive pricing
- Strict quality control (ISO 9001, BSCI certified)
- Flexible MOQ and customization options
- 15+ years of export experience to {lead.get('country', 'your region')}

Would you be open to a brief call next week to explore how we can support your sourcing needs?

Best regards,
[Your Name]
[Your Company]""",
            "cta": "Reply to schedule a call or request our catalog",
        }

        return {
            "company": company_name,
            "company_id": lead.get("company_id", ""),
            "lead_grade": grade,
            "overall_score": scores.get("overall_score", 0),
            "approach": approach,
            "urgency": urgency,
            "initial_offer": offer,
            "target_contact": decision_makers[0].get("name", "Decision Maker") if decision_makers else "Purchasing Manager",
            "best_contact_method": decision_makers[0].get("best_contact_method", "Email") if decision_makers else "Email",
            "email_template": email_template,
            "follow_up_plan": [
                {"day": 3, "action": "Follow-up email", "content": "Confirm receipt and offer catalog"},
                {"day": 7, "action": "LinkedIn connection", "content": "Connect with decision maker"},
                {"day": 14, "action": "Value-add email", "content": "Share market insights or case study"},
                {"day": 30, "action": "Sample offer", "content": "Offer free samples for quality verification"},
            ],
            "objection_handling": {
                "price_too_high": "Emphasize total cost of ownership and quality consistency",
                "already_have_supplier": "Offer backup supplier status or unique product variants",
                "not_interested": "Ask for feedback on current challenges, offer free consultation",
            },
        }

    def _generate_general_advice(self, scored_leads: List[Dict[str, Any]]) -> str:
        """生成总体建议"""
        a_count = len([l for l in scored_leads if l.get("lead_grade") == "A"])
        total = len(scored_leads)

        if a_count >= 3:
            return f"优质客户充足（{a_count}个A级），建议集中资源优先攻克Top 3，建立标杆案例后再扩展。"
        elif a_count >= 1:
            return f"有{a_count}个A级客户，建议重点跟进，同时培育B级客户作为后备。"
        else:
            return "A级客户较少，建议扩大发现范围或调整目标市场/客户画像。"
