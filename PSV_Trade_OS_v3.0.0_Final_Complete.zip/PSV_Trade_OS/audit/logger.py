"""
Audit Logger - 审计日志系统
所有智能行为必须可追踪
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import os
import threading


class AuditLogger:
    """审计日志记录器"""

    def __init__(self, log_dir: str = "./audit_logs"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        self._buffer: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._buffer_size = 100

    def log(self, 
            task_id: str,
            workflow_id: str,
            agent_id: str,
            input_data: Dict[str, Any],
            output_data: Dict[str, Any],
            tool_call: str = "",
            duration_ms: int = 0,
            status: str = "success",
            error: str = None) -> None:
        """记录审计日志"""
        entry = {
            "audit_id": f"AUD_{datetime.now().timestamp()}",
            "task_id": task_id,
            "workflow_id": workflow_id,
            "agent_id": agent_id,
            "input": input_data,
            "output": output_data,
            "tool_call": tool_call,
            "duration_ms": duration_ms,
            "status": status,
            "error": error,
            "timestamp": datetime.now().isoformat(),
        }

        with self._lock:
            self._buffer.append(entry)
            if len(self._buffer) >= self._buffer_size:
                self._flush()

    def _flush(self) -> None:
        """将缓冲区写入磁盘"""
        if not self._buffer:
            return

        date_str = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(self.log_dir, f"audit_{date_str}.jsonl")

        with open(log_file, "a", encoding="utf-8") as f:
            for entry in self._buffer:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        self._buffer.clear()

    def query(self, task_id: str = None, agent_id: str = None, 
              start_time: str = None, end_time: str = None,
              limit: int = 100) -> List[Dict[str, Any]]:
        """查询审计日志"""
        self._flush()  # 先刷新缓冲区

        results = []
        log_files = sorted(os.listdir(self.log_dir))

        for filename in log_files:
            if not filename.endswith(".jsonl"):
                continue

            filepath = os.path.join(self.log_dir, filename)
            with open(filepath, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())

                        # 过滤条件
                        if task_id and entry.get("task_id") != task_id:
                            continue
                        if agent_id and entry.get("agent_id") != agent_id:
                            continue
                        if start_time and entry.get("timestamp", "") < start_time:
                            continue
                        if end_time and entry.get("timestamp", "") > end_time:
                            continue

                        results.append(entry)
                        if len(results) >= limit:
                            return results
                    except json.JSONDecodeError:
                        continue

        return results

    def get_agent_execution_chain(self, task_id: str) -> List[Dict[str, Any]]:
        """获取某个任务的完整Agent执行链"""
        logs = self.query(task_id=task_id)
        return sorted(logs, key=lambda x: x.get("timestamp", ""))

    def get_failure_analysis(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取失败分析 - 回答：哪里失败？为什么失败？"""
        logs = self.query(task_id=task_id, limit=1000)
        failures = [log for log in logs if log.get("status") == "failed"]

        if not failures:
            return None

        return {
            "task_id": task_id,
            "total_steps": len(logs),
            "failure_count": len(failures),
            "first_failure": failures[0],
            "failure_chain": failures,
            "last_successful_step": next(
                (log for log in reversed(logs) if log.get("status") == "success"),
                None
            ),
        }

    def close(self) -> None:
        """关闭并刷新所有日志"""
        self._flush()


# 全局单例
_al_instance = None


def get_audit_logger() -> AuditLogger:
    global _al_instance
    if _al_instance is None:
        _al_instance = AuditLogger()
    return _al_instance
