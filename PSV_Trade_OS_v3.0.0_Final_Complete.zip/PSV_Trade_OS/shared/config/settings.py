"""
Global Configuration - 系统全局配置
"""
import os
from dataclasses import dataclass, field
from typing import Dict, Any


@dataclass
class PSVConfig:
    """PSV Trade OS 全局配置"""

    # 系统标识
    system_name: str = "PSV Trade Intelligence OS"
    version: str = "3.0.0"

    # LangGraph 配置
    graph_timeout: int = 3600  # 秒
    max_retries: int = 3
    checkpoint_interval: int = 30  # 秒

    # Agent 配置
    agent_timeout: int = 300  # 秒
    max_concurrent_agents: int = 5

    # 数据库配置
    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///psv_trade_os.db"))

    # 审计配置
    audit_enabled: bool = True
    audit_retention_days: int = 365

    # 恢复配置
    recovery_enabled: bool = True
    recovery_max_attempts: int = 3

    # 缓存配置
    cache_enabled: bool = True
    cache_ttl: int = 3600  # 秒

    # 业务配置
    default_markets: list = field(default_factory=lambda: ["US", "EU", "JP", "KR", "AU"])
    scoring_threshold: float = 0.6

    # LLM 配置
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "deepseek-chat"))
    llm_api_key: str = field(default_factory=lambda: os.getenv("LLM_API_KEY", ""))
    llm_base_url: str = field(default_factory=lambda: os.getenv("LLM_BASE_URL", ""))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "system_name": self.system_name,
            "version": self.version,
            "graph_timeout": self.graph_timeout,
            "max_retries": self.max_retries,
            "checkpoint_interval": self.checkpoint_interval,
            "agent_timeout": self.agent_timeout,
            "max_concurrent_agents": self.max_concurrent_agents,
            "database_url": self.database_url,
            "audit_enabled": self.audit_enabled,
            "recovery_enabled": self.recovery_enabled,
            "cache_enabled": self.cache_enabled,
            "llm_model": self.llm_model,
        }


# 全局单例配置实例
_config_instance = None


def get_config() -> PSVConfig:
    global _config_instance
    if _config_instance is None:
        _config_instance = PSVConfig()
    return _config_instance
