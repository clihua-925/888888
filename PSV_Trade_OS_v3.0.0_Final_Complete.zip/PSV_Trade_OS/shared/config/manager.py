"""
Config Manager - 配置管理器
支持多环境配置、动态配置更新
"""
from typing import Dict, Any, Optional
import os
import json


class ConfigManager:
    """配置管理器"""

    def __init__(self, config_dir: str = "./config"):
        self.config_dir = config_dir
        os.makedirs(config_dir, exist_ok=True)
        self._configs: Dict[str, Dict[str, Any]] = {}
        self._load_all()

    def _load_all(self):
        """加载所有配置文件"""
        if not os.path.exists(self.config_dir):
            return

        for filename in os.listdir(self.config_dir):
            if filename.endswith(".json"):
                env = filename.replace(".json", "")
                filepath = os.path.join(self.config_dir, filename)
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        self._configs[env] = json.load(f)
                except Exception:
                    pass

    def get(self, key: str, default: Any = None, env: str = "default") -> Any:
        """获取配置值"""
        # 优先从环境变量读取
        env_key = f"PSV_{key.upper()}"
        if env_key in os.environ:
            return os.environ[env_key]

        # 从配置文件读取
        config = self._configs.get(env, {})
        return config.get(key, default)

    def set(self, key: str, value: Any, env: str = "default") -> None:
        """设置配置值"""
        if env not in self._configs:
            self._configs[env] = {}
        self._configs[env][key] = value
        self._save(env)

    def _save(self, env: str):
        """保存配置到文件"""
        filepath = os.path.join(self.config_dir, f"{env}.json")
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self._configs[env], f, ensure_ascii=False, indent=2)

    def get_all(self, env: str = "default") -> Dict[str, Any]:
        """获取所有配置"""
        return dict(self._configs.get(env, {}))

    def create_env(self, env: str, base_env: str = "default") -> None:
        """创建新环境配置"""
        self._configs[env] = dict(self._configs.get(base_env, {}))
        self._save(env)


# 全局单例
_cm_instance = None


def get_config_manager() -> ConfigManager:
    global _cm_instance
    if _cm_instance is None:
        _cm_instance = ConfigManager()
    return _cm_instance
