"""
State Manager - LangGraph Workflow 状态管理
支持暂停、恢复、继续执行
"""
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime
import json
import os
import threading


@dataclass
class WorkflowState:
    """工作流状态快照"""
    workflow_id: str
    task_id: str
    current_node: str
    node_history: List[str] = field(default_factory=list)
    data: Dict[str, Any] = field(default_factory=dict)
    status: str = "running"  # running, paused, completed, failed
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "workflow_id": self.workflow_id,
            "task_id": self.task_id,
            "current_node": self.current_node,
            "node_history": self.node_history,
            "data": self.data,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowState":
        return cls(
            workflow_id=data["workflow_id"],
            task_id=data["task_id"],
            current_node=data["current_node"],
            node_history=data.get("node_history", []),
            data=data.get("data", {}),
            status=data.get("status", "running"),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
        )


class StateManager:
    """状态管理器 - 支持持久化和恢复"""

    def __init__(self, checkpoint_dir: str = "./checkpoints"):
        self.checkpoint_dir = checkpoint_dir
        os.makedirs(checkpoint_dir, exist_ok=True)
        self._active_states: Dict[str, WorkflowState] = {}
        self._lock = threading.RLock()

    def create_state(self, workflow_id: str, task_id: str, initial_node: str = "start") -> WorkflowState:
        """创建新的工作流状态"""
        with self._lock:
            state = WorkflowState(
                workflow_id=workflow_id,
                task_id=task_id,
                current_node=initial_node,
            )
            self._active_states[workflow_id] = state
            self._save_checkpoint(state)
            return state

    def get_state(self, workflow_id: str) -> Optional[WorkflowState]:
        """获取当前状态"""
        with self._lock:
            if workflow_id in self._active_states:
                return self._active_states[workflow_id]
            # 尝试从检查点恢复
            return self._load_checkpoint(workflow_id)

    def update_state(self, workflow_id: str, node: str, data: Dict[str, Any] = None) -> Optional[WorkflowState]:
        """更新状态并保存检查点"""
        with self._lock:
            state = self._active_states.get(workflow_id)
            if not state:
                return None

            state.current_node = node
            state.node_history.append(node)
            if data:
                state.data.update(data)
            state.updated_at = datetime.now().isoformat()

            self._save_checkpoint(state)
            return state

    def pause_state(self, workflow_id: str) -> bool:
        """暂停工作流"""
        with self._lock:
            state = self._active_states.get(workflow_id)
            if state:
                state.status = "paused"
                self._save_checkpoint(state)
                return True
            return False

    def resume_state(self, workflow_id: str) -> Optional[WorkflowState]:
        """恢复工作流"""
        with self._lock:
            state = self._load_checkpoint(workflow_id)
            if state and state.status == "paused":
                state.status = "running"
                self._active_states[workflow_id] = state
                self._save_checkpoint(state)
                return state
            return None

    def complete_state(self, workflow_id: str) -> bool:
        """标记工作流完成"""
        with self._lock:
            state = self._active_states.get(workflow_id)
            if state:
                state.status = "completed"
                self._save_checkpoint(state)
                return True
            return False

    def fail_state(self, workflow_id: str, error: str) -> bool:
        """标记工作流失败"""
        with self._lock:
            state = self._active_states.get(workflow_id)
            if state:
                state.status = "failed"
                state.data["error"] = error
                self._save_checkpoint(state)
                return True
            return False

    def _save_checkpoint(self, state: WorkflowState) -> None:
        """保存检查点到磁盘"""
        filepath = os.path.join(self.checkpoint_dir, f"{state.workflow_id}.json")
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state.to_dict(), f, ensure_ascii=False, indent=2)

    def _load_checkpoint(self, workflow_id: str) -> Optional[WorkflowState]:
        """从磁盘加载检查点"""
        filepath = os.path.join(self.checkpoint_dir, f"{workflow_id}.json")
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return WorkflowState.from_dict(data)
            except Exception:
                return None
        return None

    def list_checkpoints(self) -> List[str]:
        """列出所有可用的检查点"""
        files = os.listdir(self.checkpoint_dir)
        return [f.replace(".json", "") for f in files if f.endswith(".json")]


# 全局单例
_sm_instance = None


def get_state_manager() -> StateManager:
    global _sm_instance
    if _sm_instance is None:
        _sm_instance = StateManager()
    return _sm_instance
