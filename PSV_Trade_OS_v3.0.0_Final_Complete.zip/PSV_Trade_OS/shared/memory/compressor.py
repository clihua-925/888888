"""
Memory Compressor - 记忆压缩器
自动压缩和总结长期记忆，防止记忆膨胀
"""
from typing import Dict, Any, List
from datetime import datetime, timedelta


class MemoryCompressor:
    """记忆压缩器"""

    def __init__(self, max_entries_per_category: int = 100):
        self.max_entries = max_entries_per_category

    def compress(self, memories: List[Dict[str, Any]], category: str) -> Dict[str, Any]:
        """压缩记忆列表为摘要"""
        if len(memories) <= self.max_entries:
            return {"type": "raw", "data": memories}

        # 按重要性排序
        sorted_memories = sorted(memories, key=lambda x: x.get("importance", 0.5), reverse=True)

        # 保留高重要性记忆
        kept = sorted_memories[:self.max_entries // 2]

        # 压缩剩余记忆为摘要
        to_compress = sorted_memories[self.max_entries // 2:]
        summary = self._summarize(to_compress, category)

        return {
            "type": "compressed",
            "kept_memories": kept,
            "summary": summary,
            "original_count": len(memories),
            "compressed_count": len(kept) + 1,
        }

    def _summarize(self, memories: List[Dict[str, Any]], category: str) -> Dict[str, Any]:
        """生成记忆摘要"""
        # 提取关键信息
        key_points = []
        for mem in memories[:10]:  # 取前10条提取要点
            content = mem.get("content", {})
            if isinstance(content, dict):
                key_points.append(str(content)[:100])
            else:
                key_points.append(str(content)[:100])

        return {
            "category": category,
            "summarized_count": len(memories),
            "summary_date": datetime.now().isoformat(),
            "key_points": key_points,
            "average_importance": sum(m.get("importance", 0.5) for m in memories) / len(memories) if memories else 0,
        }

    def should_compress(self, memories: List[Dict[str, Any]]) -> bool:
        """判断是否需要压缩"""
        return len(memories) > self.max_entries
