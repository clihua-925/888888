"""
Vector Memory - 向量记忆存储
支持语义检索和相似度搜索
"""
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import json
import os
import hashlib


class VectorMemory:
    """简单向量记忆（基于关键词相似度）"""

    def __init__(self, storage_path: str = "./data/vector_memory.json"):
        self.storage_path = storage_path
        os.makedirs(os.path.dirname(storage_path), exist_ok=True)
        self._vectors: Dict[str, Dict[str, Any]] = self._load()

    def _load(self) -> Dict[str, Dict[str, Any]]:
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save(self) -> None:
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump(self._vectors, f, ensure_ascii=False, indent=2)

    def _text_to_vector(self, text: str) -> List[float]:
        """将文本转为简单向量（基于词频）"""
        words = text.lower().split()
        # 简单的词袋模型
        vector = {}
        for word in words:
            vector[word] = vector.get(word, 0) + 1
        # 归一化
        total = sum(vector.values()) or 1
        return {k: v/total for k, v in vector.items()}

    def _cosine_similarity(self, v1: Dict, v2: Dict) -> float:
        """计算余弦相似度"""
        all_keys = set(v1.keys()) | set(v2.keys())
        dot = sum(v1.get(k, 0) * v2.get(k, 0) for k in all_keys)
        norm1 = sum(v1.get(k, 0) ** 2 for k in all_keys) ** 0.5 or 1
        norm2 = sum(v2.get(k, 0) ** 2 for k in all_keys) ** 0.5 or 1
        return dot / (norm1 * norm2)

    def store(self, content: str, metadata: Dict[str, Any] = None, memory_id: str = None) -> str:
        """存储记忆"""
        mid = memory_id or f"vec_{hashlib.md5(content.encode()).hexdigest()}"
        vector = self._text_to_vector(content)

        self._vectors[mid] = {
            "content": content,
            "vector": vector,
            "metadata": metadata or {},
            "created_at": datetime.now().isoformat(),
        }
        self._save()
        return mid

    def search(self, query: str, top_k: int = 5) -> List[Tuple[str, float, Dict]]:
        """语义搜索"""
        query_vector = self._text_to_vector(query)

        results = []
        for mid, entry in self._vectors.items():
            similarity = self._cosine_similarity(query_vector, entry["vector"])
            results.append((mid, similarity, entry))

        # 排序并返回top_k
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]

    def get(self, memory_id: str) -> Optional[Dict[str, Any]]:
        """获取记忆"""
        return self._vectors.get(memory_id)

    def delete(self, memory_id: str) -> bool:
        """删除记忆"""
        if memory_id in self._vectors:
            del self._vectors[memory_id]
            self._save()
            return True
        return False

    def count(self) -> int:
        """获取记忆数量"""
        return len(self._vectors)


# 全局单例
_vm_instance = None


def get_vector_memory() -> VectorMemory:
    global _vm_instance
    if _vm_instance is None:
        _vm_instance = VectorMemory()
    return _vm_instance
