"""
Long-Term Memory - 长期记忆存储
保存历史任务、行业知识、客户数据、执行经验
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import os


class LongTermMemory:
    """长期记忆管理器 - 持久化存储"""

    def __init__(self, storage_path: str = None):
        self.storage_path = storage_path or "./data/long_term_memory.json"
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        self._memory: Dict[str, List[Dict[str, Any]]] = self._load()

    def _load(self) -> Dict[str, List[Dict[str, Any]]]:
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save(self) -> None:
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump(self._memory, f, ensure_ascii=False, indent=2)

    def store(self, category: str, content: Dict[str, Any], memory_id: str = None) -> str:
        """存储长期记忆"""
        if category not in self._memory:
            self._memory[category] = []

        entry = {
            "memory_id": memory_id or f"{category}_{datetime.now().timestamp()}",
            "content": content,
            "created_at": datetime.now().isoformat(),
            "access_count": 0,
        }
        self._memory[category].append(entry)
        self._save()
        return entry["memory_id"]

    def retrieve(self, category: str, query: Dict[str, Any] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """检索长期记忆"""
        if category not in self._memory:
            return []

        results = self._memory[category]

        # 简单过滤
        if query:
            filtered = []
            for entry in results:
                match = True
                for key, value in query.items():
                    if key not in entry["content"] or entry["content"][key] != value:
                        match = False
                        break
                if match:
                    filtered.append(entry)
            results = filtered

        # 按访问次数排序（热度）
        results = sorted(results, key=lambda x: x["access_count"], reverse=True)

        # 增加访问计数
        for entry in results[:limit]:
            entry["access_count"] += 1

        self._save()
        return results[:limit]

    def get_categories(self) -> List[str]:
        return list(self._memory.keys())


# 全局单例
_ltm_instance = None


def get_long_term_memory() -> LongTermMemory:
    global _ltm_instance
    if _ltm_instance is None:
        _ltm_instance = LongTermMemory()
    return _ltm_instance
