"""
Short-Term Memory - 当前任务状态记忆
保存当前workflow执行中的临时状态
"""
from typing import Dict, Any, Optional
from datetime import datetime
import threading


class ShortTermMemory:
    """短期记忆管理器 - 线程安全"""

    def __init__(self):
        self._memory: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()

    def set(self, task_id: str, key: str, value: Any) -> None:
        """设置任务级别的短期记忆"""
        with self._lock:
            if task_id not in self._memory:
                self._memory[task_id] = {}
            self._memory[task_id][key] = {
                "value": value,
                "timestamp": datetime.now().isoformat(),
            }

    def get(self, task_id: str, key: str) -> Optional[Any]:
        """获取任务级别的短期记忆"""
        with self._lock:
            if task_id in self._memory and key in self._memory[task_id]:
                return self._memory[task_id][key]["value"]
            return None

    def get_all(self, task_id: str) -> Dict[str, Any]:
        """获取任务的所有短期记忆"""
        with self._lock:
            if task_id not in self._memory:
                return {}
            return {k: v["value"] for k, v in self._memory[task_id].items()}

    def clear(self, task_id: str) -> None:
        """清除任务的短期记忆"""
        with self._lock:
            if task_id in self._memory:
                del self._memory[task_id]

    def exists(self, task_id: str, key: str) -> bool:
        """检查记忆是否存在"""
        with self._lock:
            return task_id in self._memory and key in self._memory[task_id]


# 全局单例
_stm_instance = None


def get_short_term_memory() -> ShortTermMemory:
    global _stm_instance
    if _stm_instance is None:
        _stm_instance = ShortTermMemory()
    return _stm_instance
