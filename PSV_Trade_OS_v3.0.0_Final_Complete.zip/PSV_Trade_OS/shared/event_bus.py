"""
Event Bus - 事件总线
支持模块间异步事件通信，解耦各组件
"""
from typing import Dict, Any, List, Callable, Optional
from datetime import datetime
import threading
import queue
import uuid


class EventBus:
    """异步事件总线"""

    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._event_queue: queue.Queue = queue.Queue()
        self._running = False
        self._worker_thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()

    def subscribe(self, event_type: str, handler: Callable) -> str:
        """订阅事件"""
        with self._lock:
            if event_type not in self._subscribers:
                self._subscribers[event_type] = []
            self._subscribers[event_type].append(handler)
        return f"sub_{event_type}_{id(handler)}"

    def unsubscribe(self, event_type: str, handler: Callable) -> bool:
        """取消订阅"""
        with self._lock:
            if event_type in self._subscribers and handler in self._subscribers[event_type]:
                self._subscribers[event_type].remove(handler)
                return True
        return False

    def publish(self, event_type: str, payload: Dict[str, Any], source: str = "") -> str:
        """发布事件"""
        event = {
            "event_id": str(uuid.uuid4()),
            "event_type": event_type,
            "payload": payload,
            "source": source,
            "timestamp": datetime.now().isoformat(),
        }
        self._event_queue.put(event)

        # 同步通知
        with self._lock:
            handlers = self._subscribers.get(event_type, [])
            for handler in handlers:
                try:
                    handler(event)
                except Exception as e:
                    print(f"Event handler error: {e}")

        return event["event_id"]

    def start_async_processor(self):
        """启动异步处理器"""
        if self._running:
            return
        self._running = True
        self._worker_thread = threading.Thread(target=self._process_events, daemon=True)
        self._worker_thread.start()

    def _process_events(self):
        """异步处理事件队列"""
        while self._running:
            try:
                event = self._event_queue.get(timeout=1)
                with self._lock:
                    handlers = self._subscribers.get(event["event_type"], [])
                    for handler in handlers:
                        try:
                            handler(event)
                        except Exception as e:
                            print(f"Async event handler error: {e}")
            except queue.Empty:
                continue

    def stop(self):
        """停止事件总线"""
        self._running = False
        if self._worker_thread:
            self._worker_thread.join(timeout=5)

    def get_subscriber_count(self, event_type: str = None) -> int:
        """获取订阅者数量"""
        with self._lock:
            if event_type:
                return len(self._subscribers.get(event_type, []))
            return sum(len(h) for h in self._subscribers.values())


# 全局单例
_eb_instance = None


def get_event_bus() -> EventBus:
    global _eb_instance
    if _eb_instance is None:
        _eb_instance = EventBus()
    return _eb_instance
