"""
Cache Manager - 缓存管理
"""
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import threading
import hashlib


class CacheManager:
    """简单内存缓存管理器"""

    def __init__(self):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()

    def _make_key(self, *args) -> str:
        """生成缓存键"""
        key_str = "|".join(str(a) for a in args)
        return hashlib.md5(key_str.encode()).hexdigest()

    def get(self, namespace: str, key: str) -> Optional[Any]:
        """获取缓存值"""
        with self._lock:
            full_key = f"{namespace}:{key}"
            entry = self._cache.get(full_key)
            if not entry:
                return None

            # 检查过期
            if datetime.now() > entry["expires_at"]:
                del self._cache[full_key]
                return None

            entry["access_count"] += 1
            return entry["value"]

    def set(self, namespace: str, key: str, value: Any, ttl_seconds: int = 3600) -> None:
        """设置缓存值"""
        with self._lock:
            full_key = f"{namespace}:{key}"
            self._cache[full_key] = {
                "value": value,
                "expires_at": datetime.now() + timedelta(seconds=ttl_seconds),
                "access_count": 0,
                "created_at": datetime.now().isoformat(),
            }

    def invalidate(self, namespace: str, key: str = None) -> None:
        """使缓存失效"""
        with self._lock:
            if key:
                full_key = f"{namespace}:{key}"
                if full_key in self._cache:
                    del self._cache[full_key]
            else:
                # 清除整个namespace
                to_remove = [k for k in self._cache if k.startswith(f"{namespace}:")]
                for k in to_remove:
                    del self._cache[k]

    def clear(self) -> None:
        """清除所有缓存"""
        with self._lock:
            self._cache.clear()


# 全局单例
_cm_instance = None


def get_cache_manager() -> CacheManager:
    global _cm_instance
    if _cm_instance is None:
        _cm_instance = CacheManager()
    return _cm_instance
