"""
Knowledge Base - 知识库管理
保存行业知识、市场知识、产品知识、企业知识
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import os


class KnowledgeBase:
    """知识库管理器"""

    def __init__(self, kb_path: str = "./data/knowledge_base.json"):
        self.kb_path = kb_path
        os.makedirs(os.path.dirname(kb_path), exist_ok=True)
        self._kb: Dict[str, Dict[str, Any]] = self._load()

    def _load(self) -> Dict[str, Dict[str, Any]]:
        if os.path.exists(self.kb_path):
            try:
                with open(self.kb_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save(self) -> None:
        with open(self.kb_path, "w", encoding="utf-8") as f:
            json.dump(self._kb, f, ensure_ascii=False, indent=2)

    def add(self, category: str, key: str, content: Dict[str, Any]) -> None:
        """添加知识"""
        if category not in self._kb:
            self._kb[category] = {}

        self._kb[category][key] = {
            "content": content,
            "updated_at": datetime.now().isoformat(),
        }
        self._save()

    def get(self, category: str, key: str) -> Optional[Dict[str, Any]]:
        """获取知识"""
        if category in self._kb and key in self._kb[category]:
            return self._kb[category][key]["content"]
        return None

    def search(self, category: str, query: str = None) -> List[Dict[str, Any]]:
        """搜索知识"""
        if category not in self._kb:
            return []

        results = []
        for key, entry in self._kb[category].items():
            if query is None or query.lower() in key.lower():
                results.append({
                    "key": key,
                    "content": entry["content"],
                })
        return results

    def get_categories(self) -> List[str]:
        return list(self._kb.keys())


# 全局单例
_kb_instance = None


def get_knowledge_base() -> KnowledgeBase:
    global _kb_instance
    if _kb_instance is None:
        _kb_instance = KnowledgeBase()
    return _kb_instance
