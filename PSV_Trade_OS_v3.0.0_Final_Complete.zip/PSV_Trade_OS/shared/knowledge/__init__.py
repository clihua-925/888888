from shared.knowledge.base import KnowledgeBase, get_knowledge_base
