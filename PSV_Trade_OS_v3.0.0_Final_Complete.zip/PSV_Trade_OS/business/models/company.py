"""
Company Model - 企业画像
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid


@dataclass
class CompanyProfile:
    """企业画像"""
    company_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    country: str = ""
    website: str = ""
    industry: str = ""
    main_products: List[str] = field(default_factory=list)
    procurement_direction: List[str] = field(default_factory=list)
    company_size: str = ""
    supply_chain_relations: List[Dict[str, str]] = field(default_factory=list)
    contacts: List[Dict[str, Any]] = field(default_factory=list)
    contact_info: Dict[str, str] = field(default_factory=dict)
    credibility_score: float = 0.0
    procurement_probability: float = 0.0
    match_score: float = 0.0
    source: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "company_id": self.company_id,
            "name": self.name,
            "country": self.country,
            "website": self.website,
            "industry": self.industry,
            "main_products": self.main_products,
            "procurement_direction": self.procurement_direction,
            "company_size": self.company_size,
            "supply_chain_relations": self.supply_chain_relations,
            "contacts": self.contacts,
            "contact_info": self.contact_info,
            "credibility_score": self.credibility_score,
            "procurement_probability": self.procurement_probability,
            "match_score": self.match_score,
            "source": self.source,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
