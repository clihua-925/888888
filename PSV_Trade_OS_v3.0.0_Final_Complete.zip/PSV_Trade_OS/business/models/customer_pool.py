"""
Customer Pool Model - 客户智能池
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid


@dataclass
class CustomerIntelligence:
    """客户智能条目"""
    customer_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    company_id: str = ""
    company_name: str = ""
    customer_level: str = "C"
    customer_value: float = 0.0
    match_degree: float = 0.0
    deal_probability: float = 0.0
    development_priority: int = 0
    follow_up_status: str = "new"
    last_contact: Optional[str] = None
    notes: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "customer_id": self.customer_id,
            "company_id": self.company_id,
            "company_name": self.company_name,
            "customer_level": self.customer_level,
            "customer_value": self.customer_value,
            "match_degree": self.match_degree,
            "deal_probability": self.deal_probability,
            "development_priority": self.development_priority,
            "follow_up_status": self.follow_up_status,
            "last_contact": self.last_contact,
            "notes": self.notes,
            "tags": self.tags,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
