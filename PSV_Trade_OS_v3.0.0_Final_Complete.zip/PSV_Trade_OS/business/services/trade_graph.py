"""
Trade Graph - 商业关系图谱
构建：产品-企业-国家-供应链-市场-客户关系网络
"""
from typing import Dict, Any, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
import json
import os


@dataclass
class TradeNode:
    """贸易图谱节点"""
    node_id: str
    node_type: str  # product, company, country, market, contact, opportunity
    label: str
    properties: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class TradeEdge:
    """贸易图谱边（关系）"""
    edge_id: str
    source_id: str
    target_id: str
    relation_type: str  # supplies_to, imports_from, operates_in, located_in, contacts, competes_with
    properties: Dict[str, Any] = field(default_factory=dict)
    weight: float = 1.0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


class TradeGraph:
    """贸易商业关系图谱"""

    def __init__(self, storage_path: str = "./data/trade_graph.json"):
        self.storage_path = storage_path
        os.makedirs(os.path.dirname(storage_path), exist_ok=True)
        self._nodes: Dict[str, TradeNode] = {}
        self._edges: Dict[str, TradeEdge] = {}
        self._adjacency: Dict[str, List[str]] = {}  # node_id -> list of edge_ids
        self._load()

    def _load(self):
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for n in data.get("nodes", []):
                    self._nodes[n["node_id"]] = TradeNode(**n)
                for e in data.get("edges", []):
                    self._edges[e["edge_id"]] = TradeEdge(**e)
                    self._build_adjacency()
            except Exception:
                pass

    def _save(self):
        data = {
            "nodes": [{"node_id": n.node_id, "node_type": n.node_type, "label": n.label, 
                       "properties": n.properties, "created_at": n.created_at} for n in self._nodes.values()],
            "edges": [{"edge_id": e.edge_id, "source_id": e.source_id, "target_id": e.target_id,
                       "relation_type": e.relation_type, "properties": e.properties, "weight": e.weight,
                       "created_at": e.created_at} for e in self._edges.values()],
        }
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _build_adjacency(self):
        self._adjacency = {}
        for edge in self._edges.values():
            if edge.source_id not in self._adjacency:
                self._adjacency[edge.source_id] = []
            self._adjacency[edge.source_id].append(edge.edge_id)

    def add_node(self, node_type: str, label: str, properties: Dict[str, Any] = None, node_id: str = None) -> str:
        """添加节点"""
        nid = node_id or f"{node_type}_{label.replace(' ', '_').replace('/', '_')}_{datetime.now().timestamp()}"
        node = TradeNode(
            node_id=nid,
            node_type=node_type,
            label=label,
            properties=properties or {},
        )
        self._nodes[nid] = node
        self._save()
        return nid

    def add_edge(self, source_id: str, target_id: str, relation_type: str, 
                 properties: Dict[str, Any] = None, weight: float = 1.0) -> str:
        """添加关系边"""
        eid = f"edge_{source_id}_{target_id}_{relation_type}_{datetime.now().timestamp()}"
        edge = TradeEdge(
            edge_id=eid,
            source_id=source_id,
            target_id=target_id,
            relation_type=relation_type,
            properties=properties or {},
            weight=weight,
        )
        self._edges[eid] = edge
        self._build_adjacency()
        self._save()
        return eid

    def get_node(self, node_id: str) -> Optional[TradeNode]:
        return self._nodes.get(node_id)

    def get_neighbors(self, node_id: str, relation_type: str = None) -> List[Dict[str, Any]]:
        """获取邻居节点"""
        results = []
        edge_ids = self._adjacency.get(node_id, [])
        for eid in edge_ids:
            edge = self._edges.get(eid)
            if not edge:
                continue
            if relation_type and edge.relation_type != relation_type:
                continue
            target = self._nodes.get(edge.target_id)
            if target:
                results.append({
                    "node": target,
                    "edge": edge,
                })
        return results

    def find_path(self, source_id: str, target_id: str, max_depth: int = 5) -> List[List[str]]:
        """查找两个节点之间的路径"""
        paths = []
        visited = set()

        def dfs(current: str, target: str, path: List[str], depth: int):
            if depth > max_depth:
                return
            if current == target:
                paths.append(path[:])
                return
            visited.add(current)
            for edge_id in self._adjacency.get(current, []):
                edge = self._edges.get(edge_id)
                if edge and edge.target_id not in visited:
                    path.append(edge.target_id)
                    dfs(edge.target_id, target, path, depth + 1)
                    path.pop()
            visited.remove(current)

        dfs(source_id, target_id, [source_id], 0)
        return paths

    def get_supply_chain(self, company_id: str) -> Dict[str, List[Dict[str, Any]]]:
        """获取企业供应链关系"""
        suppliers = self.get_neighbors(company_id, "supplies_to")
        customers = self.get_neighbors(company_id, "imports_from")
        competitors = self.get_neighbors(company_id, "competes_with")

        return {
            "suppliers": suppliers,
            "customers": customers,
            "competitors": competitors,
            "partners": self.get_neighbors(company_id, "partners_with"),
        }

    def build_from_task(self, task_id: str, companies: List[Dict[str, Any]], 
                        product: str, market: str) -> Dict[str, Any]:
        """从任务结果构建贸易图谱"""
        # 创建产品节点
        product_node = self.add_node("product", product, {"task_id": task_id})

        # 创建市场节点
        market_node = self.add_node("market", market, {"task_id": task_id})

        # 创建国家节点
        country_node = self.add_node("country", market, {"task_id": task_id})

        company_nodes = []
        for company in companies:
            # 创建企业节点
            cid = self.add_node(
                "company", 
                company.get("name", ""),
                {
                    "company_id": company.get("company_id", ""),
                    "website": company.get("website", ""),
                    "industry": company.get("industry", ""),
                    "size": company.get("company_size", ""),
                    "score": company.get("scores", {}).get("overall_score", 0),
                    "grade": company.get("lead_grade", ""),
                    "task_id": task_id,
                }
            )
            company_nodes.append(cid)

            # 企业-产品关系
            self.add_edge(cid, product_node, "procures", {"task_id": task_id})

            # 企业-市场关系
            self.add_edge(cid, market_node, "operates_in", {"task_id": task_id})

            # 企业-国家关系
            self.add_edge(cid, country_node, "located_in", {"task_id": task_id})

            # 联系人节点
            for contact in company.get("contacts", []):
                contact_node = self.add_node(
                    "contact",
                    contact.get("name", ""),
                    {
                        "title": contact.get("title", ""),
                        "email": contact.get("email", ""),
                        "is_decision_maker": contact.get("is_decision_maker", False),
                    }
                )
                self.add_edge(contact_node, cid, "works_at", {"role": contact.get("title", "")})

            # 供应链关系
            for relation in company.get("supply_chain_relations", []):
                if relation.get("type") == "supplier":
                    supplier_node = self.add_node("supplier", f"Supplier_{relation.get('region', '')}", relation)
                    self.add_edge(cid, supplier_node, "sources_from", relation)

        return {
            "product_node": product_node,
            "market_node": market_node,
            "country_node": country_node,
            "company_nodes": company_nodes,
            "total_nodes": len(self._nodes),
            "total_edges": len(self._edges),
        }

    def export_for_visualization(self) -> Dict[str, Any]:
        """导出为可视化格式"""
        return {
            "nodes": [
                {"id": n.node_id, "label": n.label, "type": n.node_type, **n.properties}
                for n in self._nodes.values()
            ],
            "edges": [
                {"id": e.edge_id, "source": e.source_id, "target": e.target_id, 
                 "type": e.relation_type, "weight": e.weight}
                for e in self._edges.values()
            ],
        }

    def get_stats(self) -> Dict[str, Any]:
        """获取图谱统计"""
        node_types = {}
        for n in self._nodes.values():
            node_types[n.node_type] = node_types.get(n.node_type, 0) + 1

        edge_types = {}
        for e in self._edges.values():
            edge_types[e.relation_type] = edge_types.get(e.relation_type, 0) + 1

        return {
            "total_nodes": len(self._nodes),
            "total_edges": len(self._edges),
            "node_types": node_types,
            "edge_types": edge_types,
            "density": len(self._edges) / max(len(self._nodes) * (len(self._nodes) - 1), 1),
        }


# 全局单例
_tg_instance = None


def get_trade_graph() -> TradeGraph:
    global _tg_instance
    if _tg_instance is None:
        _tg_instance = TradeGraph()
    return _tg_instance
