"""
Repository Layer - 数据库持久化层
所有业务数据通过Repository模式持久化
"""
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime

from database.models import (
    TradeCompany, TradeContact, TradeProduct, TradeMarket,
    TradeCustomerPool, TradeOpportunity, TradeTask, TradeWorkflow,
    AgentExecutionLog, AuditEvent, MemoryStore, init_db, get_session
)
from shared.config.settings import get_config


class BaseRepository:
    """基础Repository"""

    def __init__(self):
        config = get_config()
        self.engine = init_db(config.database_url)
        self.session = get_session(self.engine)

    def commit(self):
        self.session.commit()

    def rollback(self):
        self.session.rollback()

    def close(self):
        self.session.close()


class CompanyRepository(BaseRepository):
    """企业Repository"""

    def create(self, data: Dict[str, Any]) -> TradeCompany:
        company = TradeCompany(**data)
        self.session.add(company)
        self.session.commit()
        return company

    def get_by_id(self, company_id: str) -> Optional[TradeCompany]:
        return self.session.query(TradeCompany).filter_by(company_id=company_id).first()

    def get_by_name(self, name: str) -> List[TradeCompany]:
        return self.session.query(TradeCompany).filter(TradeCompany.name.like(f"%{name}%")).all()

    def get_by_country(self, country: str, limit: int = 100) -> List[TradeCompany]:
        return self.session.query(TradeCompany).filter_by(country=country).limit(limit).all()

    def get_high_score(self, min_score: float = 0.7, limit: int = 50) -> List[TradeCompany]:
        return self.session.query(TradeCompany).filter(TradeCompany.match_score >= min_score).order_by(desc(TradeCompany.match_score)).limit(limit).all()

    def update(self, company_id: str, data: Dict[str, Any]) -> bool:
        company = self.get_by_id(company_id)
        if not company:
            return False
        for key, value in data.items():
            if hasattr(company, key):
                setattr(company, key, value)
        company.updated_at = datetime.now()
        self.session.commit()
        return True

    def list_all(self, limit: int = 1000) -> List[TradeCompany]:
        return self.session.query(TradeCompany).limit(limit).all()

    def count(self) -> int:
        return self.session.query(TradeCompany).count()


class CustomerPoolRepository(BaseRepository):
    """客户池Repository"""

    def create(self, data: Dict[str, Any]) -> TradeCustomerPool:
        customer = TradeCustomerPool(**data)
        self.session.add(customer)
        self.session.commit()
        return customer

    def get_by_id(self, customer_id: str) -> Optional[TradeCustomerPool]:
        return self.session.query(TradeCustomerPool).filter_by(customer_id=customer_id).first()

    def get_by_grade(self, grade: str, limit: int = 100) -> List[TradeCustomerPool]:
        return self.session.query(TradeCustomerPool).filter_by(customer_level=grade).limit(limit).all()

    def get_priority_list(self, limit: int = 50) -> List[TradeCustomerPool]:
        return self.session.query(TradeCustomerPool).order_by(desc(TradeCustomerPool.development_priority)).limit(limit).all()

    def update_status(self, customer_id: str, status: str) -> bool:
        customer = self.get_by_id(customer_id)
        if not customer:
            return False
        customer.follow_up_status = status
        customer.last_contact = datetime.now()
        customer.updated_at = datetime.now()
        self.session.commit()
        return True

    def list_all(self, limit: int = 1000) -> List[TradeCustomerPool]:
        return self.session.query(TradeCustomerPool).limit(limit).all()

    def count_by_status(self) -> Dict[str, int]:
        from sqlalchemy import func
        result = self.session.query(TradeCustomerPool.follow_up_status, func.count(TradeCustomerPool.customer_id)).group_by(TradeCustomerPool.follow_up_status).all()
        return {status: count for status, count in result}


class TaskRepository(BaseRepository):
    """任务Repository"""

    def create(self, data: Dict[str, Any]) -> TradeTask:
        task = TradeTask(**data)
        self.session.add(task)
        self.session.commit()
        return task

    def get_by_id(self, task_id: str) -> Optional[TradeTask]:
        return self.session.query(TradeTask).filter_by(task_id=task_id).first()

    def get_by_status(self, status: str, limit: int = 100) -> List[TradeTask]:
        return self.session.query(TradeTask).filter_by(status=status).order_by(desc(TradeTask.created_at)).limit(limit).all()

    def update_status(self, task_id: str, status: str, result_summary: str = None) -> bool:
        task = self.get_by_id(task_id)
        if not task:
            return False
        task.status = status
        if result_summary:
            task.result_summary = result_summary
        task.updated_at = datetime.now()
        self.session.commit()
        return True

    def list_all(self, limit: int = 1000) -> List[TradeTask]:
        return self.session.query(TradeTask).order_by(desc(TradeTask.created_at)).limit(limit).all()


class OpportunityRepository(BaseRepository):
    """商业机会Repository"""

    def create(self, data: Dict[str, Any]) -> TradeOpportunity:
        opp = TradeOpportunity(**data)
        self.session.add(opp)
        self.session.commit()
        return opp

    def get_by_id(self, opportunity_id: str) -> Optional[TradeOpportunity]:
        return self.session.query(TradeOpportunity).filter_by(opportunity_id=opportunity_id).first()

    def get_by_customer(self, customer_id: str) -> List[TradeOpportunity]:
        return self.session.query(TradeOpportunity).filter_by(customer_id=customer_id).all()

    def get_high_value(self, min_value: float = 10000, limit: int = 50) -> List[TradeOpportunity]:
        return self.session.query(TradeOpportunity).filter(TradeOpportunity.estimated_value >= min_value).order_by(desc(TradeOpportunity.estimated_value)).limit(limit).all()

    def update_stage(self, opportunity_id: str, stage: str) -> bool:
        opp = self.get_by_id(opportunity_id)
        if not opp:
            return False
        opp.stage = stage
        opp.updated_at = datetime.now()
        self.session.commit()
        return True

    def list_all(self, limit: int = 1000) -> List[TradeOpportunity]:
        return self.session.query(TradeOpportunity).order_by(desc(TradeOpportunity.created_at)).limit(limit).all()


class WorkflowRepository(BaseRepository):
    """工作流Repository"""

    def create(self, data: Dict[str, Any]) -> TradeWorkflow:
        wf = TradeWorkflow(**data)
        self.session.add(wf)
        self.session.commit()
        return wf

    def get_by_id(self, workflow_id: str) -> Optional[TradeWorkflow]:
        return self.session.query(TradeWorkflow).filter_by(workflow_id=workflow_id).first()

    def get_by_task(self, task_id: str) -> List[TradeWorkflow]:
        return self.session.query(TradeWorkflow).filter_by(task_id=task_id).all()

    def update_status(self, workflow_id: str, status: str, current_node: str = None) -> bool:
        wf = self.get_by_id(workflow_id)
        if not wf:
            return False
        wf.status = status
        if current_node:
            wf.current_node = current_node
            history = wf.node_history or []
            history.append(current_node)
            wf.node_history = history
        wf.updated_at = datetime.now()
        self.session.commit()
        return True

    def list_all(self, limit: int = 1000) -> List[TradeWorkflow]:
        return self.session.query(TradeWorkflow).order_by(desc(TradeWorkflow.created_at)).limit(limit).all()


class AgentLogRepository(BaseRepository):
    """Agent执行日志Repository"""

    def create(self, data: Dict[str, Any]) -> AgentExecutionLog:
        log = AgentExecutionLog(**data)
        self.session.add(log)
        self.session.commit()
        return log

    def get_by_task(self, task_id: str, limit: int = 1000) -> List[AgentExecutionLog]:
        return self.session.query(AgentExecutionLog).filter_by(task_id=task_id).order_by(AgentExecutionLog.timestamp).limit(limit).all()

    def get_by_agent(self, agent_id: str, limit: int = 1000) -> List[AgentExecutionLog]:
        return self.session.query(AgentExecutionLog).filter_by(agent_id=agent_id).order_by(desc(AgentExecutionLog.timestamp)).limit(limit).all()

    def get_failures(self, limit: int = 100) -> List[AgentExecutionLog]:
        return self.session.query(AgentExecutionLog).filter_by(status="failed").order_by(desc(AgentExecutionLog.timestamp)).limit(limit).all()


# 统一数据服务
class TradeDataService:
    """外贸数据服务 - 统一入口"""

    def __init__(self):
        self.company_repo = CompanyRepository()
        self.customer_repo = CustomerPoolRepository()
        self.task_repo = TaskRepository()
        self.opportunity_repo = OpportunityRepository()
        self.workflow_repo = WorkflowRepository()
        self.agent_log_repo = AgentLogRepository()

    def save_task_result(self, task_id: str, workflow_id: str, result: Dict[str, Any]) -> bool:
        """保存任务完整结果到数据库"""
        try:
            # 保存企业
            for company_data in result.get("companies", []):
                self.company_repo.create(company_data)

            # 保存客户池
            for lead in result.get("scored_leads", []):
                customer_data = {
                    "company_id": lead.get("company_id", ""),
                    "company_name": lead.get("name", ""),
                    "customer_level": lead.get("lead_grade", "C"),
                    "customer_value": lead.get("scores", {}).get("overall_score", 0) * 100,
                    "match_degree": lead.get("scores", {}).get("match_degree", 0),
                    "deal_probability": lead.get("scores", {}).get("deal_probability", 0),
                    "development_priority": int(lead.get("scores", {}).get("overall_score", 0) * 10),
                    "tags": [lead.get("industry", ""), lead.get("company_size", "")],
                }
                self.customer_repo.create(customer_data)

            # 保存商业机会
            for strategy in result.get("strategies", []):
                if strategy.get("lead_grade") == "A":
                    opp_data = {
                        "customer_id": strategy.get("company_id", ""),
                        "title": f"{strategy.get('company', '')} - Partnership Opportunity",
                        "description": strategy.get("initial_offer", ""),
                        "estimated_value": 50000.0,
                        "probability": strategy.get("overall_score", 0),
                        "stage": "prospecting",
                    }
                    self.opportunity_repo.create(opp_data)

            # 更新任务状态
            self.task_repo.update_status(task_id, "completed", str(result.get("report", {}))[:500])

            # 更新工作流状态
            self.workflow_repo.update_status(workflow_id, "completed")

            return True
        except Exception as e:
            self.company_repo.rollback()
            return False

    def get_dashboard_data(self) -> Dict[str, Any]:
        """获取仪表盘数据"""
        return {
            "total_companies": self.company_repo.count(),
            "total_customers": len(self.customer_repo.list_all()),
            "total_opportunities": len(self.opportunity_repo.list_all()),
            "total_tasks": len(self.task_repo.list_all()),
            "customer_status": self.customer_repo.count_by_status(),
            "recent_tasks": [{
                "task_id": t.task_id,
                "objective": t.objective,
                "status": t.status,
                "created_at": t.created_at.isoformat() if t.created_at else "",
            } for t in self.task_repo.list_all(10)],
            "high_value_opportunities": [{
                "opportunity_id": o.opportunity_id,
                "title": o.title,
                "estimated_value": o.estimated_value,
                "probability": o.probability,
                "stage": o.stage,
            } for o in self.opportunity_repo.get_high_value()],
        }
