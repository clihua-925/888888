"""
Database Models - 外贸业务数据库模型
"""
from sqlalchemy import create_engine, Column, String, Float, Integer, DateTime, Text, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import uuid

Base = declarative_base()


class TradeCompany(Base):
    """贸易企业表"""
    __tablename__ = "trade_company"

    company_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False)
    country = Column(String(100))
    website = Column(String(500))
    industry = Column(String(200))
    main_products = Column(JSON)
    procurement_direction = Column(JSON)
    company_size = Column(String(50))
    supply_chain_relations = Column(JSON)
    contacts = Column(JSON)
    contact_info = Column(JSON)
    credibility_score = Column(Float, default=0.0)
    procurement_probability = Column(Float, default=0.0)
    match_score = Column(Float, default=0.0)
    source = Column(String(200))
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class TradeContact(Base):
    """贸易联系人表"""
    __tablename__ = "trade_contact"

    contact_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    company_id = Column(String(64), ForeignKey("trade_company.company_id"))
    name = Column(String(200))
    title = Column(String(200))
    email = Column(String(300))
    phone = Column(String(100))
    linkedin = Column(String(500))
    department = Column(String(200))
    is_decision_maker = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)


class TradeProduct(Base):
    """贸易产品表"""
    __tablename__ = "trade_product"

    product_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False)
    category = Column(String(200))
    description = Column(Text)
    target_markets = Column(JSON)
    keywords = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)


class TradeMarket(Base):
    """贸易市场表"""
    __tablename__ = "trade_market"

    market_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    country = Column(String(100), nullable=False)
    region = Column(String(100))
    market_size = Column(String(100))
    growth_rate = Column(Float)
    competition_level = Column(String(50))
    entry_barrier = Column(Text)
    analysis_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)


class TradeCustomerPool(Base):
    """客户池表"""
    __tablename__ = "trade_customer_pool"

    customer_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    company_id = Column(String(64), ForeignKey("trade_company.company_id"))
    company_name = Column(String(255))
    customer_level = Column(String(10), default="C")
    customer_value = Column(Float, default=0.0)
    match_degree = Column(Float, default=0.0)
    deal_probability = Column(Float, default=0.0)
    development_priority = Column(Integer, default=0)
    follow_up_status = Column(String(50), default="new")
    last_contact = Column(DateTime)
    notes = Column(JSON)
    tags = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class TradeOpportunity(Base):
    """商业机会表"""
    __tablename__ = "trade_opportunity"

    opportunity_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    customer_id = Column(String(64), ForeignKey("trade_customer_pool.customer_id"))
    title = Column(String(500))
    description = Column(Text)
    estimated_value = Column(Float)
    probability = Column(Float)
    stage = Column(String(50))
    expected_close_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class TradeTask(Base):
    """任务表"""
    __tablename__ = "trade_task"

    task_id = Column(String(64), primary_key=True)
    objective = Column(Text, nullable=False)
    product = Column(String(255))
    market = Column(String(200))
    target_customer = Column(String(200))
    status = Column(String(50), default="pending")
    priority = Column(Integer, default=2)
    workflow = Column(JSON)
    result_summary = Column(Text)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class TradeWorkflow(Base):
    """工作流表"""
    __tablename__ = "trade_workflow"

    workflow_id = Column(String(64), primary_key=True)
    task_id = Column(String(64), ForeignKey("trade_task.task_id"))
    current_node = Column(String(100))
    node_history = Column(JSON)
    status = Column(String(50), default="running")
    data = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class AgentExecutionLog(Base):
    """Agent执行日志表"""
    __tablename__ = "agent_execution_log"

    log_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id = Column(String(64))
    workflow_id = Column(String(64))
    agent_id = Column(String(100))
    input_data = Column(JSON)
    output_data = Column(JSON)
    tool_call = Column(String(200))
    duration_ms = Column(Integer)
    status = Column(String(50))
    error = Column(Text)
    timestamp = Column(DateTime, default=datetime.now)


class AuditEvent(Base):
    """审计事件表"""
    __tablename__ = "audit_event"

    event_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id = Column(String(64))
    workflow_id = Column(String(64))
    agent_id = Column(String(100))
    event_type = Column(String(100))
    payload = Column(JSON)
    timestamp = Column(DateTime, default=datetime.now)


class MemoryStore(Base):
    """记忆存储表"""
    __tablename__ = "memory_store"

    memory_id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    memory_type = Column(String(50))
    task_id = Column(String(64))
    agent_id = Column(String(100))
    content = Column(JSON)
    importance = Column(Float, default=0.5)
    access_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


def init_db(database_url: str = "sqlite:///psv_trade_os.db"):
    """初始化数据库"""
    engine = create_engine(database_url)
    Base.metadata.create_all(engine)
    return engine


def get_session(engine):
    """获取数据库会话"""
    Session = sessionmaker(bind=engine)
    return Session()
