"""
Contract Validator - 契约验证器
确保所有模块间的数据交换符合契约规范
"""
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass


class ValidationError(Exception):
    """验证错误"""
    pass


class ContractValidator:
    """契约验证器"""

    @staticmethod
    def validate_task_contract(data: Dict[str, Any]) -> List[str]:
        """验证任务契约"""
        errors = []
        required = ["task_id", "objective"]
        for field in required:
            if field not in data or not data[field]:
                errors.append(f"Missing required field: {field}")

        if "workflow" in data and not isinstance(data["workflow"], list):
            errors.append("Field 'workflow' must be a list")

        if "priority" in data:
            if not isinstance(data["priority"], int) or not 1 <= data["priority"] <= 4:
                errors.append("Field 'priority' must be an integer between 1 and 4")

        return errors

    @staticmethod
    def validate_agent_request(data: Dict[str, Any]) -> List[str]:
        """验证Agent请求"""
        errors = []
        required = ["request_id", "task_id", "agent_name", "input_data"]
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")

        if "input_data" in data and not isinstance(data["input_data"], dict):
            errors.append("Field 'input_data' must be a dict")

        return errors

    @staticmethod
    def validate_agent_response(data: Dict[str, Any]) -> List[str]:
        """验证Agent响应"""
        errors = []
        required = ["response_id", "request_id", "task_id", "agent_name", "result", "status"]
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")

        if "confidence" in data:
            if not isinstance(data["confidence"], (int, float)) or not 0 <= data["confidence"] <= 1:
                errors.append("Field 'confidence' must be a float between 0 and 1")

        if "status" in data and data["status"] not in ["idle", "running", "success", "failed", "waiting"]:
            errors.append("Field 'status' must be one of: idle, running, success, failed, waiting")

        return errors

    @staticmethod
    def validate_and_raise(data: Dict[str, Any], validator: Callable) -> None:
        """验证并抛出异常"""
        errors = validator(data)
        if errors:
            raise ValidationError(f"Contract validation failed: {'; '.join(errors)}")
