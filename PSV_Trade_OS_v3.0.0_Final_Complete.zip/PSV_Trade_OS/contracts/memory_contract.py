"""
Memory Contract - 记忆存储契约
统一短期和长期记忆的存储格式
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
import uuid
from datetime import datetime


class MemoryType(Enum):
    SHORT_TERM = "short_term"    # 当前任务状态
    LONG_TERM = "long_term"      # 历史任务、行业知识
    EPISODIC = "episodic"        # 执行经验
    SEMANTIC = "semantic"        # 产品/市场知识


@dataclass
class MemoryContract:
    """记忆存储契约"""
    memory_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    memory_type: MemoryType = MemoryType.SHORT_TERM
    task_id: str = ""
    agent_id: str = ""
    content: Dict[str, Any] = field(default_factory=dict)
    importance: float = 0.5  # 0.0 - 1.0
    access_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id": self.memory_id,
            "memory_type": self.memory_type.value,
            "task_id": self.task_id,
            "agent_id": self.agent_id,
            "content": self.content,
            "importance": self.importance,
            "access_count": self.access_count,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
