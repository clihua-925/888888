"""
Tool Contract - 工具调用契约
所有外部工具（搜索、采集、分析等）必须通过此契约调用
"""
from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from enum import Enum
import uuid
from datetime import datetime


class ToolType(Enum):
    SEARCH = "search"
    SCRAPER = "scraper"
    ANALYZER = "analyzer"
    ENRICHER = "enricher"
    SCORER = "scorer"
    REPORTER = "reporter"


@dataclass
class ToolContract:
    """工具调用契约"""
    tool_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tool_name: str = ""
    tool_type: ToolType = ToolType.SEARCH
    parameters: Dict[str, Any] = field(default_factory=dict)
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    duration_ms: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_id": self.tool_id,
            "tool_name": self.tool_name,
            "tool_type": self.tool_type.value,
            "parameters": self.parameters,
            "result": self.result,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "timestamp": self.timestamp,
        }
