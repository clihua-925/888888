"""
Event Contract - 事件通知契约
用于模块间异步事件通信
"""
from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from enum import Enum
import uuid
from datetime import datetime


class EventType(Enum):
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    AGENT_CALLED = "agent_called"
    AGENT_FINISHED = "agent_finished"
    AGENT_ERROR = "agent_error"
    DATA_PRODUCED = "data_produced"
    CHECKPOINT_SAVED = "checkpoint_saved"
    RECOVERY_TRIGGERED = "recovery_triggered"


@dataclass
class EventContract:
    """事件契约"""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: EventType = EventType.TASK_STARTED
    task_id: str = ""
    agent_id: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "task_id": self.task_id,
            "agent_id": self.agent_id,
            "payload": self.payload,
            "timestamp": self.timestamp,
        }
