"""
Task Contract - 统一任务格式定义
所有外贸任务必须通过此契约进行描述和传递
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
import uuid
from datetime import datetime


class TaskStatus(Enum):
    PENDING = "pending"
    PLANNING = "planning"
    EXECUTING = "executing"
    VALIDATING = "validating"
    COMPLETED = "completed"
    FAILED = "failed"
    RECOVERING = "recovering"


class TaskPriority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class TaskContract:
    """统一任务契约"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    objective: str = ""  # 任务目标，例如："开发美国生日蜡烛进口商"
    product: str = ""    # 产品
    market: str = ""     # 目标市场/国家
    target_customer: str = ""  # 目标客户类型
    constraints: Dict[str, Any] = field(default_factory=dict)  # 约束条件
    workflow: List[str] = field(default_factory=list)  # 执行工作流步骤
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority = TaskPriority.MEDIUM
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "objective": self.objective,
            "product": self.product,
            "market": self.market,
            "target_customer": self.target_customer,
            "constraints": self.constraints,
            "workflow": self.workflow,
            "status": self.status.value,
            "priority": self.priority.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TaskContract":
        return cls(
            task_id=data.get("task_id", str(uuid.uuid4())),
            objective=data.get("objective", ""),
            product=data.get("product", ""),
            market=data.get("market", ""),
            target_customer=data.get("target_customer", ""),
            constraints=data.get("constraints", {}),
            workflow=data.get("workflow", []),
            status=TaskStatus(data.get("status", "pending")),
            priority=TaskPriority(data.get("priority", 2)),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
            metadata=data.get("metadata", {}),
        )
