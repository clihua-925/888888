"""
Data Contract - 数据交换契约
统一所有模块间的数据交换格式
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
import uuid
from datetime import datetime


class DataType(Enum):
    COMPANY = "company"
    CONTACT = "contact"
    PRODUCT = "product"
    MARKET = "market"
    OPPORTUNITY = "opportunity"
    REPORT = "report"
    ANALYSIS = "analysis"


@dataclass
class DataContract:
    """数据交换契约"""
    data_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    data_type: DataType = DataType.COMPANY
    payload: Dict[str, Any] = field(default_factory=dict)
    source_agent: str = ""
    target_agent: str = ""
    version: str = "1.0"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "data_id": self.data_id,
            "data_type": self.data_type.value,
            "payload": self.payload,
            "source_agent": self.source_agent,
            "target_agent": self.target_agent,
            "version": self.version,
            "timestamp": self.timestamp,
        }
