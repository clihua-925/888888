"""
Agent Contract - 所有Agent的输入输出契约
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
import uuid
from datetime import datetime


class AgentStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    WAITING = "waiting"


@dataclass
class AgentRequest:
    """Agent输入请求"""
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str = ""
    agent_name: str = ""
    input_data: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    parameters: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "task_id": self.task_id,
            "agent_name": self.agent_name,
            "input_data": self.input_data,
            "context": self.context,
            "parameters": self.parameters,
            "timestamp": self.timestamp,
        }


@dataclass
class AgentResponse:
    """Agent输出响应 - 必须包含完整元数据"""
    response_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    request_id: str = ""
    task_id: str = ""
    agent_name: str = ""
    result: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0  # 0.0 - 1.0
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    next_action: Optional[str] = None
    status: AgentStatus = AgentStatus.IDLE
    error: Optional[str] = None
    duration_ms: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "response_id": self.response_id,
            "request_id": self.request_id,
            "task_id": self.task_id,
            "agent_name": self.agent_name,
            "result": self.result,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "next_action": self.next_action,
            "status": self.status.value,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentResponse":
        return cls(
            response_id=data.get("response_id", str(uuid.uuid4())),
            request_id=data.get("request_id", ""),
            task_id=data.get("task_id", ""),
            agent_name=data.get("agent_name", ""),
            result=data.get("result", {}),
            confidence=data.get("confidence", 0.0),
            evidence=data.get("evidence", []),
            next_action=data.get("next_action"),
            status=AgentStatus(data.get("status", "idle")),
            error=data.get("error"),
            duration_ms=data.get("duration_ms", 0),
            timestamp=data.get("timestamp", datetime.now().isoformat()),
        )
