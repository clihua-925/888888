"""
Orchestrator State - LangGraph 核心状态定义
"""
from typing import Dict, Any, List, Optional, TypedDict, Annotated
from dataclasses import dataclass, field
import operator


class TradeGraphState(TypedDict):
    """贸易智能图状态 - 贯穿整个Workflow"""
    task_id: str
    workflow_id: str
    objective: str
    product: str
    market: str
    target_customer: str
    plan: List[Dict[str, Any]]
    current_step: int
    current_agent: str
    agent_results: Annotated[List[Dict[str, Any]], operator.add]
    company_pool: List[Dict[str, Any]]
    enriched_companies: List[Dict[str, Any]]
    scored_leads: List[Dict[str, Any]]
    strategy: Dict[str, Any]
    report: Dict[str, Any]
    errors: Annotated[List[str], operator.add]
    status: str
    checkpoint_id: Optional[str]
    recovery_attempt: int
    metadata: Dict[str, Any]
