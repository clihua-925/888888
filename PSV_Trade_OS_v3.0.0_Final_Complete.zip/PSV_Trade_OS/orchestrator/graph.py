"""
Graph - LangGraph 主图定义
PSV Trade Intelligence OS 核心运行引擎
"""
from typing import Dict, Any
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from orchestrator.state import TradeGraphState
from orchestrator.planner import TradePlanner
from orchestrator.supervisor import SupervisorAgent
from orchestrator.router import Router
from orchestrator.checkpoint import CheckpointManager
from orchestrator.recovery import RecoveryManager


class TradeOrchestrator:
    """贸易智能编排器 - LangGraph核心"""

    def __init__(self):
        self.planner = TradePlanner()
        self.supervisor = SupervisorAgent()
        self.router = Router()
        self.checkpoint_mgr = CheckpointManager()
        self.recovery_mgr = RecoveryManager()
        self.graph = None
        self._build_graph()

    def _build_graph(self):
        """构建LangGraph工作流图"""
        workflow = StateGraph(TradeGraphState)

        workflow.add_node("planner", self._node_planner)
        workflow.add_node("supervisor", self._node_supervisor)
        workflow.add_node("market_research", self._node_market_research)
        workflow.add_node("company_discovery", self._node_company_discovery)
        workflow.add_node("company_enrichment", self._node_company_enrichment)
        workflow.add_node("contact_discovery", self._node_contact_discovery)
        workflow.add_node("lead_scoring", self._node_lead_scoring)
        workflow.add_node("sales_strategy", self._node_sales_strategy)
        workflow.add_node("report", self._node_report)
        workflow.add_node("checkpoint", self._node_checkpoint)
        workflow.add_node("recovery", self._node_recovery)

        workflow.set_entry_point("planner")

        workflow.add_conditional_edges(
            "planner",
            self._route_from_planner,
            {
                "supervisor": "supervisor",
                "end": END,
            }
        )

        workflow.add_conditional_edges(
            "supervisor",
            self._route_from_supervisor,
            {
                "market_research": "market_research",
                "company_discovery": "company_discovery",
                "company_enrichment": "company_enrichment",
                "contact_discovery": "contact_discovery",
                "lead_scoring": "lead_scoring",
                "sales_strategy": "sales_strategy",
                "report": "report",
                "checkpoint": "checkpoint",
                "recovery": "recovery",
                "end": END,
            }
        )

        for node in ["market_research", "company_discovery", "company_enrichment",
                     "contact_discovery", "lead_scoring", "sales_strategy", "report"]:
            workflow.add_edge(node, "supervisor")

        workflow.add_edge("checkpoint", "supervisor")
        workflow.add_edge("recovery", "supervisor")

        self.graph = workflow.compile(checkpointer=MemorySaver())

    def _node_planner(self, state: TradeGraphState) -> TradeGraphState:
        from contracts.task_contract import TaskContract

        task = TaskContract(
            task_id=state["task_id"],
            objective=state["objective"],
            product=state["product"],
            market=state["market"],
            target_customer=state["target_customer"],
        )

        response = self.planner.plan(task)

        state["plan"] = response.result.get("workflow", [])
        state["status"] = "planning"
        state["current_step"] = 0
        state["metadata"]["plan_generated"] = True

        return state

    def _node_supervisor(self, state: TradeGraphState) -> TradeGraphState:
        if state.get("status") == "recovering":
            result = self.supervisor.supervise(state["task_id"], state["workflow_id"])
            state["status"] = result.get("status", "executing")
        elif state.get("status") in ["planning", "executing"]:
            result = self.supervisor.supervise(state["task_id"], state["workflow_id"])
            state["status"] = result.get("status", "executing")
            if result.get("status") == "completed":
                state["status"] = "completed"

        return state

    def _node_market_research(self, state: TradeGraphState) -> TradeGraphState:
        state["current_agent"] = "MarketResearchAgent"
        state["current_step"] = state.get("current_step", 0) + 1
        return state

    def _node_company_discovery(self, state: TradeGraphState) -> TradeGraphState:
        state["current_agent"] = "CompanyDiscoveryAgent"
        state["current_step"] = state.get("current_step", 0) + 1
        return state

    def _node_company_enrichment(self, state: TradeGraphState) -> TradeGraphState:
        state["current_agent"] = "CompanyEnrichmentAgent"
        state["current_step"] = state.get("current_step", 0) + 1
        return state

    def _node_contact_discovery(self, state: TradeGraphState) -> TradeGraphState:
        state["current_agent"] = "ContactDiscoveryAgent"
        state["current_step"] = state.get("current_step", 0) + 1
        return state

    def _node_lead_scoring(self, state: TradeGraphState) -> TradeGraphState:
        state["current_agent"] = "LeadScoringAgent"
        state["current_step"] = state.get("current_step", 0) + 1
        return state

    def _node_sales_strategy(self, state: TradeGraphState) -> TradeGraphState:
        state["current_agent"] = "SalesStrategyAgent"
        state["current_step"] = state.get("current_step", 0) + 1
        return state

    def _node_report(self, state: TradeGraphState) -> TradeGraphState:
        state["current_agent"] = "ReportAgent"
        state["status"] = "completed"
        return state

    def _node_checkpoint(self, state: TradeGraphState) -> TradeGraphState:
        cp_id = self.checkpoint_mgr.save(state["workflow_id"], state)
        state["checkpoint_id"] = cp_id
        return state

    def _node_recovery(self, state: TradeGraphState) -> TradeGraphState:
        recovered = self.recovery_mgr.recover(state["workflow_id"])
        if recovered:
            state.update(recovered)
        return state

    def _route_from_planner(self, state: TradeGraphState) -> str:
        if state.get("plan"):
            return "supervisor"
        return "end"

    def _route_from_supervisor(self, state: TradeGraphState) -> str:
        if state.get("status") == "completed":
            return "end"
        if state.get("status") == "failed":
            if self.recovery_mgr.can_recover(state["workflow_id"]):
                return "recovery"
            return "end"
        if self.router.should_checkpoint(state):
            return "checkpoint"
        return self.router.route(state)

    def run(self, objective: str, product: str, market: str, 
            target_customer: str = "", config: Dict[str, Any] = None) -> Dict[str, Any]:
        import uuid
        import time

        task_id = f"TASK_{int(time.time())}"
        workflow_id = f"WF_{uuid.uuid4().hex[:8]}"

        initial_state: TradeGraphState = {
            "task_id": task_id,
            "workflow_id": workflow_id,
            "objective": objective,
            "product": product,
            "market": market,
            "target_customer": target_customer,
            "plan": [],
            "current_step": 0,
            "current_agent": "",
            "agent_results": [],
            "company_pool": [],
            "enriched_companies": [],
            "scored_leads": [],
            "strategy": {},
            "report": {},
            "errors": [],
            "status": "pending",
            "checkpoint_id": None,
            "recovery_attempt": 0,
            "metadata": {},
        }

        result = self.graph.invoke(initial_state, config=config)
        return {
            "task_id": task_id,
            "workflow_id": workflow_id,
            "status": result.get("status"),
            "report": result.get("report"),
            "total_steps": result.get("current_step"),
        }
