"""
Recovery - 恢复机制
任务中断后恢复执行
"""
from typing import Dict, Any, Optional
from orchestrator.state import TradeGraphState
from shared.state.manager import get_state_manager
from shared.memory.short_term import get_short_term_memory
from audit.logger import get_audit_logger


class RecoveryManager:
    """恢复管理器"""

    def __init__(self):
        self.state_mgr = get_state_manager()
        self.stm = get_short_term_memory()
        self.audit = get_audit_logger()
        self.max_attempts = 3

    def can_recover(self, workflow_id: str) -> bool:
        """判断是否可以恢复"""
        state = self.state_mgr.get_state(workflow_id)
        if not state:
            return False
        return state.status in ["paused", "failed"] and state.data.get("recovery_attempt", 0) < self.max_attempts

    def recover(self, workflow_id: str) -> Optional[TradeGraphState]:
        """恢复工作流到中断点"""
        state = self.state_mgr.get_state(workflow_id)
        if not state:
            return None

        recovery_attempt = state.data.get("recovery_attempt", 0) + 1
        state.data["recovery_attempt"] = recovery_attempt

        state.status = "running"
        self.state_mgr._save_checkpoint(state)

        graph_state = state.data.get("graph_state", {})
        graph_state["status"] = "recovering"
        graph_state["recovery_attempt"] = recovery_attempt
        graph_state["workflow_id"] = workflow_id

        self.audit.log(
            task_id=state.task_id,
            workflow_id=workflow_id,
            agent_id="RecoveryManager",
            input_data={"action": "recover", "from_node": state.current_node},
            output_data={"status": "recovered", "attempt": recovery_attempt},
            status="success",
        )

        return graph_state

    def get_recovery_point(self, workflow_id: str) -> Dict[str, Any]:
        """获取恢复点信息"""
        state = self.state_mgr.get_state(workflow_id)
        if not state:
            return {}

        return {
            "workflow_id": workflow_id,
            "task_id": state.task_id,
            "last_node": state.current_node,
            "last_step": state.data.get("current_step", 0),
            "recovery_attempt": state.data.get("recovery_attempt", 0),
            "timestamp": state.updated_at,
        }
