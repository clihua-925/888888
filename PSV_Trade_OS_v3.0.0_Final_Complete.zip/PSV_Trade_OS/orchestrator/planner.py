"""
Trade Planner Agent - 任务规划器
理解外贸目标，生成执行计划
"""
from typing import Dict, Any, List
from contracts.task_contract import TaskContract, TaskStatus
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.memory.short_term import get_short_term_memory
import time


class TradePlanner:
    """贸易任务规划器"""

    def __init__(self):
        self.name = "TradePlanner"
        self.stm = get_short_term_memory()

    def plan(self, task: TaskContract) -> AgentResponse:
        """根据外贸目标生成执行计划"""
        start_time = time.time()

        objective = task.objective
        product = task.product
        market = task.market
        customer_type = task.target_customer

        workflow = [
            {"agent": "MarketResearchAgent", "action": "analyze_market", "input": {"product": product, "market": market}},
            {"agent": "CompanyDiscoveryAgent", "action": "discover_companies", "input": {"product": product, "market": market, "customer_type": customer_type}},
            {"agent": "CompanyEnrichmentAgent", "action": "enrich_companies", "input": {"companies": "$prev.result"}},
            {"agent": "ContactDiscoveryAgent", "action": "find_contacts", "input": {"companies": "$prev.result"}},
            {"agent": "LeadScoringAgent", "action": "score_leads", "input": {"leads": "$prev.result"}},
            {"agent": "SalesStrategyAgent", "action": "generate_strategy", "input": {"scored_leads": "$prev.result"}},
            {"agent": "ReportAgent", "action": "generate_report", "input": {"all_data": "$all"}},
        ]

        plan_result = {
            "task_id": task.task_id,
            "objective": objective,
            "workflow": workflow,
            "estimated_steps": len(workflow),
            "constraints": task.constraints,
        }

        self.stm.set(task.task_id, "plan", plan_result)

        duration = int((time.time() - start_time) * 1000)

        return AgentResponse(
            request_id="",
            task_id=task.task_id,
            agent_name=self.name,
            result=plan_result,
            confidence=0.95,
            evidence=[{"type": "plan_generated", "detail": f"Generated {len(workflow)} step workflow"}],
            next_action="SupervisorAgent",
            status=AgentStatus.SUCCESS,
            duration_ms=duration,
        )

    def replan(self, task_id: str, failure_reason: str, current_state: Dict[str, Any]) -> AgentResponse:
        """失败时重新规划"""
        original_plan = self.stm.get(task_id, "plan")

        recovery_plan = {
            "recovery_from": failure_reason,
            "skip_completed": True,
            "resume_from": current_state.get("current_agent", "MarketResearchAgent"),
            "workflow": original_plan.get("workflow", []) if original_plan else [],
        }

        return AgentResponse(
            request_id="",
            task_id=task_id,
            agent_name=self.name,
            result=recovery_plan,
            confidence=0.8,
            evidence=[{"type": "replan", "detail": f"Recovery from: {failure_reason}"}],
            next_action="SupervisorAgent",
            status=AgentStatus.SUCCESS,
        )
