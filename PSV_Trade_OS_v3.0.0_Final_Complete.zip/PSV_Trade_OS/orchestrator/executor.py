"""
Executor - Agent执行器
统一封装Agent调用，处理输入输出、异常、超时
"""
from typing import Dict, Any
import time
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from audit.logger import get_audit_logger


class AgentExecutor:
    """Agent执行器"""

    def __init__(self, timeout: int = 300):
        self.timeout = timeout
        self.audit = get_audit_logger()

    def execute(self, agent, request: AgentRequest) -> AgentResponse:
        """执行Agent并处理异常"""
        start = time.time()

        try:
            if hasattr(agent, 'execute'):
                response = agent.execute(request)
            elif hasattr(agent, 'run'):
                response = agent.run(request)
            else:
                raise ValueError(f"Agent {request.agent_name} has no execute/run method")

            duration = int((time.time() - start) * 1000)
            response.duration_ms = duration

            if not isinstance(response, AgentResponse):
                raise TypeError("Agent must return AgentResponse")

            return response

        except Exception as e:
            duration = int((time.time() - start) * 1000)
            return AgentResponse(
                request_id=request.request_id,
                task_id=request.task_id,
                agent_name=request.agent_name,
                result={},
                confidence=0.0,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=duration,
            )
