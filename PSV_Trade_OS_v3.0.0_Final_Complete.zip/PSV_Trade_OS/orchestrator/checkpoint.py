"""
Checkpoint - 检查点管理
支持任务中断后的状态保存
"""
from typing import Dict, Any, Optional
from orchestrator.state import TradeGraphState
from shared.state.manager import get_state_manager
import time


class CheckpointManager:
    """检查点管理器"""

    def __init__(self):
        self.state_mgr = get_state_manager()

    def save(self, workflow_id: str, state: TradeGraphState) -> str:
        """保存工作流检查点"""
        checkpoint_id = f"cp_{workflow_id}_{time.time()}"

        self.state_mgr.update_state(
            workflow_id,
            state.get("current_agent", "unknown"),
            {
                "checkpoint_id": checkpoint_id,
                "graph_state": dict(state),
                "current_step": state.get("current_step", 0),
            }
        )

        return checkpoint_id

    def load(self, workflow_id: str) -> Optional[TradeGraphState]:
        """加载最新检查点"""
        state = self.state_mgr.get_state(workflow_id)
        if not state or not state.data.get("graph_state"):
            return None

        return state.data["graph_state"]

    def list_available(self, task_id: str = None) -> list:
        """列出所有可用检查点"""
        checkpoints = self.state_mgr.list_checkpoints()
        if task_id:
            return [cp for cp in checkpoints if cp.startswith(task_id)]
        return checkpoints
