"""
Router - 工作流节点路由器
决定下一个执行哪个Agent
"""
from typing import Dict, Any, Literal
from orchestrator.state import TradeGraphState


class Router:
    """工作流路由器"""

    def __init__(self):
        self.name = "Router"

    def route(self, state: TradeGraphState) -> Literal[
        "planner", "supervisor", "market_research", "company_discovery",
        "company_enrichment", "contact_discovery", "lead_scoring",
        "sales_strategy", "report", "checkpoint", "recovery", "end"
    ]:
        """根据当前状态决定下一个节点"""
        current_status = state.get("status", "pending")

        if current_status == "failed":
            if state.get("recovery_attempt", 0) < 3:
                return "recovery"
            return "end"

        if current_status == "recovering":
            return "supervisor"

        if current_status == "completed":
            return "end"

        current_agent = state.get("current_agent", "")
        plan = state.get("plan", [])
        current_step = state.get("current_step", 0)

        if not plan:
            return "planner"

        if current_step >= len(plan):
            return "report"

        next_agent = plan[current_step].get("agent", "")

        agent_map = {
            "MarketResearchAgent": "market_research",
            "CompanyDiscoveryAgent": "company_discovery",
            "CompanyEnrichmentAgent": "company_enrichment",
            "ContactDiscoveryAgent": "contact_discovery",
            "LeadScoringAgent": "lead_scoring",
            "SalesStrategyAgent": "sales_strategy",
            "ReportAgent": "report",
        }

        return agent_map.get(next_agent, "supervisor")

    def should_checkpoint(self, state: TradeGraphState) -> bool:
        """判断是否应该保存检查点"""
        current_step = state.get("current_step", 0)
        return current_step > 0 and current_step % 2 == 0
