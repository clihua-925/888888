"""
Supervisor Agent - 监督器
负责任务调度、Agent调用顺序控制、结果验证
"""
from typing import Dict, Any, List, Optional
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.memory.short_term import get_short_term_memory
from shared.state.manager import get_state_manager
from audit.logger import get_audit_logger
from database.repository import TradeDataService
from business.services.trade_graph import get_trade_graph
import time


class SupervisorAgent:
    """监督器 - 控制整个Agent工作流执行"""

    def __init__(self):
        self.name = "SupervisorAgent"
        self.stm = get_short_term_memory()
        self.state_mgr = get_state_manager()
        self.audit = get_audit_logger()
        self.data_service = TradeDataService()
        self.trade_graph = get_trade_graph()
        self.agents = {}
        self._register_default_agents()

    def _register_default_agents(self):
        """注册所有业务Agent"""
        from agents.market_research import MarketResearchAgent
        from agents.company_discovery import CompanyDiscoveryAgent
        from agents.company_enrichment import CompanyEnrichmentAgent
        from agents.contact_discovery import ContactDiscoveryAgent
        from agents.lead_scoring import LeadScoringAgent
        from agents.sales_strategy import SalesStrategyAgent
        from agents.report import ReportAgent

        self.register_agent("MarketResearchAgent", MarketResearchAgent())
        self.register_agent("CompanyDiscoveryAgent", CompanyDiscoveryAgent())
        self.register_agent("CompanyEnrichmentAgent", CompanyEnrichmentAgent())
        self.register_agent("ContactDiscoveryAgent", ContactDiscoveryAgent())
        self.register_agent("LeadScoringAgent", LeadScoringAgent())
        self.register_agent("SalesStrategyAgent", SalesStrategyAgent())
        self.register_agent("ReportAgent", ReportAgent())

    def register_agent(self, name: str, agent_instance):
        """注册业务Agent"""
        self.agents[name] = agent_instance

    def supervise(self, task_id: str, workflow_id: str) -> Dict[str, Any]:
        """监督执行完整工作流"""
        plan = self.stm.get(task_id, "plan")
        if not plan:
            return {"status": "failed", "error": "No plan found"}

        workflow = plan.get("workflow", [])
        current_step = 0

        self.state_mgr.update_state(workflow_id, "SupervisorAgent", {"status": "executing"})

        all_results = {}

        while current_step < len(workflow):
            step = workflow[current_step]
            agent_name = step["agent"]
            action = step["action"]

            state = self.state_mgr.get_state(workflow_id)
            if state and state.data.get("resume_step"):
                current_step = state.data["resume_step"]
                del state.data["resume_step"]

            agent = self.agents.get(agent_name)
            if not agent:
                error = f"Agent {agent_name} not registered"
                self.audit.log(
                    task_id=task_id,
                    workflow_id=workflow_id,
                    agent_id=agent_name,
                    input_data=step,
                    output_data={},
                    status="failed",
                    error=error,
                )
                return {"status": "failed", "error": error}

            # 构建请求，注入前置Agent的结果
            input_data = dict(step.get("input", {}))
            if "$prev.result" in str(input_data):
                # 替换变量引用
                prev_agent = workflow[current_step - 1]["agent"] if current_step > 0 else ""
                prev_result = self.stm.get(task_id, f"result_{prev_agent}")
                if prev_result:
                    input_data = self._resolve_variables(input_data, prev_result, all_results)

            request = AgentRequest(
                task_id=task_id,
                agent_name=agent_name,
                input_data=input_data,
                context={"step": current_step, "total": len(workflow), "workflow_id": workflow_id},
            )

            start = time.time()
            try:
                response = agent.execute(request)
                duration = int((time.time() - start) * 1000)

                self.audit.log(
                    task_id=task_id,
                    workflow_id=workflow_id,
                    agent_id=agent_name,
                    input_data=request.to_dict(),
                    output_data=response.to_dict(),
                    tool_call=action,
                    duration_ms=duration,
                    status="success" if response.status == AgentStatus.SUCCESS else "failed",
                    error=response.error,
                )

                self.stm.set(task_id, f"result_{agent_name}", response.result)
                all_results[agent_name] = response.result

                self.state_mgr.update_state(
                    workflow_id, 
                    agent_name, 
                    {"step": current_step, "result_summary": str(response.result)[:200]}
                )

                if response.status == AgentStatus.FAILED:
                    if state and state.data.get("recovery_attempt", 0) < 3:
                        return {"status": "recovering", "failed_at": agent_name, "step": current_step}
                    else:
                        return {"status": "failed", "error": response.error}

                current_step += 1

            except Exception as e:
                duration = int((time.time() - start) * 1000)
                self.audit.log(
                    task_id=task_id,
                    workflow_id=workflow_id,
                    agent_id=agent_name,
                    input_data=request.to_dict(),
                    output_data={},
                    status="failed",
                    error=str(e),
                    duration_ms=duration,
                )
                return {"status": "failed", "error": str(e), "step": current_step}

        # 工作流完成，构建Trade Graph并持久化
        self._finalize_task(task_id, workflow_id, all_results)

        self.state_mgr.complete_state(workflow_id)
        return {"status": "completed", "total_steps": current_step}

    def _resolve_variables(self, input_data: Dict, prev_result: Dict, all_results: Dict) -> Dict:
        """解析输入数据中的变量引用"""
        resolved = {}
        for key, value in input_data.items():
            if isinstance(value, str) and value == "$prev.result":
                resolved[key] = prev_result
            elif isinstance(value, str) and value == "$all":
                resolved[key] = all_results
            else:
                resolved[key] = value
        return resolved

    def _finalize_task(self, task_id: str, workflow_id: str, all_results: Dict):
        """任务完成后的收尾工作"""
        try:
            # 1. 构建Trade Graph
            scored_leads = all_results.get("LeadScoringAgent", {}).get("scored_leads", [])
            product = self.stm.get(task_id, "plan", {}).get("objective", "").split("开发")[-1].split("进口商")[0].strip() if self.stm.get(task_id, "plan") else "product"
            market = self.stm.get(task_id, "plan", {}).get("objective", "").split("开发")[0].replace("开发", "").strip() if self.stm.get(task_id, "plan") else "market"

            if scored_leads:
                self.trade_graph.build_from_task(task_id, scored_leads, product, market)

            # 2. 持久化到数据库
            self.data_service.save_task_result(task_id, workflow_id, {
                "companies": all_results.get("CompanyDiscoveryAgent", {}).get("companies", []),
                "scored_leads": scored_leads,
                "strategies": all_results.get("SalesStrategyAgent", {}).get("strategies", []),
                "report": all_results.get("ReportAgent", {}),
            })

        except Exception as e:
            # 持久化失败不影响主流程
            self.audit.log(
                task_id=task_id,
                workflow_id=workflow_id,
                agent_id="SupervisorAgent",
                input_data={"action": "finalize"},
                output_data={},
                status="failed",
                error=f"Finalize error: {str(e)}",
            )
