# PSV Trade Intelligence OS v3.0

## 系统定位

**PSV = 外贸智能业务系统**

以 **LangGraph 编排智能体** 为核心运行引擎的外贸智能操作系统。

## 核心架构

```
用户外贸目标
    ↓
Trade Intent 输入层
    ↓
LangGraph Orchestrator 编排智能体
    ↓
Agent 工作流系统 (7个专业Agent)
    ↓
数据采集 → 分析 → 评分 → 决策
    ↓
客户池 / 企业画像 / 商业机会
    ↓
Trade Graph 商业关系图谱
    ↓
数据库持久化
    ↓
审计追踪
```

## 目录结构

```
PSV_Trade_OS/
├── app/                    # 应用入口
│   └── main.py            # CLI/Web双模式入口
├── business/              # 外贸业务核心
│   ├── models/            # CompanyProfile, CustomerIntelligence
│   └── services/          # TradeGraph商业关系图谱
├── orchestrator/          # LangGraph 核心编排层 ⭐
│   ├── graph.py           # 主图定义（StateGraph + MemorySaver）
│   ├── state.py           # TradeGraphState 状态定义
│   ├── planner.py         # TradePlanner Agent
│   ├── supervisor.py      # Supervisor Agent（调度+验证+持久化）
│   ├── router.py          # 条件路由
│   ├── executor.py        # Agent执行器
│   ├── checkpoint.py      # 检查点管理
│   └── recovery.py        # 中断恢复机制
├── agents/                # 8个专业业务Agent
│   ├── base.py            # Agent基类
│   ├── market_research.py      # 市场研究
│   ├── company_discovery.py    # 企业发现
│   ├── company_enrichment.py   # 企业补全
│   ├── contact_discovery.py    # 联系人发现
│   ├── lead_scoring.py         # 客户评分
│   ├── sales_strategy.py       # 销售策略
│   └── report.py               # 报告生成
├── contracts/             # 契约层（6个契约）
├── shared/                # 共享层
│   ├── memory/            # 短期/长期记忆
│   ├── state/             # 状态管理（暂停/恢复/继续）
│   ├── cache/             # 缓存管理
│   ├── knowledge/         # 知识库
│   └── config/            # 全局配置
├── audit/                 # 审计层（全链路追踪）
├── database/              # 数据库层
│   ├── models.py          # 11张核心表
│   └── repository.py      # Repository/DAO模式
├── webui/                 # FastAPI业务界面
│   └── app.py             # 完整Web界面（7个业务页面）
└── tests/                 # 测试套件
```

## 安装

```bash
pip install -r requirements.txt
```

## 运行

### 命令行模式
```bash
python app/main.py
# 或
python app/main.py --mode cli
```

### Web UI 模式
```bash
python app/main.py --mode web
# 访问 http://localhost:8000
```

### 测试模式
```bash
python app/main.py --mode test
```

## WebUI 页面

- `/` - 仪表盘（新建任务 + 统计 + 最近任务）
- `/market-analysis` - 市场分析
- `/customer-pool` - 客户智能池（A/B/C/D分级）
- `/company-profile/{id}` - 企业画像
- `/tasks` - 开发任务列表
- `/opportunities` - 商业机会（进度条 + 阶段）
- `/supply-chain` - 供应链关系图谱
- `/reports` - 智能报告

## API 接口

- `POST /api/trade/run` - 执行外贸任务
- `GET /api/dashboard/stats` - 仪表盘统计
- `GET /api/companies` - 企业列表
- `GET /api/customers` - 客户池
- `GET /api/opportunities` - 商业机会
- `GET /api/tasks` - 任务列表
- `GET /api/audit/logs` - 审计日志
- `GET /api/trade-graph/stats` - 图谱统计
- `GET /api/trade-graph/visualization` - 图谱可视化数据

## 核心流程

1. 用户输入外贸目标
2. TradePlanner 生成7步执行计划
3. Supervisor 按顺序调度Agent
4. 每个Agent有输入/输出/置信度/证据/状态
5. 失败时自动恢复（最多3次）
6. 完成后构建Trade Graph + 持久化到数据库
7. 所有行为记录审计日志

## 验收标准

✅ 用户输入外贸目标 → 系统自动完成全流程
✅ 全过程 LangGraph 驱动
✅ 所有Agent有输入、输出、状态、日志
✅ 任务失败可恢复
✅ 所有数据进入数据库
✅ 所有行为可审计
✅ Trade Graph商业关系图谱
✅ 完整Web业务界面
