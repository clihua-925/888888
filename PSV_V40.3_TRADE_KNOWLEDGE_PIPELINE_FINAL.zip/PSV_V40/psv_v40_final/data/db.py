"""数据库连接与建表。全系统唯一持有连接实现的地方（repository 经此取连接）。

数据链路（贸易事件驱动）：
trade_raw_pages -> trade_extracted_entities / trade_extracted_shipments
  -> trade_entities -> trade_shipments -> trade_edges
任何 Edge 可回溯：Edge -> Shipment -> Evidence -> Raw Page -> URL。
"""
from __future__ import annotations
import os
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS trade_raw_pages (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    source         TEXT NOT NULL,
    url            TEXT NOT NULL,
    page_type      TEXT NOT NULL DEFAULT 'unknown',
    keyword        TEXT,
    page_number    INTEGER NOT NULL DEFAULT 1,
    html_path      TEXT,
    text           TEXT,
    title          TEXT,
    screenshot     TEXT,
    fetched_at     TEXT NOT NULL,
    search_plan_id INTEGER,
    browser_session TEXT,
    content_hash   TEXT,
    quality_score  REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS trade_extracted_entities (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    raw_page_id       INTEGER NOT NULL REFERENCES trade_raw_pages(id),
    company_candidate TEXT NOT NULL,
    role_candidate    TEXT,
    country_candidate TEXT,
    product_candidate TEXT,
    shipment_info     TEXT,
    evidence          TEXT NOT NULL,
    confidence        REAL NOT NULL DEFAULT 0.5
                      CHECK (confidence BETWEEN 0 AND 1),
    extracted_at      TEXT NOT NULL,
    model_version     TEXT NOT NULL DEFAULT 'unknown'
);

CREATE TABLE IF NOT EXISTS trade_extracted_shipments (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    raw_page_id        INTEGER NOT NULL REFERENCES trade_raw_pages(id),
    supplier_candidate TEXT NOT NULL,
    buyer_candidate    TEXT NOT NULL,
    product            TEXT,
    quantity           TEXT,
    ship_date          TEXT,
    evidence           TEXT NOT NULL,
    confidence         REAL NOT NULL DEFAULT 0.5
                       CHECK (confidence BETWEEN 0 AND 1),
    extracted_at       TEXT NOT NULL,
    model_version      TEXT NOT NULL DEFAULT 'unknown'
);

CREATE TABLE IF NOT EXISTS standard_company_data (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    raw_page_id    INTEGER NOT NULL REFERENCES trade_raw_pages(id),
    company_name   TEXT NOT NULL,
    country        TEXT,
    product        TEXT,
    shipment_count INTEGER,
    source_url     TEXT,
    original_text  TEXT NOT NULL,
    standardized_at TEXT NOT NULL,
    model_version  TEXT NOT NULL DEFAULT 'unknown'
);

CREATE TABLE IF NOT EXISTS customer_queue (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    country       TEXT,
    raw_page_id   INTEGER REFERENCES trade_raw_pages(id),
    status        TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','processing','success','failed')),
    attempts      INTEGER NOT NULL DEFAULT 0,
    profile_id    INTEGER,
    error         TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS customer_profiles (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    canonical_name TEXT NOT NULL UNIQUE,
    aliases        TEXT NOT NULL DEFAULT '[]',
    country        TEXT,
    industry       TEXT,
    products       TEXT NOT NULL DEFAULT '[]',
    company_type   TEXT,
    website        TEXT,
    address        TEXT,
    confidence     REAL NOT NULL DEFAULT 0.5,
    sources        TEXT NOT NULL DEFAULT '[]',
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trade_entities (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type    TEXT NOT NULL CHECK (entity_type IN ('Product','Company','Location','ShipmentEvent')),
    canonical_name TEXT NOT NULL,
    aliases        TEXT NOT NULL DEFAULT '[]',
    country        TEXT,
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL,
    UNIQUE (entity_type, canonical_name)
);

CREATE TABLE IF NOT EXISTS trade_shipments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_id INTEGER NOT NULL REFERENCES trade_entities(id),
    buyer_id    INTEGER NOT NULL REFERENCES trade_entities(id),
    product     TEXT,
    quantity    TEXT,
    ship_date   TEXT,
    source_url  TEXT,
    evidence    TEXT NOT NULL CHECK (length(trim(evidence)) > 0),
    confidence  REAL NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    raw_page_id INTEGER NOT NULL REFERENCES trade_raw_pages(id),
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trade_edges (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   INTEGER NOT NULL REFERENCES trade_entities(id),
    target_id   INTEGER NOT NULL REFERENCES trade_entities(id),
    relation    TEXT NOT NULL CHECK (relation IN ('PRODUCES','SUPPLIES','IMPORTS','EXPORTS','LOCATED_IN')),
    shipment_id INTEGER REFERENCES trade_shipments(id),
    evidence    TEXT NOT NULL CHECK (length(trim(evidence)) > 0),
    confidence  REAL NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    source_url  TEXT,
    raw_page_id INTEGER REFERENCES trade_raw_pages(id),
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS collector_failures (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    collector_type TEXT NOT NULL,
    keyword        TEXT,
    error          TEXT NOT NULL,
    retry_count    INTEGER NOT NULL DEFAULT 0,
    occurred_at    TEXT NOT NULL
);
"""

DEFAULT_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage", "psv_v40.db")


def connect(db_path: str | None = None) -> sqlite3.Connection:
    path = db_path or DEFAULT_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    _migrate(conn)
    conn.commit()
    return conn


def _migrate(conn: sqlite3.Connection) -> None:
    """轻量列迁移：为既有库补充新增列。"""
    def cols(table: str) -> set[str]:
        return {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    raw = cols("trade_raw_pages")
    for col, ddl in (("page_type", "TEXT NOT NULL DEFAULT 'unknown'"),
                     ("title", "TEXT"), ("screenshot", "TEXT"),
                     ("browser_session", "TEXT"), ("content_hash", "TEXT"),
                     ("quality_score", "REAL NOT NULL DEFAULT 0")):
        if col not in raw:
            conn.execute(f"ALTER TABLE trade_raw_pages ADD COLUMN {col} {ddl}")
    if "keyword" not in raw:
        conn.execute("ALTER TABLE trade_raw_pages ADD COLUMN keyword TEXT")
    if "page_number" not in raw:
        conn.execute("ALTER TABLE trade_raw_pages ADD COLUMN page_number INTEGER NOT NULL DEFAULT 1")
    ext = cols("trade_extracted_entities")
    if "shipment_info" not in ext:
        conn.execute("ALTER TABLE trade_extracted_entities ADD COLUMN shipment_info TEXT")
    edge = cols("trade_edges")
    if "shipment_id" not in edge:
        conn.execute("ALTER TABLE trade_edges ADD COLUMN shipment_id INTEGER REFERENCES trade_shipments(id)")
    if "raw_page_id" not in edge:
        conn.execute("ALTER TABLE trade_edges ADD COLUMN raw_page_id INTEGER REFERENCES trade_raw_pages(id)")


def init_db(db_path: str | None = None) -> sqlite3.Connection:
    return connect(db_path)
