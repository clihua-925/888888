"""customer_profiles 读写（L6 客户画像输出）。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import json
import sqlite3
from data.db import connect


class CustomerProfileRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, canonical_name: str, country: str | None = None,
               industry: str | None = None, products: list[str] | None = None,
               company_type: str | None = None, website: str | None = None,
               address: str | None = None, confidence: float = 0.5,
               sources: list[str] | None = None) -> int:
        now = _dt.datetime.utcnow().isoformat()
        cur = self._conn.execute(
            "INSERT INTO customer_profiles(canonical_name,aliases,country,industry,products,"
            " company_type,website,address,confidence,sources,created_at,updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (canonical_name, json.dumps([], ensure_ascii=False), country, industry,
             json.dumps(products or [], ensure_ascii=False), company_type, website,
             address, confidence, json.dumps(sources or [], ensure_ascii=False), now, now))
        self._conn.commit()
        return int(cur.lastrowid)

    def get(self, pid: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM customer_profiles WHERE id=?", (pid,)).fetchone()
        return self._row(row) if row else None

    def find_by_name(self, canonical_name: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM customer_profiles WHERE canonical_name=?", (canonical_name,)).fetchone()
        return self._row(row) if row else None

    def list_all(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM customer_profiles ORDER BY id").fetchall()
        return [self._row(r) for r in rows]

    def add_alias(self, pid: int, alias: str) -> None:
        p = self.get(pid)
        if p and alias and alias not in p["aliases"]:
            self._conn.execute(
                "UPDATE customer_profiles SET aliases=?, updated_at=? WHERE id=?",
                (json.dumps(p["aliases"] + [alias], ensure_ascii=False),
                 _dt.datetime.utcnow().isoformat(), pid))
            self._conn.commit()

    @staticmethod
    def _row(r) -> dict:
        d = dict(r)
        d["aliases"] = json.loads(d["aliases"])
        d["products"] = json.loads(d["products"])
        d["sources"] = json.loads(d["sources"])
        return d
