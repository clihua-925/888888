"""standard_company_data 读写（L5 标准化输出）。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class StandardCompanyRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, raw_page_id: int, company_name: str, original_text: str,
               country: str | None = None, product: str | None = None,
               shipment_count: int | None = None, source_url: str | None = None,
               model_version: str = "std-1") -> int:
        cur = self._conn.execute(
            "INSERT INTO standard_company_data"
            "(raw_page_id,company_name,country,product,shipment_count,source_url,"
            " original_text,standardized_at,model_version) VALUES(?,?,?,?,?,?,?,?,?)",
            (raw_page_id, company_name, country, product, shipment_count, source_url,
             original_text, _dt.datetime.utcnow().isoformat(), model_version))
        self._conn.commit()
        return int(cur.lastrowid)

    def get(self, sid: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM standard_company_data WHERE id=?", (sid,)).fetchone()
        return dict(row) if row else None

    def list_by_ids(self, ids: list[int]) -> list[dict]:
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        rows = self._conn.execute(
            f"SELECT * FROM standard_company_data WHERE id IN ({ph}) ORDER BY id", ids).fetchall()
        return [dict(r) for r in rows]

    def list_all(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM standard_company_data ORDER BY id").fetchall()
        return [dict(r) for r in rows]
