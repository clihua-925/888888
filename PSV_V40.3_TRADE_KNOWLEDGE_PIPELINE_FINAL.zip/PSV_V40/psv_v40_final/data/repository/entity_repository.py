"""trade_entities 读写。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import json
import sqlite3
from data.db import connect


class EntityRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, entity_type: str, canonical_name: str,
               aliases: list[str] | None = None, country: str | None = None) -> int:
        now = _dt.datetime.utcnow().isoformat()
        cur = self._conn.execute(
            "INSERT INTO trade_entities(entity_type,canonical_name,aliases,country,created_at,updated_at)"
            " VALUES(?,?,?,?,?,?)",
            (entity_type, canonical_name, json.dumps(aliases or [], ensure_ascii=False), country, now, now),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def get(self, entity_id: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM trade_entities WHERE id=?", (entity_id,)).fetchone()
        return self._row_to_dict(row) if row else None

    def find_by_name(self, entity_type: str, canonical_name: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM trade_entities WHERE entity_type=? AND canonical_name=?",
            (entity_type, canonical_name),
        ).fetchone()
        return self._row_to_dict(row) if row else None

    def list_all(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM trade_entities ORDER BY id").fetchall()
        return [self._row_to_dict(r) for r in rows]

    def add_alias(self, entity_id: int, alias: str) -> None:
        ent = self.get(entity_id)
        if ent and alias and alias not in ent["aliases"]:
            now = _dt.datetime.utcnow().isoformat()
            self._conn.execute(
                "UPDATE trade_entities SET aliases=?, updated_at=? WHERE id=?",
                (json.dumps(ent["aliases"] + [alias], ensure_ascii=False), now, entity_id),
            )
            self._conn.commit()

    @staticmethod
    def _row_to_dict(row) -> dict:
        d = dict(row)
        d["aliases"] = json.loads(d["aliases"])
        return d
