"""trade_extracted_shipments 读写。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class ExtractedShipmentRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, raw_page_id: int, supplier_candidate: str, buyer_candidate: str,
               evidence: str, confidence: float = 0.5, product: str | None = None,
               quantity: str | None = None, ship_date: str | None = None,
               model_version: str = "unknown") -> int:
        if not evidence or not evidence.strip():
            raise ValueError("trade_extracted_shipments.evidence 禁止为空")
        cur = self._conn.execute(
            "INSERT INTO trade_extracted_shipments"
            "(raw_page_id,supplier_candidate,buyer_candidate,product,quantity,ship_date,"
            " evidence,confidence,extracted_at,model_version) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (raw_page_id, supplier_candidate, buyer_candidate, product, quantity,
             ship_date, evidence, confidence, _dt.datetime.utcnow().isoformat(), model_version),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def get(self, sid: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM trade_extracted_shipments WHERE id=?", (sid,)).fetchone()
        return dict(row) if row else None

    def list_by_ids(self, ids: list[int]) -> list[dict]:
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        rows = self._conn.execute(
            f"SELECT * FROM trade_extracted_shipments WHERE id IN ({ph}) ORDER BY id", ids
        ).fetchall()
        return [dict(r) for r in rows]

    def list_by_raw(self, raw_page_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_extracted_shipments WHERE raw_page_id=? ORDER BY id", (raw_page_id,)
        ).fetchall()
        return [dict(r) for r in rows]
