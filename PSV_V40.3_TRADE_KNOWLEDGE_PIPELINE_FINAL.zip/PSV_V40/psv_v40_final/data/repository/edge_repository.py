"""trade_edges 读写。唯一入口。evidence 非空由 contracts 与表约束双重保证。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class EdgeRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, source_id: int, target_id: int, relation: str,
               evidence: str, confidence: float, source_url: str | None = None,
               shipment_id: int | None = None, raw_page_id: int | None = None) -> int:
        if not evidence or not evidence.strip():
            raise ValueError("trade_edges.evidence 禁止为空")
        if shipment_id is None:
            raise ValueError("trade_edges 必须关联 shipment_id（无 Shipment Event 不建边）")
        cur = self._conn.execute(
            "INSERT INTO trade_edges"
            "(source_id,target_id,relation,shipment_id,evidence,confidence,source_url,raw_page_id,created_at)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (source_id, target_id, relation, shipment_id, evidence, confidence,
             source_url, raw_page_id, _dt.datetime.utcnow().isoformat()),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def get(self, edge_id: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM trade_edges WHERE id=?", (edge_id,)).fetchone()
        return dict(row) if row else None

    def list_by_source(self, entity_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_edges WHERE source_id=? ORDER BY id", (entity_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def list_by_target(self, entity_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_edges WHERE target_id=? ORDER BY id", (entity_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def list_all(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM trade_edges ORDER BY id").fetchall()
        return [dict(r) for r in rows]

    def trace(self, edge_id: int) -> dict | None:
        """全链回溯：Edge -> 两端实体 + shipment + raw page（URL）。"""
        row = self._conn.execute("SELECT * FROM trade_edges WHERE id=?", (edge_id,)).fetchone()
        if row is None:
            return None
        edge = dict(row)
        src = self._conn.execute("SELECT * FROM trade_entities WHERE id=?", (edge["source_id"],)).fetchone()
        tgt = self._conn.execute("SELECT * FROM trade_entities WHERE id=?", (edge["target_id"],)).fetchone()
        ship = self._conn.execute("SELECT * FROM trade_shipments WHERE id=?", (edge["shipment_id"],)).fetchone()
        raw = self._conn.execute("SELECT * FROM trade_raw_pages WHERE id=?", (edge["raw_page_id"],)).fetchone()             if edge.get("raw_page_id") else None
        raw = dict(raw) if raw is not None else None
        return {"edge": edge,
                "source_entity": dict(src) if src else None,
                "target_entity": dict(tgt) if tgt else None,
                "shipment": dict(ship) if ship else None,
                "raw_page": {"id": raw["id"], "url": raw["url"], "page_type": (raw.get("page_type") if isinstance(raw, dict) else raw["page_type"])} if raw else None}
