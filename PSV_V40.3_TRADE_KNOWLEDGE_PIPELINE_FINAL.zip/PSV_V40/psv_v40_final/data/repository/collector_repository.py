"""collector_failures 读写：采集策略失败记录（browser/http/api fallback 留痕）。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class CollectorLogRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def log_failure(self, collector_type: str, error: str,
                    keyword: str | None = None, retry_count: int = 0) -> int:
        cur = self._conn.execute(
            "INSERT INTO collector_failures(collector_type,keyword,error,retry_count,occurred_at)"
            " VALUES(?,?,?,?,?)",
            (collector_type, keyword, error, retry_count, _dt.datetime.utcnow().isoformat()),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def recent_failures(self, limit: int = 50) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM collector_failures ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
