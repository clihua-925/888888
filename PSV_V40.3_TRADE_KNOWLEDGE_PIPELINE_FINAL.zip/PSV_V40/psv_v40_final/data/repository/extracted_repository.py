"""trade_extracted_entities 读写。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class ExtractedRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, raw_page_id: int, company_candidate: str, evidence: str,
               role_candidate: str | None = None, country_candidate: str | None = None,
               product_candidate: str | None = None, shipment_info: str | None = None,
               confidence: float = 0.5, model_version: str = "unknown") -> int:
        cur = self._conn.execute(
            "INSERT INTO trade_extracted_entities"
            "(raw_page_id,company_candidate,role_candidate,country_candidate,"
            " product_candidate,shipment_info,evidence,confidence,extracted_at,model_version)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (raw_page_id, company_candidate, role_candidate, country_candidate,
             product_candidate, shipment_info, evidence, confidence,
             _dt.datetime.utcnow().isoformat(), model_version),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def get(self, extracted_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM trade_extracted_entities WHERE id=?", (extracted_id,)
        ).fetchone()
        return dict(row) if row else None

    def list_by_raw(self, raw_page_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_extracted_entities WHERE raw_page_id=? ORDER BY id", (raw_page_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def list_by_ids(self, ids: list[int]) -> list[dict]:
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        rows = self._conn.execute(
            f"SELECT * FROM trade_extracted_entities WHERE id IN ({ph}) ORDER BY id", ids
        ).fetchall()
        return [dict(r) for r in rows]
