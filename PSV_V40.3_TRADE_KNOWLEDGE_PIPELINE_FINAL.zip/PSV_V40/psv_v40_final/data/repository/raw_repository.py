"""trade_raw_pages 读写。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class RawRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, source: str, url: str, html_path: str | None,
               text: str | None, search_plan_id: int | None = None,
               keyword: str | None = None, page_number: int = 1,
               page_type: str = "unknown", title: str | None = None,
               screenshot: str | None = None, browser_session: str | None = None,
               content_hash: str | None = None, quality_score: float = 0.0) -> int:
        cur = self._conn.execute(
            "INSERT INTO trade_raw_pages"
            "(source,url,page_type,keyword,page_number,html_path,text,title,screenshot,"
            " fetched_at,search_plan_id,browser_session,content_hash,quality_score)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (source, url, page_type, keyword, page_number, html_path, text, title,
             screenshot, _dt.datetime.utcnow().isoformat(), search_plan_id,
             browser_session, content_hash, quality_score),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def update_html_path(self, raw_id: int, html_path: str) -> None:
        self._conn.execute("UPDATE trade_raw_pages SET html_path=? WHERE id=?", (html_path, raw_id))
        self._conn.commit()

    def update_screenshot(self, raw_id: int, screenshot: str) -> None:
        self._conn.execute("UPDATE trade_raw_pages SET screenshot=? WHERE id=?", (screenshot, raw_id))
        self._conn.commit()

    def get(self, raw_id: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM trade_raw_pages WHERE id=?", (raw_id,)).fetchone()
        return dict(row) if row else None

    def list_by_ids(self, ids: list[int]) -> list[dict]:
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        rows = self._conn.execute(
            f"SELECT * FROM trade_raw_pages WHERE id IN ({ph}) ORDER BY id", ids
        ).fetchall()
        return [dict(r) for r in rows]

    def list_by_plan(self, search_plan_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_raw_pages WHERE search_plan_id=? ORDER BY id", (search_plan_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def list_by_keyword(self, keyword: str) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_raw_pages WHERE keyword=? ORDER BY id", (keyword,)
        ).fetchall()
        return [dict(r) for r in rows]
