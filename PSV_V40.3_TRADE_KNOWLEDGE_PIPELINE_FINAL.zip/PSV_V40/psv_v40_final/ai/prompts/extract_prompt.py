"""L5 Information Extraction Prompt。"""
from __future__ import annotations

EXTRACTION_PROMPT = """你是贸易信息抽取器。阅读原始网页文本，抽取其中出现的贸易相关公司候选。
输出 JSON：
{"candidates": [
  {"company_candidate": "公司名原文",
   "role_candidate": "supplier|buyer|manufacturer|importer|exporter|distributor|null",
   "country_candidate": "国家或 null",
   "product_candidate": "页面涉及的产品或 null",
   "evidence": "支持判断的原文片段（必须逐字来自文本）",
   "confidence": 0.0-1.0}
]}
规则：
- 只抽有贸易含义的公司（提单/进出口/供货/采购），不要抽平台、媒体、货代。
- 没有证据就不要输出该候选。
- 每条 evidence 必须能在原文中找到。"""
