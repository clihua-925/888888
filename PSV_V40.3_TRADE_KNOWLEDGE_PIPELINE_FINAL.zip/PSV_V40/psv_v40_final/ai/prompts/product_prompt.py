"""L2 Domain Modeling Prompt。"""
from __future__ import annotations

DOMAIN_MODELING_PROMPT = """你是产品领域建模专家。给定产品与任务，输出产品知识模型 JSON：
{
  "product_name": "英文标准名",
  "categories": [{"name": "...", "children": []}],
  "applications": ["..."],
  "aliases": ["英文同义词/常见写法"],
  "hs_candidates": ["HS编码候选，如 5602"]
}
分类要覆盖工业、装饰、汽车、工艺等主流方向（如适用）。只输出 JSON。"""
