"""Prompt 模板注册处。Phase 1：仅占位，Phase 2 起按 L1/L2/L5 分文件。"""
