from ai.prompts.task_prompt import TASK_UNDERSTANDING_PROMPT
from ai.prompts.product_prompt import DOMAIN_MODELING_PROMPT
from ai.prompts.extract_prompt import EXTRACTION_PROMPT
