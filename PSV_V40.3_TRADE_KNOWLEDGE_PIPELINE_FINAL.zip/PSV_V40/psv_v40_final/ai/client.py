"""统一 LLM 出入口。Business 层禁止直接 import 任何模型 SDK，只能调这里。

配置（环境变量）：
  PSV_LLM_API_KEY / OPENAI_API_KEY   有值则启用真实 LLM 调用
  PSV_LLM_BASE_URL                   默认 https://api.openai.com/v1
  PSV_LLM_MODEL                      默认 gpt-4o-mini
未配置时 configured=False，业务层走确定性规则路径（不会伪造 AI 结果）。
"""
from __future__ import annotations
import json
import os
import urllib.request
from typing import Any


class AIClientError(RuntimeError):
    pass


class AIClient:
    def __init__(self, api_key: str | None = None, base_url: str | None = None,
                 model: str | None = None, timeout: int = 60) -> None:
        self._api_key = api_key or os.getenv("PSV_LLM_API_KEY") or os.getenv("OPENAI_API_KEY")
        self._base_url = (base_url or os.getenv("PSV_LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
        self._model = model or os.getenv("PSV_LLM_MODEL") or "gpt-4o-mini"
        self._timeout = timeout

    @property
    def configured(self) -> bool:
        return bool(self._api_key)

    def chat(self, prompt: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        """调用 LLM，要求模型返回 JSON；返回解析后的 dict。未配置或未成功时抛 AIClientError。"""
        if not self.configured:
            raise AIClientError("LLM 未配置：设置 PSV_LLM_API_KEY 后启用真实 AI 路径")
        content = (
            prompt
            + "\n\n[上下文]\n"
            + json.dumps(context or {}, ensure_ascii=False)
            + "\n\n只输出 JSON，不要输出其他文字。"
        )
        payload = json.dumps({
            "model": self._model,
            "messages": [{"role": "user", "content": content}],
            "temperature": 0.2,
            "response_format": {"type": "json_object"},
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{self._base_url}/chat/completions", data=payload,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self._api_key}"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            text = data["choices"][0]["message"]["content"]
        except Exception as e:  # 网络/解析/限流统一上抛为业务可捕获错误
            raise AIClientError(f"LLM 调用失败: {e}") from e
        return _parse_json_loose(text)

    def extract(self, prompt: str, raw_text: str) -> dict[str, Any]:
        """L5 专用：对单页 Raw 文本做结构化抽取，返回 {"candidates": [...]}。"""
        return self.chat(prompt, {"raw_text": raw_text[:8000]})

    def model_version(self) -> str:
        return f"llm:{self._model}" if self.configured else "none"


def _parse_json_loose(text: str) -> dict[str, Any]:
    """从 LLM 输出中稳健提取 JSON 对象（容忍 ```json 围栏与前后噪音）。"""
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`")
        if t.lower().startswith("json"):
            t = t[4:]
    s, e = t.find("{"), t.rfind("}")
    if s < 0 or e <= s:
        raise AIClientError(f"LLM 输出不是 JSON: {text[:200]}")
    try:
        return json.loads(t[s:e + 1])
    except json.JSONDecodeError as ex:
        raise AIClientError(f"LLM 输出 JSON 解析失败: {ex}") from ex
