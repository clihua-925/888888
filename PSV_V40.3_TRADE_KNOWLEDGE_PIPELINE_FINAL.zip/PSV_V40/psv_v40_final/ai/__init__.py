"""AI Layer: LLM 调用与 Prompt 的唯一住处。business 只能经 ai/client。"""
