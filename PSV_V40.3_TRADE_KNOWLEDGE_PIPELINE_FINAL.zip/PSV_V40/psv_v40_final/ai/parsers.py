"""AI 输出 -> contracts 的结构化解析与校验。

职责：把 LLM/解析器的原始输出安全地转成 contracts 模型；非法项丢弃并记录原因。
"""
from __future__ import annotations
from typing import Any


def parse_with(model_cls, payload: dict[str, Any]):
    """用 contracts 模型校验单条数据；失败抛 ValidationError（由调用方决定重试/丢弃）。"""
    return model_cls.model_validate(payload)


def validate_many(model_cls, items: list[dict[str, Any]]) -> tuple[list, list[dict]]:
    """批量校验，返回 (合法实例列表, 被拒绝的原始payload+原因列表)。绝不带病通过。"""
    ok, rejected = [], []
    for it in items:
        try:
            ok.append(model_cls.model_validate(it))
        except Exception as e:
            rejected.append({"payload": it, "reason": str(e)})
    return ok, rejected


def validate_extracted_candidate(items: list[dict[str, Any]],
                                 raw_page_id: int) -> tuple[list[dict], list[dict]]:
    """校验 L5 AI 输出（V40.1 schema），强制：
    - 必填 company_name / evidence（非空）
    - confidence 归一化到 [0,1]
    - raw_page_id 回填（不信任 AI 给的值，防止串页）
    """
    ok, rejected = [], []
    for it in items:
        name = str(it.get("company_name") or "").strip()
        ev = str(it.get("evidence") or "").strip()
        if not name or not ev:
            rejected.append({"payload": it, "reason": "company_name/evidence 为空"})
            continue
        try:
            conf = float(it.get("confidence", 0.5))
        except (TypeError, ValueError):
            conf = 0.5
        ok.append({
            "company_name": name,
            "company_role": (str(it.get("company_role") or "").strip().lower() or None),
            "country": str(it.get("country") or "").strip() or None,
            "product": str(it.get("product") or "").strip() or None,
            "shipment_info": str(it.get("shipment_info") or "").strip() or None,
            "evidence": ev,
            "source_url": str(it.get("source_url") or "").strip() or None,
            "raw_page_id": raw_page_id,
            "confidence": min(1.0, max(0.0, conf)),
        })
    return ok, rejected
