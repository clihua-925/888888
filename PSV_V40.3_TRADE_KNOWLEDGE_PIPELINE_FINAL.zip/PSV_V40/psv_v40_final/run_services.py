"""PSV 服务启动器（由 start_psv.bat 经 powershell 隐藏调用）。

拉起 Backend(:8000) + Frontend(:3000) 两个子进程（无窗口），
日志分别写入 logs/backend.log 与 logs/frontend.log，端口就绪后自动打开浏览器。
"""
from __future__ import annotations
import os
import socket
import subprocess
import sys
import time
import webbrowser

APP = os.path.dirname(os.path.abspath(__file__))
LOGS = os.path.join(APP, "logs")
PY = sys.executable
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)


def _wait_port(port: int, timeout: int = 40) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            if socket.socket().connect_ex(("127.0.0.1", port)) == 0:
                return True
        except OSError:
            pass
        time.sleep(0.5)
    return False


def main() -> int:
    os.makedirs(LOGS, exist_ok=True)
    procs = []
    if socket.socket().connect_ex(("127.0.0.1", 8000)) != 0:
        f = open(os.path.join(LOGS, "backend.log"), "ab")
        procs.append(subprocess.Popen(
            [PY, "-m", "uvicorn", "api.app:app", "--host", "0.0.0.0", "--port", "8000"],
            cwd=APP, stdout=f, stderr=subprocess.STDOUT, creationflags=CREATE_NO_WINDOW))
    if socket.socket().connect_ex(("127.0.0.1", 3000)) != 0:
        f = open(os.path.join(LOGS, "frontend.log"), "ab")
        procs.append(subprocess.Popen(
            [PY, "-m", "http.server", "3000", "--directory", "frontend"],
            cwd=APP, stdout=f, stderr=subprocess.STDOUT, creationflags=CREATE_NO_WINDOW))
    if _wait_port(8000) and _wait_port(3000):
        webbrowser.open("http://localhost:3000")
        print("[OK] Backend:8000 Frontend:3000 已就绪，浏览器已打开")
        return 0
    print("[ERROR] 服务启动超时，请查看 logs/backend.log 与 logs/frontend.log")
    return 1


if __name__ == "__main__":
    sys.exit(main())
