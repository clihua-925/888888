"""L1 Task Understanding 的输出契约。"""
from __future__ import annotations
from pydantic import BaseModel, Field


class TaskObject(BaseModel):
    """用户任务的结构化理解。L1 输出，禁止包含任何供应商/企业结论。"""

    product: str = Field(..., description="产品名称，例如：毛毡")
    target_market: str = Field(..., description="目标市场，例如：美国")
    target_country: str | None = Field(None, description="目标国家，可空")
    company_types: list[str] = Field(
        default_factory=list,
        description="目标企业类型，例如：manufacturer / importer / distributor",
    )
    analysis_goal: str = Field(..., description="分析目标，例如：供应链结构分析")
