"""Shipment 契约。

ExtractedShipment：L5 从 Raw 抽出的候选贸易事件（候选名，未经 L6 归一）。
ShipmentEvent：L7 归一后落库的正式贸易事件（实体 ID）。
"""
from __future__ import annotations
from pydantic import BaseModel, Field, model_validator


class ExtractedShipment(BaseModel):
    """L5 候选贸易事件：supplier/buyer 均为候选写法，必须带 evidence 与 raw_page_id。"""

    raw_page_id: int
    supplier_candidate: str = Field(..., min_length=1)
    buyer_candidate: str = Field(..., min_length=1)
    product: str | None = None
    quantity: str | None = None
    date: str | None = None
    evidence: str = Field(..., min_length=1)
    confidence: float = Field(0.5, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def _evidence_not_blank(self) -> "ExtractedShipment":
        if not self.evidence.strip():
            raise ValueError("ExtractedShipment 必须有非空 evidence")
        return self


class ShipmentEvent(BaseModel):
    """L7 正式贸易事件（trade_shipments 行）。"""

    id: int | None = None
    supplier_id: int = Field(..., description="出口方 trade_entities.id")
    buyer_id: int = Field(..., description="进口方 trade_entities.id")
    product: str | None = None
    quantity: str | None = None
    date: str | None = None
    source_url: str | None = None
    raw_page_id: int = Field(..., description="证据所在 Raw 页")
    evidence: str = Field(..., min_length=1)
    confidence: float = Field(..., ge=0.0, le=1.0)

    @model_validator(mode="after")
    def _evidence_not_blank(self) -> "ShipmentEvent":
        if not self.evidence.strip():
            raise ValueError("ShipmentEvent 必须有非空 evidence")
        return self
