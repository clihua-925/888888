"""Contract Layer: 唯一的数据结构定义处。orchestration/business/ai 全部经此通信。"""
