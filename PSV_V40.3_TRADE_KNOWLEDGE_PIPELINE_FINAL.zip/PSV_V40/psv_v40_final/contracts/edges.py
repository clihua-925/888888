"""L7 Relationship Construction 的输出契约。没有 evidence 不允许创建 Edge。"""
from __future__ import annotations
from enum import Enum
from pydantic import BaseModel, Field, model_validator


class RelationType(str, Enum):
    PRODUCES = "PRODUCES"
    SUPPLIES = "SUPPLIES"
    IMPORTS = "IMPORTS"
    EXPORTS = "EXPORTS"
    LOCATED_IN = "LOCATED_IN"


class Edge(BaseModel):
    """图谱中的边。source/target 为 trade_entities.id。硬约束：必须有证据。"""

    source: int = Field(..., description="trade_entities.id")
    target: int = Field(..., description="trade_entities.id")
    relation: RelationType
    evidence: str = Field(..., min_length=1, description="关系证据，禁止为空")
    confidence: float = Field(..., ge=0.0, le=1.0)
    source_url: str | None = Field(None, description="证据来源 URL")

    @model_validator(mode="after")
    def _evidence_not_blank(self) -> "Edge":
        if not self.evidence.strip():
            raise ValueError("Edge 必须有非空 evidence")
        return self
