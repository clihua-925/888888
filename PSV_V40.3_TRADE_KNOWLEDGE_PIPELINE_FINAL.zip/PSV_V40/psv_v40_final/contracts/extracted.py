"""L5 Information Extraction 的输出契约。

注意：这是 AI 候选结果（candidate），不是正式实体。
正式实体由 L6 Entity Resolution 产出。
"""
from __future__ import annotations
from pydantic import BaseModel, Field


class ExtractedFact(BaseModel):
    """从单条 Raw 数据中抽取的候选事实，必须携带 evidence 与 raw_page_id 以便回溯。"""

    raw_page_id: int
    company_candidate: str = Field(..., description="AI 候选公司名，未归一")
    role_candidate: str | None = Field(None, description="候选角色：supplier/buyer/manufacturer...")
    country_candidate: str | None = Field(None)
    evidence: str = Field(..., description="原文证据片段")
    model_version: str = Field(default="unknown", description="产生该结果的模型版本")
