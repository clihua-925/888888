"""L2 Domain Modeling 的输出契约。"""
from __future__ import annotations
from pydantic import BaseModel, Field


class CategoryNode(BaseModel):
    """产品分类树节点，例如 Industrial Felt / Decorative Felt。"""

    name: str
    children: list["CategoryNode"] = Field(default_factory=list)


class ProductKnowledgeModel(BaseModel):
    """产品知识模型：分类、应用、同义词、HS 候选。"""

    product_name: str
    categories: list[CategoryNode] = Field(default_factory=list)
    applications: list[str] = Field(default_factory=list)
    aliases: list[str] = Field(default_factory=list)
    hs_candidates: list[str] = Field(default_factory=list)


CategoryNode.model_rebuild()
