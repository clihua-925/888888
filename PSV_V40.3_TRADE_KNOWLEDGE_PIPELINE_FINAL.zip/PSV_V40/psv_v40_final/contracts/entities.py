"""L6 Entity Resolution 的输出契约。"""
from __future__ import annotations
from enum import Enum
from pydantic import BaseModel, Field


class EntityType(str, Enum):
    PRODUCT = "Product"
    COMPANY = "Company"
    LOCATION = "Location"
    SHIPMENT_EVENT = "ShipmentEvent"


class Entity(BaseModel):
    """正式实体（图谱中的点）。canonical_name 为归一后的唯一名。"""

    entity_type: EntityType
    canonical_name: str = Field(..., min_length=1)
    aliases: list[str] = Field(default_factory=list)
    country: str | None = None
