"""L5 双输出：实体候选 + 贸易事件候选（shipment_detail 页 Shipper/Consignee 模式）。"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.extracted_repository import ExtractedRepository
from data.repository.extracted_shipment_repository import ExtractedShipmentRepository
from business.trade.extractor import TradeExtractor
from business.shared.page_cleaner import clean_html

_IY_LIKE = ("Shinwon Felt | 180 shipments  Wool Felt Supplier Korea  "
            "ABC Import LLC | 45 shipments  Felt Buyer USA  "
            "Global Textiles Inc | 300 shipments")
_SHIP_PAGE = ("BILL OF LADING  Shipper: Shinwon Felt Co  Consignee: ABC Import LLC  "
              "Product: Industrial Felt  Quantity: 180 units  Date: 2026-08-01")


def test_page_cleaner_strips_noise():
    html = "<html><head><style>body{}</style><script>var x=1;</script></head>" \
           "<body><nav>menu</nav><p>Shinwon Felt 180 shipments</p></body></html>"
    text = clean_html(html)
    assert "var x" not in text and "menu" not in text
    assert "Shinwon Felt" in text


def test_extract_entities_and_shipments():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        raw = RawRepository(conn)
        r1 = raw.create("importyeti", "http://iy/search", None, _IY_LIKE, page_type="search_result")
        r2 = raw.create("importyeti", "http://iy/ship/1", None, _SHIP_PAGE, page_type="shipment_detail")
        out = TradeExtractor(conn=conn).extract([r1, r2])
        ents = ExtractedRepository(conn).list_by_ids(out["extracted_ids"])
        ships = ExtractedShipmentRepository(conn).list_by_ids(out["shipment_extracted_ids"])
        assert len(ents) >= 2 and all(e["evidence"] for e in ents)
        assert any("Shinwon" in e["company_candidate"] for e in ents)
        assert len(ships) >= 1, "shipment_detail 页应抽出贸易事件"
        s0 = ships[0]
        assert "Shinwon" in s0["supplier_candidate"] and "ABC Import" in s0["buyer_candidate"]
        assert s0["evidence"].strip() and s0["raw_page_id"] == r2
    finally:
        conn.close(); os.unlink(path)
