"""Test 2：L2 Domain Modeling —— ProductKnowledgeModel 含四大毛毡分类。"""
from business.product.domain_model_service import DomainModelService
from business.product.task_service import TaskService


def test_felt_categories():
    task = TaskService().understand("毛毡")
    model = DomainModelService().build(task)
    names = [c.name for c in model.categories]
    assert "Industrial Felt" in names
    assert "Decorative Felt" in names
    assert "Automotive Felt" in names
    assert "Craft Felt" in names
    assert model.aliases and model.hs_candidates
