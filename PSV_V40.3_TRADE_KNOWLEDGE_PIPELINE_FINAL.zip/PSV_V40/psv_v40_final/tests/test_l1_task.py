"""Test 1：L1 Task Understanding —— 输入『毛毡』输出 TaskObject。"""
from business.product.task_service import TaskService


def test_task_object_from_felt():
    t = TaskService().understand("毛毡")
    assert t.product == "Felt"
    assert t.target_market
    assert t.analysis_goal
    assert "supplier" in t.company_types and "importer" in t.company_types
