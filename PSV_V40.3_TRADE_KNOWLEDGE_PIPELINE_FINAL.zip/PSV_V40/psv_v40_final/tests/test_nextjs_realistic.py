"""端到端（新职责边界）：L4 -> L5 -> L7(调用L6) -> L6节点 -> L8 可用。"""
import os, tempfile
from contracts.search_plan import SearchPlan
from business.trade.collector.browser_agent import BrowserAgentCollector
from business.trade.collector.driver import BaseDriver, PageBundle
from data.db import init_db
from data.repository.raw_repository import RawRepository
from business.trade.standardizer import TradeStandardizer
from business.trade.relationship_builder import RelationshipBuilder
from data.repository.edge_repository import EdgeRepository
from data.repository.customer_profile_repository import CustomerProfileRepository

NEXT = '{"props":{"pageProps":{"companies":[{"slug":"shinwon-felt","name":"Shinwon Felt","shipments":180,"country":"Korea"}]}}}'
SUP = ('<html><title>Shinwon Felt | ImportYeti</title><body>180 Shipments'
       '<script id="__NEXT_DATA__" type="application/json">'
       '{"props":{"pageProps":{"records":[{"consignee":"ABC Import LLC","country":"USA","shipments":120}]}}}'
       '</script></body></html>')


def _p(html, url, t, kw=None, n=1):
    import re
    m = re.search(r"<title>([^<]+)", html)
    return PageBundle(html=html, url=url, page_type=t, keyword=kw, page_number=n,
                      title=m.group(1) if m else None)


class _FakeDriver(BaseDriver):
    driver_type = "fake"
    def homepage(self):
        return _p("<html><title>ImportYeti</title><body>trade data</body></html>",
                  "https://www.importyeti.com/", "homepage")
    def search(self, keyword, max_pages=3):
        return [_p('<html><title>Search</title><body>supplier importer '
                   '<script id="__NEXT_DATA__" type="application/json">' + NEXT +
                   '</script></body></html>',
                   "https://www.importyeti.com/search?q=x", "search_result", keyword, 1)]
    def company_detail(self, slug):
        return _p(SUP, f"https://www.importyeti.com/company/{slug}", "company_detail")
    def shipment_detail(self, url):
        return None


def test_full_chain_new_boundary():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        collector = BrowserAgentCollector(driver=_FakeDriver(), raw_repo=RawRepository(conn), max_pages=1)
        raw_ids = collector.collect(SearchPlan(queries=["Industrial Felt supplier"], sources=[],
                                               directions=[], priority=[]))
        types = {RawRepository(conn).get(i)["page_type"] for i in raw_ids}
        assert {"homepage", "search_result", "company_detail"} <= types

        std_ids = TradeStandardizer(conn=conn).standardize(raw_ids)
        assert std_ids, "L5 应产出标准化公司数据"

        result = RelationshipBuilder(conn=conn).build(std_ids, raw_ids)
        assert result["customer_stats"]["success"] >= 1
        assert result["shipment_ids"] and result["edge_ids"]
        edges = [EdgeRepository(conn).get(i) for i in result["edge_ids"]]
        assert all(e["relation"] == "SUPPLIES" and e["shipment_id"] for e in edges)
        profiles = CustomerProfileRepository(conn).list_all()
        assert any(p["canonical_name"] == "ABC Import LLC" for p in profiles)
        print("  E2E ✓ std:", len(std_ids), "· shipments:", len(result["shipment_ids"]),
              "· edges:", len(edges), "· customer profiles:", len(profiles))
    finally:
        conn.close(); os.unlink(path)
