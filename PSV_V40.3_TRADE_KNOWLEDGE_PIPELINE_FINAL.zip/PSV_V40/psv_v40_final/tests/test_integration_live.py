"""真实采集集成测试（需外网）。ImportYeti 搜索页 → Raw 落库 → 抽取候选。

网络不可用时自动 skip，绝不伪造结果。
"""
import os, tempfile
import pytest


def test_live_importyeti_roundtrip():
    try:
        from business.trade.collector.fetcher import UrllibFetcher
        html, url = UrllibFetcher(timeout=15).fetch(
            "https://www.importyeti.com/search?q=industrial+felt")
    except Exception as e:
        pytest.skip(f"外网不可用: {e}")
    assert "importyeti" in url
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    from data.db import init_db
    from data.repository.raw_repository import RawRepository
    conn = init_db(path)
    try:
        raw = RawRepository(conn)
        rid = raw.create("importyeti", url, None, html[:200000])
        from business.trade.extractor import TradeExtractor
        ids = TradeExtractor(conn=conn).extract([rid])
        assert raw.get(rid)["text"] or raw.get(rid)["url"]
        print(f"live extracted candidates: {len(ids)}")
    finally:
        conn.close(); os.unlink(path)
