"""Repository 层验收：四层表外键链 raw -> extracted -> entity -> edge 可追溯。"""
import os
import tempfile
import pytest
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.extracted_repository import ExtractedRepository
from data.repository.entity_repository import EntityRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository


@pytest.fixture()
def repos():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    conn = init_db(path)
    yield (conn, RawRepository(conn), ExtractedRepository(conn),
           EntityRepository(conn), EdgeRepository(conn))
    conn.close()
    os.unlink(path)


def test_four_layer_chain(repos):
    conn, raw_r, ext_r, ent_r, edge_r = repos
    raw_id = raw_r.create(source="importyeti", url="http://iy/shinwon",
                          html_path="/storage/files/1.html", text="180 shipments")
    ext_id = ext_r.create(raw_page_id=raw_id, company_candidate="Shinwon Felt Co.",
                          role_candidate="supplier", country_candidate="Korea",
                          evidence="180 shipments of felt", model_version="test-1")
    src_id = ent_r.create("Company", "Shinwon Felt", aliases=["Shinwon Felt Co."], country="Korea")
    tgt_id = ent_r.create("Company", "ABC Import LLC", aliases=[], country="USA")
    ship_id = ShipmentRepository(conn).create(
        supplier_id=src_id, buyer_id=tgt_id, product="Industrial Felt",
        evidence="BOL: Shinwon Felt -> ABC Import LLC, 180 shipments",
        confidence=0.92, raw_page_id=raw_id, source_url="http://iy/shinwon")
    edge_id = edge_r.create(source_id=src_id, target_id=tgt_id, relation="EXPORTS",
                            evidence="BOL: Shinwon Felt -> ABC Import LLC, 180 shipments",
                            confidence=0.92, source_url="http://iy/shinwon",
                            shipment_id=ship_id, raw_page_id=raw_id)
    assert ext_r.list_by_raw(raw_id)[0]["company_candidate"] == "Shinwon Felt Co."
    trace = edge_r.trace(edge_id)
    assert trace["source_entity"]["canonical_name"] == "Shinwon Felt"
    assert trace["edge"]["relation"] == "EXPORTS" and trace["edge"]["shipment_id"] == ship_id


def test_edge_rejects_empty_evidence(repos):
    _, _, _, ent_r, edge_r = repos
    a = ent_r.create("Company", "A Co")
    b = ent_r.create("Company", "B Co")
    with pytest.raises(Exception):
        edge_r.create(a, b, "SUPPLIES", "   ", 0.8, None)


def test_entity_unique_per_type(repos):
    _, _, _, ent_r, _ = repos
    ent_r.create("Company", "Shinwon Felt")
    with pytest.raises(Exception):
        ent_r.create("Company", "Shinwon Felt")


def test_extracted_requires_raw_fk(repos):
    _, _, ext_r, _, _ = repos
    with pytest.raises(Exception):
        ext_r.create(raw_page_id=99999, company_candidate="Ghost Co",
                     evidence="no such raw page")
