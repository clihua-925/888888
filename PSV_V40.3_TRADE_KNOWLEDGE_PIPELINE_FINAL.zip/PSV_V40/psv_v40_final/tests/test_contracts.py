"""Contract 层验收：字段完整性、枚举合法性、Edge 证据硬约束。"""
import pytest
from contracts.task import TaskObject
from contracts.product import ProductKnowledgeModel, CategoryNode
from contracts.search_plan import SearchPlan, SearchDirection
from contracts.extracted import ExtractedFact
from contracts.entities import Entity, EntityType
from contracts.edges import Edge, RelationType


def test_task_object_fields():
    t = TaskObject(product="毛毡", target_market="美国", target_country="US",
                   company_types=["manufacturer", "importer"], analysis_goal="供应链结构分析")
    assert t.product == "毛毡"
    assert "importer" in t.company_types


def test_product_knowledge_model_felt_tree():
    felt = ProductKnowledgeModel(
        product_name="Felt",
        categories=[CategoryNode(name="Industrial Felt"),
                    CategoryNode(name="Decorative Felt"),
                    CategoryNode(name="Automotive Felt"),
                    CategoryNode(name="Craft Felt")],
        applications=["filtration", "gasket", "craft"],
        aliases=["wool felt", "synthetic felt"],
        hs_candidates=["5911", "5602"],
    )
    names = [c.name for c in felt.categories]
    assert "Industrial Felt" in names and "Automotive Felt" in names


def test_search_plan_no_collection():
    sp = SearchPlan(queries=["industrial felt supplier"], sources=["importyeti"],
                    directions=[SearchDirection.SUPPLIER_SIDE], priority=["importyeti"])
    assert sp.queries and not hasattr(sp, "results")


def test_extracted_fact_is_candidate_not_entity():
    f = ExtractedFact(raw_page_id=1, company_candidate="Shinwon Felt Co.",
                      role_candidate="supplier", country_candidate="Korea",
                      evidence="180 shipments")
    assert f.company_candidate == "Shinwon Felt Co."


def test_entity_types():
    e = Entity(entity_type=EntityType.COMPANY, canonical_name="Shinwon Felt",
               aliases=["Shinwon Felt Co.", "Shinwon Felt Ltd."], country="Korea")
    assert e.canonical_name == "Shinwon Felt"


def test_edge_requires_evidence():
    with pytest.raises(Exception):
        Edge(source=1, target=2, relation=RelationType.SUPPLIES,
             evidence="", confidence=0.9, source_url="http://x")


def test_edge_requires_confidence_range():
    with pytest.raises(Exception):
        Edge(source=1, target=2, relation=RelationType.IMPORTS,
             evidence="BOL record", confidence=1.5, source_url=None)


def test_relation_enum_membership():
    assert {r.value for r in RelationType} == {"PRODUCES", "SUPPLIES", "IMPORTS", "EXPORTS", "LOCATED_IN"}
