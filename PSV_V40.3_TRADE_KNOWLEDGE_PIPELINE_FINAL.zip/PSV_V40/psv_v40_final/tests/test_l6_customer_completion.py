"""L6 客户补全：队列状态流转 + 变体去重 + 画像输出。只处理客户。"""
import os, tempfile
from data.db import init_db
from data.repository.customer_queue_repository import CustomerQueueRepository
from data.repository.customer_profile_repository import CustomerProfileRepository
from business.trade.customer_service import CustomerCompletionService


def test_queue_dedup_and_profile():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        svc = CustomerCompletionService(conn=conn)
        q1 = svc.enqueue("ABC Import LLC", "USA")
        q2 = svc.enqueue("ABC Imports", "USA")   # 变体
        q3 = svc.enqueue("XYZ Manufacturing", "Germany")
        stats = svc.process_pending()
        assert stats["processed"] == 3 and stats["success"] == 3, stats
        queue = CustomerQueueRepository(conn)
        assert all(j["status"] == "success" for j in
                   queue.list_by_status("success"))
        profiles = CustomerProfileRepository(conn).list_all()
        assert len(profiles) == 2, "ABC Import LLC / ABC Imports 应去重为一个画像"
        abc = next(p for p in profiles if p["canonical_name"] == "ABC Import LLC")
        assert "ABC Imports" in abc["aliases"]
        assert abc["country"] == "USA" and 0 <= abc["confidence"] <= 1
        assert abc["company_type"] and "products" in abc
    finally:
        conn.close(); os.unlink(path)
