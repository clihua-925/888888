"""Shipment 契约：候选与正式事件均强制 evidence。"""
import pytest
from contracts.shipment import ExtractedShipment, ShipmentEvent


def test_extracted_shipment_requires_evidence():
    with pytest.raises(Exception):
        ExtractedShipment(raw_page_id=1, supplier_candidate="A Co",
                          buyer_candidate="B Co", evidence="")


def test_extracted_shipment_fields():
    s = ExtractedShipment(raw_page_id=1, supplier_candidate="Shinwon Felt",
                          buyer_candidate="ABC Import LLC", product="Industrial Felt",
                          quantity="180 units", date="2026-08", evidence="BOL-123",
                          confidence=0.9)
    assert s.supplier_candidate == "Shinwon Felt"


def test_shipment_event_fields():
    s = ShipmentEvent(supplier_id=1, buyer_id=2, product="Industrial Felt",
                      quantity="180 units", date="2026-08", source_url="http://x",
                      raw_page_id=9, evidence="BOL-123", confidence=0.92)
    assert s.raw_page_id == 9 and 0 <= s.confidence <= 1
