"""离线集成测试：完整流水线在无外网、无 LLM 环境下走完 L1-L10（L4 采集为空时下游优雅降级）。

不使用任何 synthetic 贸易数据：L4 由空 collector 注入产生 0 条 Raw，
后续阶段在空输入下仍必须正确执行并产出结构化报告。
"""
from orchestration.runner import run_pipeline


class _NoCollector:
    def collect(self, plan):
        return []


def test_full_pipeline_offline(monkeypatch=None):
    from orchestration import graph as g
    orig = g.TradeDataCollector
    g.TradeDataCollector = lambda *a, **k: _NoCollector()  # L4 不触网
    try:
        state = run_pipeline("毛毡")
    finally:
        g.TradeDataCollector = orig
    assert state["task"].product == "Felt"
    names = [c.name for c in state["product_model"].categories]
    assert "Industrial Felt" in names
    assert any("supplier" in q for q in state["search_plan"].queries)
    assert state.get("raw_page_ids", []) == []
    report = state["report"]
    assert report["product"] == "Felt" and report["market"]
    for k in ("top_suppliers", "top_buyers", "trade_relations", "evidence",
              "risks", "opportunities"):
        assert k in report, f"报告缺少字段 {k}"
    assert "Industrial Felt" in report["product_analysis"]["categories"]
