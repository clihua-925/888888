"""Test 3：L3 Discovery Planning —— SearchPlan 含 supplier/buyer 双向查询。"""
from business.trade.discovery_service import DiscoveryService
from business.product.domain_model_service import DomainModelService
from business.product.task_service import TaskService


def test_search_plan_supplier_and_buyer_queries():
    task = TaskService().understand("毛毡")
    plan = DiscoveryService().plan(task, DomainModelService().build(task))
    assert plan.queries and plan.sources and plan.priority
    joined = " ".join(plan.queries).lower()
    assert "supplier" in joined and "manufacturer" in joined
    assert "importer" in joined and "buyer" in joined
    assert "Industrial Felt supplier" in plan.queries
