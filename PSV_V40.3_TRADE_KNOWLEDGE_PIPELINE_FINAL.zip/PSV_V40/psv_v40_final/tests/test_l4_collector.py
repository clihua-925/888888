"""Test 4：L4 Raw 保存 + 净化 + CollectorManager 策略降级（全部注入假 fetcher，不触网）。"""
import os
import tempfile
from contracts.search_plan import SearchPlan
from business.trade.collector import TradeDataCollector, CollectorManager
from business.trade.collector.http_collector import HttpCollector
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.collector_repository import CollectorLogRepository


class _FakeFetcher:
    """模拟一次成功取数（返回真实形态 HTML 文本，不含任何编造企业数据）。"""
    def fetch(self, url, keyword=None):
        html = "<html><body>Industrial Felt supplier - 120 shipments to US importer</body></html>"
        return html, url, None


class _FakeHttp(HttpCollector):
    collector_type = "http"
    def fetch(self, url):
        html = "<html><body>Industrial Felt supplier - 120 shipments to US importer</body></html>"
        return html, url, None


class _FailingHttp(HttpCollector):
    collector_type = "http"
    def fetch(self, url):
        from business.trade.collector.http_collector import FetchError
        raise FetchError("boom")


def test_raw_page_saved():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        plan = SearchPlan(queries=["Industrial Felt supplier"], sources=["importyeti"],
                          directions=[], priority=["importyeti"])
        c = TradeDataCollector(raw_repo=RawRepository(conn), collectors=None,
                               manager=CollectorManager(http=_FakeHttp(),
                                                        log_repo=CollectorLogRepository(conn)))
        ids = c.collect(plan)
        assert len(ids) >= 1
        rows = RawRepository(conn).list_by_ids(ids)
        assert any(r["page_type"] == "homepage" for r in rows), "应保存首页"
        srow = next(r for r in rows if r["page_type"] == "search_result")
        assert srow["keyword"] == "Industrial Felt supplier" and srow["page_number"] == 1
        row = rows[0]
        assert row["source"] == "importyeti" and row["url"]
        assert row["html_path"] and os.path.exists(row["html_path"])
        assert row["fetched_at"] and row["browser_session"] and row["content_hash"]
    finally:
        conn.close(); os.unlink(path)


def test_manager_records_failure():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        log = CollectorLogRepository(conn)
        mgr = CollectorManager(http=_FailingHttp(), log_repo=log)
        try:
            mgr.fetch("http://x", keyword="felt")
            assert False, "应当全链失败"
        except Exception:
            pass
        fails = log.recent_failures()
        assert fails and fails[0]["collector_type"] == "http"
        assert "retry_count" in fails[0] and fails[0]["occurred_at"]
    finally:
        conn.close(); os.unlink(path)


def test_purifier_drops_junk():
    from business.shared.page_purifier import purify
    keep, _ = purify("https://www.importyeti.com/search?q=x", "supplier 100 shipments")
    drop, reason = purify("https://en.wikipedia.org/wiki/Felt", "Felt is a textile")
    assert keep and not drop and reason.startswith("junk_domain")
