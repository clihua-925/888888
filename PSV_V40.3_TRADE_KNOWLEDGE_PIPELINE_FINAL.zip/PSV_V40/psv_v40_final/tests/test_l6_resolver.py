"""Test 6：L6 Entity Resolution —— 后缀变体 + 相似度 + 国家归一。"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.extracted_repository import ExtractedRepository
from data.repository.entity_repository import EntityRepository
from business.trade.entity_resolver import (EntityResolver, normalize_key, name_similarity,
                                            normalize_country)


def test_suffix_variants_merge():
    assert normalize_key("Shinwon Felt Co.") == normalize_key("Shinwon Felt Ltd.")
    assert name_similarity("Shinwon Felt Co.", "Shinwon Felts Ltd.") >= 0.9
    assert normalize_country("USA") == "USA" and normalize_country("south korea") == "Korea"
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        raw = RawRepository(conn); ext = ExtractedRepository(conn)
        rid = raw.create("importyeti", "http://iy/1", None, "x")
        e1 = ext.create(rid, "Shinwon Felt Co.", role_candidate="supplier",
                        country_candidate="Korea", evidence="180 shipments")
        e2 = ext.create(rid, "Shinwon Felt Ltd.", role_candidate="supplier",
                        country_candidate="Korea", evidence="180 shipments")
        pairs = EntityResolver(conn=conn).resolve([e1, e2])
        assert len({ent for _, ent in pairs}) == 1
        ent = EntityRepository(conn).get(pairs[0][1])
        assert "Shinwon Felt Ltd." in ent["aliases"]
        assert ent["country"] == "Korea"
    finally:
        conn.close(); os.unlink(path)
