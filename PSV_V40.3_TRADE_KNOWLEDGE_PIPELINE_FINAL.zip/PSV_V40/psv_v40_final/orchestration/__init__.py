"""Orchestration Layer: 只有 LangGraph 流程定义，节点只读 state / 调 service / 写 state。"""
