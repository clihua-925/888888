"""LangGraph State。只做组合，不定义业务字段；字段全部来自 contracts。"""
from __future__ import annotations
from typing import Optional
from typing_extensions import TypedDict
from contracts.task import TaskObject
from contracts.product import ProductKnowledgeModel
from contracts.search_plan import SearchPlan


class PipelineState(TypedDict, total=False):
    user_input: str                                   # 原始输入，例如 "毛毡"
    task: Optional[TaskObject]                        # L1
    product_model: Optional[ProductKnowledgeModel]    # L2
    search_plan: Optional[SearchPlan]                 # L3
    raw_page_ids: list[int]                           # L4
    std_ids: list[int]                                # L5 标准化数据
    shipment_ids: list[int]                           # L7 Trade Shipment
    edge_ids: list[int]                               # L7 Trade Edge
    customer_queue_stats: dict                        # L6 队列统计
    customer_profile_ids: list[int]                   # L6 客户画像
    resolved_map: dict[int, int]                      # L6: extracted_id -> entity_id
    entity_ids: list[int]                             # L6
    shipment_ids: list[int]                           # L7
    edge_ids: list[int]                               # L7
    fused_profiles: dict                              # L8
    graph_metrics: dict                               # L9
    report: Optional[dict]                            # L10
