"""流水线执行器。

优先使用 LangGraph 编译后的图；未安装 langgraph 时按 _NODES 顺序纯 Python 执行
（节点函数本身与图定义一致，行为等价，便于无依赖环境验收 L1-L3）。
"""
from __future__ import annotations
from orchestration.graph import _NODES
from orchestration.state import PipelineState


def run_pipeline(user_input: str) -> PipelineState:
    state: PipelineState = {"user_input": user_input}
    try:
        from langgraph.graph import StateGraph, END
    except ImportError:
        graph = None
    if graph is not None:
        g = StateGraph(PipelineState)
        for name, fn in _NODES.items():
            g.add_node(name, fn)
        names = list(_NODES)
        for a, b in zip(names, names[1:]):
            g.add_edge(a, b)
        g.set_entry_point(names[0])
        g.add_edge(names[-1], END)
        return g.compile().invoke(state)
    for fn in _NODES.values():
        state.update(fn(state))
    return state
