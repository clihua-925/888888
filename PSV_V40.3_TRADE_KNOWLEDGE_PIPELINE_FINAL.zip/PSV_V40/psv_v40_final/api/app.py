"""FastAPI 应用：任务创建/状态/结果/图谱 + 静态前端托管。

启动：uvicorn api.app:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from api.task_manager import get_manager

app = FastAPI(title="PSV V40.3 — Supply Chain Knowledge Agent")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")


class TaskCreate(BaseModel):
    product: str
    country: str | None = None        # 美国 / 德国 / 日本 ...
    goal: str | None = None           # 供应商分析 / 采购商分析 / 市场分析


@app.get("/")
def index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


@app.post("/task/create")
def create_task(body: TaskCreate):
    parts = [body.product]
    if body.country:
        parts.append(f"销往 {body.country}")
    if body.goal:
        parts.append(f"目标 {body.goal}")
    tid = get_manager().create(" ".join(parts))
    return {"task_id": tid}


@app.get("/task/status/{tid}")
def task_status(tid: str):
    s = get_manager().status(tid)
    if not s:
        raise HTTPException(404, "task not found")
    return s


@app.get("/task/result/{tid}")
def task_result(tid: str):
    r = get_manager().result(tid)
    if not r:
        raise HTTPException(404, "result not ready")
    return r


@app.get("/graph/{tid}")
def task_graph(tid: str):
    g = get_manager().graph(tid)
    if not g:
        raise HTTPException(404, "graph not ready")
    return g


@app.get("/runs/list")
def runs_list():
    return {"runs": get_manager().list_runs()}


@app.get("/runs/file/{name}")
def runs_file(name: str):
    d = get_manager().read_run(name)
    if not d:
        raise HTTPException(404, "run file not found")
    return d


@app.get("/health")
def health():
    return {"ok": True, "version": "V40.3"}
