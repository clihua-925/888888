"""API Layer: FastAPI 接口 + 任务管理。业务仍全部经 orchestration/business，本层只做 HTTP 适配。"""
