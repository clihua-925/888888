"""L2 Domain Modeling：建立 ProductKnowledgeModel。

毛毡领域模型使用内置领域种子（分类/应用/同义词/HS 候选来自既有行业配置知识重新整理）；
配置 LLM 时可在种子基础上做扩展增强，扩展失败不影响基线输出。
"""
from __future__ import annotations
from contracts.task import TaskObject
from contracts.product import ProductKnowledgeModel, CategoryNode
from ai.client import AIClient, AIClientError
from ai.prompts import DOMAIN_MODELING_PROMPT

# 领域种子：毛毡（来自行业配置知识的重新整理，不复制旧代码）
_FELT_MODEL = ProductKnowledgeModel(
    product_name="Felt",
    categories=[
        CategoryNode(name="Industrial Felt", children=[
            CategoryNode(name="Wool Industrial Felt"),
            CategoryNode(name="Synthetic Industrial Felt"),
        ]),
        CategoryNode(name="Decorative Felt"),
        CategoryNode(name="Automotive Felt"),
        CategoryNode(name="Craft Felt"),
    ],
    applications=["filtration", "gasket & sealing", "oil absorption", "sound insulation",
                  "polishing", "craft & DIY", "automotive interior", "furniture padding"],
    aliases=["wool felt", "synthetic felt", "needle-punched felt", "pressed felt", "nonwoven felt"],
    hs_candidates=["5602", "5911", "5603"],
)


class DomainModelService:
    def __init__(self, ai: AIClient | None = None) -> None:
        self._ai = ai or AIClient()

    def build(self, task: TaskObject) -> ProductKnowledgeModel:
        base = self._baseline(task.product)
        if self._ai.configured:
            try:
                data = self._ai.chat(DOMAIN_MODELING_PROMPT, {"product": task.product})
                return self._merge(base, data)
            except AIClientError:
                pass
        return base

    def _baseline(self, product: str) -> ProductKnowledgeModel:
        if product in ("毛毡", "Felt", "felt"):
            return _FELT_MODEL.model_copy(deep=True)
        p = product.strip().title()
        return ProductKnowledgeModel(product_name=p,
                                     categories=[CategoryNode(name=p)],
                                     applications=[], aliases=[p.lower()],
                                     hs_candidates=[])

    def _merge(self, base: ProductKnowledgeModel, data: dict) -> ProductKnowledgeModel:
        """LLM 扩展只增不覆盖：新增的分类/应用/别名/HS 并入基线。"""
        try:
            cats = [c.name for c in base.categories] + [x["name"] for x in data.get("categories", []) if x.get("name")]
            new_cats = [c for c in dict.fromkeys(cats)]
            return base.model_copy(update={
                "categories": base.categories + [CategoryNode(name=n) for n in new_cats if n not in {c.name for c in base.categories}],
                "applications": list(dict.fromkeys(base.applications + data.get("applications", []))),
                "aliases": list(dict.fromkeys(base.aliases + data.get("aliases", []))),
                "hs_candidates": list(dict.fromkeys(base.hs_candidates + data.get("hs_candidates", []))),
            })
        except Exception:
            return base
