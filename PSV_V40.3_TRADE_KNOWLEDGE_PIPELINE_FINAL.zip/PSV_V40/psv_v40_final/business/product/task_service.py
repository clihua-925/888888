"""L1 Task Understanding：把用户输入（如"毛毡"）理解为 TaskObject。

双路径：
- 配置了 LLM：经 ai/client 走 TASK_UNDERSTANDING_PROMPT（AI 失败自动降级到规则路径）
- 未配置：确定性规则基线（产品标准化中英文映射 + 默认市场），不伪造 AI 结果
"""
from __future__ import annotations
import re
from contracts.task import TaskObject
from ai.client import AIClient, AIClientError
from ai.prompts import TASK_UNDERSTANDING_PROMPT

_PRODUCT_ZH_EN = {"毛毡": "Felt", "毛毡布": "Felt"}
_DEFAULT_MARKET = "美国"
_DEFAULT_GOAL = "供应链结构分析"
_DEFAULT_COMPANY_TYPES = ["manufacturer", "supplier", "exporter", "importer", "buyer", "distributor"]


class TaskService:
    def __init__(self, ai: AIClient | None = None) -> None:
        self._ai = ai or AIClient()

    def understand(self, user_input: str) -> TaskObject:
        text = (user_input or "").strip()
        if not text:
            raise ValueError("任务输入为空")
        if self._ai.configured:
            try:
                data = self._ai.chat(TASK_UNDERSTANDING_PROMPT, {"user_input": text})
                return TaskObject(**data)
            except AIClientError:
                pass  # 降级规则路径
        return self._rule_based(text)

    def _rule_based(self, text: str) -> TaskObject:
        product = _PRODUCT_ZH_EN.get(text, text)
        market = _DEFAULT_MARKET
        m = re.search(r"([\u4e00-\u9fffA-Za-z ]+?)\s*(?:销往|出口到|目标|market[::]?)\s*([\u4e00-\u9fffA-Za-z]+)", text)
        if m:
            product = _PRODUCT_ZH_EN.get(m.group(1).strip(), product)
            market = m.group(2).strip()
        return TaskObject(product=product, target_market=market, target_country=None,
                          company_types=list(_DEFAULT_COMPANY_TYPES), analysis_goal=_DEFAULT_GOAL)
