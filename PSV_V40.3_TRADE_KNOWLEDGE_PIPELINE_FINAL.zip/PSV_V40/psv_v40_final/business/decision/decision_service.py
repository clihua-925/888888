"""L10 Decision Intelligence：组织 L1-L9 产物为最终商业报告。

格式（V40.1）：产品 / 市场 / 主要供应商 / 主要采购商 / 贸易关系 / 证据 / 风险 / 机会。
"""
from __future__ import annotations


class DecisionService:
    def report(self, state: dict) -> dict:
        metrics = state.get("graph_metrics") or {}
        profiles = state.get("fused_profiles") or {}
        product = state.get("product_model")
        task = state.get("task")

        suppliers = metrics.get("supplier_analysis", [])
        buyers = metrics.get("buyer_analysis", [])
        evidence = self._evidence_summary(profiles)
        return {
            "product": getattr(product, "product_name", None),
            "market": getattr(task, "target_market", None),
            "product_analysis": {
                "categories": [c.name for c in getattr(product, "categories", [])],
                "applications": getattr(product, "applications", []),
                "hs_candidates": getattr(product, "hs_candidates", []),
            },
            "top_suppliers": suppliers,
            "top_buyers": buyers,
            "trade_relations": {
                "edge_count": metrics.get("edge_count", 0),
                "shipment_count": metrics.get("shipment_count", 0),
                "country_distribution": metrics.get("country_distribution", {}),
                "trade_strength": metrics.get("trade_strength", {}),
            },
            "evidence": evidence,
            "company_profiles": profiles,
            "opportunities": self._opportunities(suppliers, buyers, metrics),
            "risks": metrics.get("risks", []),
        }

    @staticmethod
    def _evidence_summary(profiles: dict) -> dict:
        urls = sorted({u for p in profiles.values() for u in p.get("source_urls", [])})
        total_ev = sum(p.get("evidence_count", 0) for p in profiles.values())
        return {"total_evidence": total_ev, "source_urls": urls[:20]}

    @staticmethod
    def _opportunities(suppliers: list, buyers: list, metrics: dict) -> list[str]:
        ops: list[str] = []
        if buyers and not suppliers:
            ops.append("检测到买家需求但供应商证据不足：优先补强 supplier 侧采集")
        if suppliers:
            ops.append(f"已识别 {len(suppliers)} 家候选供应商（按连接买家数排序），可进入深度尽调")
        if len(buyers) >= 3:
            ops.append("买家网络分散，存在多通道进入机会")
        if metrics.get("concentration_top3_share", 1) < 0.4 and suppliers:
            ops.append("供应商集中度低，新进入者存在空间")
        if metrics.get("shipment_count", 0) >= 3:
            ops.append("已存在可验证的 shipment 事件链，可开展对手方渗透分析")
        if not ops:
            ops.append("数据尚不足以生成机会判断，建议扩充 Raw 采集量")
        return ops
