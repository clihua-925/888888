"""Business Layer: 全部业务逻辑唯一住处。禁止访问 db（只能经 repository），禁止直接调 LLM（只能经 ai/client）。"""
