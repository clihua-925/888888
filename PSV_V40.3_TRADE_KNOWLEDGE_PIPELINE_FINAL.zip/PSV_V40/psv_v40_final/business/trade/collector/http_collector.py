"""HTTP 采集策略（fallback 层）：标准库实现，UA 伪装，超时控制。"""
from __future__ import annotations
import urllib.request


class FetchError(RuntimeError):
    pass


class HttpCollector:
    collector_type = "http"

    def __init__(self, timeout: int = 15) -> None:
        self._timeout = timeout
        self._ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

    def fetch(self, url: str) -> tuple[str, str]:
        """返回 (html, final_url)。失败抛 FetchError，由 Manager 记录并降级。"""
        req = urllib.request.Request(url, headers={"User-Agent": self._ua,
                                                   "Accept-Language": "en-US,en;q=0.9"})
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return resp.read().decode("utf-8", errors="replace"), resp.geturl()
        except Exception as e:
            raise FetchError(f"{url}: {e}") from e
