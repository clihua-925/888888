"""ImportYeti 采集器 = L4 Browser Agent（驱动注入：浏览器优先，HTTP 降级）。"""
from __future__ import annotations
from business.trade.collector.browser_agent import BrowserAgentCollector
from business.trade.collector.browser_driver import BrowserDriver, BrowserUnavailable
from business.trade.collector.http_driver import HttpDriver


def build_importyeti_collector(manager_fetch, raw_repo=None, max_pages: int = 3,
                               max_detail_pages: int = 3):
    """按可用性选择驱动：浏览器（真实用户操作）优先，HTTP 降级。"""
    driver = None
    try:
        d = BrowserDriver(max_pages=3)
        d._pw()  # 仅探测 playwright 是否可用
        driver = d
    except BrowserUnavailable:
        driver = None
    if driver is None:
        driver = HttpDriver(manager_fetch, max_pages=max_pages)
    return BrowserAgentCollector(driver=driver, raw_repo=raw_repo,
                                 max_pages=max_pages, max_detail_pages=max_detail_pages)


class ImportYetiCollector(BrowserAgentCollector):
    """兼容旧构造签名：fetch_fn 注入时走 HTTP 降级驱动。"""
    def __init__(self, fetch_fn=None, **kw):
        from business.trade.collector.http_driver import HttpDriver
        driver = kw.pop("driver", None) or HttpDriver(fetch_fn, max_pages=kw.get("max_pages", 3))
        super().__init__(driver=driver, **kw)
