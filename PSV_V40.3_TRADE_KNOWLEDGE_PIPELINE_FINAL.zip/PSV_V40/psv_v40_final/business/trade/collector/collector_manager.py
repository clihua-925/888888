"""采集策略管理器：Browser → HTTP fallback，失败留痕（collector_failures）。

浏览器策略基于 BrowserDriver 会话：每次取数 start→取页面→stop（只关 page + 断开 CDP），
绝不调用 browser.close()——共享 Chrome 由 start_ai_browser.bat 管理，登录态属于用户。
"""
from __future__ import annotations
from business.trade.collector.browser_driver import BrowserDriver, BrowserUnavailable
from business.trade.collector.http_collector import HttpCollector, FetchError


class _BrowserFetchAdapter:
    """把 BrowserDriver 适配成 manager 的 fetch(url)->(html, final_url, shot) 接口。"""
    collector_type = "browser"

    def __init__(self, driver: BrowserDriver) -> None:
        self._d = driver

    def fetch(self, url: str):
        self._d.start()
        try:
            self._d._ensure_page()
            page = self._d._page
            page.goto(url, timeout=self._d._timeout, wait_until="domcontentloaded")
            page.wait_for_timeout(2500)
            page.mouse.wheel(0, 2500)
            page.wait_for_timeout(1000)
            return page.content(), page.url, page.screenshot(full_page=False)
        finally:
            self._d.stop()  # 只关 page、断开 CDP；共享 Chrome 保持运行


class CollectorManager:
    def __init__(self, browser=None, http: HttpCollector | None = None,
                 log_repo=None, max_retries: int = 1) -> None:
        self._browser = browser or _BrowserFetchAdapter(BrowserDriver())
        self._http = http or HttpCollector()
        self._log = log_repo
        self._max_retries = max_retries
        self.last_strategy: str | None = None

    def fetch(self, url: str, keyword: str | None = None) -> tuple[str, str, bytes | None]:
        errors: list[str] = []
        for stype, s in (("browser", self._browser), ("http", self._http)):
            for attempt in range(self._max_retries + 1):
                try:
                    html, final, shot = s.fetch(url)
                    self.last_strategy = stype
                    return html, final, shot
                except Exception as e:
                    errors.append(f"{stype}#{attempt}: {e}")
                    self._record(stype, str(e)[:500], keyword, attempt)
                    if stype == "browser":
                        break  # 浏览器层失败不硬重试，直接降级
        raise FetchError(" | ".join(errors))

    def _record(self, collector_type: str, error: str, keyword: str | None, attempt: int) -> None:
        if self._log is not None:
            try:
                self._log.log_failure(collector_type=collector_type, error=error,
                                      keyword=keyword, retry_count=attempt)
            except Exception:
                pass
