"""页面快照：HTML/Text 落盘（截图由 BrowserCollector 在可用时附加）。"""
from __future__ import annotations
import os
import re

STORAGE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))))), "storage", "files")

_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")


def html_to_text(html: str) -> str:
    text = _TAG_RE.sub(" ", html or "")
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'")):
        text = text.replace(a, b)
    return _WS_RE.sub(" ", text).strip()


class PageSnapshot:
    """把采集到的页面保存为 raw_{id}.html / raw_{id}.txt / raw_{id}.png。"""

    def __init__(self, storage_dir: str = STORAGE_DIR) -> None:
        self._dir = storage_dir
        os.makedirs(self._dir, exist_ok=True)

    def save_html(self, raw_id: int, html: str) -> str:
        path = os.path.join(self._dir, f"raw_{raw_id}.html")
        with open(path, "w", encoding="utf-8") as f:
            f.write(html or "")
        return path

    def save_text(self, raw_id: int, text: str) -> str:
        path = os.path.join(self._dir, f"raw_{raw_id}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(text or "")
        return path

    def save_screenshot(self, raw_id: int, png_bytes: bytes) -> str:
        path = os.path.join(self._dir, f"raw_{raw_id}.png")
        with open(path, "wb") as f:
            f.write(png_bytes)
        return path
