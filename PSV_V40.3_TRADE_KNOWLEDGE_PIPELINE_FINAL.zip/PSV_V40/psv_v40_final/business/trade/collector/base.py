"""采集器基类。L4 的唯一职责：最大化采集真实原始数据。

不理解业务：不判断谁是供应商/采购商，不输出任何实体结论。
每页落库字段：page_type / keyword / page_number / html(落盘) / text / title /
screenshot / timestamp / browser_session / content_hash / quality_score。
"""
from __future__ import annotations
import hashlib
import os
from contracts.search_plan import SearchPlan

STORAGE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))))), "storage", "files")


class RawSaveError(RuntimeError):
    pass


def content_hash(html: str) -> str:
    return hashlib.sha256((html or "").encode("utf-8", errors="replace")).hexdigest()[:16]


def quality_score(text: str | None, html: str | None) -> float:
    """页面质量启发式：贸易信号越密、内嵌数据越全，分越高（0-1）。"""
    body = ((text or "") + " " + (html or "")).lower()
    signals = ["shipment", "shipper", "consignee", "supplier", "importer",
               "exporter", "hs code", "bill of lading", "__next_data__", "/company/"]
    hits = sum(1 for s in signals if s in body)
    return round(min(1.0, 0.15 + hits * 0.12), 2)


class BaseCollector:
    name: str = "base"

    def __init__(self, snapshot=None, raw_repo=None, max_pages: int = 3,
                 keyword: str | None = None) -> None:
        from business.trade.collector.page_snapshot import PageSnapshot
        from data.repository.raw_repository import RawRepository
        self._snap = snapshot or PageSnapshot()
        self._repo = raw_repo or RawRepository()
        self._max = max_pages
        self._keyword = keyword

    def collect(self, plan: SearchPlan) -> list[int]:
        raise NotImplementedError

    def _save_raw(self, url: str, html: str | None, text: str | None,
                  search_plan_id: int | None = None,
                  keyword: str | None = None, page_number: int = 1,
                  page_type: str = "unknown", title: str | None = None,
                  browser_session: str | None = None,
                  screenshot: bytes | None = None) -> int:
        raw_id = self._repo.create(
            source=self.name, url=url, html_path=None, text=text,
            search_plan_id=search_plan_id, keyword=keyword or self._keyword,
            page_number=page_number, page_type=page_type, title=title,
            browser_session=browser_session,
            content_hash=content_hash(html), quality_score=quality_score(text, html))
        try:
            os.makedirs(STORAGE_DIR, exist_ok=True)
            if html is not None:
                self._repo.update_html_path(raw_id, self._snap.save_html(raw_id, html))
                self._snap.save_text(raw_id, text or "")
            if screenshot:
                self._repo.update_screenshot(raw_id, self._snap.save_screenshot(raw_id, screenshot))
        except OSError as e:
            raise RawSaveError(f"Raw 落盘失败 raw_id={raw_id}: {e}") from e
        return raw_id
