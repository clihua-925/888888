"""页面驱动抽象：Browser Agent 只与驱动交互，模拟真实用户操作步骤。

真实驱动（BrowserDriver）：Chrome CDP + playwright，执行
  开首页 → 识别搜索框 → 输入关键词 → 回车 → 等待 → 翻页 → 点公司链接 → 点贸易详情。
降级驱动（HttpDriver）：无浏览器环境使用，行为模式相同但标记 driver_type=http。
测试注入 FakeDriver 即可离线验证全链。
"""
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class PageBundle:
    html: str
    url: str
    page_type: str                      # homepage / search_result / company_detail / shipment_detail
    keyword: str | None = None
    page_number: int = 1
    title: str | None = None
    screenshot: bytes | None = None


class BaseDriver:
    driver_type: str = "base"

    def start(self) -> None:
        """会话开始（浏览器驱动建立连接；无状态驱动为空操作）。"""

    def stop(self) -> None:
        """会话结束。铁律：只释放本进程占用的页面/资源，绝不关闭共享浏览器进程。"""

    def homepage(self) -> PageBundle:
        raise NotImplementedError

    def search(self, keyword: str, max_pages: int = 3) -> list[PageBundle]:
        raise NotImplementedError

    def company_detail(self, slug: str) -> PageBundle | None:
        raise NotImplementedError

    def shipment_detail(self, url: str) -> PageBundle | None:
        raise NotImplementedError


@dataclass
class BrowserSession:
    """browser_session 记录：随每页 Raw 落库。"""
    driver_type: str
    started_at: str
    login_status: str = "unknown"
    pages_visited: int = 0
    extra: dict = field(default_factory=dict)

    def tick(self) -> None:
        self.pages_visited += 1

    def as_text(self) -> str:
        import json
        return json.dumps({"driver_type": self.driver_type,
                           "started_at": self.started_at,
                           "login_status": self.login_status,
                           "pages_visited": self.pages_visited, **self.extra},
                          ensure_ascii=False)
