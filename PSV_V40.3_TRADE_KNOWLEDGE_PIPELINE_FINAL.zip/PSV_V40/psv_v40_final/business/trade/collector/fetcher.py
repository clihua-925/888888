"""网络取数通道。Collector 的唯一网络出口，便于测试替换与超时控制。"""
from __future__ import annotations
import urllib.request


class FetchError(RuntimeError):
    pass


class UrllibFetcher:
    """真实 HTTP 抓取（标准库实现，UA 伪装，10s 超时）。"""

    def __init__(self, timeout: int = 10) -> None:
        self._timeout = timeout
        self._ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

    def fetch(self, url: str) -> tuple[str, str]:
        """返回 (html, final_url)。失败抛 FetchError。"""
        req = urllib.request.Request(url, headers={"User-Agent": self._ua,
                                                   "Accept-Language": "en-US,en;q=0.9"})
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return resp.read().decode("utf-8", errors="replace"), resp.geturl()
        except Exception as e:
            raise FetchError(f"{url}: {e}") from e
