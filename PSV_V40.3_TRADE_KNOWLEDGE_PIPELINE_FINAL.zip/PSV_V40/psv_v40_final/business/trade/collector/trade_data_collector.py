"""L4 采集调度（图节点入口）：按 sources/priority 分发，经 CollectorManager 策略链取数。"""
from __future__ import annotations
from contracts.search_plan import SearchPlan
from business.trade.collector.base import BaseCollector
from business.trade.collector.collector_manager import CollectorManager
from business.trade.collector.importyeti_collector import ImportYetiCollector
from data.repository.collector_repository import CollectorLogRepository


class TradeDataCollector:
    def __init__(self, collectors: list[BaseCollector] | None = None,
                 manager: CollectorManager | None = None,
                 raw_repo=None, max_pages_per_source: int = 3,
                 log_repo=None) -> None:
        if log_repo is None:
            conn = getattr(raw_repo, "_conn", None)
            log_repo = CollectorLogRepository(conn) if conn is not None else CollectorLogRepository()
        self._manager = manager or CollectorManager(log_repo=log_repo)
        self._collectors = collectors if collectors is not None else [
            ImportYetiCollector(fetch_fn=self._manager.fetch,
                                raw_repo=raw_repo, max_pages=max_pages_per_source),
        ]

    def collect(self, plan: SearchPlan) -> list[int]:
        ids: list[int] = []
        order = {s: i for i, s in enumerate(plan.priority or [])}
        for c in sorted(self._collectors, key=lambda c: order.get(c.name, 99)):
            ids.extend(c.collect(plan))
        return ids
