"""L4 Browser Agent：模拟真实用户操作采集 ImportYeti 全类页面。

流程：启动检查 → 首页（homepage）→ 理解页面状态 → 按 L3 Search Plan 逐关键词搜索
（search_result，多页）→ 发现公司链接 → 公司详情（company_detail）→ 贸易详情（shipment_detail）。
L4 不理解业务：只保存网页/HTML/文本/截图/URL/时间/页面关系。
"""
from __future__ import annotations
import time
from contracts.search_plan import SearchPlan
from business.trade.collector.base import BaseCollector
from business.trade.collector.driver import BaseDriver, BrowserSession
from business.trade.collector.page_snapshot import html_to_text
from business.trade.collector.http_driver import extract_company_slugs, find_shipment_link
from business.shared.page_purifier import purify


class BrowserAgentCollector(BaseCollector):
    name = "importyeti"

    def __init__(self, driver: BaseDriver, max_detail_pages: int = 3, **kw) -> None:
        super().__init__(**kw)
        self._driver = driver
        self._max_detail = max_detail_pages

    def collect(self, plan: SearchPlan) -> list[int]:
        ids: list[int] = []
        try:
            self._driver.start()   # 会话开始：连接一次复用
        except Exception:
            pass
        try:
            return self._collect_inner(plan, ids)
        finally:
            try:
                self._driver.stop()  # 只释放页面，不关共享浏览器
            except Exception:
                pass

    def _collect_inner(self, plan: SearchPlan, ids: list[int]) -> list[int]:
        session = BrowserSession(
            driver_type=getattr(self._driver, "driver_type", "unknown"),
            started_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
            login_status=getattr(self._driver, "login_status", "unknown"),
        )
        sess = session.as_text()

        # Step 2: 首页进入
        try:
            home = self._driver.homepage()
            session.tick()
            rid = self._save(home, session, plan, sess)
            if rid > 0: ids.append(rid)
        except Exception:
            pass  # 首页失败不中断，继续按关键词搜索

        # Step 4-8: 按 Search Plan 执行
        for q in plan.queries[: self._max]:
            try:
                pages = self._driver.search(q, max_pages=3)
            except Exception:
                continue
            search_html = ""
            for pg in pages:
                session.tick()
                rid = self._save(pg, session, plan, sess)
                if rid > 0: ids.append(rid)
                search_html += pg.html or ""
            for slug in extract_company_slugs(search_html)[: self._max_detail]:
                cp = self._driver.company_detail(slug)
                if cp is None:
                    continue
                session.tick()
                cid = self._save(cp, session, plan, sess)
                if cid > 0: ids.append(cid)
                link = find_shipment_link(cp.html, "https://www.importyeti.com")
                if link:
                    sp = self._driver.shipment_detail(link)
                    if sp is not None:
                        session.tick()
                        sid = self._save(sp, session, plan, sess)
                        if sid > 0: ids.append(sid)
        return ids

    def _save(self, pg, session: BrowserSession, plan: SearchPlan, sess_text: str) -> int:
        text = html_to_text(pg.html)
        keep, _ = purify(pg.url, text)
        if not keep and pg.page_type != "homepage":
            return -1  # 无贸易信号页不落库（首页除外，作为流程证据）
        raw_id = self._save_raw(pg.url, pg.html, text,
                                keyword=pg.keyword, page_number=pg.page_number,
                                page_type=pg.page_type, title=pg.title,
                                browser_session=sess_text,
                                screenshot=pg.screenshot)
        session.extra["last_page_type"] = pg.page_type
        return raw_id
