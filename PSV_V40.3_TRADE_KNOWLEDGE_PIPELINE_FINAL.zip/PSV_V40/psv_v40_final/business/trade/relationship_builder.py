"""L7 Trade Relationship Construction：从 ImportYeti 提单/客户关系数据发现真实贸易关系。

职责：
  输入：L5 standard_company_data（供应商标准信息）+ L4 raw 中 IY 公司贸易页面
  流程：读取供应商 IY 页面 Customers/Shipment Records -> 提取客户候选
        -> 调用 L6 CustomerCompletionService（AI 验证/去重/画像，队列处理）
        -> 建立 Trade Shipment（supplier/customer/product/shipment_date/evidence/source_url/raw_page_id）
        -> 建立 Trade Edge：Supplier -[SUPPLIES]-> Customer（含 shipment_id/evidence/source_url/confidence）
  注意：供应商不做深度分析（不补全、不验证），保留 L5 标准化信息即可；
        供应商页面中的 Suppliers 区块不进入深度分析。
"""
from __future__ import annotations
import json
import re
import sqlite3
from data.db import connect
from data.repository.standard_company_repository import StandardCompanyRepository
from data.repository.raw_repository import RawRepository
from data.repository.entity_repository import EntityRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository
from business.trade.customer_service import CustomerCompletionService
from business.trade.entity_resolver import normalize_key

_NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)
_CONSIGNEE_RE = re.compile(r"Consignee[^\n:]{0,20}:\s*([A-Z][A-Za-z0-9&.,'\-\s]{2,60})", re.I)


class RelationshipBuilder:
    def __init__(self, conn: sqlite3.Connection | None = None,
                 customer_service: CustomerCompletionService | None = None) -> None:
        c = conn or connect()
        self._std = StandardCompanyRepository(c)
        self._raw = RawRepository(c)
        self._ent = EntityRepository(c)
        self._edge = EdgeRepository(c)
        self._ship = ShipmentRepository(c)
        self._customers = customer_service or CustomerCompletionService(conn=c)
        self.last_shipment_ids: list[int] = []

    def build(self, std_ids: list[int], raw_page_ids: list[int] | None = None) -> dict:
        """输入 L5 标准化数据 id 列表（+ 可选 raw 页）。返回 edge_ids/shipment_ids/customer_stats。"""
        std_rows = self._std.list_by_ids(std_ids)
        raw_pages = self._raw.list_by_ids(raw_page_ids or [])
        edge_ids: list[int] = []
        self.last_shipment_ids = []

        # 客户发现只计算一次（正反向审核：去重复 I/O）
        discovery = {id(row): self._discover_customers(row, raw_pages) for row in std_rows}
        for row in std_rows:
            self._ensure_supplier(row)          # 供应商：仅 L5 标准化信息
            for cust_name, cust_country, _ev, _conf in discovery[id(row)]:
                self._customers.enqueue(cust_name, cust_country, row["raw_page_id"])
        customer_stats = self._customers.process_pending()     # L7 调用 L6（队列 + AI 补全）

        # 客户补全后建 Shipment + SUPPLIES Edge
        for row in std_rows:
            supplier_id = self._ensure_supplier(row)
            for cust_name, cust_country, evidence, conf in discovery[id(row)]:
                cust_ent = self._find_customer_entity(cust_name)
                if cust_ent is None:
                    continue
                raw = self._raw.get(int(row["raw_page_id"])) or {}
                ship_id = self._ship.create(
                    supplier_id=supplier_id, buyer_id=cust_ent,
                    product=row.get("product"), quantity=None,
                    ship_date=None, source_url=row.get("source_url"),
                    evidence=evidence, confidence=conf,
                    raw_page_id=int(row["raw_page_id"]))
                self.last_shipment_ids.append(ship_id)
                edge_ids.append(self._edge.create(
                    supplier_id, cust_ent, "SUPPLIES", evidence, conf,
                    source_url=row.get("source_url"),
                    shipment_id=ship_id, raw_page_id=int(row["raw_page_id"])))
        return {"edge_ids": edge_ids, "shipment_ids": self.last_shipment_ids,
                "customer_stats": customer_stats}

    # ---- 供应商：仅用 L5 标准化信息建立/复用实体，不做补全 ----
    def _ensure_supplier(self, row: dict) -> int:
        found = self._ent.find_by_name("Company", row["company_name"])
        if found:
            return int(found["id"])
        return self._ent.create("Company", row["company_name"], aliases=[],
                                country=row.get("country"))

    # ---- 从 IY 公司贸易页提取客户候选（Customers / Shipment Records） ----
    def _discover_customers(self, row: dict, raw_pages: list[dict]):
        out = []
        key = normalize_key(row["company_name"])
        for page in raw_pages:
            if page.get("page_type") not in ("company_detail", "shipment_detail"):
                continue
            title = (page.get("title") or "").lower()
            url = (page.get("url") or "").lower()
            text = page.get("text") or ""
            if key not in normalize_key(title) and key not in normalize_key(url) \
               and key not in normalize_key(text[:400]):
                continue  # 只读该供应商自己的贸易页面
            html = page.get("html_path") and _read(page["html_path"]) or ""
            seen: set[str] = set()

            def _add(name, country, ev, conf):
                name = " ".join(name.split()).strip(" -|·–—")
                if len(name) < 3 or name.lower() in seen:
                    return
                seen.add(name.lower())
                out.append((name, country, ev, conf))

            m = _NEXT_DATA_RE.search(html)
            if m:
                try:
                    data = json.loads(m.group(1))
                except json.JSONDecodeError:
                    data = None
                if isinstance(data, (dict, list)):
                    stack = [data]
                    while stack:
                        cur = stack.pop()
                        if isinstance(cur, dict):
                            co = cur.get("consignee") or cur.get("customer") or cur.get("buyer")
                            if isinstance(co, str) and len(co) > 2:
                                _add(co, cur.get("country") if isinstance(cur.get("country"), str) else None,
                                     f"consignee {co} on supplier record", 0.65)
                            stack.extend(v for v in cur.values() if isinstance(v, (dict, list)))
                        elif isinstance(cur, list):
                            stack.extend(x for x in cur if isinstance(x, (dict, list)))
            for m2 in _CONSIGNEE_RE.finditer(text):
                _add(m2.group(1), None, f"Consignee: {m2.group(1)}", 0.6)
        return out

    def _find_customer_entity(self, name: str) -> int | None:
        key = normalize_key(name)
        for e in self._ent.list_all():
            if e["entity_type"] != "Company":
                continue
            if any(normalize_key(n) == key for n in [e["canonical_name"], *e["aliases"]]):
                return int(e["id"])
        return None


def _read(path: str) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""
