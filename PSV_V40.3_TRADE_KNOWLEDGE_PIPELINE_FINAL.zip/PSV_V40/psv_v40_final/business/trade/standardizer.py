"""L5 Data Standardization：trade_raw_pages -> standard_company_data。

职责边界（严格遵守）：
  做：把原始网页整理成标准字段（company_name/country/product/shipment_count/
      source_url/raw_page_id/original_text）
  不做：企业真实性判断、去重、企业画像、供应商/客户关系判断（那些属于 L6/L7/L8）
"""
from __future__ import annotations
import json
import re
import sqlite3
from data.db import connect
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository

_NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)
_TITLE_RE = re.compile(r"<title>([^<|]+)", re.I)
_SHIP_TXT_RE = re.compile(r"([\d,]{1,9})\s*[\+]?\s*Shipments", re.I)
_CARD_RE = re.compile(r"([A-Z][A-Za-z0-9&.,'\-\s]{2,60}?)\s*[\|·\-–—]\s*(\d[\d,]{0,9})\s+shipments", re.I)


class TradeStandardizer:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        c = conn or connect()
        self._raw = RawRepository(c)
        self._std = StandardCompanyRepository(c)

    def standardize(self, raw_page_ids: list[int]) -> list[int]:
        out: list[int] = []
        for rid in raw_page_ids or []:
            page = self._raw.get(rid)
            if not page:
                continue
            html = page.get("html_path") and _read(page["html_path"]) or ""
            text = page.get("text") or ""
            for row in self._rows(page, html, text):
                out.append(self._std.create(
                    raw_page_id=rid, company_name=row["company_name"],
                    country=row.get("country"), product=row.get("product"),
                    shipment_count=row.get("shipment_count"),
                    source_url=page.get("url"), original_text=row["original_text"]))
        return out

    def _rows(self, page: dict, html: str, text: str) -> list[dict]:
        rows: list[dict] = []
        seen: set[str] = set()

        def _add(name, ship=None, country=None, product=None, ev=""):
            name = " ".join((name or "").split()).strip(" -|·–—")
            if not name or len(name) < 3 or name.lower() in seen:
                return
            seen.add(name.lower())
            rows.append({"company_name": name, "country": country, "product": product,
                         "shipment_count": ship,
                         "original_text": ev or (f"{ship} shipments" if ship else name)})

        m = _NEXT_DATA_RE.search(html or "")
        if m:
            try:
                data = json.loads(m.group(1))
            except json.JSONDecodeError:
                data = None
            if isinstance(data, (dict, list)):
                stack = [data]
                while stack:
                    cur = stack.pop()
                    if isinstance(cur, dict):
                        ship = cur.get("shipments")
                        nm = cur.get("name") or cur.get("company_name")
                        if isinstance(ship, int) and ship > 0 and isinstance(nm, str) and len(nm) > 2:
                            _add(nm, ship, cur.get("country") if isinstance(cur.get("country"), str) else None)
                        stack.extend(v for v in cur.values() if isinstance(v, (dict, list)))
                    elif isinstance(cur, list):
                        stack.extend(x for x in cur if isinstance(x, (dict, list)))
        mt = _TITLE_RE.search(html or "")
        if mt and "importyeti" in (page.get("url") or ""):
            ms = _SHIP_TXT_RE.search(text or "")
            if ms:
                _add(mt.group(1).split(" - ")[0].split(" | ")[0], _to_int(ms.group(1)))
        for m2 in _CARD_RE.finditer(text or ""):
            _add(m2.group(1), _to_int(m2.group(2)))
        return rows


def _to_int(s: str) -> int | None:
    try:
        return int(str(s).replace(",", ""))
    except ValueError:
        return None


def _read(path: str) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""
