"""L8 Knowledge Fusion：把实体相关的边、shipment、证据、来源聚合成企业画像。

画像：company / products / countries / buyers / suppliers / shipments / confidence / source_urls。
数据来源：trade_shipments + trade_edges + trade_extracted_entities（多来源融合的 Raw 底座）。
"""
from __future__ import annotations
import sqlite3
from data.db import connect
from data.repository.entity_repository import EntityRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository


class FusionService:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        c = conn or connect()
        self._ent = EntityRepository(c)
        self._edge = EdgeRepository(c)
        self._ship = ShipmentRepository(c)

    def fuse(self, entity_ids: list[int]) -> dict[int, dict]:
        profiles: dict[int, dict] = {}
        for eid in entity_ids or []:
            ent = self._ent.get(eid)
            if not ent:
                continue
            ships_out = self._ship.list_by_supplier(eid)
            ships_in = self._ship.list_by_buyer(eid)
            edges = self._edge.list_by_source(eid) + self._edge.list_by_target(eid)
            all_ev = edges + ships_out + ships_in
            profiles[eid] = {
                "company": ent["canonical_name"],
                "entity_type": ent["entity_type"],
                "aliases": ent["aliases"],
                "countries": sorted({self._name(e["target_id"]) for e in edges
                                     if e["relation"] == "LOCATED_IN"}),
                "products": sorted({s["product"] for s in ships_out + ships_in if s["product"]}
                                   | {self._name(e["target_id"]) for e in edges
                                      if e["relation"] in ("PRODUCES", "EXPORTS", "IMPORTS")
                                      and self._type(e["target_id"]) == "Product"}),
                "buyers": sorted({self._name(s["buyer_id"]) for s in ships_out}),
                "suppliers": sorted({self._name(s["supplier_id"]) for s in ships_in}),
                "shipments": len(ships_out) + len(ships_in),
                "evidence_count": len(all_ev),
                "confidence": round(sum(float(x["confidence"]) for x in all_ev)
                                    / max(1, len(all_ev)), 3),
                "source_urls": sorted({x["source_url"] for x in all_ev if x.get("source_url")}),
            }
        return profiles

    def _name(self, entity_id: int) -> str:
        e = self._ent.get(entity_id)
        return e["canonical_name"] if e else str(entity_id)

    def _type(self, entity_id: int) -> str:
        e = self._ent.get(entity_id)
        return e["entity_type"] if e else ""
