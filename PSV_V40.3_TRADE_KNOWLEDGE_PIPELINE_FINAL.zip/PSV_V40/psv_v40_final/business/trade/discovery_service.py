"""L3 Discovery Planning：生成 Search Plan（查询词/数据源/方向/优先级）。

禁止采集。查询词由产品分类叶子节点 × {supplier,manufacturer,importer,buyer} 组合生成。
"""
from __future__ import annotations
from contracts.task import TaskObject
from contracts.product import ProductKnowledgeModel, CategoryNode
from contracts.search_plan import SearchPlan, SearchDirection

_SOURCES = ["importyeti", "usitc", "official_site", "b2b"]
_SUPPLIER_TERMS = ["manufacturer", "supplier", "exporter"]
_BUYER_TERMS = ["importer", "buyer", "distributor"]
_MAX_QUERIES = 24


class DiscoveryService:
    def plan(self, task: TaskObject, model: ProductKnowledgeModel) -> SearchPlan:
        leaves = [c.name for c in model.categories if isinstance(c, CategoryNode)] or [model.product_name]
        leaves = list(dict.fromkeys(leaves))[:6]
        queries: list[str] = []
        for leaf in leaves:
            for term in _SUPPLIER_TERMS + _BUYER_TERMS:
                queries.append(f"{leaf} {term}")
        queries = list(dict.fromkeys(queries))[:_MAX_QUERIES]
        return SearchPlan(
            queries=queries,
            sources=list(_SOURCES),
            directions=[SearchDirection.SUPPLIER_SIDE, SearchDirection.BUYER_SIDE,
                        SearchDirection.TRADE_EVIDENCE, SearchDirection.COMPANY_IDENTITY],
            priority=["importyeti", "usitc", "official_site", "b2b"],
        )
