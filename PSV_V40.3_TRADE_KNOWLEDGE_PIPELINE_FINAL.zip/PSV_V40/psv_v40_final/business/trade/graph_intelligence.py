"""L9 Graph Intelligence：基于 entities / edges / shipments 的图分析。

供应商分析：连接买家数、出口国家数、贸易次数、贸易强度
买家分析：采购来源数、产品范围
风险分析：单一供应来源、国家集中度、低置信度边
"""
from __future__ import annotations
import sqlite3
from collections import Counter, defaultdict
from data.db import connect
from data.repository.entity_repository import EntityRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository


class GraphIntelligence:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        c = conn or connect()
        self._ent = EntityRepository(c)
        self._edge = EdgeRepository(c)
        self._ship = ShipmentRepository(c)

    def analyze(self, edge_ids: list[int] | None = None) -> dict:
        entities = {e["id"]: e for e in self._ent.list_all()}
        name = lambda i: entities.get(i, {}).get("canonical_name", str(i))
        edges = self._edge.list_all()
        if edge_ids:
            keep = set(edge_ids)
            edges = [e for e in edges if e["id"] in keep]
        ships = self._ship.list_all()

        # ---- 供应商分析 ----
        supplier_buyers: dict[int, set] = defaultdict(set)
        supplier_countries: dict[int, set] = defaultdict(set)
        trade_count: Counter = Counter()
        strength: defaultdict = defaultdict(float)
        for s in ships:
            supplier_buyers[s["supplier_id"]].add(s["buyer_id"])
            trade_count[name(s["supplier_id"])] += 1
            strength[name(s["supplier_id"])] += s["confidence"]
            strength[name(s["buyer_id"])] += s["confidence"]
        for e in edges:
            if e["relation"] == "LOCATED_IN":
                # 公司所在国（对供应商而言即出口侧国家）
                supplier_countries[e["source_id"]].add(name(e["target_id"]))
            if e["relation"] in ("EXPORTS", "PRODUCES"):
                trade_count[name(e["source_id"])] += 1
            if e["relation"] in ("EXPORTS", "PRODUCES", "IMPORTS"):
                strength[name(e["source_id"])] += e["confidence"]
                strength[name(e["target_id"])] += e["confidence"]

        top_suppliers = [
            {"name": name(sid), "buyers": len(bset),
             "export_countries": len(supplier_countries.get(sid, set())),
             "trade_count": trade_count.get(name(sid), 0)}
            for sid, bset in sorted(supplier_buyers.items(),
                                    key=lambda kv: -len(kv[1]))[:10]
        ]

        # ---- 买家分析 ----
        buyer_suppliers: dict[int, set] = defaultdict(set)
        buyer_products: dict[int, set] = defaultdict(set)
        for s in ships:
            buyer_suppliers[s["buyer_id"]].add(s["supplier_id"])
            if s["product"]:
                buyer_products[s["buyer_id"]].add(s["product"])
        top_buyers = [
            {"name": name(bid), "supplier_sources": len(sset),
             "product_scope": sorted(buyer_products.get(bid, set()))}
            for bid, sset in sorted(buyer_suppliers.items(),
                                    key=lambda kv: -len(kv[1]))[:10]
        ]

        # ---- 国家分布 / 集中度 ----
        country_dist = Counter()
        for e in edges:
            if e["relation"] == "LOCATED_IN":
                country_dist[name(e["target_id"])] += 1
        total_supply = sum(trade_count.values())
        top3_share = (sum(c for _, c in trade_count.most_common(3)) / total_supply) if total_supply else 0.0

        # ---- 风险分析 ----
        risks = []
        if len(top_suppliers) == 1 and top_suppliers[0]["buyers"] > 0:
            risks.append(f"单一供应来源：{top_suppliers[0]['name']} 承接全部已发现贸易")
        if top3_share > 0.6 and total_supply:
            risks.append(f"供应商集中度高：前3占比 {top3_share:.0%}")
        if country_dist and country_dist.most_common(1)[0][1] / sum(country_dist.values()) > 0.7:
            risks.append(f"国家集中度风险：{country_dist.most_common(1)[0][0]} 占比过高")
        low_conf = [e["id"] for e in edges if e["confidence"] < 0.5]
        if low_conf:
            risks.append(f"存在 {len(low_conf)} 条低置信度关系（<0.5），需人工复核")

        return {
            "edge_count": len(edges),
            "shipment_count": len(ships),
            "supplier_analysis": top_suppliers,
            "buyer_analysis": top_buyers,
            "country_distribution": dict(country_dist.most_common()),
            "trade_strength": dict(sorted(strength.items(), key=lambda kv: -kv[1])[:10]),
            "concentration_top3_share": round(top3_share, 3),
            "low_confidence_edge_ids": low_conf,
            "risks": risks,
        }
