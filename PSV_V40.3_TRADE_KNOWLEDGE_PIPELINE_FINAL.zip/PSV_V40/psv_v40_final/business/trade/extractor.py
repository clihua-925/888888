"""L5 Information Extraction：Raw Page -> Cleaner -> AI -> Validator
-> trade_extracted_entities + trade_extracted_shipments。

输出两类事实：
  实体候选：company_name/role/country/product/evidence...
  贸易事件候选：supplier_candidate/buyer_candidate/product/quantity/date/evidence...
LLM 配置时 AI 主导（输出 candidates + shipments，经校验落库）；
未配置走确定性解析：__NEXT_DATA__ JSON / 详情页 title / shipment 页的
'Shipper: X  Consignee: Y' 文本模式。无证据一律丢弃。
"""
from __future__ import annotations
import json
import re
import sqlite3
from data.db import connect
from data.repository.raw_repository import RawRepository
from data.repository.extracted_repository import ExtractedRepository
from data.repository.extracted_shipment_repository import ExtractedShipmentRepository
from business.shared.page_cleaner import clean_html, truncate
from ai.client import AIClient, AIClientError
from ai.parsers import validate_extracted_candidate

_NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)
_TITLE_RE = re.compile(r"<title>([^<|]+)", re.I)
_SHIP_TXT_RE = re.compile(r"([\d,]{1,9})\s*[\+]?\s*Shipments", re.I)
_SHIP_CARD_RE = re.compile(r"([A-Z][A-Za-z0-9&.,'\-\s]{2,60}?)\s*[\|·\-–—]\s*(\d[\d,]{0,9})\s+shipments", re.I)
_SHIPPER_RE = re.compile(r"Shipper[^\n:]{0,20}:\s*([A-Z][A-Za-z0-9&.,'\-\s]{2,60})", re.I)
_CONSIGNEE_RE = re.compile(r"Consignee[^\n:]{0,20}:\s*([A-Z][A-Za-z0-9&.,'\-\s]{2,60})", re.I)
_ROLE_HINTS = (("manufacturer", "manufactur"), ("supplier", "supplier"), ("exporter", "export"),
               ("importer", "import"), ("buyer", "buyer"), ("distributor", "distributor"))


class TradeExtractor:
    def __init__(self, ai: AIClient | None = None, conn: sqlite3.Connection | None = None) -> None:
        self._ai = ai or AIClient()
        c = conn or connect()
        self._raw = RawRepository(c)
        self._ext = ExtractedRepository(c)
        self._ship = ExtractedShipmentRepository(c)

    def extract(self, raw_page_ids: list[int]) -> dict:
        """返回 {"extracted_ids": [...], "shipment_extracted_ids": [...]}。"""
        out = {"extracted_ids": [], "shipment_extracted_ids": []}
        for rid in raw_page_ids or []:
            page = self._raw.get(rid)
            if not page:
                continue
            ents, ships = self._extract_one(page)
            for c in ents:
                out["extracted_ids"].append(self._ext.create(
                    raw_page_id=rid, company_candidate=c["company_name"],
                    role_candidate=c.get("company_role"),
                    country_candidate=c.get("country"),
                    product_candidate=c.get("product"),
                    shipment_info=c.get("shipment_info"),
                    evidence=c["evidence"], confidence=c.get("confidence", 0.5),
                    model_version=c.get("model_version", "psv-parser-2")))
            for s in ships:
                out["shipment_extracted_ids"].append(self._ship.create(
                    raw_page_id=rid,
                    supplier_candidate=s["supplier_candidate"],
                    buyer_candidate=s["buyer_candidate"],
                    product=s.get("product"), quantity=s.get("quantity"),
                    ship_date=s.get("date"), evidence=s["evidence"],
                    confidence=s.get("confidence", 0.5),
                    model_version=s.get("model_version", "psv-parser-2")))
        return out

    # ---- 双输出：实体 + 贸易事件 ----
    def _extract_one(self, page: dict) -> tuple[list[dict], list[dict]]:
        html = page.get("html_path") and _read(page["html_path"]) or ""
        cleaned = truncate(clean_html(html or page.get("text") or ""))
        if self._ai.configured:
            try:
                out = self._ai.extract(_PROMPT, cleaned)
                ents, _ = validate_extracted_candidate(out.get("candidates", []), raw_page_id=page["id"])
                ships = [_valid_ship(s, page["id"]) for s in out.get("shipments", [])]
                ships = [s for s in ships if s]
                if ents or ships:
                    return ([{**c, "model_version": self._ai.model_version()} for c in ents],
                            [{**s, "model_version": self._ai.model_version()} for s in ships])
            except AIClientError:
                pass
        return self._deterministic(page, html, cleaned)

    def _deterministic(self, page: dict, html: str, cleaned: str) -> tuple[list[dict], list[dict]]:
        ents: list[dict] = []
        ships: list[dict] = []
        seen: set[str] = set()
        url = page.get("url") or ""

        def _ent(name, ship, conf, country=None):
            name = " ".join(name.split()).strip(" -|·–—")
            if not name or len(name) < 3 or name.lower() in seen:
                return
            seen.add(name.lower())
            role = next((r for r, h in _ROLE_HINTS if h in cleaned.lower()), None)
            ents.append({"company_name": name, "company_role": role, "country": country,
                         "product": None, "shipment_info": ship, "evidence": ship,
                         "source_url": url, "raw_page_id": page["id"],
                         "confidence": conf, "model_version": "psv-parser-2"})

        def _ship(sup, buy, ev, conf, product=None, qty=None, date=None):
            sup = " ".join(sup.split()).strip(" -|·–—")
            buy = " ".join(buy.split()).strip(" -|·–—")
            if len(sup) < 3 or len(buy) < 3 or not ev.strip():
                return
            ships.append({"supplier_candidate": sup, "buyer_candidate": buy,
                          "product": product, "quantity": qty, "date": date,
                          "evidence": ev, "confidence": conf,
                          "source_url": url, "raw_page_id": page["id"],
                          "model_version": "psv-parser-2"})

        # 通用：__NEXT_DATA__ 递归（公司对象 / 含 shipper+consignee 的 shipment 对象）
        m = _NEXT_DATA_RE.search(html or "")
        if m:
            try:
                data = json.loads(m.group(1))
            except json.JSONDecodeError:
                data = None
            if isinstance(data, (dict, list)):
                stack = [data]
                while stack:
                    cur = stack.pop()
                    if isinstance(cur, dict):
                        sh, co = cur.get("shipper") or cur.get("supplier"), cur.get("consignee") or cur.get("buyer")
                        if isinstance(sh, str) and isinstance(co, str):
                            _ship(sh, co, f"shipper {sh} → consignee {co}", 0.65,
                                  product=cur.get("product") if isinstance(cur.get("product"), str) else None,
                                  qty=str(cur["quantity"]) if isinstance(cur.get("quantity"), (int, str)) else None,
                                  date=cur.get("date") if isinstance(cur.get("date"), str) else None)
                        ship_n = cur.get("shipments")
                        nm = cur.get("name") or cur.get("company_name") or cur.get("slug")
                        if isinstance(ship_n, int) and ship_n > 0 and isinstance(nm, str) and len(nm) > 2:
                            country = cur.get("country") if isinstance(cur.get("country"), str) else None
                            _ent(nm, f"{ship_n} shipments", 0.6, country)
                        stack.extend(v for v in cur.values() if isinstance(v, (dict, list)))
                    elif isinstance(cur, list):
                        stack.extend(x for x in cur if isinstance(x, (dict, list)))

        # 详情页：title + shipments
        mt = _TITLE_RE.search(html or "")
        if mt and "importyeti" in url:
            title = " ".join(mt.group(1).split())
            ms = _SHIP_TXT_RE.search(cleaned)
            if title and ms:
                _ent(title.split(" - ")[0].split(" | ")[0], f"{ms.group(1)} shipments", 0.6)

        # 文本卡片（兜底）
        for m2 in _SHIP_CARD_RE.finditer(cleaned):
            _ent(m2.group(1), f"{m2.group(2)} shipments", 0.5)

        # shipment_detail 页：Shipper/Consignee 模式
        if page.get("page_type") == "shipment_detail" or "shipment" in url:
            sh_m, co_m = _SHIPPER_RE.search(cleaned), _CONSIGNEE_RE.search(cleaned)
            if sh_m and co_m:
                _ship(sh_m.group(1), co_m.group(1),
                      f"Shipper: {sh_m.group(1)} | Consignee: {co_m.group(1)}", 0.7)
        return ents, ships


def _valid_ship(s: dict, raw_page_id: int) -> dict | None:
    sup = str(s.get("supplier") or "").strip()
    buy = str(s.get("buyer") or "").strip()
    ev = str(s.get("evidence") or "").strip()
    if not sup or not buy or not ev:
        return None
    try:
        conf = min(1.0, max(0.0, float(s.get("confidence", 0.5))))
    except (TypeError, ValueError):
        conf = 0.5
    return {"supplier_candidate": sup, "buyer_candidate": buy, "evidence": ev,
            "confidence": conf, "product": s.get("product"), "quantity": s.get("quantity"),
            "date": s.get("date"), "raw_page_id": raw_page_id}


_PROMPT = """你是贸易信息抽取器。阅读原始网页文本，抽取两类事实，输出 JSON：
{"candidates":[{"company_name":"","company_role":"supplier/buyer/importer/exporter","country":"","product":"","evidence":"","confidence":0.0}],
 "shipments":[{"supplier":"","buyer":"","product":"","date":"","quantity":"","evidence":"","confidence":0.0}]}
规则：只抽有贸易证据的内容；shipments 只在能同时找到供货方与采购方时输出；每条 evidence 必须来自原文。只输出 JSON。"""


def _read(path: str) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""
