"""L6 Customer Information Completion：只处理采购商/客户，不碰供应商。

职责：
  1) 任务队列 customer_queue（pending/processing/success/failed + attempts）
  2) 客户去重（名称变体归一，aliases 合并）
  3) AI 验证（配置 LLM 时）：基于原始证据评估公司真实性与画像字段
  4) 客户画像补全：名称/国家/行业/采购产品/企业类型/官网/地址/可信度
禁止：供应商验证/画像/去重/补全；供应商只保留 L5 标准化信息。
"""
from __future__ import annotations
import json
import sqlite3
from data.db import connect
from data.repository.customer_queue_repository import CustomerQueueRepository
from data.repository.customer_profile_repository import CustomerProfileRepository
from data.repository.entity_repository import EntityRepository
from business.trade.entity_resolver import normalize_key, normalize_country, name_similarity
from ai.client import AIClient, AIClientError

SIMILARITY_THRESHOLD = 0.9


class CustomerCompletionService:
    def __init__(self, ai: AIClient | None = None, conn: sqlite3.Connection | None = None) -> None:
        c = conn or connect()
        self._queue = CustomerQueueRepository(c)
        self._profiles = CustomerProfileRepository(c)
        self._ent = EntityRepository(c)
        self._ai = ai or AIClient()

    # ---- 队列 ----
    def enqueue(self, customer_name: str, country: str | None = None,
                raw_page_id: int | None = None) -> int:
        return self._queue.enqueue(customer_name, country, raw_page_id)

    def process_pending(self, limit: int = 50) -> dict:
        """Worker：处理队列中所有 pending（含失败重试一次）。"""
        stats = {"processed": 0, "success": 0, "failed": 0}
        for job in self._queue.list_by_status("pending", limit):
            self._queue.set_status(job["id"], "processing")
            try:
                pid = self._complete_one(job["customer_name"], job.get("country"))
                self._queue.set_status(job["id"], "success", profile_id=pid)
                stats["success"] += 1
            except Exception as e:
                self._queue.set_status(job["id"], "failed", error=str(e)[:300])
                stats["failed"] += 1
            stats["processed"] += 1
        return stats

    def queue_stats(self) -> dict:
        return self._queue.stats()

    def summary(self) -> dict:
        """L6 节点入口：兜底处理队列 + 返回画像/实体统计（连接在此层内管理）。"""
        stats = self.process_pending()
        profiles = self._profiles.list_all()
        entities = [e for e in self._ent.list_all() if e["entity_type"] == "Company"]
        return {"customer_queue_stats": {**self.queue_stats(), **stats},
                "customer_profile_ids": [p["id"] for p in profiles],
                "entity_ids": [int(e["id"]) for e in entities]}

    # ---- 补全单个客户 ----
    def _complete_one(self, name: str, country: str | None) -> int:
        country_n = normalize_country(country)
        existing = self._match_existing(name)
        if existing is not None:
            self._profiles.add_alias(existing, name)  # 客户去重：变体并入已有画像
            return existing
        profile = self._ai_enrich(name, country_n)
        pid = self._profiles.create(
            canonical_name=name, country=profile.get("country") or country_n,
            industry=profile.get("industry"),
            products=profile.get("products") or [],
            company_type=profile.get("company_type") or "buyer/importer",
            website=profile.get("website"), address=profile.get("address"),
            confidence=profile.get("confidence", 0.5),
            sources=profile.get("sources") or [])
        # 同步为图谱客户实体（供 L7 建边）
        ent = self._ent.find_by_name("Company", name)
        if not ent:
            self._ent.create("Company", name, aliases=[], country=profile.get("country") or country_n)
        return pid

    def _match_existing(self, name: str) -> int | None:
        key = normalize_key(name)
        best_id, best = None, 0.0
        for p in self._profiles.list_all():
            names = [p["canonical_name"], *p["aliases"]]
            if any(normalize_key(n) == key for n in names):
                return int(p["id"])
            for n in names:
                s = name_similarity(name, n)
                if s > best:
                    best, best_id = s, int(p["id"])
        return best_id if best >= SIMILARITY_THRESHOLD else None

    def _ai_enrich(self, name: str, country: str | None) -> dict:
        """AI 验证 + 画像补全。未配置 LLM 时返回基于证据强度的保守画像（不伪造）。"""
        if self._ai.configured:
            try:
                out = self._ai.chat(_VERIFY_PROMPT, {"company": name, "country": country or ""})
                conf = out.get("confidence", 0.5)
                try:
                    conf = min(1.0, max(0.0, float(conf)))
                except (TypeError, ValueError):
                    conf = 0.5
                return {"country": out.get("country") or country,
                        "industry": out.get("industry"),
                        "products": out.get("products") or [],
                        "company_type": out.get("company_type"),
                        "website": out.get("website"), "address": out.get("address"),
                        "confidence": conf,
                        "sources": out.get("sources") or ([] if not out.get("website") else [out["website"]])}
            except AIClientError:
                pass
        return {"country": country, "confidence": 0.5,
                "sources": [], "products": []}


_VERIFY_PROMPT = """你是企业信息验证助手。给定客户公司名称与国家，评估公司真实性并补全画像。
输出 JSON：{"exists": true, "country": "", "industry": "", "products": [],
"company_type": "buyer/importer/distributor", "website": "", "address": "", "confidence": 0.0-1.0}
无法确认的字段填 null，confidence 反映确信程度。只输出 JSON。"""
