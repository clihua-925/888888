"""L6 Entity Resolution：候选公司名归一、去重、别名合并，产出正式实体。

识别手段（重新实现）：
- 规范化 key：小写 + 去标点 + 去通用后缀（co/ltd/inc/llc/gmbh...）
- 名称相似度：difflib ratio >= 0.9 视为同一企业
- 域名匹配：候选名与已知实体官网域名主干一致则合并
- 国家归一：us/usa/united states → USA 等
同一 key/高相似度的多个 candidate 合并为一个 Company 实体，原写法记入 aliases。
"""
from __future__ import annotations
import difflib
import re
import sqlite3
from data.db import connect
from data.repository.extracted_repository import ExtractedRepository
from data.repository.entity_repository import EntityRepository

_SUFFIXES = {"co", "ltd", "limited", "inc", "incorporated", "llc", "llp", "gmbh",
             "corp", "corporation", "company", "bv", "pte", "sarl", "kft", "sa", "ag", "kk"}
_COUNTRY_MAP = {
    "us": "USA", "usa": "USA", "united states": "USA", "u.s.": "USA", "u.s.a.": "USA",
    "korea": "Korea", "south korea": "Korea", "kr": "Korea",
    "china": "China", "cn": "China", "prc": "China",
    "uk": "UK", "united kingdom": "UK", "england": "UK",
    "germany": "Germany", "deutschland": "Germany",
    "japan": "Japan", "india": "India", "taiwan": "Taiwan",
    "mexico": "Mexico", "canada": "Canada", "vietnam": "Vietnam", "turkey": "Turkey",
}
_PUNCT_RE = re.compile(r"[^a-z0-9 ]")
SIMILARITY_THRESHOLD = 0.9


def normalize_key(name: str) -> str:
    """公司名归一 key：小写、去标点、去通用后缀词。"""
    t = _PUNCT_RE.sub(" ", (name or "").lower())
    tokens = [w for w in t.split() if w not in _SUFFIXES]
    return " ".join(tokens)


def name_similarity(a: str, b: str) -> float:
    """归一后名称相似度（0-1）。"""
    ka, kb = normalize_key(a), normalize_key(b)
    if not ka or not kb:
        return 0.0
    return difflib.SequenceMatcher(None, ka, kb).ratio()


def domain_key(name: str) -> str:
    """公司名 -> 域名主干近似（去后缀、去空格），用于域名匹配。"""
    return normalize_key(name).replace(" ", "")


def normalize_country(c: str | None) -> str | None:
    if not c:
        return None
    return _COUNTRY_MAP.get(c.strip().lower(), c.strip())


class EntityResolver:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        c = conn or connect()
        self._ext = ExtractedRepository(c)
        self._ent = EntityRepository(c)

    def resolve(self, extracted_ids: list[int]) -> list[tuple[int, int]]:
        """返回 [(extracted_id, entity_id), ...]；同一 extracted 只映射一个 Company 实体。"""
        pairs: list[tuple[int, int]] = []
        key_cache: dict[str, int] = {}
        for row in self._ext.list_by_ids(extracted_ids):
            raw_name = str(row.get("company_candidate") or "").strip()
            if not raw_name:
                continue
            key = normalize_key(raw_name) or raw_name.lower()
            entity_id = key_cache.get(key)
            if entity_id is None:
                entity_id = self._match_existing(raw_name)
            if entity_id is None:
                entity_id = self._ent.create(
                    "Company", canonical_name=raw_name,
                    aliases=[], country=normalize_country(row.get("country_candidate")))
            else:
                self._ent.add_alias(entity_id, raw_name)
            key_cache[key] = entity_id
            cur = self._ent.get(entity_id) or {}
            if raw_name != cur.get("canonical_name") and raw_name not in cur.get("aliases", []):
                self._ent.add_alias(entity_id, raw_name)
            pairs.append((int(row["id"]), entity_id))
        return pairs

    def _match_existing(self, raw_name: str) -> int | None:
        """依次：key 精确匹配 -> 域名主干匹配 -> 相似度匹配。"""
        key = normalize_key(raw_name)
        dkey = domain_key(raw_name)
        best_id, best_score = None, 0.0
        for e in self._ent.list_all():
            if e["entity_type"] != "Company":
                continue
            names = [e["canonical_name"], *e["aliases"]]
            if any(normalize_key(n) == key for n in names):
                return int(e["id"])
            if dkey and any(domain_key(n) == dkey for n in names):
                return int(e["id"])
            for n in names:
                s = name_similarity(raw_name, n)
                if s > best_score:
                    best_score, best_id = s, int(e["id"])
        if best_score >= SIMILARITY_THRESHOLD:
            return best_id
        return None
