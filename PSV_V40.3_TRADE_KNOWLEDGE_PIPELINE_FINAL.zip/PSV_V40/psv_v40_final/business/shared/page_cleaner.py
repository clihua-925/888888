"""Page Cleaner：Raw HTML -> 干净文本。

去脚本/样式/导航噪音，压缩空白，截断到 LLM 输入上限。
纯函数，无状态。
"""
from __future__ import annotations
import re

_SCRIPT_RE = re.compile(r"<(script|style|noscript)[^>]*>.*?</\1>", re.S | re.I)
_NAV_RE = re.compile(r"<(header|footer|nav)[^>]*>.*?</\1>", re.S | re.I)
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")

MAX_CHARS = 8000


def clean_html(html: str) -> str:
    """HTML -> 去噪文本（保留正文可读性）。"""
    if not html:
        return ""
    t = _SCRIPT_RE.sub(" ", html)
    t = _NAV_RE.sub(" ", t)
    t = _TAG_RE.sub(" ", t)
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'")):
        t = t.replace(a, b)
    return _WS_RE.sub(" ", t).strip()


def truncate(text: str, limit: int = MAX_CHARS) -> str:
    return text[:limit]
