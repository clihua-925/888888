"""Raw 页净化规则（V40 重新实现；仅借鉴旧系统的领域删除/保留信号经验，不复制代码）。

原则：L4 落库前删除百科/词典/目录/社媒等无贸易价值页面；
保留信号命中任一即保留（importer/exporter/BOL/HS 等贸易痕迹）。
"""
from __future__ import annotations
from urllib.parse import urlparse

DELETE_DOMAINS = (
    # 百科 / 问答 / 社区 / 开发者站点
    "baike.baidu.com", "zhihu.com", "wikipedia.org", "quora.com", "reddit.com",
    "csdn.net", "stackoverflow.com", "github.com",
    # 词典 / 翻译
    "dictionary.com", "merriam-webster.com", "youdao.com", "deepl.com",
    # 社媒 / 视频
    "youtube.com", "facebook.com", "instagram.com", "twitter.com", "x.com",
    "tiktok.com", "pinterest.com",
    # B2B 目录聚合页 / 电商零售（单独卡片页由解析器判断，域名级先放行官方站点）
    "yellowpages.com", "yelp.com",
)

KEEP_SIGNALS = (
    "importer", "exporter", "supplier", "manufacturer", "shipper", "consignee",
    "notify party", "hs code", "shipment", "bill of lading", "bol",
    "import", "export", "customs", "提单", "进口", "出口", "供应商", "采购商",
)


def purify(url: str, text: str | None) -> tuple[bool, str]:
    """返回 (是否保留, 原因)。"""
    host = (urlparse(url).hostname or "").lower()
    if any(d in host for d in DELETE_DOMAINS):
        return False, f"junk_domain:{host}"
    body = (text or "").lower()
    hits = [s for s in KEEP_SIGNALS if s in body]
    if not hits:
        return False, "no_trade_signal"
    return True, "keep:" + ",".join(hits[:3])
