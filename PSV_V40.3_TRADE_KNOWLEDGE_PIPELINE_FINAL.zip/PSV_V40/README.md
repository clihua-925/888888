# PSV V40.3 启动说明

## 环境模式（重要）

PSV 采用**共享 venv 迭代模式**：虚拟环境放在 PSV_V40 的**上一级目录**（如 `D:\chang\venv`），
代码目录 `PSV_V40\` 可随时整体替换为新版本 zip 解压结果，**环境一次部署、长期复用**。

查找顺序（start_psv.bat / install_psv.bat 一致）：
1. `PSV_V40\..\venv`（共享环境，**优先**）
2. `PSV_V40\venv`（包内环境）

## 第一次运行

双击 **`install_psv.bat`**

自动完成：定位/创建 venv → Python 版本检查（3.10+，langgraph 1.x 要求）→
`pip install -r requirements.txt`（langgraph 1.x 最新线）→ 初始化数据库 → 生成 `.env`

## 日常启动

双击 **`start_psv.bat`** 即可，无需命令行、无需手动激活。

自动执行（全程无黑窗）：
①激活共享 venv ②AI Browser（Chrome CDP :9222，登录态存 `psv_chrome_profile\`）
③隐藏启动 Backend `:8000` + Frontend `:3000` ④自动打开浏览器 → `http://localhost:3000`

启动后如页面无法访问，查看日志定位：
- `psv_v40_final\logs\backend.log`（API 服务报错）
- `psv_v40_final\logs\frontend.log`
- `psv_v40_final\logs\pipeline.log`（每次分析各阶段执行记录）

UI 中点击任意阶段（L1~L10）可展开该层详细数据（产物数量、ID 列表、错误堆栈），
失败时红色横幅直接标明失败于哪一层。

## 停止

双击 **`stop_psv.bat`**（关闭 Backend / Frontend / AI Browser，不影响你自己的 Chrome）。

## 版本迭代

```
D:\chang\
├── venv\           ← 共享环境（不动它）
├── PSV_V40\        ← 旧版本直接删除/改名
└── PSV_V40x.zip     ← 新版本解压为 PSV_V40 即可
```

升级后只需双击一次 `install_psv.bat`（增量装新依赖），再双击 `start_psv.bat`。

## 依赖版本基线（2026-09）

| 包 | 要求 | 说明 |
|---|---|---|
| langgraph | >=1.0,<2.0 | 1.0 起 API 冻结，当前最新 1.2.x |
| pydantic | >=2.7 | contracts 层 |
| fastapi / uvicorn | >=0.115 / >=0.30 | API 层 |
| playwright | >=1.45 | 浏览器采集层（可选增强） |
| pytest | >=8.2 | 测试 |
| sqlalchemy / python-dotenv | >=2.0 / >=1.0 | 数据层 / 配置 |
