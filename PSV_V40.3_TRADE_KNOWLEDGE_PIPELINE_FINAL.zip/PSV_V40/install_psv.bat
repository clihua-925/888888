﻿@echo off
chcp 65001 >nul
REM ============================================================
REM  PSV V40.3 安装/升级脚本（兼容共享 venv 迭代模式）
REM  优先级：..\venv（共享环境，推荐）-> .\venv（包内）-> 新建 .\venv
REM ============================================================
setlocal
cd /d %~dp0
set APP=%~dp0psv_v40_final
title PSV V40.3 Install

echo === PSV V40.3 安装/升级 ===

REM --- 定位 venv ---
set VENV_DIR=
if exist "%~dp0..\venv\Scripts\python.exe" ( set VENV_DIR=%~dp0..\venv & echo [OK] 使用共享环境: %~dp0..\venv )
if not defined VENV_DIR if exist "%~dp0venv\Scripts\python.exe" ( set VENV_DIR=%~dp0venv & echo [OK] 使用包内环境: %~dp0venv )

if not defined VENV_DIR (
  echo [1/4] 未找到现有 venv，创建新环境 ...
  where python >nul 2>nul
  if errorlevel 1 (
    where py >nul 2>nul
    if errorlevel 1 ( echo [ERROR] 未找到 Python，请先安装 Python 3.10+ & pause & exit /b 1 )
    set PYCMD=py -3
  ) else ( set PYCMD=python )
  %PYCMD% -m venv "%~dp0venv"
  set VENV_DIR=%~dp0venv
)
set PY=%VENV_DIR%\Scripts\python.exe

REM --- Python 版本检查（langgraph 1.x 需要 3.10+）---
"%PY%" -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1
if errorlevel 1 ( echo [ERROR] Python 版本过低，需要 3.10+ & pause & exit /b 1 )
for /f "tokens=*" %%v in ('"%PY%" -c "import platform;print(platform.python_version())"') do echo [OK] Python %%v

"%PY%" -m pip install --upgrade pip
echo [2/4] 安装/升级依赖（langgraph 1.x 最新线）...
"%PY%" -m pip install -r "%APP%\requirements.txt"
"%PY%" -c "import playwright" >nul 2>&1
if not errorlevel 1 ( "%PY%" -m playwright install chromium )

echo [3/4] 初始化数据库 ...
pushd "%APP%"
"%PY%" -c "from data.db import init_db; init_db(); print('[OK] database initialized')"
popd

echo [4/4] 生成配置文件 ...
if not exist "%APP%\.env" ( copy "%APP%\.env.example" "%APP%\.env" >nul & echo [OK] .env 已生成 )

echo.
echo ==========================================
echo   完成！日常启动：双击 start_psv.bat
echo   环境位置：%VENV_DIR%
echo ==========================================
pause
