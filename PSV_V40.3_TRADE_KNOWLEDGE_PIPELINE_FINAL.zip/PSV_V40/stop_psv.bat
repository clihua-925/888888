﻿@echo off
chcp 65001 >nul
REM PSV V40.3 一键停止：关闭 Backend / Frontend / AI Browser
setlocal EnableDelayedExpansion
title PSV V40.3 Stop

echo 停止 Backend (8000) 与 Frontend (3000)...
for %%P in (8000 3000) do (
  for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P" ^| findstr "LISTENING"') do (
    if not "%%a"=="*" taskkill /F /T /PID %%a >nul 2>&1
  )
)

echo 停止 AI Browser（psv_chrome_profile）...
REM 主方案：PowerShell（Win10/11 通用）；兜底：wmic
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Where-Object { $_.CommandLine -like '*psv_chrome_profile*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
if errorlevel 1 (
  for /f "tokens=2 delims=," %%a in ('wmic process where "name='chrome.exe' and commandline like '%%psv_chrome_profile%%'" get processid /format:csv 2^>nul ^| findstr /r "[0-9]"') do (
    taskkill /F /T /PID %%a >nul 2>&1
  )
)
echo [OK] 已停止。可直接关闭本窗口。
timeout /t 5 >nul
