﻿@echo off
chcp 65001 >nul
REM PSV AI Browser：启动 Chrome CDP 模式（保持登录态，供 BrowserCollector 使用）
setlocal
set PROFILE=%~dp0psv_chrome_profile
if not exist "%PROFILE%" mkdir "%PROFILE%"

set CHROME=
for %%P in ("C:\Program Files\Google\Chrome\Application\chrome.exe" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe") do (
  if exist %%~P set CHROME=%%~P
)
if not defined CHROME ( echo [WARN] 未找到 Chrome，浏览器采集层将降级为 HTTP & exit /b 0 )

REM 已运行则跳过（仅检测 LISTENING）
netstat -ano | findstr ":9222" | findstr "LISTENING" >nul
if not errorlevel 1 ( echo [OK] Chrome CDP 已在运行 & exit /b 0 )

REM 强单例：先杀掉所有占用本 profile 的 Chrome（含孤儿/多实例），等待句柄释放后再启动
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Where-Object { $_.CommandLine -like '*psv_chrome_profile*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
timeout /t 2 >nul

start "" "%CHROME%" --remote-debugging-port=9222 --user-data-dir="%PROFILE%" --no-first-run --no-default-browser-check
echo [OK] Chrome AI Browser 已启动（CDP :9222，配置 %PROFILE%）
