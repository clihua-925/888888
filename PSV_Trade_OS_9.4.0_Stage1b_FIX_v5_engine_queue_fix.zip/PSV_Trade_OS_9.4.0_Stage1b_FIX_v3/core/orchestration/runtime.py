"""Process-local runtime context for business node dependencies."""
from __future__ import annotations

import contextvars
from typing import Any

_ENGINE_CONTEXT: contextvars.ContextVar = contextvars.ContextVar("psv_engine_context")


class EngineContext:
    __slots__ = ("decision_layer", "database")

    def __init__(self, decision_layer: Any, database: Any) -> None:
        self.decision_layer = decision_layer
        self.database = database


def push_engine_context(decision_layer: Any, database: Any):
    return _ENGINE_CONTEXT.set(EngineContext(decision_layer, database))


def pop_engine_context(token) -> None:
    _ENGINE_CONTEXT.reset(token)


def get_decision_layer() -> Any:
    ctx = _ENGINE_CONTEXT.get(None)
    if ctx is None:
        raise RuntimeError("No engine context; cannot get decision_layer")
    return ctx.decision_layer


def get_database() -> Any:
    ctx = _ENGINE_CONTEXT.get(None)
    if ctx is None:
        raise RuntimeError("No engine context; cannot get database")
    return ctx.database
