"""Contract registry and validation primitives for PSV Trade OS 9.4.0."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class ContractDefinition:
    """Formal data contract between a node and shared state."""
    node_id: str
    input_keys: tuple[str, ...] = ()
    output_keys: tuple[str, ...] = ()
    responsibility: str = ""
    success: str = ""
    failure: str = ""
    blocking: bool = True
    side_effects: tuple[str, ...] = ()
    database_write_authority: bool = False

    def __post_init__(self) -> None:
        if not self.node_id.strip():
            raise ValueError("node_id must not be empty")
        if not self.responsibility.strip():
            raise ValueError(f"responsibility is required for {self.node_id}")

    def validate_input(self, state: Mapping[str, Any]) -> None:
        missing = [key for key in self.input_keys if key not in state]
        if missing:
            raise ValueError(f"{self.node_id} missing input keys: {', '.join(missing)}")

    def validate_output(self, state: Mapping[str, Any]) -> None:
        missing = [key for key in self.output_keys if key not in state]
        if missing:
            raise ValueError(f"{self.node_id} missing output keys: {', '.join(missing)}")


NodeContract = ContractDefinition


@dataclass
class ContractRegistry:
    contracts: dict[str, ContractDefinition] = field(default_factory=dict)

    def register(self, contract: ContractDefinition) -> None:
        if contract.node_id in self.contracts:
            raise ValueError(f"Contract already registered: {contract.node_id}")
        self.contracts[contract.node_id] = contract

    def register_many(self, contracts: Iterable[ContractDefinition]) -> None:
        pending = list(contracts)
        node_ids = [contract.node_id for contract in pending]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("Duplicate node_id found in contract collection")
        duplicates = [node_id for node_id in node_ids if node_id in self.contracts]
        if duplicates:
            raise ValueError(f"Contracts already registered: {', '.join(duplicates)}")
        for contract in pending:
            self.contracts[contract.node_id] = contract

    def get(self, node_id: str) -> ContractDefinition:
        try:
            return self.contracts[node_id]
        except KeyError as exc:
            raise KeyError(f"Contract not registered: {node_id}") from exc

    def validate(self, node_id: str, state: Mapping[str, Any], *, phase: str) -> bool:
        contract = self.get(node_id)
        normalized_phase = phase.strip().lower()
        if normalized_phase == "input":
            contract.validate_input(state)
        elif normalized_phase == "output":
            contract.validate_output(state)
        else:
            raise ValueError("phase must be either 'input' or 'output'")
        return True

    def validate_input(self, node_id: str, state: Mapping[str, Any]) -> bool:
        return self.validate(node_id, state, phase="input")

    def validate_output(self, node_id: str, state: Mapping[str, Any]) -> bool:
        return self.validate(node_id, state, phase="output")
