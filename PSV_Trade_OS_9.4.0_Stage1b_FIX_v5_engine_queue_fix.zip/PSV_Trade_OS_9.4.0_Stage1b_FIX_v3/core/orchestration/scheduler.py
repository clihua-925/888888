"""Asynchronous workflow scheduler for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
import os
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

from .mission import MissionDirector
from .state import STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING

LOGGER = logging.getLogger(__name__)


class WorkflowScheduler:
    """Submit Missions to background threads without controlling business nodes."""

    _PROCESS_ACTIVE_TASK_IDS: set[str] = set()
    _PROCESS_ACTIVE_LOCK = threading.Lock()

    def __init__(self, mission_director: MissionDirector) -> None:
        self.mission_director = mission_director
        self._threads: dict[str, threading.Thread] = {}
        self._lock = threading.Lock()
        self._process_id = os.getpid()
        self._worker_token = uuid.uuid4().hex
        self._startup_time = datetime.now(timezone.utc)
        self._active_task_ids: set[str] = set()
        self._recovery_scan_completed = False
        self._run_startup_recovery_once()

    def _run_startup_recovery_once(self) -> None:
        """Run the persisted-task recovery scan once for this scheduler instance."""
        if self._recovery_scan_completed:
            return
        self._recovery_scan_completed = True
        self._recover_persisted_tasks()

    def _recover_persisted_tasks(self) -> None:
        """Recover only persisted work that predates this scheduler process."""
        try:
            tasks = self.mission_director.database.get_tasks_by_status((STATUS_PENDING, STATUS_RUNNING))
        except Exception:
            LOGGER.exception("Failed to scan persisted tasks during scheduler startup")
            return
        for task in tasks:
            task_id = str(task["task_id"])

            if task["status"] == STATUS_RUNNING:
                # 1) 属于当前调度器实例 -> 跳过
                if self._belongs_to_current_scheduler(task):
                    LOGGER.debug(
                        "Skipping recovery for task owned by current scheduler: task_id=%s",
                        task_id,
                    )
                    continue

                # 2) 属于另一个仍然存活的调度器进程 -> 跳过（Flask reloader / 多进程场景）
                if self._is_owned_by_live_process(task):
                    LOGGER.debug(
                        "Skipping recovery: task owned by another live scheduler process: task_id=%s",
                        task_id,
                    )
                    continue

                # 3) 真正的遗留任务：无 checkpoint -> FAILED；有 checkpoint -> resume
                if self.mission_director.engine.has_checkpoint(task_id):
                    self._start_thread(task_id, self._resume_task, "psv-recover-resume")
                else:
                    state = dict(task["state"])
                    state["status"] = STATUS_FAILED
                    state["error"] = {
                        "code": "PROCESS_RESTART_INTERRUPTED",
                        "message": "Task was RUNNING when the scheduler process restarted and has no durable checkpoint",
                    }
                    self.mission_director.database.update_task(task_id, state, STATUS_FAILED)
                    self.mission_director.database.add_event(
                        task_id, "TASK_RECOVERY_FAILED", status=STATUS_FAILED, payload=state["error"]
                    )
                    LOGGER.warning("Marked interrupted RUNNING task failed: task_id=%s", task_id)
            else:
                self._start_thread(task_id, self._execute_task, "psv-recover")
                LOGGER.info("Recovered pending task: task_id=%s", task_id)

    def _is_owned_by_live_process(self, task: dict[str, Any]) -> bool:
        """Return True if the RUNNING task is owned by another still-alive scheduler process.

        This distinguishes a stale RUNNING record from a task that another live
        scheduler process (e.g. Flask reloader child) is actively executing.
        """
        state = task.get("state")
        if not isinstance(state, dict):
            return False
        orchestration = state.get("orchestration")
        if not isinstance(orchestration, dict):
            return False
        worker_token = str(orchestration.get("scheduler_worker_token") or "").strip()
        if not worker_token:
            return False  # 没有 token，说明不是本进程新提交的任务
        try:
            worker_pid = int(orchestration.get("scheduler_worker_pid"))
        except (TypeError, ValueError):
            return False
        if worker_pid == self._process_id:
            return False  # 自己进程的交给 _belongs_to_current_scheduler 处理
        return self._is_process_alive(worker_pid)

    @staticmethod
    def _is_process_alive(pid: int) -> bool:
        """Cross-platform PID liveness probe via os.kill(pid, 0)."""
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False

    def _belongs_to_current_scheduler(self, task: dict[str, Any]) -> bool:
        """Return whether a RUNNING task is owned by this scheduler process instance."""
        state = task.get("state")
        if not isinstance(state, dict):
            return False
        orchestration = state.get("orchestration")
        if not isinstance(orchestration, dict):
            return False
        worker_token = str(orchestration.get("scheduler_worker_token") or "").strip()
        worker_pid = orchestration.get("scheduler_worker_pid")
        task_id = str(task.get("task_id") or "")
        with self._lock:
            if task_id in self._active_task_ids:
                thread = self._threads.get(task_id)
                if thread is None or thread.is_alive():
                    return True
        with self._PROCESS_ACTIVE_LOCK:
            if task_id in self._PROCESS_ACTIVE_TASK_IDS:
                return True
        for thread in threading.enumerate():
            if thread.is_alive() and thread.name.endswith(f"-{task_id}"):
                return True
        if worker_token == self._worker_token:
            return True
        try:
            return bool(worker_token) and int(worker_pid) == self._process_id
        except (TypeError, ValueError):
            return False

    def _claim_task_worker(self, task_id: str) -> None:
        """Persist scheduler ownership before a worker can transition the task to RUNNING."""
        try:
            task = self.mission_director.database.get_task(task_id)
            state = dict(task.get("state") or {})
            orchestration = dict(state.get("orchestration") or {})
            orchestration["scheduler_worker_pid"] = self._process_id
            orchestration["scheduler_worker_token"] = self._worker_token
            state["orchestration"] = orchestration
            self.mission_director.database.update_task(
                task_id, state, str(task.get("status") or STATUS_PENDING)
            )
        except Exception:
            LOGGER.exception("Failed to persist scheduler worker ownership: task_id=%s", task_id)
            raise

    def _start_thread(self, task_id: str, target: Any, name_prefix: str) -> None:
        """Start one worker after claiming task ownership for this scheduler instance."""
        with self._lock:
            existing = self._threads.get(task_id)
            if existing is not None and existing.is_alive():
                return
            self._active_task_ids.add(task_id)
            with self._PROCESS_ACTIVE_LOCK:
                self._PROCESS_ACTIVE_TASK_IDS.add(task_id)
            thread = threading.Thread(
                target=target, args=(task_id,), name=f"{name_prefix}-{task_id}", daemon=True
            )
            try:
                self._claim_task_worker(task_id)
                self._threads[task_id] = thread
            except Exception:
                self._active_task_ids.discard(task_id)
                with self._PROCESS_ACTIVE_LOCK:
                    self._PROCESS_ACTIVE_TASK_IDS.discard(task_id)
                raise
        thread.start()

    def submit(
        self,
        workflow_id: str | None,
        request: str,
        market: str,
        industry: str,
    ) -> str:
        """Create a task and return immediately while execution runs in a daemon thread."""
        task_id = self.mission_director.create_pending(
            request=request, market=market, industry=industry, workflow_id=workflow_id
        )
        self._start_thread(task_id, self._execute_task, "psv-task")
        LOGGER.info("Workflow submitted asynchronously: task_id=%s", task_id)
        return task_id

    def submit_resume(self, task_id: str) -> str:
        """Resume a persisted task in a background thread and return immediately."""
        self._start_thread(task_id, self._resume_task, "psv-resume")
        LOGGER.info("Workflow resume submitted asynchronously: task_id=%s", task_id)
        return task_id

    def _execute_task(self, task_id: str) -> None:
        """Run one MissionDirector execution and contain worker exceptions."""
        try:
            self.mission_director.execute(task_id)
        except Exception:
            LOGGER.exception("Background workflow execution failed: task_id=%s", task_id)
        finally:
            with self._lock:
                self._threads.pop(task_id, None)
                self._active_task_ids.discard(task_id)
                with self._PROCESS_ACTIVE_LOCK:
                    self._PROCESS_ACTIVE_TASK_IDS.discard(task_id)

    def _resume_task(self, task_id: str) -> None:
        """Run one MissionDirector resume and contain worker exceptions."""
        try:
            self.mission_director.resume(task_id)
        except Exception:
            LOGGER.exception("Background workflow resume failed: task_id=%s", task_id)
        finally:
            with self._lock:
                self._threads.pop(task_id, None)
                self._active_task_ids.discard(task_id)
                with self._PROCESS_ACTIVE_LOCK:
                    self._PROCESS_ACTIVE_TASK_IDS.discard(task_id)