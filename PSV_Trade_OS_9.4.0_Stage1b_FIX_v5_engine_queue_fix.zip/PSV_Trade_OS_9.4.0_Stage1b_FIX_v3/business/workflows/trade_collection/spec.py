"""Declarative trade collection workflow specification."""

from __future__ import annotations
from core.orchestration.contracts import ContractDefinition, NodeContract

WORKFLOW_ID = "trade_collection"
WORKFLOW_VERSION = "9.4.0"
NODE_IDS = ("PRODUCT_DEFINITION","TRADE_STRATEGY","CUSTOMS_NODE_COLLECTION","TRADE_EDGE_BUILD","EVIDENCE_VERIFY","ENTITY_RESOLUTION","GRAPH_EXPANSION","RESOURCE_CLASSIFICATION","DATABASE_COMMIT")
NODE_SPECS = {
    "PRODUCT_DEFINITION": {"node_id":"PRODUCT_DEFINITION","responsibility":"Define the target trade product.","capabilities":("product_definition",)},
    "TRADE_STRATEGY": {"node_id":"TRADE_STRATEGY","responsibility":"Build trade analysis strategy fragments.","capabilities":("trade_strategy",)},
    "CUSTOMS_NODE_COLLECTION": {"node_id":"CUSTOMS_NODE_COLLECTION","responsibility":"Collect customs and trade nodes.","capabilities":("customs_collection",)},
    "TRADE_EDGE_BUILD": {"node_id":"TRADE_EDGE_BUILD","responsibility":"Build candidate trade relationships.","capabilities":("relationship_building","ai_assisted",)},
    "EVIDENCE_VERIFY": {"node_id":"EVIDENCE_VERIFY","responsibility":"Verify business evidence.","capabilities":("evidence_verification","ai_assisted",)},
    "ENTITY_RESOLUTION": {"node_id":"ENTITY_RESOLUTION","responsibility":"Resolve canonical trade entities.","capabilities":("entity_resolution","ai_assisted",)},
    "GRAPH_EXPANSION": {"node_id":"GRAPH_EXPANSION","responsibility":"Expand the trade graph.","capabilities":("graph_expansion",)},
    "RESOURCE_CLASSIFICATION": {"node_id":"RESOURCE_CLASSIFICATION","responsibility":"Classify trade resources.","capabilities":("resource_classification","ai_assisted",)},
    "DATABASE_COMMIT": {"node_id":"DATABASE_COMMIT","responsibility":"Persist finalized trade data.","capabilities":("database_commit",)},
}
CONTRACTS = (
    ContractDefinition("PRODUCT_DEFINITION",("mission",),("product_definition",),"Define the target trade product.","product_definition is available.","Product definition cannot be established."),
    ContractDefinition("TRADE_STRATEGY",("mission","product_definition"),("fragments",),"Form trade analysis strategy fragments.","Strategy fragments are available.","Trade strategy cannot be formed."),
    ContractDefinition("CUSTOMS_NODE_COLLECTION",("product_definition","fragments"),("trade_nodes","fragments","evidence_pool"),"Collect trade nodes and initial evidence.","Trade nodes and evidence are available.","Trade node collection cannot complete."),
    ContractDefinition("TRADE_EDGE_BUILD",("trade_nodes","evidence_pool"),("relationships","decisions"),"Build candidate trade relationships.","Candidate relationships are available.","Trade relationships cannot be built."),
    ContractDefinition("EVIDENCE_VERIFY",("evidence_pool","trade_nodes"),("evidence_pool","decisions"),"Verify evidence against trade nodes.","Evidence verification results are available.","Evidence verification cannot complete."),
    ContractDefinition("ENTITY_RESOLUTION",("trade_nodes","evidence_pool"),("entities","decisions"),"Resolve canonical entities.","Resolved entities are available.","Entity resolution cannot complete."),
    ContractDefinition("GRAPH_EXPANSION",("entities","relationships","evidence_pool"),("relationships",),"Expand the trade graph.","Expanded graph data is available.","Graph expansion cannot complete."),
    ContractDefinition("RESOURCE_CLASSIFICATION",("relationships","evidence_pool","decisions"),("decisions",),"Classify trade resources.","Classification decisions are available.","Resource classification cannot complete."),
    ContractDefinition("DATABASE_COMMIT",("entities","relationships","evidence_pool"),("node_reports",),"Persist finalized trade data.","Final trade data is committed.","Final trade data cannot be committed.",True,("business_database_write",),True),
)
PAYLOAD_KEYS = {
    "mission": ("mission",), "product_definition": ("product_definition",), "trade_strategy": ("fragments",),
    "customs_collection": ("trade_nodes","fragments","evidence_pool"), "trade_edge_build": ("relationships","decisions"),
    "evidence_verify": ("evidence_pool","decisions"), "entity_resolution": ("entities","decisions"),
    "graph_expansion": ("relationships",), "resource_classification": ("decisions",), "database_commit": ("node_reports",),
}
CAPABILITIES = ("product_definition","trade_strategy","customs_collection","relationship_building","evidence_verification","entity_resolution","graph_expansion","resource_classification","database_commit","ai_assisted")
