# PSV Engine v45 - 修复版 (REPAIRED)

## 修复内容

### 1. db.py - 数据库层（阻塞级修复）
- 修复 `executescript` 语法错误（原系统无法启动）
- 补齐所有缺失方法：`save_account_intelligence`, `save_trade_intelligence`, `save_contact_intelligence`, `get_latest_info_gain`, `list_tasks`, `get_lead_detail`, `move_lead`, `expansion_activity`, `save_schedule`, `toggle_schedule`, `delete_schedule`, `get_sender_profile`, `list_ai_calls`, `count` 等
- 新增 `queue_intelligence_task`, `add_to_customer_pool`, `add_to_supplier_pool`, `save_task_log`

### 2. network_expansion.py - 网络扩张引擎（架构级修复）
- **移除 `_add_to_pool` 中的自动补全线程**（小编排智能体失控）
- 扩张引擎只负责发现节点，不自行触发补全
- 补全由 Orchestrator 统一调度
- 所有新发现节点自动进入对应资源池

### 3. app.py - Web UI API（一致性修复）
- 删除 `/api/network-expansion` 旧路由（避免新旧架构并存）
- 修复 `/api/info-gain/<task_id>` 调用不存在方法的问题
- 统一使用新的网络扩张引擎
- 新增 `/api/info-gain/<task_id>/latest` 接口
- 新增 `/api/pools/customers` 和 `/api/pools/suppliers` 接口

### 4. visualization.py - 贸易图谱（数据模型修复）
- 从旧 `relationships` 表切换到新的 `trade_edges` 表
- 节点支持点击进入情报中心、启动网络扩张、加入开发
- 支持品类隔离筛选

### 5. account_intelligence_center.py - 情报中心（持久化修复）
- 修复 `_save_profile` 调用 `save_account_intelligence`
- 修复 `_save_trade_records` 调用 `save_trade_intelligence`
- 修复 `_save_contacts` 调用 `save_contact_intelligence`
- 确保情报档案正确持久化到统一实体表

### 6. system.py - 主编排智能体（架构清理）
- 删除重复的 `run_network`, `run_node`, `run_dev_node` 旧方法
- 统一网络扩张入口：`expand_network()`
- 统一情报补全入口：`enrich_entity()`
- 统一业务开发入口：`start_development()`
- Orchestrator 拥有完整流程控制权

## 文件清单

```
PSV_Engine_v45_Repaired/
├── core/
│   ├── memory/
│   │   └── db.py                    # 修复：语法错误 + 补齐方法
│   ├── intelligence/
│   │   ├── network_expansion.py     # 修复：移除自动线程
│   │   └── account_intelligence_center.py  # 修复：持久化调用
│   ├── trade_graph/
│   │   └── visualization.py         # 修复：切换到新表
│   ├── webui/
│   │   └── app.py                   # 修复：清理旧路由
│   └── system.py                    # 修复：统一入口
└── README_REPAIRED.md
```

## 使用方法

1. 备份原 `core/` 目录
2. 将修复版文件覆盖到对应位置
3. 保留原文件中的 `ai_router.py`, `waterfall.py`, `stop_condition.py`, `execution_center.py`（这些文件无需修改）
4. 重启系统

## 验证清单

替换后请检查：
- [ ] 系统能正常启动（db.py 无语法错误）
- [ ] `/api/network/expand` 可正常调用
- [ ] `/api/info-gain/<task_id>` 返回 200
- [ ] 网络扩张不自行启动补全线程
- [ ] 贸易图谱数据来自 trade_edges 表
- [ ] 情报中心档案能正确保存

## 注意事项

- 第一采集链表 100% 冻结，未做任何修改
- 原 `core/tools/expand.py` 等旧实现建议删除
- 建议后续实现 `_source_public_webpage` 和 `_source_public_registry` 的真实数据源
