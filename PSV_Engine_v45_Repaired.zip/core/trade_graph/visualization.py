# -*- coding: utf-8 -*-
"""Trade Graph Visualization v45 (REPAIRED)
修复内容：
1. 从旧 relationships 表切换到新的 trade_edges 表
2. 节点点击可进入情报中心、启动网络扩张、进入业务中心
3. 支持品类隔离筛选
"""
import json
from typing import Dict, List, Any, Optional
from core.memory.db import DB


class TradeGraphVisualization:
    """贸易图谱可视化 - 展示贸易节点、边、证据和关系。"""

    def __init__(self, db: DB = None):
        self.db = db or DB()

    def build_graph(self, task_id: str = None, norm: str = None, 
                   category_id: str = None, limit: int = 500) -> Dict[str, Any]:
        """
        构建贸易图谱数据。

        修复后：使用 trade_edges 新表，而非旧 relationships 表。
        """
        nodes = {}
        edges = []

        # 查询 trade_edges 表（新架构）
        query_sql = "SELECT * FROM trade_edges WHERE 1=1"
        params = []

        if category_id:
            query_sql += " AND category_id = ?"
            params.append(category_id)

        if norm:
            query_sql += " AND (from_norm = ? OR to_norm = ?)"
            params.extend([norm, norm])

        query_sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        with self.db.c() as x:
            trade_edges = x.execute(query_sql, params).fetchall()

        for edge in trade_edges:
            edge_dict = dict(edge)

            # 处理 from 节点
            from_norm = edge_dict.get('from_norm')
            if from_norm and from_norm not in nodes:
                entity = self.db.get_entity(from_norm)
                nodes[from_norm] = self._build_node(from_norm, entity, 'customer')

            # 处理 to 节点
            to_norm = edge_dict.get('to_norm')
            if to_norm and to_norm not in nodes:
                entity = self.db.get_entity(to_norm)
                nodes[to_norm] = self._build_node(to_norm, entity, 'supplier')

            # 构建边
            edges.append({
                'id': edge_dict.get('edge_id'),
                'from': from_norm,
                'to': to_norm,
                'relation': edge_dict.get('relation', 'trades_with'),
                'product': edge_dict.get('product', ''),
                'hs_code': edge_dict.get('hs_code', ''),
                'shipment_count': edge_dict.get('shipment_count', 0),
                'evidence_level': edge_dict.get('evidence_level', 'MEDIUM'),
                'confidence': edge_dict.get('confidence', 0),
                'discovered_via': edge_dict.get('discovered_via', ''),
                'first_seen': edge_dict.get('first_seen'),
                'last_seen': edge_dict.get('last_seen')
            })

        return {
            'nodes': list(nodes.values()),
            'edges': edges,
            'meta': {
                'total_nodes': len(nodes),
                'total_edges': len(edges),
                'category_id': category_id,
                'query_norm': norm
            }
        }

    def _build_node(self, norm: str, entity: Optional[Dict], default_type: str) -> Dict:
        """构建节点数据。"""
        node = {
            'id': norm,
            'label': entity.get('name', norm) if entity else norm,
            'type': default_type,
            'country': entity.get('country', '') if entity else '',
            'industry': entity.get('industry', '') if entity else '',
            'website': entity.get('website', '') if entity else '',
            # 交互功能
            'click_target': 'account_intelligence_center',
            'click_url': f'/api/account-intelligence/{norm}',
            'actions': [
                {'label': '查看情报档案', 'url': f'/api/account-intelligence/{norm}'},
                {'label': '补全信息', 'url': f'/api/account-intelligence/{norm}/enrich', 'method': 'POST'},
                {'label': '网络扩张', 'url': '/api/network/expand', 'method': 'POST', 'body': {'seed_norm': norm}},
                {'label': '加入开发', 'url': '/api/execution/qualify', 'method': 'POST', 'body': {'norm': norm}}
            ]
        }

        # 如果有情报档案，添加完整度信息
        if entity:
            profile = self.db.get_intelligence_profile(entity.get('entity_id'))
            if profile:
                node['completeness_score'] = profile.get('completeness_score', 0)
                node['development_eligible'] = bool(profile.get('development_eligible', 0))

        return node

    def get_entity_detail(self, norm: str) -> Dict:
        """获取实体在图谱中的详细信息。"""
        entity = self.db.get_entity(norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found'}

        # 获取所有关联边
        edges = self.db.list_trade_edges(entity_id=entity.get('entity_id'))

        # 获取证据
        evidence = self.db.list_evidence(entity_id=entity.get('entity_id'))

        # 获取生命周期
        lifecycle = self.db.get_lifecycle_history(entity.get('entity_id'))

        return {
            'ok': True,
            'entity': entity,
            'edges': edges,
            'evidence': evidence,
            'lifecycle': lifecycle,
            'network_depth': self._calculate_network_depth(entity.get('entity_id'))
        }

    def _calculate_network_depth(self, entity_id: str) -> int:
        """计算实体的网络深度。"""
        edges = self.db.list_trade_edges(entity_id=entity_id)
        if not edges:
            return 0
        return 1  # 简化计算

    def get_expansion_path(self, task_id: str) -> List[Dict]:
        """获取网络扩张路径可视化数据。"""
        logs = self.db.get_expansion_log(task_id)

        path_nodes = []
        path_edges = []

        for log in logs:
            log_dict = dict(log)

            # 添加发现节点
            discovered_norm = log_dict.get('discovered_norm')
            if discovered_norm:
                path_nodes.append({
                    'norm': discovered_norm,
                    'name': log_dict.get('discovered_name', discovered_norm),
                    'role': log_dict.get('discovered_role', 'unknown'),
                    'round': log_dict.get('round_num', 0),
                    'strategy': log_dict.get('strategy', ''),
                    'confidence': log_dict.get('confidence', 0),
                    'is_processed': bool(log_dict.get('is_processed', 0)),
                    'is_enriched': bool(log_dict.get('is_enriched', 0))
                })

            # 添加扩张边
            from_entity_id = log_dict.get('from_entity_id')
            discovered_entity_id = log_dict.get('discovered_entity_id')
            if from_entity_id and discovered_entity_id:
                path_edges.append({
                    'from': from_entity_id,
                    'to': discovered_entity_id,
                    'relation': log_dict.get('relation_type', ''),
                    'strategy': log_dict.get('strategy', ''),
                    'round': log_dict.get('round_num', 0)
                })

        return {
            'nodes': path_nodes,
            'edges': path_edges,
            'total_discovered': len(path_nodes)
        }
