# -*- coding: utf-8 -*-
"""PSV System Orchestrator v45 (REPAIRED)
修复内容：
1. 删除重复的 run_network/run_node/run_dev_node 旧方法
2. 统一网络扩张入口为 expand_network()
3. 统一业务开发入口为 start_development()
4. 主编排智能体拥有完整流程控制权
5. 支持任务状态管理和失败恢复
"""
import json, time, uuid
from typing import Dict, List, Any, Optional
from core.memory.db import DB
from core.intelligence.network_expansion import NetworkExpansionEngine
from core.intelligence.account_intelligence_center import AccountIntelligenceCenter
from core.intelligence.waterfall import WaterfallEnrichmentEngine
from core.business_execution.execution_center import BusinessExecutionCenter


class PSVSystem:
    """
    主编排智能体 / Orchestrator。

    职责：
    - 统一控制整个后半程流程
    - 调度网络扩张、情报补全、业务开发等任务
    - 管理任务状态和失败恢复
    - 禁止节点自行创建独立任务编排
    """

    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.expansion_engine = NetworkExpansionEngine(self.db)
        self.intelligence_center = AccountIntelligenceCenter(self.db)
        self.waterfall_engine = WaterfallEnrichmentEngine(self.db)
        self.execution_center = BusinessExecutionCenter(self.db)

    # ========== 网络扩张（唯一入口） ==========
    def expand_network(self, seed_norm: str, category_id: str = None,
                      max_depth: int = 3, parent_task_id: str = None) -> Dict[str, Any]:
        """
        启动网络扩张任务。

        这是网络扩张的唯一入口。所有网络扩张必须通过此方法启动。
        """
        task_id = f"net-{uuid.uuid4().hex[:8]}"

        # 创建任务
        self.db.create_task(
            task_id=task_id,
            task_name=f"Network Expansion: {seed_norm}",
            task_type='network_expansion',
            category_id=category_id,
            parent_task_id=parent_task_id
        )

        self.db.save_task_log(task_id, 'orchestrator', 
                             f"Orchestrator starting network expansion for {seed_norm}")

        try:
            # 执行扩张
            result = self.expansion_engine.expand(
                seed_norm=seed_norm,
                task_id=task_id,
                category_id=category_id,
                max_depth=max_depth
            )

            # 扩张完成后，Orchestrator 决定下一步：自动补全新发现的节点
            self._schedule_post_expansion_tasks(task_id, result, category_id)

            self.db.update_task(task_id, run_status='completed')
            self.db.save_task_log(task_id, 'orchestrator', 'Network expansion completed')

            return result

        except Exception as e:
            self.db.update_task(task_id, run_status='failed', failure_reason=str(e))
            self.db.save_task_log(task_id, 'orchestrator_error', str(e))
            raise

    def _schedule_post_expansion_tasks(self, task_id: str, expansion_result: Dict, 
                                      category_id: str):
        """
        扩张完成后，Orchestrator 调度后续补全任务。

        这是关键修复：不是由网络扩张引擎自行启动补全，
        而是由 Orchestrator 统一调度。
        """
        discovered_nodes = expansion_result.get('discovered_nodes', [])

        for node in discovered_nodes:
            norm = node.get('norm')
            if not norm:
                continue

            # 为每个新发现的节点创建补全任务
            enrich_task_id = self.db.queue_intelligence_task(
                norm=norm,
                category_id=category_id,
                source_task_id=task_id
            )

            self.db.save_task_log(task_id, 'orchestrator',
                f"Scheduled enrichment task {enrich_task_id} for {norm}")

    # ========== 情报补全（唯一入口） ==========
    def enrich_entity(self, norm: str, category_id: str = None,
                     parent_task_id: str = None) -> Dict[str, Any]:
        """
        触发实体情报补全。

        统一入口，由 Orchestrator 调度执行。
        """
        task_id = f"enrich-{uuid.uuid4().hex[:8]}"

        self.db.create_task(
            task_id=task_id,
            task_name=f"Enrichment: {norm}",
            task_type='waterfall_enrichment',
            category_id=category_id,
            parent_task_id=parent_task_id
        )

        self.db.save_task_log(task_id, 'orchestrator', 
                             f"Orchestrator starting enrichment for {norm}")

        try:
            result = self.intelligence_center.enrich(
                norm=norm,
                category_id=category_id
            )

            self.db.update_task(task_id, run_status='completed')
            return result

        except Exception as e:
            self.db.update_task(task_id, run_status='failed', failure_reason=str(e))
            raise

    # ========== 业务开发（唯一入口） ==========
    def start_development(self, lead_norm: str, **kwargs) -> Dict[str, Any]:
        """
        启动业务开发流程。

        统一入口，检查开发资格后生成开发信。
        """
        task_id = f"dev-{uuid.uuid4().hex[:8]}"

        self.db.create_task(
            task_id=task_id,
            task_name=f"Development: {lead_norm}",
            task_type='business_development'
        )

        self.db.save_task_log(task_id, 'orchestrator', 
                             f"Orchestrator starting development for {lead_norm}")

        try:
            # 检查开发资格
            qualification = self.execution_center.qualify_for_development(lead_norm)

            if not qualification.get('qualified', False):
                self.db.update_task(task_id, run_status='completed')
                return {
                    'task_id': task_id,
                    'qualified': False,
                    'reason': qualification.get('reason', 'Not qualified')
                }

            # 生成开发信
            letter = self.execution_center.generate_development_letter(lead_norm)

            # 创建执行记录
            entity = self.db.get_entity(lead_norm)
            record_id = self.db.create_execution_record(
                entity_id=entity.get('entity_id') if entity else None,
                execution_type='development_letter',
                task_id=task_id,
                draft_subject=letter.get('subject', ''),
                draft_body=letter.get('body', ''),
                personalized_content=letter.get('personalized', ''),
                recipient_email=letter.get('recipient_email', ''),
                used_intelligence=letter.get('used_intelligence', {}),
                used_evidence=letter.get('used_evidence', []),
                used_ai_model=letter.get('used_ai_model', '')
            )

            self.db.update_task(task_id, run_status='completed', development_count=1)

            return {
                'task_id': task_id,
                'qualified': True,
                'record_id': record_id,
                'letter': letter
            }

        except Exception as e:
            self.db.update_task(task_id, run_status='failed', failure_reason=str(e))
            raise

    # ========== 任务管理 ==========
    def get_task_status(self, task_id: str) -> Optional[Dict]:
        """获取任务状态。"""
        return self.db.get_task(task_id)

    def list_active_tasks(self) -> List[Dict]:
        """获取活跃任务列表。"""
        return self.db.list_tasks(status='running')

    def pause_task(self, task_id: str) -> bool:
        """暂停任务。"""
        return self.db.pause_task(task_id)

    def resume_task(self, task_id: str) -> bool:
        """恢复任务。"""
        return self.db.resume_task(task_id)

    # ========== 已删除的旧方法 ==========
    # 以下旧方法已删除，避免重复入口：
    # - run_network(self, tid, params=None)
    # - run_node(self, tid, params=None)
    # - run_dev_node(self, tid, params=None)
    # - start_network_expansion(self, ...)
    # 
    # 请统一使用：
    # - expand_network(seed_norm, ...) 替代 run_network / start_network_expansion
    # - enrich_entity(norm, ...) 替代 run_node
    # - start_development(lead_norm, ...) 替代 run_dev_node
