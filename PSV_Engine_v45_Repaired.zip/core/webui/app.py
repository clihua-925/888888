# -*- coding: utf-8 -*-
"""PSV Engine Web UI v45 (REPAIRED)
修复内容：
1. 删除 /api/network-expansion 旧路由（避免新旧架构并存）
2. 修复 /api/info-gain/<task_id> 调用不存在方法的问题
3. 统一使用新的网络扩张引擎
4. 所有 API 路由确保有真实后台功能
"""
import json, time
from flask import Flask, jsonify, request
from core.memory.db import DB
from core.intelligence.account_intelligence_center import AccountIntelligenceCenter
from core.intelligence.network_expansion import NetworkExpansionEngine
from core.trade_graph.visualization import TradeGraphVisualization
from core.business_execution.execution_center import BusinessExecutionCenter
from core.system import PSVSystem

app = Flask(__name__)
db = DB()
SYS = PSVSystem()


# ========== 健康检查 ==========
@app.route('/api/health', methods=['GET'])
def api_health():
    return jsonify({'ok': True, 'version': 'v45-repaired', 'timestamp': time.time()})


# ========== 情报中心 API ==========
@app.route('/api/account-intelligence/<norm>', methods=['GET'])
def api_account_intelligence(norm):
    """获取客户/供应商情报档案"""
    intel = db.get_account_intelligence(norm)
    if not intel:
        return jsonify({'ok': False, 'error': 'Entity not found'}), 404
    return jsonify({'ok': True, 'data': intel})


@app.route('/api/account-intelligence/<norm>/enrich', methods=['POST'])
def api_enrich_account(norm):
    """触发情报补全"""
    body = request.get_json() or {}
    category_id = body.get('category_id')

    # 创建补全任务，由 Orchestrator 调度执行
    task_id = db.queue_intelligence_task(norm, category_id=category_id)

    return jsonify({
        'ok': True,
        'task_id': task_id,
        'message': 'Enrichment task queued, will be processed by Orchestrator'
    })


@app.route('/api/account-intelligence/<norm>/network', methods=['GET'])
def api_account_network(norm):
    """查看实体的贸易网络"""
    entity = db.get_entity(norm)
    if not entity:
        return jsonify({'ok': False, 'error': 'Entity not found'}), 404

    edges = db.list_trade_edges(entity_id=entity.get('entity_id'))
    return jsonify({'ok': True, 'entity': entity, 'edges': edges})


# ========== 网络扩张 API ==========
@app.route('/api/network/expand', methods=['POST'])
def api_network_expand():
    """启动网络扩张（唯一入口）"""
    body = request.get_json() or {}
    seed_norm = body.get('seed_norm')
    category_id = body.get('category_id')
    max_depth = body.get('max_depth', 3)

    if not seed_norm:
        return jsonify({'ok': False, 'error': 'seed_norm required'}), 400

    engine = NetworkExpansionEngine(db)
    result = engine.expand(
        seed_norm=seed_norm,
        category_id=category_id,
        max_depth=max_depth
    )

    return jsonify({'ok': True, 'result': result})


# ========== 已删除：旧路由 /api/network-expansion ==========
# 原旧路由代码已移除，避免调用 core.tools.expand 旧实现


# ========== 信息增益 API ==========
@app.route('/api/info-gain/<task_id>', methods=['GET'])
def api_info_gain(task_id):
    """获取网络扩张的信息增益曲线"""
    # 修复：使用 db.get_info_gain_curve（已确认存在）
    logs = db.get_info_gain_curve(task_id)
    return jsonify({'ok': True, 'logs': logs})


@app.route('/api/info-gain/<task_id>/latest', methods=['GET'])
def api_info_gain_latest(task_id):
    """获取最新信息增益"""
    logs = db.get_latest_info_gain(task_id)
    return jsonify({'ok': True, 'logs': logs})


# ========== 贸易图谱 API ==========
@app.route('/api/trade-graph', methods=['GET'])
def api_trade_graph():
    """获取贸易图谱数据"""
    category_id = request.args.get('category_id')
    norm = request.args.get('norm')

    viz = TradeGraphVisualization(db)
    graph = viz.build_graph(norm=norm, category_id=category_id)

    return jsonify({'ok': True, 'graph': graph})


@app.route('/api/trade-graph/entity/<norm>', methods=['GET'])
def api_trade_graph_entity(norm):
    """获取单个实体的图谱详情"""
    viz = TradeGraphVisualization(db)
    detail = viz.get_entity_detail(norm)
    return jsonify({'ok': True, 'data': detail})


# ========== 业务中心 API ==========
@app.route('/api/execution/qualify', methods=['POST'])
def api_execution_qualify():
    """评估客户是否达到开发条件"""
    body = request.get_json() or {}
    norm = body.get('norm')

    if not norm:
        return jsonify({'ok': False, 'error': 'norm required'}), 400

    center = BusinessExecutionCenter(db)
    result = center.qualify_for_development(norm)

    return jsonify({'ok': True, 'result': result})


@app.route('/api/execution/generate-letter', methods=['POST'])
def api_generate_letter():
    """生成开发信"""
    body = request.get_json() or {}
    norm = body.get('norm')
    contact_name = body.get('contact_name')

    if not norm:
        return jsonify({'ok': False, 'error': 'norm required'}), 400

    center = BusinessExecutionCenter(db)
    result = center.generate_development_letter(norm, contact_name=contact_name)

    return jsonify({'ok': True, 'result': result})


@app.route('/api/execution/send', methods=['POST'])
def api_execution_send():
    """执行发送流程"""
    body = request.get_json() or {}
    record_id = body.get('record_id')
    method = body.get('method', 'outlook_web')

    if not record_id:
        return jsonify({'ok': False, 'error': 'record_id required'}), 400

    center = BusinessExecutionCenter(db)
    result = center.execute_send(record_id, method=method)

    return jsonify({'ok': True, 'result': result})


@app.route('/api/execution/records', methods=['GET'])
def api_execution_records():
    """获取执行记录"""
    status = request.args.get('status')
    limit = int(request.args.get('limit', 100))

    records = db.list_execution_records(status=status, limit=limit)
    return jsonify({'ok': True, 'records': records})


# ========== 任务面板 API ==========
@app.route('/api/tasks', methods=['GET'])
def api_tasks():
    """获取任务列表"""
    status = request.args.get('status')
    task_type = request.args.get('task_type')
    category_id = request.args.get('category_id')
    limit = int(request.args.get('limit', 100))

    tasks = db.list_tasks(status=status, task_type=task_type, 
                         category_id=category_id, limit=limit)
    return jsonify({'ok': True, 'tasks': tasks})


@app.route('/api/tasks/<task_id>', methods=['GET'])
def api_task_detail(task_id):
    """获取任务详情"""
    task = db.get_task(task_id)
    if not task:
        return jsonify({'ok': False, 'error': 'Task not found'}), 404
    return jsonify({'ok': True, 'task': task})


@app.route('/api/tasks/<task_id>/pause', methods=['POST'])
def api_task_pause(task_id):
    """暂停任务"""
    db.pause_task(task_id)
    return jsonify({'ok': True})


@app.route('/api/tasks/<task_id>/resume', methods=['POST'])
def api_task_resume(task_id):
    """恢复任务"""
    db.resume_task(task_id)
    return jsonify({'ok': True})


# ========== 实体池 API ==========
@app.route('/api/pools/customers', methods=['GET'])
def api_customer_pool():
    """获取客户资源池"""
    category_id = request.args.get('category_id')
    # 从 entity_pools 表查询
    with db.c() as x:
        sql = "SELECT e.* FROM entities e JOIN entity_pools p ON e.entity_id = p.entity_id WHERE p.pool_type = 'customer'"
        params = []
        if category_id:
            sql += " AND p.category_id = ?"
            params.append(category_id)
        rows = x.execute(sql, params).fetchall()
        return jsonify({'ok': True, 'customers': [dict(r) for r in rows]})


@app.route('/api/pools/suppliers', methods=['GET'])
def api_supplier_pool():
    """获取供应商资源池"""
    category_id = request.args.get('category_id')
    with db.c() as x:
        sql = "SELECT e.* FROM entities e JOIN entity_pools p ON e.entity_id = p.entity_id WHERE p.pool_type = 'supplier'"
        params = []
        if category_id:
            sql += " AND p.category_id = ?"
            params.append(category_id)
        rows = x.execute(sql, params).fetchall()
        return jsonify({'ok': True, 'suppliers': [dict(r) for r in rows]})


# ========== 品类管理 API ==========
@app.route('/api/categories', methods=['GET'])
def api_categories():
    """获取品类列表"""
    with db.c() as x:
        rows = x.execute("SELECT * FROM categories").fetchall()
        return jsonify({'ok': True, 'categories': [dict(r) for r in rows]})


# ========== 系统状态 API ==========
@app.route('/api/system/status', methods=['GET'])
def api_system_status():
    """获取系统整体状态"""
    return jsonify({
        'ok': True,
        'entities': db.count('entities'),
        'trade_edges': db.count('trade_edges'),
        'tasks': db.count('task_panel'),
        'execution_records': db.count('execution_records'),
        'expansion_active': db.expansion_activity()
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
