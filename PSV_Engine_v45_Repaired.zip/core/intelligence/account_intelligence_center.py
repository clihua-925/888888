# -*- coding: utf-8 -*-
"""Account Intelligence Center v45 (REPAIRED)
修复内容：
1. 修复 _save_profile/_save_trade_records/_save_contacts 调用不存在方法的问题
2. 使用 db.save_account_intelligence / save_trade_intelligence / save_contact_intelligence
3. 确保情报档案正确持久化到统一实体表
"""
import json, time
from typing import Dict, List, Any, Optional
from core.memory.db import DB
from core.intelligence.waterfall import WaterfallEnrichmentEngine
from core.intelligence.ai_router import ai_route


class AccountIntelligenceCenter:
    """
    客户/供应商情报中心。

    负责：
    - 构建完整情报档案
    - 信息完整度评估
    - 客户价值评分
    - 开发资格判断
    """

    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.waterfall = WaterfallEnrichmentEngine(db)

    def get_intelligence(self, norm: str) -> Dict[str, Any]:
        """获取完整情报档案。"""
        # 从统一实体表查询
        entity = self.db.get_entity(norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found'}

        entity_id = entity.get('entity_id')

        # 组装完整情报
        intelligence = {
            'entity_id': entity_id,
            'norm': norm,
            'basic_identity': self._get_basic_identity(entity),
            'trade_identity': self._get_trade_identity(entity_id),
            'purchase_behavior': self._get_purchase_behavior(entity_id),
            'info_completeness': self._calculate_completeness(entity_id),
            'info_completeness_detail': self._get_completeness_detail(entity_id),
            'value_score': self._calculate_value_score(entity_id),
            'contacts': self.db.list_entity_contacts(entity_id),
            'evidence': self.db.list_evidence(entity_id),
            'lifecycle': self.db.get_lifecycle_history(entity_id),
            'dev_qualified': self._check_development_qualification(entity_id),
            'dev_qualification_reason': self._get_qualification_reason(entity_id),
            'trade_network': self._get_trade_network(entity_id)
        }

        return {'ok': True, 'data': intelligence}

    def enrich(self, norm: str, category_id: str = None, 
              force: bool = False) -> Dict[str, Any]:
        """
        触发情报补全。

        修复后：调用瀑布补全引擎，结果通过 db 正确持久化。
        """
        entity = self.db.get_or_create_entity(norm=norm, name=norm)
        entity_id = entity.get('entity_id')

        # 执行瀑布补全
        result = self.waterfall.enrich_entity(norm, category_id=category_id, force=force)

        # 更新情报档案
        self._save_profile(norm, {
            'name': entity.get('name', norm),
            'info_completeness': result.get('completeness', 0),
            'info_completeness_detail': result.get('detail', {}),
            'value_score': self._calculate_value_score(entity_id),
            'dev_qualified': self._check_development_qualification(entity_id),
            'dev_qualification_reason': self._get_qualification_reason(entity_id),
            'trade_network': self._get_trade_network(entity_id)
        })

        # 记录生命周期
        self.db.transition_lifecycle(
            entity_id=entity_id,
            from_state=self.db.get_current_lifecycle_state(entity_id),
            to_state='ENRICHED',
            reason='Waterfall enrichment completed',
            actor='account_intelligence_center'
        )

        return {'ok': True, 'enriched': result}

    def _get_basic_identity(self, entity: Dict) -> Dict:
        """基础企业身份信息。"""
        return {
            'standard_name': entity.get('name', ''),
            'original_name': entity.get('original_name', ''),
            'country': entity.get('country', ''),
            'address': entity.get('address', ''),
            'website': entity.get('website', ''),
            'phone': entity.get('phone', ''),
            'enterprise_type': entity.get('enterprise_type', ''),
            'industry': entity.get('industry', ''),
            'product_categories': entity.get('product_categories', ''),
            'brand': entity.get('brand', ''),
            'entity_status': entity.get('entity_status', 'active'),
            'data_source': entity.get('data_source', '')
        }

    def _get_trade_identity(self, entity_id: str) -> Dict:
        """贸易身份信息。"""
        roles = self.db.get_entity_roles(entity_id)
        edges = self.db.list_trade_edges(entity_id=entity_id)

        return {
            'roles': roles,
            'role_display': ' / '.join(roles) if roles else 'unknown',
            'trade_count': len(edges),
            'suppliers': [e for e in edges if e.get('relation') == 'supplier_of'],
            'customers': [e for e in edges if e.get('relation') == 'customer_of'],
            'products': list(set([e.get('product', '') for e in edges if e.get('product')]))
        }

    def _get_purchase_behavior(self, entity_id: str) -> Dict:
        """采购/供应行为推导。"""
        edges = self.db.list_trade_edges(entity_id=entity_id)

        if not edges:
            return {'activity': 'unknown', 'frequency': 'unknown'}

        # 计算活跃度
        shipment_counts = [e.get('shipment_count', 0) for e in edges]
        total_shipments = sum(shipment_counts)

        return {
            'total_shipments': total_shipments,
            'supplier_count': len([e for e in edges if e.get('relation') == 'supplier_of']),
            'customer_count': len([e for e in edges if e.get('relation') == 'customer_of']),
            'products': list(set([e.get('product', '') for e in edges if e.get('product')])),
            'activity': 'high' if total_shipments > 10 else 'medium' if total_shipments > 3 else 'low'
        }

    def _calculate_completeness(self, entity_id: str) -> float:
        """计算信息完整度百分比。"""
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return 0.0

        fields = ['name', 'country', 'address', 'website', 'phone', 
                 'enterprise_type', 'industry', 'product_categories']
        filled = sum(1 for f in fields if entity.get(f))
        return round(filled / len(fields) * 100, 1)

    def _get_completeness_detail(self, entity_id: str) -> Dict:
        """信息完整度详情。"""
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return {}

        return {
            'basic_info': self._calculate_completeness(entity_id),
            'trade_info': min(100, len(self.db.list_trade_edges(entity_id)) * 20),
            'product_info': 100 if entity.get('product_categories') else 0,
            'contact_info': min(100, len(self.db.list_entity_contacts(entity_id)) * 50),
            'email_info': min(100, len([c for c in self.db.list_entity_contacts(entity_id) if c.get('email')]) * 50),
            'website_info': 100 if entity.get('website') else 0
        }

    def _calculate_value_score(self, entity_id: str) -> Dict:
        """计算客户开发价值评分。"""
        entity = self.db.get_entity_by_id(entity_id)
        edges = self.db.list_trade_edges(entity_id=entity_id)
        contacts = self.db.list_entity_contacts(entity_id)

        # 各维度评分 (0-100)
        trade_realness = min(100, len(edges) * 25)  # 贸易真实性
        product_match = 70  # 产品匹配度（需要外部输入）
        recent_activity = 80 if edges and any(e.get('last_seen', 0) > time.time() - 90*86400 for e in edges) else 40
        purchase_strength = min(100, sum(e.get('shipment_count', 0) for e in edges) * 5)
        info_completeness = self._calculate_completeness(entity_id)
        contact_availability = min(100, len(contacts) * 50)

        # 综合评分
        total = (trade_realness * 0.2 + product_match * 0.15 + recent_activity * 0.15 +
                purchase_strength * 0.15 + info_completeness * 0.15 + contact_availability * 0.2)

        return {
            'trade_realness': trade_realness,
            'product_match': product_match,
            'recent_activity': recent_activity,
            'purchase_strength': purchase_strength,
            'info_completeness': info_completeness,
            'contact_availability': contact_availability,
            'total_score': round(total, 1),
            'priority': 'high' if total >= 70 else 'medium' if total >= 40 else 'low'
        }

    def _check_development_qualification(self, entity_id: str) -> bool:
        """检查是否达到开发条件。"""
        score = self._calculate_value_score(entity_id)
        contacts = self.db.list_entity_contacts(entity_id)
        has_email = any(c.get('email') for c in contacts)

        return (score.get('total_score', 0) >= 50 and 
                score.get('trade_realness', 0) >= 40 and
                has_email)

    def _get_qualification_reason(self, entity_id: str) -> str:
        """获取开发资格判断原因。"""
        if self._check_development_qualification(entity_id):
            return 'Meets all development criteria'

        reasons = []
        score = self._calculate_value_score(entity_id)
        if score.get('total_score', 0) < 50:
            reasons.append('Value score too low')
        if score.get('trade_realness', 0) < 40:
            reasons.append('Insufficient trade evidence')

        contacts = self.db.list_entity_contacts(entity_id)
        if not any(c.get('email') for c in contacts):
            reasons.append('No valid contact email')

        return '; '.join(reasons) if reasons else 'Not qualified'

    def _get_trade_network(self, entity_id: str) -> Dict:
        """获取贸易网络概览。"""
        edges = self.db.list_trade_edges(entity_id=entity_id)
        return {
            'direct_connections': len(edges),
            'suppliers': len([e for e in edges if e.get('relation') == 'supplier_of']),
            'customers': len([e for e in edges if e.get('relation') == 'customer_of']),
            'network_depth': 1  # 简化
        }

    def _save_profile(self, norm: str, data: dict):
        """保存客户情报档案。

        修复后：调用 db.save_account_intelligence（已确认存在）。
        """
        self.db.save_account_intelligence(norm, data)

    def _save_trade_records(self, norm: str, data: dict):
        """保存贸易情报。

        修复后：调用 db.save_trade_intelligence（已确认存在）。
        """
        self.db.save_trade_intelligence(norm, data)

    def _save_contacts(self, norm: str, data: dict):
        """保存联系人情报。

        修复后：调用 db.save_contact_intelligence（已确认存在）。
        """
        self.db.save_contact_intelligence(norm, data)
