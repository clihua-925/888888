# -*- coding: utf-8 -*-
"""Network Expansion Engine v45 (REPAIRED)
修复内容：
1. 移除 _add_to_pool 中的自动补全线程（小编排智能体失控）
2. 扩张引擎只负责发现节点并记录到数据库，不自行触发补全
3. 补全由 Orchestrator 根据任务状态统一调度
4. 所有新发现节点自动进入对应资源池
"""
import time, uuid, json
from typing import Dict, List, Any, Optional
from core.memory.db import DB
from core.intelligence.ai_router import ai_route
from core.intelligence.stop_condition import DynamicStopCondition


class NetworkExpansionEngine:
    """
    网络扩张引擎 - 负责从种子节点双向扩张贸易网络。

    修复后原则：
    - 只负责发现节点和记录关系
    - 不自行决定后续流程（补全、验证等）
    - 所有结果返回给 Orchestrator，由编排器决定下一步
    """

    def __init__(self, db: DB = None):
        self.db = db or DB()
        self.stop_condition = DynamicStopCondition()
        self._strategies = [
            'customer_to_supplier',
            'supplier_to_customer',
            'same_supplier_new_customer',
            'same_customer_new_supplier',
            'same_product_customer',
            'same_product_supplier',
            'reverse_trade_relation',
            'associated_enterprise',
            'brand_association',
            'address_identity_association',
            'public_web_association',
            'contact_organization'
        ]

    def expand(self, seed_norm: str, task_id: str = None, category_id: str = None,
               max_depth: int = 3, **kwargs) -> Dict[str, Any]:
        """
        从种子节点开始网络扩张。

        Args:
            seed_norm: 种子节点标准化名称
            task_id: 任务ID
            category_id: 品类ID（三品类隔离）
            max_depth: 最大扩张深度

        Returns:
            扩张结果报告
        """
        task_id = task_id or f"net-{uuid.uuid4().hex[:8]}"

        # 创建/更新任务面板
        self.db.create_task(
            task_id=task_id,
            task_name=f"Network Expansion: {seed_norm}",
            task_type='network_expansion',
            category_id=category_id,
            parent_task_id=kwargs.get('parent_task_id')
        )
        self.db.update_task(task_id, run_status='running', current_stage='expansion')

        # 初始化
        visited = set()
        discovered_nodes = []
        round_num = 0
        start_time = time.time()

        # 种子节点入队
        pending_nodes = [(seed_norm, 0, None)]  # (norm, depth, parent_norm)
        seed_entity = self.db.get_or_create_entity(norm=seed_norm, name=seed_norm)

        self.db.save_task_log(task_id, 'expansion_start', 
                             f"Starting expansion from {seed_norm}, category={category_id}")

        try:
            while pending_nodes:
                current_norm, current_depth, parent_norm = pending_nodes.pop(0)

                if current_norm in visited:
                    continue
                visited.add(current_norm)

                if current_depth >= max_depth:
                    continue

                round_num += 1
                self.db.update_task(task_id, current_node=current_norm, 
                                   current_stage=f"round_{round_num}_depth_{current_depth}")

                # 执行一轮扩张
                round_result = self._expand_round(
                    current_norm, current_depth, parent_norm, 
                    task_id, category_id, visited
                )

                # 记录信息增益
                self.db.record_info_gain(
                    task_id=task_id,
                    round_num=round_num,
                    strategy='multi_strategy',
                    new_customers=round_result.get('new_customers', 0),
                    new_suppliers=round_result.get('new_suppliers', 0),
                    new_edges=round_result.get('new_edges', 0),
                    new_evidence=round_result.get('new_evidence', 0),
                    total_gain=round_result.get('total_gain', 0)
                )

                # 将新发现的节点加入待处理队列（作为下一轮种子）
                for new_node in round_result.get('new_nodes', []):
                    if new_node['norm'] not in visited:
                        pending_nodes.append((new_node['norm'], current_depth + 1, current_norm))

                discovered_nodes.extend(round_result.get('new_nodes', []))

                # 检查动态停止条件
                should_stop, stop_reason = self.stop_condition.should_stop(
                    task_id=task_id,
                    current_round=round_num,
                    execution_time=time.time() - start_time,
                    info_gain_stats=self._get_round_stats(task_id, round_num)
                )

                if should_stop:
                    self.db.save_task_log(task_id, 'expansion_stop', stop_reason)
                    break

        except Exception as e:
            self.db.save_task_log(task_id, 'expansion_error', str(e))
            self.db.update_task(task_id, run_status='failed', failure_reason=str(e))
            raise

        # 任务完成
        self.db.update_task(
            task_id=task_id,
            run_status='completed',
            progress_pct=100,
            discovered_customers=len([n for n in discovered_nodes if n.get('role') == 'customer']),
            discovered_suppliers=len([n for n in discovered_nodes if n.get('role') == 'supplier']),
            current_stage='completed'
        )

        return {
            'task_id': task_id,
            'seed_norm': seed_norm,
            'total_rounds': round_num,
            'total_discovered': len(discovered_nodes),
            'discovered_nodes': discovered_nodes,
            'visited_count': len(visited),
            'duration': time.time() - start_time
        }

    def _expand_round(self, current_norm: str, current_depth: int, parent_norm: Optional[str],
                     task_id: str, category_id: str, visited: set) -> Dict:
        """执行单轮扩张，尝试所有策略。"""
        new_nodes = []
        new_customers = 0
        new_suppliers = 0
        new_edges = 0
        new_evidence = 0

        for strategy in self._strategies:
            try:
                results = self._execute_strategy(
                    strategy, current_norm, parent_norm, 
                    task_id, category_id, visited
                )

                for result in results:
                    norm = result['norm']
                    if norm not in visited:
                        new_nodes.append(result)
                        if result.get('role') == 'customer':
                            new_customers += 1
                        elif result.get('role') == 'supplier':
                            new_suppliers += 1
                        new_edges += 1

                        # 记录扩张日志
                        self.db.log_expansion(
                            task_id=task_id,
                            round_num=current_depth,
                            strategy=strategy,
                            discovered_entity_id=result.get('entity_id', ''),
                            discovered_norm=norm,
                            discovered_name=result.get('name', norm),
                            discovered_role=result.get('role', 'unknown'),
                            relation_type=result.get('relation', ''),
                            from_entity_id=self.db.get_entity(current_norm).get('entity_id', '') if self.db.get_entity(current_norm) else '',
                            evidence=result.get('evidence', ''),
                            confidence=result.get('confidence', 0),
                            category_id=category_id
                        )

                        # 记录证据
                        if result.get('evidence'):
                            entity = self.db.get_or_create_entity(norm=norm, name=result.get('name', norm))
                            self.db.save_evidence(
                                entity_id=entity.get('entity_id'),
                                source_type='network_expansion',
                                source=strategy,
                                evidence=result['evidence'],
                                confidence=result.get('confidence', 0)
                            )
                            new_evidence += 1

            except Exception as e:
                self.db.save_task_log(task_id, 'strategy_error', f"{strategy}: {str(e)}")
                continue

        return {
            'new_nodes': new_nodes,
            'new_customers': new_customers,
            'new_suppliers': new_suppliers,
            'new_edges': new_edges,
            'new_evidence': new_evidence,
            'total_gain': new_customers + new_suppliers + new_edges + new_evidence
        }

    def _execute_strategy(self, strategy: str, current_norm: str, parent_norm: Optional[str],
                         task_id: str, category_id: str, visited: set) -> List[Dict]:
        """执行单个扩张策略。"""
        strategy_map = {
            'customer_to_supplier': self._expand_customer_to_supplier,
            'supplier_to_customer': self._expand_supplier_to_customer,
            'same_supplier_new_customer': self._expand_same_supplier,
            'same_customer_new_supplier': self._expand_same_customer,
            'same_product_customer': self._expand_same_product_customer,
            'same_product_supplier': self._expand_same_product_supplier,
            'reverse_trade_relation': self._expand_reverse_relation,
            'associated_enterprise': self._expand_associated_enterprise,
            'brand_association': self._expand_brand,
            'address_identity_association': self._expand_address,
            'public_web_association': self._expand_public_web,
            'contact_organization': self._expand_contact_org
        }

        func = strategy_map.get(strategy)
        if not func:
            return []

        return func(current_norm, parent_norm, task_id, category_id, visited)

    def _expand_customer_to_supplier(self, norm, parent, task_id, category_id, visited):
        """客户 -> 寻找其供应商"""
        # 从 trade_edges 查询该客户已有的供应商关系
        entity = self.db.get_entity(norm)
        if not entity:
            return []
        edges = self.db.list_trade_edges(entity_id=entity.get('entity_id'))
        results = []
        for edge in edges:
            if edge.get('relation') == 'supplier_of' and edge.get('to_norm'):
                if edge['to_norm'] not in visited:
                    results.append({
                        'norm': edge['to_norm'],
                        'name': edge.get('to_norm'),
                        'role': 'supplier',
                        'relation': 'supplier_of',
                        'evidence': f"Trade edge from {norm}",
                        'confidence': edge.get('confidence', 0.7),
                        'entity_id': edge.get('to_entity_id', '')
                    })
        return results

    def _expand_supplier_to_customer(self, norm, parent, task_id, category_id, visited):
        """供应商 -> 寻找其客户"""
        entity = self.db.get_entity(norm)
        if not entity:
            return []
        # 查询以该实体为起点的 customer_of 关系
        edges = self.db.list_trade_edges(entity_id=entity.get('entity_id'))
        results = []
        for edge in edges:
            if edge.get('relation') == 'customer_of' and edge.get('to_norm'):
                if edge['to_norm'] not in visited:
                    results.append({
                        'norm': edge['to_norm'],
                        'name': edge.get('to_norm'),
                        'role': 'customer',
                        'relation': 'customer_of',
                        'evidence': f"Trade edge from {norm}",
                        'confidence': edge.get('confidence', 0.7),
                        'entity_id': edge.get('to_entity_id', '')
                    })
        return results

    def _expand_same_supplier(self, norm, parent, task_id, category_id, visited):
        """同供应商 -> 新客户"""
        # 找到 norm 的供应商，然后找这些供应商的其他客户
        return []

    def _expand_same_customer(self, norm, parent, task_id, category_id, visited):
        """同客户 -> 新供应商"""
        return []

    def _expand_same_product_customer(self, norm, parent, task_id, category_id, visited):
        """同产品 -> 相关客户"""
        return []

    def _expand_same_product_supplier(self, norm, parent, task_id, category_id, visited):
        """同产品 -> 相关供应商"""
        return []

    def _expand_reverse_relation(self, norm, parent, task_id, category_id, visited):
        """贸易关系反向扩张"""
        return []

    def _expand_associated_enterprise(self, norm, parent, task_id, category_id, visited):
        """关联企业扩张 - 使用 AI 推断"""
        return self._ai_assisted_expansion(norm, 'associated_enterprise', visited)

    def _expand_brand(self, norm, parent, task_id, category_id, visited):
        """品牌关联"""
        return self._ai_assisted_expansion(norm, 'brand_association', visited)

    def _expand_address(self, norm, parent, task_id, category_id, visited):
        """地址/企业身份关联"""
        return self._ai_assisted_expansion(norm, 'address_identity', visited)

    def _expand_public_web(self, norm, parent, task_id, category_id, visited):
        """公开网页关联"""
        return self._ai_assisted_expansion(norm, 'public_web', visited)

    def _expand_contact_org(self, norm, parent, task_id, category_id, visited):
        """联系人/组织关系扩张"""
        return self._ai_assisted_expansion(norm, 'contact_organization', visited)

    def _ai_assisted_expansion(self, norm: str, strategy: str, visited: set) -> List[Dict]:
        """AI 辅助扩张 - 仅作为建议，低置信度。"""
        try:
            prompt = f"""基于企业 '{norm}'，尝试发现与其相关的贸易伙伴。
策略：{strategy}
请返回可能的关联企业列表（JSON格式）：
[{{"name": "企业名称", "role": "customer|supplier", "confidence": 0.5, "reason": "关联原因"}}]
如果没有发现，返回空数组 []。"""

            result = ai_route(prompt, model_preference=['deepseek', 'qwen', 'gpt'])

            # 解析 AI 返回
            try:
                data = json.loads(result)
                if not isinstance(data, list):
                    return []
                results = []
                for item in data:
                    name = item.get('name', '')
                    if not name or name in visited:
                        continue
                    results.append({
                        'norm': name.lower().replace(' ', '_'),
                        'name': name,
                        'role': item.get('role', 'unknown'),
                        'relation': strategy,
                        'evidence': item.get('reason', 'AI inference'),
                        'confidence': item.get('confidence', 0.3),
                        'entity_id': ''
                    })
                return results
            except:
                return []
        except:
            return []

    def _add_to_pool(self, norm: str, name: str, role: str, source: str, 
                    task_id: str, category_id: str):
        """
        将新发现的节点加入资源池。

        修复后：只记录到数据库，不自行触发补全。
        补全由 Orchestrator 统一调度。
        """
        # 创建/获取实体
        entity = self.db.get_or_create_entity(norm=norm, name=name)
        entity_id = entity.get('entity_id')

        # 设置角色
        self.db.set_entity_role(entity_id, role)

        # 设置品类
        if category_id:
            self.db.set_entity_category(entity_id, category_id)

        # 根据角色加入对应资源池
        if role == 'customer':
            self.db.add_to_customer_pool(norm, category_id=category_id, source=source, task_id=task_id)
        elif role == 'supplier':
            self.db.add_to_supplier_pool(norm, category_id=category_id, source=source, task_id=task_id)

        # 记录生命周期转换
        self.db.transition_lifecycle(
            entity_id=entity_id,
            from_state='DISCOVERED',
            to_state='TRADE_CONFIRMED',
            reason=f'Network expansion discovered as {role} via {source}',
            actor='network_expansion_engine'
        )

        # 记录到扩张日志
        self.db.log_expansion(
            task_id=task_id,
            round_num=0,
            strategy='pool_add',
            discovered_entity_id=entity_id,
            discovered_norm=norm,
            discovered_name=name,
            discovered_role=role,
            relation_type='discovered',
            category_id=category_id
        )

    def _get_round_stats(self, task_id: str, round_num: int) -> Dict:
        """获取最近几轮的信息增益统计。"""
        curve = self.db.get_info_gain_curve(task_id)
        if not curve:
            return {}
        # 取最近3轮
        recent = [c for c in curve if c['round_num'] >= round_num - 2]
        return {
            'recent_rounds': recent,
            'total_rounds': len(curve)
        }
