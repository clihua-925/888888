@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
title PSV Trade OS 9.4.1 Launcher

rem ============================================================
rem PSV Trade OS 9.4.1 - Start Script (CRLF)
rem Chain: .env -> Python -> venv -> deps -> verify -> WebUI -> CDP Chrome
rem ============================================================

cd /d "%~dp0"

rem --- 0. Ensure .env exists ---
if not exist "%~dp0.env" (
    if exist "%~dp0.env.example" (
        copy /y "%~dp0.env.example" "%~dp0.env" >nul
        echo [OK] Created .env from .env.example - review it if you need custom settings.
    ) else (
        echo [WARN] .env.example not found; environment defaults will be used.
    )
)

rem --- 1. Resolve Python interpreter (3.10 - 3.14) ---
set "PYTHON_EXE="
set "PYTHON_VERSION="
for /f "tokens=2 delims= " %%V in ('python --version 2^>^&1') do set "PYTHON_VERSION=%%V"
if defined PYTHON_VERSION (
    for /f "tokens=1,2 delims=." %%A in ("%PYTHON_VERSION%") do (
        if "%%A"=="3" if %%B GEQ 10 if %%B LEQ 14 set "PYTHON_EXE=python"
    )
)
if not defined PYTHON_EXE (
    echo [INFO] Trying Python launcher for version 3.10-3.14 ...
    for %%V in (3.13 3.12 3.11 3.10 3.14) do (
        if not defined PYTHON_EXE (
            py -%%V -c "import sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] <= (3,14) else 1)" >nul 2>&1
            if not errorlevel 1 set "PYTHON_EXE=py -%%V"
        )
    )
)
if not defined PYTHON_EXE (
    echo [ERROR] No usable Python found. Need Python 3.10-3.14 from https://www.python.org
    echo         Tick "Add python.exe to PATH" during install, then re-run this script.
    pause
    exit /b 1
)
echo [OK] Using Python: %PYTHON_EXE%

rem --- 2. .env legacy migration (lift old caps, keep user settings) ---
if exist "%~dp0.env" (
    "%PYTHON_EXE%" -c "from pathlib import Path; p=Path('.env'); t=p.read_text(encoding='utf-8',errors='replace'); u=t.replace('MAX_TASK_SECONDS=1800','MAX_TASK_SECONDS=7200'); (p.write_text(u,encoding='utf-8') if u!=t else None)" >nul 2>&1
)

rem --- 3. Create/reuse project virtual environment ---
set "VENV_DIR=%~dp0.venv"
set "ENV_MODE=project"
set "ENV_PYTHON=%VENV_DIR%\Scripts\python.exe"
if not exist "%ENV_PYTHON%" (
    echo [INFO] Creating virtual environment in .venv ...
    %PYTHON_EXE% -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] venv creation failed.
        pause
        exit /b 1
    )
) else (
    echo [OK] Virtual environment found: %VENV_DIR%
)

rem --- 4. Dependencies (probe first: offline-safe restart) ---
"%ENV_PYTHON%" -c "import flask, openai, langgraph, dotenv, playwright, curl_cffi" >nul 2>&1
if not errorlevel 1 goto deps_ok
echo [INFO] Installing dependencies (first run or after requirements change) ...
"%ENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip >nul
"%ENV_PYTHON%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo [ERROR] Dependency installation failed. Check network / pip mirror, then re-run.
    pause
    exit /b 1
)
"%ENV_PYTHON%" -c "import playwright" >nul 2>&1
if errorlevel 1 (
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check "playwright>=0.7,<0.8"
    if errorlevel 1 ( echo [WARN] playwright install failed; browser source will be unavailable. )
)
"%ENV_PYTHON%" -c "import curl_cffi" >nul 2>&1
if errorlevel 1 (
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check "curl_cffi>=0.7,<0.8"
    if errorlevel 1 ( echo [WARN] curl_cffi install failed; anonymous HTTP source falls back to urllib. )
)
:deps_ok
echo [OK] Dependencies ready.

rem --- 5. Native runtime smoke check (AV interference) ---
"%ENV_PYTHON%" -c "import uuid_utils" >nul 2>&1
if errorlevel 1 (
    echo [WARN] uuid_utils blocked or missing. Reinstalling with --force-reinstall --no-cache-dir ...
    "%ENV_PYTHON%" -m pip install --disable-pip-version-check --force-reinstall --no-cache-dir uuid-utils
    if errorlevel 1 (
        echo [ERROR] Native runtime check failed.
        echo         If antivirus blocked it: Windows Security -^> Virus & threat protection
        echo         -^> Protection history -^> Restore/Allow the blocked item, then re-run.
        pause
        exit /b 1
    )
)
echo [OK] Native runtime check OK.

rem --- 6. Static verification gate ---
"%ENV_PYTHON%" "%~dp0verify_install.py"
if errorlevel 1 (
    echo [ERROR] Static verification failed. See messages above.
    pause
    exit /b 1
)

rem --- 7. Port collision guard (upgrade scenario) ---
"%ENV_PYTHON%" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8090/',timeout=1).read(1)" >nul 2>&1
if not errorlevel 1 (
    echo [WARN] Port 8090 is ALREADY responding - another instance is running.
    echo [WARN] If upgrading: close the old WebUI window first, otherwise the
    echo [WARN] readiness check below may confirm the OLD instance while the new
    echo [WARN] one fails to bind.
    pause
)

rem --- 8. Start WebUI in its own window ---
start "PSV Trade OS WebUI" cmd /k ""%ENV_PYTHON%" "%~dp0run_webui.py""

rem --- 9. Wait for readiness ---
set "READY=0"
for /l %%I in (1,1,60) do (
    "%ENV_PYTHON%" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8090/',timeout=1).read(1)" >nul 2>&1
    if not errorlevel 1 (
        set "READY=1"
        goto webui_ready
    )
    timeout /t 2 /nobreak >nul
)
echo [ERROR] WebUI did not become ready within ~2 minutes. Check the WebUI window for errors.
pause
exit /b 1

:webui_ready
echo [OK] WebUI is responding at http://127.0.0.1:8090

rem --- 10. CDP browser (9222) ---
netstat -ano | findstr /r ":9222 .*LISTENING" >nul
if not errorlevel 1 echo [INFO] Port 9222 already listening - reusing existing CDP browser session.
call "%~dp0start_chrome_debug.bat"

echo.
echo ============================================================
echo  WebUI: http://127.0.0.1:8090
echo  Chrome CDP: http://127.0.0.1:9222 (log in to importyeti.com
echo  in the opened Chrome window before running collection)
echo ============================================================
pause
