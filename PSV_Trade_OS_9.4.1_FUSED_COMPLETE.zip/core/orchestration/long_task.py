"""Long-task facade for PSV Trade OS 9.4.1."""

from __future__ import annotations

from typing import Any

from .mission import MissionDirector
from .scheduler import WorkflowScheduler


class LongTaskManager:
    """Thin facade over asynchronous workflow scheduling and task tracking."""

    def __init__(self, scheduler: WorkflowScheduler) -> None:
        self.scheduler = scheduler

    def submit(
        self,
        workflow_id: str | None,
        request: str,
        market: str,
        industry: str,
    ) -> str:
        """Submit a new long-running task."""
        return self.scheduler.submit(workflow_id, request, market, industry)

    def resume(self, task_id: str) -> str:
        """Submit a durable checkpoint resume."""
        return self.scheduler.submit_resume(task_id)

    def track(self, task_id: str) -> dict[str, Any]:
        """Return the current persisted task record."""
        database = self.scheduler.mission_director.database
        return database.get_task(task_id)
