"""Generic task recovery engine for PSV Trade OS 9.4.1."""

from __future__ import annotations

import logging
from collections.abc import Mapping, MutableMapping
from typing import Any

from .policies import DEFAULT_POLICY, Policy
from .state import STATUS_FAILED, STATUS_PAUSED, STATUS_RUNNING, TaskState

LOGGER = logging.getLogger(__name__)

FAILURE_TYPES = frozenset({
    "node_failure",
    "contract_input_failure",
    "contract_output_failure",
    "timeout",
    "no_information_gain",
    "engine_failure",
})


class RecoveryManager:
    """Apply generic recovery policy without business-node knowledge."""

    def __init__(self, policy: Policy = DEFAULT_POLICY) -> None:
        self.policy = policy

    def can_retry(self, state: Mapping[str, Any], node_id: str, failure_type: str) -> bool:
        """Determine whether the failure type is retryable and budget remains."""
        normalized_failure_type = self._validate_failure_type(failure_type)
        if normalized_failure_type in {"timeout", "no_information_gain"}:
            return False
        attempts = self._attempts_for(state, node_id)
        return attempts < self.policy.max_retries

    def prepare_retry(
        self,
        state: MutableMapping[str, Any] | TaskState,
        node_id: str,
        error: Exception | str,
        failure_type: str,
    ) -> dict[str, Any]:
        """Prepare a generic retry or fail according to failure type and retry budget."""
        normalized_failure_type = self._validate_failure_type(failure_type)
        attempts = self._attempts_for(state, node_id)
        next_attempt = attempts + 1
        if not self.can_retry(state, node_id, normalized_failure_type):
            return self.fail(
                state,
                code="RECOVERY_NOT_RETRYABLE",
                message=f"Failure type {normalized_failure_type} is not retryable or retry limit reached for node {node_id}",
            )

        orchestration = self._orchestration(state)
        attempts_map = orchestration.setdefault("attempts", {})
        attempts_map[node_id] = next_attempt
        orchestration["recovery_action"] = "RETRY"
        orchestration["resume_node"] = node_id
        state["status"] = STATUS_RUNNING
        state["error"] = {
            "code": "RETRY_SCHEDULED",
            "message": str(error),
            "node_id": node_id,
            "attempt": next_attempt,
            "failure_type": normalized_failure_type,
        }
        LOGGER.warning(
            "Retry scheduled: node=%s attempt=%s/%s failure_type=%s error=%s",
            node_id,
            next_attempt,
            self.policy.max_retries,
            normalized_failure_type,
            error,
        )
        return {
            "action": "RETRY",
            "node_id": node_id,
            "attempt": next_attempt,
            "failure_type": normalized_failure_type,
            "error": state["error"],
        }

    def fail(
        self,
        state: MutableMapping[str, Any] | TaskState,
        code: str,
        message: str,
    ) -> dict[str, Any]:
        """Mark the task failed and persist the failure in shared state."""
        error = {"code": code, "message": message}
        state["error"] = error
        state["status"] = STATUS_FAILED
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "FAIL"
        orchestration.pop("resume_node", None)
        LOGGER.error(
            "Task recovery failed: code=%s message=%s",
            code,
            message,
        )
        return {"action": "FAIL", "error": error}

    def pause(
        self,
        state: MutableMapping[str, Any] | TaskState,
        reason: str,
    ) -> dict[str, Any]:
        """Pause a task for later orchestration resume."""
        state["status"] = STATUS_PAUSED
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "PAUSE"
        orchestration["pause_reason"] = reason
        LOGGER.warning("Task paused: %s", reason)
        return {"action": "PAUSE", "reason": reason}

    def resume(
        self,
        state: MutableMapping[str, Any] | TaskState,
    ) -> dict[str, Any]:
        """Resume a paused task."""
        state["status"] = STATUS_RUNNING
        orchestration = self._orchestration(state)
        orchestration["recovery_action"] = "RESUME"
        LOGGER.info("Task resumed")
        return {"action": "RESUME"}

    @staticmethod
    def _validate_failure_type(failure_type: str) -> str:
        """Validate and normalize the generic failure category."""
        normalized = str(failure_type).strip().lower()
        if normalized not in FAILURE_TYPES:
            raise ValueError(
                "Unsupported failure_type: "
                f"{failure_type!r}; expected one of {sorted(FAILURE_TYPES)}"
            )
        return normalized

    @staticmethod
    def _orchestration(
        state: MutableMapping[str, Any],
    ) -> MutableMapping[str, Any]:
        """Return the mutable orchestration state container."""
        value = state.get("orchestration")
        if value is None:
            value = {}
            state["orchestration"] = value
        if not isinstance(value, MutableMapping):
            raise TypeError(
                "state['orchestration'] must be a mutable mapping"
            )
        return value

    @classmethod
    def _attempts_for(
        cls,
        state: Mapping[str, Any],
        node_id: str,
    ) -> int:
        """Read the generic attempt counter from shared state."""
        orchestration = state.get("orchestration", {})
        if not isinstance(orchestration, Mapping):
            return 0
        attempts = orchestration.get("attempts", {})
        if not isinstance(attempts, Mapping):
            return 0
        value = attempts.get(node_id, 0)
        try:
            return max(0, int(value))
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Invalid attempt counter for node {node_id}: {value!r}"
            ) from exc
