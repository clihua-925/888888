"""Mission Director for PSV Trade OS 9.4.1."""

from __future__ import annotations

import logging
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Mapping

from core.config.settings import Settings
from core.memory.db import Database

from .engine import WorkflowEngine
from .registry import WorkflowRegistry
from .state import STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING, TaskState
from .task_understanding import TaskUnderstanding

LOGGER = logging.getLogger(__name__)
DEFAULT_WORKFLOW_ID = "trade_collection"


def _run_task_understanding_thread(container: dict[str, Any], request: str, settings_values: dict[str, Any]) -> None:
    """Run AI mission understanding in a daemon thread for hard timeout enforcement."""
    try:
        settings = Settings(
            app_version=str(settings_values["app_version"]),
            web_host=str(settings_values["web_host"]),
            web_port=int(settings_values["web_port"]),
            llm_base_url=str(settings_values["llm_base_url"]),
            llm_api_key=str(settings_values["llm_api_key"]),
            llm_model=str(settings_values["llm_model"]),
            database_path=Path(settings_values["database_path"]),
            checkpoint_path=Path(settings_values["checkpoint_path"]),
            log_level=str(settings_values["log_level"]),
            max_task_seconds=int(settings_values["max_task_seconds"]),
            max_steps=int(settings_values["max_steps"]),
            max_retries=int(settings_values["max_retries"]),
            no_progress_limit=int(settings_values["no_progress_limit"]),
        )
        from core.model.reasoning import ReasoningEngine
        from .decision import DecisionLayer
        understanding = TaskUnderstanding(
            decision_layer=DecisionLayer(reasoning_engine=ReasoningEngine(settings))
        )
        mission = understanding.understand(request)
        container["result"] = {"ok": True, "mission": mission, "decision": dict(understanding.last_decision)}
    except Exception as exc:
        LOGGER.exception("Task understanding worker thread failed")
        container["result"] = {"ok": False, "error": str(exc)}


class MissionDirector:
    """Create standard Missions and delegate execution to the workflow engine."""

    def __init__(
        self,
        database: Database,
        registry: WorkflowRegistry,
        task_understanding: TaskUnderstanding,
        engine: WorkflowEngine,
    ) -> None:
        self.database = database
        self.registry = registry
        self.task_understanding = task_understanding
        self.engine = engine

    def create(
        self,
        request: str,
        market: str,
        industry: str,
        workflow_id: str | None = None,
    ) -> str:
        """Create a pending task and defer AI understanding to execution time."""
        selected_workflow_id = (workflow_id or DEFAULT_WORKFLOW_ID).strip()
        workflow = self.registry.get(selected_workflow_id)
        task_id = self.create_pending(
            request=request, market=market, industry=industry, workflow_id=workflow.workflow_id
        )
        return task_id

    def create_pending(
        self,
        request: str,
        market: str,
        industry: str,
        workflow_id: str | None = None,
    ) -> str:
        """Persist a pending task without blocking the HTTP submission path on AI inference."""
        selected_workflow_id = (workflow_id or DEFAULT_WORKFLOW_ID).strip()
        workflow = self.registry.get(selected_workflow_id)
        normalized_request = str(request).strip()
        normalized_market = str(market).strip()
        normalized_industry = str(industry).strip()
        if not normalized_request:
            raise ValueError("request must not be empty")
        if not normalized_market:
            raise ValueError("market must not be empty")
        if not normalized_industry:
            raise ValueError("industry must not be empty")
        task_id = str(uuid.uuid4())
        mission: dict[str, Any] = {
            "intent": "",
            "task_type": "",
            "objective": normalized_request,
            "targets": [],
            "constraints": [],
            "success_criteria": [],
            "market": normalized_market,
            "industry": normalized_industry,
            "request": normalized_request,
        }
        state: TaskState = {
            "mission": mission,
            "product_definition": {},
            "trade_nodes": [],
            "fragments": [],
            "search_queries": [],
            "evidence_pool": [],
            "entities": [],
            "relationships": [],
            "decisions": [],
            "history": [],
            "orchestration": {"step_count": 0, "no_progress_count": 0},
            "error": {},
            "node_reports": {},
            "status": STATUS_PENDING,
            "task_id": task_id,
            "workflow_id": workflow.workflow_id,
            "workflow_version": workflow.version,
        }
        self.database.create_task(task_id, workflow.workflow_id, state, STATUS_PENDING)
        self.database.add_event(
            task_id, "TASK_CREATED", status=STATUS_PENDING,
            payload={"workflow_id": workflow.workflow_id, "ai_understanding": "deferred"},
        )
        LOGGER.info("Mission task created: task_id=%s workflow_id=%s", task_id, workflow.workflow_id)
        return task_id

    def execute(self, task_id: str) -> TaskState:
        """Execute a persisted task with lifecycle-wide hard timeout enforcement."""
        started = time.monotonic()
        try:
            record = self.database.get_task(task_id)
            workflow = self.registry.get(record["workflow_id"])
            state = dict(record["state"])
            state["status"] = STATUS_RUNNING
            self.database.update_task(task_id, state, STATUS_RUNNING)
            self.database.add_event(task_id, "TASK_EXECUTION_STARTED", status=STATUS_RUNNING)

            max_seconds = max(1, int(self.engine.policy.max_task_seconds))
            understanding_timeout = min(120, max_seconds)
            remaining_before_ai = max_seconds - (time.monotonic() - started)
            if remaining_before_ai <= 0:
                return self._fail_timeout(task_id, state, 0)
            container: dict[str, Any] = {}
            worker = threading.Thread(
                target=_run_task_understanding_thread,
                args=(container, str(state["mission"].get("request", "")), self._settings_values()),
                name=f"psv-understanding-{task_id}",
                daemon=True,
            )
            worker.start()
            worker.join(min(understanding_timeout, int(remaining_before_ai)))
            if worker.is_alive():
                return self._fail_timeout(task_id, state, int(understanding_timeout))
            message = container.get("result")
            if message is None:
                raise RuntimeError("Task understanding worker returned no result")
            if not message.get("ok"):
                raise RuntimeError(str(message.get("error", "Task understanding failed")))

            mission = dict(message["mission"])
            mission["market"] = str(state["mission"].get("market", "")).strip()
            mission["industry"] = str(state["mission"].get("industry", "")).strip()
            state["mission"] = mission
            decision_record = dict(message.get("decision", {}))
            if decision_record:
                self.database.add_event(
                    task_id, "AI_DECISION", node_id="TASK_UNDERSTANDING", status=STATUS_RUNNING,
                    payload={
                        "decision_type": decision_record.get("decision_type", "mission_understanding"),
                        "node_id": "TASK_UNDERSTANDING", "confidence": decision_record.get("confidence"),
                        "rationale": decision_record.get("rationale"), "decision": decision_record.get("decision"),
                        "metadata": decision_record.get("metadata", {}),
                    },
                )
            self.database.update_task(task_id, state, STATUS_RUNNING)
            elapsed = time.monotonic() - started
            remaining = max(0, int(max_seconds - elapsed))
            if remaining <= 0:
                return self._fail_timeout(task_id, state, max_seconds)
            result = self.engine.run(state, workflow, resume=False, timeout_seconds=remaining)
            final_status = str(result.get("status", STATUS_FAILED))
            self.database.update_task(task_id, result, final_status)
            self.database.add_event(task_id, "TASK_EXECUTION_FINISHED", status=final_status)
            return result
        except Exception as exc:
            LOGGER.exception("Mission execution failed: task_id=%s", task_id)
            record = self.database.get_task(task_id)
            state = dict(record["state"])
            state["status"] = STATUS_FAILED
            state["error"] = {"code": "MISSION_EXECUTION_ERROR", "message": str(exc)}
            self.database.update_task(task_id, state, STATUS_FAILED)
            self.database.add_event(task_id, "TASK_EXECUTION_FAILED", status=STATUS_FAILED, payload=state["error"])
            raise

    def _fail_timeout(self, task_id: str, state: Mapping[str, Any], elapsed_or_limit: int) -> TaskState:
        """Persist a lifecycle timeout after an isolated stage exceeds its hard budget."""
        failed = dict(state)
        failed["status"] = "TASK_TIMEOUT"
        failed["error"] = {
            "code": "MAX_TASK_SECONDS",
            "message": f"Task exceeded hard timeout during mission lifecycle (limit {self.engine.policy.max_task_seconds}s)",
        }
        orchestration = dict(failed.get("orchestration", {}))
        orchestration["recovery_action"] = "TIMEOUT"
        orchestration["timeout_stage"] = "TASK_UNDERSTANDING"
        failed["orchestration"] = orchestration
        self.database.update_task(task_id, failed, "TASK_TIMEOUT")
        self.database.add_event(task_id, "TASK_TIMEOUT", status="TASK_TIMEOUT", payload=failed["error"] | {"elapsed": elapsed_or_limit})
        return failed

    def _settings_values(self) -> dict[str, Any]:
        settings = self.engine.settings
        return {
            "app_version": settings.app_version, "web_host": settings.web_host, "web_port": settings.web_port,
            "llm_base_url": settings.llm_base_url, "llm_api_key": settings.llm_api_key, "llm_model": settings.llm_model,
            "database_path": str(settings.database_path), "checkpoint_path": str(settings.checkpoint_path),
            "log_level": settings.log_level, "max_task_seconds": settings.max_task_seconds,
            "max_steps": settings.max_steps, "max_retries": settings.max_retries, "no_progress_limit": settings.no_progress_limit,
        }

    def resume(self, task_id: str) -> TaskState:
        """Resume a task from its durable LangGraph checkpoint."""
        record = self.database.get_task(task_id)
        workflow = self.registry.get(record["workflow_id"])
        state = dict(record["state"])
        state["task_id"] = task_id
        state["status"] = STATUS_RUNNING
        self.database.update_task(task_id, state, STATUS_RUNNING)
        self.database.add_event(task_id, "TASK_RESUME_STARTED", status=STATUS_RUNNING)
        self.database.add_event(
            task_id,
            "CHECKPOINT",
            status=STATUS_RUNNING,
            payload={"action": "restore_requested", "thread_id": task_id},
        )
        try:
            result = self.engine.run(state, workflow, resume=True)
            final_status = str(result.get("status", STATUS_FAILED))
            self.database.update_task(task_id, result, final_status)
            self.database.add_event(task_id, "TASK_RESUME_FINISHED", status=final_status)
            return result
        except Exception as exc:
            LOGGER.exception("Mission resume failed: task_id=%s", task_id)
            failed = dict(state)
            failed["status"] = STATUS_FAILED
            failed["error"] = {"code": "MISSION_RESUME_ERROR", "message": str(exc)}
            self.database.update_task(task_id, failed, STATUS_FAILED)
            self.database.add_event(task_id, "TASK_RESUME_FAILED", status=STATUS_FAILED, payload=failed["error"])
            raise
