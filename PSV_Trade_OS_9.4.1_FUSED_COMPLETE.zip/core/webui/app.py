"""Unified Flask Web API and WebUI for PSV Trade OS 9.4.1."""

from __future__ import annotations

import json
import logging
import threading
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request, send_from_directory

from core.config.markets import markets as load_configured_markets
from core.config.settings import APP_VERSION, Settings
from core.memory.db import Database
from core.orchestration.conditions import ConditionEdgeEngine
from core.orchestration.engine import WorkflowEngine
from core.orchestration.mission import MissionDirector
from core.orchestration.policies import Policy
from core.orchestration.recovery import RecoveryManager
from core.orchestration.registry import WorkflowRegistry
from core.orchestration.scheduler import WorkflowScheduler
from core.orchestration.state import STATUS_PENDING
from core.orchestration.task_understanding import TaskUnderstanding

LOGGER = logging.getLogger(__name__)
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
_PLATFORM_LOCK = threading.Lock()
_PLATFORM_CACHE: dict[str, Any] = {}


DEFAULT_MARKETS = [
    {"id": "US", "name": "United States"},
    {"id": "EU", "name": "European Union"},
    {"id": "CN", "name": "China"},
    {"id": "JP", "name": "Japan"},
    {"id": "KR", "name": "South Korea"},
    {"id": "ASEAN", "name": "ASEAN"},
]


def _build_platform(runtime_settings: Settings) -> tuple[Database, WorkflowRegistry, WorkflowScheduler]:
    """Build the WebUI orchestration boundary once per application process."""
    cache_key = str(runtime_settings.database_path)
    with _PLATFORM_LOCK:
        cached = _PLATFORM_CACHE.get(cache_key)
        if cached is not None:
            return cached["database"], cached["registry"], cached["scheduler"]

        runtime_settings.ensure_directories()
        database = Database(runtime_settings.database_path)
        registry = WorkflowRegistry()
        registry.discover()
        policy = Policy(
            max_task_seconds=runtime_settings.max_task_seconds,
            max_steps=runtime_settings.max_steps,
            max_retries=runtime_settings.max_retries,
            no_progress_limit=runtime_settings.no_progress_limit,
            version=runtime_settings.app_version,
        )
        engine = WorkflowEngine(
            registry=registry,
            condition_engine=ConditionEdgeEngine(),
            recovery_manager=RecoveryManager(policy),
            policy=policy,
            database=database,
            settings=runtime_settings,
        )
        mission_director = MissionDirector(
            database=database,
            registry=registry,
            task_understanding=TaskUnderstanding(),
            engine=engine,
        )
        scheduler = WorkflowScheduler(mission_director)
        _PLATFORM_CACHE[cache_key] = {
            "database": database,
            "registry": registry,
            "scheduler": scheduler,
        }
        return database, registry, scheduler


def _workflow_payload(workflow: Any) -> dict[str, Any]:
    """Convert a registered workflow to a stable JSON-safe API shape."""
    return {
        "workflow_id": workflow.workflow_id,
        "version": workflow.version,
        "nodes": list(workflow.node_ids),
        "capabilities": list(workflow.capabilities),
    }


def _load_markets(runtime_settings: Settings) -> list[dict[str, str]]:
    """Load data/markets.json when available, otherwise use the frozen default list."""
    market_path = Path("data/markets.json")
    if not market_path.is_absolute():
        market_path = Path.cwd() / market_path
    if not market_path.exists():
        return list(DEFAULT_MARKETS)
    try:
        configured = load_configured_markets()
    except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
        LOGGER.warning("Unable to read market configuration %s: %s", market_path, exc)
        return list(DEFAULT_MARKETS)
    markets: list[dict[str, str]] = []
    for item in configured:
        if not isinstance(item, dict):
            continue
        market_id = str(item.get("id") or item.get("code") or "").strip()
        market_name = str(item.get("name") or "").strip()
        if market_id and market_name:
            markets.append({"id": market_id, "name": market_name})
    return markets or list(DEFAULT_MARKETS)


def create_app(
    runtime_settings: Settings | None = None,
    *,
    database: Database | None = None,
    registry: WorkflowRegistry | None = None,
    scheduler: WorkflowScheduler | None = None,
) -> Flask:
    """Create the unified Flask application with injectable orchestration boundaries."""
    settings = runtime_settings if runtime_settings is not None else Settings()
    if database is None or registry is None or scheduler is None:
        database, registry, scheduler = _build_platform(settings)

    flask_app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="/static")
    flask_app.config["PSV_VERSION"] = APP_VERSION
    flask_app.extensions["psv_database"] = database
    flask_app.extensions["psv_registry"] = registry
    flask_app.extensions["psv_scheduler"] = scheduler
    flask_app.extensions["psv_settings"] = settings

    @flask_app.get("/")
    def mission_console() -> Any:
        """Serve the single unified orchestration console."""
        return send_from_directory(STATIC_DIR, "mission.html")

    @flask_app.get("/api/health")
    def health() -> Any:
        """Return service health and registered workflows."""
        workflows = flask_app.extensions["psv_registry"].workflows()
        return jsonify({
            "ok": True,
            "version": APP_VERSION,
            "status": "healthy",
            "llm_model": settings.llm_model,
            "workflows": [workflow.workflow_id for workflow in workflows],
        }), 200

    @flask_app.get("/api/orchestration/workflows")
    def orchestration_workflows() -> Any:
        """Return dynamically registered workflows."""
        workflows = flask_app.extensions["psv_registry"].workflows()
        return jsonify({"workflows": [_workflow_payload(workflow) for workflow in workflows]}), 200

    @flask_app.post("/api/orchestration/run")
    def orchestration_run() -> Any:
        """Submit a Mission through WorkflowScheduler."""
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Request body must be a JSON object"}), 400
        request_text = str(payload.get("request", "")).strip()
        market = str(payload.get("market", "")).strip()
        industry = str(payload.get("industry", "")).strip()
        workflow_id_value = payload.get("workflow_id")
        workflow_id = str(workflow_id_value).strip() if workflow_id_value is not None else None
        if not request_text:
            return jsonify({"error": "request is required"}), 400
        if not market:
            return jsonify({"error": "market is required"}), 400
        if not industry:
            return jsonify({"error": "industry is required"}), 400
        selected_workflow = workflow_id or "trade_collection"
        try:
            flask_app.extensions["psv_registry"].get(selected_workflow)
        except KeyError as exc:
            return jsonify({"error": str(exc)}), 404
        try:
            task_id = flask_app.extensions["psv_scheduler"].submit(
                workflow_id=selected_workflow,
                request=request_text,
                market=market,
                industry=industry,
            )
        except Exception as exc:
            LOGGER.exception("Workflow submission failed")
            return jsonify({"error": f"Workflow submission failed: {exc}"}), 500
        return jsonify({
            "ok": True,
            "task_id": task_id,
            "workflow_id": selected_workflow,
            "status": STATUS_PENDING,
        }), 202

    @flask_app.get("/api/orchestration/tasks/<task_id>")
    def orchestration_task(task_id: str) -> Any:
        """Return persisted task state plus Decisions, Evidence, Audit, and commit information."""
        normalized_task_id = task_id.strip()
        if not normalized_task_id:
            return jsonify({"error": "task_id is required"}), 400
        try:
            record = flask_app.extensions["psv_database"].get_task(normalized_task_id)
            audit = flask_app.extensions["psv_database"].get_task_events(normalized_task_id)
        except KeyError:
            return jsonify({"error": f"Task not found: {normalized_task_id}"}), 404
        state = record.get("state", {})
        node_reports = state.get("node_reports", {})
        database_report = node_reports.get("DATABASE_COMMIT", {})
        response = {
            "ok": True,
            "task_id": record["task_id"],
            "workflow_id": record["workflow_id"],
            "status": record["status"],
            "created_at": record["created_at"],
            "updated_at": record["updated_at"],
            "state": state,
            "decisions": state.get("decisions", []),
            "evidence": state.get("evidence_pool", []),
            "audit": audit,
            "node_reports": node_reports,
            "recovery": {
                "retries": state.get("orchestration", {}).get("retry_count", 0),
                "action": state.get("orchestration", {}).get("recovery_action"),
                "error": state.get("error", {}),
            },
            "database_commit": database_report,
        }
        return jsonify(response), 200

    @flask_app.get("/api/config/markets")
    def config_markets() -> Any:
        """Return available market configuration."""
        return jsonify({"markets": _load_markets(settings)}), 200

    @flask_app.errorhandler(404)
    def not_found(error: Any) -> Any:
        """Return JSON for unknown routes while keeping the root console available."""
        return jsonify({"error": "Not found", "path": request.path}), 404

    @flask_app.errorhandler(405)
    def method_not_allowed(error: Any) -> Any:
        """Return JSON for unsupported methods."""
        return jsonify({"error": "Method not allowed", "path": request.path}), 405

    @flask_app.errorhandler(500)
    def internal_error(error: Any) -> Any:
        """Return JSON for uncaught application errors."""
        LOGGER.exception("Unhandled WebUI error")
        return jsonify({"error": "Internal server error"}), 500

    @flask_app.get("/api/entities")
    def list_entities():
        database = flask_app.extensions["psv_database"]
        role = str(request.args.get("role", "") or "").strip().lower()
        rows = database.list_trade_entities(role=role)
        return jsonify({"entities": rows})

    @flask_app.get("/api/relationships")
    def list_relationships():
        database = flask_app.extensions["psv_database"]
        rows = database.list_trade_relationships()
        return jsonify({"relationships": rows})

    @flask_app.get("/api/letters")
    def list_letters():
        database = flask_app.extensions["psv_database"]
        rows = database.list_outreach_letters()
        return jsonify({"letters": rows})

    return flask_app


app = create_app()


if __name__ == "__main__":
    runtime_settings = app.extensions["psv_settings"]
    print(f"PSV Trade OS {APP_VERSION} WebUI: http://{runtime_settings.web_host}:{runtime_settings.web_port}")
    print(f"PSV Trade OS {APP_VERSION} API ready on {runtime_settings.web_host}:{runtime_settings.web_port}")
    app.run(host=runtime_settings.web_host, port=runtime_settings.web_port)
