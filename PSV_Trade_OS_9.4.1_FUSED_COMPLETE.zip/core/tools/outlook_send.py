# -*- coding: utf-8 -*-
"""v38 微软邮箱自动发送（销售执行层）。

链路：预检 → 打开 Outlook 写信页（自动填入收件人/主题/正文）→ 登录检测 → 自动点击"发送" → 写回状态。
原则：
- 不以后台 SMTP 直发为前提；发送动作发生在用户自己的微软邮箱里（Playwright 接管 CDP 浏览器）。
- 邮箱未登录 / 浏览器未启动 / 环境不满足 → 明确报错并停在可恢复位置（消息状态保持 ready_to_send）。
- 绝不假装成功：只有真正点到发送按钮才写 sent。
"""
import time
from core.config import settings
from core.memory.db import DB

SEND_SELECTORS = [
    'button[title="发送"]', 'button[aria-label="发送"]',
    'button[title="Send"]', 'button[aria-label="Send"]',
    '[role="button"][title="Send"]', 'button.ms-Button--primary[title]',
]
LOGIN_HINTS = ('login.microsoftonline.com', 'login.live.com', 'account.microsoft.com')


def preflight(norm):
    """返回 (ok, ctx, error)。ctx 含 msg/to/subject/body；error 是人话原因。"""
    db = DB()
    msg = db.latest_out_message(norm)
    if not msg or not msg.get('draft'):
        return False, {}, '没有可发送的开发信草稿'
    content = msg.get('content', '')
    subject, body = 'PSV introduction', content
    lines = content.splitlines()
    if lines and lines[0].lower().startswith('subject:'):
        subject = lines[0].split(':', 1)[1].strip() or subject
        body = '\n'.join(lines[1:]).strip()
    to = ''
    contacts = db.list_contacts(norm)
    rec = next((c for c in contacts if c.get('email') and c.get('email_status') in ('mx_ok', 'pattern', 'syntax_ok')), None)
    if rec: to = rec['email']
    if not to:
        import re
        lead = db.get_lead(norm) or {}
        to = next((e for e in re.split(r'[,;\s]+', str(lead.get('emails') or '')) if '@' in e), '')
    if not to:
        return False, {}, '无收件人：请先补全或找联系人'
    from core.tools.web_ai import _cdp_alive
    if not (settings.IY_WEB_CDP_ENABLED and _cdp_alive(settings.IY_WEB_CDP_URL)):
        return False, {}, 'AI 浏览器(9222)未启动——先双击 start_chrome_debug.bat'
    return True, {'msg': msg, 'to': to, 'subject': subject, 'body': body}, ''


def auto_send(norm):
    """自动完成：打开邮箱→填充→点击发送。返回 {'ok','status','to','error'}。
    失败时消息状态保持 ready_to_send（可恢复位置），成功写 sent。"""
    db = DB()
    ok, ctx, err = preflight(norm)
    if not ok:
        return {'ok': False, 'status': 'ready_to_send', 'error': err}
    msg, to, subject, body = ctx['msg'], ctx['to'], ctx['subject'], ctx['body']
    db.set_message_status(msg['id'], 'ready_to_send')
    from core.tools import mailer
    url = mailer.compose_url(to, subject, body, provider='outlook')
    pw = None
    try:
        from playwright.sync_api import sync_playwright
        pw = sync_playwright().start()
        br = pw.chromium.connect_over_cdp(settings.IY_WEB_CDP_URL)
        ctx0 = br.contexts[0]
        pg = ctx0.new_page()
        pg.goto(url, timeout=60000, wait_until='domcontentloaded')
        pg.wait_for_timeout(4000)
        # 登录检测：被重定向到登录页 → 明确提示，停在可恢复位置
        cur = (pg.url or '').lower()
        if any(h in cur for h in LOGIN_HINTS):
            try: pg.close()
            except Exception: ...
            db.set_message_status(msg['id'], 'send_failed', reason='微软邮箱未登录——请在 AI 浏览器里登录 Outlook 后重试')
            return {'ok': False, 'status': 'send_failed', 'to': to,
                    'error': '微软邮箱未登录——请在 AI 浏览器里登录 Outlook 后重试（草稿已保留）'}
        # v39 五态：写信页已打开并填充完成 → opened（已打开），随后自动点击发送
        db.set_message_status(msg['id'], 'opened')
        clicked = False
        for _ in range(6):  # 写信页异步渲染，轮询等待发送按钮出现
            for sel in SEND_SELECTORS:
                try:
                    el = pg.query_selector(sel)
                    if el and el.is_visible() and el.is_enabled():
                        el.click(); clicked = True; break
                except Exception:
                    continue
            if clicked: break
            pg.wait_for_timeout(1500)
        if not clicked:
            try: pg.close()
            except Exception: ...
            db.set_message_status(msg['id'], 'send_failed', reason='未找到可用的发送按钮（Outlook 界面可能改版或邮件未填充完成）')
            return {'ok': False, 'status': 'send_failed', 'to': to,
                    'error': '未找到可用的"发送"按钮（Outlook 界面可能改版或邮件未填充完成）——邮件已在邮箱中打开，可在该页人工检查后发送'}
        pg.wait_for_timeout(3000)
        try: pg.close()
        except Exception: ...
        db.set_message_status(msg['id'], 'sent', sent=True)
        db.add_enrichment_event(norm, 'outreach', 'outlook_auto_send', to, True)
        return {'ok': True, 'status': 'sent', 'to': to}
    except Exception as e:
        db.set_message_status(msg['id'], 'send_failed', reason='自动发送异常：' + str(e)[:200])
        return {'ok': False, 'status': 'send_failed', 'to': to,
                'error': '自动发送失败：' + str(e)[:200] + '（草稿已保留，可恢复重试）'}
    finally:
        if pw:
            try: pw.stop()
            except Exception: ...
