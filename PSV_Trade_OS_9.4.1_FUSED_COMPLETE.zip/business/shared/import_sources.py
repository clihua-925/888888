"""Shared multi-source import-record loader (local first, IY human-like browser session, IY API, graceful degrade)."""
from __future__ import annotations
import time

import json
import os
import re
import urllib.parse
import urllib.request
from pathlib import Path

_TIMEOUT = 15


def _load_local(market: str, industry: str) -> list:
    m = str(market or "").strip().lower().replace(" ", "_")
    ind = str(industry or "").strip().lower()
    candidates = []
    if m and ind:
        candidates.append(Path("data/imports") / f"{m}_{ind}.json")
    candidates.append(Path("data/imports/records.json"))
    for path in candidates:
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    return [x for x in data if isinstance(x, dict)]
        except Exception:
            continue
    return []


_IY_CHROME_LABELS = {
    "customers", "customer", "suppliers", "supplier", "products", "product",
    "shipments", "shipment", "search", "results", "result", "home", "about",
    "contact", "login", "sign up", "signup", "companies", "company", "importers",
    "exporters", "importer", "exporter", "pages", "page", "menu", "help",
    "total sea shipments over time", "top shippers", "recent searches",
    "trending searches", "importyeti", "all rights reserved", "privacy", "terms",
}


_BUSINESS_SUFFIXES = re.compile(
    r"(llc|inc|corp|co|ltd|group|trading|importers?|exporters?|company|enterprise|gmbh|sarl|bv|b\.v|spa|pty)"
)


def _looks_like_company_name(name, reject_words=None) -> bool:
    """剔除 ImportYeti 页面导航/标题文字，只留公司名。

    reject_words: 与查询词/产品词相同的单词名直接拒收（如查询"Felt"时
    结果里的"Felt"是查询词本身不是公司）；单词短名必须带商业后缀。
    """
    text = str(name or "").strip()
    if len(text) < 4 or len(text) > 80 or not any(ch.isalpha() for ch in text):
        return False
    low = text.lower()
    if low in _IY_CHROME_LABELS:
        return False
    if reject_words and low in reject_words:
        return False
    if len(low.split()) < 2 and not _BUSINESS_SUFFIXES.search(low):
        return False
    return True


def _collect_company_names(page) -> list:
    """从结果页收集 /company/ 链接文本（滚动两轮去重）。"""
    def _once() -> list:
        names = []
        for a in page.query_selector_all('a[href*="/company/"]'):
            try:
                text = (a.inner_text() or "").strip()
            except Exception:
                continue
            if text and text not in names:
                names.append(text)
        return names

    found = _once()
    for _ in range(2):
        if not found:
            break
        try:
            page.mouse.wheel(0, 900)
            page.wait_for_timeout(1500)
            for name in _once():
                if name not in found:
                    found.append(name)
        except Exception:
            break
    return found


_FAST_SELECTORS = (
    'input[type="search"], input[placeholder*="earch" i], input[name="q"], '
    'input[aria-label*="earch" i], input[data-testid*="earch" i], '
    'textarea[placeholder*="earch" i], form input[type="text"]'
)


def _fast_search(page, query: str):
    """快通道：直接选择器搜索，无 LLM，全程约 15-20 秒。

    返回名单表示成功；返回 None 表示失败（无搜索框/等待超时/异常），
    由调用方决定是否升级 DOM Agent 慢通道。
    """
    try:
        box = page.query_selector(_FAST_SELECTORS)
        if box is None:
            return None
        box.click()
        box.fill("")
        box.type(query, delay=40)
        page.keyboard.press("Enter")
        page.wait_for_selector('a[href*="/company/"]', timeout=12000)
        page.wait_for_timeout(1200)
        return _collect_company_names(page)
    except Exception:
        return None


def _human_search_once(page, query: str, diag: dict, reject_words=None) -> list:
    """双通道仿人工搜索。

    快通道（选择器直搜，≤20秒）优先；失败才升级 DOM Agent 恢复（每查询
    预算180秒，模型逐步决策）。成功（结果页出现公司链接）后收集并过滤；
    失败把错误与决策历史写进 diag，返回空列表走下一数据源。
    """
    reject = {str(w).strip().lower() for w in (reject_words or []) if str(w).strip()}
    fast = _fast_search(page, query)
    if fast is not None:
        names = [nm for nm in fast if _looks_like_company_name(nm, reject)]
        diag["browser_error"] = "" if names else "fast_path_no_results"
        return names
    from core.tools.dom_agent import DOMAgent
    agent = DOMAgent()
    goal = f'在 ImportYeti 首页搜索框输入 "{query}"，然后按回车或点击搜索按钮，等待结果页面出现公司链接'
    result = agent.run_goal(page, goal, max_steps=10, budget_ms=180000)
    if not result.get("done"):
        diag["browser_error"] = result.get("error") or "dom_agent_failed"
        diag["dom_history"] = result.get("history") or []
        return []
    names = _collect_company_names(page)
    return [nm for nm in names if _looks_like_company_name(nm, reject)]


def _fetch_importyeti_browser(market: str, industry: str, limit: int = 60,
                              queries: list | None = None, diag: dict | None = None) -> list:
    """仿人工浏览器采集主循环：多查询轮询（策略来自方案节点），全程可见（IY_BROWSER_VISIBLE=0 关闭）。"""
    import time as _time
    if diag is None:
        diag = {}
    def _fail(reason: str) -> list:
        diag["browser_error"] = reason
        return []
    if not (queries or industry or market):
        return _fail("empty_query")
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return _fail("playwright_missing")
    try:
        cdp = os.environ.get("OUTLOOK_CDP_URL", "http://127.0.0.1:9222")
        visible = os.environ.get("IY_BROWSER_VISIBLE", "1").strip() != "0"
        with sync_playwright() as pw:
            try:
                browser = pw.chromium.connect_over_cdp(cdp)
            except Exception as exc:
                return _fail(f"cdp_unreachable: {type(exc).__name__}")
            context = browser.contexts[0] if browser.contexts else None
            if context is None:
                return _fail("no_browser_context")
            page = None
            for pg in context.pages:
                if "importyeti.com" in (pg.url or ""):
                    page = pg
                    break
            if page is None:
                page = context.new_page()
            # 始终回到首页再搜索：公司详情页/其他子页面没有搜索框，
            # 之前的"复用任意importyeti页面"逻辑会在公司页上抓版块标题当公司名。
            try:
                page.goto("https://www.importyeti.com/", timeout=60000, wait_until="domcontentloaded")
                try:
                    page.wait_for_load_state("networkidle", timeout=10000)
                except Exception:
                    page.wait_for_timeout(3000)
            except Exception:
                page.wait_for_timeout(1000)  # 首页打不开也继续，搜索盒检测会给出真实错误
            # Cloudflare挑战等待（参考老版iy_web.py的轮询思路）：
            # 出现挑战页时等搜索框出现，最长20秒；超时如实报错。
            try:
                head = page.evaluate("() => (document.body ? document.body.innerText.slice(0, 400) : '')") or ""
            except Exception:
                head = ""
            if re.search(r"just a moment|attention required|cf-chl|verify you are", head, re.I):
                diag["browser_error"] = "cloudflare"
                try:
                    page.wait_for_selector('input[type="search"], input[placeholder*="earch" i], input[name="q"]', timeout=20000)
                    diag["browser_error"] = ""
                except Exception:
                    return _fail(diag, "cloudflare_timeout")
            if visible:
                try:
                    page.bring_to_front()
                except Exception:
                    ...
            out = []
            seen_names = set()
            qi = 0
            total_deadline = time.time() + 360  # 浏览器源总预算6分钟
            default_queries = [q for q in (str(industry or "").strip(),) if q] or [str(market or "").strip()]
            for qi, query in enumerate(list(queries or default_queries)[:4], start=1):
                if len(out) >= limit:
                    break
                if time.time() > total_deadline:
                    diag["browser_error"] = diag.get("browser_error") or "source_budget_exceeded"
                    break
                try:
                    names = _human_search_once(page, query, diag, reject_words={query, industry, market, "importyeti"})
                except Exception as exc:  # DOM Agent 自身异常不应中断整个浏览器源
                    diag["browser_error"] = f"dom_agent_exception:{type(exc).__name__}"
                    break
                for name in names:
                    if name in seen_names or len(out) >= limit:
                        continue
                    seen_names.add(name)
                    out.append({
                        "node_id": f"IYB_{len(out)+1:04d}",
                        "name": name,
                        "role": "buyer",
                        "country": market,
                        "shipments": 0,
                        "industry": industry,
                        "source": "importyeti_browser",
                        "metadata": {"query": query},
                    })
                _time.sleep(1.2)
            if not out:
                return _fail(diag.get("browser_error") or "empty_extraction")
            diag["browser_queries"] = qi
            diag["browser_error"] = ""
            return out
    except Exception as exc:
        return _fail(f"exception: {type(exc).__name__}: {str(exc)[:120]}")


def _fetch_importyeti(market: str, industry: str, diag: dict | None = None) -> list:
    """ImportYeti 公开摘要 API（v45 原版同款端点，匿名免 key，curl_cffi Chrome 指纹优先）。"""
    def _fail(reason: str) -> list:
        if diag is not None:
            diag["http_error"] = reason
        return []
    if str(market).strip().lower() not in ("us", "usa", "united states", "america", "\u7f8e\u56fd", ""):
        return _fail("unsupported_market")
    query = f"{industry}".strip()
    if not query:
        return _fail("empty_query")
    try:
        from core.config.industry import load_industry
        profile = load_industry(industry) or {}
        for word in (profile.get("keywords") or []) + (profile.get("product_terms") or []):
            word = str(word).strip()
            if word and re.search(r"[A-Za-z]", word):
                query = word
                break
    except Exception:
        query = query
    try:
        url = "https://www.importyeti.com/api/search?q=" + urllib.parse.quote(query) + "&page=1"
        payload = None
        try:
            from curl_cffi import requests as creq
            resp = creq.get(url, impersonate="chrome", timeout=_TIMEOUT,
                            headers={"Referer": "https://www.importyeti.com/"})
            if resp.status_code == 200:
                payload = resp.json()
            else:
                return _fail(f"http_{resp.status_code}")
        except ImportError:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
                "Accept": "application/json, text/plain, */*",
                "Referer": "https://www.importyeti.com/",
            })
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                payload = json.loads(resp.read().decode("utf-8", "replace"))
        rows = []
        if isinstance(payload, dict):
            rows = payload.get("searchResults") or payload.get("results") or payload.get("data") or []
        if not isinstance(rows, list) or not rows:
            return _fail("empty_results")
        if diag is not None:
            diag["http_error"] = ""
        out = []
        for idx, item in enumerate(rows[:50], start=1):
            if not isinstance(item, dict):
                continue
            name = item.get("title") or item.get("name") or item.get("companyName") or ""
            name = str(name).strip()
            if len(name) < 2:
                continue
            try:
                shipments = int(item.get("totalShipments") or 0)
            except (TypeError, ValueError):
                shipments = 0
            out.append({
                "node_id": f"IY_{idx:04d}",
                "name": name,
                "role": "buyer",
                "country": "United States",
                "shipments": shipments,
                "industry": industry,
                "source": "importyeti",
                "metadata": {"website": item.get("website") or "", "address": item.get("address") or ""},
            })
        if not out:
            return _fail("no_valid_rows")
        return out
    except Exception as exc:
        return _fail(f"exception: {type(exc).__name__}: {str(exc)[:120]}")


def fetch_comtrade_flows(hs_code: str = "", reporter: str = "USA", partner: str = "World",
                         period: str = "2024", max_records: int = 50) -> list:
    """UN Comtrade 宏观贸易流校验（免费 key，注册即得，免费档 500 次/日）。"""
    key = os.environ.get("COMTRADE_API_KEY", "").strip()
    if not key or not hs_code:
        return []
    try:
        url = (
            "https://comtradeapi.un.org/public/v1/preview/C/A/HS"
            f"?reporterCode={reporter}&partnerCode={partner}&period={period}"
            f"&cmdCode={hs_code}&maxRecords={max_records}"
        )
        req = urllib.request.Request(url, headers={"Ocp-Apim-Subscription-Key": key, "User-Agent": "PSV-Trade-OS/9.4"})
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            payload = json.loads(resp.read().decode("utf-8", "replace"))
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            return []
        return [{
            "reporter": item.get("reporterDesc", ""),
            "partner": item.get("partnerDesc", ""),
            "flow": item.get("flowDesc", ""),
            "hs": item.get("cmdCode", ""),
            "value_usd": item.get("primaryValue", 0),
            "period": item.get("period", ""),
        } for item in data[:max_records] if isinstance(item, dict)]
    except Exception:
        return []


def load_import_records_diag(market: str = "", industry: str = "", queries: list | None = None,
                             accept=None) -> tuple:
    """级联加载并返回各源诊断：本地 → 浏览器会话(仿人工多查询) → 匿名HTTP。

    accept: 可选判定谓词。某源有原始记录但 0 条通过 accept 时视为"该源无有效
    数据"，继续下一级——修复旧版"本地文件存在即短路、过滤后 0 条静默无数据"。
    """
    diag = {"local": 0, "browser": 0, "http": 0, "used": "none", "errors": []}

    def _kept(records: list) -> list:
        if accept is None or not records:
            return records
        return [item for item in records if accept(item)]

    # 1) 本地
    local_records = _load_local(market, industry)
    diag["local"] = len(local_records)
    kept = _kept(local_records)
    diag["local_kept"] = len(kept)
    if kept:
        diag["used"] = "local"
        return kept, diag
    if local_records:
        diag["errors"].append("local: all_filtered")

    # 2) 仿人工浏览器会话（可见；IY_BROWSER_ENABLED=0 关闭）
    if os.environ.get("IY_BROWSER_ENABLED", "1").strip() == "1":
        browser_records = _fetch_importyeti_browser(market, industry, diag=diag, queries=queries) or []
        diag["browser"] = len(browser_records)
        kept = _kept(browser_records)
        diag["browser_kept"] = len(kept)
        if kept:
            diag["used"] = "browser"
            return kept, diag
        if browser_records:
            diag["errors"].append("browser: all_filtered")
        elif diag.get("browser_error"):
            diag["errors"].append(f"browser: {diag['browser_error']}")
    else:
        diag["browser_error"] = "disabled"

    # 3) 匿名 HTTP（IY_FETCH_ENABLED=0 关闭）
    if os.environ.get("IY_FETCH_ENABLED", "1").strip() == "1":
        http_records = _fetch_importyeti(market, industry, diag=diag) or []
        diag["http"] = len(http_records)
        kept = _kept(http_records)
        diag["http_kept"] = len(kept)
        if kept:
            diag["used"] = "http"
            return kept, diag
        if http_records:
            diag["errors"].append("http: all_filtered")
        elif diag.get("http_error"):
            diag["errors"].append(f"http: {diag['http_error']}")
    else:
        diag["http_error"] = "disabled"

    if not diag["errors"]:
        diag["errors"].append("all_sources_empty")
    return [], diag
