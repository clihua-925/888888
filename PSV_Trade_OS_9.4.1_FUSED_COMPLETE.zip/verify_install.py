"""Static and runtime deployment verifier for PSV Trade OS 9.4.1."""

from __future__ import annotations

import argparse
import socket
import ast
import json
import os
from pathlib import Path

# Keep verifier/test execution from creating Python bytecode caches inside the deployable tree.
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import re
import sqlite3
import subprocess
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.request
from typing import Any
import zipfile
import importlib.metadata

ROOT = Path(__file__).resolve().parent
VERSION = "9.4.1"
REQUIRED_FILES = (
    "VERSION.txt",
    "requirements.txt",
    "run_webui.py",
    "start.bat",
    "start_chrome_debug.bat",
    "core/config/settings.py",
    "core/memory/db.py",
    "core/model/reasoning.py",
    "core/orchestration/state.py",
    "core/orchestration/contracts.py",
    "core/orchestration/registry.py",
    "core/orchestration/recovery.py",
    "core/orchestration/engine.py",
    "core/orchestration/mission.py",
    "core/orchestration/scheduler.py",
    "business/workflows/trade_collection/spec.py",
    "business/workflows/trade_collection/nodes.py",
    "core/webui/app.py",
    "core/webui/static/mission.html",
)
FORBIDDEN_SUFFIXES = {".pyc", ".tmp", ".bak", ".swp"}
ENVIRONMENT_DIRS = {".venv", "venv"}


def project_files():
    """Yield project files while excluding the local virtual environment."""
    for path in ROOT.rglob("*"):
        if any(part in ENVIRONMENT_DIRS for part in path.relative_to(ROOT).parts):
            continue
        yield path


def project_dirs():
    """Yield project paths while excluding the local virtual environment."""
    for path in ROOT.rglob("*"):
        if any(part in ENVIRONMENT_DIRS for part in path.relative_to(ROOT).parts):
            continue
        yield path
LEGACY_API = ("/api/" + "search", "/api/" + "products", "/api/" + "trade", "/api/" + "customs")
LEGACY_SEMANTICS = ("trade_" + "first_collection", "第" + "一采集链")
REQUIRED_NODES = (
    "PRODUCT_DEFINITION", "TRADE_STRATEGY", "CUSTOMS_NODE_COLLECTION",
    "TRADE_EDGE_BUILD", "EVIDENCE_VERIFY", "ENTITY_RESOLUTION",
    "GRAPH_EXPANSION", "RESOURCE_CLASSIFICATION", "DATABASE_COMMIT",
)
STATUS_NAMES = (
    "STATUS_PENDING", "STATUS_RUNNING", "STATUS_COMPLETED", "STATUS_FAILED",
    "STATUS_PAUSED", "STATUS_TIMEOUT",
)

def forbidden_word(name: str) -> str:
    """Construct a forbidden scanner token without embedding the token literally."""
    pieces = {
        "a": ("pa", "ss"),
        "b": ("TO", "DO"),
        "c": ("FIX", "ME"),
        "d": ("Not", "Implemented", "Error"),
    }
    return "".join(pieces[name])


def read_text(path: Path) -> str:
    """Read a UTF-8 text file."""
    return path.read_text(encoding="utf-8-sig")


def fail(message: str) -> None:
    """Raise a verifier failure."""
    raise RuntimeError(message)


def check_structure() -> None:
    """Validate required deployment files and forbidden transient artifacts."""
    missing = [item for item in REQUIRED_FILES if not (ROOT / item).is_file()]
    if missing:
        fail("Missing required files: " + ", ".join(missing))
    for path in project_dirs():
        if path.name == "__pycache__" or path.suffix.lower() in FORBIDDEN_SUFFIXES:
            fail(f"Forbidden transient artifact: {path.relative_to(ROOT)}")


def check_source_rules() -> None:
    """Scan project source for forbidden implementation markers and empty functions."""
    token_values = tuple(forbidden_word(name) for name in ("a", "b", "c", "d"))
    for path in project_files():
        if not path.is_file() or path.suffix.lower() not in {".py", ".html", ".bat"}:
            continue
        if path.parent.name == "static" and "core/webui" in path.relative_to(ROOT).as_posix():
            # Owner-approved restored legacy UI assets are data, not authored source.
            continue
        text = read_text(path)
        if path.suffix.lower() == ".py":
            tree = ast.parse(text, filename=str(path))
            # "pass" 只禁止裸占位语句；字符串/标识符中的 pass 子串（如 passed）合法
            if any(isinstance(node, ast.Pass) for node in ast.walk(tree)):
                fail(f"Forbidden source marker 'pass': {path.relative_to(ROOT)}")
            for token in token_values:
                if token != "pass" and token in text:
                    fail(f"Forbidden source marker {token!r}: {path.relative_to(ROOT)}")
        else:
            for token in token_values:
                if token in text:
                    fail(f"Forbidden source marker {token!r}: {path.relative_to(ROOT)}")
        if path.suffix.lower() == ".py":
            tree = ast.parse(text, filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    body = [item for item in node.body if not (isinstance(item, ast.Expr) and isinstance(getattr(item, "value", None), ast.Constant) and isinstance(item.value.value, str))]
                    if not body:
                        fail(f"Empty function: {path.relative_to(ROOT)}:{node.name}")


def check_versions_and_architecture() -> None:
    """Validate frozen version and architecture invariants."""
    version_path = ROOT / "VERSION.txt"
    if read_text(version_path).strip() != VERSION:
        fail(f"VERSION.txt is {read_text(version_path).strip()!r}, expected {VERSION!r}")

    release_rules = ROOT / "release_rules.py"
    release_rules_text = read_text(release_rules)
    if not re.search(r"(?m)^__version__\s*=\s*[\"']9\.4\.1[\"']\s*$", release_rules_text):
        fail("release_rules.py is missing the required __version__ marker")
    spec = read_text(ROOT / "business/workflows/trade_collection/spec.py")
    if re.search(r"\b(ORDER|EDGES|RECOVERY)\s*=", spec):
        fail("WorkflowSpec contains forbidden orchestration declarations")
    registry = read_text(ROOT / "core/orchestration/registry.py")
    if re.search(r"from\s+business\.workflows\.trade_collection|import\s+business\.workflows\.trade_collection", registry):
        fail("Registry contains hardcoded trade workflow imports")
    recovery = read_text(ROOT / "core/orchestration/recovery.py")
    if any(node_id in recovery for node_id in REQUIRED_NODES):
        fail("RecoveryManager contains business node IDs")
    state = read_text(ROOT / "core/orchestration/state.py")
    if sum(state.count(name) for name in STATUS_NAMES) < len(STATUS_NAMES):
        fail("Status constants are incomplete")
    if not re.search(r"from \.state import .*STATUS_PENDING", read_text(ROOT / "core/orchestration/mission.py")):
        fail("MissionDirector does not import status constants from the state module")
    webui = read_text(ROOT / "core/webui/app.py")
    if "business.workflows" in webui:
        fail("WebUI imports business workflow modules directly")
    if any(route in webui for route in LEGACY_API):
        fail("Legacy API route detected")
    all_text = "\n".join(read_text(p) for p in project_files() if p.is_file() and p.suffix.lower() in {".py", ".bat", ".txt", ".md"})
    for semantic in LEGACY_SEMANTICS:
        if semantic in all_text:
            fail(f"Legacy business semantic detected: {semantic}")
    requirements = read_text(ROOT / "requirements.txt")
    if not re.search(r"(?im)^openai>=1\.50,<2\.0\s*$", requirements):
        fail("requirements.txt does not pin the required OpenAI 1.x range")


def check_nodes_and_contracts() -> None:
    """Validate nine business nodes and complete contracts."""
    nodes_text = read_text(ROOT / "business/workflows/trade_collection/nodes.py")
    for node_id in REQUIRED_NODES:
        if not re.search(rf"^def\s+{node_id}\(state:\s*TaskState\)\s*->\s*TaskState:\s*$", nodes_text, re.MULTILINE):
            fail(f"Missing node or signature: {node_id}")
    spec = read_text(ROOT / "business/workflows/trade_collection/spec.py")
    for node_id in REQUIRED_NODES:
        if f'"{node_id}"' not in spec:
            fail(f"Node absent from WorkflowSpec: {node_id}")
    tree = ast.parse(spec, filename=str(ROOT / "business/workflows/trade_collection/spec.py"))
    contract_calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "ContractDefinition"]
    if len(contract_calls) != 9:
        fail(f"Expected nine ContractDefinition entries, found {len(contract_calls)}")
    for call in contract_calls:
        if len(call.args) < 6:
            fail("ContractDefinition entry is incomplete")


def check_dependencies() -> None:
    """Import every top-level requirement and report a hard failure on missing dependencies."""
    packages = {
        "langgraph": "langgraph",
        "langgraph-checkpoint": "langgraph-checkpoint",
        "langgraph-checkpoint-sqlite": "langgraph-checkpoint-sqlite",
        "langchain-core": "langchain-core",
        "openai": "openai",
        "python-dotenv": "python-dotenv",
    }
    missing = []
    for package, dist_name in packages.items():
        try:
            installed_version = importlib.metadata.version(dist_name)
            print(f"DEPENDENCY_OK {dist_name}=={installed_version}")
            if dist_name == "langgraph" and installed_version != "1.2.11":
                fail(f"langgraph version is {installed_version!r}, expected '1.2.11'")
        except Exception as exc:
            missing.append(f"{package}: {type(exc).__name__}: {exc}")
    if missing:
        fail("Dependency import failure:\n" + "\n".join(missing))


def http_json(url: str, method: str = "GET", payload: dict[str, Any] | None = None) -> tuple[int, dict[str, Any]]:
    """Call a JSON HTTP endpoint."""
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(body)
        except json.JSONDecodeError:
            parsed = {"error": body}
        return exc.code, parsed


def wait_for_task(base_url: str, task_id: str, timeout_seconds: int = 1800) -> dict[str, Any]:
    """Poll a task until a terminal status is reached."""
    from core.orchestration.state import (
        STATUS_COMPLETED, STATUS_FAILED, STATUS_PAUSED, STATUS_TIMEOUT,
    )

    deadline = time.monotonic() + timeout_seconds
    terminal = {STATUS_COMPLETED, STATUS_FAILED, STATUS_TIMEOUT, STATUS_PAUSED}
    while time.monotonic() < deadline:
        try:
            status, payload = http_json(f"{base_url}/api/orchestration/tasks/{task_id}")
        except Exception as exc:
            fail(f"Runtime service became unreachable while waiting for task completion: {exc}")
        if status != 200:
            fail(f"Task endpoint returned HTTP {status}: {payload}")
        if payload.get("status") in terminal:
            return payload
        time.sleep(0.5)
    fail("Runtime task did not reach a terminal state within the verifier timeout")


def _require_runtime_llm_configuration() -> tuple[str, str]:
    """Require the real OpenAI-compatible DeepSeek endpoint before runtime execution."""
    try:
        from dotenv import load_dotenv
    except ImportError as exc:
        fail(f"python-dotenv is required for runtime environment loading: {exc}")
    load_dotenv(ROOT / ".env", override=False)
    base_url = os.getenv("LLM_BASE_URL", "").strip()
    api_key = os.getenv("LLM_API_KEY", "").strip()
    model = os.getenv("LLM_MODEL", "deepseek-r1-distill-llama-70b").strip()
    if not base_url:
        fail("Runtime Gate requires LLM_BASE_URL to be configured; mock LLM is forbidden")
    if not api_key:
        fail("Runtime Gate requires LLM_API_KEY to be configured; empty credentials are forbidden")
    if model != "deepseek-r1-distill-llama-70b":
        fail(f"Runtime Gate requires deepseek-r1-distill-llama-70b, got {model!r}")
    return base_url, api_key


def _free_local_port() -> int:
    """Reserve an ephemeral localhost port long enough to choose it safely."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


def _stop_runtime_process(process: subprocess.Popen[str]) -> None:
    """Stop the verifier process tree so Windows releases SQLite handles."""
    if process.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            process.kill()
    else:
        process.terminate()
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def _remove_temp_tree(path: Path) -> None:
    """Remove a verifier temp tree with bounded Windows file-lock retries."""
    last_error: Exception | None = None
    for attempt in range(12):
        try:
            shutil.rmtree(path)
            return
        except OSError as exc:
            last_error = exc
            if attempt == 11:
                raise
            time.sleep(0.25 * (attempt + 1))
    if last_error is not None:
        raise last_error


def check_runtime() -> None:
    """Run the real API-to-orchestration-to-DeepSeek-to-SQLite deployment chain."""
    check_dependencies()
    llm_base_url, llm_api_key = _require_runtime_llm_configuration()
    temp_dir = Path(tempfile.mkdtemp(prefix="psv_verify_"))
    try:
        temp = temp_dir
        database_path = temp / "psv.db"
        checkpoint_path = temp / "checkpoints.db"
        env = os.environ.copy()
        env.update({
            "DATABASE_PATH": str(database_path),
            "CHECKPOINT_PATH": str(checkpoint_path),
            "LLM_BASE_URL": llm_base_url,
            "LLM_API_KEY": llm_api_key,
            "LLM_MODEL": "deepseek-r1-distill-llama-70b",
            "WEB_HOST": "127.0.0.1",
            "WEB_PORT": str(_free_local_port()),
            "MAX_TASK_SECONDS": "1800",
            "MAX_STEPS": "40",
            "MAX_RETRIES": "2",
            "NO_PROGRESS_LIMIT": "3",
        })
        runtime_log = open(temp_dir / "webui_runtime.log", "w", encoding="utf-8", errors="replace")
        process = subprocess.Popen(
            [sys.executable, str(ROOT / "run_webui.py")],
            cwd=ROOT,
            env=env,
            stdout=runtime_log,
            stderr=subprocess.STDOUT,
            text=True,
        )
        try:
            base_url = f"http://127.0.0.1:{env['WEB_PORT']}"
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                try:
                    status, payload = http_json(f"{base_url}/api/health")
                    if status == 200 and payload.get("ok") is True:
                        break
                except Exception:
                    time.sleep(0.5)
            else:
                fail("WebUI did not become healthy within 30 seconds")
            status, payload = http_json(f"{base_url}/api/orchestration/workflows")
            if status != 200 or not any(item.get("workflow_id") == "trade_collection" for item in payload.get("workflows", [])):
                fail(f"Workflow API validation failed: HTTP {status}: {payload}")
            submission_started = time.monotonic()
            status, submitted = http_json(
                f"{base_url}/api/orchestration/run",
                method="POST",
                payload={"request": "Find solar panel trade partners", "market": "US", "industry": "solar"},
            )
            submission_seconds = time.monotonic() - submission_started
            if status != 202 or not submitted.get("task_id"):
                fail(f"Run API validation failed: HTTP {status}: {submitted}")
            if submission_seconds >= 10:
                fail(
                    "Run API submission is not asynchronous: "
                    f"HTTP 202 took {submission_seconds:.2f}s"
                )
            task_id = str(submitted["task_id"])
            early_status, early_payload = http_json(f"{base_url}/api/orchestration/tasks/{task_id}")
            if early_status != 200:
                fail(f"Task endpoint failed immediately after submission: HTTP {early_status}: {early_payload}")
            if early_payload.get("task_id") != task_id:
                fail("Task endpoint returned a mismatched task_id")
            task = wait_for_task(base_url, task_id)
            from core.orchestration.state import STATUS_COMPLETED
            if task.get("status") != STATUS_COMPLETED:
                fail("Runtime task did not complete: " + json.dumps(task, ensure_ascii=False))
            state = task.get("state", {})
            for key in ("mission", "product_definition", "trade_nodes", "fragments", "evidence_pool", "entities", "relationships", "decisions", "history", "orchestration", "error", "node_reports"):
                if key not in state:
                    fail(f"Shared State key missing at runtime: {key}")
            if len(state.get("trade_nodes", [])) < 3:
                fail("Runtime trade node count is below three")
            if len(state.get("evidence_pool", [])) < 3:
                fail("Runtime evidence count is below three")
            if not state.get("entities"):
                fail("Runtime entity resolution produced no entities")
            if not state.get("relationships"):
                fail("Runtime graph produced no relationships")
            if not state.get("decisions"):
                fail("Runtime DecisionLayer produced no decisions")
            reports = state.get("node_reports", {})
            if reports.get("DATABASE_COMMIT", {}).get("status") != "committed":
                fail("DATABASE_COMMIT report is not committed")
            audit = task.get("audit", [])
            if not audit:
                fail("Audit event stream is empty")
            database_connection = sqlite3.connect(database_path)
            checkpoint_connection = sqlite3.connect(checkpoint_path)
            try:
                for table in ("trade_entities", "trade_edges", "evidence"):
                    count = database_connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                    if count <= 0:
                        fail(f"Database table {table} is empty")
                event_rows = database_connection.execute(
                    "SELECT event_id,event_type FROM task_events WHERE task_id=? ORDER BY event_id ASC",
                    (str(submitted["task_id"]),),
                ).fetchall()
                if not event_rows:
                    fail("No task_events were persisted for the runtime task")
                event_types = {str(row[1]) for row in event_rows}
                required_events = {"AI_DECISION", "CHECKPOINT", "DATABASE_COMMIT"}
                missing_events = sorted(required_events - event_types)
                if missing_events:
                    fail("Required audit events missing: " + ", ".join(missing_events))
                database_commit_rows = database_connection.execute(
                    "SELECT event_id FROM task_events WHERE task_id=? AND event_type='DATABASE_COMMIT' AND event_id>=1",
                    (str(submitted["task_id"]),),
                ).fetchall()
                if not database_commit_rows:
                    fail("DATABASE_COMMIT audit event is missing or has an invalid event_id")
                if "NODE_FAILURE" in event_types:
                    for conditional_event in ("RETRY", "RECOVERY"):
                        if conditional_event not in event_types:
                            fail(f"{conditional_event} event is required because NODE_FAILURE occurred")
                checkpoint_tables = {
                    str(row[0])
                    for row in checkpoint_connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    ).fetchall()
                }
                if "checkpoints" not in checkpoint_tables:
                    fail(
                        "Checkpoint database is missing the LangGraph 'checkpoints' table; "
                        + f"found: {sorted(checkpoint_tables)}"
                    )
                write_tables = checkpoint_tables.intersection({"writes", "checkpoint_writes"})
                if not write_tables:
                    fail(
                        "Checkpoint database is missing the LangGraph writes table; "
                        + f"found: {sorted(checkpoint_tables)}"
                    )
                checkpoint_count = checkpoint_connection.execute("SELECT COUNT(*) FROM checkpoints").fetchone()[0]
                if checkpoint_count <= 0:
                    fail("Checkpoint database contains no checkpoint rows")
            finally:
                database_connection.close()
                checkpoint_connection.close()
            if not checkpoint_path.exists() or checkpoint_path.stat().st_size == 0:
                fail("Checkpoint database file was not created")
            print("RUNTIME_DB_CHECK=PASS")
            print(f"RUNTIME_DB_PATH={database_path}")
            print(f"RUNTIME_CHECKPOINT_PATH={checkpoint_path}")
            print("RUNTIME_OK")
        finally:
            _stop_runtime_process(process)
            runtime_log.close()
    finally:
        _remove_temp_tree(temp_dir)


def parse_args() -> argparse.Namespace:
    """Parse verifier command-line options."""
    parser = argparse.ArgumentParser(description="Verify PSV Trade OS 9.4.1 installation")
    parser.add_argument("--runtime", action="store_true", help="run real API and persistence integration checks")
    return parser.parse_args()


def main() -> int:
    """Run static checks and, optionally, runtime checks."""
    try:
        # Remove only Python-generated cache directories left by a previous local verification run.
        # The deployment ZIP is still checked and packaged without transient artifacts.
        for cache_dir in ROOT.rglob("__pycache__"):
            if cache_dir.is_dir() and not any(part in ENVIRONMENT_DIRS for part in cache_dir.relative_to(ROOT).parts):
                shutil.rmtree(cache_dir, ignore_errors=True)
        check_structure()
        check_source_rules()
        check_versions_and_architecture()
        check_nodes_and_contracts()
        check_dependencies()
        if parse_args().runtime:
            check_runtime()
        print("VERIFY_OK")
        return 0
    except Exception as exc:
        print(f"VERIFY_ERROR: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
