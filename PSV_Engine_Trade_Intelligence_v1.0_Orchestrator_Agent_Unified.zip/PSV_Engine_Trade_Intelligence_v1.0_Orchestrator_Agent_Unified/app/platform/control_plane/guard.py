"""Control-plane loop/retry budget. Nodes cannot extend these budgets."""
from __future__ import annotations

def check_step_budget(steps, max_steps):
    return int(steps) < int(max_steps)

def check_reentry(count, max_reentries):
    return int(count) <= int(max_reentries)
