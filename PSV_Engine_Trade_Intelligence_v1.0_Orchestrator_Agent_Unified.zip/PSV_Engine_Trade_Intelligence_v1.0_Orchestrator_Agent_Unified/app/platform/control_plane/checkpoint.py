"""Small persistent checkpoint adapter; independent of business nodes."""
from __future__ import annotations
import json, os, tempfile, time
from pathlib import Path

def checkpoint_dir(root=None):
    # One installation = one data root. Never depend on the caller's CWD.
    base = Path(root) if root else (Path(__file__).resolve().parents[2] / "data")
    p = base / "checkpoints"
    p.mkdir(parents=True, exist_ok=True)
    return p

def save(run_id, state, root=None):
    p=checkpoint_dir(root)/(str(run_id).replace('/','_')+".json")
    # Runtime callbacks/private handles are not restorable state and must never be
    # stringified into a checkpoint. The checkpoint is a control-plane artifact.
    clean = {k: v for k, v in (state or {}).items() if not str(k).startswith("_") and not callable(v)}
    payload={"run_id":run_id,"saved_at":time.time(),"state":clean}
    fd,tmp=tempfile.mkstemp(prefix=p.stem+".",suffix=".tmp",dir=str(p.parent)); os.close(fd)
    try:
        Path(tmp).write_text(json.dumps(payload,ensure_ascii=False,default=str),encoding="utf-8")
        os.replace(tmp,p)
    finally:
        try: os.unlink(tmp)
        except OSError: pass
    return str(p)

def load(run_id, root=None):
    p=checkpoint_dir(root)/(str(run_id).replace('/','_')+".json")
    try: return json.loads(p.read_text(encoding="utf-8")).get("state")
    except (OSError, json.JSONDecodeError, AttributeError): return None
