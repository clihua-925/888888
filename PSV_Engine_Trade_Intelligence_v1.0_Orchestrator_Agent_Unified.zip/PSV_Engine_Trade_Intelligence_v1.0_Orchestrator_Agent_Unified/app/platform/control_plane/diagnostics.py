"""Collection chain failure diagnostics."""
from datetime import datetime

def diagnose(task):
    reason=str((task or {}).get("failure_reason") or "")
    hints=[]
    if "goal" in reason.lower(): hints.append("task contract missing goal; verify collection request")
    if "contract" in reason.lower(): hints.append("check node handoff contract compatibility")
    if "database" in reason.lower(): hints.append("check sqlite availability")
    return {"time":datetime.utcnow().isoformat(),"reason":reason,"hints":hints,"severity":"error" if reason else "info"}
