"""Execution trace adapter inspired by the reference agent; append-only JSONL."""
from __future__ import annotations
import json, time, threading
from pathlib import Path
_LOCK=threading.Lock()

def append(run_id, event, root=None):
    d=Path(root or "data")/"traces"; d.mkdir(parents=True,exist_ok=True)
    p=d/(str(run_id).replace('/','_')+".jsonl")
    row={"ts":time.time(),"run_id":run_id,**dict(event)}
    with _LOCK:
        with p.open("a",encoding="utf-8") as f: f.write(json.dumps(row,ensure_ascii=False,default=str)+"\n")
    return row
