"""Failure and retry contracts for the standard orchestration control plane."""
from __future__ import annotations
import time
DEFAULT_MAX_RETRY = 3

def build_failure_state(node, error, retry_count=0, history=None):
    return {"error_type": type(error).__name__ if isinstance(error, BaseException) else "RuntimeError", "error_message": str(error)[:1000], "failed_node": node, "retry_count": int(retry_count), "history": list(history or [])}

def build_retry_context(target_node, strategy="retry", max_retry=DEFAULT_MAX_RETRY, current_attempt=1, **extra):
    return {"target_node": target_node, "strategy": strategy, "max_retry": int(max_retry), "current_attempt": int(current_attempt), "ts": time.time(), **extra}
