"""Standard task-entry contract adapted from the reference maintenance agent.
PSV workflows consume the same control-plane contract without changing the 9 business nodes.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any
import time
import re

class ContractValidationError(ValueError): pass

@dataclass
class TaskContract:
    task_id: str
    workflow: str
    goal: str
    market: str = "USA"
    industry: str = ""
    quantity: int = 20
    constraints: list[str] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    timeout_policy: dict[str, Any] = field(default_factory=lambda: {"max_seconds": 3600, "on_timeout": "checkpoint_and_pause"})
    model_policy: dict[str, Any] = field(default_factory=lambda: {"provider": "local", "serial": True})

    def validate(self):
        if not self.task_id.strip(): raise ContractValidationError("task_id required")
        if not isinstance(self.workflow, str) or not self.workflow.strip(): raise ContractValidationError("workflow required")
        if not re.fullmatch(r"[A-Za-z0-9_-]+", self.workflow): raise ContractValidationError("workflow must be alphanumeric/_/-")
        if not self.goal.strip(): raise ContractValidationError("goal required")
        if self.quantity < 1: raise ContractValidationError("quantity must be >= 1")
        if not isinstance(self.constraints, list) or not all(isinstance(x, str) for x in self.constraints): raise ContractValidationError("constraints must be list[str]")
        if not isinstance(self.acceptance_criteria, list) or not all(isinstance(x, str) for x in self.acceptance_criteria): raise ContractValidationError("acceptance_criteria must be list[str]")
        if not isinstance(self.timeout_policy, dict) or not isinstance(self.model_policy, dict): raise ContractValidationError("policies must be mappings")
        return self

    def finalize(self):
        self.validate(); return self

    def to_dict(self): return asdict(self)

def build_collection_contract(goal, *, task_id=None, market="USA", industry="", quantity=20, constraints=None, acceptance_criteria=None):
    return TaskContract(task_id=task_id or f"col-{time.time_ns()}", workflow="collection", goal=(str(goal or "").strip() or f"{industry or 'default'} market collection research"), market=market or "USA", industry=industry or "", quantity=int(quantity or 20), constraints=list(constraints or []), acceptance_criteria=list(acceptance_criteria or [])).finalize()
