"""PSV v46.2 database migration manager baseline."""

def current_schema_version():
    return "46.2"
