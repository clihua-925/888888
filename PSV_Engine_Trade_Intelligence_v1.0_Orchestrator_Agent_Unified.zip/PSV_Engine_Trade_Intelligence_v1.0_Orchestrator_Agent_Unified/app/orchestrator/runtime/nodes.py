# -*- coding: utf-8 -*-
"""当前业务节点层（专业执行层）：九节点薄包装 + 执行器。

关键词 → 海关贸易数据节点 → 确定 importer/supplier/shipper 节点 → 保存贸易证据
→ 从节点展开关联企业 → 贸易关系图谱。
第一阶段只建完整贸易节点图（简单净化，不评分）；第二阶段才做客户价值判断。

最终架构收敛（current）：
- 节点只有执行权：不返回 abort/next_node/编排状态（编排层统一剥离，见 graph.ORCHESTRATOR_KEYS）。
- 边的生命周期唯一通道：TRADE_EDGE_BUILD 建边(内存) → EVIDENCE_VERIFY 分级(内存+存量对账)
  → DATABASE_COMMIT 唯一正式写库。执行器不再直接写 relationships。
- 证据分级唯一实现：core.trade_graph.trade_node.evidence_level（本文件 _evidence_level 为别名）。
- 复核键 = canonical node_id（与 graph.ORDER 同名），复核键统一使用正式节点名。
"""
import json, os, re, sqlite3, time, hashlib
import requests
from pathlib import Path

# DATABASE_COMMIT 防御：最终节点显式绑定 JSON 序列化器，避免运行环境/后续重构导致 json 名称丢失。
_JSON_DUMPS = json.dumps
from core.config import settings
from core.config.industry import load_industry
from core.model.reasoning import ReasoningEngine
from core.runtime import experts
from core.tools.data_sources.manager import DataSourceManager, Evolution, gate_check, norm, noise, identity_valid, hard_evidence
from core.tools import suppliers as sup
from core.tools import expand as expand_tool
from core.tools import trade_filter
from core.trade_graph import customs_node_pipeline as cnp
from core.trade_graph.trade_node import (evidence_level, TRUSTED_SOURCES, EVIDENCE_DEMOTE,
                                         LOGISTICS_RE, EVIDENCE_LEVELS, is_non_company_name)

# 证据四级唯一判定函数的本层别名（canonical 实现在 trade_node.py，禁止第二套分级逻辑）
_evidence_level = evidence_level

# 当前：第一链查询词必须携带的贸易证据信号（定位贸易节点，而不是找联系方式）
TRADE_EVIDENCE_SIGNALS = ('importer of record', 'customs data', 'bill of lading',
                          'import records', 'hs code', 'shipment', 'shipper',
                          'consignee', 'importer', 'supplier')

BAD = re.compile(r'on behalf of|freight|forwarder|logistics|express|cargo|shipping|customs broker|packaging|consulting|翻译|词典|物流|货代', re.I)
_engine = None

def _eng():
    global _engine
    if _engine is None:
        _engine = ReasoningEngine()
    return _engine

def _report(state, node, rep):
    nr = dict(state.get('node_reports') or {})
    nr[node] = rep
    return nr

def _ev(c):
    e = c.get('evidence') or {}
    bits = []
    if e.get('shipments'):
        bits.append(f"shipments={e['shipments']}")
    if e.get('score'):
        bits.append(f"score={e['score']}")
    if e.get('last_seen'):
        bits.append(f"last_seen={e['last_seen']}")
    return (' [' + ', '.join(str(b) for b in bits) + ']') if bits else ''

def _brief(cs, n=12):
    return '\n'.join('- ' + c.get('name','') + ' | ' + str(c.get('country','')) + ' | ' + str(c.get('source','')) + _ev(c) for c in (cs or [])[:n])

# ---------- 1. ICP 客户画像师 ----------
def n_icp(state):
    ind = state['industry']
    icp = None
    industry_cfg = load_industry(ind)
    # 优先使用配置中的 ICP，避免不必要的 LLM 调用
    if settings.EXPERT_MODE and _eng().available:
        icp = _eng().review(
            f'市场:{state["market"]} 行业:{ind}\n生成客户画像契约JSON：'
            '{"must":["必收信号3-5条"],"reject":["拒收信号3-5条"],"keywords":["英文关键词5-8个"],"hs":["相关HS编码"]}',
            system='你是资深外贸客户画像师，只输出JSON')
    if not icp or not icp.get('must'):
        icp = {'must': industry_cfg.get('icp_must', ['USA company', 'import or trade evidence']),
               'reject': industry_cfg.get('icp_reject', ['dictionary', 'marketplace retail page', 'freight forwarder']),
               'keywords': industry_cfg.get('keywords', [ind]),
               'hs': industry_cfg.get('hs_codes', [])}
    rep = experts.review('PRODUCT_DEFINITION', 'ICP契约：\n' + json.dumps(icp, ensure_ascii=False),
                         [('含必收信号', bool(icp.get('must')), 'must 非空' if icp.get('must') else 'must 缺失'),
                          ('含拒收信号', bool(icp.get('reject')), 'reject 非空' if icp.get('reject') else 'reject 缺失'),
                          ('关键词与行业相关', bool(icp.get('keywords')), ','.join((icp.get('keywords') or [])[:5]))],
                         critical={'含必收信号','含拒收信号'})
    return {'icp': icp, 'node_reports': _report(state, 'PRODUCT_DEFINITION', rep), '_note': 'ICP契约已锁定'}

# ---------- 2. STRATEGY 贸易节点定位策略师：第一次搜索的目标是定位贸易节点 ----------
def n_strategy(state):
    industry_cfg = load_industry(state.get('industry'))
    plan = Evolution().plan(state['market'], state['industry'])
    # current Product Intelligence Layer：产品不是单一关键词，而是
    # 主名称+同义词+商业采购名+材料词+应用词+HS候选集+排除词 的情报档案。
    # LLM 可用时扩展档案，不可用时确定性兜底（行业配置+内置采购修饰词），不断链。
    from core.trade_graph import product_intelligence as pi
    # 当前：PRODUCT_DEFINITION 已产出档案则直接复用，避免重复 LLM 调用与定义漂移
    profile=state.get('product_profile') or pi.build_product_profile(state['industry'],state.get('icp'))
    pi_plan=pi.build_query_plan(profile)
    hs_validation=state.get('product_domain',{}).get('hs_validation') or pi.validate_hs(profile['hs_candidates'])  # 只标注不过滤
    # Node 2 只把“检索意图”加到 Node 1 的语义计划上，不改变产品定义。
    # 用户可通过 query_override 提供本轮额外入口；它们被标成 override，不会伪装成同义词。
    override=[str(v).strip() for v in (state.get('query_override') or []) if str(v).strip()]
    queries=[]
    seen=set()
    for q in pi_plan:
        k=str(q.get('query') or '').strip().lower()
        if k and k not in seen: seen.add(k); queries.append(dict(q))
    for q in override:
        k=q.lower()
        if k not in seen:
            seen.add(k); queries.append({'query':q,'query_type':'override','expected_role':'both','expected_product_relation':'unknown','priority':66,'stage':2,'rationale':'user/runtime supplied retrieval hint','anchor_required':False,'result_count':None,'usable_trade_nodes':None,'usable_trade_edges':None,'precision_estimate':None,'recall_contribution':None})
    # 若配置没有显式角色词，Node 2 仍为每个核心/可信同义词生成买家/供应商定位词；
    # 这些是“搜索策略”，不是产品同义词。
    base_words=[]
    for _b in [profile.get('core_name')] + list(profile.get('synonyms') or []):
        _b=str(_b or '').strip()
        if _b and _b.lower() not in {x.lower() for x in base_words}: base_words.append(_b)
    base_words=base_words[:4]
    role_mods=(('importer','buyer','distributor'),('manufacturer','factory','exporter','supplier'))
    role_specs=(('buyer_role','buyer',role_mods[0]),('supplier_role','supplier',role_mods[1]))
    for qtype,role,mods in role_specs:
        for b in base_words:
            for mod in mods:
                q=f'{b} {mod}'; k=q.lower()
                if k not in seen:
                    seen.add(k); queries.append({'query':q,'query_type':qtype,'expected_role':role,'expected_product_relation':'exact','priority':74,'stage':2,'rationale':'role localization derived from target product','anchor_required':True,'result_count':None,'usable_trade_nodes':None,'usable_trade_edges':None,'precision_estimate':None,'recall_contribution':None})
    queries=sorted(queries,key=lambda x:(int(x.get('stage',4)), -int(x.get('priority',0))))
    hs_codes=profile['hs_candidates'] or cnp.resolve_hs_codes(state.get('industry'), state.get('icp'))
    rationale=('第一采集链以海关贸易数据节点为中心：关键词→HS编码→海关/提单数据源→'
               '确定 importer/supplier/shipper 节点并保存贸易证据；不使用通用搜索引擎结果；'
               '每次运行做增量 delta + 历史轮换；已有客户只合并新证据，新客户才进入开发池；'
               '展会/普通网络仅后置补充验证（第二阶段）')
    strategy={'queries':queries,'source_queries':{x:[q.get('query') for q in queries] for x in ('customs','importyeti','importyeti_web')},
              'sources':['hs_finder','customs_bulk','customs_raw','importyeti','importyeti_web','customs_web'],
              'secondary_sources':['public_crawler','exhibition','web_verify'],'hs_codes':hs_codes,
              'product_profile':profile,'exclusions':profile.get('exclusions') or [],'hs_validation':hs_validation,
              'objective':'locate_trade_nodes','first_chain':'customs_node_centric',
              'rationale':rationale,'evolution':plan,'incremental':True,'fanout_hard_sources':True}
    rep=experts.review('TRADE_STRATEGY','查询参数：'+json.dumps(queries,ensure_ascii=False)+'\nHS：'+','.join(hs_codes or [])+'\n策略：'+rationale,
                       [('至少2个产品/行业查询变体',len(queries)>=2,f'{len(queries)}个'),
                        ('主证据源为海关贸易源',True,'hs_finder + customs fan-out'),
                        ('查询词含贸易证据信号',any(any(sig in str(q.get('query') if isinstance(q,dict) else q).lower() for sig in TRADE_EVIDENCE_SIGNALS) for q in queries),'已包含'),
                        ('增量运行已启用',True,'delta + rotating window')],critical={'主证据源为海关贸易源','查询词含贸易证据信号','增量运行已启用'})
    return {'strategy':strategy,'node_reports':_report(state,'TRADE_STRATEGY',rep),'_note':f"产品情报：同义词{len(profile['synonyms'])}·商业名{len(profile['commercial_names'])}·排除词{len(profile['exclusions'])}·HS候选{len(hs_codes or [])}(已验证{sum(1 for v in hs_validation.values() if v['validated'])})·查询{len(queries)}个·宽覆盖"}



def _product_boundary_filter(c, boundary, rule_version='collection-filter-v3'):
    """Deterministic collection gate: only explicit exclusions are IRRELEVANT."""
    e=c.get('evidence') or {}
    text=' '.join(str(x or '') for x in [c.get('name'), c.get('website'), e.get('url'), e.get('products'), e.get('description'), e.get('descr')]).lower()
    exclusions=[str(x).strip().lower() for x in (boundary.get('exclude_terms') or boundary.get('exclusions') or []) if str(x).strip()]
    matched=next((x for x in exclusions if x and x in text), '')
    product_terms=[str(x).strip().lower() for x in (boundary.get('product_terms') or []) if str(x).strip()]
    def _hs4(value):
        digits=re.sub(r'\D','',str(value or ''))
        return digits[:4] if len(digits)>=4 else digits
    hs_terms={_hs4(x) for x in (boundary.get('hs_candidates') or []) if _hs4(x)}
    raw_hs=e.get('hs') or ([e.get('hs')] if e.get('hs') else [])
    if isinstance(raw_hs,str): raw_hs=[raw_hs]
    hs={_hs4(x) for x in raw_hs if _hs4(x)}
    relevant=any(x in text for x in product_terms) or bool(hs_terms & hs)
    if matched:
        result='IRRELEVANT'; reason='explicit_exclusion_term'
    elif relevant:
        result='RELEVANT'; reason='product_term_or_hs_match'
    else:
        result='UNCERTAIN'; reason='no_explicit_product_or_exclusion_match'
    c['collection_filter']={'result':result,'reason':reason,'matched_term':matched,'rule_version':rule_version,'boundary_version':boundary.get('version') or 'unknown'}
    return result


def _target_fit_rule_gate(c, state):
    """Deterministic pre-gate for Node 6 Target Fit.

    Rules may close only high-confidence boundaries.  Strong target evidence and
    explicit product-boundary exclusions are decided here; ambiguous entities
    remain for the dedicated DeepSeek 70B judgment.  This keeps quality-first
    semantics while preventing a full-model call for every trade entity.
    """
    e=c.get('evidence') or {}
    pd=state.get('product_domain') or {}
    profile=state.get('product_profile') or {}
    text=' '.join(str(x or '') for x in [
        c.get('name'), c.get('industry'), c.get('product_categories'),
        e.get('products'), e.get('descr'), e.get('description'), e.get('product_text')
    ]).lower()
    # Strong target signal: target HS or sufficiently specific product terms.
    def hs4(v):
        digits=re.sub(r'\D','',str(v or ''))
        return digits[:4] if len(digits)>=4 else ''
    target_hs={hs4(x) for x in (pd.get('hs_candidates') or profile.get('hs_candidates') or []) if hs4(x)}
    raw_hs=e.get('hs') or c.get('hs') or []
    if isinstance(raw_hs,str): raw_hs=[raw_hs]
    observed_hs={hs4(x) for x in raw_hs if hs4(x)}
    hs_hit=bool(target_hs & observed_hs)
    terms=[]
    canonical=str(profile.get('canonical') or pd.get('canonical') or '').strip().lower()
    if canonical: terms.append(canonical)
    terms += [str(x).strip().lower() for x in (profile.get('synonyms') or pd.get('product_terms') or []) if str(x).strip()]
    terms += [str(x).strip().lower() for x in (profile.get('precision_terms') or []) if str(x).strip()]
    # Avoid broad material/function words being treated as decisive target proof.
    strong_terms=[x for x in dict.fromkeys(terms) if len(x)>=5 and x not in {'candle','wax','fragrance','candles'}]
    product_hit=any(x in text for x in strong_terms)
    exact_core=bool(canonical and canonical in text)
    # Explicit product-boundary exclusions are a hard non-target boundary only
    # when no strong target evidence exists in the same entity evidence.
    exclusions=[str(x).strip().lower() for x in (pd.get('exclude_terms') or profile.get('exclusions') or []) if str(x).strip()]
    exclusion_hit=next((x for x in exclusions if x and x in text), '')
    # HS alone is NOT sufficient for Target Fit. A chapter such as HS 3406
    # can prove a real candle trade, but cannot prove that the company is a
    # target for a specific product such as BIRTHDAY_CANDLES. HS-only cases
    # therefore remain ambiguous and must enter the dedicated DeepSeek gate.
    if product_hit or exact_core:
        return {'target_fit':'TARGET_RELEVANT','origin':'RULE_EXPLICIT_PRODUCT_SIGNAL',
                'reason':'明确产品术语与当前产品边界一致','matched_hs':sorted(target_hs & observed_hs),
                'matched_terms':[x for x in strong_terms if x in text][:5]}
    if exclusion_hit:
        return {'target_fit':'NON_TARGET','origin':'RULE_EXPLICIT_PRODUCT_BOUNDARY',
                'reason':f'命中产品边界排除词：{exclusion_hit}','matched_term':exclusion_hit}
    return None

def _fragment_group_key(f):
    e=f.get('evidence') or {}
    return '|'.join([norm(e.get('source_batch') or f.get('source') or ''), norm(e.get('reference_number') or e.get('shipment_id') or ''),
                     norm(f.get('country') or ''), norm(e.get('from_name') or e.get('exporter') or ''),
                     norm(e.get('to_name') or e.get('importer') or ''), norm(e.get('query') or f.get('query') or '')])


def _critical_judgment_fingerprint(stage, obj, state=None):
    """Fingerprint only judgment-changing facts; unrelated evidence must not reopen AI."""
    e=obj.get('evidence') or {}
    pd=state.get('product_domain') if state else None
    if stage == 'ENTITY_RESOLUTION':
        data={'entity':obj.get('canonical_name') or obj.get('name'),'country':obj.get('country'),
              'product_boundary_version':(pd or {}).get('version'),'products':e.get('products'),'hs':e.get('hs'),
              'trade_role':obj.get('type') or obj.get('node_role')}
    elif stage == 'TARGET_FIT':
        data={'entity':obj.get('entity_id') or obj.get('name'),'product_boundary_version':(pd or {}).get('version'),
              'product':e.get('products'),'hs':e.get('hs'),'trade_fact_ids':obj.get('trade_fact_ids') or [],
              'business':obj.get('business_description') or e.get('company_description') or e.get('public_page')}
    elif stage == 'RESOURCE_CLASSIFICATION':
        data={'entity':obj.get('entity_id') or obj.get('name'),'product_boundary_version':(pd or {}).get('version'),
              'target_fit':obj.get('target_fit'),'trade_status':obj.get('trade_status'),'role_evidence':obj.get('role_evidence') or {},
              'trade_fact_ids':obj.get('trade_fact_ids') or [],'direction':obj.get('direction')}
    else:
        data={'entity':obj.get('name'),'product':e.get('products'),'hs':e.get('hs'),'trade':obj.get('trade_fact_id') or obj.get('shipment_id'),'direction':obj.get('relation')}
    return hashlib.sha1(json.dumps(data,sort_keys=True,ensure_ascii=False,default=str).encode('utf-8')).hexdigest()[:20]

# ---------- 3. 海关贸易节点采集（海关节点中心；确定性通过，保留简单净化） ----------
def n_collect(state):
    # 当前：第一采集链 = CustomsNodePipeline（关键词→HS→海关源 fan-out→节点识别）。
    pipe=cnp.CustomsNodePipeline()
    qs=(state.get('strategy') or {}).get('queries'); sq=(state.get('strategy') or {}).get('source_queries')
    companies,used,errors,gate,graph,node_stats=pipe.run(
        state['market'],state['industry'],state['quantity'],
        queries=qs,source_queries=sq,icp=state.get('icp'),task_id=state.get('task_id',''),
        query_plan=(state.get('strategy') or {}).get('query_plan') or [])
    mgr=pipe  # last_evolution 兼容（下方读取 mgr.last_evolution）
    # 保存贸易证据：节点级证据事件落盘（图谱关系边由 SUPPLIER_MINING/REVERSE_HARVEST 展开后保存）。
    try: cnp.save_graph(graph,state.get('task_id',''),depth=0)
    except Exception: pass
    state['trade_graph']=graph.to_dict()
    # RAW 保留：这里不因资料缺失淘汰客户。明确非客户才进入 quarantine。
    raw=list(companies); identity=[]; quarantine=[]
    # 地点/国家等关系残片必须在 identity_valid 之前单独保留；否则“非公司”会被误当成“无价值”。
    raw_fragments=[]; raw_business=[]
    for _c in raw:
        _typ=str(_c.get('type') or _c.get('kind') or '').lower()
        _url=str((_c.get('evidence') or {}).get('url') or _c.get('website') or '').lower()
        if _typ in {'fragment','location','country','government','person','logistics'} or '/location/' in _url or '/country/' in _url:
            raw_fragments.append(_c)
        else:
            raw_business.append(_c)
    # 当前第一轮简单净化：删除百科/新闻/词典/翻译/广告目录/明显错误企业；
    # 保留一切带贸易节点信号（importer/exporter/supplier/manufacturer/shipper/
    # consignee/notify party/HS/shipment/BOL/trade evidence）的候选。不评分。
    purified,dropped=trade_filter.purify(raw_business,exclusions=[])
    # 当前：collection filter is boundary-only. Do not use generic business-noise
    # exclusions as a semantic customer gate; keep every uncertain trade candidate.
    quarantine.extend(c for c,_r in dropped if _r and str(_r).lower().startswith('hard_invalid'))
    filter_audit=[]
    boundary=state.get('product_domain') or {}
    for c in purified:
        fr=_product_boundary_filter(c,boundary)
        if fr == 'IRRELEVANT':
            c['collection_filter_audit']=dict(c.get('collection_filter') or {})
            filter_audit.append(c['collection_filter_audit'])
            quarantine.append(c)
            continue
        if not identity_valid(c):
            quarantine.append(c)
        else:
            identity.append(c)
            c.setdefault('collection_filter',{})['result']=fr
    stats={'raw':len(raw),'clean':len(identity),'relevant':sum(1 for c in identity if (c.get('collection_filter') or {}).get('result')=='RELEVANT'),'uncertain':sum(1 for c in identity if (c.get('collection_filter') or {}).get('result')=='UNCERTAIN'),'irrelevant':len(filter_audit),'noise':len(quarantine),'duplicate':0,'identity_only':0,'hard_evidence':sum(1 for c in identity if (c.get('evidence') or {}).get('shipments') or (c.get('evidence') or {}).get('customs') or (c.get('evidence') or {}).get('trade_evidence')),
           'new_candidates':int(gate.get('new_candidates') or 0),'existing_enriched':int(gate.get('existing_enriched') or 0),'source_fanout':True,'incremental':True,
           'trade_nodes':node_stats.get('nodes',0),'node_roles':node_stats.get('by_role',{}),'hs_codes':node_stats.get('hs_codes',[])}
    stats['noise_ratio']=stats['noise']/max(1,stats['raw']);stats['clean_ratio']=stats['clean']/max(1,stats['raw'])
    for c in identity:
        e=c.setdefault('evidence',{}); is_hard=any(e.get(k) for k in ('shipments','customs','trade_evidence','bill_of_lading','supplier_relation'))
        e.setdefault('evidence_level','hard_trade' if is_hard else 'identity_only')
        if not is_hard: stats['identity_only']+=1
    pen=node_stats.get('penetration') or {}
    pen_criteria=[]
    if pen:
        pen_criteria=[
            {'name':'① IY锁定贸易节点','ok':bool(pen.get('locked')),'detail':f"{pen.get('locked',0)} 个入口节点（关键词→ImportYeti搜索）"},
            {'name':'② 递归渗透展开','ok':pen.get('nodes',0)>pen.get('locked',0),'detail':f"+{pen.get('nodes',0)} 节点 · {pen.get('relations',0)} 条贸易关系 · 页访 {pen.get('pages',0)}"},
            {'name':'③ 渗透停止原因','ok':True,'detail':{'frontier_drained':'节点全部展开完毕','page_budget':'页访预算耗尽（关系已保留，下轮继续）','max_nodes':'达到单轮节点上限','circuit_breaker':'连续失败熔断'}.get(pen.get('stopped_by'),pen.get('stopped_by') or '—')}]
    rep={'verdict':'pass' if identity else 'fail','role':'SOURCE_COLLECTOR','criteria':pen_criteria+[{'name':'有身份即保留','ok':bool(identity),'detail':f'{len(identity)}家'},{'name':'明确垃圾隔离','ok':True,'detail':f'{len(quarantine)}家'}], 'notes':f'RAW {len(raw)} · clean候选 {len(identity)} · quarantine {len(quarantine)}'}
    pen=node_stats.get('penetration') or {}
    pen_note=(f" · IY浏览器{'就绪' if pen.get('browser_ready') else '未就绪'}·搜索锁定 {pen.get('search_locked_total',pen.get('locked',0))}入口·扩张种子 {pen.get('search_expansion_seeds',0)}·页访 {pen.get('pages',0)}·网络节点 {pen.get('nodes',0)}/关系 {pen.get('relations',0)}·停止 {pen.get('stopped_by','—')}" if pen.get('enabled') else '')
    graph_note=f" · 买家 {node_stats.get('buyers',0)}/供应商 {node_stats.get('suppliers',0)}/网络深度 {node_stats.get('network_depth',0)}" if node_stats.get('buyers') or node_stats.get('suppliers') else ''
    return {'raw_companies':raw,'raw_fragments':raw_fragments,'companies':identity,'quarantine':quarantine,'filter_audit':filter_audit,'source':'+'.join(used) if used else 'none','source_errors':errors,'collect_gate':gate,'query_telemetry':dict((gate or {}).get('query_telemetry') or {}),'penetration_stats':dict((gate or {}).get('penetration_stats') or {}),'clean_stats':stats,'evolution':mgr.last_evolution,'node_reports':_report(state,'CUSTOMS_NODE_COLLECTION',rep),'_success':bool(identity),'_note':f'增量采集 {len(raw)} · 新候选 {stats["new_candidates"]} · 已有客户补充 {stats["existing_enriched"]} · 隔离 {len(quarantine)}{pen_note}{graph_note}'}

def hard_evidence_local(c):
    e=c.get('evidence') or {};return bool(e.get('shipments') or e.get('customs') or e.get('trade_evidence') or e.get('bill_of_lading') or e.get('supplier_relation'))

def n_seed_buyers(state):
    """Select expansion seeds deterministically from shared Target Fit/evidence.
    Node 7 no longer spends one DeepSeek call per entity just to decide whether to expand.
    """
    cs=list(state.get('companies') or [])
    depth=int(state.get('_expansion_depth') or 1)
    budget=max(1,min(int(state.get('quantity') or settings.SEED_BUYERS_PER_TASK),
                    int(((state.get('strategy') or {}).get('expansion_policy') or {}).get('per_seed_budget') or 15)))
    ranked=[]
    for c in cs:
        if _trade_node_is_fragment(c) or is_non_company_name(c.get('name')): continue
        fit=str(c.get('target_fit') or '').upper()
        grade=str((c.get('evidence') or {}).get('grade') or c.get('evidence_level') or '').upper()
        shipments=int((c.get('evidence') or {}).get('shipments') or 0)
        if fit!='TARGET_RELEVANT': continue
        score=100+(30 if grade=='STRONG' else 15 if grade=='MEDIUM' else 0)+min(shipments,20)
        ranked.append((score,c))
    ranked.sort(key=lambda x:(-x[0], norm(x[1].get('name'))))
    seeds=[c for _,c in ranked[:budget]]
    rep=experts.review('GRAPH_EXPANSION',f'扩张种子 {len(seeds)}/{len(cs)}，深度 {depth}；规则优先，不逐实体调用AI',
                       [('种子来自Target Fit/证据',True,f'{len(seeds)}'),('非目标实体不作为种子',True,'TARGET_FIT=NON_TARGET跳过')],critical={'种子来自Target Fit/证据'})
    state.setdefault('expansion_judgment_stats',[]).append({'depth':depth,'input':len(cs),'ai_judged':0,'reused':0,'rule_reused':len(seeds),'seeds':len(seeds)})
    return {'seed_buyers':seeds,'companies':seeds,
            'expansion_judgments':[{'name':c.get('name'),'expand':'yes','expected_value':'high' if str(c.get('target_fit')).upper()=='TARGET_RELEVANT' else 'medium',
                                    'direction':'both','ai_success':False,'origin':'RULE_TARGET_FIT'} for c in seeds],
            'node_reports':_report(state,'GRAPH_EXPANSION',rep),'_success':bool(seeds),
            '_note':f'扩张种子规则筛选 {len(seeds)} 家：Target Fit/证据优先，AI=0'}


def n_supplier_mining(state):
    """客户→供应商：第一优先级必须来自海关贸易记录；ImportYeti网页仅作为同类海关数据源补充。"""
    # 本地 customs_raw 没有逐票成本，第一轮清洗通过的客户全部进入关系图；
    # SUPPLIER_MINING_BUYERS 只限制需要访问 ImportYeti 网页补缺的外部客户数，避免免费额度被浪费。
    seeds=list(state.get('seed_buyers') or state.get('companies') or [])
    results=[]; supplier_rows=[]; relations=[]; errors=[]
    try:
        from core.tools.customs_graph import buyer_to_suppliers
        supplier_rows, relations = buyer_to_suppliers(seeds, settings.IY_WEB_MAX_SUPPLIERS)
        results.append({'source':'customs_raw','buyers':len(seeds),'suppliers':len(supplier_rows),'relations':len(relations)})
    except Exception as e:
        errors.append('customs_raw:'+str(e)[:160])
    # 如果本地原始海关库没有覆盖某个种子，再使用 ImportYeti 这一同类海关数据网站的免费网页关系。
    covered={x['norm'] for x in supplier_rows}
    missing=[b for b in seeds if not any(norm(r.get('from_name'))==norm(b.get('name')) for r in relations)]
    if missing and settings.IY_WEB_ENABLED:
        missing=missing[:settings.SUPPLIER_MINING_BUYERS]
        try:
            from core.tools import iy_web
            if iy_web.available():
                with iy_web.IYWeb() as w:
                    # 当前渗透方式：买家节点携带第一搜索时拿到的公司主页 URL（evidence.url），
                    # 直接透视该页的 Suppliers 区；缺 URL 时按名搜索解析主页，绝不猜 slug。
                    # current 防资源枯竭：节点注册表 NODE_REVISIT_DAYS 内已访问过的买家页不再重复访问；
                    # 页访预算 IY_PAGE_BUDGET 耗尽即停止开新页（已挖到的关系全部保留）。
                    from core.trade_graph import iy_network as iyn
                    budget=iyn.PageBudget(); fails=0; skipped_fresh=0
                    for buyer in sorted(missing[:int(getattr(settings,'IY_WEB_TOP_BUYERS',settings.SUPPLIER_MINING_BUYERS))],
                                        key=lambda b:-int((b.get('evidence') or {}).get('shipments') or 0)):
                        if fails>=2: break  # 当前熔断：连续2个节点失败即停，保住浏览器配额
                        bn=norm(buyer.get('name'))
                        if iyn.node_fresh(bn,'company'):
                            skipped_fresh+=1; continue  # 该节点近期已渗透，供应商已在池中，不重复烧页访
                        try:
                            url=str((buyer.get('evidence') or {}).get('url') or '') or iyn.node_url(bn,'company')
                            if not iy_web.is_trade_entity_url(url,'company'):
                                if not budget.take('search:'+str(buyer.get('name'))[:40]): break
                                url=w.company_page_for(buyer.get('name','')) or ''
                            if not url:
                                fails+=1; errors.append(f"{buyer.get('name')}: 未解析到 ImportYeti 公司主页"); continue
                            if not budget.take('page:'+url[-60:]): break
                            rows=w.relationships(url,'Suppliers')[:settings.IY_WEB_MAX_SUPPLIERS]
                            if not rows and w.last_error: fails+=1
                            else:
                                fails=0
                                iyn.mark_node(bn,'company',slug=url.rstrip('/').split('/')[-1],url=url,
                                              shipments=int((buyer.get('evidence') or {}).get('shipments') or 0),run_id=state.get('task_id',''))
                            for r in rows:
                                nm=r.get('name') or ''; sn=norm(nm)
                                if not sn: continue
                                e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'products':r.get('products') or '', 'hs':r.get('hs') or [], 'supplier_relation':buyer.get('name'),'location':r.get('location') or '','location_url':r.get('location_url') or '','url':r.get('url') or ''}
                                supplier_rows.append({'norm':sn,'name':nm,'slug':r.get('url','').rstrip('/').split('/')[-1] if r.get('url') else '', 'shipments':r.get('shipments') or 0,'last_seen':time.time(),'harvested':False,'bol_fetched':0,'via':'importyeti_web','evidence':e})
                                relations.append({'from_name':buyer.get('name'),'from_type':'buyer','to_name':nm,'to_type':'supplier','relation':'buyer_to_supplier','evidence':e,'source':'importyeti_web','confidence':.95})
                            results.append({'source':'importyeti_web','buyer':buyer.get('name'),'suppliers':len(rows)})
                        except Exception as e:
                            fails+=1; errors.append(f"{buyer.get('name')}: {str(e)[:100]}")
                    if skipped_fresh or budget.spent_on:
                        results.append({'source':'importyeti_web','summary':budget.note()+f'·注册表命中跳过{skipped_fresh}个已渗透节点'})
        except Exception as e: errors.append('importyeti_web:'+str(e)[:160])
    # 第三层：ImportKey公开海关公司页。仅补没有本地/ImportYeti覆盖的种子；不做普通搜索。
    if missing and settings.IMPORTKEY_ENABLED:
        try:
            from core.tools.data_sources.sources import ImportKeyPublicSource
            ik=ImportKeyPublicSource()
            for buyer in missing[:settings.SUPPLIER_MINING_BUYERS]:
                rows=ik.company_relationships(buyer.get('name',''),'suppliers',settings.IMPORTKEY_MAX_RELATIONS)
                for r in rows:
                    nm=r.get('name') or ''; sn=norm(nm)
                    if not sn: continue
                    e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'supplier_relation':buyer.get('name'),'location':r.get('location') or '','location_url':r.get('location_url') or '','url':r.get('url') or ''}
                    supplier_rows.append({'norm':sn,'name':nm,'slug':'','shipments':r.get('shipments') or 0,'last_seen':time.time(),'harvested':False,'bol_fetched':0,'via':'importkey_public','evidence':e})
                    relations.append({'from_name':buyer.get('name'),'from_type':'buyer','to_name':nm,'to_type':'supplier','relation':'buyer_to_supplier','evidence':e,'source':'importkey_public','confidence':.9})
                if rows: results.append({'source':'importkey_public','buyer':buyer.get('name'),'suppliers':len(rows)})
        except Exception as e: errors.append('importkey_public:'+str(e)[:160])
    # 去重但不丢失“来自多个客户”的关系证据
    merged={}
    for x in supplier_rows:
        n=x.get('norm') or norm(x.get('name'))
        if not n or is_non_company_name(x.get('name')): continue  # 当前伪实体拦截

        if n not in merged: merged[n]=dict(x)
        else:
            merged[n]['shipments']=max(int(merged[n].get('shipments') or 0),int(x.get('shipments') or 0))
            if not merged[n].get('slug') and x.get('slug'): merged[n]['slug']=x['slug']
            merged[n]['via']=merged[n].get('via','')+'+'+x.get('via','')
    # 当前任务隔离：禁止把其他任务/产品域的全局 supplier_pool 注入本次扩张。
    # 本轮供应商只能来自：当前 buyers 的 customs_raw / ImportYeti / ImportKey 关系结果。
    # 当前：全部供应商节点落池（sup.norm 为供应商池统一身份），收割状态可持久化
    try:
        sup.upsert_pool([{'norm':sup.norm(x.get('name')),'name':x.get('name'),
                          'slug':x.get('slug') or sup.slugify(x.get('name')),
                          'shipments':int(x.get('shipments') or 0),
                          'last_seen':x.get('last_seen') or time.time()} for x in merged.values() if x.get('name')])
    except Exception: pass
    # 当前：用 suppliers 表的持久收割状态回填，已渗透节点下一轮不再重复反查
    try:
        conn=sqlite3.connect(settings.DATABASE_PATH,timeout=10)
        done={r[0] for r in conn.execute("SELECT supplier_norm FROM suppliers WHERE harvested_at IS NOT NULL AND harvested_at!=''")}
        conn.close()
        for n,x in merged.items():
            if sup.norm(x.get('name')) in done: x['harvested']=True
    except Exception: pass
    p=sorted(merged.values(),key=lambda x:-int(x.get('shipments') or 0))[:settings.SUPPLIER_MINING_MAX_SUPPLIERS]
    new=[x for x in p if not x.get('harvested')]
    # 当前：供应商节点与 buyer→supplier 边合并进贸易关系图谱（第一阶段建图，不评分）
    try:
        g=cnp.TradeGraph()
        for x in p:
            nd=cnp.TradeNode(x.get('name'),'supplier',x.get('via') or '')
            if x.get('evidence'): nd.add_evidence(x['evidence'])
            g.add_node(nd)
        for e in cnp.relations_to_edges(relations,1): g.add_edge(e)
        trade_graph=cnp.merge_graph_into_state(state,g,depth=1)
    except Exception:
        trade_graph=state.get('trade_graph')
    rep=experts.review('GRAPH_EXPANSION',f'客户→供应商：种子{len(seeds)}，海关关系{len(p)}，未收割{len(new)}，错误{len(errors)}', [('关系链存在',bool(p) or bool(errors),f'{len(p)}家')])
    ok=bool(p) or (not seeds) or (not settings.HARVEST_ENABLED)
    return {'suppliers':p,'supplier_new':new,'trade_graph':trade_graph,'supplier_mining':{'buyers':results,'errors':errors,'relation_source_policy':'customs_trade_only'},'node_reports':_report(state,'GRAPH_EXPANSION',rep),'_success':ok,'_note':f'客户→供应商 {len(p)} 家·新工厂 {len(new)} 家·海关关系优先'}


def n_reverse_harvest(state):
    """供应商→客户：优先从 customs_raw 反查；无本地覆盖时才使用 ImportYeti 海关网页关系。"""
    if not settings.HARVEST_ENABLED:
        return {'harvest':{'mode':'disabled'},'_success':True,'_note':'收割禁用'}
    new=list(state.get('supplier_new') or [])
    # 初始 supplier seed 也要执行反向 Customers 透视，但不把它当作“新发现公司”。
    for seed in (state.get('supplier_seeds') or []):
        if norm(seed.get('name')) not in {norm(x.get('name')) for x in new}: new.append(seed)
    merged=list(state.get('companies') or []); have={norm(c.get('name')) for c in merged}; results=[]; errors=[]; added_total=0
    if not new:
        return {'harvest':{'mode':'idle','results':[]},'node_reports':_report(state,'GRAPH_EXPANSION',experts.review('GRAPH_EXPANSION','供应商已收割完毕，正常终态')),'_success':True,'_note':'本轮无新工厂可收割'}
    # 第一层：本地海关原始记录
    profiled=0
    try:
        from core.tools.customs_graph import supplier_to_buyers
        buyers, relations=supplier_to_buyers(new[:settings.NETWORK_EXPANSION_SUPPLIERS], settings.IY_WEB_MAX_CUSTOMERS)
        for c in buyers:
            rn=norm(c.get('name'))
            if not rn or is_non_company_name(c.get('name')): continue  # 当前伪实体拦截
            if rn not in have:
                have.add(rn); merged.append(c); added_total+=1
        results.append({'source':'customs_raw','suppliers':len(new),'customers':len(buyers),'new':added_total})
        # current 单点彻底性：本地提单覆盖的供应商，立即把“这个供应商分析清楚了没有”落成画像
        # （产品结构/档次推断/供应能力/客户覆盖），数据全部来自真实提单，推断如实标注。
        try:
            from core.trade_graph import supplier_profile as sprof
            local_customers={}
            for rel in relations:
                local_customers.setdefault(rel['from_name'],0)
                local_customers[rel['from_name']]+=1
            for s in new[:settings.NETWORK_EXPANSION_SUPPLIERS]:
                if norm(s.get('name')) in {norm(r.get('from_name')) for r in relations}:
                    if sprof.profile_supplier(s.get('name'),customers_found=local_customers.get(s.get('name'),0),run_id=state.get('task_id','')):
                        profiled+=1
        except Exception: pass
    except Exception as e:
        errors.append('customs_raw:'+str(e)[:160])
    # 第二层：ImportYeti，同样是海关/提单关系源；仅补没有本地海关覆盖的供应商
    covered_supplier_names={norm(x.get('from_name')) for x in relations} if 'relations' in locals() else set()
    # 当前：本地海关层已渗透过的供应商同样标记，避免后续运行重复收割同一节点
    for s in new[:settings.NETWORK_EXPANSION_SUPPLIERS]:
        if norm(s.get('name')) in covered_supplier_names:
            try: sup.mark_harvested(sup.norm(s.get('name')),0)
            except Exception: pass
    fallback=[s for s in new[:settings.NETWORK_EXPANSION_SUPPLIERS] if norm(s.get('name')) not in covered_supplier_names]
    if fallback and settings.IY_WEB_ENABLED:
        try:
            from core.tools import iy_web
            if iy_web.available():
                with iy_web.IYWeb() as w:
                    # 当前渗透方式：落池时带真实 slug 的直接拼主页；没有的按名搜索解析主页，
                    # 绝不猜 slug；连续2个节点失败即熔断，保住浏览器配额。
                    # current 防资源枯竭：供应商节点注册表去重 + 页访预算； harvested 标记之外
                    # 再加 NODE_REVISIT_DAYS 保护，避免同一节点页被反复打开。
                    from core.trade_graph import iy_network as iyn
                    budget=iyn.PageBudget(); fails=0; skipped_fresh=0
                    for s in fallback:
                        if fails>=2: break
                        sn_=sup.norm(s.get('name'))
                        if iyn.node_fresh(sn_,'supplier'):
                            skipped_fresh+=1
                            try: sup.mark_harvested(sn_,0)
                            except Exception: pass
                            continue
                        try:
                            if s.get('slug'):
                                url='https://www.importyeti.com/supplier/'+s['slug']
                            else:
                                url=iyn.node_url(sn_,'supplier')
                            if url and not iy_web.is_trade_entity_url(url,'supplier'):
                                url=''
                                if not url:
                                    if not budget.take('search:'+str(s.get('name'))[:40]): break
                                    url=w.supplier_page_for(s.get('name','')) or ''
                            if not url:
                                fails+=1; errors.append(f"{s.get('name')}: 未解析到 ImportYeti 供应商主页"); continue
                            if not budget.take('page:'+url[-60:]): break
                            rows=w.relationships(url,'Customers')[:settings.IY_WEB_MAX_CUSTOMERS]
                            if not rows and w.last_error:
                                fails+=1
                                try: sup.log_harvest(state.get('task_id'),s.get('slug') or '',s.get('name'),'importyeti_web','fail',0,str(w.last_error)[:120])
                                except Exception: pass
                                continue
                            fails=0
                            iyn.mark_node(sn_,'supplier',slug=s.get('slug') or url.rstrip('/').split('/')[-1],url=url,
                                          shipments=int(s.get('shipments') or 0),run_id=state.get('task_id',''))
                            # 当前：该供应商的单点画像——产品档次/供应能力/客户覆盖度（拿到多少、页面共多少）
                            try:
                                from core.trade_graph import supplier_profile as sprof
                                if sprof.profile_supplier(s.get('name'),page_total=int(getattr(w,'last_total',0) or 0),
                                                          customers_found=len(rows),run_id=state.get('task_id','')):
                                    profiled+=1
                            except Exception: pass
                            added=0
                            for r in rows:
                                nm=r.get('name') or '';rn=norm(nm)
                                if not rn:continue
                                e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'products':r.get('products') or '', 'hs':r.get('hs') or [], 'supplier_relation':s.get('name'),'location':r.get('location') or '','location_url':r.get('location_url') or '','url':url}
                                c={'name':nm,'country':'USA','industry':state.get('industry',''),'type':'importer','website':'','source':'importyeti_reverse','strength':5,'evidence':e}
                                if rn not in have:
                                    have.add(rn);merged.append(c);added+=1;added_total+=1
                            results.append({'source':'importyeti_web','supplier':s.get('name'),'customers':len(rows),'new':added})
                            # 当前：渗透完成后标记已收割，下一轮从其他节点继续，不重复挖同一节点
                            try:
                                sup.mark_harvested(sup.norm(s.get('name')),len(rows))
                                _tot=int(getattr(w,'last_total',0) or 0)
                                sup.log_harvest(state.get('task_id'),s.get('slug') or '',s.get('name'),'importyeti_web','ok',len(rows),
                                                f'客户覆盖 {len(rows)}/{_tot}' if _tot else '')
                            except Exception: pass
                        except Exception as e:
                            fails+=1; errors.append(f"{s.get('name')}: {str(e)[:100]}")
                    if skipped_fresh or budget.spent_on:
                        results.append({'source':'importyeti_web','summary':budget.note()+f'·注册表命中跳过{skipped_fresh}个已渗透节点'})
        except Exception as e: errors.append('importyeti_web:'+str(e)[:160])
    # 第三层：ImportKey公开海关公司页，补没有本地/ImportYeti覆盖的供应商反向客户。
    if fallback and settings.IMPORTKEY_ENABLED:
        try:
            from core.tools.data_sources.sources import ImportKeyPublicSource
            ik=ImportKeyPublicSource()
            for s in fallback[:settings.NETWORK_EXPANSION_SUPPLIERS]:
                rows=ik.company_relationships(s.get('name',''),'buyers',settings.IMPORTKEY_MAX_RELATIONS)
                added=0
                for r in rows:
                    nm=r.get('name') or ''; rn=norm(nm)
                    if not rn: continue
                    e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'supplier_relation':s.get('name'),'location':r.get('location') or '','location_url':r.get('location_url') or '','url':r.get('url') or ''}
                    c={'name':nm,'country':'USA','industry':state.get('industry',''),'type':'importer','website':'','source':'importkey_public','strength':5,'evidence':e}
                    if rn not in have: have.add(rn); merged.append(c); added+=1; added_total+=1
                if rows: results.append({'source':'importkey_public','supplier':s.get('name'),'customers':len(rows),'new':added})
        except Exception as e: errors.append('importkey_public:'+str(e)[:160])
    # 当前：supplier→customer 边与新买家节点合并进贸易关系图谱
    try:
        g=cnp.TradeGraph()
        for c in merged:
            nd=cnp.TradeNode(c.get('name'),c.get('node_role') or c.get('type') or 'importer',c.get('source') or '')
            if c.get('evidence'): nd.add_evidence(c['evidence'])
            g.add_node(nd)
        for e in cnp.relations_to_edges(relations if 'relations' in locals() else [],2): g.add_edge(e)
        trade_graph=cnp.merge_graph_into_state(state,g,depth=2)
    except Exception:
        trade_graph=state.get('trade_graph')
    # 当前：图谱待展开节点可见化——反复运行即可完善贸易图谱，进度可度量
    try:
        from core.trade_graph import supplier_profile as sprof
        graph_pending=sprof.pending_graph_nodes()
    except Exception: graph_pending={}
    # 当前统一 Trade Evidence 层：反向收割发现的客户碎片同样登记贸易节点池
    try:
        from core.memory.db import DB as _DB2
        _db2=_DB2()
        for c in merged:
            if norm(c.get('name')) in {norm(x.get('name')) for x in (state.get('companies') or [])}:
                continue
            e0=c.get('evidence') or {}
            _db2.upsert_trade_node(c.get('name'),role='importer',url=e0.get('url') or '',
                shipments=e0.get('shipments') or 0,products=e0.get('products') or '',hs=e0.get('hs') or [],
                depth=2,via=e0.get('supplier_relation') or '',source=c.get('source') or '',
                country=c.get('country') or '')
    except Exception: pass
    rep=experts.review('GRAPH_EXPANSION',f'供应商→客户：透视{len(new)}家，新客户{added_total}，供应商画像{profiled}份，错误{len(errors)}',[('双向海关关系执行',added_total>0 or not errors,f'{added_total}家新增'),('供应商单点画像',profiled>0 or not new,f'{profiled}份')])
    return {'harvest':{'mode':'customs_graph','results':results,'errors':errors,'policy':'customs_only_relationships','suppliers_profiled':profiled},'companies':merged,'trade_graph':trade_graph,'graph_pending':graph_pending,'reverse_new':[x for x in merged if norm(x.get('name')) not in {norm(c.get('name')) for c in state.get('companies',[])}],'node_reports':_report(state,'GRAPH_EXPANSION',rep),'_success':True,'_note':f'反向收割 {len(new)} 家工厂·新增客户 {added_total}·供应商画像 {profiled} 份·待展开节点 {graph_pending.get("unharvested_suppliers",0)} 家·全部关系来自海关数据源'}

# 当前：物流/货代/船代是真实贸易节点（图谱证据、验证参照、收割路径），
# 但它们不是客户——不再丢弃，统一停放到贸易节点数据池（role='logistics'）。
LOGISTICS_RE=re.compile(r'freight|forwarder|logistics|cargo|shipping|customs broker|packaging',re.I)

def n_clean_verify(state):
    companies=list(state.get('companies') or []);out=[];seen=set();dropped=0;known=0;identity_only=0;new_entities=[];existing_entities=[]
    logistics_parked=0; dupes=0; drop_samples=[]
    from core.memory.db import DB
    db=DB()
    for x in companies:
        nm=(x.get('name') or '').strip();n=norm(nm)
        if not n:
            dropped+=1
            if len(drop_samples)<8: drop_samples.append((nm[:60],'名称无效'))
            continue
        if LOGISTICS_RE.search(nm):
            e=x.get('evidence') or {}
            try: db.upsert_trade_node(nm,role='logistics',url=e.get('url') or '',shipments=e.get('shipments') or 0,products=e.get('products') or '',hs=e.get('hs') or [],depth=e.get('depth') or 0,via=e.get('via') or e.get('supplier_relation') or '',source=x.get('source') or '')
            except Exception: pass
            logistics_parked+=1
            if len(drop_samples)<8: drop_samples.append((nm[:60],'物流/货代→节点池'))
            continue
        if noise(nm):
            dropped+=1
            if len(drop_samples)<8: drop_samples.append((nm[:60],'明确非企业'))
            continue
        if n in seen:
            dupes+=1
            continue
        seen.add(n)
        old=db.get_lead(n)
        if old: known+=1; existing_entities.append(x)
        else: new_entities.append(x)
        if not hard_evidence_local(x):identity_only+=1
        out.append(x)
    # 这里故意不写 leads。ENTITY_RESOLUTION 只负责“识别已有/新实体”，
    # 真正的画像合并与业务分区必须由最后的 DATABASE_COMMIT 原子完成。
    # 否则新客户会在这里提前进入 leads，最后节点再看时就会被误判成“已有客户”，
    # 从而出现“采集有结果、开发池却没有客户”的生产级逻辑错误。
    funnel={'stage':'ENTITY_RESOLUTION','in':len(companies),'out':len(out),
            'duplicates_merged':dupes,'logistics_parked':logistics_parked,'dropped':dropped,
            'samples':drop_samples}
    funnels=list(state.get('funnel') or []); funnels.append(funnel)
    rep=experts.review('ENTITY_RESOLUTION',f'二轮清洗 输入{len(companies)}→{len(out)}·已有{known}·新增{len(new_entities)}·同名合并{dupes}·物流入池{logistics_parked}·明确非企业{dropped}·仅身份{identity_only}',
                       [('计数可解释',len(out)+dropped+dupes+logistics_parked<=len(companies),f'{len(out)}+合并{dupes}+物流{logistics_parked}+非企业{dropped}={len(out)+dropped+dupes+logistics_parked} ≤ {len(companies)}'),
                        ('增量身份已区分',known+len(new_entities)==len(out),f'已有{known}+新增{len(new_entities)}={len(out)}'),
                        ('身份客户不因缺字段删除',True,'policy locked'),
                        ('减少原因透明',True,'；'.join(f'{a}:{b}' for a,b in drop_samples[:4]) or '无丢弃')],critical={'计数可解释','增量身份已区分'})
    return {'task_data':out,'companies':out,'new_companies':new_entities,'new_entity_companies':new_entities,'existing_enriched_companies':existing_entities,
            'known_count':known,'new_entity_count':len(new_entities),'dropped_count':dropped,'identity_only_count':identity_only,
            'funnel':funnels,
            'node_reports':_report(state,'ENTITY_RESOLUTION',rep),'_success':True,'_note':f'二轮清洗 {len(companies)}→{len(out)} 家·新增 {len(new_entities)}·已有补充 {known}·同名合并 {dupes}·物流入池 {logistics_parked}·明确非企业 {dropped}'}

def n_gate(state):
    cs=list(state.get('companies') or state.get('task_data') or []);accepted=[];rejects=[];judgments=[]
    for c in cs:
        e=c.get('evidence') or {}; hard=hard_evidence_local(c); relation=bool(e.get('supplier_relation'))
        # 客户身份和证据强度分离：只有明确非客户才剔除；低完整度客户进入 pending，而不是 reject。
        if noise(c.get('name')):
            decision='reject';reason='明确非客户/服务商'
            rejects.append({'name':c.get('name'),'reason':reason})
        else:
            decision='accept';reason='硬贸易证据' if hard else ('反向供应链关系' if relation else '身份候选（待画像补全）')
            accepted.append(c)
        judgments.append({'name':c.get('name'),'decision':decision,'reason':reason,'hard_evidence':hard})
    strong=sum(1 for c in accepted if hard_evidence_local(c));g={'ok':len(accepted)>=settings.GATE_MIN_QUALIFIED,'raw':len(cs),'qualified':len(accepted),'strong':strong,'rejects':rejects,'judgments':judgments,'qualified_companies':accepted,'identity_only':sum(1 for c in accepted if not hard_evidence_local(c))}
    rep=experts.review('RESOURCE_CLASSIFICATION',f'候选{len(cs)}·放行{len(accepted)}·强证据{strong}·仅身份{g["identity_only"]}',[('逐家有结论',len(judgments)==len(cs),f'{len(judgments)}/{len(cs)}'),('数量达标',g['ok'],f'{len(accepted)}/{settings.GATE_MIN_QUALIFIED}')],critical={'逐家有结论','数量达标'})
    prior_new={norm(c.get('name')) for c in (state.get('new_companies') or [])}
    new_qualified=[c for c in accepted if norm(c.get('name')) in prior_new]
    g['new_qualified']=len(new_qualified); g['existing_refresh']=len(accepted)-len(new_qualified)
    return {'gate':g,'qualified_companies':accepted,'new_companies':new_qualified,'node_reports':_report(state,'RESOURCE_CLASSIFICATION',rep),'_success':g['ok'],'_note':f'证据资格：放行{len(accepted)}·新增开发{len(new_qualified)}·已有画像刷新{len(accepted)-len(new_qualified)}·强证据{strong}'}


# ============================================================
# 当前贸易图谱智能体节点层（最终架构：真实资源优先 + 召回率最大化 +
# 证据分层 + 图谱优先 + 一个总编排智能体统一控制）
# 九节点契约（唯一版本，Planner/Orchestrator/Runner/Registry/UI 同名）：
#   1 PRODUCT_DEFINITION       产品定义 → 16维产品语义矩阵 + 动态查询计划（无固定上限）
#   2 TRADE_STRATEGY           贸易定位 → 12要素动态搜索计划（HS=强辅助信号，非硬过滤）
#   3 CUSTOMS_NODE_COLLECTION  海关节点采集 → Trade Node 全字段 + 逐查询计量（query_stats）
#   4 TRADE_EDGE_BUILD         贸易关系边建立 → 标准边字段 + evidence_level
#   5 EVIDENCE_VERIFY          证据四级验证 → STRONG/MEDIUM/WEAK/UNVERIFIED（降权不删除）
#   6 ENTITY_RESOLUTION        贸易节点→企业实体 → CUSTOMER/SUPPLIER/CUSTOMER_AND_SUPPLIER/UNKNOWN
#   7 GRAPH_EXPANSION          递归多层双向扩张 + 动态停止（图谱优先：先图谱后资源）
#   8 RESOURCE_CLASSIFICATION  三维分类（角色/贸易状态/开发状态）+ 理由字段
#   9 DATABASE_COMMIT          三类资产入库（Entity+Edge+Evidence）+ 完整漏斗
# 编排器（graph.py）拥有唯一流程控制权，节点只拥有执行权。
# ============================================================

# 实体解析：法律后缀归一（Panjiva 式实体解析的最小确定性实现——
# “NINGBO XX PLASTIC CO LTD” 与 “NINGBO XX PLASTIC CO., LTD.” 是同一实体）。
LEGAL_SUFFIX_RE = re.compile(
    r'\b(incorporated|inc|llc|llp|ltd|limited|corp|corporation|co|company|gmbh|sarl|sa|ag|plc|pty)\b\.?', re.I)


def entity_key(name):
    """实体归一键：去法律后缀+标点。仅用于“完全同键”的保守合并，不做模糊猜测。"""
    return re.sub(r'[^a-z0-9一-鿿]+', '', LEGAL_SUFFIX_RE.sub(' ', str(name or '').lower()))


def _is_supplier(c):
    return c.get('type') == 'supplier' or c.get('node_role') == 'supplier' or \
           c.get('entity_role') == 'SUPPLIER' or \
           str(c.get('lifecycle') or '').startswith('SUPPLIER')


# ---------- NODE 1 PRODUCT_DEFINITION：自然语言产品 → 16维产品语义矩阵 ----------
def n_product_definition(state):
    from core.trade_graph import product_intelligence as pi
    icp_out = n_icp(state)  # ICP 契约并入本节点产出，不再是独立节点
    icp = icp_out.get('icp') or {}
    profile = pi.build_product_profile(state['industry'], icp)
    hs_val = pi.validate_hs(profile['hs_candidates'])
    # 当前：动态查询计划——矩阵产出多少用多少，无固定上限；
    # 逐查询计量与动态淘汰由 CUSTOMS_NODE_COLLECTION 回填 query_stats。
    query_plan = pi.build_query_plan(profile)
    domain = re.sub(r'[^A-Z0-9]+', '_', str(profile['canonical']).upper()).strip('_') or 'GENERAL'
    # 当前产品情报反哺：上一轮从真实海关描述学到的词，进入本轮召回查询（低优先级、有上限、不替代矩阵词）
    learned_qs = pi.learned_recall_queries(domain)
    if learned_qs:
        known = {q['query'].lower() for q in query_plan}
        query_plan += [q for q in learned_qs if q['query'].lower() not in known]
    matrix = [q['query'] for q in query_plan]
    DIMS16 = ('core_name','standard_name_en','synonyms','spelling_variants','industry_terms',
              'buyer_terms','supplier_terms','form_words','materials','function_words',
              'trade_terms','hs_candidates','exclusions','precision_terms','recall_terms','combo_queries')
    dims_filled = sum(1 for k in DIMS16 if profile.get(k))
    product_domain = {'key': domain, 'canonical': profile['canonical'], 'version': hashlib.sha1(json.dumps({k: profile.get(k) for k in ('canonical','standard_name_en','synonyms','spelling_variants','industry_terms','buyer_terms','supplier_terms','form_words','materials','function_words','trade_terms','hs_candidates','exclusions','precision_terms','recall_terms','combo_queries','applications')},sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()[:12],
                      # 规范契约四要素：product_terms / trade_terms / hs_candidates / exclude_terms
                      'product_terms': [profile['canonical']] + list(profile['synonyms']),
                      'trade_terms': list(profile['trade_terms']),
                      'hs_candidates': profile['hs_candidates'], 'exclude_terms': profile['exclusions'],
                      'matrix': matrix, 'query_plan': query_plan, 'hs_validation': hs_val,
                      'exclusions': profile['exclusions'],
                      'materials': profile['materials'], 'applications': profile['applications'],
                      'semantic_matrix': {k: profile.get(k) for k in DIMS16}}
    rep = experts.review('PRODUCT_DEFINITION',
                         f'产品域 {domain}\n16维语义矩阵：{dims_filled}/16 维已填充\n查询计划：{len(query_plan)} 条（无固定上限）\n' +
                         json.dumps(matrix[:12], ensure_ascii=False) +
                         f'\n排除词：{profile["exclusions"]}\nHS候选：{profile["hs_candidates"]}',
                         [('产品语义矩阵16维', dims_filled >= 8, f'{dims_filled}/16 维'),
                          ('关键词矩阵非单一关键词', len(matrix) >= 3, f'{len(matrix)}个'),
                          ('排除词已定义', bool(profile['exclusions']), f'{len(profile["exclusions"])}个'),
                          ('HS候选集已验证标注', True, f"{sum(1 for v in hs_val.values() if v['validated'])}/{len(hs_val)} 有历史提单")],
                         critical={'关键词矩阵非单一关键词'})
    return {'icp': icp, 'product_profile': profile, 'product_domain': product_domain,
            'node_reports': _report(state, 'PRODUCT_DEFINITION', rep), '_success': True,
            '_note': f"产品定义 {domain}：语义矩阵{dims_filled}/16维·查询计划{len(query_plan)}条（动态无上限）·排除{len(profile['exclusions'])}词·HS候选{len(profile['hs_candidates'])}个·LLM增强{'是' if profile['llm_enriched'] else '否（确定性兜底）'}"}


# ---------- NODE 2 TRADE_STRATEGY：贸易定位（12要素动态搜索计划） ----------
def n_trade_strategy(state):
    out = n_strategy(state)  # 执行器复用；profile 由 PRODUCT_DEFINITION 提供（见 n_strategy 内复用逻辑）
    strategy = dict(out.get('strategy') or {})
    pd = state.get('product_domain') or {}
    # 当前：查询计划来自16维语义矩阵，无固定上限；
    # query_stats 里已 retired 的查询降权（排到队尾但不删除——下轮有产出立即回活）。
    plan = list(pd.get('query_plan') or [])
    retired = set()
    try:
        from core.memory.db import DB
        retired = {r['query'].lower() for r in DB().list_query_stats(pd.get('key'), status='retired', limit=2000)}
    except Exception:
        pass
    active = [q for q in plan if q['query'].lower() not in retired]
    demoted = [q for q in plan if q['query'].lower() in retired]
    query_plan = active + demoted
    queries = [q['query'] for q in query_plan]
    strategy_query_items = list(strategy.get('queries') or [])
    for q in strategy_query_items:  # 执行器既有变体并入，不丢失
        qtext = q.get('query') if isinstance(q,dict) else q
        if qtext and qtext not in queries:
            queries.append(qtext)
    # 自适应执行计划：Node 2 负责决定搜索顺序与停止条件，Node 3 负责实际执行。
    # 不再把“生成了91条查询”误认为“执行了91条查询”。
    stage_counts = {}
    for q in query_plan:
        stage_counts[int(q.get('stage', 4))] = stage_counts.get(int(q.get('stage', 4)), 0) + 1
    execution_policy = {
        'mode': 'staged_adaptive_retrieval',
        'waves': [
            {'stage': 0, 'name': 'anchor', 'min_queries': 1, 'max_queries': 1, 'required': True},
            {'stage': 1, 'name': 'product_equivalents', 'min_queries': min(3, stage_counts.get(1, 0)), 'max_queries': stage_counts.get(1, 0), 'required': bool(stage_counts.get(1))},
            {'stage': 2, 'name': 'trade_roles', 'min_queries': min(4, stage_counts.get(2, 0)), 'max_queries': stage_counts.get(2, 0), 'required': bool(stage_counts.get(2))},
            {'stage': 3, 'name': 'close_context', 'min_queries': min(3, stage_counts.get(3, 0)), 'max_queries': stage_counts.get(3, 0), 'required': False},
            {'stage': 4, 'name': 'broad_recall', 'min_queries': min(2, stage_counts.get(4, 0)), 'max_queries': stage_counts.get(4, 0), 'required': False},
        ],
        'stop_policy': {
            'never_stop_after_anchor_only': True,
            'continue_if_new_nodes': True,
            'continue_if_new_sources': True,
            'continue_if_role_coverage_missing': True,
            'stop_when': ['all planned waves exhausted', 'two consecutive waves yield zero new nodes and zero new sources', 'source circuit breaker'],
            'do_not_stop_only_because_quantity_reached': True,
        },
        'feedback_fields': ['result_count', 'usable_trade_nodes', 'usable_trade_edges', 'precision_estimate', 'recall_contribution'],
    }
    strategy.update({
        # 12 要素动态搜索计划
        'product_domain': pd.get('key', ''),                                # 1 产品域
        'buyer_types': ['importer', 'distributor', 'wholesaler', 'brand owner', 'retailer'],  # 2 买家类型
        'supplier_types': ['factory', 'manufacturer', 'exporter'],          # 3 供应商类型
        'target_roles': ['CUSTOMER', 'SUPPLIER', 'CUSTOMER_AND_SUPPLIER'],  # 4 目标角色
        'target_hs': pd.get('hs_candidates') or strategy.get('hs_codes') or [],  # 5 目标HS
        'hs_strategy': {'candidates': pd.get('hs_candidates') or [],        # 6 HS策略：强辅助信号，非硬过滤
                        'validation': pd.get('hs_validation') or {},
                        'policy': 'strong_signal_not_hard_filter'},
        'target_countries': [state.get('market') or 'USA'],                 # 7 目标市场
        'query_plan': query_plan,                                           # 8 动态查询计划（逐查询计量）
        'execution_policy': execution_policy,                               # 8b 分阶段自适应执行策略
        'precision_recall_split': {                                         # 9 精度/召回配比
            'precision': sum(1 for q in query_plan if q.get('query_type') in ('core','synonym','spelling','precision','buyer_role','supplier_role')),
            'recall': sum(1 for q in query_plan if q.get('query_type') in ('recall','industry','form','combo'))},
        'expansion_policy': {'mode': 'bidirectional_value_bounded',             # 10 扩张策略
                             'max_depth': min(int(getattr(settings,'MAX_EXPANSION_ROUNDS',3)), 3),
                             'dynamic_stop': ['连续2轮零新增', '目标相关新增低于阈值', 'information_gain低', 'frontier耗尽', '达到轮数上限'],
                             'graph_first': True, 'level1_required': True, 'level2_default': True, 'level3_conditional': True,
                             'per_seed_budget': int(getattr(settings,'EXPAND_CUSTOMERS',15)),
                             'global_new_entity_budget': int(getattr(settings,'EXPAND_MAX_NEW',40))},
        'evidence_policy': {'levels': ['STRONG', 'MEDIUM', 'WEAK', 'UNVERIFIED'],  # 11 证据策略：四级降权不删除
                            'policy': 'demote_not_delete'},
        'collection_budget': {'quantity': int(state.get('quantity') or 20), # 12 采集预算：第一轮宽采集
                              'first_round': 'wide', 'retired_queries_demoted': len(demoted)},
        'queries': queries,
        'query_count': len(queries),
        'positioning': 'trade_graph_first'})
    nr = dict(state.get('node_reports') or {})
    nr['TRADE_STRATEGY'] = (out.get('node_reports') or {}).get('TRADE_STRATEGY') or {}
    return {**{k: v for k, v in out.items() if k not in ('node_reports', '_note')},
            'strategy': strategy, 'node_reports': nr, '_success': out.get('_success', True),
            '_note': f"贸易定位（12要素）：域 {pd.get('key','—')} · 买家{len(strategy['buyer_types'])}类/供应商{len(strategy['supplier_types'])}类 · 目标HS {len(strategy['target_hs'])} 个（强信号非硬过滤）· 目标市场 {state.get('market','')} · 动态查询 {len(queries)} 条（精度{strategy['precision_recall_split']['precision']}/召回{strategy['precision_recall_split']['recall']}·降权{len(demoted)}）"}


# ---------- current Local DeepSeek semantic layer ----------
def _ai_queue_hook(state):
    # Runtime observation/checkpoint hook supplied by Orchestrator. It never controls
    # node flow. Queue state is persisted for live UI progress and crash diagnostics.
    def hook(queue):
        try:
            state['ai_queue'] = dict(queue or {})
            cb = state.get('_persist_runtime')
            if cb: cb(state)
        except Exception:
            pass
    return hook

def _shared_judgment_bucket(state, stage):
    """Persistent per-task judgment cache.

    A node owns the semantic decision, while later nodes reuse the decision and
    only reopen it when new evidence creates ambiguity/conflict. This is the
    shared-state contract: facts and prior judgments travel downstream together.
    """
    root = state.setdefault('judgment_registry', {})
    return root.setdefault(stage, {})


def _judgment_fingerprint(stage, obj, state=None):
    """Stable fingerprint for the business facts that matter to a judgment."""
    if stage == 'EVIDENCE_VERIFY':
        data = {
            'from': obj.get('from_name'), 'to': obj.get('to_name'),
            'relation': obj.get('relation'), 'source': obj.get('source'),
            'shipments': (obj.get('evidence') or {}).get('shipments') or obj.get('shipment_count'),
            'hs': (obj.get('evidence') or {}).get('hs') or obj.get('hs_code'),
            'products': (obj.get('evidence') or {}).get('products') or obj.get('product_text'),
            'url': (obj.get('evidence') or {}).get('url'),
        }
    elif stage == 'ENTITY_RESOLUTION':
        e = obj.get('evidence') or {}
        data = {'name': obj.get('canonical_name') or obj.get('name'), 'type': obj.get('type') or obj.get('node_role'),
                'country': obj.get('country'), 'products': e.get('products'), 'hs': e.get('hs'),
                'product_boundary_version': ((state.get('product_domain') or {}).get('version') if state else None),
                'trade_role': obj.get('type') or obj.get('node_role')}
    elif stage == 'TARGET_FIT':
        e = obj.get('evidence') or {}
        data = {'entity_id': obj.get('entity_id') or obj.get('name'),
                'product_boundary_version': ((state.get('product_domain') or {}).get('version') if state else None),
                'products': e.get('products'), 'hs': e.get('hs'),
                'trade_fact_ids': obj.get('trade_fact_ids') or [],
                'business_description': e.get('company_description') or e.get('public_page') or obj.get('business_description')}
    elif stage == 'GRAPH_EXPANSION':
        e = obj.get('evidence') or {}
        data = {'name': obj.get('name'), 'role': obj.get('entity_role') or obj.get('type'),
                'products': e.get('products'), 'hs': e.get('hs'), 'shipments': e.get('shipments'),
                'source': obj.get('source'), 'product_relevance': obj.get('product_relevance'),
                'trade_status': obj.get('trade_status')}
    elif stage == 'RESOURCE_CLASSIFICATION':
        e = obj.get('evidence') or {}
        data = {'name': obj.get('name'), 'role': obj.get('entity_role') or obj.get('type'),
                'country': obj.get('country'), 'products': e.get('products'), 'hs': e.get('hs'),
                'shipments': e.get('shipments'), 'source': obj.get('source'),
                'trade_status': obj.get('trade_status'),
                'product_boundary_version': ((state.get('product_domain') or {}).get('version') if state else None),
                'target_fit': obj.get('target_fit'),
                'evidence_level': e.get('grade') or obj.get('evidence_level'),
                'entity_judgment': obj.get('entity_ai_judgment') or {},
                'evidence_judgment': e.get('ai_evidence_judgment') or {}}
    else:
        data = obj
    raw = json.dumps(data, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:20]


def _shared_get(state, stage, obj):
    if not getattr(settings, 'AI_SHARED_JUDGMENT_REUSE', True):
        return None
    return _shared_judgment_bucket(state, stage).get(_judgment_fingerprint(stage, obj, state))


def _shared_put(state, stage, obj, judgment, origin):
    if not isinstance(judgment, dict):
        return
    j = dict(judgment)
    j.setdefault('judgment_origin', origin)
    j.setdefault('judgment_stage', stage)
    j.setdefault('judgment_fingerprint', _judgment_fingerprint(stage, obj, state))
    _shared_judgment_bucket(state, stage)[j['judgment_fingerprint']] = j


def _ai_ok(j):
    return isinstance(j, dict) and bool(j.get('_ai_success'))


def _node3_trade_judgment(c):
    e = c.get('evidence') or {}
    j = e.get('ai_judgment') or {}
    return j if isinstance(j, dict) else {}


def _clear_company_signal(c):
    """High-confidence company signal already established upstream."""
    e = c.get('evidence') or {}
    j = _node3_trade_judgment(c)
    et = str(j.get('entity_type') or c.get('ai_entity_type') or '').lower()
    conf = float(j.get('confidence') or 0)
    explicit_company = str(c.get('type') or '').lower() in ('importer','buyer','supplier','company','customer')
    has_url = bool(e.get('url') or c.get('website'))
    hard = hard_evidence_local(c)
    return ((et == 'company' and conf >= 0.82) or (explicit_company and has_url and hard))


def _entity_role_from_existing(c):
    j = c.get('entity_ai_judgment') or {}
    role = str(j.get('role') or '').upper()
    if role in ('CUSTOMER','SUPPLIER','CUSTOMER_AND_SUPPLIER','UNKNOWN'):
        return role
    j3 = _node3_trade_judgment(c)
    tr = str(j3.get('trade_role') or '').lower()
    if tr in ('supplier','manufacturer','exporter','shipper'):
        return 'SUPPLIER'
    if tr in ('importer','consignee','buyer','notify_party'):
        return 'CUSTOMER'
    if _is_supplier(c):
        return 'SUPPLIER'
    if hard_evidence_local(c):
        return 'CUSTOMER'
    return 'UNKNOWN'


def _entity_needs_ai(c):
    if _trade_node_is_fragment(c) or is_non_company_name(c.get('name')):
        return False
    existing = c.get('entity_ai_judgment') or {}
    if _ai_ok(existing):
        return False
    # Node 3 already established a high-confidence company identity: do not ask
    # the same question again. Node 6 only reopens conflicts/identity ambiguity.
    if _clear_company_signal(c):
        return False
    return True


def _edge_needs_ai(ed):
    e = ed.get('evidence') or {}
    prior = e.get('ai_evidence_judgment') or ed.get('ai_evidence_judgment') or {}
    if _ai_ok(prior):
        return False
    grade = str(ed.get('evidence_level') or '').upper()
    if not grade:
        grade = str(_evidence_level(e, ed.get('source') or '') or '').upper()
    shipments = int(e.get('shipments') or ed.get('shipment_count') or 0)
    hs = e.get('hs') or ed.get('hs_code') or []
    products = str(e.get('products') or ed.get('product_text') or '').strip()
    # Strong, source-backed edges with actual shipments and product/HS fields are
    # already sufficiently proven by deterministic evidence policy. AI is reserved
    # for the cases where semantics can change the level.
    if grade == 'STRONG' and shipments > 0 and (hs or products):
        return False
    return True


def _expansion_rule(c):
    """Return a deterministic expansion judgment only when the case is obvious."""
    e = c.get('evidence') or {}
    role = str(c.get('entity_role') or '').upper()
    ts = str(c.get('trade_status') or '').upper()
    if not ts:
        summary = c.get('evidence_summary') or e.get('evidence_summary') or {}
        best = str(summary.get('best_level') or '').upper()
        shipments_hint = int(e.get('shipments') or 0)
        ts = 'TRADE_CONFIRMED' if best == 'STRONG' or (shipments_hint > 0 and hard_evidence_local(c)) else ('TRADE_SUPPORTED' if best in ('MEDIUM','WEAK') or hard_evidence_local(c) else 'DISCOVERED')
    shipments = int(e.get('shipments') or 0)
    if role in ('CUSTOMER','SUPPLIER','CUSTOMER_AND_SUPPLIER') and ts == 'TRADE_CONFIRMED' and shipments >= 3:
        return {'_ai_success': False, 'expand': 'yes', 'expected_value': 'high',
                'direction': 'both', 'reason': '已确认企业实体且有多票真实贸易证据', 'confidence': 0.95,
                'judgment_origin': 'RULE_REUSE'}
    if role in ('CUSTOMER','SUPPLIER','CUSTOMER_AND_SUPPLIER') and ts == 'TRADE_CONFIRMED' and shipments > 0:
        return {'_ai_success': False, 'expand': 'maybe', 'expected_value': 'medium',
                'direction': 'both', 'reason': '已确认企业实体且存在真实贸易证据', 'confidence': 0.86,
                'judgment_origin': 'RULE_REUSE'}
    return None


def _classification_rule(c, default_role):
    """Reuse accumulated state when final classification is already determined."""
    role = str(c.get('entity_role') or default_role or 'UNKNOWN').upper()
    if role not in ('CUSTOMER','SUPPLIER','CUSTOMER_AND_SUPPLIER','UNKNOWN'):
        return None
    e = c.get('evidence') or {}
    ts = str(c.get('trade_status') or '').upper()
    if not ts:
        summary = c.get('evidence_summary') or e.get('evidence_summary') or {}
        best = str(summary.get('best_level') or '').upper()
        shipments_hint = int(e.get('shipments') or 0)
        if best == 'STRONG' or (shipments_hint > 0 and hard_evidence_local(c)):
            ts = 'TRADE_CONFIRMED'
        elif best in ('MEDIUM','WEAK') or hard_evidence_local(c):
            ts = 'TRADE_SUPPORTED'
        else:
            ts = 'DISCOVERED'
    ai_rel = str((c.get('ai_classification_judgment') or {}).get('business_relevance') or '').lower()
    if role == 'UNKNOWN':
        return None
    if ts not in ('TRADE_CONFIRMED','TRADE_SUPPORTED','DISCOVERED'):
        return None
    if ai_rel == 'unrelated':
        ds = 'DISCOVERED_POOL'
    elif ts in ('TRADE_CONFIRMED','TRADE_SUPPORTED'):
        ds = 'DEVELOPMENT_POOL'
    else:
        ds = 'DISCOVERED_POOL'
    return {'_ai_success': False, 'entity_role': role,
            'business_relevance': 'core' if ts == 'TRADE_CONFIRMED' else 'unknown',
            'development_status': ds, 'priority': 'high' if ts == 'TRADE_CONFIRMED' else 'medium',
            'reason': '复用上游实体角色与证据分级，无新增冲突', 'confidence': 0.92 if ts == 'TRADE_CONFIRMED' else 0.82,
            'judgment_origin': 'SHARED_STATE_REUSE'}

def _trade_node_is_fragment(c):
    """确定性识别 ImportYeti 地点/国家关系残片；这里不调用模型。"""
    typ=str(c.get('type') or c.get('kind') or '').strip().lower()
    if typ in ('fragment','location','country','government','person','logistics'):
        return typ if typ != 'fragment' else 'fragment'
    e=c.get('evidence') or {}
    url=str(e.get('url') or c.get('website') or '').lower()
    if '/location/' in url:
        return 'location'
    if '/country/' in url:
        return 'country'
    return ''

def _ai_entity_judgments(companies, state):
    """Node 6 is incremental entity resolution, not a second full screening pass."""
    from core.intelligence.local_judge import resolve_entities_serial
    domain=(state.get('product_domain') or {}).get('key',''); market=state.get('market') or 'USA'
    out=[]; fragments=[]; judgments=[]; uncertain=[]; reused=0; ruled=0
    for c in (companies or []):
        if _trade_node_is_fragment(c) or is_non_company_name(c.get('name')):
            c['fragment_type']=_trade_node_is_fragment(c) or 'non_company'
            fragments.append(c)
            judgments.append({'name':c.get('name'),'entity_type':c.get('fragment_type'),'role':'UNKNOWN',
                              'merge_safe':'no','confidence':1.0,'ai_success':False,'decision':'FRAGMENT_BY_RULE'})
            ruled += 1
            continue
        cached = _shared_get(state, 'ENTITY_RESOLUTION', c)
        existing = c.get('entity_ai_judgment') or cached
        if _ai_ok(existing):
            c['entity_ai_judgment']=dict(existing)
            c.setdefault('evidence',{})['entity_ai_judgment']=dict(existing)
            out.append(c); judgments.append({'name':c.get('name'),'entity_type':existing.get('entity_type'),'role':existing.get('role'),
                                              'merge_safe':existing.get('merge_safe'),'confidence':existing.get('confidence'),
                                              'ai_success':True,'decision':'REUSED_JUDGMENT'})
            reused += 1
            continue
        if not _entity_needs_ai(c):
            role=_entity_role_from_existing(c)
            j={'_ai_success':False,'entity_type':'company','canonical_name':c.get('name') or '',
               'role':role,'same_entity_confidence':0.92,'merge_safe':'unknown',
               'reason':'复用节点3已建立的高置信企业信号；仅做保守同名合并',
               'confidence':0.92,'judgment_origin':'SHARED_STATE_REUSE'}
            c['entity_ai_judgment']=j; c.setdefault('evidence',{})['entity_ai_judgment']=j
            out.append(c); judgments.append({'name':c.get('name'),'entity_type':'company','role':role,
                                              'merge_safe':'unknown','confidence':0.92,'ai_success':False,
                                              'decision':'REUSED_NODE3'})
            _shared_put(state,'ENTITY_RESOLUTION',c,j,'SHARED_STATE_REUSE')
            ruled += 1
        else:
            uncertain.append(c)
    results=resolve_entities_serial(uncertain,domain,market,progress_hook=_ai_queue_hook(state)) if uncertain else []
    for c,j in zip(uncertain,results):
        j=j or {'_ai_success':False,'entity_type':'unknown','role':'UNKNOWN','merge_safe':'unknown','reason':'no semantic judgment','confidence':0}
        if '_ai_success' not in j and j.get('entity_type'): j['_ai_success']=True
        c['entity_ai_judgment']=j; c.setdefault('evidence',{})['entity_ai_judgment']=j
        _shared_put(state,'ENTITY_RESOLUTION',c,j,'AI_DEEP')
        # target fit is a separate semantic layer; keep it independent from final role.
        if not c.get('target_fit'):
            tf_cached=_shared_get(state,'TARGET_FIT',c)
            if isinstance(tf_cached,dict): c['target_fit']=tf_cached.get('target_fit')

        et=str(j.get('entity_type') or 'unknown').lower()
        if et in ('location','country','government','person','logistics'):
            c['fragment_type']=et; fragments.append(c)
        else: out.append(c)
        judgments.append({'name':c.get('name'),'entity_type':et,'role':j.get('role'),'merge_safe':j.get('merge_safe'),
                          'confidence':j.get('confidence'),'ai_success':bool(j.get('_ai_success')),'decision':'AI_DEEP'})
    state.setdefault('ai_node_judgments',[]).extend(judgments)
    state['entity_resolution_ai_stats']={'input':len(companies or []),'ai_judged':len(uncertain),
                                          'reused':reused,'rule_reused':ruled,'fragments':len(fragments)}
    return out,fragments,judgments

def _node3_direct_fallback_observations(state, companies, existing):
    """Bounded direct-trade evidence fallback for Node 3 only.
    No target-fit decision and no route selection; unanchored counterparts remain unresolved.
    """
    if existing:
        return [], {'attempted': False, 'source': '', 'seeds': 0, 'rows': 0, 'reason': 'already_have_direct_observations'}
    max_seeds=max(1,int(getattr(settings,'NODE3_DIRECT_FALLBACK_SEEDS',5)))
    seeds=sorted([c for c in (companies or []) if c.get('name')], key=lambda c:-int((c.get('evidence') or {}).get('shipments') or 0))[:max_seeds]
    if not seeds:
        return [], {'attempted': False, 'source': '', 'seeds': 0, 'rows': 0, 'reason': 'no_trade_node_seed'}
    rows=[]
    try:
        from core.tools.data_sources.sources import ImportKeyPublicSource
        src=ImportKeyPublicSource()
        if not src.available():
            return [], {'attempted': False, 'source': 'importkey_public', 'seeds': len(seeds), 'rows': 0, 'reason': 'source_disabled'}
        for seed in seeds:
            try: rels=src.company_relationships(seed.get('name',''),'suppliers',int(getattr(settings,'NODE3_DIRECT_FALLBACK_RELATIONS',10))) or []
            except Exception as exc:
                state.setdefault('source_errors',[]).append('node3_importkey:'+str(exc)[:160]); rels=[]
            for r in rels:
                nm=str(r.get('name') or '').strip()
                if len(nm)<3: continue
                rows.append({'from_name':seed.get('name'),'from_type':'buyer','to_name':nm,'to_type':'unresolved_trade_node','relation':'buyer_to_supplier','source':'importkey_public','source_url':str(r.get('url') or ''),'products':r.get('products') or '','hs':r.get('hs') or [],'shipments':int(r.get('shipments') or 0),'location':r.get('location') or '','parent_node':seed.get('name'),'depth':1,'query':seed.get('name') or '','identity_status':'UNRESOLVED','confidence':0.80,'raw_evidence':{'source':'importkey_public','parent_entity':seed.get('name'),'counterpart_raw':nm,'shipments':r.get('shipments') or 0,'url':r.get('url') or ''}})
    except Exception as exc:
        state.setdefault('source_errors',[]).append('node3_importkey:'+str(exc)[:160])
        return [], {'attempted': True, 'source':'importkey_public', 'seeds':len(seeds), 'rows':0, 'reason':'executor_error'}
    return rows, {'attempted': True, 'source':'importkey_public', 'seeds':len(seeds), 'rows':len(rows),'reason':'direct_observations_recovered' if rows else 'source_returned_no_rows'}

def n_customs_node_collection(state):
    """Node 3 = trade-node discovery and evidence assembly, not customer targeting.

    The unit of work is an auditable trade observation:
        source record -> node identity -> role -> counterpart -> product/HS/shipment evidence.
    High-recall records stay in the graph. Only explicit non-trade/location junk is quarantined.
    Ambiguous trade rows are retained as UNRESOLVED fragments and may be semantically resolved;
    resolution never decides customer value.
    """
    out = n_collect(state)
    from core.memory.db import DB
    db = DB()
    pd = state.get('product_domain') or {}
    pd_key = pd.get('key', '')
    companies = list(out.get('companies') or [])
    seed_fragments = list(out.get('raw_fragments') or [])

    # ---- 1. Separate true unresolved trade fragments from pure geo/context fragments.
    trade_fragments=[]
    ai_candidates=[]
    for f in seed_fragments:
        f.setdefault('fragment_type', _trade_node_is_fragment(f) or 'fragment')
        f['ai_judged']=False
        f['ai_admission']='RAW_FRAGMENT_RETAINED'
        trade_fragments.append(f)

    # Pipeline already distinguishes exact entity URLs from unresolved relationship rows.
    # Pull those unresolved rows out of companies before Node 4 sees them as company endpoints.
    still_companies=[]
    for c in companies:
        typ=str(c.get('type') or c.get('kind') or '').lower()
        status=str(c.get('entity_status') or '').upper()
        if typ == 'unresolved_trade_node' or status == 'UNRESOLVED_TRADE_NODE':
            c['fragment_type']='unresolved_trade_node'
            c['ai_judged']=False
            c['ai_admission']='UNRESOLVED_TRADE_NODE_RETAINED'
            trade_fragments.append(c)
            if hard_evidence_local(c):
                ai_candidates.append(c)
        else:
            still_companies.append(c)
    companies=still_companies

    # ---- 2. Semantic repair only for ambiguous identity; never for customer value.
    ai_node_judgments=[]
    canonical_map={}
    if ai_candidates:
        try:
            from core.intelligence.local_judge import resolve_trade_fragments_serial
            results=resolve_trade_fragments_serial(ai_candidates,pd_key,state.get('market') or 'USA',progress_hook=_ai_queue_hook(state))
        except Exception as exc:
            results=[{'_ai_success':False,'reason':str(exc)[:200]} for _ in ai_candidates]
        for frag,j in zip(ai_candidates,results):
            j=j if isinstance(j,dict) else {'_ai_success':False,'reason':'invalid model result'}
            frag['trade_node_resolution']=j
            frag.setdefault('evidence',{})['trade_node_resolution']=j
            ai_node_judgments.append({'name':frag.get('name'),'decision':'AI_TRADE_NODE_RESOLUTION',
                                      'resolution':j.get('resolution'),'node_type':j.get('node_type'),
                                      'trade_role':j.get('trade_role'),'canonical_name':j.get('canonical_name'),
                                      'confidence':j.get('confidence'),'ai_success':bool(j.get('_ai_success'))})
            canonical=str(j.get('canonical_name') or '').strip()
            node_type=str(j.get('node_type') or '').lower()
            conf=float(j.get('confidence') or 0)
            if j.get('_ai_success') and str(j.get('resolution')).lower()=='resolved' and canonical and node_type in ('company','brand') and conf>=0.75:
                old=norm(frag.get('name')); new=norm(canonical)
                if old and new and old!=new:
                    canonical_map[old]=canonical
                # Promote to a trade node, retaining the complete original evidence and audit.
                promoted=dict(frag)
                promoted['name']=canonical
                promoted['type']='supplier' if str(j.get('trade_role') or '').lower() in ('supplier','manufacturer','exporter','shipper') else 'buyer'
                promoted['node_role']=promoted['type']
                promoted['entity_status']='RESOLVED'
                promoted['ai_admission']='AI_RESOLVED_TRADE_NODE'
                companies.append(promoted)
                frag['fragment_type']='resolved_into_trade_node'

    # ---- 3. Rebuild graph endpoint names after identity repair; no semantic/customer decision.
    graph_dict=dict(out.get('trade_graph') or {})
    if canonical_map:
        try:
            from core.trade_graph.trade_node import TradeGraph, TradeEdge
            g=TradeGraph()
            for nd in graph_dict.get('nodes') or []:
                old=norm(nd.get('name')); nm=canonical_map.get(old,nd.get('name'))
                role=nd.get('role') or 'importer'
                if old in canonical_map:
                    role='supplier' if any(c.get('name')==nm and c.get('type')=='supplier' for c in companies) else role
                node=__import__('core.trade_graph.trade_node',fromlist=['TradeNode']).TradeNode(nm,role,nd.get('source') or '')
                for ev in nd.get('evidence') or []: node.add_evidence(ev)
                g.add_node(node)
            for ed in graph_dict.get('edges') or []:
                fn=canonical_map.get(norm(ed.get('from_name')),ed.get('from_name'))
                tn=canonical_map.get(norm(ed.get('to_name')),ed.get('to_name'))
                ev=dict(ed.get('evidence') or {})
                ev['identity_repaired']=True
                ev['original_from_name']=ed.get('from_name'); ev['original_to_name']=ed.get('to_name')
                g.add_edge(TradeEdge(fn,ed.get('from_type'),tn,ed.get('to_type'),ed.get('relation'),ev,
                                     ed.get('source'),ed.get('confidence',1.0),ed.get('depth',1),
                                     ed.get('discovered_via',''),ed.get('parent_node',''),ed.get('expansion_path','')))
            graph_dict=g.to_dict()
            state['trade_graph']=graph_dict
        except Exception:
            pass

    # ---- 4. Build explicit auditable observations for Node 4/5; an observation is not yet a verdict.
    observations=[]
    for ed in (graph_dict.get('edges') or []):
        ev=ed.get('evidence') or {}
        observations.append({
            'observation_id':_critical_judgment_fingerprint('NODE3_OBSERVATION',{
                'from':ed.get('from_name'),'to':ed.get('to_name'),'source':ed.get('source'),
                'products':ev.get('products'),'hs':ev.get('hs'),'shipments':ev.get('shipments'),
                'url':ev.get('url'),'relation':ed.get('relation')},state),
            'from_name':ed.get('from_name'),'from_type':ed.get('from_type'),
            'to_name':ed.get('to_name'),'to_type':ed.get('to_type'),
            'relation':ed.get('relation'),'source':ed.get('source') or '',
            'source_url':ev.get('url') or '','products':ev.get('products') or '',
            'hs':ev.get('hs') or [],'shipments':int(ev.get('shipments') or 0),
            'location':ev.get('location') or '','location_url':ev.get('location_url') or '',
            'parent_node':ed.get('parent_node') or ev.get('parent_entity') or '',
            'depth':int(ed.get('depth') or 0),'query':ev.get('query') or '',
            'identity_status':'UNRESOLVED' if ed.get('to_type') in ('fragment','unresolved_trade_node') else 'OBSERVED',
            'raw_evidence':ev,
        })

    fallback_obs, fallback_meta = _node3_direct_fallback_observations(state, companies, observations)
    observations.extend(fallback_obs)
    state['node3_direct_fallback']=fallback_meta
    if fallback_obs:
        for o in fallback_obs:
            state.setdefault('trade_fragments',[]).append({'name':o.get('to_name'),'type':'unresolved_trade_node','fragment_type':'unresolved_trade_node','evidence':o.get('raw_evidence') or {},'ai_admission':'DIRECT_OBSERVATION_FALLBACK_RETAINED'})
    state['trade_observations']=observations
    try:
        db.save_trade_observations(observations, task_id=state.get('task_id',''), product_domain=pd_key)
    except Exception as exc:
        state.setdefault('source_errors',[]).append('trade_observation_persist:'+str(exc)[:160])

    # ---- 5. Per-query telemetry must distinguish executed from merely planned.
    query_stats=[]
    try:
        telemetry=dict(out.get('query_telemetry') or {})
        for rec in ((out.get('collect_gate') or {}).get('query_telemetry') or {}).values():
            telemetry[str(rec.get('query') or '').strip().lower()]=rec
        for rec in (state.get('query_telemetry') or {}).values():
            telemetry[str(rec.get('query') or '').strip().lower()]=rec
        for rec in ((out.get('penetration_stats') or {}).get('search') or []):
            key=str(rec.get('query') or '').strip().lower()
            if not key: continue
            t=telemetry.setdefault(key,{'query':rec.get('query'),'attempted':True,'sources':[],'raw_rows':0,'new_nodes':0})
            t['attempted']=True
            if 'importyeti_web' not in t['sources']: t['sources'].append('importyeti_web')
            t['raw_rows']=max(int(t.get('raw_rows') or 0),int(rec.get('raw') or 0))
            t['new_nodes']=max(int(t.get('new_nodes') or 0),int(rec.get('locked_new') or 0))
        matched_nodes={}; matched_edges={}
        for c in companies:
            q=str((c.get('evidence') or {}).get('query') or c.get('query') or '').strip().lower()
            n=norm(c.get('name'))
            if q and n: matched_nodes.setdefault(q,set()).add(n)
        for ed in (graph_dict.get('edges') or []):
            q=str((ed.get('evidence') or {}).get('query') or '').strip().lower()
            if q: matched_edges[q]=int(matched_edges.get(q,0))+1
        total_nodes=len({norm(c.get('name')) for c in companies if norm(c.get('name'))})
        for q in (pd.get('query_plan') or []):
            qtext=str(q.get('query') or '').strip(); key=qtext.lower(); t=telemetry.get(key) or {}
            attempted=bool(t.get('attempted'))
            raw_count=int(t.get('raw_rows') or 0) if attempted else None
            usable_nodes=len(matched_nodes.get(key,set())) if attempted else None
            usable_edges=int(matched_edges.get(key,0)) if attempted else None
            rec=dict(q)
            rec.update({'result_count':raw_count,'usable_trade_nodes':usable_nodes,'usable_trade_edges':usable_edges,
                        'precision_estimate':round(usable_nodes/max(1,raw_count),3) if attempted and raw_count else None,
                        'recall_contribution':round(usable_nodes/max(1,total_nodes),3) if attempted and total_nodes else None,
                        'measurement_basis':'current_run_observed_execution' if attempted else 'planned_not_executed',
                        'execution_status':'executed' if attempted else 'not_executed','executed_sources':list(t.get('sources') or [])})
            db.save_query_stat(state.get('task_id',''),pd_key,rec); query_stats.append(rec)
    except Exception as e:
        query_stats.append({'query':'(telemetry_error)','note':str(e)[:160],'measurement_basis':'current_run'})

    # ---- 6. Product intelligence feedback uses only observed trade descriptions.
    intel_feedback={}
    try:
        from core.trade_graph import product_intelligence as pi
        prof=dict(state.get('product_profile') or {}); prof.setdefault('hs_candidates',pd.get('hs_candidates') or [])
        intel_feedback=pi.harvest_description_terms(pd_key,prof)
    except Exception:
        pass

    # ---- 7. Canonical Trade Node records: identity status is explicit and evidence is preserved.
    nodes=[]
    for c in companies:
        e=c.setdefault('evidence',{})
        role=c.get('node_role') or ('supplier' if _is_supplier(c) else ('buyer' if e.get('shipments') or e.get('customs') else 'unknown'))
        resolved=bool(e.get('shipments') or e.get('customs') or e.get('trade_evidence') or c.get('country'))
        status='RESOLVED' if resolved else 'UNRESOLVED_TRADE_NODE'
        nodes.append({'node_id':norm(c.get('name')),'entity':c.get('entity') or c.get('name'),'name':c.get('name'),
                      'role':role,'roles':sorted({role}|set(e.get('roles') or [])),'country':c.get('country') or '',
                      'product_domain':pd_key,'product_relation':e.get('products') or '','hs_code':e.get('hs') or [],
                      'shipments':int(e.get('shipments') or 0),'source':c.get('source') or '',
                      'query':e.get('query') or c.get('query') or '','evidence':e,'entity_status':status,
                      'identity_anchor':e.get('url') or c.get('website') or ''})
        try:
            db.upsert_trade_node(c.get('name'),role=role,url=e.get('url') or '',shipments=int(e.get('shipments') or 0),
                                 products=e.get('products') or '',hs=e.get('hs') or [],depth=int(e.get('depth') or 0),
                                 via=e.get('via') or e.get('query') or '',source=c.get('source') or '',country=c.get('country') or '',
                                 entity_status=status,product_domain=pd_key)
        except Exception: pass
    for c in trade_fragments:
        e=c.setdefault('evidence',{})
        nodes.append({'node_id':norm(c.get('name')),'entity':c.get('name'),'name':c.get('name'),'role':'fragment',
                      'roles':['fragment'],'fragment_type':c.get('fragment_type') or c.get('type') or 'fragment',
                      'country':c.get('country') or '','product_domain':pd_key,'product_relation':e.get('products') or '',
                      'hs_code':e.get('hs') or [],'shipments':int(e.get('shipments') or 0),'source':c.get('source') or '',
                      'query':e.get('query') or c.get('query') or '','evidence':e,
                      'entity_status':'TRADE_FRAGMENT','identity_anchor':e.get('url') or c.get('website') or ''})
        try:
            db.upsert_trade_node(c.get('name'),role='fragment',url=e.get('url') or '',shipments=int(e.get('shipments') or 0),
                                 products=e.get('products') or '',hs=e.get('hs') or [],depth=int(e.get('depth') or 0),
                                 via=e.get('via') or e.get('query') or '',source=c.get('source') or '',country=c.get('country') or '',
                                 entity_status='TRADE_FRAGMENT',product_domain=pd_key)
        except Exception: pass

    unresolved=sum(1 for n in nodes if n['entity_status']=='UNRESOLVED_TRADE_NODE')
    funnel=list(state.get('funnel') or [])
    funnel.append({'stage':'CUSTOMS_NODE_COLLECTION','in':len(out.get('raw_companies') or companies),'out':len(nodes),
                   'note':f'贸易节点{len(nodes)}·已解析{len(nodes)-unresolved-len(trade_fragments)}·UNRESOLVED {unresolved}·残片{len(trade_fragments)}·关系观察{len(observations)}·AI身份修复{sum(1 for x in ai_node_judgments if x.get("ai_success"))}·查询计量{len(query_stats)}·情报反哺{len(intel_feedback.get("learned") or {})}词'})
    nr=dict(out.get('node_reports') or {})
    # A node-only result is useful evidence, but it is not yet a healthy handoff
    # to Node 4. Mark it WARN (not FAIL): the central orchestrator can decide whether
    # to re-plan/recollect or continue, while Node 3 itself remains high-recall.
    obs_count=len(observations)
    quality='PASS' if obs_count else ('WARN' if nodes else 'FAIL')
    quality_reason=('direct_trade_observations_available' if obs_count else
                    'trade_nodes_found_but_no_direct_trade_observations' if nodes else
                    'no_trade_nodes_found')
    rep={'verdict':'pass' if quality=='PASS' else ('warn' if quality=='WARN' else 'fail'),
         'role':'TRADE_NODE_COLLECTOR',
         'criteria':[{'name':'贸易节点保留','ok':bool(nodes),'detail':f'{len(nodes)}个'},
                     {'name':'身份锚点优先','ok':True,'detail':'exact entity URL → company；否则 unresolved/fragment'},
                     {'name':'客户判断后置','ok':True,'detail':'Node 3 不做 target fit / customer role'},
                     {'name':'原始观察可回放','ok':bool(obs_count),'detail':f'{obs_count}条'},
                     {'name':'编排器可感知质量','ok':True,'detail':quality_reason}],
         'quality':quality,'quality_reason':quality_reason,
         'notes':f'RAW {len(out.get("raw_companies") or [])} · nodes {len(nodes)} · unresolved {unresolved} · fragments {len(trade_fragments)} · observations {obs_count} · direct_fallback {fallback_meta.get("source") or "-"}/{fallback_meta.get("rows") or 0}'}
    nr=_report(state,'CUSTOMS_NODE_COLLECTION',rep)
    note=(out.get('_note') or '')+f' · 贸易节点 {len(nodes)}（公司 {len(companies)}·残片 {len(trade_fragments)}·UNRESOLVED {unresolved}）·直接关系观察 {len(observations)}·AI身份修复 {sum(1 for x in ai_node_judgments if x.get("ai_success"))}·逐查询计量 {len(query_stats)}'
    collection_layers={'input':len(out.get('raw_companies') or []),'direct_pass':len(companies),'fragment':len(trade_fragments),
                        'ai_pending':len(ai_candidates),'ai_kept':sum(1 for x in ai_node_judgments if x.get('resolution')=='resolved'),
                        'ai_fragment':sum(1 for x in ai_node_judgments if x.get('resolution')!='resolved'),'ai_failed':sum(1 for x in ai_node_judgments if not x.get('ai_success')),
                        'mode':'TRADE_NODE_DISCOVERY'}
    return {**{k:v for k,v in out.items() if k not in ('node_reports','_note')},
            'companies':companies,'trade_nodes':nodes,'trade_entities':nodes,'trade_fragments':trade_fragments,
            'trade_observations':observations,'ai_node_judgments':ai_node_judgments,'collection_layers':collection_layers,'node3_direct_fallback':fallback_meta,
            'query_stats':query_stats,'funnel':funnel,'collection_quality':{'status':quality,'reason':quality_reason,'trade_nodes':len(nodes),'trade_observations':obs_count,'direct_relationship_required':True},'node_reports':nr,'_success':bool(nodes),'_note':note}


# ---------- NODE 4 TRADE_EDGE_BUILD：关系收口建边（内存标准边；正式写库唯一出口是 DATABASE_COMMIT） ----------
def _sync_edges_from_graph(state):
    """把 state['trade_graph'] 的图谱边标准化并入 state['trade_edges']（内存，幂等去重）。
    边的唯一生命周期：图谱边 → 本函数标准化（证据等级初标 + 非 STRONG 降权）
    → EVIDENCE_VERIFY 核验计数/存量对账 → DATABASE_COMMIT 唯一写库。
    任何节点/执行器不得直接写 relationships。"""
    pd_key = (state.get('product_domain') or {}).get('key', '')
    edges_in = (state.get('trade_graph') or {}).get('edges') or []
    existing = list(state.get('trade_edges') or [])
    seen = {(norm(e.get('buyer_entity_id')), norm(e.get('supplier_entity_id')),
             e.get('relation') or 'buyer_to_supplier') for e in existing}
    added = 0; skipped = 0
    for ed in edges_in:
        if not ed.get('from_name') or not ed.get('to_name'):
            skipped += 1; continue
        # 当前伪实体拦截：国家/城市/港口/地址/AI判定fragment端点不进入正式边集；
        # 原始关系仍保留在 trade_graph/trade_fragments 供回放。
        if is_non_company_name(ed.get('from_name')) or is_non_company_name(ed.get('to_name')) \
                or str(ed.get('from_type') or '').lower() == 'fragment' \
                or str(ed.get('to_type') or '').lower() == 'fragment':
            skipped += 1; continue
        e = ed.get('evidence') or {}
        lvl = _evidence_level(e, ed.get('source') or '')
        is_b2s = (ed.get('relation') or 'buyer_to_supplier') == 'buyer_to_supplier'
        buyer = ed.get('from_name') if is_b2s else ed.get('to_name')
        supplier = ed.get('to_name') if is_b2s else ed.get('from_name')
        key = (norm(buyer), norm(supplier), ed.get('relation') or 'buyer_to_supplier')
        if key in seen:
            continue
        seen.add(key)
        conf = float(ed.get('confidence') or 0.8)
        if lvl != 'STRONG':
            conf = min(conf, EVIDENCE_DEMOTE[lvl])  # 降权幂等（min 封顶），不删除
        # 标准边字段：buyer/supplier/product/HS/票数/首末交易日期/来源/证据/置信度
        existing.append({'buyer_entity_id': norm(buyer), 'supplier_entity_id': norm(supplier),
                         'product_id': pd_key,
                         'product_text': str(e.get('products') or e.get('product_text') or '')[:300],
                         'hs_code': e.get('hs') or [], 'shipment_count': int(e.get('shipments') or 0),
                         'first_trade_date': e.get('first_seen') or '',
                         'last_trade_date': e.get('last_seen') or e.get('last_shipment') or '',
                         'source': ed.get('source') or 'trade_graph', 'evidence_id': '',
                         'evidence_level': lvl, 'confidence': conf,
                         'from_name': ed.get('from_name'), 'to_name': ed.get('to_name'),
                         'from_type': ed.get('from_type') or 'buyer',
                         'to_type': ed.get('to_type') or 'supplier',
                         'relation': ed.get('relation') or 'buyer_to_supplier',
                         'depth': int(ed.get('depth') or 1),
                         # 当前可追溯性：谁发现 / 由谁展开 / 单跳路径（多跳由 parent_node 回溯）
                         'discovered_via': ed.get('discovered_via') or ed.get('source') or 'trade_graph',
                         'parent_node': ed.get('parent_node') or ed.get('from_name') or '',
                         'expansion_path': ed.get('expansion_path') or ('%s→%s' % (ed.get('from_name'), ed.get('to_name'))),
                         'evidence': e})
        added += 1
    state['trade_edges'] = existing
    return existing, added, skipped


def n_trade_edge_build(state):
    """建边收口：只建内存标准边并登记端点候选池，不写 relationships。"""
    from core.memory.db import DB
    db = DB()
    fragments=list(state.get('trade_fragments') or [])
    recovered=[]; unresolved=[]; truncated=[]
    if fragments:
        # 分组上限只限制本轮70B深判规模；超限残片必须继续保留为UNRESOLVED，绝不静默丢弃。
        groups={}
        for f in fragments:
            groups.setdefault(_fragment_group_key(f), []).append(f)
        bounded=[]
        group_limit=max(1,int(getattr(settings,'FRAGMENT_GROUP_MAX',50)))
        for key,grp in groups.items():
            bounded.extend(grp[:group_limit])
            for extra in grp[group_limit:]:
                extra.setdefault('evidence',{})['fragment_budget']={'status':'DEFERRED','reason':'fragment_group_budget_exceeded','group_key':key,'group_limit':group_limit,'judgment_origin':'RULE_REUSE'}
                truncated.append(extra)
        fragments=bounded + truncated
        from core.intelligence.local_judge import resolve_trade_fragments_serial
        # Rule-first fragment triage: obvious geo/placeholder fragments never consume a 70B call.
        ai_fragments=[]; rule_unresolved=[]
        for f in fragments:
            typ=str(f.get('type') or f.get('kind') or f.get('fragment_type') or '').lower()
            e=f.get('evidence') or {}
            useful=bool(e.get('products') or e.get('hs') or e.get('shipments') or e.get('trade_evidence') or e.get('supplier_relation') or e.get('customer_relation') or e.get('exporter') or e.get('importer'))
            companyish=bool(re.search(r'\b(inc|llc|ltd|corp|co|company|group|industries|enterprise|trading|trade|manufacturer|supplier|exporter|importer|factory)\b', str(f.get('name') or ''), re.I))
            name_parts=[x for x in re.split(r'\s+', str(f.get('name') or '').strip()) if x]
            # ImportYeti location fragments often inherit the parent shipment's product/HS
            # fields. Those fields do not make a place name into a company. If the source
            # already labels it as a fragment and there is no corporate marker, keep it as
            # unresolved instead of spending one 70B request on a likely location.
            fragment_geo_like = typ == 'fragment' and not companyish and len(name_parts) <= 4 and not (e.get('url') or e.get('email') or e.get('phone'))
            if (typ in ('location','country','government','person','logistics') and not useful and not companyish) or fragment_geo_like:
                reason='rule_geo_or_noncompany_without_trade_fields' if not fragment_geo_like else 'rule_fragment_without_company_marker'
                f.setdefault('evidence',{})['fragment_resolution']={'_ai_success':False,'resolution':'unresolved','node_type':typ or 'fragment','reason':reason,'confidence':0.98,'judgment_origin':'RULE_REUSE'}
                rule_unresolved.append(f)
            else:
                ai_fragments.append(f)
        results=resolve_trade_fragments_serial(ai_fragments,(state.get('product_domain') or {}).get('key',''),state.get('market') or 'USA',progress_hook=_ai_queue_hook(state)) if ai_fragments else []
        result_map={id(f):j for f,j in zip(ai_fragments,results)}
        for f in fragments:
            j=result_map.get(id(f)) or (f.get('evidence') or {}).get('fragment_resolution') or {'_ai_success':False,'resolution':'unresolved','node_type':'unknown','reason':'模型未返回解析','confidence':0}
            f.setdefault('evidence',{})['fragment_resolution']=j; f['fragment_resolution']=j
            if str(j.get('resolution') or '').lower()=='resolved' and str(j.get('node_type') or '').lower() in ('company','brand') and j.get('canonical_name'):
                base=dict(f); base['name']=j.get('canonical_name'); base['type']='supplier' if str(j.get('trade_role') or '').lower() in ('supplier','manufacturer','exporter','shipper') else f.get('type') or 'buyer'
                e=base.setdefault('evidence',{})
                if j.get('recovered_products') and not e.get('products'): e['products']=j['recovered_products']
                if j.get('recovered_hs') and not e.get('hs'): e['hs']=j['recovered_hs']
                e['fragment_recovered_from']=f.get('name'); recovered.append(base)
            else: unresolved.append(f)
    companies=list(state.get('companies') or []); by_name={norm(c.get('name')):c for c in companies if norm(c.get('name'))}
    for c in recovered:
        k=norm(c.get('name'))
        if not k: continue
        if k in by_name:
            eo=by_name[k].setdefault('evidence',{}); en=c.get('evidence') or {}
            eo['shipments']=max(int(eo.get('shipments') or 0),int(en.get('shipments') or 0))
            for key in ('products','hs','url','country'):
                if not eo.get(key) and en.get(key): eo[key]=en[key]
        else: companies.append(c); by_name[k]=c
    state['companies']=companies; state['trade_fragments']=unresolved

    # 先同步图谱标准边，再计算 candidate_trade_facts。不能在初始化前引用 trade_edges。
    trade_edges, added, skipped = _sync_edges_from_graph(state)
    for _fact in trade_edges:
        _fact['construction_status']='COMPLETE' if _fact.get('from_name') and _fact.get('to_name') and (_fact.get('product_text') or _fact.get('hs_code')) else 'PARTIAL'
    state['candidate_trade_facts']=list(trade_edges)
    state['trade_fact_construction']={'recovered':len(recovered),'unresolved':len(unresolved),
                                      'grouped_fragments':len(fragments),'deep_judged_fragments':len(fragments)-len(truncated),
                                      'budget_preserved_unresolved':len(truncated),
                                      'status':'COMPLETE' if trade_edges else 'UNRESOLVED'}
    # 图谱完整性：边的两个端点都必须登记为 Trade Node 候选池（物流/货代按 logistics 角色
    # 停放进图谱库，不删除——它是验证参照与收割路径）。候选池登记 ≠ 正式关系写库。
    for ed in ((state.get('trade_graph') or {}).get('edges') or []):
        e = ed.get('evidence') or {}
        for nm, tp in ((ed.get('from_name'), ed.get('from_type') or 'buyer'),
                       (ed.get('to_name'), ed.get('to_type') or 'supplier')):
            try:
                role = 'logistics' if LOGISTICS_RE.search(str(nm or '')) else tp
                db.upsert_trade_node(nm, role=role, url=e.get('url') or '',
                                     shipments=int(e.get('shipments') or 0), products=e.get('products') or '',
                                     hs=e.get('hs') or [], depth=int(ed.get('depth') or 1),
                                     via='edge_endpoint', source=ed.get('source') or 'trade_graph',
                                     entity_status='RESOLVED' if e.get('shipments') else 'UNRESOLVED_TRADE_NODE')
            except Exception:
                pass
    rep = experts.review('TRADE_EDGE_BUILD', f'建边 {len(trade_edges)} 条（内存标准边，幂等去重，新增 {added}）· 残缺跳过 {skipped}',
                         [('边携带标准字段', True, 'buyer_entity_id/supplier_entity_id/product/HS/票数/日期/source/evidence_level/confidence'),
                          ('证据等级已初步标注', True, 'STRONG/MEDIUM/WEAK/UNVERIFIED（非 STRONG 已降权）'),
                          ('双向关系齐备', True, 'buyer_to_supplier + supplier_to_customer'),
                          ('本节点不写库', True, '正式写库唯一出口 DATABASE_COMMIT')],
                         critical={'边携带标准字段'})
    return {'edges_built': len(trade_edges), 'trade_edges': trade_edges, 'candidate_trade_facts': list(state.get('candidate_trade_facts') or []),
            'trade_fact_construction': dict(state.get('trade_fact_construction') or {}),
            'node_reports': _report(state, 'TRADE_EDGE_BUILD', rep),
            '_success': True,
            '_note': f'贸易关系建立：标准边 {len(trade_edges)} 条（内存·含 evidence_level/票数/HS/产品/首末见·残片超限保留为UNRESOLVED·待 EVIDENCE_VERIFY 核验、DATABASE_COMMIT 统一写库）'}


# ---------- NODE 5 EVIDENCE_VERIFY：证据四级核验（STRONG/MEDIUM/WEAK/UNVERIFIED），降权不删除 ----------
def n_evidence_verify(state):
    """唯一判定函数 evidence_level（trade_node.py）。
    1) 内存边（state['trade_edges']）逐条复核等级与降权（幂等 min 封顶）；
    2) 存量 DB 对账：本任务此前已由其他通道（expand/历史任务）落库的边按同一规则补判，
       保证数据库里不存在未分级的正式边。"""
    from core.memory.db import DB
    db = DB(); task_id = state.get('task_id', '')
    counts = {'STRONG': 0, 'MEDIUM': 0, 'WEAK': 0, 'UNVERIFIED': 0}
    samples = []
    trade_edges = list(state.get('trade_edges') or [])
    from core.intelligence.local_judge import judge_edges_serial
    edge_ai=[]; uncertain_edges=[]; edge_results=[]
    for ed in trade_edges:
        prior=(ed.get('evidence') or {}).get('ai_evidence_judgment') or ed.get('ai_evidence_judgment') or _shared_get(state,'EVIDENCE_VERIFY',ed)
        if isinstance(prior,dict) and _ai_ok(prior):
            ed.setdefault('evidence',{})['ai_evidence_judgment']=dict(prior)
            ed['ai_evidence_judgment']=dict(prior)
            ed['_evidence_judgment_origin']='REUSED_JUDGMENT'
            continue
        if _edge_needs_ai(ed):
            uncertain_edges.append(ed)
        else:
            e=ed.get('evidence') or {}; grade=_evidence_level(e, ed.get('source') or '')
            prior={'_ai_success':False,'recommended_level':grade,'trade_support':'strong' if grade=='STRONG' else 'medium',
                   'product_relevance':'unknown','relation_valid':'yes','reason':'确定性证据策略已足以支持当前等级','confidence':0.95 if grade=='STRONG' else 0.8,
                   'judgment_origin':'RULE_REUSE'}
            e['ai_evidence_judgment']=prior; ed['ai_evidence_judgment']=prior; ed['_evidence_judgment_origin']='RULE_REUSE'
            _shared_put(state,'EVIDENCE_VERIFY',ed,prior,'RULE_REUSE')
    edge_results=judge_edges_serial(uncertain_edges,(state.get('product_domain') or {}).get('key',''),progress_hook=_ai_queue_hook(state)) if uncertain_edges else []
    result_iter=iter(edge_results)
    for ed in trade_edges:
        e=ed.get('evidence') or {}
        aj=ed.get('ai_evidence_judgment')
        if not isinstance(aj,dict) or not (aj.get('recommended_level') or aj.get('trade_support')):
            try: aj=next(result_iter)
            except StopIteration: aj={'_ai_success':False,'reason':'no semantic judgment'}
        e=ed.get('evidence') or {}; aj=aj or {'_ai_success':False,'reason':'no batch judgment'}
        if '_ai_success' not in aj and aj.get('recommended_level'): aj['_ai_success']=True
        e['ai_evidence_judgment']=aj; ed['ai_evidence_judgment']=aj
        if _ai_ok(aj):
            ed['_evidence_judgment_origin']='AI_DEEP'
            _shared_put(state,'EVIDENCE_VERIFY',ed,aj,'AI_DEEP')
        edge_ai.append({'from':ed.get('from_name'),'to':ed.get('to_name'),'recommended_level':aj.get('recommended_level'),'trade_support':aj.get('trade_support'),'product_relevance':aj.get('product_relevance'),'ai_success':bool(aj.get('_ai_success'))})
        grade = _evidence_level(e, ed.get('source') or '')
        # “有提单”只证明贸易发生；如果70B判断不能支持强产品/关系结论，则降级，不删除。
        rec = str(aj.get('recommended_level') or '').upper()
        if rec in EVIDENCE_LEVELS:
            rank={'UNVERIFIED':0,'WEAK':1,'MEDIUM':2,'STRONG':3}
            if rank.get(rec,3) < rank.get(grade,3): grade=rec
        ed['evidence_level'] = grade
        counts[grade] += 1
        if grade != 'STRONG':
            ed['confidence'] = min(float(ed.get('confidence') or 0.8), EVIDENCE_DEMOTE[grade])
            e['grade'] = grade
            if len(samples) < 5:
                samples.append(f"{ed.get('from_name')}→{ed.get('to_name')}({grade})")
    # 存量对账：本任务已落库的边（旧通道遗留/单独执行产生）按同一判定函数补判降权
    try:
        rels = db.list_relationships(task_id=task_id, limit=2000)
    except Exception:
        rels = []
    for r in rels:
        try:
            e = json.loads(r.get('evidence') or '{}')
        except Exception:
            e = {}
        grade = _evidence_level(e, r.get('source') or '')
        if not trade_edges:
            counts[grade] += 1  # 无内存边（单独执行/旧任务）时以存量为准
            if grade in ('WEAK', 'UNVERIFIED') and len(samples) < 5:
                samples.append(f"{r.get('from_name')}→{r.get('to_name')}({grade})")
        if grade != 'STRONG':
            try:
                e['grade'] = grade
                with db.c() as x:
                    x.execute('UPDATE relationships SET confidence=MIN(confidence,?), evidence_level=?, evidence=? WHERE id=?',
                              (EVIDENCE_DEMOTE[grade], grade, json.dumps(e, ensure_ascii=False)[:1800], r.get('id')))
            except Exception:
                pass
        else:
            try:
                with db.c() as x:
                    x.execute("UPDATE relationships SET evidence_level='STRONG' WHERE id=? AND COALESCE(evidence_level,'')=''", (r.get('id'),))
            except Exception:
                pass
    # 节点侧只标注不淘汰：IY 验证/交叉验证计数
    companies = state.get('companies') or []
    try:
        from core.trade_graph import iy_network as iyn
        companies = iyn.tag_verification(companies)
    except Exception:
        pass
    # 当前：evidence completion requests. Only critical missing fields create a route.
    verification_gaps=[]
    for ed in trade_edges:
        e=ed.get('evidence') or {}
        missing=[]
        if not ed.get('from_name') or not ed.get('to_name'): missing.append('trade_parties')
        if not (e.get('products') or ed.get('product_text') or e.get('hs') or ed.get('hs_code')): missing.append('product_evidence')
        if not (e.get('shipments') or e.get('customs') or e.get('trade_evidence') or e.get('bill_of_lading')): missing.append('trade_evidence')
        if missing:
            verification_gaps.append({'fact_id':hashlib.sha1(json.dumps([ed.get('from_name'),ed.get('to_name'),ed.get('relation')],ensure_ascii=False).encode()).hexdigest()[:16],
                                      'from_name':ed.get('from_name'),'to_name':ed.get('to_name'),'missing_fields':missing,
                                      'search_dimensions':(['product_description','hs_code','company_product'] if 'product_evidence' in missing else [])+
                                                          (['shipment','bill_of_lading','customs_record'] if 'trade_evidence' in missing else []),
                                      'attempted_sources':[ed.get('source') or 'trade_graph'], 'priority':'HIGH' if 'product_evidence' in missing else 'MEDIUM'})
    verification_gaps=verification_gaps[:int(getattr(settings,'EVIDENCE_COMPLETION_MAX',20))]
    # Prevent the same unresolved gap from creating an endless 5→3/4→5 loop.
    gap_fp=hashlib.sha1(json.dumps([(g.get('from_name'),g.get('to_name'),tuple(g.get('missing_fields') or [])) for g in verification_gaps],sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:16]
    prev_gap_fp=str((state.get('route_state') or {}).get('last_gap_fingerprint') or '')
    gap_round=int((state.get('route_state') or {}).get('gap_round') or 0)
    route='ENTITY_RESOLUTION'
    if verification_gaps and gap_fp != prev_gap_fp and gap_round < 2:
        # If Node 2 already contains the requested dimensions, search directly in Node 3;
        # otherwise update strategy first. Pure structure gaps go back to Node 4.
        dims={d for g in verification_gaps for d in g.get('search_dimensions',[])}
        strategy_dims=set()
        for q in ((state.get('strategy') or {}).get('query_plan') or []):
            strategy_dims.update(str(q.get('query_type') or '').lower().split(','))
            strategy_dims.update(str(q.get('query') or '').lower().split())
        if any(d in ' '.join(strategy_dims) for d in dims): route='NODE_3_SEARCH'
        elif dims: route='NODE_2_SEARCH'
        else: route='NODE_4_RECONSTRUCT'
    state['verification_gaps']=verification_gaps
    state['verified_trade_facts']=[dict(e) for e in trade_edges if str(e.get('evidence_level') or '').upper() in ('STRONG','MEDIUM','WEAK')]
    state['evidence_requests']=verification_gaps
    state['route_state']=dict(state.get('route_state') or {}, evidence_route=route, last_gap_fingerprint=gap_fp, gap_round=(gap_round+1 if verification_gaps and gap_fp != prev_gap_fp else gap_round), verification_converged=bool(verification_gaps and gap_fp==prev_gap_fp))

    # 当前共享状态交接: evidence verification becomes a reusable fact on
    # both edge endpoints. Downstream nodes should consume this summary instead of
    # reopening every edge/entity question from scratch.
    endpoint_summary = {}
    rank = {'UNVERIFIED':0, 'WEAK':1, 'MEDIUM':2, 'STRONG':3}
    for ed in trade_edges:
        lvl = str(ed.get('evidence_level') or 'UNVERIFIED').upper()
        for nm in (ed.get('from_name'), ed.get('to_name')):
            k = norm(nm)
            if not k: continue
            z = endpoint_summary.setdefault(k, {'best_level':'UNVERIFIED','edge_count':0,'strong_edges':0,'medium_edges':0,'weak_edges':0,'max_confidence':0.0})
            z['edge_count'] += 1
            z['max_confidence'] = max(float(z.get('max_confidence') or 0), float(ed.get('confidence') or 0))
            key = lvl.lower() + '_edges'
            if key in z: z[key] += 1
            if rank.get(lvl,0) > rank.get(z['best_level'],0): z['best_level'] = lvl
    for c in companies:
        sm = endpoint_summary.get(norm(c.get('name')))
        if sm:
            c['evidence_summary'] = dict(sm)
            c.setdefault('evidence', {})['evidence_summary'] = dict(sm)
    state['entity_evidence_summary'] = endpoint_summary
    strong, medium, weak, unverified = counts['STRONG'], counts['MEDIUM'], counts['WEAK'], counts['UNVERIFIED']
    # 当前：本节点职责 = 给关系分级，不是决定关系是否存在。
    # 关系存在与否由真实贸易关系决定；证据等级只影响 confidence/development_status/resource_priority。
    # 全部边为弱证据 ⇒ 全部降权保留进发现池，节点照常成功——绝不因弱证据阻断主链。
    graded_total = strong + medium + weak + unverified
    ok = True  # 分级完成即成功（产物契约由 Contract Registry 硬校验 evidence_verify 非空）
    rep = experts.review('EVIDENCE_VERIFY',
                         ('本轮无贸易边：没有待核验 trade fact，正常进入实体解析/扩张。' if not trade_edges and not rels else
                          f'证据四级：STRONG {strong} · MEDIUM {medium} · WEAK {weak} · UNVERIFIED {unverified}') +
                         (f'（弱样本：{"；".join(samples)}）' if samples else ''),
                         [('全量边完成四级分级', graded_total > 0 or not (trade_edges or rels),
                           ('0/0：本轮无贸易边，正常无核验对象' if not trade_edges and not rels else f'{graded_total}/{len(trade_edges) or len(rels)} 已分级')),
                          ('分级不判存亡', True, '证据等级只决定 confidence/优先级，弱证据不阻断主链'),
                          ('弱证据降权保留不删除', True, 'WEAK→0.3 UNVERIFIED→0.1 留待补证据'),
                          ('判定函数唯一', True, 'trade_node.evidence_level，建边/核验/入库同一规则')])
    return {'companies': companies, 'trade_edges': trade_edges,
            'verified_trade_facts': list(state.get('verified_trade_facts') or []),
            'verification_gaps': list(state.get('verification_gaps') or []),
            'evidence_requests': list(state.get('evidence_requests') or []),
            'evidence_verify': {'STRONG': strong, 'MEDIUM': medium, 'WEAK': weak, 'UNVERIFIED': unverified,
                                'strong': strong, 'medium': medium, 'weak': weak, 'unverified': unverified,
                                'samples': samples, 'ai_judgments': edge_ai, 'verification_gaps': len(verification_gaps), 'route': route},
            'node_reports': _report(state, 'EVIDENCE_VERIFY', rep), '_success': ok,
            '_note': f'证据四级：STRONG {strong}（确认池）· MEDIUM {medium} · WEAK {weak} · UNVERIFIED {unverified}（降权进发现池，不删节点）'}


# ---------- NODE 6 ENTITY_RESOLUTION：贸易节点 → 企业实体（唯一实体，多角色） ----------
def n_entity_resolution(state):
    companies = list(state.get('companies') or [])
    # 当前：实体类型由本地DeepSeek先判断，规则仅做第二道安全兜底。
    companies, entity_fragments, entity_ai_judgments = _ai_entity_judgments(companies, state)
    if entity_fragments:
        state['trade_fragments'] = list(state.get('trade_fragments') or []) + entity_fragments
    # 0) 当前伪实体兜底拦截：国家/城市/港口/地址绝不进入公司实体集（采集层已拦，此处双保险）
    non_entity = [c for c in companies if is_non_company_name(c.get('name'))]
    if non_entity:
        companies = [c for c in companies if not is_non_company_name(c.get('name'))]
    # 1) 保守实体解析：法律后缀归一键完全相同才合并；记录 SAME_AS 别名备查
    groups = {}
    for c in companies:
        k = entity_key(c.get('name')) or norm(c.get('name'))
        if not k:
            continue
        if k not in groups:
            groups[k] = c
        else:
            w = groups[k]  # 票数高者为主记录，其余并入别名
            e_w, e_c = w.setdefault('evidence', {}), c.get('evidence') or {}
            if int(e_c.get('shipments') or 0) > int(e_w.get('shipments') or 0):
                e_c.setdefault('aliases', []).append(w.get('name'))
                c['evidence'] = e_c
                groups[k] = c
                w = c
            else:
                e_w.setdefault('aliases', [])
                if c.get('name') not in e_w['aliases']:
                    e_w['aliases'].append(c.get('name'))
            e2 = groups[k]['evidence']
            e2['shipments'] = max(int(e2.get('shipments') or 0), int(e_c.get('shipments') or 0))
            e2['same_as_merged'] = True
    merged = list(groups.values())
    resolved = len(companies) - len(merged)
    # 当前：标准化完成后做目标客户适配性；不承担最终Customer/Supplier角色。
    from core.intelligence.local_judge import target_fit_serial
    target_inputs=[]; target_reused=0; target_rule=0; non_target_rule=0
    for c in merged:
        c['product_profile']=state.get('product_profile') or {}
        prior=c.get('target_fit_judgment') or _shared_get(state,'TARGET_FIT',c)
        if isinstance(prior,dict) and str(prior.get('target_fit') or '').upper() in ('TARGET_RELEVANT','NON_TARGET','UNCERTAIN') and (_ai_ok(prior) or prior.get('judgment_origin')):
            c['target_fit_judgment']=dict(prior); target_reused+=1
            continue
        rule_j=_target_fit_rule_gate(c,state)
        if rule_j:
            c['target_fit_judgment']={**rule_j,'_ai_success':False,'confidence':0.97}
            c.setdefault('evidence',{})['target_fit_judgment']=c['target_fit_judgment']
            _shared_put(state,'TARGET_FIT',c,c['target_fit_judgment'],rule_j['origin'])
            if rule_j['target_fit']=='TARGET_RELEVANT': target_rule+=1
            else: non_target_rule+=1
        else:
            target_inputs.append(c)
    state['entity_resolution_ai_stats']={'input':len(companies or []),'ai_judged':0,'reused':0,'rule_reused':0,
                                          'fragments':len(entity_fragments),'target_fit_ai_judged':len(target_inputs),
                                          'target_fit_reused':target_reused,'target_fit_rule_target':target_rule,
                                          'target_fit_rule_non_target':non_target_rule}
    # Persist the plan before the first model call so the UI can show exactly why
    # the node is running and how many records actually need DeepSeek.
    try:
        cb=state.get('_persist_runtime')
        if cb: cb(state)
    except Exception:
        pass
    results=target_fit_serial(target_inputs,(state.get('product_domain') or {}).get('key',''),state.get('market') or 'USA',progress_hook=_ai_queue_hook(state)) if target_inputs else []
    for c,j in zip(target_inputs,results):
        j=j or {'_ai_success':False,'target_fit':'UNCERTAIN','reason':'模型未返回目标适配判断','confidence':0}
        if '_ai_success' not in j and j.get('target_fit'): j['_ai_success']=True
        c['target_fit_judgment']=j; c.setdefault('evidence',{})['target_fit_judgment']=j; _shared_put(state,'TARGET_FIT',c,j,'AI_DEEP')
        # target fit is a separate semantic layer; keep it independent from final role.
        if not c.get('target_fit'):
            tf_cached=_shared_get(state,'TARGET_FIT',c)
            if isinstance(tf_cached,dict): c['target_fit']=tf_cached.get('target_fit')

    for c in merged:
        j=c.get('target_fit_judgment') or {}; c['target_fit']=str(j.get('target_fit') or 'UNCERTAIN').upper(); c.setdefault('evidence',{})['target_fit']=c['target_fit']
    # 2) 角色归并（当前统一角色词表）：同一实体既是买家又是供应商 →
    # CUSTOMER_AND_SUPPLIER（一个实体多个角色，不删任一身份）；无法判定 → UNKNOWN。
    # 角色必须在合并前的全部原始记录上收集——同一实体的 buyer/supplier 两条记录
    # 在第1步就被合并成一条，事后看只剩一个身份。
    def _base_role(c):
        ai_role=str((c.get('entity_ai_judgment') or {}).get('role') or '').upper()
        if ai_role in ('CUSTOMER','SUPPLIER','CUSTOMER_AND_SUPPLIER','NEITHER','UNKNOWN'):
            return ai_role
        if _is_supplier(c):
            return 'SUPPLIER'
        e = c.get('evidence') or {}
        if e.get('shipments') or e.get('customs') or c.get('type') in ('importer', 'customer'):
            return 'CUSTOMER'
        return 'UNKNOWN'
    roles = {}
    for c in companies:
        k = entity_key(c.get('name')) or norm(c.get('name'))
        if k:
            roles.setdefault(k, set()).add(_base_role(c))
    src_count = {}
    for c in companies:
        k = norm(c.get('name'))
        src_count[k] = src_count.get(k, 0) + 1
    company_entities = []
    for c in merged:
        rs = roles.get(entity_key(c.get('name')) or norm(c.get('name'))) or {'UNKNOWN'}
        rs = rs - {'UNKNOWN'} if len(rs) > 1 else rs
        role = 'CUSTOMER_AND_SUPPLIER' if len(rs) > 1 else next(iter(rs))
        e = c.get('evidence') or {}
        if len(rs) > 1:
            c.setdefault('evidence', {})['roles'] = sorted(rs)
        company_entities.append({
            'entity_id': norm(c.get('name')), 'company_id': norm(c.get('name')),
            'legal_name': c.get('name'), 'name': c.get('name'),
            'aliases': list(e.get('aliases') or []), 'trade_names': [c.get('name')] + list(e.get('aliases') or []),
            'country': c.get('country') or '', 'address': c.get('address') or e.get('address') or '',
            'website': c.get('website') or e.get('url') or '',
            'role': role, 'roles': sorted(rs),
            'evidence': e, 'trade_edges': int(e.get('shipments') or 0),
            'ai_judgment': c.get('entity_ai_judgment') or {},
            'target_fit': c.get('target_fit') or 'UNCERTAIN',
            'target_fit_judgment': c.get('target_fit_judgment') or {},
            'source_count': src_count.get(norm(c.get('name')), 1)})
    # 3) 执行器复用：简单净化 + 增量识别（含物流停放节点池——TRADE_NODE_ONLY 只进图谱库）
    state2 = dict(state); state2['companies'] = merged
    out = n_clean_verify(state2)
    nr = dict(out.get('node_reports') or {})
    dual = sum(1 for e2 in company_entities if e2['role'] == 'CUSTOMER_AND_SUPPLIER')
    unknown = sum(1 for e2 in company_entities if e2['role'] == 'UNKNOWN')
    note = f'实体解析 {len(companies)}→{len(merged)}（后缀归一合并 {resolved} · 双角色 {dual} · UNKNOWN {unknown}）· ' + (out.get('_note') or '')
    expansion_gate=_build_expansion_gate(state, company_entities)
    # Persist the gate as a first-class handoff so Node 7 cannot accidentally
    # infer eligibility from raw trade evidence.
    state['expansion_gate']=expansion_gate
    return {**{k: v for k, v in out.items() if k not in ('node_reports', '_note')},
            'company_entities': company_entities, 'entity_resolved': resolved,
            'entity_resolution': {'input': len(companies) + len(non_entity), 'merged': len(merged),
                                  'resolved': resolved, 'dual': dual, 'unknown': unknown,
                                  'non_entity_filtered': len(non_entity),
                                  'ai_fragments': len(entity_fragments),
                                  'ai_judged': len(entity_ai_judgments),
                                  'target_fit_ai_judged': len(target_inputs), 'target_fit_reused': target_reused,
                                  'target_fit_rule_target': target_rule, 'target_fit_rule_non_target': non_target_rule,
                                  'target_fit_counts': {k:sum(1 for c in merged if c.get('target_fit')==k) for k in ('TARGET_RELEVANT','NON_TARGET','UNCERTAIN')},
                                  'expansion_gate': expansion_gate,
                                  'entities': len(company_entities)},
            'expansion_gate': expansion_gate,
            'node_reports': nr, '_success': out.get('_success', True), '_note': note}


# ---------- EXPANSION GATE：Node 7 的强前置条件 ----------
def _build_expansion_gate(state, companies):
    """Freeze the business condition before any network expansion call.

    Node 7 may only consume entities whose target-fit judgment is already
    resolved. Missing/UNCERTAIN judgments are never silently treated as
    expandable. This is a business precondition, not a new node.
    """
    rows=[]; pending=[]; eligible=[]; blocked=[]
    for c in companies or []:
        name=c.get('name') or c.get('legal_name') or ''
        fit=str(c.get('target_fit') or (c.get('target_fit_judgment') or {}).get('target_fit') or '').upper()
        if fit not in ('TARGET_RELEVANT','NON_TARGET','UNCERTAIN'):
            pending.append(name); continue
        if fit == 'TARGET_RELEVANT':
            eligible.append(name)
        else:
            blocked.append(name)
        rows.append({'name':name,'target_fit':fit,'expansion_eligible':fit=='TARGET_RELEVANT'})
    gate={
        'status':'READY' if not pending else 'BLOCKED_PENDING_TARGET_FIT',
        'eligible_count':len(eligible),'blocked_count':len(blocked),'pending_count':len(pending),
        'eligible_entities':eligible,'blocked_entities':blocked,'pending_entities':pending,
        'judgment_required_before_expansion':bool(pending),
        'rows':rows,
        'rule':'Node7 only expands TARGET_RELEVANT; NON_TARGET/UNCERTAIN never seed expansion; UNCERTAIN is a resolved judgment but not an expansion seed',
        'version':'v46.0'
    }
    return gate

# ---------- NODE 7 GRAPH_EXPANSION：递归多层双向扩张（图谱优先，边际收益动态停止） ----------
def n_graph_expansion(state):
    """Bounded bidirectional expansion.

    Level 1 is mandatory, Level 2 is default, Level 3 is conditional. Expansion
    never directly performs downstream routing; it records new facts/entities and
    the Orchestrator decides whether to re-enter 4/5/6.
    """
    policy=((state.get('strategy') or {}).get('expansion_policy') or {})
    max_depth=min(int(policy.get('max_depth') or 3), int(getattr(settings,'MAX_EXPANSION_ROUNDS',3)))
    round_no=int(state.get('expansion_rounds') or 0)+1
    state['expansion_rounds']=round_no
    notes=[]; depths=[]; reports={}; cur=dict(state); step_errors=0; step_runs=0
    prev_total=len(cur.get('companies') or [])
    prev_target=sum(1 for c in (cur.get('companies') or []) if str(c.get('target_fit') or '').upper()=='TARGET_RELEVANT')
    prev_edges=len(cur.get('trade_edges') or [])
    # Hard precondition: resolve Target Fit BEFORE Node 7. Never infer eligibility
    # from STRONG trade evidence and never expand newly discovered entities in the
    # same invocation; new entities must return to Node 6 first.
    gate=_build_expansion_gate(cur, cur.get('company_entities') or cur.get('companies') or [])
    cur['expansion_gate']=gate
    if gate.get('pending_count'):
        cur['route_state']=dict(cur.get('route_state') or {})
        cur['route_state']['expansion_precondition']='TARGET_FIT_REQUIRED'
        cur['route_state']['expansion_new_entities']=False
        cur['route_state']['expansion_new_trade_facts']=False
        cur['graph_expansion']={'depths':[],'stopped_by':'target_fit_pending','max_depth':max_depth,'round':round_no,
                                'eligible_count':gate.get('eligible_count',0),'pending_count':gate.get('pending_count',0)}
        cur['_success']=False
        cur['_note']=f'扩张前置条件未满足：{gate.get("pending_count")} 个实体尚未完成 Target Fit，必须先回到 Node 6'
        return cur
    frozen_names={norm(x) for x in gate.get('eligible_entities') or []}
    frozen_seed_pool=[c for c in (cur.get('companies') or []) if norm(c.get('name')) in frozen_names]
    # Target Fit is necessary but not sufficient: a seed must also have an executable
    # expansion handle (existing IY URL/cache or local customs relation). Otherwise
    # Node 7 must finish as a normal no-source state instead of throwing a runtime error.
    def _expandable(c):
        e=c.get('evidence') or {}
        url=str(e.get('url') or c.get('website') or '')
        has_iyn=False
        try:
            from core.trade_graph import iy_network as _iyn
            k=_iyn.get_node(norm(c.get('name')), 'company') or _iyn.get_node(norm(c.get('name')), 'supplier')
            has_iyn=bool((k or {}).get('url'))
        except Exception:
            pass
        has_local_rel=bool(e.get('supplier_count') or e.get('supplier_relation') or e.get('customer_relation') or e.get('trade_evidence'))
        return bool(url or has_iyn or has_local_rel)
    expandable_seed_pool=[c for c in frozen_seed_pool if _expandable(c)]
    gate['expandable_count']=len(expandable_seed_pool)
    gate['non_expandable_count']=max(0,len(frozen_seed_pool)-len(expandable_seed_pool))
    gate['expandable_entities']=[c.get('name') for c in expandable_seed_pool]
    if frozen_seed_pool and not expandable_seed_pool:
        cur['graph_expansion']={'depths':[],'stopped_by':'no_expandable_source','max_depth':max_depth,'round':round_no,
                                'eligible_count':gate.get('eligible_count',0),'expandable_count':0,'pending_count':0,
                                'non_expandable_count':gate.get('non_expandable_count',0)}
        cur['route_state']=dict(cur.get('route_state') or {})
        cur['route_state']['expansion_new_entities']=False; cur['route_state']['expansion_new_trade_facts']=False
        cur['route_state']['expansion_precondition']='NO_EXPANDABLE_SOURCE'
        cur['_success']=True
        cur['_note']=f'Target Fit 已完成，但 {len(frozen_seed_pool)} 个目标实体均无可执行扩张入口，正常跳过网络扩张'
        return cur
    if not frozen_seed_pool:
        cur['graph_expansion']={'depths':[],'stopped_by':'no_target_eligible_seeds','max_depth':max_depth,'round':round_no,
                                'eligible_count':0,'pending_count':0}
        cur['route_state']=dict(cur.get('route_state') or {})
        cur['route_state']['expansion_new_entities']=False; cur['route_state']['expansion_new_trade_facts']=False
        cur['_success']=True
        cur['_note']='扩张前置条件已满足，但没有 TARGET_RELEVANT 种子，正常跳过网络扩张'
        return cur
    # 供应商/客户资产都属于当前黑板；扩张子步骤只能追加/合并，不能覆盖上游候选。
    state_supplier_carry={'suppliers':list(cur.get('suppliers') or []),'supplier_new':list(cur.get('supplier_new') or [])}
    global_budget=int(policy.get('global_new_entity_budget') or getattr(settings,'EXPAND_MAX_NEW',40))
    new_total_budget=0
    stopped_by='max_depth'
    new_trade_facts=[]; all_new_entities=[]
    for depth in range(1,max_depth+1):
        cur['_expansion_depth']=depth
        # Seeds are frozen at Node 7 entry AFTER Target Fit. Newly discovered
        # entities are deliberately excluded until the orchestrator routes them
        # through Node 6 and resolves their own target-fit condition.
        seeds=sorted(expandable_seed_pool, key=lambda c:int((c.get('evidence') or {}).get('shipments') or 0), reverse=True)
        seeds=seeds[:int(policy.get('per_seed_budget') or 15)]
        # 初始搜索也可能锁定 supplier 节点；这些节点不能伪装成 buyer 去跑 buyer→supplier，
        # 但必须进入同一轮的 supplier→customer 反查路径。
        supplier_seeds=[c for c in seeds if _is_supplier(c)]
        if supplier_seeds:
            have_supplier={norm(x.get('name')) for x in (cur.get('supplier_new') or [])}
            cur['supplier_seeds']=[x for x in supplier_seeds if norm(x.get('name')) not in have_supplier]
        else:
            cur['supplier_seeds']=[]
        before={norm(c.get('name')):c for c in (cur.get('companies') or []) if norm(c.get('name'))}
        edge_before={(norm(e.get('buyer_entity_id')),norm(e.get('supplier_entity_id')),e.get('relation') or 'buyer_to_supplier') for e in (cur.get('trade_edges') or [])}
        layer_new=[]
        # Existing executors are reused; they do not control flow.
        for step,fn in (('seed',n_seed_buyers),('mine',n_supplier_mining),('harvest',n_reverse_harvest)):
            step_runs += 1
            try:
                out=fn(cur) or {}
                for k,v in out.items():
                    if k in ('node_reports','_success','_note'):
                        continue
                    # seed_buyers 是本轮执行选择，不是全量企业资产；禁止 Node 7 把 companies 缩成 seeds。
                    if step == 'seed' and k == 'companies':
                        continue
                    if k == 'companies' and isinstance(v,list):
                        existing={norm(x.get('name')):x for x in (cur.get('companies') or []) if norm(x.get('name'))}
                        for item in v:
                            nk=norm(item.get('name')) if isinstance(item,dict) else ''
                            if nk and nk not in existing: existing[nk]=item
                        cur[k]=list(existing.values())
                    else:
                        cur[k]=v
                reports.update(out.get('node_reports') or {})
            except Exception as exc:
                step_errors += 1
                notes.append(f'[d{depth}] {step} error: {type(exc).__name__}: {str(exc)[:120]}')
        # supplier_new 是 Node 7 的真实新增实体，必须回到统一 companies 黑板，
        # 这样后续 Node 6 才会对它做实体标准化 + Target Fit，而不是绕过 Node 6 直接进 Node 8。
        current_companies=list(cur.get('companies') or [])
        current_names={norm(x.get('name')) for x in current_companies if norm(x.get('name'))}
        for supplier in (cur.get('supplier_new') or []):
            sn=norm(supplier.get('name'))
            if sn and sn not in current_names and new_total_budget < global_budget:
                current_companies.append(supplier); current_names.add(sn)
        cur['companies']=current_companies
        after=list(cur.get('companies') or [])
        merged=dict(before)
        for c in after:
            k=norm(c.get('name'))
            if not k: continue
            if k not in merged:
                if new_total_budget < global_budget:
                    merged[k]=c; layer_new.append(c); new_total_budget+=1
            else:
                old=merged[k]; eo=old.setdefault('evidence',{}); en=c.get('evidence') or {}
                eo['shipments']=max(int(eo.get('shipments') or 0),int(en.get('shipments') or 0))
                for kk in ('products','hs','url','country','company_description'):
                    if not eo.get(kk) and en.get(kk): eo[kk]=en[kk]
        cur['companies']=list(merged.values())
        for key in ('suppliers','supplier_new'):
            got=cur.get(key) or []; prev=state_supplier_carry.get(key) or []; seen={norm(x.get('name')) for x in got}
            cur[key]=got+[x for x in prev if norm(x.get('name')) not in seen]; state_supplier_carry[key]=cur[key]
        _,_,_=_sync_edges_from_graph(cur)
        edge_after={(norm(e.get('buyer_entity_id')),norm(e.get('supplier_entity_id')),e.get('relation') or 'buyer_to_supplier') for e in (cur.get('trade_edges') or [])}
        new_edge_keys=edge_after-edge_before
        target_now=sum(1 for c in cur['companies'] if str(c.get('target_fit') or '').upper()=='TARGET_RELEVANT')
        layer_new_count=len(layer_new); new_targets=max(0,target_now-prev_target); new_edges=len(new_edge_keys)
        gain=layer_new_count+new_targets+new_edges
        dup_rate=1-(layer_new_count/max(1,len(after)))
        depths.append({'depth':depth,'entities_total':len(cur['companies']),'new_entities':layer_new_count,'new_target_relevant':new_targets,
                       'new_target_edges':new_edges,'duplicate_rate':round(dup_rate,3),'information_gain':gain,
                       'budget_remaining':max(0,global_budget-new_total_budget),'seed_count':len(seeds)})
        all_new_entities.extend(layer_new)
        if layer_new or new_edges:
            new_trade_facts.extend([e for e in (cur.get('trade_edges') or []) if (norm(e.get('buyer_entity_id')),norm(e.get('supplier_entity_id')),e.get('relation') or 'buyer_to_supplier') in new_edge_keys])
        prev_target=target_now; prev_edges=len(cur.get('trade_edges') or []); prev_total=len(cur.get('companies') or [])
        if not layer_new and new_edges==0:
            # 没有新增实体/贸易边就是正常收敛，不重复烧同一批页面/数据库查询。
            stopped_by='no_new_entities'
            break
        if depth>=2 and gain < int(getattr(settings,'EXPANSION_MIN_NEW_TARGETS',2)):
            stopped_by='low_information_gain'; break
        if new_total_budget>=global_budget:
            stopped_by='budget_exhausted'; break
    if len(depths)>=max_depth and stopped_by=='max_depth': stopped_by='round_limit'
    # 黑板中的 trade_graph 缺失/半结构化时按空图安全恢复；不能因为可选图谱字段让整条链崩溃。
    if not isinstance(cur.get('trade_graph'),dict):
        cur['trade_graph']={'nodes':[],'edges':[],'stats':{}}
    else:
        cur['trade_graph'].setdefault('nodes',[]); cur['trade_graph'].setdefault('edges',[])
    synced,edges_added,edges_skipped=_sync_edges_from_graph(cur)
    route_state=dict(state.get('route_state') or {})
    # New edges must be verified before classification; new entities must be resolved.
    route_state['expansion_new_trade_facts']=bool(new_trade_facts)
    route_state['expansion_new_entities']=bool(all_new_entities)
    state['route_state']=route_state
    state['expansion_new_entities']=all_new_entities[:global_budget]
    state['expansion_new_trade_facts']=new_trade_facts[:global_budget]
    # 有候选但三个扩张执行器全部异常时，不能把“什么都没做”伪装成正常收敛；
    # 交给编排器的恢复机制处理。零候选/正常无新增仍是成功终态。
    seed_attempted = bool(seeds) if 'seeds' in locals() else bool(cur.get('companies'))
    hard_failure = bool(depths) and seed_attempted and step_errors >= step_runs and not (all_new_entities or new_trade_facts)
    if hard_failure:
        stopped_by='executor_error'
    graph_info={'depths':depths,'stopped_by':stopped_by,'max_depth':max_depth,'round':round_no,
                'graph_first':True,'edges_synced':len(synced),'edges_added':edges_added,
                'information_gain':sum(x.get('information_gain',0) for x in depths),
                'route_after_expansion':('TRADE_EDGE_BUILD' if new_trade_facts else ('ENTITY_RESOLUTION' if all_new_entities else 'RESOURCE_CLASSIFICATION')),
                'step_errors':step_errors,'step_runs':step_runs,'expansion_gate':gate}
    if hard_failure:
        graph_info['route_after_expansion']='RESOURCE_CLASSIFICATION'  # 不在失败态强行回流；由编排器恢复决定
    nr=dict(cur.get('node_reports') or {})
    nr['GRAPH_EXPANSION']={'verdict':'fail' if hard_failure else 'pass','depths':depths,'stopped_by':stopped_by,'substeps':reports,'edges_synced':len(synced),
                           'step_errors':step_errors,'step_runs':step_runs,'notes':' | '.join(notes)[:500]}
    cur['node_reports']=nr
    cur['graph_expansion']=graph_info
    cur['_success']=not hard_failure
    cur['_note']=f'受控双向扩张：round={round_no}·levels={len(depths)}·stop={stopped_by}·new_entities={len(all_new_entities)}·new_edges={len(new_trade_facts)}·IG={graph_info["information_gain"]}' + (f'·执行器异常 {step_errors}/{step_runs}' if step_errors else '')
    return cur


# ---------- NODE 8 RESOURCE_CLASSIFICATION：三维分类（角色 × 贸易状态 × 开发状态） ----------
def n_resource_classification(state):
    """current 三维分类词表（每个实体三个维度 + 理由字段，禁止只有 QUALIFIED）：
      entity_role:        CUSTOMER / SUPPLIER / CUSTOMER_AND_SUPPLIER / UNKNOWN
      trade_status:       TRADE_CONFIRMED(硬证据+票数) / TRADE_SUPPORTED(可信来源) / DISCOVERED(弱信号)
      development_status: DEVELOPMENT_POOL / MAINTENANCE_POOL / WON / DISCOVERED_POOL / REMOVED / UNASSIGNED
    lifecycle 生命周期串由三维推导（CUSTOMER_CONFIRMED 等），一套逻辑，不并行。
    """
    # 当前：Node 8 is not a pre-gate. It consumes all entity candidates and performs the final business gate.
    out = {'qualified_companies': list(state.get('companies') or []), 'new_companies': list(state.get('new_companies') or [])}
    pd_key = (state.get('product_domain') or {}).get('key', '')
    # 当前伪实体拦截（第三道保险）：国家/城市/港口/地址绝不进入分类与入库
    _raw_in = list(state.get('companies') or [])
    _kept = [c for c in _raw_in if not is_non_company_name(c.get('name'))]
    if len(_kept) != len(_raw_in):
        state['companies'] = _kept
        out = {'qualified_companies': list(state.get('companies') or []), 'new_companies': list(state.get('new_companies') or [])}
    role_map = {e.get('entity_id') or e.get('company_id'): e for e in (state.get('company_entities') or [])}
    classified_entities = []
    counts = {'by_role': {}, 'by_trade_status': {}, 'by_development_status': {}, 'lifecycle': {}}
    from core.intelligence.local_judge import classify_resources_serial
    _classify_candidates=list(out.get('qualified_companies') or []) + list(state.get('supplier_new') or [])
    _classify_results=[]; _classify_ai_inputs=[]; _classify_map={}
    classification_reused=0; classification_rule=0
    for _c in _classify_candidates:
        prior=_c.get('ai_classification_judgment') or _shared_get(state,'RESOURCE_CLASSIFICATION',_c)
        if isinstance(prior,dict) and (_ai_ok(prior) or prior.get('entity_role')):
            _classify_map[id(_c)]=prior; _classify_map.setdefault(norm(_c.get('name')),prior); classification_reused+=1; continue
        role_hint=(role_map.get(norm(_c.get('name'))) or {}).get('role') or _c.get('entity_role') or ('SUPPLIER' if _is_supplier(_c) else 'CUSTOMER')
        _c['entity_role']=role_hint
        if str(_c.get('target_fit') or '').upper() == 'NON_TARGET':
            _c['final_role_hint']='NEITHER'
        # 当前：Node 8 是最终商业角色闸门。没有已经完成的最终角色判断就必须进入DeepSeek；
        # 不再用“有贸易证据”规则直接推导Customer。
        _classify_ai_inputs.append(_c)
    _classify_results=classify_resources_serial(_classify_ai_inputs,pd_key,state.get('market') or 'USA',progress_hook=_ai_queue_hook(state)) if _classify_ai_inputs else []
    for _c,_j in zip(_classify_ai_inputs,_classify_results):
        _classify_map[id(_c)]=_j; _classify_map.setdefault(norm(_c.get('name')),_j)
        if _ai_ok(_j): _shared_put(state,'RESOURCE_CLASSIFICATION',_c,_j,'AI_DEEP')

    def _classify(c, default_role):
        e = c.get('evidence') or {}
        ent = role_map.get(norm(c.get('name')))
        # 实体解析已判定 UNKNOWN → 保持 UNKNOWN（角色未定只进图谱库）；
        # 未经过实体解析的实体才用默认角色。
        role = (ent.get('role') or 'UNKNOWN') if ent is not None else default_role
        aj=_classify_map.get(id(c)) or _classify_map.get(norm(c.get('name')))
        if not aj: aj={'_ai_success':False,'reason':'no batch judgment'}
        elif '_ai_success' not in aj and aj.get('entity_role'): aj['_ai_success']=True
        c.setdefault('evidence', {})['ai_classification_judgment'] = aj
        c['ai_classification_judgment'] = aj
        ai_role = str(aj.get('entity_role') or '').upper()
        target_fit=str(c.get('target_fit') or (c.get('evidence') or {}).get('target_fit') or '').upper()
        if target_fit == 'NON_TARGET':
            role = 'NEITHER'
        elif ai_role in ('CUSTOMER','SUPPLIER','CUSTOMER_AND_SUPPLIER','NEITHER','UNKNOWN'):
            role = ai_role
        hard = bool(e.get('shipments') or e.get('customs') or e.get('trade_evidence') or e.get('bill_of_lading'))
        has_ship = int(e.get('shipments') or 0) > 0
        # —— 贸易状态 ——
        ai_rel = str(aj.get('business_relevance') or 'unknown').lower()
        if hard and has_ship:
            ts, reason = 'TRADE_CONFIRMED', '硬贸易证据（海关票数 %s）' % e.get('shipments')
        elif hard:
            ts, reason = 'TRADE_SUPPORTED', '可信贸易来源（无提单数字）'
        else:
            ts, reason = 'DISCOVERED', '弱信号发现（保留观察，不删除）'
        # —— 开发状态 ——
        if role == 'UNKNOWN':
            ds = 'UNASSIGNED'
            lifecycle = 'TRADE_NODE_ONLY'
            reason += '；角色未定，只进贸易图谱库'
        elif role == 'NEITHER':
            ds = 'DISCOVERED_POOL'
            lifecycle = 'NEITHER'
            reason += '；最终商业闸门判定为Neither，不进入客户/供应商库'
        else:
            # AI判定为 unrelated 不删除，只停在发现池，避免“有贸易=目标客户”的错误升级。
            ds = 'DISCOVERED_POOL' if ai_rel == 'unrelated' else ('DEVELOPMENT_POOL' if ts in ('TRADE_CONFIRMED', 'TRADE_SUPPORTED') else 'DISCOVERED_POOL')
            if role == 'CUSTOMER':
                lifecycle = 'CUSTOMER_' + ('CONFIRMED' if ts == 'TRADE_CONFIRMED' else 'DEVELOPMENT')
            elif role == 'SUPPLIER':
                lifecycle = 'SUPPLIER_' + {'TRADE_CONFIRMED': 'CONFIRMED', 'TRADE_SUPPORTED': 'DEVELOPMENT', 'DISCOVERED': 'BACKUP'}[ts]
            else:
                lifecycle = 'CUSTOMER_AND_SUPPLIER_' + ('CONFIRMED' if ts == 'TRADE_CONFIRMED' else 'DEVELOPMENT')
        c['entity_role'] = role
        c['trade_status'] = ts
        c['development_status'] = ds
        c['classification_reason'] = reason
        c['lifecycle'] = lifecycle
        c['product_domain'] = pd_key
        counts['by_role'][role] = counts['by_role'].get(role, 0) + 1
        counts['by_trade_status'][ts] = counts['by_trade_status'].get(ts, 0) + 1
        counts['by_development_status'][ds] = counts['by_development_status'].get(ds, 0) + 1
        counts['lifecycle'][lifecycle] = counts['lifecycle'].get(lifecycle, 0) + 1
        classified_entities.append(c)

    for c in (out.get('qualified_companies') or []):
        _classify(c, 'SUPPLIER' if _is_supplier(c) else 'CUSTOMER')
    # 扩张挖到的供应商同样进入分类（供应商统一由 DATABASE_COMMIT 入库）。
    # 一个实体多个角色：已在客户侧的实体再次以供应商身份出现 → 升级为 CUSTOMER_AND_SUPPLIER。
    seen = {norm(c.get('name')) for c in classified_entities}
    for s in (state.get('supplier_new') or []):
        if is_non_company_name(s.get('name')): continue  # 当前伪实体拦截
        sn = norm(s.get('name'))
        if sn in seen:
            for c in classified_entities:
                if norm(c.get('name')) != sn:
                    continue
                if c.get('entity_role') == 'CUSTOMER':
                    counts['by_role']['CUSTOMER'] = counts['by_role'].get('CUSTOMER', 1) - 1
                    c['entity_role'] = 'CUSTOMER_AND_SUPPLIER'
                    counts['by_role']['CUSTOMER_AND_SUPPLIER'] = counts['by_role'].get('CUSTOMER_AND_SUPPLIER', 0) + 1
                    old_lc = c.get('lifecycle') or ''
                    counts['lifecycle'][old_lc] = counts['lifecycle'].get(old_lc, 1) - 1
                    c['lifecycle'] = 'CUSTOMER_AND_SUPPLIER_' + ('CONFIRMED' if c.get('trade_status') == 'TRADE_CONFIRMED' else 'DEVELOPMENT')
                    counts['lifecycle'][c['lifecycle']] = counts['lifecycle'].get(c['lifecycle'], 0) + 1
                    c['classification_reason'] = (c.get('classification_reason') or '') + '；同实体双侧身份：客户+供应商'
                break
            continue
        seen.add(sn)
        _classify({'name': s.get('name'), 'country': s.get('country') or '', 'type': 'supplier',
                   'source': s.get('via') or s.get('source') or 'customs_raw',
                   'evidence': s.get('evidence') or {}}, 'SUPPLIER')
    nr = dict(out.get('node_reports') or {})
    note = ('三维分类：角色%s · 贸易状态%s · 开发状态%s · 域 %s · AI深判 %s · 共享复用 %s · 规则复用 %s · 分类实体 %s · ' % (
            counts['by_role'], counts['by_trade_status'], counts['by_development_status'], pd_key, len(_classify_ai_inputs), classification_reused, classification_rule, len(classified_entities))) + (out.get('_note') or '')
    # new_companies 保留给交接契约（全部已分类实体，新旧判定交给入库层幂等去重）
    return {**{k: v for k, v in out.items() if k not in ('node_reports', '_note')},
            'classified_entities': classified_entities, 'classification': counts,
            'node_reports': nr, '_success': out.get('_success', True), '_note': note}


# ---------- NODE 9 DATABASE_COMMIT：三类资产入库（Entity + Edge + Evidence）+ 完整漏斗 ----------
def n_database_commit(state):
    """classification → entity_converter → 客户库 / 供应商库 / 贸易图谱库。
    三类资产一次提交：Entity（leads）+ Edge（relationships）+ Evidence（evidence_events）。
    数量全程留痕：输入 → 转换 → 写入，任何数量变化必须说明原因（漏斗 drop_reasons）。
    提交对象是【全部已分类实体】——新增/更新/无变化由入库层幂等去重如实报告。"""
    from core.memory.db import DB
    db = DB()
    funnel = list(state.get('funnel') or [])
    classified = list(state.get('classified_entities') or state.get('qualified_companies') or [])
    funnel.append({'stage': 'DATABASE_COMMIT.输入(已分类实体)', 'in': len(classified), 'out': len(classified)})

    # —— 转换层 entity_converter：三维分类 → 客户行/供应商行/双角色行/纯贸易节点 ——
    KIND_MAP = {'CUSTOMER': 'customer', 'SUPPLIER': 'supplier', 'CUSTOMER_AND_SUPPLIER': 'both'}
    ZONE_MAP = {'DEVELOPMENT_POOL': 'dev', 'MAINTENANCE_POOL': 'maint', 'WON': 'won',
                'DISCOVERED_POOL': 'pending', 'REMOVED': 'discard', 'UNASSIGNED': 'pool'}
    customers = []; suppliers = []; both = []; node_only = 0; convert_failed = []
    for c in classified:
        lc = c.get('lifecycle') or ''
        nm = (c.get('name') or '').strip()
        if lc == 'TRADE_NODE_ONLY' or c.get('entity_role') in ('UNKNOWN','NEITHER'):
            node_only += 1; continue  # 只进贸易图谱库（trade_nodes 已在采集层登记）
        if len(nm) < 3:
            convert_failed.append((nm or '(空名)', '名称无效')); continue
        role = c.get('entity_role') or ('SUPPLIER' if _is_supplier(c) else 'CUSTOMER')
        if role == 'NEITHER':
            node_only += 1; continue
        kind = KIND_MAP.get(role, 'customer')
        zone = ZONE_MAP.get(c.get('development_status') or '', 'dev' if lc.endswith('CONFIRMED') else 'pending')
        row = {'name': nm, 'country': c.get('country') or '', 'type': 'supplier' if kind in ('supplier', 'both') else 'customer',
               'source': c.get('source') or '', 'evidence': c.get('evidence') or {},
               'lifecycle': lc, 'product_domain': c.get('product_domain') or '',
               'entity_role': role, 'trade_status': c.get('trade_status') or '',
               'development_status': c.get('development_status') or '',
               'classification_reason': c.get('classification_reason') or '',
               '_kind': kind, '_zone': zone}
        {'customer': customers, 'supplier': suppliers, 'both': both}[kind].append(row)
    funnel.append({'stage': 'DATABASE_COMMIT.转换(entity_converter)', 'in': len(classified),
                   'out': len(customers) + len(suppliers) + len(both),
                   'note': f'客户{len(customers)}·供应商{len(suppliers)}·双角色{len(both)}·纯贸易节点{node_only}·转换失败{len(convert_failed)}',
                   'drop_reasons': [f'{n}:{r}' for n, r in convert_failed[:8]]})

    # —— 资产一：Entity 写入（幂等去重，如实报告 新增/更新/无变化/待验证/失败） ——
    created = 0; created_sup = 0; created_both = 0; updated = 0; pending_n = 0; unchanged = 0; failed = []
    committed_norms = []
    for c in customers + suppliers + both:
        result = db.commit_discovery_lead(c, zone=c['_zone'], kind=c['_kind'])
        if not result.get('ok'):
            failed.append((c.get('name') or '')[:120]); continue
        committed_norms.append(result.get('norm'))
        if result.get('created'):
            if c['_zone'] == 'dev':
                if c['_kind'] == 'supplier': created_sup += 1
                elif c['_kind'] == 'both': created_both += 1
                else: created += 1
            else:
                pending_n += 1
        elif result.get('changed'):
            updated += 1
        else:
            unchanged += 1
    total_in = len(customers) + len(suppliers) + len(both)
    funnel.append({'stage': 'DATABASE_COMMIT.Entity写入', 'in': total_in,
                   'out': created + created_sup + created_both + updated + pending_n + unchanged,
                   'note': f'新增客户{created}·新增供应商{created_sup}·双角色{created_both}·更新{updated}·无变化{unchanged}·发现池{pending_n}·失败{len(failed)}'})

    # —— 资产二：Edge 写入（relationships 全系统唯一正式出口） ——
    # 内存标准边在此落库（INSERT OR IGNORE 幂等，重复边自动累加证据）；写前兜底重判等级。
    task_id = state.get('task_id', '')
    edge_in = list(state.get('trade_edges') or [])
    edge_written = 0
    edge_failed = []
    for ed in edge_in:
        try:
            e = ed.get('evidence') or {}
            lvl = ed.get('evidence_level') or _evidence_level(e, ed.get('source') or '')
            if lvl != 'STRONG':
                ed['confidence'] = min(float(ed.get('confidence') or 0.8), EVIDENCE_DEMOTE[lvl])
            db.add_relationship(task_id, ed.get('from_name'), ed.get('from_type') or 'buyer',
                                ed.get('to_name'), ed.get('to_type') or 'supplier',
                                ed.get('relation') or 'buyer_to_supplier', e,
                                ed.get('source') or 'trade_graph', ed.get('confidence') or 0.8,
                                ed.get('depth') or 1, evidence_level=lvl,
                                discovered_via=ed.get('discovered_via') or '',
                                parent_node=ed.get('parent_node') or '',
                                expansion_path=ed.get('expansion_path') or '',
                                product_domain=ed.get('product_id') or (state.get('product_domain') or {}).get('key', ''))
            edge_written += 1
        except Exception as exc:
            edge_failed.append({'from': ed.get('from_name'), 'to': ed.get('to_name'),
                                'error': f'{type(exc).__name__}: {exc}'})
    # 回读核验：同库回读本任务全部边，确认写入可见；并兜底登记端点节点进候选池——
    # 图谱优先：每条边的两端都必须是图谱里的 Trade Node。
    try:
        rels = db.list_relationships(task_id=task_id, limit=5000)
        edge_n = len(rels)
        edge_levels = {}
        for r in rels:
            lv = r.get('evidence_level') or 'UNVERIFIED'
            edge_levels[lv] = edge_levels.get(lv, 0) + 1
            for nm, tp in ((r.get('from_name'), r.get('from_type') or 'buyer'),
                           (r.get('to_name'), r.get('to_type') or 'supplier')):
                try:
                    role = 'logistics' if LOGISTICS_RE.search(str(nm or '')) else tp
                    db.upsert_trade_node(nm, role=role, shipments=int(r.get('shipment_count') or 0),
                                         products=r.get('product') or '', hs=r.get('hs') or '',
                                         depth=int(r.get('depth') or 1), via='edge_endpoint',
                                         source=r.get('source') or 'trade_graph',
                                         entity_status='RESOLVED' if (r.get('shipment_count') or 0) > 0 else 'UNRESOLVED_TRADE_NODE',
                                         product_domain=r.get('product_domain') or (state.get('product_domain') or {}).get('key', ''))
                except Exception as exc:
                    # 端点补登记失败不应伪装成成功；保留主边写入结果，同时留下可诊断错误。
                    edge_failed.append({'from': nm, 'to': r.get('to_name'),
                                        'error': f'endpoint_upsert: {type(exc).__name__}: {exc}'})
    except Exception as exc:
        edge_n = 0; edge_levels = {}
        edge_failed.append({'error': f'edge_readback: {type(exc).__name__}: {exc}'})
    funnel.append({'stage': 'DATABASE_COMMIT.Edge写入(唯一出口)', 'in': len(edge_in),
                   'out': edge_written, 'note': f'库内本任务边 {edge_n} 条·证据等级分布 {edge_levels}·失败 {len(edge_failed)}',
                   'errors': edge_failed[:8]})
    # —— 资产三：Evidence 写入（每个实体一条证据事件，权重跟随贸易状态） ——
    ev_n = 0
    evidence_failed = []
    for c in customers + suppliers + both:
        try:
            e = c.get('evidence') or {}
            w = {'TRADE_CONFIRMED': 1.0, 'TRADE_SUPPORTED': 0.6, 'DISCOVERED': 0.3}.get(c.get('trade_status'), 0.5)
            payload = {'evidence': e, 'trade_status': c.get('trade_status'),
                       'reason': c.get('classification_reason') or ''}
            db.add_evidence_event(task_id, db._norm(c.get('name')), 'trade_asset_commit',
                                  c.get('source') or 'customs', _JSON_DUMPS(payload, ensure_ascii=False)[:1800], w)
            ev_n += 1
        except Exception as exc:
            evidence_failed.append({'name': c.get('name'), 'error': f'{type(exc).__name__}: {exc}'})
    funnel.append({'stage': 'DATABASE_COMMIT.Evidence写入', 'in': total_in, 'out': ev_n,
                   'errors': evidence_failed[:8]})
    state['funnel'] = funnel

    # 回读自证：提交后立即用同一连接回读；界面若与这里不一致，唯一可能是打开了另一个项目副本
    verify = {'db': os.path.basename(str(settings.DATABASE_PATH)), 'dev_customers': 0, 'dev_suppliers': 0, 'probe_ok': True}
    try:
        import sqlite3 as _sq
        with _sq.connect(str(settings.DATABASE_PATH)) as _x:
            verify['dev_customers'] = _x.execute("SELECT COUNT(*) FROM leads WHERE zone='dev' AND kind IN ('customer','both')").fetchone()[0]
            verify['dev_suppliers'] = _x.execute("SELECT COUNT(*) FROM leads WHERE zone='dev' AND kind IN ('supplier','both')").fetchone()[0]
            for pn in committed_norms[:5]:
                if pn and not _x.execute('SELECT 1 FROM leads WHERE norm=?', (pn,)).fetchone():
                    verify['probe_ok'] = False; break
    except Exception:
        verify['probe_ok'] = False
    ok = (len(failed) == 0 and not edge_failed and not evidence_failed and edge_written == len(edge_in) and total_in == created + created_sup + created_both + pending_n + updated + unchanged) and verify['probe_ok']
    rep = experts.review('DATABASE_COMMIT',
                         f'三类资产入库：Entity 输入{len(classified)}→转换{total_in}(客户{len(customers)}+供应商{len(suppliers)}+双角色{len(both)}，纯节点{node_only})'
                         f'→写入：新增客户{created}·供应商{created_sup}·双角色{created_both}·更新{updated}·无变化{unchanged}·发现池{pending_n}·失败{len(failed)} '
                         f'| Edge 写入{edge_written}/库内{edge_n} 条{edge_levels} | Evidence {ev_n} 条 · 回读{"通过" if verify["probe_ok"] else "失败"}',
                         [('数量恒等（输入=转换+纯节点+失败）', len(classified) == total_in + node_only + len(convert_failed),
                           f'{len(classified)}={total_in}+{node_only}+{len(convert_failed)}'),
                          ('数量恒等（写入=新增+更新+无变化+发现池+失败）', total_in == created + created_sup + created_both + pending_n + updated + unchanged + len(failed),
                           f'{total_in}={created}+{created_sup}+{created_both}+{updated}+{unchanged}+{pending_n}+{len(failed)}'),
                          ('三类资产齐备（Entity+Edge+Evidence）', ev_n == total_in - len(failed) and edge_written == len(edge_in) and not edge_failed and not evidence_failed, f'Entity {total_in}·Edge {edge_written}/{len(edge_in)}·Evidence {ev_n}/{total_in}·边失败{len(edge_failed)}·证据失败{len(evidence_failed)}'),
                          ('回读验证（同库可见）', verify['probe_ok'], f"库 {verify['db']} · 确认池客户 {verify['dev_customers']} · 供应商 {verify['dev_suppliers']}")],
                         critical={'数量恒等（写入=新增+更新+无变化+发现池+失败）', '回读验证（同库可见）'})
    return {'database_commit': {'input': len(classified), 'converted': total_in, 'node_only': node_only,
                                'convert_failed': convert_failed,
                                'dev': created, 'dev_suppliers': created_sup, 'dev_both': created_both,
                                'updated': updated, 'unchanged': unchanged, 'pending': pending_n, 'failed': failed,
                                'edges': edge_n, 'edge_written': edge_written, 'edge_failed': edge_failed[:8], 'edge_levels': edge_levels, 'evidence_events': ev_n, 'evidence_failed': evidence_failed[:8],
                                'verify': verify, 'funnel': funnel,
                                'policy': 'classified_all_commit; three_assets(entity+edge+evidence); idempotent_dedup; kind_aware(customer/supplier/both); evidence_graded'},
            'commit_verify': verify,
            'node_reports': _report(state, 'DATABASE_COMMIT', rep), '_success': ok,
            '_note': (f"入库完成：输入{len(classified)}→新增客户{created}·供应商{created_sup}·双角色{created_both}·已有更新{updated}·发现池{pending_n}"
                      f"·边{edge_n}条·证据{ev_n}条·确认池现存 客户{verify['dev_customers']}/供应商{verify['dev_suppliers']}（库 {verify['db']}）"
                      if ok else f'入库失败：Entity失败{len(failed)}·Edge失败{len(edge_failed)}·Evidence失败{len(evidence_failed)}·回读{"失败" if not verify["probe_ok"] else "通过"}')}
