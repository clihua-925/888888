# -*- coding: utf-8 -*-
"""Collection orchestrator entry: build state, execute the nine-node graph, checkpoint every node, and persist the terminal result."""
import time,uuid,json
from core.control_plane.task_contract import build_collection_contract
from core.memory.db import DB
from core.runtime import graph
class Orchestrator:
    def __init__(self): self.db=DB()
    def run(self,request,market='USA',industry='birthday candles',quantity=20,task_id=None):
        contract=build_collection_contract(request, task_id=task_id, market=market, industry=industry, quantity=quantity)
        tid=contract.task_id; t0=time.time()
        state={'task_id':tid,'request':request,'market':market,'industry':industry,
               'task_contract':contract.to_dict(),'workflow':'collection','control_plane_version':'v46.1',
               'quantity':int(quantity or 20),'nodes':[],'companies':[],
               'success':False,
               'node_reports':{},'strategy':{},'query_override':None,
               'current_node':'INIT','node_status':{},'handoffs':{},'retry_history':[],'plans':[],
               'diagnostics':[],'mission_decisions':[],'funnel':[], 'node3_quality_reentries':0, 'node3_quality_history':[], '_persist_runtime': None}
        last_observed = {'marker': None}
        def persist(st):
            # Observation/checkpoint only: the nine node implementations and graph topology
            # are untouched. Persist enough runtime state for the UI to reconstruct the
            # exact node-by-node progress after navigation/refresh/reopen.
            category_id = st.get('category_id') or {'birthday candles':'candle','candle':'candle','enamel pot':'enamel_pot','felt':'felt'}.get(str(industry).lower())
            if not self.db.get_task(tid):
                self.db.create_task(tid, request, 'collection', category_id, None)
            order = graph.ORDER
            raw_statuses = dict(st.get('node_status') or {})
            # UI/持久化快照使用 canonical 字符串状态；运行时 node_status 内部仍可保留 attempt/error 等元数据。
            statuses = {n: (v.get('status') if isinstance(v, dict) else str(v)) for n, v in raw_statuses.items()}
            done_count = sum(1 for n in order if statuses.get(n) in ('SUCCESS','SKIPPED'))
            current = st.get('current_node') or 'MISSION_DIRECTOR'
            idx = order.index(current) if current in order else (len(order) if current == 'END' else 0)
            progress = 100 if current == 'END' and not st.get('abort') else round(min(99, max(done_count * 100 / len(order), idx * 100 / len(order))), 1)
            snapshot = {
                'order': order,
                'current_node': current,
                'node_status': statuses,
                'nodes': list(st.get('nodes') or [])[-20:],
                'handoffs': dict(st.get('handoffs') or {}),
                'retry_history': list(st.get('retry_history') or [])[-20:],
                'failure_history': list(st.get('failure_history') or [])[-20:],
                'mission_decisions': list(st.get('mission_decisions') or [])[-10:],
                'collection_quality': dict(st.get('collection_quality') or {}),
                'node3_direct_fallback': dict(st.get('node3_direct_fallback') or {}),
                'node3_quality_reentries': int(st.get('node3_quality_reentries') or 0),
                'node3_quality_history': list(st.get('node3_quality_history') or [])[-10:],
                'terminal_reason': st.get('error') or '',
                'task_contract': dict(st.get('task_contract') or {}),
                'control_plane': dict(st.get('control_plane') or {}),
                'funnel': list(st.get('funnel') or [])[-10:],
                'ai_queue': dict(st.get('ai_queue') or {}),
                'entity_resolution_ai_stats': dict(st.get('entity_resolution_ai_stats') or {}),
                'target_fit_stats': dict(st.get('entity_resolution_ai_stats') or {}),
                'updated_at': time.time(),
            }
            self.db.update_task(tid, current_node=current, current_stage=current, progress_pct=progress,
                                resume_state=json.dumps(snapshot, ensure_ascii=False, separators=(',', ':')))
            marker = (current, tuple(sorted(statuses.items())))
            if marker != last_observed['marker']:
                self.db.save_task_log(tid, 'collection_observer', f'节点状态：{current}；完成 {done_count}/{len(order)}；进度 {progress}%')
                last_observed['marker'] = marker
        state['_persist_runtime'] = persist
        persist(state)
        try:
            state=graph.run_graph(state,persist)
        except Exception as e:
            # 最外层最后一道保险：任何未被节点/恢复器捕获的异常，都必须写成终态失败，
            # 绝不能让 UI 永久显示“某节点执行中”。同时保留 traceback 供现场诊断。
            state['abort']='failed'
            state['error']=f"orchestrator_unhandled: {type(e).__name__}: {e}"
            state['traceback']=__import__('traceback').format_exc()[-5000:]
            failed_node=state.get('current_node') or 'UNKNOWN'
            try:
                graph._set_status(state, failed_node, 'FAILED', attempt=1, error=state['error'])
            except Exception:
                pass
            state.setdefault('nodes',[]).append({'node':failed_node,'status':'FAILED','success':False,
                                                'attempt':1,'ts':time.time(),'note':state['error'],
                                                'exception':True})
            persist(state)
            state['current_node']=failed_node
        abort=state.get('abort')
        status={'failed':'failed','failed_gate':'failed_gate','done_degraded':'done_degraded','error':'error'}.get(abort,'done')
        state['success']=status in ('done','done_degraded')
        state['duration_sec']=round(time.time()-t0,2)
        res={k:v for k,v in state.items() if k!='traceback'}
        if not self.db.get_task(tid): self.db.create_task(tid, request, 'collection', None, None)
        self.db.update_task(tid, run_status=status, current_node=state.get('current_node'),
                            failure_reason=str(state.get('error') or '')[:500] if status not in ('done','done_degraded') else '',
                            completed_at=time.time())
        return res

    def run_development(self, lead_norm, task_id=None, start_node=None,
                        our_product=None, our_company=None):
        """Compatibility entry for the post-collection business flow.

        The former runtime.development module was removed during the merged build.
        Keep this public entry point, but route it through the canonical Business
        Execution Center instead of importing a deleted 已移除模块.
        """
        from core.business_execution.execution_center import BusinessExecutionCenter
        tid = task_id or ('dev-' + uuid.uuid4().hex[:8])
        t0 = time.time()
        executor = BusinessExecutionCenter(self.db)
        self.db.create_task(tid, f'Development sequence: {lead_norm}', 'development', None, None)
        self.db.update_task(tid, run_status='running', current_stage='qualification', current_node='BUSINESS_QUALIFICATION')
        self.db.save_task_log(tid, 'orchestrator', f'Starting business execution for {lead_norm}')
        try:
            qualification = executor.qualify_for_development(lead_norm)
            if not qualification.get('qualified'):
                result = {'ok': False, 'stage': 'qualification_failed',
                          'reason': qualification.get('reason'),
                          'checks': qualification.get('checks', {}), 'qualification': qualification}
                self.db.update_task(tid, run_status='completed', current_stage='qualification_failed', completed_at=time.time())
                return result
            self.db.update_task(tid, current_stage='letter_generation', current_node='DEVELOPMENT_LETTER')
            letter = executor.generate_development_letter(lead_norm, our_product=our_product, our_company=our_company)
            ok = bool(letter.get('ok'))
            status = 'completed' if ok else 'failed'
            self.db.update_task(tid, run_status=status, current_stage='letter_generated' if ok else 'letter_failed', completed_at=time.time())
            result = {'ok': ok, 'stage': 'letter_generated' if ok else 'letter_failed',
                      'qualification': qualification, 'letter': letter, 'task_id': tid,
                      'duration_sec': round(time.time() - t0, 2)}
            self.db.save_task_log(tid, 'orchestrator', f'Business execution {status} for {lead_norm}')
            return result
        except Exception as e:
            self.db.update_task(tid, run_status='failed', failure_reason=str(e)[:500], completed_at=time.time())
            self.db.save_task_log(tid, 'orchestrator', f'Business execution failed: {e}')
            return {'ok': False, 'stage': 'failed', 'error': str(e)[:500], 'task_id': tid,
                    'duration_sec': round(time.time() - t0, 2)}
