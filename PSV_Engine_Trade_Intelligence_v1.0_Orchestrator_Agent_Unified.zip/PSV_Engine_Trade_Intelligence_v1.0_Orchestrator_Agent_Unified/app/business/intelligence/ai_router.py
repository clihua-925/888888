# -*- coding: utf-8 -*-
"""AI Router / AI Gateway (FULL)

统一管理 GPT / DeepSeek / Qwen 调用。
- 节点不直接绑定某一个模型
- 自动故障切换
- 返回自然语言结论（结构化解析由调用方处理）
- 记录 AI 调用日志
"""
import os, time, json, re
from typing import List, Dict, Any, Optional
from core.config import settings


class AIRouter:
    """AI 路由网关"""

    def __init__(self):
        self.providers = settings.AI_PROVIDERS
        self.call_history = []

    def route(self, prompt: str, model_preference: List[str] = None,
              system_prompt: str = None, temperature: float = 0.3,
              max_tokens: int = 2000, require_json: bool = False) -> Dict[str, Any]:
        """
        统一 AI 调用接口。

        Args:
            prompt: 用户提示
            model_preference: 模型优先级列表，如 ['deepseek', 'qwen', 'gpt']
            system_prompt: 系统提示
            temperature: 温度
            max_tokens: 最大 token
            require_json: 是否要求返回 JSON

        Returns:
            {
                'success': bool,
                'content': str,           # 自然语言结论（第一结果）
                'model_used': str,        # 实际使用的模型
                'provider': str,          # 提供商名称
                'latency_ms': int,
                'error': str,             # 失败时填充
                'parsed_json': Any,       # 如果成功解析 JSON
                'raw_response': str,      # 原始响应
            }
        """
        preference = model_preference or [p['name'] for p in sorted(self.providers, key=lambda x: x['priority'])]

        for provider_name in preference:
            provider = next((p for p in self.providers if p['name'] == provider_name), None)
            if not provider:
                continue

            api_key = os.environ.get(provider['api_key_env'], '')
            if not api_key:
                continue

            start = time.time()
            try:
                result = self._call_provider(provider, prompt, system_prompt, temperature, max_tokens)
                latency = int((time.time() - start) * 1000)

                # 记录调用
                self._log_call(provider_name, prompt[:200], result['content'][:200], latency, True)

                # 尝试解析 JSON
                parsed = None
                if require_json:
                    parsed = self._extract_json(result['content'])

                return {
                    'success': True,
                    'content': result['content'],
                    'model_used': provider['model'],
                    'provider': provider_name,
                    'latency_ms': latency,
                    'error': '',
                    'parsed_json': parsed,
                    'raw_response': result['raw'],
                }
            except Exception as e:
                latency = int((time.time() - start) * 1000)
                self._log_call(provider_name, prompt[:200], str(e)[:200], latency, False)
                continue  # 切换到下一个 provider

        # 全部失败
        return {
            'success': False,
            'content': '',
            'model_used': '',
            'provider': '',
            'latency_ms': 0,
            'error': 'All AI providers failed',
            'parsed_json': None,
            'raw_response': '',
        }

    def _call_provider(self, provider: Dict, prompt: str, system_prompt: str,
                       temperature: float, max_tokens: int) -> Dict:
        """调用具体提供商（抽象层，实际可接入真实 API）"""
        name = provider['name']
        api_key = os.environ.get(provider['api_key_env'], '')

        if name == 'gpt':
            return self._call_openai(api_key, provider['model'], prompt, system_prompt, temperature, max_tokens)
        elif name == 'deepseek':
            return self._call_deepseek(api_key, provider['model'], prompt, system_prompt, temperature, max_tokens)
        elif name == 'qwen':
            return self._call_qwen(api_key, provider['model'], prompt, system_prompt, temperature, max_tokens)
        else:
            raise ValueError(f"Unknown provider: {name}")

    def _call_openai(self, api_key: str, model: str, prompt: str, system_prompt: str,
                     temperature: float, max_tokens: int) -> Dict:
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            resp = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                timeout=settings.AI_TIMEOUT
            )
            content = resp.choices[0].message.content
            return {'content': content, 'raw': content}
        except Exception as e:
            raise

    def _call_deepseek(self, api_key: str, model: str, prompt: str, system_prompt: str,
                       temperature: float, max_tokens: int) -> Dict:
        try:
            import openai
            client = openai.OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            resp = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                timeout=settings.AI_TIMEOUT
            )
            content = resp.choices[0].message.content
            return {'content': content, 'raw': content}
        except Exception as e:
            raise

    def _call_qwen(self, api_key: str, model: str, prompt: str, system_prompt: str,
                   temperature: float, max_tokens: int) -> Dict:
        try:
            import openai
            client = openai.OpenAI(api_key=api_key, base_url="https://dashscope.aliyuncs.com/compatible-mode/v1")
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            resp = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                timeout=settings.AI_TIMEOUT
            )
            content = resp.choices[0].message.content
            return {'content': content, 'raw': content}
        except Exception as e:
            raise

    def _extract_json(self, text: str) -> Any:
        """从自然语言响应中提取 JSON"""
        # 尝试直接解析
        try:
            return json.loads(text)
        except:
            pass
        # 尝试提取代码块
        match = re.search(r'```(?:json)?\s*([\s\S]*?)```', text)
        if match:
            try:
                return json.loads(match.group(1))
            except:
                pass
        # 尝试提取方括号/花括号内容
        match = re.search(r'(\[[\s\S]*\]|\{[\s\S]*\})', text)
        if match:
            try:
                return json.loads(match.group(1))
            except:
                pass
        return None

    def _log_call(self, provider: str, prompt_preview: str, result_preview: str,
                  latency: int, success: bool):
        self.call_history.append({
            'provider': provider,
            'prompt_preview': prompt_preview,
            'result_preview': result_preview,
            'latency_ms': latency,
            'success': success,
            'timestamp': time.time()
        })


# 全局单例
_router = None

def ai_route(prompt: str, model_preference: List[str] = None,
             system_prompt: str = None, temperature: float = 0.3,
             max_tokens: int = 2000, require_json: bool = False) -> str:
    """
    便捷函数：返回自然语言字符串。
    如果全部失败，返回空字符串。
    """
    global _router
    if _router is None:
        _router = AIRouter()
    result = _router.route(prompt, model_preference, system_prompt, temperature, max_tokens, require_json)
    return result['content'] if result['success'] else ''


def ai_route_structured(prompt: str, model_preference: List[str] = None,
                        system_prompt: str = None) -> Dict[str, Any]:
    """
    结构化调用：返回完整结果字典（含 success/error/parsed_json）。
    """
    global _router
    if _router is None:
        _router = AIRouter()
    return _router.route(prompt, model_preference, system_prompt, require_json=True)
