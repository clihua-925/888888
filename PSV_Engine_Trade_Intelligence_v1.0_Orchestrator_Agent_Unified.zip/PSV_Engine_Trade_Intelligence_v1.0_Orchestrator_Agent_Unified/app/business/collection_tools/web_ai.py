# -*- coding: utf-8 -*-
"""current: 网页AI兜底通道（DeepSeek/ChatGPT 网页版，走用户已登录的 CDP 浏览器会话）。
定位：疑难问题的少量对话式兜底，不是批量工具。
安全闸：每日上限 WEBAI_DAILY_MAX + 调用间隔 WEBAI_MIN_INTERVAL 秒 + 仅开发/维护区客户触发。
用法：
  from core.tools import web_ai
  txt=web_ai.ask('把 Signature Brands 的官网/邮箱/电话/地址给我，输出JSON')
  python -m core.tools.web_ai diag deepseek "hello"   # 诊断"""
import re,time,json,sqlite3,random
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.abspath(_os.path.join(_os.path.dirname(__file__),'../..')))
from core.config import settings

ENGINES={
 'deepseek':{'url':'https://chat.deepseek.com/',
             'inputs':['textarea#chat-input','textarea[placeholder]','textarea[aria-label]','div[contenteditable="true"]','div[role="textbox"]','[contenteditable="true"]','textarea'],
             'answers':['.ds-markdown','.ds-markdown-container','.markdown','[class*=markdown]','[class*=message]']},
 'chatgpt':{'url':'https://chatgpt.com/',
            'inputs':['#prompt-textarea','div[contenteditable="true"]','textarea'],
            'answers':['[data-message-author-role="assistant"]','.markdown','[class*=markdown]']},
 # current 千问（通义）网页引擎：走用户在 CDP 浏览器里已登录的通义会话；
 # 未登录时 preflight 诚实失败并自动切换下一家——绝不假装成功。
 'qwen':{'url':'https://www.tongyi.com/',
         'inputs':['textarea[placeholder]','textarea','div[contenteditable="true"]'],
         'answers':['[class*=markdown]','.markdown','[class*=answer]','[class*=message]']},
}
_last_call=[0.0]

def _quota_ok(engine):
    day=time.strftime('%Y-%m-%d')
    try:
        conn=sqlite3.connect(settings.DATABASE_PATH)
        conn.execute('CREATE TABLE IF NOT EXISTS source_quota(source TEXT,day TEXT,count INT,UNIQUE(source,day))')
        r=conn.execute('SELECT count FROM source_quota WHERE source=? AND day=?',('webai_'+engine,day)).fetchone()
        used=r[0] if r else 0
        ok=used<int(settings.WEBAI_DAILY_MAX)
        conn.close(); return ok,used
    except Exception: return True,0

def _quota_inc(engine):
    day=time.strftime('%Y-%m-%d')
    try:
        conn=sqlite3.connect(settings.DATABASE_PATH)
        conn.execute('INSERT INTO source_quota(source,day,count) VALUES(?,?,1) ON CONFLICT(source,day) DO UPDATE SET count=count+1',('webai_'+engine,day))
        conn.commit(); conn.close()
    except Exception: pass

def _cdp_alive(url):
    import urllib.request
    try:
        op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with op.open(url+'/json/version',timeout=4) as r: return r.status==200
    except Exception: return False

class WebAI:
    """挂 CDP 桌面浏览器（用户已登录 DeepSeek/GPT 的那个 Chrome）。

    保留早期版本的核心策略：一个 Playwright/CDP 会话复用、随机调用间隔、
    流式回答稳定检测、失败只降级不伪造结果。针对批量专家确认增加了：
    - 复用已有 AI 标签页，避免每家公司都重新建页/重载；
    - 提交前记录旧回答，避免把上一家公司回答误认成当前回答；
    - 一次温和重试（刷新后重发），仍无结果则返回 None；
    - preflight 诊断，让上层能区分 CDP/登录/页面/回答等待失败。
    """
    def __init__(self):
        self._pw=None; self._br=None; self._ctx=None; self._pg=None
        self._engine=None
        self._owns_page=False

    def _launch(self, engine=None):
        from playwright.sync_api import sync_playwright
        if not (settings.IY_WEB_CDP_ENABLED and _cdp_alive(settings.IY_WEB_CDP_URL)):
            raise RuntimeError('CDP 浏览器未就绪（先跑 start_chrome_debug.bat 并登录 AI 网站）')
        self._pw=sync_playwright().start()
        self._br=self._pw.chromium.connect_over_cdp(settings.IY_WEB_CDP_URL)
        contexts=self._br.contexts
        if not contexts:
            raise RuntimeError('CDP 已连接但没有可用 BrowserContext')
        self._ctx=contexts[0]
        self._pg=None
        self._owns_page=False
        # 优先复用用户已经打开的目标 AI 页面；没有才新建。
        if engine and engine in ENGINES:
            target=ENGINES[engine]['url']
            for pg in self._ctx.pages:
                try:
                    if pg.url and pg.url.startswith(target):
                        self._pg=pg; self._owns_page=False; break
                except Exception:
                    pass
        if self._pg is None:
            self._pg=self._ctx.new_page()
            self._owns_page=True
        self._engine=None

    def close(self):
        try:
            # 不关闭用户原本打开的 DeepSeek/ChatGPT 标签页；仅关闭本 worker 自己创建的页面。
            if self._pg and self._owns_page: self._pg.close()
        except Exception: pass
        try:
            if self._pw: self._pw.stop()
        except Exception: pass
        self._pg=None; self._ctx=None; self._br=None; self._pw=None; self._engine=None; self._owns_page=False

    def _first_visible(self,selectors):
        for sel in selectors:
            try:
                els=self._pg.query_selector_all(sel)
                for el in els:
                    if el.is_visible(): return el
            except Exception: continue
        return None

    def _answer_text(self,cfg):
        """取当前页面最后一条可见回答，多个选择器去重后按 DOM 顺序取最后一项。"""
        vals=[]
        for sel in cfg.get('answers',[]):
            try:
                for el in self._pg.query_selector_all(sel):
                    if el.is_visible():
                        txt=(el.inner_text() or '').strip()
                        if txt and txt not in vals:
                            vals.append(txt)
            except Exception:
                continue
        return vals[-1] if vals else ''

    def _answer_snapshot(self,cfg):
        vals=[]
        for sel in cfg.get('answers',[]):
            try:
                for el in self._pg.query_selector_all(sel):
                    if el.is_visible():
                        txt=(el.inner_text() or '').strip()
                        if txt and txt not in vals: vals.append(txt)
            except Exception: continue
        return vals

    def prepare(self,engine=None,timeout=60000):
        """连接并准备目标网页。返回可记录到任务日志的诊断信息。"""
        engine=engine or settings.WEBAI_ENGINE
        cfg=ENGINES.get(engine)
        if not cfg: return {'ok':False,'stage':'config','engine':engine,'error':'未知引擎'}
        try:
            if not self._pg:
                self._launch(engine)
            current=self._pg.url or ''
            if not current.startswith(cfg['url']):
                self._pg.goto(cfg['url'],timeout=timeout,wait_until='domcontentloaded')
                self._pg.wait_for_timeout(5000)
            else:
                # 已在目标页时只给页面一点恢复时间，不重复导航。
                self._pg.wait_for_timeout(700)
            box=self._first_visible(cfg['inputs'])
            if not box:
                self._pg.wait_for_timeout(2500)
                box=self._first_visible(cfg['inputs'])
            if not box:
                return {'ok':False,'stage':'input','engine':engine,'url':self._pg.url or '',
                        'error':'未找到输入框（可能未登录、页面改版或当前页面不可交互）'}
            return {'ok':True,'stage':'ready','engine':engine,'url':self._pg.url or ''}
        except Exception as e:
            return {'ok':False,'stage':'page','engine':engine,'url':getattr(self._pg,'url','') if self._pg else '',
                    'error':str(e)[:300]}

    def preflight(self,engine=None):
        engine=engine or settings.WEBAI_ENGINE
        if not settings.IY_WEB_CDP_ENABLED:
            return {'ok':False,'stage':'cdp_disabled','engine':engine,'error':'IY_WEB_CDP_ENABLED=false'}
        if not _cdp_alive(settings.IY_WEB_CDP_URL):
            return {'ok':False,'stage':'cdp_offline','engine':engine,'error':'CDP端口不可用'}
        ok,used=_quota_ok(engine)
        if not ok:
            return {'ok':False,'stage':'quota','engine':engine,'used':used,'limit':int(settings.WEBAI_DAILY_MAX),
                    'error':'达到当日网页AI调用上限'}
        return self.prepare(engine)

    def _wait_answer(self,cfg,before,deadline):
        last=''; stable=0; seen=False
        while time.time()<deadline:
            self._pg.wait_for_timeout(1800)
            txt=self._answer_text(cfg)
            if not txt: continue
            # 必须是提交后的新/变化回答，防止上一轮答案被直接拿走。
            is_new=(txt not in before) or (before and txt != max(before,key=len)) or not before
            if not is_new:
                continue
            seen=True
            if txt==last: stable+=1
            else: stable=0
            last=txt
            # 连续两次相同即认为流式输出稳定；短答案也允许通过，避免合法的简短结论被丢弃。
            if stable>=2 and len(txt.strip())>10:
                return txt,'stable'
        return (last if seen and len(last.strip())>10 else ''),'timeout' if not seen else 'unstable'

    def ask(self,question,engine=None,timeout=None,retries=1):
        """复用同一网页会话询问；回答必须在提交后出现并稳定，否则降级。"""
        engine=engine or settings.WEBAI_ENGINE
        cfg=ENGINES.get(engine)
        if not cfg:
            print('[webai] 未知引擎:',engine); return None
        ok,used=_quota_ok(engine)
        if not ok:
            print('[webai] %s 已达今日上限(%d轮)，跳过'%(engine,settings.WEBAI_DAILY_MAX)); return None
        import random as _rnd
        need=float(settings.WEBAI_MIN_INTERVAL)*_rnd.uniform(1.0,2.5)
        gap=time.time()-_last_call[0]
        if gap<need: time.sleep(need-gap)
        if not self._pg:
            try: self._launch(engine)
            except Exception as e:
                print('[webai] launch failed:',str(e)[:160]); return None
        last_error=''
        for attempt in range(max(0,int(retries))+1):
            try:
                ready=self.prepare(engine)
                if not ready.get('ok'):
                    last_error=ready.get('error') or ready.get('stage') or 'prepare failed'
                    print('[webai] %s 未就绪: %s'%(engine,last_error[:160])); return None
                box=self._first_visible(cfg['inputs'])
                if not box:
                    return None
                before=set(self._answer_snapshot(cfg))
                box.click()
                self._pg.wait_for_timeout(250)
                try:
                    box.fill('')
                except Exception:
                    # contenteditable 常常不支持 fill；退回键盘全选清空，避免把上一客户问题拼接到本轮。
                    try:
                        box.click(); self._pg.keyboard.press('Control+A'); self._pg.keyboard.press('Backspace')
                    except Exception: pass
                self._pg.wait_for_timeout(200)
                self._pg.keyboard.insert_text(question[:4000])
                self._pg.wait_for_timeout(700)
                self._pg.keyboard.press('Enter')
                _last_call[0]=time.time()
                deadline=time.time()+int(timeout or settings.WEBAI_TIMEOUT)
                txt,state=self._wait_answer(cfg,before,deadline)
                if txt:
                    _quota_inc(engine)
                    print('[webai] %s 回答 %d 字（今日第%d/%d轮，attempt=%d）'%(engine,len(txt),used+1,settings.WEBAI_DAILY_MAX,attempt+1))
                    return txt
                last_error=state
                print('[webai] %s 无稳定回答: %s'%(engine,state))
                if attempt<retries:
                    # 只在确认没有新回答时恢复页面，避免打断正在生成的有效回答。
                    try:
                        self._pg.reload(timeout=60000,wait_until='domcontentloaded')
                        self._pg.wait_for_timeout(3500)
                    except Exception: pass
                    # 重试前重新等待全局节奏。
                    need=float(settings.WEBAI_MIN_INTERVAL)*_rnd.uniform(1.0,2.0)
                    gap=time.time()-_last_call[0]
                    if gap<need: time.sleep(need-gap)
            except Exception as e:
                last_error=str(e)[:180]
                print('[webai] %s 异常(attempt=%d): %s'%(engine,attempt+1,last_error))
                if attempt<retries:
                    try:
                        self._pg.reload(timeout=60000,wait_until='domcontentloaded'); self._pg.wait_for_timeout(3000)
                    except Exception: pass
        return None

    def ask_json(self,question,engine=None,timeout=None,retries=1):
        """网页AI结构化回答。解析失败只返回 None，不把解析失败当作业务拒绝。"""
        raw=self.ask(question,engine=engine,timeout=timeout,retries=retries)
        if not raw: return None
        text=raw.strip()
        if text.startswith('```'):
            text=re.sub(r'^```(?:json)?\s*','',text,flags=re.I)
            text=re.sub(r'\s*```$','',text)
        candidates=[]
        a=text.find('{'); b=text.rfind('}')
        if a>=0 and b>a: candidates.append(text[a:b+1])
        for cand in candidates:
            try:
                obj=json.loads(cand)
                if isinstance(obj,dict): return obj
            except Exception: pass
        return None

def identity_review(self, subject, timeout=None):
    """网页 DeepSeek 企业身份专家：结构化失败/不可用统一返回 degraded。"""
    prompt=(
        '你是企业真实性与客户身份确认专家。请使用当前网页版 DeepSeek 的联网搜索能力主动核查企业公开网页、官网、公司资料，\n'
        '再与提供的海关/提单贸易事实交叉比对。普通网页只能用于身份核查，不能凭普通网页创建贸易关系。\n'
        '判定：confirmed=有充分身份对应且无明显冲突；suspect=资料不足但无明确冲突；rejected=明确对应错误企业、身份冲突或明显虚假。\n'
        '不要因为官网、邮箱、电话缺失就 rejected。若无法联网/无法有效回答，不得猜测，返回 degraded。\n'
        '只输出JSON：{"verdict":"confirmed|suspect|rejected|degraded","confidence":0-1,'
        '"canonical_name":"最终确认的企业法定/官网名称","aliases":["海关或品牌别名"],'
        '"reason":"160字内","identity":"身份结论","missing":["关键缺口"],"sources":["核查页面名称"]}\n\n'
        '待核查事实：\n'+str(subject)[:9000]
    )
    parsed=self.ask_json(prompt,engine='deepseek',timeout=timeout or settings.WEBAI_TIMEOUT,retries=1)
    if not parsed:
        return {'verdict':'degraded','confidence':0,'reason':'网页版 DeepSeek 未返回可解析的专家结论；保留贸易事实，等待复核',
                'identity':'','canonical_name':'','aliases':[],'missing':[],'sources':[],'engine':'deepseek_web','degraded':True}
    verdict=str(parsed.get('verdict') or 'suspect').lower()
    if verdict not in ('confirmed','suspect','rejected','degraded'): verdict='suspect'
    try: confidence=float(parsed.get('confidence') or 0)
    except Exception: confidence=0.0
    return {'verdict':verdict,'confidence':max(0,min(1,confidence)),
            'canonical_name':str(parsed.get('canonical_name') or parsed.get('identity') or '')[:300],
            'aliases':[str(x)[:200] for x in (parsed.get('aliases') or []) if str(x).strip()][:10],
            'reason':str(parsed.get('reason') or '')[:300],
            'identity':str(parsed.get('identity') or '')[:300],
            'missing':parsed.get('missing') or [],'sources':parsed.get('sources') or [],
            'engine':'deepseek_web','degraded':verdict=='degraded'}

def verify_claims(self, subject, timeout=None):
    """网页 DeepSeek 小上下文事实核验：逐字段判断网页公开信息是否支持/冲突。
    只做验证，不创建贸易关系；无法核查时返回 degraded。"""
    prompt=(
        '你是企业资料真实性核验专家。请使用当前网页版 DeepSeek 的联网搜索主动核查公开网页/官网。'
        '海关/提单记录只是待核对事实，不代表客户字段100%正确。重点检查公司身份、官网、地址、电话、邮箱和联系人。'
        '发现明显错误（例如不存在的电话、明显错误邮箱、属于另一家公司的联系方式）必须指出。'
        '同一字段存在多个候选值时不要擅自删除，分别判断并保留可验证值。不要因为缺少资料而判错。'
        '不得创建或推断客户-供应商贸易关系。若网页无法访问、未登录、无法完成搜索或回答不可靠，返回 degraded。'
        '只输出JSON，尽量短：'
        '{"identity":"confirmed|suspect|rejected|degraded","confidence":0-1,'
        '"canonical_name":"","reason":"100字内",'
        '"fields":[{"field":"phone|email|website|address|name|contact_person","value":"","status":"verified|suspect|invalid|not_found","reason":"60字内","source":"页面名称或URL"}],'
        '"contacts":[{"name":"","title":"","email":"","phone":"","status":"verified|suspect|invalid","reason":"60字内","source":"页面名称或URL"}]}'
        '\n\n待核验资料：\n'+str(subject)[:5200]
    )
    parsed=self.ask_json(prompt,engine='deepseek',timeout=timeout or settings.WEBAI_TIMEOUT,retries=1)
    if not parsed:
        return {'identity':'degraded','confidence':0,'canonical_name':'','reason':'网页 DeepSeek 未返回可解析核验结果',
                'fields':[],'contacts':[],'engine':'deepseek_web','degraded':True}
    identity=str(parsed.get('identity') or 'suspect').lower()
    if identity not in ('confirmed','suspect','rejected','degraded'): identity='suspect'
    try: conf=float(parsed.get('confidence') or 0)
    except Exception: conf=0.0
    fields=[]
    for x in parsed.get('fields') or []:
        if isinstance(x,dict) and str(x.get('value') or '').strip():
            st=str(x.get('status') or 'suspect').lower()
            if st not in ('verified','suspect','invalid','not_found'): st='suspect'
            fields.append({'field':str(x.get('field') or '')[:40],'value':str(x.get('value') or '')[:300],
                           'status':st,'reason':str(x.get('reason') or '')[:120], 'source':str(x.get('source') or '')[:300]})
    contacts=[]
    for x in parsed.get('contacts') or []:
        if isinstance(x,dict) and any(str(x.get(k) or '').strip() for k in ('name','email','phone')):
            st=str(x.get('status') or 'suspect').lower()
            if st not in ('verified','suspect','invalid'): st='suspect'
            contacts.append({'name':str(x.get('name') or '')[:150],'title':str(x.get('title') or '')[:120],
                             'email':str(x.get('email') or '')[:200],'phone':str(x.get('phone') or '')[:80],
                             'status':st,'reason':str(x.get('reason') or '')[:120],'source':str(x.get('source') or '')[:300]})
    return {'identity':identity,'confidence':max(0,min(1,conf)),
            'canonical_name':str(parsed.get('canonical_name') or '')[:300],
            'reason':str(parsed.get('reason') or '')[:300], 'fields':fields,'contacts':contacts,
            'engine':'deepseek_web','degraded':identity=='degraded'}

WebAI.verify_claims=verify_claims

WebAI.identity_review=identity_review

def solve(problem,context='',engines=None,timeout=None):
    """难题终结者：本地解决不了的核心问题，按引擎链逐个问，拿到第一个有效回答。"""
    engines=engines or [settings.WEBAI_ENGINE]+[e for e in ('deepseek','chatgpt') if e!=settings.WEBAI_ENGINE]
    prompt=(problem+'\n\n背景上下文：\n'+str(context)[:3000]) if context else problem
    w=WebAI()
    try:
        w._launch()
        for eng in engines:
            r=w.ask(prompt,engine=eng,timeout=timeout)
            if r and len(r.strip())>10:
                print('[webai] 难题已由 %s 解决(%d字)'%(eng,len(r)))
                return r
            print('[webai] %s 无有效回答, 换下一引擎'%eng)
        return None
    except Exception as e:
        print('[webai] solve failed:',str(e)[:100]); return None
    finally: w.close()

def ask(question,engine=None,timeout=None):
    """一次性入口：自动开/关浏览器页。"""
    w=WebAI()
    try:
        w._launch()
        return w.ask(question,engine=engine,timeout=timeout)
    except Exception as e:
        print('[webai] failed:',str(e)[:100]); return None
    finally: w.close()

if __name__=='__main__':
    import sys
    if len(sys.argv)>2 and sys.argv[1]=='diag':
        eng=sys.argv[2]
        q=sys.argv[3] if len(sys.argv)>3 else '请只回答两个字：收到'
        print('== 网页AI诊断:',eng,'==')
        print('引擎URL:',ENGINES.get(eng,{}).get('url'))
        print('每日上限:',settings.WEBAI_DAILY_MAX,'| 间隔:',settings.WEBAI_MIN_INTERVAL,'s')
        r=ask(q,engine=eng,timeout=90)
        print('回答:',(r or '(无)')[:200])
    else:
        print('用法: python -m core.tools.web_ai diag deepseek "问题"')
