# -*- coding: utf-8 -*-
"""Customs Graph 网络扩张：两轮共享实体编排。

当前模块说明：
- 扩张是任务不是页面：expansion_tasks 表驱动，进度面板可读，断点续跑（已完成策略不重跑）。
- 策略注册表 6 种（只保留有真实数据源的）：
  1 customer_suppliers   客户→供应商→客户（ImportYeti 网页，双向收割）
  2 supplier_customers   供应商→客户（供应商种子直接开 Customers 区）
  3 importer_suppliers   进口商→供应商（开发池买家种子，同1不同种子池）
  4 exporter_customers   出口商→客户（供应商池种子，同2不同种子池）
  5 same_product_importers 同产品进口商（本地：同产品域未开发实体提入开发候选，不造边）
  6 cross_market_entity  同实体跨市场（本地：证据显示既是客户又是供应商→kind='both'）
  （同品牌/同地址/网站/联系人组织 4 种无数据源，不做——做了就是假功能）
- 信息增益停止：单轮增益 < min_gain 切策略；连续 2 轮零增益停止；预算/深度只是安全帽。
- 交叉去重入库不变：所有实体经 db.commit_network_entity，已存在只合并证据，绝不重置区域/开发状态。
"""
import re,time,json
from core.config import settings
from core.memory.db import DB
from core.tools import suppliers as sup
from core.trade_graph.trade_node import evidence_level, EVIDENCE_DEMOTE
from core.runtime.postflow import PostFlowTracker

STRATEGIES={
 'customer_suppliers':{'label':'客户→供应商→客户','kind':'web'},
 'supplier_customers':{'label':'供应商→客户','kind':'web'},
 'importer_suppliers':{'label':'进口商→供应商','kind':'web'},
 'exporter_customers':{'label':'出口商→客户','kind':'web'},
 'same_product_importers':{'label':'同产品进口商','kind':'local'},
 'cross_market_entity':{'label':'同实体跨市场','kind':'local'},
}
DEFAULT_ORDER=['customer_suppliers','supplier_customers','same_product_importers','cross_market_entity']
# 种子池差异：1/3 与 2/4 共用收割函数，只是种子不同——注册表各策略真实可执行。
SEED_POOL={'customer_suppliers':('customer','dev'),'importer_suppliers':('customer','pending'),
           'supplier_customers':('supplier','dev'),'exporter_customers':('supplier','pool')}


class _WebSession:
    """一次 IY 会话内执行多个 web 策略：页访预算 + 连续失败熔断 共享。"""
    def __init__(self, task_id, stats, customers_per, suppliers_per, root_domain=''):
        from core.trade_graph import iy_network as iyn
        self.iyn=iyn; self.task_id=task_id; self.stats=stats
        self.customers_per=customers_per; self.suppliers_per=suppliers_per
        self.budget=iyn.PageBudget(); self.fails=0; self.w=None
        # current 品类隔离：扩张产出实体与边全部打上根产品域，三品类不混
        self.root_domain=str(root_domain or '')

    def __enter__(self):
        from core.tools import iy_web
        if not iy_web.available(): raise RuntimeError('ImportYeti网页未就绪')
        self.w=iy_web.IYWeb(); return self

    def __exit__(self,*a):
        try: self.w.close()
        except Exception: pass

    def harvest_supplier(self, db, s_norm, s_name, s_slug, d, via):
        """打开供应商页拉客户：客户去重入库 + supplier→customer 边。返回(新增数,新frontier)。"""
        added=0; new_front=[]
        if self.iyn.node_fresh(s_norm,'supplier'):
            existing=db.list_trade_edges(norm=s_norm,category_id=self.root_domain or None)
            if any(e.get('relation') in ('customer_of','supplier_of') for e in existing): return 0,[]
        url=('https://www.importyeti.com/supplier/'+s_slug) if s_slug else self.iyn.node_url(s_norm,'supplier')
        if not url:
            if not self.budget.take('search:'+str(s_name)[:40]): return 0,[]
            url=self.w.supplier_page_for(s_name) or ''
        if not url:
            self.stats['errors'].append(f'{s_name}: 未解析到 ImportYeti 供应商主页'); return 0,[]
        if not self.budget.take('page:'+url[-60:]): return 0,[]
        try:
            custs=self.w.relationships(url,'Customers')[:self.customers_per]
            if not custs and self.w.last_error:
                self.fails+=1; return 0,[]
            self.fails=0
            self.iyn.mark_node(s_norm,'supplier',slug=s_slug or url.rstrip('/').split('/')[-1],url=url,run_id=self.task_id or '')
            for c in custs:
                nm=c.get('name') or ''
                if not DB._norm(nm): continue
                ev={'customs':True,'trade_evidence':True,'iy_verified':True,'shipments':c.get('shipments') or 0,
                    'products':c.get('products') or '','url':c.get('url') or url,'supplier_relation':s_name}
                r=db.commit_network_entity(nm,'customer',evidence=ev,source=f'network_expand:d{d}',zone_new='dev',product_domain=self.root_domain)
                try: db.upsert_trade_node(nm,role='buyer',url=ev.get('url',''),shipments=ev.get('shipments') or 0,products=ev.get('products',''),depth=d+1,via=s_name,source='network_expand')
                except Exception: pass
                if r.get('created'):
                    self.stats['new_leads']+=1; added+=1
                    db.mark_frontier(r['norm'],'pending',depth=d+1,task_id=self.task_id)
                    new_front.append(db.get_lead(r['norm']))
                _ev={'shipments':c.get('shipments'),'products':c.get('products') or '','url':url,'iy_verified':True}
                _lvl=evidence_level(_ev,'importyeti_web')
                db.add_relationship(self.task_id,s_name,'supplier',nm,'buyer','supplier_to_customer',
                                    _ev,'importyeti_web',
                                    confidence=min(.9 if c.get('shipments') else .75, EVIDENCE_DEMOTE.get(_lvl,1.0)),
                                    depth=d+1,evidence_level=_lvl,
                                    discovered_via=str(via or ''),parent_node=s_name,
                                    expansion_path=f'{s_name} → {nm}',product_domain=self.root_domain)
                try:
                    db.save_trade_edge(s_name,nm,'customer_of',product=c.get('products') or '',
                                       shipment_count=int(c.get('shipments') or 0),evidence=json.dumps(_ev,ensure_ascii=False),
                                       source_type='importyeti_web',confidence=min(.9 if c.get('shipments') else .75, EVIDENCE_DEMOTE.get(_lvl,1.0)),
                                       category_id=category_id if 'category_id' in locals() else None)
                except Exception:
                    pass
                try: db.add_to_customer_pool(DB._norm(nm),nm,self.root_domain or '', 'network_expansion', self.task_id or '')
                except Exception: pass
            sup.mark_harvested(s_norm,len(custs))
            sup.log_harvest(self.task_id or '',s_slug or '',s_name,'network_expand','ok',len(custs),f'depth={d};new={added};via={via}')
        except Exception as e:
            self.stats['errors'].append(f'{s_name}:{str(e)[:80]}')
        return added,new_front

    def scan_buyer(self, db, buyer, d, via, harvest_suppliers=True):
        """打开买家页拉供应商（入库+buyer→supplier 边），并逐个收割供应商客户。返回(新增数,新frontier)。"""
        added=0; new_front=[]
        bn_=sup.norm(buyer['name'])
        if self.iyn.node_fresh(bn_,'company'):
            existing=db.list_trade_edges(norm=bn_,category_id=self.root_domain or None)
            if any(e.get('relation') in ('supplier_of','customer_of') for e in existing): return 0,[]
        burl=str((buyer.get('evidence') or {}).get('url') or '') if isinstance(buyer.get('evidence'),dict) else ''
        if '/company/' not in burl: burl=self.iyn.node_url(bn_,'company')
        if '/company/' not in burl:
            if not self.budget.take('search:'+str(buyer['name'])[:40]): return 0,[]
            burl=self.w.company_page_for(buyer['name']) or ''
        if not burl:
            self.fails+=1; self.stats['errors'].append(f'{buyer["name"]}: 未解析到 ImportYeti 公司主页'); return 0,[]
        if not self.budget.take('page:'+burl[-60:]): return 0,[]
        rows=self.w.relationships(burl,'Suppliers')[:self.suppliers_per]
        if not rows and self.w.last_error: self.fails+=1; return 0,[]
        self.fails=0
        self.iyn.mark_node(bn_,'company',slug=burl.rstrip('/').split('/')[-1],url=burl,run_id=self.task_id or '')
        sup_entries=[]
        for r in rows:
            nm=r.get('name') or '';sn=sup.norm(nm)
            if not sn:continue
            sup_entries.append({'norm':sn,'name':nm,'slug':r.get('url','').rstrip('/').split('/')[-1] if r.get('url') else '','shipments':r.get('shipments') or 0,'last_seen':time.time(),'via':f'expand:d{d}:{buyer["name"]}'})
            ev={'customs':True,'trade_evidence':True,'iy_verified':True,'shipments':r.get('shipments') or 0,
                'products':r.get('products') or '','url':r.get('url') or burl,'customer_relation':buyer['name']}
            cr=db.commit_network_entity(nm,'supplier',evidence=ev,source=f'network_expand:d{d}',zone_new='dev',product_domain=self.root_domain)
            try: db.upsert_trade_node(nm,role='supplier',url=ev.get('url',''),shipments=ev.get('shipments') or 0,products=ev.get('products',''),depth=d,via=buyer['name'],source='network_expand')
            except Exception: pass
            if cr.get('created'): self.stats['new_suppliers']+=1
            _ev={'shipments':r.get('shipments'),'products':r.get('products') or '','url':r.get('url') or burl,'iy_verified':True}
            _lvl=evidence_level(_ev,'importyeti_web')
            db.add_relationship(self.task_id,buyer['name'],'buyer',nm,'supplier','buyer_to_supplier',
                                _ev,'importyeti_web',
                                confidence=min(.9 if r.get('shipments') else .75, EVIDENCE_DEMOTE.get(_lvl,1.0)),
                                depth=d,evidence_level=_lvl,
                                discovered_via=str(via or ''),parent_node=buyer['name'],
                                expansion_path=f'{buyer["name"]} → {nm}',product_domain=self.root_domain)
        if sup_entries: sup.upsert_pool(sup_entries)
        if harvest_suppliers:
            for se in sup_entries:
                a,nf=self.harvest_supplier(db,se['norm'],se['name'],se.get('slug') or '',d,via)
                added+=a; new_front.extend(nf)
                if self.fails>=2: break
        return added,new_front

    def harvest_supplier_list(self, db, suppliers, d, via):
        """批量收割供应商客户：供应商池先全局去重，再逐个抓 Customers。"""
        added=0; new_front=[]
        for se in suppliers:
            if self.fails>=2: break
            try:
                a,nf=self.harvest_supplier(db,se['norm'],se['name'],se.get('slug') or '',d,via)
                added += a; new_front.extend(nf)
            except Exception as e:
                self.stats['errors'].append(f"{se.get('name','')}: {str(e)[:80]}")
        return added,new_front


def run_network_two_rounds(task_id=None, seed_norms=None, category_id=None,
                           buyers_per=None, suppliers_per=None, customers_per=None,
                           max_new=None, root_domain=''):
    """两轮贸易网络扩张（共享实体库/条件边版）。

    设计原则：
    - 关系只能来自 customs_raw；本地没有关系时才使用 ImportYeti 的美国海关提单网页证据。
    - 不再把“身份核验/信息补全”作为网络扩张阻塞节点。
    - 不再设置供应商去重/客户去重节点；共享数据库按 norm 实体唯一化，重复发现写入 expansion_logs。
    - Round 2 直接消费 Round 1 新发现客户的贸易事实，不等待网页资料补全。
    - 所有新客户统一进入独立的信息补全队列，补全与网络扩张解耦。
    """
    db=DB()
    from core.config import settings
    from core.tools import customs_graph
    task_id=task_id or 'net2_'+str(int(time.time()))
    suppliers_per=int(suppliers_per or settings.NETWORK_EXPANSION_SUPPLIERS)
    customers_per=int(customers_per or settings.NETWORK_EXPANSION_CUSTOMERS)
    max_new=int(max_new or settings.NETWORK_EXPANSION_MAX_NEW)
    root_domain=str(root_domain or category_id or '')
    stats={'task_id':task_id,'status':'running','rounds':[],
           'seed_customers':0,'round1_new_customers':0,'round2_new_customers':0,
           'supplier_pool':0,'new_customers':0,'discovered_customer_norms':[],
           'supplier_norms':[],'new_suppliers':0,'new_edges':0,'customs_edges':0,
           'duplicate_discoveries':0,'errors':[],'category_id':category_id,'root_domain':root_domain}
    db.create_task(task_id=task_id,task_name='网络扩张 · 共享实体两轮海关贸易裂变',
                   task_type='network_expansion_batch',category_id=category_id)

    flow=PostFlowTracker(db,task_id,'network_expansion',['INPUT_CUSTOMERS','R1_CUSTOMER_TO_SUPPLIER','R1_SUPPLIER_TO_CUSTOMER','R1_NEW_CUSTOMERS','R2_CUSTOMER_TO_SUPPLIER','R2_SUPPLIER_TO_CUSTOMER','GLOBAL_ENTITY_MERGE','COMPLETED'])
    previous_stage=None

    def stage(name,pct,msg='',condition=None):
        nonlocal previous_stage
        if previous_stage and previous_stage in flow.state['node_status'] and previous_stage != name:
            flow.state['node_status'][previous_stage]='SUCCESS'
        flow.checkpoint(name,'SUCCESS' if name=='COMPLETED' else 'RUNNING',pct,
                        shared_data={'seed_customers':stats['seed_customers'],'supplier_pool':stats['supplier_pool'],
                                     'new_customers':stats['new_customers'],'new_suppliers':stats['new_suppliers'],
                                     'new_edges':stats['new_edges'],'duplicate_discoveries':stats['duplicate_discoveries'],
                                     'customs_edges':stats['customs_edges'],'round1_new_customers':stats['round1_new_customers'],
                                     'round2_new_customers':stats['round2_new_customers']},
                        condition=condition,message=msg)
        previous_stage=name

    def hard_trade_fact(norm,name=''):
        """一次 SQL 门禁：只判断是否存在海关事实，不调用网页AI。"""
        try:
            with db.c() as x:
                row=x.execute("""SELECT 1 FROM customs_raw
                                WHERE importer_norm=? OR shipper=? OR notify=?
                                   OR lower(importer)=lower(?) OR lower(notify)=lower(?)
                                LIMIT 1""",(norm,norm,norm,name or norm,name or norm)).fetchone()
                if row: return True
        except Exception as e:
            stats['errors'].append('seed_fact:'+str(e)[:120])
        try:
            edges=db.list_trade_edges(norm=norm,category_id=category_id or root_domain or None)
            return any(int(e.get('shipment_count') or 0)>0 and
                       str(e.get('source_type') or '').lower() in
                       ('customs_raw','customs_trade','importyeti_web','importyeti_penetration') for e in edges)
        except Exception: return False

    def seed_candidates():
        if seed_norms:
            raw=[str(n).strip() for n in seed_norms if str(n or '').strip()]
        else:
            rows=db.list_customer_pool(category_id=category_id or root_domain or None)
            raw=[r.get('norm') for r in rows if r.get('norm')]
            if not raw:
                rows=db.list_leads(kind='customer',limit=10000,domain=root_domain or None)
                raw=[r.get('norm') for r in rows if r.get('norm')]
        # 一次批量 SQL，避免原版本对每个客户反复打开查询/实体读取造成“第一节点卡半小时”。
        raw=list(dict.fromkeys(raw))[:10000]
        if not raw: return []
        out=[]
        try:
            placeholders=','.join('?' for _ in raw)
            with db.c() as x:
                x.row_factory=__import__('sqlite3').Row
                rows=x.execute(f"SELECT norm,name FROM leads WHERE norm IN ({placeholders})",raw).fetchall()
                names={r['norm']:r['name'] for r in rows}
                rows=x.execute(f"SELECT norm,name FROM entities WHERE norm IN ({placeholders})",raw).fetchall()
                for r in rows: names[r['norm']]=r['name'] or names.get(r['norm']) or r['norm']
                facts=set(r[0] for r in x.execute(f"""SELECT DISTINCT importer_norm FROM customs_raw
                    WHERE importer_norm IN ({placeholders}) AND importer_norm<>''""",raw).fetchall())
            # 再补一张统一 trade_edges 的批量硬证据索引；不要逐客户执行 SQL。
            edge_facts=set()
            if raw:
                placeholders2=','.join('?' for _ in raw)
                edge_rows=x.execute(f"SELECT DISTINCT from_norm FROM trade_edges WHERE from_norm IN ({placeholders2}) AND shipment_count>0 AND lower(COALESCE(source_type,'')) IN ('customs_raw','customs_trade','importyeti_web','importyeti_penetration') UNION SELECT DISTINCT to_norm FROM trade_edges WHERE to_norm IN ({placeholders2}) AND shipment_count>0 AND lower(COALESCE(source_type,'')) IN ('customs_raw','customs_trade','importyeti_web','importyeti_penetration')",raw+raw).fetchall()
                edge_facts={str(r[0]) for r in edge_rows if r[0]}
            for n in raw:
                nm=names.get(n) or n
                if n in facts or n in edge_facts: out.append({'norm':n,'name':nm})
        except Exception:
            for n in raw:
                nm=(db.get_lead(n) or db.get_entity(n) or {}).get('name') or n
                if hard_trade_fact(n,nm): out.append({'norm':n,'name':nm})
        return out

    def persist_rel(rel,depth,label):
        ev=rel.get('evidence') or {}
        if not isinstance(ev,dict): ev={}
        if not ev.get('customs') and not ev.get('trade_evidence'):
            return False
        shipments=int(ev.get('shipments') or rel.get('shipment_count') or 0)
        if shipments<=0: return False
        fn=rel.get('from_norm') or customs_graph.norm(rel.get('from_name') or '')
        tn=rel.get('to_norm') or customs_graph.norm(rel.get('to_name') or '')
        if not fn or not tn: return False
        relation=rel.get('relation') or 'buyer_to_supplier'
        mapped={'buyer_to_supplier':'supplier_of','supplier_to_buyer':'customer_of','supplier_to_customer':'customer_of'}
        product_v=ev.get('products') or rel.get('product') or ''
        hs_v=ev.get('hs') or rel.get('hs') or ''
        if isinstance(product_v,(list,tuple)): product_v=', '.join(str(v) for v in product_v)
        if isinstance(hs_v,(list,tuple)): hs_v=', '.join(str(v) for v in hs_v)
        ev_json=json.dumps(ev,ensure_ascii=False,default=str)
        db.save_trade_edge(fn,tn,mapped.get(relation,relation),product=str(product_v)[:500],
                           hs_code=str(hs_v)[:300],shipment_count=shipments,
                           evidence=ev_json,source_type='customs_raw',
                           confidence=float(rel.get('confidence') or 1),category_id=category_id or root_domain)
        # 任务级关系日志用于执行面板/扩张路径；共享 trade_edges 仍是统一实体事实库。
        try:
            fe=db.get_or_create_entity(fn,rel.get('from_name') or fn); te=db.get_or_create_entity(tn,rel.get('to_name') or tn)
            with db.c() as x:
                x.execute("""INSERT OR IGNORE INTO relationships
                    (task_id,from_norm,from_name,from_type,to_norm,to_name,to_type,relation,evidence,source,confidence,depth,created_at,shipment_count,hs,product,product_domain)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (task_id,fn,rel.get('from_name') or fn,rel.get('from_type') or 'buyer',tn,rel.get('to_name') or tn,rel.get('to_type') or 'supplier',
                     relation,ev_json,'customs_raw',float(rel.get('confidence') or 1),int(depth),time.time(),shipments,str(hs_v)[:300],str(product_v)[:500],category_id or root_domain))
                x.commit()
        except Exception as ee:
            stats['errors'].append(f'relationship_log:{str(ee)[:120]}')
        db.log_expansion(task_id,depth,label,db.get_or_create_entity(fn,fn).get('entity_id'),fn,rel.get('from_name') or fn,
                         'customer',relation,evidence=json.dumps(ev,ensure_ascii=False,default=str),confidence=float(rel.get('confidence') or 1),
                         category_id=category_id or root_domain)
        stats['customs_edges']+=1
        return True

    def record_entity(name,kind,evidence,depth,label):
        nm=(name or '').strip();
        if not nm: return None
        ev=evidence if isinstance(evidence,dict) else {}
        r=db.commit_network_entity(nm,kind,evidence=ev,source='network_customs_raw',zone_new='dev',
                                   product_domain=category_id or root_domain)
        n=r.get('norm') or customs_graph.norm(nm)
        ent=db.get_entity(n) or {}
        db.upsert_trade_node(nm,role='supplier' if kind=='supplier' else 'importer',
                             shipments=ev.get('shipments') or 0,products=ev.get('products') or '',
                             hs=ev.get('hs') or [],depth=depth,via=label,source='customs_raw',
                             product_domain=category_id or root_domain)
        # 共享实体条件边：已存在不删除、不重复建实体，只记录“再次发现”。
        if not r.get('created'):
            stats['duplicate_discoveries']+=1
            try:
                db.log_expansion(task_id,depth,'shared_entity_duplicate',ent.get('entity_id'),n,nm,kind,
                                 'duplicate_discovery',evidence=json.dumps(ev,ensure_ascii=False,default=str),
                                 confidence=1,category_id=category_id or root_domain)
            except Exception: pass
        # Shared customer/supplier pool is the handoff surface for Intelligence Center,
        # Business Center and the next network round. Never rely on the leads table alone.
        try:
            if kind=='customer':
                db.add_to_customer_pool(n,nm,category_id or root_domain,'network_expansion',task_id)
            else:
                db.add_to_supplier_pool(n,nm,category_id or root_domain,'network_expansion',task_id)
        except Exception as e:
            stats['errors'].append(f'pool_handoff:{n}:{str(e)[:100]}')
        return {'norm':n,'name':nm,'evidence':ev,'created':bool(r.get('created'))}

    def local_customer_to_suppliers(buyer_names,depth,label):
        suppliers,rels=customs_graph.buyer_to_suppliers([{'name':n} for n in buyer_names],suppliers_per)
        supplier_map={}
        for item in suppliers or []:
            sn=item.get('norm') or customs_graph.norm(item.get('name'))
            if not sn: continue
            supplier_map.setdefault(sn,item)
            record_entity(item.get('name') or sn,'supplier',item.get('evidence') or {},depth,label)
        for rel in rels or []: persist_rel(rel,depth,label)
        return list(supplier_map.values())

    def local_supplier_to_customers(suppliers,depth,label):
        buyers,rels=customs_graph.supplier_to_buyers(suppliers,customers_per)
        for rel in rels or []: persist_rel(rel,depth,label)
        return buyers or []

    def fallback_iY_customer_to_suppliers(buyer_names,depth,label,ws_holder):
        from core.tools import iy_web
        if ws_holder[0] is None:
            if not iy_web.available(): raise RuntimeError('本地 customs_raw 无对应关系，且 ImportYeti 网页未就绪')
            ws_holder[0]=_WebSession(task_id,stats,customers_per,suppliers_per,root_domain=root_domain); ws_holder[0].__enter__()
        ws=ws_holder[0]; supplier_map={}
        for bn in buyer_names:
            try:
                buyer=db.get_lead(bn) or db.get_entity(bn) or {'norm':bn,'name':bn}
                ws.scan_buyer(db,buyer,depth,label,harvest_suppliers=False)
                rels=db.list_relationships(task_id=task_id,norm=bn,limit=5000,domain=category_id or root_domain)
                for rel in rels:
                    if rel.get('relation')=='buyer_to_supplier' and int(rel.get('shipment_count') or 0)>0:
                        sn=rel.get('to_norm')
                        if sn: supplier_map.setdefault(sn,{'norm':sn,'name':rel.get('to_name') or sn,'slug':''})
            except Exception as e: stats['errors'].append(f'{label}:buyer:{bn}:{str(e)[:100]}')
        return list(supplier_map.values())

    def fallback_iY_supplier_to_customers(suppliers,depth,label,ws_holder):
        from core.tools import iy_web
        if ws_holder[0] is None:
            if not iy_web.available(): raise RuntimeError('ImportYeti网页未就绪')
            ws_holder[0]=_WebSession(task_id,stats,customers_per,suppliers_per,root_domain=root_domain); ws_holder[0].__enter__()
        ws=ws_holder[0]; customer_map={}
        for se in suppliers:
            try:
                _,nf=ws.harvest_supplier(db,se.get('norm'),se.get('name') or se.get('norm'),se.get('slug') or '',depth,label)
                for c in nf or []:
                    if isinstance(c,dict) and c.get('norm'): customer_map.setdefault(c['norm'],c)
            except Exception as e: stats['errors'].append(f'{label}:supplier:{se.get("name")}: {str(e)[:100]}')
        return list(customer_map.values())

    ws_holder=[None]
    try:
        # 01：只做共享数据库输入，绝不在这里调用信息补全或网页AI。
        stage('INPUT_CUSTOMERS',2,'读取共享客户库 + 海关事实索引；不做网页AI，不阻塞网络扩张')
        seeds=seed_candidates(); stats['seed_customers']=len(seeds)
        if not seeds:
            db.update_task(task_id,run_status='blocked',current_stage='INPUT_CUSTOMERS',current_node='INPUT_CUSTOMERS',progress_pct=100,
                           failure_reason='共享客户库中没有具备海关/提单事实的客户',completed_at=time.time())
            stats['status']='blocked'; stats['errors'].append('no_customs_seed_customers'); return stats
        db.save_task_log(task_id,'input_customers',f'共享客户输入完成：{len(seeds)} 家；身份核验/信息补全已与网络扩张解耦')

        # Round 1: two explicit nodes; both consume the same shared database state.
        seed_names=[x['name'] for x in seeds]
        stage('R1_CUSTOMER_TO_SUPPLIER',12,f'第一轮：{len(seeds)} 家客户 → 供应商；先读取本地海关/提单关系',condition={'edge':'seed_ready','taken':True})
        r1_suppliers=local_customer_to_suppliers(seed_names,1,'round1_customs_raw')
        r1_local_had=bool(r1_suppliers)
        if not r1_local_had:
            db.save_task_log(task_id,'round1_fallback','customs_raw 无第一轮客户→供应商关系，条件边切换 ImportYeti 海关提单证据源')
            r1_suppliers=fallback_iY_customer_to_suppliers(seed_names,1,'round1_importyeti_customs',ws_holder)
        stage('R1_SUPPLIER_TO_CUSTOMER',30,f"第一轮：{len(r1_suppliers)} 家供应商 → 客户；关系源：{'本地海关' if r1_local_had else 'ImportYeti海关提单'}",condition={'edge':'trade_source_route','taken':r1_local_had,'fallback':'importyeti_customs'})
        r1_buyers=local_supplier_to_customers(r1_suppliers,1,'round1_customs_supplier_to_customer') if r1_local_had else fallback_iY_supplier_to_customers(r1_suppliers,1,'round1_importyeti_supplier_to_customer',ws_holder)
        r1_customers={}
        for b in r1_buyers or []:
            nm=b.get('name') or ''; n=customs_graph.norm(nm)
            if not n: continue
            rec=record_entity(nm,'customer',b.get('evidence') or {},2,'round1_customer')
            if rec and rec.get('created') and n not in {x['norm'] for x in seeds}:
                r1_customers.setdefault(n,rec)
        if max_new > 0 and len(r1_customers) > max_new:
            r1_customers=dict(list(r1_customers.items())[:max_new])
            db.save_task_log(task_id,'r1_budget',f'第一轮新增客户达到安全上限 {max_new} 家，后续只处理已截取的客户')
        stats['round1_new_customers']=len(r1_customers); stats['new_customers']=len(r1_customers)
        stage('R1_NEW_CUSTOMERS',42,f'第一轮新增客户 {len(r1_customers)} 家；不等待补全，直接进入第二轮',condition={'edge':'r1_new_customers','taken':bool(r1_customers)})

        # Round 2 directly consumes Round 1 customer records from the shared entity/trade state.
        r2_names=[x['name'] for x in r1_customers.values()]
        stage('R2_CUSTOMER_TO_SUPPLIER',52,f'第二轮：{len(r2_names)} 家第一轮新增客户 → 供应商；不等待信息补全',condition={'edge':'r2_seed_available','taken':bool(r2_names)})
        r2_suppliers=local_customer_to_suppliers(r2_names,3,'round2_customs_raw') if r2_names else []
        r2_local_had=bool(r2_suppliers)
        if r2_names and not r2_local_had:
            try: r2_suppliers=fallback_iY_customer_to_suppliers(r2_names,3,'round2_importyeti_customs',ws_holder)
            except Exception as e: stats['errors'].append(f'R2_FALLBACK:{str(e)[:140]}')
        stage('R2_SUPPLIER_TO_CUSTOMER',78,f"第二轮：{len(r2_suppliers)} 家供应商 → 客户；关系源：{'本地海关' if r2_local_had else 'ImportYeti海关提单' if r2_names else '无新增客户'}",condition={'edge':'trade_source_route','taken':r2_local_had,'fallback':'importyeti_customs','seed_available':bool(r2_names)})
        r2_buyers=local_supplier_to_customers(r2_suppliers,3,'round2_customs_supplier_to_customer') if r2_local_had else fallback_iY_supplier_to_customers(r2_suppliers,3,'round2_importyeti_supplier_to_customer',ws_holder) if r2_suppliers else []
        r2_customers={}
        seed_set={x['norm'] for x in seeds}
        for b in r2_buyers or []:
            nm=b.get('name') or ''; n=customs_graph.norm(nm)
            if not n: continue
            rec=record_entity(nm,'customer',b.get('evidence') or {},4,'round2_customer')
            if rec and rec.get('created') and n not in seed_set and n not in r1_customers:
                r2_customers.setdefault(n,rec)
        remaining=max(0,max_new-len(r1_customers)) if max_new>0 else len(r2_customers)
        if max_new > 0 and len(r2_customers) > remaining:
            r2_customers=dict(list(r2_customers.items())[:remaining])
            db.save_task_log(task_id,'r2_budget',f'第二轮新增客户受全局安全上限约束：剩余名额 {remaining} 家')
        stats['round2_new_customers']=len(r2_customers); stats['new_customers']=len(r1_customers)+len(r2_customers)
        stats['discovered_customer_norms']=list(r1_customers)+list(r2_customers)
        stats['supplier_norms']=list({(s.get('norm') or customs_graph.norm(s.get('name'))) for s in (r1_suppliers or [])+(r2_suppliers or []) if s.get('norm') or s.get('name')})
        stats['supplier_norms']=[x for x in stats['supplier_norms'] if x]
        stats['supplier_pool']=len(stats['supplier_norms']); stats['new_suppliers']=stats['supplier_pool']

        stage('GLOBAL_ENTITY_MERGE',90,f'共享数据库合并完成：供应商 {stats["supplier_pool"]}；新增客户 {stats["new_customers"]}；重复发现 {stats["duplicate_discoveries"]}',condition={'edge':'shared_entity_merge','taken':True})
        try: stats['new_edges']=int(db.c().execute('SELECT COUNT(*) FROM relationships WHERE task_id=?',(task_id,)).fetchone()[0])
        except Exception: stats['new_edges']=stats['customs_edges']
        # 信息补全不再属于网络扩张流程节点；网络链只把新增客户留在共享客户库，后续由独立补全队列处理。
        stage('COMPLETED',100,f'两轮网络扩张完成：供应商 {stats["new_suppliers"]}，新增客户 {stats["new_customers"]}，贸易边 {stats["new_edges"]}，重复发现 {stats["duplicate_discoveries"]}')
        db.update_task(task_id,run_status='completed',current_stage='COMPLETED',current_node='COMPLETED',progress_pct=100,
                       discovered_customers=stats['new_customers'],discovered_suppliers=stats['new_suppliers'],
                       new_edges=stats['new_edges'],completed_at=time.time())
        stats['rounds']=[{'round':1,'customer_seeds':len(seeds),'unique_suppliers':len({s.get('norm') for s in r1_suppliers or [] if s.get('norm')}),'new_customers':len(r1_customers)},
                         {'round':2,'customer_seeds':len(r2_names),'unique_suppliers':len({s.get('norm') for s in r2_suppliers or [] if s.get('norm')}),'new_customers':len(r2_customers)}]
        stats['status']='completed'; return stats
    except Exception as e:
        try: flow.checkpoint('GLOBAL_ENTITY_MERGE','FAILED',90,shared_data={'error':str(e)[:300]},message=f'网络扩张异常：{str(e)[:300]}')
        except Exception: pass
        stats['status']='failed'; stats['errors'].append(str(e)[:200])
        db.update_task(task_id,run_status='failed',current_stage='FAILED',current_node='FAILED',failure_reason=str(e)[:500],completed_at=time.time())
        db.save_task_log(task_id,'network_batch_error',str(e)[:300]); return stats
    finally:
        if ws_holder[0]:
            try: ws_holder[0].__exit__(None,None,None)
            except Exception: pass
