# -*- coding: utf-8 -*-
"""Business Execution Center (AUDITED & REPAIRED)

Fixes:
1. _check_outlook_login: Real Playwright detection
2. _simulate_send: Replaced with real browser automation
3. Clear prompt when Outlook not logged in
4. Full status tracking: DRAFT -> READY -> SENT / FAILED
"""
import time, json
from typing import Dict, List, Any, Optional
from core.memory.db import DB
from core.intelligence.ai_router import ai_route, ai_route_structured
from core.config import settings
from core.runtime.postflow import PostFlowTracker


class BusinessExecutionCenter:
    def __init__(self, db: DB = None):
        self.db = db or DB()

    def execute_business_flow(self, lead_norm: str, category_id: str = None,
                             our_product: str = None, our_company: str = None,
                             mode: str = "draft", allow_inline_enrichment: bool = True, task_id: str = None) -> Dict[str, Any]:
        """完整业务执行链：资料审核 → 详细画像再定位 → 补全 → 开发资格 → 开发信 → 草稿/发送。

        第一采集链不在此修改；这里只消费统一实体资产。mode 支持 preview、draft、send。
        """
        mode = str(mode or 'draft').lower()
        if mode not in ('preview', 'draft', 'send'):
            return {'ok': False, 'stage': 'input_validation', 'error': 'mode must be preview, draft or send'}

        entity = self.db.get_entity(lead_norm)
        if not entity:
            return {'ok': False, 'stage': 'entity_audit', 'error': 'Entity not found', 'action_required': 'RETURN_TO_INTELLIGENCE'}

        entity_id = entity['entity_id']
        task_id = task_id or f"biz-{int(time.time())}-{entity_id[-6:]}"
        self.db.create_task(task_id, f'业务执行：{entity.get("name") or lead_norm}', 'business_execution',
                            category_id, None)
        flow = PostFlowTracker(self.db, task_id, 'business_execution',
                               ['PROFILE_AUDIT','DETAILED_PROFILE','PROFILE_ENRICHMENT','QUALIFICATION','DEVELOPMENT_LETTER','OUTREACH','COMPLETED'])
        flow.checkpoint('PROFILE_AUDIT','RUNNING',5,
                        shared_data={'norm':lead_norm,'category_id':category_id,'shared_tables':['entities','entity_data_claims','contacts','trade_edges']},
                        message='业务节点1：读取统一客户资产并审核身份、联系人、证据')

        try:
            audit_before = self._profile_audit(entity_id)
            flow.checkpoint('PROFILE_AUDIT','SUCCESS',15,shared_data={'audit_completeness':audit_before['completeness']},message='业务节点1完成：客户资料审核通过')
            flow.handoff('PROFILE_AUDIT','DETAILED_PROFILE',{'norm':lead_norm,'audit':audit_before},['norm','audit'],message='审核结果交接给详细客户画像')
            self.db.save_task_log(task_id, 'business_execution',
                                  f"资料审核完成：完整度 {audit_before['completeness']}%，联系人 {audit_before['contacts']}，邮箱 {audit_before['emails']}")

            self.db.update_task(task_id, current_stage='DETAILED_PROFILE', current_node='DETAILED_PROFILE', progress_pct=25)
            flow.checkpoint('DETAILED_PROFILE','RUNNING',25,shared_data={'trade_data':'shared trade_edges','claims':'shared entity_data_claims'},message='业务节点2：基于共享贸易与资料数据生成详细客户画像')
            # 详细画像先调用统一 AI 验证；失败不伪造成功，继续保留确定性资料。
            validation = None
            try:
                validation = self._ai_profile_validation(lead_norm)
                self.db.save_task_log(task_id, 'business_execution',
                                      f"详细客户画像完成：{validation.get('model_used') or 'deterministic'}")
                flow.checkpoint('DETAILED_PROFILE','SUCCESS',35,shared_data={'profile_model':validation.get('model_used') or 'deterministic'},message='业务节点2完成：详细画像已交接')
                flow.handoff('DETAILED_PROFILE','PROFILE_ENRICHMENT',{'norm':lead_norm,'profile_ready':bool(validation.get('ok'))},['norm','profile_ready'],message='详细画像→资料补全节点交接')
            except Exception as e:
                validation = {'ok': False, 'error': str(e)[:300]}
                self.db.save_task_log(task_id, 'business_execution', f'详细画像 AI 暂不可用：{str(e)[:220]}；保留确定性画像')
                flow.checkpoint('DETAILED_PROFILE','SUCCESS',35,shared_data={'profile_model':'deterministic'},message='业务节点2降级完成：保留确定性画像')
                flow.handoff('DETAILED_PROFILE','PROFILE_ENRICHMENT',{'norm':lead_norm,'profile_ready':False},['norm','profile_ready'],message='确定性画像→资料补全节点交接')

            self.db.update_task(task_id, current_stage='PROFILE_ENRICHMENT', current_node='PROFILE_ENRICHMENT', progress_pct=45)
            flow.checkpoint('PROFILE_ENRICHMENT','RUNNING',45,shared_data={'enrichment_source':'independent_enrichment_queue'},message='业务节点3：消费独立信息补全结果')
            enrichment = self.db.get_intelligence(lead_norm)
            edata=enrichment.get('data') or {}
            completeness_value=edata.get('info_completeness')
            if completeness_value is None:
                completeness_value=(edata.get('completeness') or {}).get('overall')
            if completeness_value is None:
                completeness_value=(self.db.get_entity(lead_norm) or {}).get('info_completeness')
            needs_enrichment = (not enrichment.get('ok') or
                                 float(completeness_value or 0) < 80 or
                                 len(edata.get('contacts') or []) == 0)
            enrich_result = None
            if needs_enrichment:
                if not allow_inline_enrichment:
                    reason='客户尚未完成独立信息补全队列；业务执行暂停等待补全完成'
                    self.db.update_task(task_id, run_status='waiting_enrichment', current_stage='PROFILE_ENRICHMENT',
                                        current_node='PROFILE_ENRICHMENT', progress_pct=45, failure_reason=reason)
                    self.db.save_task_log(task_id, 'business_execution', reason)
                    flow.checkpoint('PROFILE_ENRICHMENT','BLOCKED',45,shared_data={'reason':reason},condition={'edge':'enrichment_ready','taken':False},message=reason)
                    return {'ok': False, 'stage': 'enrichment_required', 'task_id': task_id,
                            'qualification': None, 'enrichment': {'ok': False, 'required': True, 'reason': reason},
                            'validation': validation, 'action_required': 'WAIT_ENRICHMENT'}
                enrich_result = self._enrich_for_business(lead_norm, category_id)
                self.db.save_task_log(task_id, 'business_execution',
                                      f"客户资料补全完成：{enrich_result.get('completeness', 0)}%")
                flow.checkpoint('PROFILE_ENRICHMENT','SUCCESS',55,shared_data={'completeness':enrich_result.get('completeness',0)},message='业务节点3完成：共享资料补全结果')
                flow.handoff('PROFILE_ENRICHMENT','QUALIFICATION',{'norm':lead_norm,'completeness':enrich_result.get('completeness',0)},['norm','completeness'],message='资料补全→开发资格交接')
            else:
                enrich_result = {'ok': True, 'skipped': True, 'completeness': (enrichment.get('data') or {}).get('info_completeness', 0)}
                self.db.save_task_log(task_id, 'business_execution', '客户资料已达到业务执行阈值，跳过重复补全')
                flow.checkpoint('PROFILE_ENRICHMENT','SUCCESS',55,shared_data={'completeness':enrich_result.get('completeness',0),'skipped':True},message='业务节点3：资料已足够，跳过重复补全')
                flow.handoff('PROFILE_ENRICHMENT','QUALIFICATION',{'norm':lead_norm,'completeness':enrich_result.get('completeness',0)},['norm','completeness'],message='已有资料→开发资格交接')

            # 重新读取统一情报，确保资格判断使用补全后的最新数据。
            self.db.update_task(task_id, current_stage='QUALIFICATION', current_node='QUALIFICATION', progress_pct=60)
            flow.checkpoint('QUALIFICATION','RUNNING',65,shared_data={'trade_evidence_required':True},message='业务节点4：真实性、匹配度、可触达性资格判断')
            qualification = self.qualify_for_development(lead_norm)
            if not qualification.get('qualified'):
                self.db.update_task(task_id, run_status='blocked', current_stage='QUALIFICATION', current_node='QUALIFICATION',
                                    progress_pct=60, failure_reason=qualification.get('reason'))
                self.db.save_task_log(task_id, 'business_execution', f"开发资格未通过：{qualification.get('reason')}")
                flow.checkpoint('QUALIFICATION','BLOCKED',65,shared_data={'qualification':qualification},condition={'edge':'qualified','taken':False},message=f"开发资格阻断：{qualification.get('reason')}")
                return {'ok': False, 'stage': 'qualification', 'task_id': task_id,
                        'qualification': qualification, 'enrichment': enrich_result,
                        'validation': validation, 'action_required': 'CONTINUE_INTELLIGENCE_ENRICHMENT'}

            flow.checkpoint('QUALIFICATION','SUCCESS',72,shared_data={'qualification':qualification},message='业务节点4完成：客户满足开发资格')
            flow.handoff('QUALIFICATION','DEVELOPMENT_LETTER',{'norm':lead_norm,'qualified':True},['norm','qualified'],condition={'edge':'qualified','taken':True},message='开发资格→开发信交接')
            self.db.update_task(task_id, current_stage='DEVELOPMENT_LETTER', current_node='DEVELOPMENT_LETTER', progress_pct=78)
            flow.checkpoint('DEVELOPMENT_LETTER','RUNNING',78,shared_data={'our_product':our_product or settings.SENDER_COMPANY},message='业务节点5：生成个性化开发信')
            letter = self.generate_development_letter(lead_norm, our_product=our_product, our_company=our_company,
                                                       skip_qualification=True)
            if not letter.get('ok'):
                self.db.update_task(task_id, run_status='failed', current_stage='DEVELOPMENT_LETTER',
                                    current_node='DEVELOPMENT_LETTER', failure_reason=letter.get('error'))
                flow.checkpoint('DEVELOPMENT_LETTER','FAILED',78,shared_data={'error':letter.get('error')},message=f"开发信生成失败：{letter.get('error')}")
                return {'ok': False, 'stage': 'development_letter', 'task_id': task_id,
                        'qualification': qualification, 'letter': letter, 'validation': validation}

            flow.checkpoint('DEVELOPMENT_LETTER','SUCCESS',88,shared_data={'record_id':letter.get('record_id'),'recipient':letter.get('recipient','')},message='业务节点5完成：开发信已生成并保存为执行记录')
            flow.handoff('DEVELOPMENT_LETTER','OUTREACH',{'record_id':letter.get('record_id'),'mode':mode},['record_id','mode'],message='开发信→Outlook触达交接')
            flow.checkpoint('OUTREACH','RUNNING',90,shared_data={'mode':mode},message='业务节点6：处理 Outlook 草稿或发送')
            action = {'status': 'READY', 'method': 'local_draft_record'}
            if mode == 'draft':
                action = self.open_outlook_and_save_draft(letter['record_id'])
            elif mode == 'send':
                action = self.open_outlook_and_send(letter['record_id'])
            action_ok = bool(action.get('ok', True))
            flow.checkpoint('OUTREACH','SUCCESS' if action_ok else 'FAILED',100 if action_ok else 92,shared_data={'outreach_status':action.get('status'),'method':action.get('method')},condition={'edge':'outreach_success','taken':action_ok},message=f"Outlook触达结果：{action.get('status', 'READY')}")
            if action_ok: flow.finish(100)
            self.db.update_task(task_id, current_stage='OUTREACH', current_node='OUTREACH', progress_pct=100,
                                run_status='done' if action_ok else 'failed',
                                failure_reason=None if action_ok else action.get('error'), completed_at=time.time())
            self.db.save_task_log(task_id, 'business_execution',
                                  f"业务链完成：{action.get('status', 'READY')} / {action.get('method', '-')}")
            return {'ok': action_ok, 'stage': 'outreach', 'task_id': task_id,
                    'audit': audit_before, 'validation': validation, 'enrichment': enrich_result,
                    'qualification': qualification, 'letter': {**letter, 'send_status': action.get('status')},
                    'outreach': action}
        except Exception as e:
            try: flow.checkpoint('OUTREACH','FAILED',95,shared_data={'error':str(e)[:500]},message=f'业务链异常：{str(e)[:400]}')
            except Exception: pass
            self.db.update_task(task_id, run_status='failed', failure_reason=str(e)[:500], completed_at=time.time())
            self.db.save_task_log(task_id, 'business_execution', f'业务链异常：{str(e)[:400]}')
            return {'ok': False, 'stage': 'exception', 'task_id': task_id, 'error': str(e)[:500]}

    def _profile_audit(self, entity_id: str) -> Dict[str, Any]:
        entity = self.db.get_entity_by_id(entity_id) or {}
        fields = ['name','country','address','website','phone','enterprise_type','industry','product_categories','brand']
        filled = sum(1 for f in fields if entity.get(f))
        contacts = self.db.list_entity_contacts(entity_id)
        evidence = self.db.list_evidence(entity_id)
        return {'completeness': round(filled / len(fields) * 100, 1), 'filled_fields': filled,
                'total_fields': len(fields), 'contacts': len(contacts),
                'emails': sum(1 for c in contacts if c.get('email')), 'evidence': len(evidence)}

    def _ai_profile_validation(self, norm: str) -> Dict[str, Any]:
        result = self._build_profile_validation(norm)
        if result.get('ok'):
            return result
        return {'ok': False, 'model_used': result.get('model_used'), 'error': result.get('error')}

    def _build_profile_validation(self, norm: str) -> Dict[str, Any]:
        intel = self.db.get_intelligence(norm)
        if not intel.get('ok'):
            return intel
        data = intel.get('data') or {}
        prompt = f"""请审核并再次定位下面客户的详细画像，只使用提供的企业情报，不编造事实。\n企业：{norm}\n基础身份：{json.dumps(data.get('basic_identity',{}), ensure_ascii=False)}\n贸易身份：{json.dumps(data.get('trade_identity',{}), ensure_ascii=False)}\n采购行为：{json.dumps(data.get('purchase_behavior',{}), ensure_ascii=False)}\n联系人：{json.dumps(data.get('contacts',[]), ensure_ascii=False)}\n缺口：{json.dumps(data.get('gaps',[]), ensure_ascii=False)}\n请输出：目标客户类型、可能采购角色、产品/需求线索、决策人职位线索、开发切入点、风险与不确定项。"""
        r = ai_route_structured(prompt, model_preference=['deepseek','qwen','gpt'])
        return {'ok': bool(r.get('success')), 'model_used': r.get('provider'),
                'content': r.get('content'), 'parsed': r.get('parsed_json'), 'error': r.get('error','')}

    def _enrich_for_business(self, norm: str, category_id: str = None) -> Dict[str, Any]:
        entity = self.db.get_entity(norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found', 'completeness': 0}
        current = self.db.get_current_lifecycle_state(entity['entity_id'])
        if current not in ('ENRICHING', 'ENRICHED'):
            try:
                self.db.transition_lifecycle(entity['entity_id'], current, 'ENRICHING', 'Business flow requested profile enrichment', 'business_execution_center')
            except Exception:
                pass
        try:
            from core.intelligence.account_intelligence_center import AccountIntelligenceCenter
            wrapped = AccountIntelligenceCenter(self.db).enrich(norm, category_id=category_id, force=False)
            result = wrapped.get('enriched') or {}
            return {'ok': bool(wrapped.get('ok')), **result}
        except Exception as e:
            latest = self.db.get_intelligence(norm)
            return {'ok': False, 'error': str(e)[:400],
                    'completeness': (latest.get('data') or {}).get('info_completeness', 0) if latest.get('ok') else 0}

    def qualify_for_development(self, lead_norm: str) -> Dict[str, Any]:
        entity = self.db.get_entity(lead_norm)
        if not entity:
            return {'qualified': False, 'reason': 'Entity not found'}

        entity_id = entity['entity_id']
        score = self._calculate_score(entity_id)
        contacts = self.db.list_entity_contacts(entity_id)
        has_email = any(c.get('email') for c in contacts)
        current_state = self.db.get_current_lifecycle_state(entity_id)

        checks = {
            'entity_exists': True,
            'trade_evidence': score.get('trade_realness', 0) >= 40,
            'product_match': score.get('product_match', 0) >= 50,
            'recent_activity': score.get('recent_activity', 0) >= 40,
            'info_complete': score.get('info_completeness', 0) >= 40,
            'has_contact': len(contacts) > 0,
            'has_email': has_email,
            'not_blocked': current_state not in ('QUARANTINED', 'INVALID', 'DO_NOT_CONTACT'),
        }

        qualified = all(checks.values())
        failed = [k for k, v in checks.items() if not v]

        return {
            'qualified': qualified,
            'checks': checks,
            'failed_checks': failed,
            'reason': 'All checks passed' if qualified else f"Failed: {', '.join(failed)}",
            'score': score,
            'current_state': current_state,
        }

    def generate_development_letter(self, lead_norm: str, our_product: str = None,
                                    our_company: str = None, skip_qualification: bool = False) -> Dict[str, Any]:
        entity = self.db.get_entity(lead_norm)
        if not entity:
            return {'ok': False, 'error': 'Entity not found'}

        qualification=self.qualify_for_development(lead_norm)
        if not skip_qualification and not qualification.get('qualified'):
            return {'ok':False,'error':'Lead is not qualified for development','qualification':qualification}
        entity_id = entity['entity_id']
        intelligence = self.db.get_intelligence(lead_norm)
        contacts = self.db.list_entity_contacts(entity_id)
        primary_contact = next((c for c in contacts if c.get('email') and c.get('verified')), None) or next((c for c in contacts if c.get('email')), None) or (contacts[0] if contacts else {})
        evidence = self.db.list_evidence(entity_id, min_priority=50)

        prompt = f"""Please generate a personalized English business development email for:

Customer:
- Company: {entity.get('name', lead_norm)}
- Country: {entity.get('country', '')}
- Industry: {entity.get('industry', '')}
- Products: {entity.get('product_categories', '')}
- Contact: {primary_contact.get('name', '')} ({primary_contact.get('title', '')})
- Trade evidence: {json.dumps([e['evidence'] for e in evidence[:3]], ensure_ascii=False)}

Our side:
- Company: {our_company or settings.SENDER_COMPANY}
- Sender: {settings.SENDER_NAME_EN} ({settings.SENDER_NAME})
- Email: {settings.SENDER_EMAIL}
- Phone: {settings.SENDER_PHONE}
- Products: {our_product or 'relevant products'}

Requirements:
1. Use real customer intelligence, no generic mass emails
2. Natural, professional, concise
3. Clear CTA
4. Attractive subject line
5. End with the sender name, company, email and phone supplied above. Never invent contact details.

Return format:
Subject: [subject]
Body: [body]
"""

        result = ai_route_structured(prompt, model_preference=['deepseek', 'qwen', 'gpt'])
        if not result['success']:
            return {'ok': False, 'error': result.get('error', 'AI generation failed')}

        content = result['content']
        subject = self._extract_subject(content)
        body = self._extract_body(content)

        record_id = self.db.create_execution_record(
            entity_id=entity_id,
            execution_type='development_letter',
            task_id=f"dev-{int(time.time())}",
            draft_subject=subject,
            draft_body=body,
            personalized_content=content,
            recipient_email=primary_contact.get('email', ''),
            used_intelligence=intelligence.get('data') if isinstance(intelligence, dict) else None,
            used_evidence=[e['evidence_id'] for e in evidence[:5]],
            used_ai_model=result.get('provider', 'unknown')
        )

        self.db.update_execution_status(record_id, 'READY')

        self.db.transition_lifecycle(
            entity_id=entity_id,
            from_state=self.db.get_current_lifecycle_state(entity_id),
            to_state='READY_FOR_OUTREACH',
            reason='Development letter generated',
            actor='business_execution_center'
        )

        return {
            'ok': True,
            'record_id': record_id,
            'subject': subject,
            'body': body,
            'personalized': content,
            'recipient': primary_contact.get('email', ''),
            'used_model': result.get('provider'),
        }

    def open_outlook_and_save_draft(self, record_id: str) -> Dict[str, Any]:
        """在真实 Outlook 网页会话中打开新邮件并填入内容，依靠 Outlook 自动保存到草稿箱。"""
        records = self.db.get_execution_records(record_id=record_id)
        if not records:
            return {'ok': False, 'error': 'Record not found', 'status': 'FAILED'}
        record = records[0]
        try:
            status = self._check_outlook_login()
            if not status.get('logged_in'):
                self.db.update_execution_status(record_id, 'READY')
                return {'ok': False, 'error': status.get('error') or 'Microsoft Outlook not logged in',
                        'status': 'READY', 'action_required': status.get('action_required','LOGIN_OUTLOOK'),
                        'login_url': status.get('login_url','https://outlook.live.com')}
            result = self._playwright_draft(record)
            self.db.update_execution_status(record_id, 'DRAFT' if result.get('success') else 'READY')
            return {'ok': bool(result.get('success')), 'status': 'DRAFT' if result.get('success') else 'READY',
                    'record_id': record_id, 'method': result.get('method','outlook_draft'),
                    'error': result.get('error',''), 'action_required': result.get('action_required')}
        except Exception as e:
            self.db.update_execution_status(record_id, 'READY')
            return {'ok': False, 'status': 'READY', 'record_id': record_id, 'error': str(e)[:500]}

    def _playwright_draft(self, record: Dict) -> Dict[str, Any]:
        try:
            from playwright.sync_api import sync_playwright
            cdp_url = getattr(settings, 'IY_WEB_CDP_URL', 'http://127.0.0.1:9222')
            with sync_playwright() as p:
                browser = p.chromium.connect_over_cdp(cdp_url)
                if not browser.contexts:
                    return {'success': False, 'error': 'No desktop browser context available', 'action_required': 'START_BROWSER'}
                context = browser.contexts[0]
                page = next((pg for pg in context.pages if 'outlook.live.com' in pg.url or 'office.com' in pg.url), None) or context.new_page()
                if 'outlook.live.com' not in page.url:
                    page.goto('https://outlook.live.com/mail/0/', wait_until='domcontentloaded', timeout=30000)
                page.wait_for_timeout(1500)
                if any(token in page.url.lower() for token in ('login','signin','account.live.com')):
                    return {'success': False, 'error': 'Outlook is not logged in', 'action_required': 'LOGIN_OUTLOOK'}
                new_mail = page.locator('button[aria-label="New mail"],button[aria-label="新建邮件"],button[aria-label="New message"],button[title="New mail"],button[title="新建邮件"]').first
                new_mail.click(timeout=15000)
                page.wait_for_timeout(800)
                to_field = page.locator('[aria-label="To"],[aria-label="收件人"],[aria-label="To recipients"]').first
                to_field.fill(record.get('recipient_email',''))
                subject_field = page.locator('[aria-label="Add a subject"],[aria-label="添加主题"],[placeholder="Add a subject"]').first
                subject_field.fill(record.get('draft_subject',''))
                body_editor = page.locator('[aria-label="Message body"],[aria-label="邮件正文"],[contenteditable="true"]').first
                body_editor.fill(record.get('draft_body',''))
                page.wait_for_timeout(2500)
                # 不点击发送；保留撰写窗让 Outlook 自动保存到 Drafts。
                return {'success': True, 'method': 'cdp_persistent_outlook_draft'}
        except ImportError:
            return {'success': False, 'error': 'Playwright is not installed', 'action_required': 'INSTALL_PLAYWRIGHT'}
        except Exception as e:
            return {'success': False, 'error': str(e)[:500], 'action_required': 'CHECK_OUTLOOK_BROWSER'}

    def open_outlook_and_send(self, record_id: str) -> Dict[str, Any]:
        records = self.db.get_execution_records(record_id=record_id)
        if not records:
            return {'ok': False, 'error': 'Record not found', 'status': 'FAILED'}

        record = records[0]

        try:
            outlook_status = self._check_outlook_login()
            if not outlook_status['logged_in']:
                self.db.update_execution_status(record_id, 'FAILED')
                return {
                    'ok': False,
                    'error': 'Microsoft Outlook not logged in. Please login first.',
                    'status': 'FAILED',
                    'action_required': 'LOGIN_OUTLOOK',
                    'login_url': outlook_status.get('login_url', 'https://outlook.live.com')
                }

            send_result = self._playwright_send(record)
            if send_result['success']:
                self.db.update_execution_status(record_id, 'SENT', sent_at=time.time())
                entity_id = record.get('entity_id')
                if entity_id:
                    self.db.transition_lifecycle(
                        entity_id=entity_id,
                        from_state='READY_FOR_OUTREACH',
                        to_state='OUTREACH_ACTIVE',
                        reason='Email sent via Outlook automation',
                        actor='business_execution_center'
                    )
                return {
                    'ok': True,
                    'status': 'SENT',
                    'record_id': record_id,
                    'sent_at': time.time(),
                    'method': 'playwright_automation'
                }
            else:
                self.db.update_execution_status(record_id, 'FAILED')
                return {
                    'ok': False,
                    'error': send_result.get('error', 'Send failed'),
                    'status': 'FAILED'
                }

        except Exception as e:
            self.db.update_execution_status(record_id, 'FAILED')
            return {'ok': False, 'error': str(e), 'status': 'FAILED'}

    def _check_outlook_login(self) -> Dict:
        """Check the real desktop browser session used for sending.

        We never treat a missing Playwright/browser as a successful login.
        The desktop launcher creates a persistent Chromium profile and exposes
        it through CDP on IY_WEB_CDP_URL (default localhost:9222).
        """
        try:
            from playwright.sync_api import sync_playwright
            from core.config import settings
            cdp_url = getattr(settings, 'IY_WEB_CDP_URL', 'http://127.0.0.1:9222')
            with sync_playwright() as p:
                browser = p.chromium.connect_over_cdp(cdp_url)
                contexts = browser.contexts
                if not contexts:
                    browser.close()
                    return {'logged_in': False, 'error': 'No browser context on CDP', 'action_required': 'START_BROWSER'}
                pages = [pg for ctx in contexts for pg in ctx.pages]
                page = next((pg for pg in pages if 'outlook.live.com' in pg.url or 'office.com' in pg.url), None)
                if page is None:
                    page = contexts[0].new_page()
                    page.goto('https://outlook.live.com/mail/0/', wait_until='domcontentloaded', timeout=30000)
                    page.wait_for_timeout(2000)
                url = page.url.lower()
                logged_in = ('login' not in url and 'signin' not in url and 'account.live.com' not in url)
                if not logged_in:
                    return {'logged_in': False, 'login_url': 'https://outlook.live.com', 'action_required': 'LOGIN_OUTLOOK'}
                return {'logged_in': True, 'cdp_url': cdp_url}
        except ImportError:
            return {'logged_in': False, 'error': 'Playwright is not installed', 'action_required': 'INSTALL_PLAYWRIGHT'}
        except Exception as e:
            return {'logged_in': False, 'error': str(e)[:500],
                    'action_required': 'START_BROWSER', 'cdp_url': 'http://127.0.0.1:9222'}

    def _playwright_send(self, record: Dict) -> Dict:
        """Send through the user's real persistent Outlook browser session.

        No simulated success is permitted. SENT is returned only after the
        browser reports that the send action was completed.
        """
        try:
            from playwright.sync_api import sync_playwright
            from core.config import settings
            cdp_url = getattr(settings, 'IY_WEB_CDP_URL', 'http://127.0.0.1:9222')
            with sync_playwright() as p:
                browser = p.chromium.connect_over_cdp(cdp_url)
                if not browser.contexts:
                    return {'success': False, 'error': 'No desktop browser context available', 'action_required': 'START_BROWSER'}
                context = browser.contexts[0]
                page = next((pg for pg in context.pages if 'outlook.live.com' in pg.url or 'office.com' in pg.url), None)
                if page is None:
                    page = context.new_page()
                page.goto('https://outlook.live.com/mail/0/', wait_until='domcontentloaded', timeout=30000)
                page.wait_for_timeout(2000)
                if any(token in page.url.lower() for token in ('login', 'signin', 'account.live.com')):
                    return {'success': False, 'error': 'Outlook is not logged in', 'action_required': 'LOGIN_OUTLOOK'}

                new_mail = page.locator('button[aria-label="New mail"],button[aria-label="新建邮件"],button[aria-label="New message"],button[title="New mail"],button[title="新建邮件"]')
                new_mail.first.click(timeout=15000)
                page.wait_for_timeout(800)

                to_field = page.locator('[aria-label="To"],[aria-label="收件人"],[aria-label="To recipients"]').first
                to_field.fill(record.get('recipient_email', ''))
                subject_field = page.locator('[aria-label="Add a subject"],[aria-label="添加主题"],[placeholder="Add a subject"]').first
                subject_field.fill(record.get('draft_subject', ''))
                body_editor = page.locator('[aria-label="Message body"],[aria-label="邮件正文"],[contenteditable="true"]').first
                body_editor.fill(record.get('draft_body', ''))

                send_button = page.locator('button[aria-label="Send"],button[aria-label="发送"],button[title="Send"],button[title="发送"]')
                send_button.first.click(timeout=15000)
                page.wait_for_timeout(1500)

                # Outlook normally removes the compose pane and shows a sent
                # notification. Require one of those observable signals.
                sent_signal = False
                try:
                    sent_signal = page.get_by_text('Sent', exact=True).count() > 0
                except Exception:
                    pass
                compose_visible = page.locator('[aria-label="Message body"],[aria-label="邮件正文"],[contenteditable="true"]').count() > 0
                if compose_visible and not sent_signal:
                    return {'success': False, 'error': 'Send was clicked but Outlook did not confirm completion'}
                return {'success': True, 'method': 'cdp_persistent_outlook'}
        except ImportError:
            return {'success': False, 'error': 'Playwright is not installed', 'action_required': 'INSTALL_PLAYWRIGHT'}
        except Exception as e:
            return {'success': False, 'error': str(e)[:500], 'action_required': 'CHECK_OUTLOOK_BROWSER'}

    def _calculate_score(self, entity_id: str) -> Dict:
        entity = self.db.get_entity_by_id(entity_id)
        edges = self.db.list_trade_edges(entity_id=entity_id)
        contacts = self.db.list_entity_contacts(entity_id)

        trade_realness = min(100, len(edges) * 25)
        product_match = 70
        recent_activity = 80 if edges and any((e.get('last_trade') or 0) > time.time() - 90*86400 for e in edges) else 40
        purchase_strength = min(100, sum(int(e.get('shipment_count') or 0) for e in edges) * 5)
        info_completeness = self._calc_completeness(entity_id)
        contact_availability = min(100, len(contacts) * 50)

        total = (trade_realness * 0.2 + product_match * 0.15 + recent_activity * 0.15 +
                purchase_strength * 0.15 + info_completeness * 0.15 + contact_availability * 0.2)

        return {
            'trade_realness': trade_realness,
            'product_match': product_match,
            'recent_activity': recent_activity,
            'purchase_strength': purchase_strength,
            'info_completeness': info_completeness,
            'contact_availability': contact_availability,
            'total_score': round(total, 1),
        }

    def _calc_completeness(self, entity_id: str) -> float:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return 0.0
        fields = ['name', 'country', 'address', 'website', 'phone',
                  'enterprise_type', 'industry', 'product_categories']
        filled = sum(1 for f in fields if entity.get(f))
        return round(filled / len(fields) * 100, 1)

    def _extract_subject(self, content: str) -> str:
        for line in content.split('\n'):
            if line.lower().startswith('subject:'):
                return line.split(':', 1)[1].strip()
        return "Business Collaboration Opportunity"

    def _extract_body(self, content: str) -> str:
        parts = content.split('Body:', 1)
        return parts[1].strip() if len(parts) > 1 else content
