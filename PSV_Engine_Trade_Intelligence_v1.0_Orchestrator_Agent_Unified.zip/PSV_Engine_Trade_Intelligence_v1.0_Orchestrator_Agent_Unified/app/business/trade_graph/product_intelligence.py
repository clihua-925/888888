# -*- coding: utf-8 -*-
"""current Product Intelligence Layer —— 产品语义矩阵（纯执行工具，非节点、不做流程决策）。

每个产品是一份 16 维语义矩阵，不是单一关键词：
    core_name          1 核心产品名称
    standard_name_en   2 英文标准名称
    synonyms           3 同义词
    spelling_variants  4 拼写变体（enamel/enameled/enamelled、单复数）
    industry_terms     5 行业叫法
    buyer_terms        6 买家常用叫法
    supplier_terms     7 供应商常用叫法
    form_words         8 产品形态词（pot/pan/saucepan/stock pot/set…）
    materials          9 材料词
    function_words    10 功能词
    trade_terms       11 贸易描述词（manufacturer/exporter/importer/distributor/wholesaler）
    hs_candidates     12 HS候选（强辅助信号，不作硬过滤）
    exclusions        13 排除词
    precision_terms   14 高精度词（具体组合，定位准）
    recall_terms      15 高召回词（宽泛覆盖，如 enamelware/kitchenware）
    combo_queries     16 组合查询词

查询不设固定上限：矩阵产出多少就用多少，由 CUSTOMS_NODE_COLLECTION 逐查询计量
（result_count/usable_trade_nodes/usable_trade_edges），低价值查询动态淘汰、
高价值查询下轮保留——上限跟随产出，不写死。

来源优先级（全部确定性兜底，LLM 只是增强、不是依赖）：
    1. 行业配置（设置页可维护）
    2. 内置规则（拼写变体/形态词/角色修饰词组合）
    3. LLM 扩展（超时或失败自动略过）
"""
import re

# 贸易描述词（买卖双侧角色修饰）
BUYER_MODIFIERS = ('importer', 'buyer', 'distributor', 'wholesaler', 'retailer', 'brand')
SUPPLIER_MODIFIERS = ('manufacturer', 'factory', 'exporter', 'supplier', 'OEM')
COMMERCIAL_MODIFIERS = ('wholesale', 'bulk', 'OEM', 'custom', 'private label')

# 拼写变体规则（确定性）：美式/英式、单复数
def _spelling_variants(word):
    """Conservative lexical variants only; never invent a new product category."""
    out=set(); w=str(word or '').strip()
    if not w: return []
    out.add(w)
    low=w.lower()
    # Common English singular/plural variants on the final lexical token.
    toks=w.split()
    last=toks[-1] if toks else ''
    if last:
        ll=last.lower()
        if ll.endswith('ies') and len(last)>3:
            out.add(' '.join(toks[:-1]+[last[:-3]+'y']))
        elif ll.endswith('s') and not ll.endswith('ss'):
            out.add(' '.join(toks[:-1]+[last[:-1]]))
        elif ll.endswith(('s','x','z','ch','sh')):
            out.add(' '.join(toks[:-1]+[last+'es']))
        else:
            out.add(' '.join(toks[:-1]+[last+'s']))
    # Explicit enamel spelling variants; safe because the semantic phrase is preserved.
    if 'enamel' in low:
        out.add(w.replace('enamelware','enamelled ware').replace('enamel','enameled'))
        out.add(w.replace('enamelware','enameled ware').replace('enamel','enamelled'))
    return sorted(_dedup(out))

def _split_cfg(v):
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    return [x.strip() for x in str(v or '').replace('；', ';').replace(';', ',').split(',') if x.strip()]


def _dedup(seq):
    out = []; seen = set()
    for x in seq:
        k = str(x or '').strip().lower()
        if k and k not in seen:
            seen.add(k); out.append(str(x).strip())
    return out


def _llm_expand(industry, cfg_terms, target_context=None):
    """Grounded LLM semantic expansion.

    The model is given the actual target product definition (not merely the industry
    label). It may propose candidates, but every candidate is typed and later checked
    by deterministic boundary rules. This avoids query drift while preserving recall.
    """
    try:
        from core.utils import jsonutil
        from core.model.client import ModelClient
        mc = ModelClient()
        if not mc.health():
            return None
        ctx = target_context or {}
        canonical = str(ctx.get('canonical') or industry).strip()
        standard = str(ctx.get('standard_name_en') or canonical).strip()
        applications = _split_cfg(ctx.get('applications'))
        materials = _split_cfg(ctx.get('materials'))
        explicit_syn = _split_cfg(ctx.get('synonyms'))
        prompt = (
            '你是B2B贸易检索语义专家。\n'
            '目标产品（必须保持原始意图）：%s\n标准名称：%s\n'
            '应用：%s\n材料：%s\n已有可信同义词：%s\n'
            '行业：%s\n已知词：%s\n\n'
            '只输出JSON：{'
            '"synonyms":[],"spelling_variants":[],"industry_terms":[],"form_words":[],'
            '"materials":[],"function_words":[],"precision_terms":[],"recall_terms":[],'
            '"exclusions":[],'
            '"notes":[]}'
            '\n严格要求：'
            '1) synonyms 只能是目标产品本身的真实同义表达，不得是上位词、材料词、场景词、角色词；'
            '2) spelling_variants 只能是拼写/单复数/地区变体；'
            '3) industry_terms 可以是行业叫法，但不得改变目标产品类别；'
            '4) form_words/materials/function_words 是语义属性，不是同义词；'
            '5) precision_terms 必须能独立帮助定位目标产品；'
            '6) recall_terms 可以更宽，但不得伪装成 exact synonym；'
            '7) exclusions 只放明确同名歧义或明确无关领域；'
            '8) 不要把 importer/manufacturer/supplier/buyer 等贸易角色放进产品同义词；'
            '9) 不要把与目标产品同属大类但用途不同的商品当成 synonym；'
            '10) 每类最多8个，全部英文小写。') % (
                canonical, standard, ','.join(applications[:8]), ','.join(materials[:8]),
                ','.join(explicit_syn[:8]), industry, ','.join(cfg_terms[:12]))
        from core.config import settings
        txt = mc.chat(prompt, timeout=getattr(settings, 'AI_JUDGE_TIMEOUT', getattr(settings, 'LLM_TIMEOUT', 480)),
                      max_tokens=getattr(settings, 'AI_JUDGE_MAX_TOKENS', 1800))
        j = jsonutil.j(txt or '')
        keys = ('synonyms', 'spelling_variants', 'industry_terms', 'form_words',
                'materials', 'function_words', 'precision_terms', 'recall_terms', 'exclusions')
        if isinstance(j, dict) and any(j.get(k) for k in keys):
            return {k: _split_cfg(j.get(k)) for k in keys}
    except Exception:
        pass
    return None

def _semantic_anchor_filter(items, anchors):
    """LLM 生成的同义词/精确词保守准入：至少命中完整产品词锚点。
    注意：这里使用词边界而不是 substring，避免 candlestick/candleholder/candlelight
    因包含 candle 就被误认为 birthday candles 的语义近邻。
    """
    anchors = [str(a).strip().lower() for a in (anchors or []) if str(a).strip()]
    out = []
    for x in items or []:
        text = str(x or '').strip()
        low = text.lower()
        if text and any(re.search(r'(?<![a-z])' + re.escape(a) + r'(?![a-z])', low) for a in anchors):
            out.append(text)
    return _dedup(out)


_QUERY_HARD_NOISE = {
    # 常见 candle 同名词，但不是生日蜡烛产品；这些词不能作为 Node 1 的 close/exact 查询。
    'candlestick', 'candlesticks', 'candleholder', 'candleholders', 'candlelight',
    'candlelighter', 'candle lighters', 'candle lamp', 'candle lamps',
}

def _query_term_allowed(text, profile, dimension):
    """Node 1 查询边界：阻止明显同名噪声，保留不确定项给 recall，而非升级为 exact。"""
    t = str(text or '').strip().lower()
    if not t:
        return False
    if t in _QUERY_HARD_NOISE:
        return False
    # 拼写/同义词/精确查询必须含完整核心语义词，不能只靠 substring。
    if dimension in ('synonym', 'spelling', 'precision'):
        anchors = [str(profile.get('canonical') or '').strip().lower()] + [str(x).strip().lower() for x in (profile.get('synonyms') or [])]
        anchors = [x for x in anchors if x]
        return any(re.search(r'(?<![a-z])' + re.escape(a) + r'(?![a-z])', t) for a in anchors)
    if dimension == 'industry':
        # 行业词允许 broader recall，但必须包含完整产品/应用锚点或明确 party/cake 语境。
        toks = set(re.findall(r'[a-z]+', t))
        allowed_context = {'birthday', 'cake', 'party', 'candle', 'candles', 'decorating', 'decoration', 'supplies'}
        return bool(toks & allowed_context) and not any(x in t for x in _QUERY_HARD_NOISE)
    return True


def build_product_profile(industry, icp=None, use_llm=True):
    """构建 16 维产品语义矩阵。

    重要边界：
    - search_terms / keywords 不是自动等价的“同义词”。
    - 角色词（manufacturer/importer/supplier...）只进入角色查询，不污染产品同义词。
    - 宽泛词（wax/fragrance/home decor...）只能作为 recall/industry 支撑，不能标成 exact。
    - 配置存在显式 typed fields 时优先使用；旧配置仍走保守兼容路径。
    """
    from core.config.industry import load_industry
    cfg = load_industry(industry)
    terms = _dedup(_split_cfg(cfg.get('search_terms')) or [industry])
    keywords = _split_cfg(cfg.get('keywords'))
    icp_kw = _split_cfg((icp or {}).get('keywords'))

    # Core product identity must not inherit a role-bearing search term.
    # Prefer explicit core_name, then default_web_industry/name_en, then the first term.
    # This keeps legacy industry configs (e.g. 'felt manufacturer') generic without
    # forcing every product to be manually migrated before it can use the engine.
    candidates = [cfg.get('core_name'), cfg.get('default_web_industry'), cfg.get('name_en'), cfg.get('name'), terms[0] if terms else industry]
    core = next((str(x).strip() for x in candidates if str(x or '').strip()), str(industry).strip())
    standard_name = str(cfg.get('standard_name_en') or cfg.get('name_en') or core).strip()

    # 新配置优先；旧配置中含角色/商业修饰词的条目不再当产品同义词。
    explicit_synonyms = _split_cfg(cfg.get('synonyms'))
    # Only an explicit synonym field is allowed to populate the synonym dimension.
    # Legacy search_terms/keywords are evidence for retrieval, not proof of equivalence.
    synonyms = _dedup(explicit_synonyms)

    cfg_exclusions = _split_cfg(cfg.get('exclusions'))
    cfg_materials = _split_cfg(cfg.get('materials'))
    cfg_applications = _split_cfg(cfg.get('applications'))
    industry_terms = _split_cfg(cfg.get('industry_terms'))
    # Backward-compatible related vocabulary: search_terms/keywords remain close/broad
    # retrieval hints, never exact synonyms. Keep only meaningful terms and de-duplicate.
    legacy_related = [x for x in terms[1:] + keywords if x and x.lower() != core.lower()]
    industry_terms = _dedup(industry_terms + legacy_related)
    form_words = _split_cfg(cfg.get('form_words'))
    function_words = _split_cfg(cfg.get('function_words'))
    precision = _split_cfg(cfg.get('precision_terms'))
    recall = _split_cfg(cfg.get('recall_terms'))
    combo = _split_cfg(cfg.get('combo_queries'))

    # 产品语义锚点：用于约束 LLM 的 exact/synonym 输出，避免“fragrance/wax/home decor”越级。
    anchors = _dedup([core] + synonyms)
    llm = _llm_expand(industry, [core] + synonyms + keywords, {'canonical': core, 'standard_name_en': standard_name, 'synonyms': synonyms, 'applications': cfg_applications, 'materials': cfg_materials}) if use_llm else None
    if llm:
        llm_syn = _semantic_anchor_filter(llm.get('synonyms'), anchors)
        llm_prec = _semantic_anchor_filter(llm.get('precision_terms'), anchors)
        synonyms = _dedup(synonyms + llm_syn)
        industry_terms = _dedup(industry_terms + llm.get('industry_terms', []))
        form_words = _dedup(form_words + llm.get('form_words', []))
        function_words = _dedup(function_words + llm.get('function_words', []))
        precision = _dedup(precision + llm_prec)
        recall = _dedup(recall + llm.get('recall_terms', []))
        cfg_materials = _dedup(cfg_materials + llm.get('materials', []))
        cfg_exclusions = _dedup(cfg_exclusions + llm.get('exclusions', []))

    # ICP keywords 是情报支撑，不再自动提升为 exact synonym。
    support_terms = _dedup(keywords + terms[1:] + icp_kw)

    # 确定性角色维度：由核心产品词/可信同义词生成，而不是把 manufacturer/supplier 当产品词。
    base_words = _dedup([core] + synonyms)[:5]
    buyer_terms = _dedup('%s %s' % (b, m) for b in base_words[:3] for m in BUYER_MODIFIERS)
    supplier_terms = _dedup('%s %s' % (b, m) for b in base_words[:3] for m in SUPPLIER_MODIFIERS)
    trade_terms = _dedup(list(BUYER_MODIFIERS) + list(SUPPLIER_MODIFIERS))

    # 高精度词只接受显式配置或经过目标语义锚定的LLM候选。
    # 材料/形态/功能默认保持属性维度，不自动拼成exact查询，避免产品漂移。
    precision = _dedup(precision)

    # 高召回词：显式配置优先；否则从 support_terms/核心上位词保守生成。
    if not recall:
        tokens = core.split()
        recall = _dedup([x for x in support_terms if x.lower() not in {core.lower()}][:8])
        if len(tokens) > 1:
            recall += [tokens[-1], tokens[0] + 'ware' if not tokens[0].endswith('ware') else tokens[0]]
        else:
            recall.append(core)
        recall = _dedup(recall)

    # 组合查询：显式配置 + 可信核心词×商业语境。
    if not combo:
        for b in base_words[:3]:
            for mod in COMMERCIAL_MODIFIERS[:3]:
                combo.append('%s %s' % (b, mod))
        for p in precision[:4]:
            combo.append('%s importer' % p)
    combo = _dedup(combo)

    hs_candidates = [str(x).strip() for x in (cfg.get('hs_codes') or []) if str(x).strip()]
    for x in ((icp or {}).get('hs') or []):
        if str(x).strip() and str(x).strip() not in hs_candidates:
            hs_candidates.append(str(x).strip())

    return {'core_name': core, 'standard_name_en': standard_name, 'canonical': core,
            'synonyms': synonyms, 'spelling_variants': _dedup(_spelling_variants(core) + [v for ss in synonyms[:6] for v in _spelling_variants(ss)]),
            'industry_terms': industry_terms, 'buyer_terms': buyer_terms, 'supplier_terms': supplier_terms,
            'form_words': form_words, 'materials': cfg_materials, 'function_words': function_words,
            'trade_terms': trade_terms, 'hs_candidates': hs_candidates, 'exclusions': cfg_exclusions,
            'precision_terms': precision, 'recall_terms': recall, 'combo_queries': combo,
            'commercial_names': combo, 'applications': cfg_applications,
            'support_terms': support_terms, 'llm_enriched': bool(llm)}


def build_query_plan(profile):
    """Build a typed, staged query plan from the semantic profile.

    Node 1 defines *what the product means*; Node 2 later decides *how aggressively
    to search for it*.  Stages prevent a large static list from being mistaken for
    executed coverage and allow feedback-driven expansion.
    """
    p = profile
    plan = []

    def add(q, qtype, role, rel, pri, stage, rationale, anchor_required=True):
        q = str(q or '').strip()
        if not q:
            return
        if qtype in ('synonym', 'spelling', 'precision') and not _query_term_allowed(q, p, qtype):
            return
        plan.append({'query': q, 'query_type': qtype, 'expected_role': role,
                     'expected_product_relation': rel, 'priority': pri,
                     'stage': int(stage), 'rationale': rationale,
                     'anchor_required': bool(anchor_required),
                     'result_count': None, 'usable_trade_nodes': None,
                     'usable_trade_edges': None, 'precision_estimate': None,
                     'recall_contribution': None})

    # Stage 0: canonical anchor. Always execute first.
    add(p.get('core_name'), 'core', 'both', 'exact', 100, 0, 'canonical product anchor')

    # Stage 1: only true product equivalents / spelling variants.
    for q in p.get('synonyms') or []:
        add(q, 'synonym', 'both', 'exact', 92, 1, 'configured/validated product synonym')
    for q in p.get('spelling_variants') or []:
        if str(q).strip().lower() != str(p.get('core_name') or '').strip().lower():
            add(q, 'spelling', 'both', 'exact', 88, 1, 'spelling or singular/plural variant')
    for q in p.get('precision_terms') or []:
        add(q, 'precision', 'both', 'close', 84, 1, 'high-precision candidate phrase; semantic relation still verified downstream')

    # Stage 2: trade-role localization. Role is search intent, never product meaning.
    for q in p.get('buyer_terms') or []:
        add(q, 'buyer_role', 'buyer', 'exact', 76, 2, 'locate importer/buyer/distributor nodes')
    for q in p.get('supplier_terms') or []:
        add(q, 'supplier_role', 'supplier', 'exact', 76, 2, 'locate manufacturer/supplier/exporter nodes')
    for q in p.get('combo_queries') or []:
        add(q, 'combo', 'both', 'exact', 72, 2, 'commercial procurement context')

    # Stage 3: close semantic neighborhoods. These are useful but not equivalent.
    for q in p.get('industry_terms') or []:
        if _query_term_allowed(q, p, 'industry'):
            add(q, 'industry', 'both', 'close', 62, 3, 'target-specific industry context', anchor_required=False)
    for q in p.get('function_words') or []:
        add('%s %s' % (p.get('core_name'), q), 'function', 'both', 'close', 58, 3, 'target function context')
    # Form/material combinations are generated only as close queries and only when
    # explicitly configured; they never become product synonyms.
    for q in p.get('form_words') or []:
        fq = str(q).strip()
        if fq:
            add('%s %s' % (p.get('core_name'), fq), 'form', 'both', 'close', 56, 3, 'target form context')
    for q in p.get('materials') or []:
        add('%s %s' % (q, p.get('core_name')), 'material', 'both', 'close', 54, 3, 'target material context')

    # Stage 4: broad recall. These are deliberately broad and never exact.
    for q in p.get('recall_terms') or []:
        add(q, 'recall', 'both', 'broad', 45, 4, 'broad recall / vocabulary gap', anchor_required=False)

    seen = set(); out = []
    for it in sorted(plan, key=lambda x: (x['stage'], -x['priority'])):
        k = it['query'].lower()
        if k not in seen:
            seen.add(k); out.append(it)
    return out

def expand_queries(profile, limit=None):
    """接口：返回查询字符串列表。limit=None 表示不设固定上限。"""
    qs = [it['query'] for it in build_query_plan(profile)]
    return qs if limit is None else qs[:int(limit)]


def is_excluded(text, profile):
    """排除词命中=确定无关（如 dental enamel 之于珐琅锅）。拿不准不排除。"""
    t = str(text or '').lower()
    if not t:
        return ''
    for ex in (profile or {}).get('exclusions') or []:
        ex = str(ex).strip().lower()
        if ex and ex in t:
            return ex
    return ''


def validate_hs(hs_candidates):
    """历史贸易验证：每个候选 HS 在 customs_raw 里的真实提单记录数。
    只做标注不过滤：HS 是强辅助信号，不是硬过滤条件。"""
    out = {}
    if not hs_candidates:
        return out
    try:
        from core.memory.db import DB
        db = DB()
        with db.c() as x:
            for hs in hs_candidates:
                like = str(hs).strip() + '%'
                n = x.execute("SELECT COUNT(*) FROM customs_raw WHERE hs LIKE ?", (like,)).fetchone()[0]
                out[str(hs)] = {'rows': int(n), 'validated': n > 0}
    except Exception:
        for hs in hs_candidates:
            out.setdefault(str(hs), {'rows': 0, 'validated': False})
    return out


def measure_query(query, hs_candidates=None):
    """逐查询实测（对本地海关库 customs_raw）：该查询词能命中多少真实提单、
    涉及多少贸易节点（进口商+发货人）。供 CUSTOMS_NODE_COLLECTION 回填 query_stats，
    低价值查询（连续 0 产出）下轮淘汰。"""
    q = str(query or '').strip()
    if not q:
        return {'result_count': 0, 'usable_trade_nodes': 0}
    try:
        from core.memory.db import DB
        db = DB()
        like = '%' + q.lower() + '%'
        with db.c() as x:
            rows = x.execute(
                "SELECT importer, shipper FROM customs_raw WHERE LOWER(descr) LIKE ? OR LOWER(importer) LIKE ? LIMIT 5000",
                (like, like)).fetchall()
        nodes = set()
        for imp, shp in rows:
            if imp: nodes.add(('b', imp.strip().lower()))
            if shp: nodes.add(('s', shp.strip().lower()))
        return {'result_count': len(rows), 'usable_trade_nodes': len(nodes)}
    except Exception:
        return {'result_count': 0, 'usable_trade_nodes': 0}


# ---------- current 真实海关描述反哺产品情报 ----------
_STOP_TOKENS = {'and', 'or', 'the', 'of', 'for', 'with', 'in', 'on', 'to', 'a', 'an',
                'pcs', 'pc', 'set', 'sets', 'ctn', 'ctns', 'carton', 'cartons', 'kg', 'kgs',
                'no', 'nos', 'type', 'item', 'code', 'po', 'style', 'size', 'color', 'colour',
                'material', 'product', 'products', 'goods', 'made', 'china', 'usa', 'new',
                'per', 'as', 'by', 'at', 'from', 'hs', 'shipment', 'cargo', 'container'}


def harvest_description_terms(product_domain_key, profile, min_hits=2, max_terms=30):
    """从 customs_raw 真实提单描述中收割高频产品表达，写入产品情报记忆（product_intel_terms）。

    反哺闭环：产品情报 → 搜索 → 真实贸易描述 → 产品情报更新 → 下一轮搜索。
    采纳规则（保守，防噪声）：
      - 只扫描 HS 候选命中 或 含核心词根的提单描述；
      - 候选词 = 描述中的单词/二元组，须含字母、非停用词、非排除词、非纯数字；
      - 词须与核心词根同现（同一提单描述内），保证是"本产品的真实商业叫法"；
      - 命中 ≥min_hits 条提单才入库。
    返回 {'scanned': n, 'learned': {term: hits}}。"""
    try:
        from core.memory.db import DB
    except Exception:
        return {'scanned': 0, 'learned': {}}
    profile = profile or {}
    core_roots = set()
    for w in str(profile.get('core_name') or '').lower().split():
        w = re.sub(r'[^a-z]', '', w)
        if len(w) >= 3:
            core_roots.add(w)
    if not core_roots:
        return {'scanned': 0, 'learned': {}}
    exclusions = {str(x).lower() for x in (profile.get('exclusions') or [])}
    hs_codes = [str(h) for h in (profile.get('hs_candidates') or [])][:8]
    db = DB()
    rows = []
    try:
        with db.c() as x:
            for root in list(core_roots)[:3]:
                rows += x.execute("SELECT descr FROM customs_raw WHERE LOWER(descr) LIKE ? LIMIT 3000",
                                  ('%' + root + '%',)).fetchall()
            for hs in hs_codes[:4]:
                rows += x.execute("SELECT descr FROM customs_raw WHERE hs LIKE ? LIMIT 1000",
                                  (str(hs) + '%',)).fetchall()
    except Exception:
        return {'scanned': 0, 'learned': {}}
    counts = {}
    for (descr,) in rows:
        t = str(descr or '').lower()
        if not t or not any(r in t for r in core_roots):
            continue
        if any(ex and ex in t for ex in exclusions):
            continue
        words = [w for w in re.split(r'[^a-z]+', t) if len(w) >= 3 and w not in _STOP_TOKENS]
        wset = set(words)
        # 二元组：含核心词根的相邻组合（"cast iron"、"enamel pot" 这类真实商业叫法）
        for i in range(len(words) - 1):
            bg = words[i] + ' ' + words[i + 1]
            if any(r in (words[i], words[i + 1]) for r in core_roots) and not any(ex in bg for ex in exclusions):
                counts[bg] = counts.get(bg, 0) + 1
        # 单词：修饰/形态词（与核心词同现的才叫法，如 cast / iron / coated）
        for w in wset - core_roots:
            counts[w] = counts.get(w, 0) + 1
    learned = {t: c for t, c in counts.items() if c >= int(min_hits)}
    learned = dict(sorted(learned.items(), key=lambda kv: -kv[1])[:int(max_terms)])
    # 已经在 16 维矩阵里的词不重复学习
    existing = set()
    for k in ('core_name', 'synonyms', 'precision_terms', 'recall_terms', 'combo_queries'):
        v = profile.get(k)
        for q in ([v] if isinstance(v, str) else (v or [])):
            existing.add(str(q).lower().strip())
    learned = {t: c for t, c in learned.items() if t not in existing}
    if learned:
        try:
            db.save_intel_terms(product_domain_key, learned)
        except Exception:
            pass
    return {'scanned': len(rows), 'learned': learned}


def learned_recall_queries(product_domain_key, min_hits=2, limit=10):
    """读取产品情报记忆中学到的词，生成 learned_recall 查询（低优先级、有上限）。"""
    try:
        from core.memory.db import DB
        rows = DB().list_intel_terms(product_domain_key, status='learned', min_hits=min_hits, limit=limit)
        return [{'query': r['term'], 'query_type': 'learned_recall', 'expected_role': 'both',
                 'expected_product_relation': 'broad', 'priority': 55,
                 'result_count': None, 'usable_trade_nodes': None,
                 'usable_trade_edges': None, 'precision_estimate': None,
                 'recall_contribution': None, 'learned_hits': r['hits']} for r in rows]
    except Exception:
        return []
