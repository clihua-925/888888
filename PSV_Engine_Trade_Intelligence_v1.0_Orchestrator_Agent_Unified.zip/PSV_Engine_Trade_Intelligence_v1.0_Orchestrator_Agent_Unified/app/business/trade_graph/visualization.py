# -*- coding: utf-8 -*-
"""Trade Graph Visualization (FULL)

贸易图谱核心对象：
客户、供应商、产品、贸易记录、贸易边、联系人、品牌、企业、地址、证据

核心关系：
客户 ↔ 贸易边 ↔ 供应商

必须支持：
1. 节点点击
2. 边点击
3. 查看贸易证据
4. 查看交易次数
5. 查看首末交易时间
6. 查看产品
7. 查看来源
8. 查看关系强度
9. 查看网络深度
10. 从节点直接进入情报中心
11. 从节点直接启动网络扩张
12. 从节点直接进入业务中心

图谱必须成为【关系探索入口】而不是简单的数据展示页面。
"""
import time, json, sqlite3
from typing import Dict, List, Any, Optional
from core.memory.db import DB


class TradeGraphVisualization:
    def __init__(self, db: DB = None):
        self.db = db or DB()

    def get_graph(self, center_norm: str = None, category_id: str = None,
                  depth: int = 1, limit: int = 200) -> Dict[str, Any]:
        """
        获取贸易图谱数据（供前端可视化库如 D3/Cytoscape 使用）。

        Returns:
            {
                'nodes': [ {id, label, type, role, ...} ],
                'edges': [ {id, source, target, relation, ...} ],
                'center': center_norm,
                'category_id': category_id,
            }
        """
        nodes = []
        edges = []
        seen_norms = set()

        if center_norm:
            # 从中心节点按深度做 BFS；depth=1 为直接贸易邻居，避免 UI
            # 请求 depth=2/3 却只返回一层。
            center_entity = self.db.get_entity(center_norm)
            if center_entity:
                nodes.append(self._format_node(center_entity, is_center=True))
                seen_norms.add(center_norm)

            frontier = {center_norm}
            max_depth = max(1, min(int(depth or 1), 5))
            for _level in range(max_depth):
                next_frontier = set()
                for current_norm in frontier:
                    for edge in self.db.list_trade_edges(norm=current_norm, category_id=category_id):
                        if category_id and edge.get('category_id') != category_id:
                            continue
                        formatted = self._format_edge(edge)
                        if formatted['id'] not in {e['id'] for e in edges}:
                            edges.append(formatted)
                        other_norm = edge['to_norm'] if edge['from_norm'] == current_norm else edge['from_norm']
                        if other_norm not in seen_norms:
                            other_entity = self.db.get_entity(other_norm)
                            if other_entity:
                                nodes.append(self._format_node(other_entity))
                                seen_norms.add(other_norm)
                                next_frontier.add(other_norm)
                        if len(edges) >= limit:
                            break
                    if len(edges) >= limit:
                        break
                frontier = next_frontier
                if not frontier or len(edges) >= limit:
                    break
        else:
            # 全局图谱（按品类筛选）
            all_edges = self.db.list_trade_edges(category_id=category_id)
            for edge in all_edges[:limit]:
                if category_id and edge.get('category_id') != category_id:
                    continue
                for norm in [edge['from_norm'], edge['to_norm']]:
                    if norm not in seen_norms:
                        entity = self.db.get_entity(norm)
                        if entity:
                            nodes.append(self._format_node(entity))
                            seen_norms.add(norm)
                edges.append(self._format_edge(edge))

        return {
            'nodes': nodes,
            'edges': edges,
            'center': center_norm,
            'category_id': category_id,
            'node_count': len(nodes),
            'edge_count': len(edges),
        }

    def get_node_detail(self, norm: str) -> Dict[str, Any]:
        """点击节点后显示的详细信息，支持直接进入情报中心/业务中心"""
        entity = self.db.get_entity(norm)
        if not entity:
            return {'ok': False, 'error': 'Node not found'}

        entity_id = entity['entity_id']
        edges = self.db.list_trade_edges(entity_id=entity_id)
        contacts = self.db.list_entity_contacts(entity_id)
        evidence = self.db.list_evidence(entity_id)
        lifecycle = self.db.get_lifecycle_history(entity_id)

        # 计算是否可进入业务中心
        dev_ready = self._check_dev_ready(entity_id)

        return {
            'ok': True,
            'node': {
                'norm': norm,
                'name': entity.get('name', norm),
                'entity_id': entity_id,
                'type': 'entity',
                'roles': self.db.get_entity_roles(entity_id),
                'country': entity.get('country', ''),
                'industry': entity.get('industry', ''),
                'product_categories': entity.get('product_categories', ''),
                'website': entity.get('website', ''),
                'info_completeness': entity.get('info_completeness', 0),
            },
            'trade_edges': edges,
            'contacts': contacts,
            'evidence': evidence,
            'lifecycle': lifecycle,
            'actions': {
                'view_intelligence': f"/api/intelligence/{norm}",
                'start_expansion': f"/api/network/expand?seed={norm}",
                'add_to_development': f"/api/development/start?lead={norm}" if dev_ready else None,
            },
            'dev_ready': dev_ready,
        }

    def get_edge_detail(self, edge_id: str) -> Dict[str, Any]:
        """点击边后显示的详细信息"""
        with self.db.c() as x:
            x.row_factory = sqlite3.Row
            row=x.execute("SELECT * FROM trade_edges WHERE edge_id=?",(edge_id,)).fetchone()
            if not row: return {'ok':False,'error':'Edge not found'}
            edge=dict(row)

        return {
            'ok': True,
            'edge': {
                'edge_id': edge_id,
                'from': edge.get('from_norm'),
                'to': edge.get('to_norm'),
                'relation': edge.get('relation'),
                'product': edge.get('product'),
                'hs_code': edge.get('hs_code'),
                'shipment_count': edge.get('shipment_count', 0),
                'first_trade': edge.get('first_trade'),
                'last_trade': edge.get('last_trade'),
                'evidence': edge.get('evidence'),
                'source_type': edge.get('source_type'),
                'confidence': edge.get('confidence', 0),
                'category_id': edge.get('category_id'),
            }
        }

    def get_expansion_path(self, norm: str, task_id: str = None) -> Dict[str, Any]:
        """获取某个节点的网络扩张路径（可视化用）"""
        logs = self.db.get_expansion_logs(task_id) if task_id else []
        # 过滤出与 norm 相关的扩张记录
        related = [l for l in logs if l.get('from_entity_id') == (self.db.get_entity(norm) or {}).get('entity_id')]

        path = []
        for log in related:
            path.append({
                'from': norm,
                'to': log.get('discovered_norm'),
                'strategy': log.get('strategy'),
                'evidence': log.get('evidence'),
                'confidence': log.get('confidence'),
                'round': log.get('round_num'),
            })

        return {
            'norm': norm,
            'task_id': task_id,
            'expansion_path': path,
            'discovered_count': len(path),
        }

    def _format_node(self, entity: Dict, is_center: bool = False) -> Dict:
        return {
            'id': entity.get('norm'),
            'label': entity.get('name', entity.get('norm')),
            'entity_id': entity.get('entity_id'),
            'type': 'center' if is_center else 'entity',
            'role': self.db.get_entity_roles(entity.get('entity_id')) or ['unknown'],
            'country': entity.get('country', ''),
            'industry': entity.get('industry', ''),
            'completeness': entity.get('info_completeness', 0),
            'dev_qualified': bool(entity.get('dev_qualified', 0)),
        }

    def _format_edge(self, edge: Dict) -> Dict:
        return {
            'id': edge.get('edge_id'),
            'source': edge.get('from_norm'),
            'target': edge.get('to_norm'),
            'relation': edge.get('relation'),
            'product': edge.get('product'),
            'shipment_count': edge.get('shipment_count', 0),
            'confidence': edge.get('confidence', 0),
            'source_type': edge.get('source_type', ''),
        }

    def _check_dev_ready(self, entity_id: str) -> bool:
        entity = self.db.get_entity_by_id(entity_id)
        if not entity:
            return False
        contacts = self.db.list_entity_contacts(entity_id)
        has_email = any(c.get('email') for c in contacts)
        return bool(entity.get('dev_qualified', 0)) and has_email
