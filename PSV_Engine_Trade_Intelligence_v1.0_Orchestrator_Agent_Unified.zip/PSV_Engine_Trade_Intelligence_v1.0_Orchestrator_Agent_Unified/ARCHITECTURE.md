PSV Engine unified architecture

business/
  external trade business capabilities

orchestrator/
  workflow scheduling and execution

platform/
  database, audit, recovery, configuration

webui/
  user interface
