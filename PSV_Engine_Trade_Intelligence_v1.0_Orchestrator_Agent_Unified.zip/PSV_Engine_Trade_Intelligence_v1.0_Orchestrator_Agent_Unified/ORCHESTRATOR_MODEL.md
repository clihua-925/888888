# PSV Trade Intelligence Orchestrator

业务入口:
Trade Intent

流程:
Intent -> Planner -> Workflow -> Business Agents -> Data Commit -> Intelligence Output

Agents:
- Market Agent
- Company Discovery Agent
- Enrichment Agent
- Customer Scoring Agent
- Trade Graph Agent

Platform services provide execution support only.
