from pathlib import Path
import sqlite3, sys

ROOT=Path(__file__).parent
errors=[]
for p in [ROOT/"core", ROOT/"data", ROOT/"requirements.txt"]:
    if not p.exists(): errors.append(f"missing:{p}")

db=ROOT/"data"/"psv.db"
if db.exists():
    try:
        sqlite3.connect(db).execute("select 1")
    except Exception as e: errors.append("database:"+str(e))
else: errors.append("missing database")
if errors:
    print("STARTUP CHECK FAILED")
    for e in errors: print("-",e)
    sys.exit(1)
print("STARTUP CHECK OK")
