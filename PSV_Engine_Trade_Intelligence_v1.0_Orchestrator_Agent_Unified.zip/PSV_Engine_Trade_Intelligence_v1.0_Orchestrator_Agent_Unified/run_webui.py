from core.config import settings
from core.webui.app import run
if __name__=='__main__':
    print(f'PSV Engine {settings.VERSION} | database: {settings.DATABASE_PATH}')
    run()
