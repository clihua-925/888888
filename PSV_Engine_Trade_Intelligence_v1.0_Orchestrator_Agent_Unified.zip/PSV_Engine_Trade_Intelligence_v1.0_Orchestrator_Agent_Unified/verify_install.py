# -*- coding: utf-8 -*-
"""PSV Engine deployment verification. Run after start.bat installs dependencies."""
import os, sys, sqlite3, tempfile, importlib, pathlib, py_compile, re

ROOT = pathlib.Path(__file__).resolve().parent
required = [
    'run_webui.py', '启动PSV.bat', 'start.bat', 'start_chrome_debug.bat', 'requirements.txt',
    'core/runtime/contracts.py', 'core/runtime/graph.py', 'core/runtime/nodes.py', 'core/runtime/postflow.py',
    'core/trade_graph/customs_node_pipeline.py', 'core/trade_graph/trade_node.py',
    'core/intelligence/account_intelligence_center.py',
    'core/intelligence/waterfall.py', 'core/intelligence/ai_router.py',
    'core/business_execution/execution_center.py', 'core/webui/app.py', 'core/runtime/scheduler.py',
    'core/webui/static/intelligence.html', 'core/webui/static/graph.html', 'core/webui/static/business.html',
    'data/industry_configs/candle.json', 'data/industry_configs/enamel_pot.json', 'data/industry_configs/felt.json',
]
missing=[p for p in required if not (ROOT/p).exists()]
if missing:
    print('[FAIL] missing files:', *missing, sep='\n  '); raise SystemExit(2)

for p in ROOT.rglob('*.py'):
    py_compile.compile(str(p), doraise=True)
print('[OK] Python compilation')

os.environ['DATABASE_PATH'] = str(ROOT/'data'/'_verify_temp.db')
try:
    from core.memory.db import DB
    db=DB()
    count=db.c().execute("select count(*) from sqlite_master where type='table'").fetchone()[0]
    print('[OK] SQLite init:', count, 'tables')
    from core.config.industry import load_industry
    cfg=load_industry('enamel_pot')
    assert cfg.get('keywords') and cfg.get('search_terms')
    print('[OK] enamel_pot config')
    from core.trade_graph.visualization import TradeGraphVisualization
    assert TradeGraphVisualization(db).get_graph(depth=2)['node_count'] == 0
    print('[OK] trade graph service')
except Exception as e:
    print('[FAIL] core verification:', e); raise
finally:
    try: (ROOT/'data'/'_verify_temp.db').unlink()
    except FileNotFoundError: pass

# These must not remain as active dependencies in the merged build.
text='\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in (ROOT/'core').rglob('*.py'))
for bad in ('from core.runtime.development import run_sequence', "fetch('/api/enrich'", 'NetworkExpansionEngine', 'from core.intelligence.network_expansion'):
    if bad in text:
        print('[FAIL] stale reference:', bad); raise SystemExit(3)
print('[OK] stale reference scan')

# Current release must be the only active version identity.
all_text = '\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in ROOT.rglob('*')
                  if p.is_file() and p.name != 'verify_install.py'
                  and not p.name.startswith('DATA_AUDIT') and p.name != 'CHANGELOG.txt'
                  and p.suffix.lower() in ('.py','.md','.txt','.example'))
for stale in tuple(f'v45.{x}' for x in range(10,22)):
    if stale in all_text:
        print('[FAIL] stale release marker:', stale); raise SystemExit(6)
for stale in ('@app.route(\"/api/task"', 'NetworkExpansionEngine', 'from core.intelligence.network_expansion'):
    if stale in all_text:
        print('[FAIL] stale interface marker:', stale); raise SystemExit(6)
print('[OK] current release/interface scan')

# Shared judgment smoke test: write/read must be stable and evidence rules must avoid unnecessary AI.
from core.runtime import nodes as _nodes
_smoke = {'judgment_registry': {}}
_obj = {'from_name':'A','to_name':'B','relation':'buyer_to_supplier','source':'importyeti',
        'evidence': {'shipments': 5, 'hs':['3406'], 'products':'birthday candles'}}
_j = {'_ai_success': True, 'recommended_level':'STRONG', 'confidence':0.96}
_nodes._shared_put(_smoke, 'EVIDENCE_VERIFY', _obj, _j, 'AI_DEEP')
assert _nodes._shared_get(_smoke, 'EVIDENCE_VERIFY', _obj) is not None
assert _nodes._edge_needs_ai(_obj) is False
print('[OK] shared judgment smoke test')
# Target Fit must be a real semantic gate: HS-only evidence is not enough for a
# specific product, while explicit product terms can pass deterministically.
_gate_state={'product_domain':{'hs_candidates':['3406'],'key':'birthday_candles'},
             'product_profile':{'canonical':'birthday candles','synonyms':['birthday candles'],'precision_terms':['candle numeral']}}
assert _nodes._target_fit_rule_gate({'name':'Generic Candle Trader','evidence':{'hs':['3406.00'],'products':'Wax Candles'}}, _gate_state) is None
assert _nodes._target_fit_rule_gate({'name':'Birthday Candle Co','evidence':{'hs':['3406.00'],'products':'Birthday Candles'}}, _gate_state).get('target_fit') == 'TARGET_RELEVANT'
_gate_state['companies']=[{'name':'Generic Candle Trader','target_fit':'UNCERTAIN','target_fit_judgment':{'target_fit':'UNCERTAIN','_ai_success':True}},
                          {'name':'Birthday Candle Co','target_fit':'TARGET_RELEVANT','target_fit_judgment':{'target_fit':'TARGET_RELEVANT','_ai_success':True}}]
_gate_state['company_entities']=_gate_state['companies']
_g=_nodes._build_expansion_gate(_gate_state,_gate_state['company_entities'])
assert _g['pending_count'] == 0 and _g['eligible_count'] == 1
print('[OK] Node 7 Target Fit precondition')
# ImportYeti URL/relationship parser smoke: location/company is NOT a company URL.
from core.tools.iy_web import is_trade_entity_url, parse_rel_card
assert is_trade_entity_url('https://www.importyeti.com/company/decopac')
assert is_trade_entity_url('https://www.importyeti.com/supplier/universal-candle-vietnam')
assert not is_trade_entity_url('https://www.importyeti.com/location/company/united-states-of-america/city/5016450-anoka')
assert not is_trade_entity_url('https://www.importyeti.com/location/company/united-states-of-america/country')
_rel = parse_rel_card('Decopac\nAnoka\nUnited States of America\n97\nWax Candles\nHS Codes: (3406.00)', 'Decopac', 'Anoka')
assert _rel['location'] == 'Anoka' and 'decopac' not in _rel['products'].lower() and 'anoka' not in _rel['products'].lower()
print('[OK] ImportYeti entity/location parser smoke')

# Node 7 regression: n_graph_expansion must return a separate output mapping.
# The orchestrator strips private keys (including `nodes`) from node output. Returning
# the live state object would therefore delete the orchestrator's own state['nodes']
# and reproduce KeyError: 'nodes'. This test guards the exact failure seen in psv(8).db.
import core.runtime.nodes as _n7
_orig_n7 = (_n7.n_seed_buyers, _n7.n_supplier_mining, _n7.n_reverse_harvest)
try:
    def _fake_seed(s):
        seeds=[c for c in (s.get('companies') or []) if c.get('target_fit')=='TARGET_RELEVANT']
        return {'seed_buyers':seeds,'companies':seeds,'_success':True,'_note':'regression'}
    def _fake_mine(s):
        return {'suppliers':[],'supplier_new':[],'trade_graph':{'nodes':[],'edges':[],'stats':{}},'_success':True}
    def _fake_harvest(s):
        return {'companies':list(s.get('companies') or []),'supplier_new':[],'suppliers':[],
                'trade_graph':s.get('trade_graph'),'_success':True}
    _n7.n_seed_buyers, _n7.n_supplier_mining, _n7.n_reverse_harvest = _fake_seed, _fake_mine, _fake_harvest
    _n7_state={'nodes':['sentinel'],
               'companies':[{'name':'Regression Target','target_fit':'TARGET_RELEVANT',
                             'evidence':{'url':'https://www.importyeti.com/company/regression-target'}}],
               'company_entities':[{'name':'Regression Target','target_fit':'TARGET_RELEVANT'}],
               'trade_edges':[], 'trade_graph':{'nodes':[],'edges':[],'stats':{}},
               'strategy':{'expansion_policy':{'max_depth':1,'per_seed_budget':1,'global_new_entity_budget':1}},
               'expansion_rounds':0,'quantity':1,'product_domain':{'key':'regression'},
               'route_state':{}}
    _n7_out=_n7.n_graph_expansion(_n7_state)
    assert _n7_out is not _n7_state and _n7_state.get('nodes') == ['sentinel'], 'Node 7 mutated live orchestrator state'
    print('[OK] Node 7 output/state isolation regression')
finally:
    _n7.n_seed_buyers, _n7.n_supplier_mining, _n7.n_reverse_harvest = _orig_n7

# Canonical package must not contain obsolete packaged versions/backup artifacts.
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    n=p.name.lower()
    if any(tag in n for tag in ('backup','\u590d\u5236','\u62f7\u8d1d','\u65e7版')) or re.search(r'v45\.(?:10|11|12|13|14)(?:\D|$)', p.name, re.I):
        print('[FAIL] obsolete artifact:', p.relative_to(ROOT)); raise SystemExit(4)
print('[OK] obsolete artifact scan')

canonical=(ROOT/'VERSION.txt').read_text(encoding='utf-8').strip()
if canonical != 'PSV Engine v46.0':
    print('[FAIL] canonical version mismatch:', canonical); raise SystemExit(5)
print('[OK] canonical version:', canonical)

# Canonical version must be aligned across executable configuration and runtime metadata.
settings_text=(ROOT/'core'/'config'/'settings.py').read_text(encoding='utf-8')
if "VERSION='v46.0'" not in settings_text:
    print('[FAIL] settings.py version is not v46.0'); raise SystemExit(7)
# Reject obvious replacement/mojibake markers in filenames without banning legitimate CJK names.
for p in ROOT.rglob('*'):
    if any(ord(ch) == 0xFFFD for ch in p.name) or 'ï¿½' in p.name:
        print('[FAIL] mojibake filename:', p.relative_to(ROOT)); raise SystemExit(8)
print('[OK] canonical version/filename alignment')
print('PSV deployment verification passed.')
