PSV Engine Trade Intelligence v1.0

Core:
- Foreign trade intelligence system
- Customer discovery
- Company profiling
- Market intelligence
- Trade graph

Architecture:
Business Layer -> Orchestrator -> Platform Services

The orchestrator is infrastructure, not the product core.
