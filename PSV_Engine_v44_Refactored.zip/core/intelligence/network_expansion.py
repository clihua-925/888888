# -*- coding: utf-8 -*-
"""Network Expansion Engine v42
核心职责：从客户情报中心触发，5种扩张方向，结果自动进入候选池并同步贸易图谱。
"""

import json, time, uuid
from typing import List, Dict
from core.memory.db import DB
from core.intelligence.ai_router import ai_route
from core.intelligence.stop_condition import InformationGainStopCondition

class NetworkExpansionEngine:
    EXPANSION_TYPES = {
        'customer_to_supplier': '客户→供应商（找供应商的其他客户）',
        'supplier_to_customer': '供应商→客户（找工厂的其他买家）',
        'customer_to_customer': '客户→客户（找同类采购商）',
        'product_expansion': '产品扩张（找同产品进口商）',
        'enterprise_association': '企业关联扩张（同地址/品牌/集团/联系人）'
    }

    def __init__(self):
        self.db = DB()
        self.stop_condition = InformationGainStopCondition(patience=3)

    def expand(self, seed_norm: str, expansion_types: List[str] = None,
               depth: int = 5, max_new: int = 50) -> dict:
        """网络扩张主入口。使用信息增益停止机制，禁止固定时间停止。"""
        task_id = f"exp-{uuid.uuid4().hex[:8]}"
        if not expansion_types:
            expansion_types = list(self.EXPANSION_TYPES.keys())

        seed_intelligence = self.db.get_account_intelligence(seed_norm)
        if not seed_intelligence:
            seed_lead = self.db.get_lead(seed_norm)
            if not seed_lead:
                return {'ok': False, 'error': 'seed not found', 'seed_norm': seed_norm}
            seed_intelligence = {'norm': seed_norm, 'name': seed_lead.get('name')}

        all_discovered = []
        round_results = []
        total_new_customers = 0
        total_new_suppliers = 0
        total_new_edges = 0

        current_seeds = [seed_norm]
        stop_reason = 'depth_reached'

        for round_num in range(1, depth + 1):
            round_discovered = []
            round_customers = 0
            round_suppliers = 0
            round_edges = 0

            for current_seed in current_seeds:
                if len(all_discovered) >= max_new * 2:
                    break
                for exp_type in expansion_types:
                    discovered = self._execute_expansion(
                        task_id, current_seed, exp_type, 
                        seed_intelligence, max_new_per_type=max(5, max_new // len(expansion_types))
                    )
                    round_discovered.extend(discovered)
                    for d in discovered:
                        if d.get('relation_type') == 'customer':
                            round_customers += 1
                        elif d.get('relation_type') == 'supplier':
                            round_suppliers += 1
                        round_edges += 1

            seen = set()
            unique_discovered = []
            for d in round_discovered:
                key = d.get('discovered_norm', '')
                if key and key not in seen:
                    seen.add(key)
                    unique_discovered.append(d)

            # 保存到网络发现表 + 同步到贸易图谱
            for d in unique_discovered:
                self.db.save_network_discovered(
                    task_id=task_id,
                    seed_norm=d.get('seed_norm'),
                    discovered_norm=d.get('discovered_norm'),
                    relation_type=d.get('relation_type'),
                    relation_path=d.get('relation_path'),
                    evidence=d.get('evidence', {})
                )
                # v42新增：同步创建贸易边到 relationships 表
                self._sync_to_trade_graph(d, round_num)

            imported = self._auto_import(task_id, unique_discovered)

            round_results.append({
                'round': round_num,
                'discovered': len(unique_discovered),
                'new_customers': round_customers,
                'new_suppliers': round_suppliers,
                'new_edges': round_edges,
                'imported': imported
            })

            all_discovered.extend(unique_discovered)
            total_new_customers += round_customers
            total_new_suppliers += round_suppliers
            total_new_edges += round_edges

            # v42：使用信息增益停止机制（替代旧的 _check_info_gain_stop）
            stop_check = self.stop_condition.check(round_num)
            if stop_check['should_stop']:
                stop_reason = 'information_gain_stop'
                break

            # 备选：无新种子时停止
            current_seeds = [d['discovered_norm'] for d in unique_discovered 
                           if d.get('relation_type') in ('customer', 'supplier')][:20]
            if not current_seeds:
                stop_reason = 'no_more_seeds'
                break

        result = {
            'rounds': len(round_results),
            'total_discovered': len(all_discovered),
            'new_customers': total_new_customers,
            'new_suppliers': total_new_suppliers,
            'new_trade_edges': total_new_edges,
            'round_details': round_results
        }
        # 修复：save_expansion_task 参数适配
        self.db.save_expansion_task_v42(
            task_id=task_id,
            seed_norm=seed_norm,
            expansion_types=expansion_types,
            depth=depth,
            max_new=max_new,
            status='done',
            result=result
        )

        return {
            'ok': True,
            'task_id': task_id,
            'seed_norm': seed_norm,
            'rounds': len(round_results),
            'total_discovered': len(all_discovered),
            'new_customers': total_new_customers,
            'new_suppliers': total_new_suppliers,
            'new_trade_edges': total_new_edges,
            'stop_reason': stop_reason,
            'details': round_results
        }

    def _sync_to_trade_graph(self, d: dict, round_num: int):
        """v42新增：将网络扩张结果同步到贸易图谱 relationships 表"""
        relation_type = d.get('relation_type', 'associated')
        # 映射到 relationships 表的 relation 字段
        rel_map = {
            'customer': 'supplies_to',
            'supplier': 'supplied_by',
            'associated': 'associated'
        }
        relation = rel_map.get(relation_type, 'associated')
        evidence = d.get('evidence', {})
        evidence['expansion_type'] = d.get('exp_type', 'unknown')
        evidence['discovery_round'] = round_num
        evidence['relation_path'] = d.get('relation_path', '')

        try:
            self.db.save_relationship(
                from_norm=d.get('seed_norm'),
                to_norm=d.get('discovered_norm'),
                relation=relation,
                source='network_expansion',
                evidence=json.dumps(evidence, ensure_ascii=False),
                product=evidence.get('shared_hs', evidence.get('shared_product', '')),
                time_range='',
                transaction_count=evidence.get('trade_count', 0)
            )
        except Exception as e:
            # 同步失败不阻塞主流程
            pass

    def _execute_expansion(self, task_id: str, seed_norm: str, exp_type: str,
                           seed_intelligence: dict, max_new_per_type: int) -> List[dict]:
        if exp_type == 'customer_to_supplier':
            return self._expand_customer_to_supplier(seed_norm, seed_intelligence, max_new_per_type)
        elif exp_type == 'supplier_to_customer':
            return self._expand_supplier_to_customer(seed_norm, seed_intelligence, max_new_per_type)
        elif exp_type == 'customer_to_customer':
            return self._expand_customer_to_customer(seed_norm, seed_intelligence, max_new_per_type)
        elif exp_type == 'product_expansion':
            return self._expand_product(seed_norm, seed_intelligence, max_new_per_type)
        elif exp_type == 'enterprise_association':
            return self._expand_enterprise_association(seed_norm, seed_intelligence, max_new_per_type)
        return []

    def _expand_customer_to_supplier(self, seed_norm: str, intelligence: dict, max_new: int) -> List[dict]:
        discovered = []
        trades = intelligence.get('trades', [])
        for trade in trades:
            suppliers = trade.get('current_suppliers', [])
            for supplier_name in suppliers[:10]:
                related = self._query_related_companies(
                    supplier_name, 'customer', exclude_norm=seed_norm, limit=max_new
                )
                for rel in related:
                    discovered.append({
                        'seed_norm': seed_norm,
                        'discovered_norm': rel['norm'],
                        'relation_type': 'customer',
                        'relation_path': f"{seed_norm} → 供应商({supplier_name}) → 其他客户({rel['name']})",
                        'evidence': {
                            'shared_supplier': supplier_name,
                            'supplier_trade_count': trade.get('shipment_count', 0),
                            'source': 'customs_network'
                        }
                    })
        return discovered

    def _expand_supplier_to_customer(self, seed_norm: str, intelligence: dict, max_new: int) -> List[dict]:
        discovered = []
        with self.db.c() as c:
            c.row_factory = __import__('sqlite3').Row
            sql = """SELECT DISTINCT importer_norm, importer, COUNT(*) as cnt 
                FROM customs_raw 
                WHERE shipper_norm=? OR lower(shipper)=lower(?)
                GROUP BY importer_norm 
                ORDER BY cnt DESC LIMIT ?"""
            rows = c.execute(sql, (seed_norm, intelligence.get('name', ''), max_new)).fetchall()
            for row in rows:
                if row['importer_norm'] and row['importer_norm'] != seed_norm:
                    discovered.append({
                        'seed_norm': seed_norm,
                        'discovered_norm': row['importer_norm'],
                        'relation_type': 'customer',
                        'relation_path': f"{seed_norm}(供应商) → 买家({row['importer']})",
                        'evidence': {
                            'trade_count': row['cnt'],
                            'source': 'customs_raw'
                        }
                    })
        return discovered

    def _expand_customer_to_customer(self, seed_norm: str, intelligence: dict, max_new: int) -> List[dict]:
        discovered = []
        trades = intelligence.get('trades', [])
        hs_codes = list(set(t.get('hs_code', '') for t in trades if t.get('hs_code')))
        if not hs_codes:
            return discovered
        with self.db.c() as c:
            c.row_factory = __import__('sqlite3').Row
            for hs in hs_codes[:3]:
                limit = max(2, max_new // len(hs_codes)) if hs_codes else max_new
                sql = """SELECT DISTINCT importer_norm, importer, COUNT(*) as cnt
                    FROM customs_raw
                    WHERE hs=? AND importer_norm != ?
                    GROUP BY importer_norm
                    ORDER BY cnt DESC LIMIT ?"""
                rows = c.execute(sql, (hs, seed_norm, limit)).fetchall()
                for row in rows:
                    discovered.append({
                        'seed_norm': seed_norm,
                        'discovered_norm': row['importer_norm'],
                        'relation_type': 'customer',
                        'relation_path': f"{seed_norm} ← 同HS({hs}) → {row['importer']}",
                        'evidence': {
                            'shared_hs': hs,
                            'trade_count': row['cnt'],
                            'source': 'customs_hs_match'
                        }
                    })
        return discovered

    def _expand_product(self, seed_norm: str, intelligence: dict, max_new: int) -> List[dict]:
        # 产品扩张与客户→客户逻辑相同（同HS进口商）
        return self._expand_customer_to_customer(seed_norm, intelligence, max_new)

    def _expand_enterprise_association(self, seed_norm: str, intelligence: dict, max_new: int) -> List[dict]:
        discovered = []
        address = intelligence.get('address', '')
        if address and len(address) > 10:
            with self.db.c() as c:
                c.row_factory = __import__('sqlite3').Row
                sql = """SELECT norm, name, address FROM leads 
                    WHERE norm != ? AND address IS NOT NULL AND address != ''
                    AND length(address) > 10"""
                rows = c.execute(sql, (seed_norm,)).fetchall()
                for row in rows:
                    if self._address_similar(address, row['address']):
                        discovered.append({
                            'seed_norm': seed_norm,
                            'discovered_norm': row['norm'],
                            'relation_type': 'associated',
                            'relation_path': f"{seed_norm} ← 同地址 → {row['name']}",
                            'evidence': {
                                'shared_address': row['address'],
                                'source': 'address_match'
                            }
                        })

        brands = intelligence.get('brand_info', [])
        if isinstance(brands, str):
            brands = [brands] if brands else []
        if brands:
            with self.db.c() as c:
                c.row_factory = __import__('sqlite3').Row
                for brand in brands:
                    limit = max(2, max_new // len(brands)) if brands else max_new
                    sql = """SELECT norm, name FROM account_intelligence
                        WHERE norm != ? AND brand_info LIKE ?
                        LIMIT ?"""
                    rows = c.execute(sql, (seed_norm, f'%{brand}%', limit)).fetchall()
                    for row in rows:
                        discovered.append({
                            'seed_norm': seed_norm,
                            'discovered_norm': row['norm'],
                            'relation_type': 'associated',
                            'relation_path': f"{seed_norm} ← 同品牌({brand}) → {row['name']}",
                            'evidence': {
                                'shared_brand': brand,
                                'source': 'brand_match'
                            }
                        })
        return discovered[:max_new]

    def _query_related_companies(self, name: str, relation_type: str, 
                                  exclude_norm: str, limit: int) -> List[dict]:
        with self.db.c() as c:
            c.row_factory = __import__('sqlite3').Row
            sql = """SELECT DISTINCT importer_norm as norm, importer as name
                FROM customs_raw
                WHERE shipper=? AND importer_norm != ?
                LIMIT ?"""
            rows = c.execute(sql, (name, exclude_norm, limit)).fetchall()
            return [{'norm': r['norm'], 'name': r['name']} for r in rows]

    def _address_similar(self, addr1: str, addr2: str) -> bool:
        a1 = addr1.lower().replace(',', ' ').split()
        a2 = addr2.lower().replace(',', ' ').split()
        common = set(a1) & set(a2)
        has_number = any(any(c.isdigit() for c in token) for token in common)
        return len(common) >= 3 and has_number

    def _auto_import(self, task_id: str, discovered: List[dict]) -> int:
        imported = 0
        for d in discovered:
            norm = d.get('discovered_norm')
            if not norm:
                continue
            existing = self.db.get_lead(norm)
            if existing:
                continue
            try:
                self.db.save_lead({
                    'norm': norm,
                    'name': norm.replace('_', ' ').title(),
                    'kind': d.get('relation_type', 'unknown'),
                    'zone': 'discovered',
                    'source': f"network_expansion:{d.get('relation_path', '')}",
                    'status': 'discovered',
                    'score': 0,
                    'grade': 'U'
                })
                imported += 1
            except Exception:
                pass
        return imported

_engine = None

def get_engine() -> NetworkExpansionEngine:
    global _engine
    if _engine is None:
        _engine = NetworkExpansionEngine()
    return _engine

def expand(seed_norm: str, **kwargs) -> dict:
    return get_engine().expand(seed_norm, **kwargs)
