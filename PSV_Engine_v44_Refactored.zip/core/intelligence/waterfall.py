# -*- coding: utf-8 -*-
"""ENRICHMENT WATERFALL v37：字段级补全（Clay 模式落地）。

原则：
- 逐字段独立 waterfall：website/emails/phones/contact_person/address 各有自己的 provider 链
- 成功即停：某字段拿到值就不再消耗更贵的 provider
- 便宜优先：官网正则（免费）→ 本地模型（便宜）→ 浏览器AI（贵）→ 搜索（仅 website）
- 最后验证：邮箱统一做语法 + 每域名一次 MX 检查，不信任 provider 自报
- 全程留痕：每一步写 enrichment_events（field/provider/value/ok）
单字段失败不阻塞其他字段；全部字段有值或 provider 耗尽即停。
"""
import re
import json
from core.memory.db import DB
from core.intelligence import ai_gateway

FIELDS = ['website', 'intro', 'emails', 'phones', 'contact_person', 'linkedin', 'address']


def _meta_intro(html):
    """从官网 meta description / og:description 提取公司简介（免费、确定来源）。"""
    for pat in (r'<meta[^>]+(?:name|property)=["\'](?:description|og:description)["\'][^>]+content=["\']([^"\']{10,300})',
                r'<meta[^>]+content=["\']([^"\']{10,300})["\'][^>]+(?:name|property)=["\'](?:description|og:description)["\']'):
        m = re.search(pat, html or '', re.I)
        if m: return m.group(1).strip()[:300]
    return ''


def _regex_extract(html):
    """v38：官网 HTML 免费提取（联系字段 + 简介 + LinkedIn），不再经过 ContactFinder 旧整记录流程。"""
    from core.tools.contact_finder import ContactFinder
    out = ContactFinder()._extract_from_html(html)
    intro = _meta_intro(html)
    if intro: out['intro'] = intro
    m = re.search(r'https?://(?:www\.)?linkedin\.com/(?:company|in)/[A-Za-z0-9_-]+', html or '')
    if m: out['linkedin'] = m.group(0)
    return out
_EMAIL_RE = r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
ROLE_PREFIXES = ('info', 'sales', 'support', 'admin', 'contact', 'office', 'hello', 'mail', 'service')
_mx_cache = {}


def _valid_email(e):
    e = str(e or '').strip().lower()
    return bool(re.fullmatch(_EMAIL_RE, e))


def mx_ok(domain):
    """每域名一次 MX 检查（缓存）；dnspython 不可用时退化为 None（未知不判死）。"""
    domain = str(domain or '').lower().strip()
    if not domain: return None
    if domain in _mx_cache: return _mx_cache[domain]
    ok = None
    try:
        import dns.resolver
        ok = bool(dns.resolver.resolve(domain, 'MX', lifetime=6))
    except Exception:
        ok = None
    _mx_cache[domain] = ok
    return ok


def verify_emails(emails):
    """语法 + 去重 + 去角色邮箱优先降级 + MX；返回 [(email, status)]，status∈mx_ok/syntax_ok/invalid/no_mx。"""
    out = []; seen = set()
    for e in emails or []:
        e = str(e).strip().lower()
        if not e or e in seen: continue
        seen.add(e)
        if not _valid_email(e): out.append((e, 'invalid')); continue
        m = mx_ok(e.split('@', 1)[1])
        out.append((e, 'mx_ok' if m else ('syntax_ok' if m is None else 'no_mx')))
    # 角色邮箱排后（可发但优先级低）
    out.sort(key=lambda t: (t[0].split('@')[0] in ROLE_PREFIXES, t[0]))
    return out


def _fetch(url, timeout=15):
    import requests
    r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=timeout)
    return r.text or ''


def _llm_extract(lead, html, fields):
    want = '、'.join(fields)
    prompt = (f'从公司官网HTML中提取以下字段：{want}。公司: {lead.get("name")}\n'
              '只输出JSON，键为 website/intro/emails/phones/contact_person/linkedin/address，emails/phones 用数组。不知道就省略该键。\n'
              f'HTML前5000字符: {html[:5000]}')
    r = ai_gateway.chat(prompt, task='enrich_extract', temperature=0.1, max_tokens=400, timeout=120)
    if not r['ok']: return {}
    try:
        txt = r['text']; j = json.loads(txt[txt.find('{'):txt.rfind('}') + 1])
        return {k: v for k, v in j.items() if k in FIELDS and v}
    except Exception:
        return {}


def _webai_extract(lead, fields):
    from core.config import settings
    if not settings.WEBAI_ENABLED: return {}
    want = '、'.join(fields)
    prompt = (f'请提供 "{lead.get("name")}" 这家公司的公开信息：{want}。\n'
              '只返回JSON，键为 website/intro/emails/phones/contact_person/linkedin/address，不知道就省略。')
    r = ai_gateway.chat(prompt, task='enrich_webai', timeout=150)
    if not r['ok']: return {}
    try:
        txt = r['text']; j = json.loads(txt[txt.find('{'):txt.rfind('}') + 1])
        return {k: v for k, v in j.items() if k in FIELDS and v}
    except Exception:
        return {}


def enrich_lead(norm, fields=None):
    """字段级 waterfall 主入口。返回 {field: {value, provider, verified}} 与缺口列表。"""
    db = DB(); lead = db.get_lead(norm)
    if not lead: return {'ok': False, 'error': '客户不存在'}
    fields = fields or FIELDS
    missing = [f for f in fields if not lead.get(f)]
    result = {'ok': True, 'filled': {}, 'still_missing': [], 'events': 0}
    if not missing:
        result['note'] = '所有字段已有值，无需补全'; return result

    def fill(field, value, provider):
        nonlocal lead
        if isinstance(value, list): value = ','.join(str(v) for v in value[:5])
        value = str(value).strip()[:300]
        if not value: return False
        db.lead_update(norm, **{field: value})
        db.add_enrichment_event(norm, field, provider, value, True)
        result['filled'][field] = {'value': value, 'provider': provider}
        result['events'] += 1
        lead = db.get_lead(norm) or lead
        return True

    # ---- website：只有搜索能找到（先查，后续字段都依赖官网） ----
    if 'website' in missing:
        from core.tools.contact_finder import ContactFinder
        w = ContactFinder()._search_website_by_company(lead.get('name'), lead.get('country'))
        db.add_enrichment_event(norm, 'website', 'bing_search', w or '', bool(w))
        if w: fill('website', w, 'bing_search')
    # ---- 官网正则（免费，一次抓取多字段共用） ----
    html = ''
    if lead.get('website'):
        try: html = _fetch(lead['website'])
        except Exception:
            html = ''
            db.add_enrichment_event(norm, 'website_html', 'fetch', '', False)
    if html:
        ext = _regex_extract(html)
        for f in [f for f in missing if f != 'website' and f in ext and not lead.get(f)]:
            fill(f, ext[f], 'website_regex')
    # ---- 本地/网关 LLM 提取（便宜） ----
    still = [f for f in missing if not lead.get(f)]
    if still and html:
        ext = _llm_extract(lead, html, still)
        for f, v in ext.items():
            if f in still and not lead.get(f): fill(f, v, 'ai_gateway:' + str(ext and 'local'))
    # ---- 浏览器 AI 兜底（贵，只为仍缺的关键字段） ----
    still = [f for f in missing if not lead.get(f)]
    key_still = [f for f in still if f in ('emails', 'contact_person', 'phones', 'website')]
    if key_still:
        ext = _webai_extract(lead, key_still)
        for f, v in (ext or {}).items():
            if not lead.get(f): fill(f, v, 'webai')
    # ---- 邮箱最后验证（不信任 provider 自报） ----
    if lead.get('emails'):
        pairs = verify_emails(str(lead['emails']).replace(';', ',').split(','))
        good = [e for e, s in pairs if s in ('mx_ok', 'syntax_ok')]
        status_map = {e: s for e, s in pairs}
        if good and ','.join(good) != str(lead['emails']):
            db.lead_update(norm, emails=','.join(good))
        db.lead_update(norm, email_verified=json.dumps(status_map, ensure_ascii=False))
        result['email_verification'] = status_map
        for e, s in pairs:
            if s != 'invalid':
                db.upsert_contact(norm, e, email_status=s, source='waterfall')
    result['still_missing'] = [f for f in fields if not (db.get_lead(norm) or {}).get(f)]
    # 失败也留痕：每个仍缺字段记录一次"provider 链耗尽"，便于情报中心解释"为什么缺"
    for f in result['still_missing']:
        db.add_enrichment_event(norm, f, 'waterfall_exhausted', '', False)
    result['note'] = f"补全 {len(result['filled'])} 字段，仍缺 {len(result['still_missing'])} 个"
    return result
