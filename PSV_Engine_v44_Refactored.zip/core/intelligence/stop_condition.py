# -*- coding: utf-8 -*-
"""STOP_CONDITION v41：信息增益停止机制。

禁止：运行固定时间直接停止。

规则：连续多轮没有新增客户、没有新增供应商、没有新增贸易边、没有新增有效信息，才停止。
"""
import time
from typing import Dict, List
from core.memory.db import DB


class InformationGainStopCondition:
    """信息增益停止条件：最大化利用贸易信息残片，不要过早丢弃有效线索。"""

    def __init__(self, patience: int = 3):
        """
        patience: 连续多少轮无增益后停止
        """
        self.patience = patience
        self.history: List[Dict] = []
        self.consecutive_no_gain = 0

    def check(self, round_num: int) -> Dict:
        """检查当前轮次是否应该停止。"""
        db = DB()

        # 统计当前数据库状态
        stats = self._get_current_stats(db)

        # 与上一轮比较
        if self.history:
            prev = self.history[-1]
            gain = self._calculate_gain(prev, stats)

            if gain['total'] == 0:
                self.consecutive_no_gain += 1
            else:
                self.consecutive_no_gain = 0

            should_stop = self.consecutive_no_gain >= self.patience

            result = {
                'round': round_num,
                'should_stop': should_stop,
                'consecutive_no_gain': self.consecutive_no_gain,
                'patience': self.patience,
                'current_stats': stats,
                'gain_from_last': gain,
                'history': self.history[-5:]  # 最近5轮
            }
        else:
            result = {
                'round': round_num,
                'should_stop': False,
                'consecutive_no_gain': 0,
                'patience': self.patience,
                'current_stats': stats,
                'gain_from_last': None,
                'history': []
            }

        self.history.append({
            'round': round_num,
            'stats': stats,
            'timestamp': time.time()
        })

        return result

    def _get_current_stats(self, db) -> Dict:
        """获取当前数据库关键指标。"""
        try:
            with db.c() as c:
                total_leads = c.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
                total_suppliers = c.execute("SELECT COUNT(*) FROM leads WHERE type='supplier' OR category LIKE '%supplier%'").fetchone()[0]
                total_buyers = c.execute("SELECT COUNT(*) FROM leads WHERE type='buyer' OR category LIKE '%buyer%' OR category LIKE '%import%'").fetchone()[0]
                total_edges = c.execute('SELECT COUNT(*) FROM relationships').fetchone()[0]
                total_evidence = c.execute('SELECT COUNT(*) FROM evidence_events').fetchone()[0]
                total_enrichment = c.execute('SELECT COUNT(*) FROM enrichment_events').fetchone()[0]
                total_contacts = c.execute('SELECT COUNT(*) FROM contacts').fetchone()[0]

                return {
                    'leads': total_leads,
                    'suppliers': total_suppliers,
                    'buyers': total_buyers,
                    'edges': total_edges,
                    'evidence_events': total_evidence,
                    'enrichment_events': total_enrichment,
                    'contacts': total_contacts,
                    'timestamp': time.time()
                }
        except Exception as e:
            return {'error': str(e), 'timestamp': time.time()}

    def _calculate_gain(self, prev: Dict, current: Dict) -> Dict:
        """计算两轮之间的信息增益。"""
        if 'error' in prev.get('stats', {}) or 'error' in current:
            return {'total': 0, 'details': {}}

        p = prev['stats']
        c = current

        gains = {
            'new_leads': max(0, c.get('leads', 0) - p.get('leads', 0)),
            'new_suppliers': max(0, c.get('suppliers', 0) - p.get('suppliers', 0)),
            'new_buyers': max(0, c.get('buyers', 0) - p.get('buyers', 0)),
            'new_edges': max(0, c.get('edges', 0) - p.get('edges', 0)),
            'new_evidence': max(0, c.get('evidence_events', 0) - p.get('evidence_events', 0)),
            'new_enrichment': max(0, c.get('enrichment_events', 0) - p.get('enrichment_events', 0)),
            'new_contacts': max(0, c.get('contacts', 0) - p.get('contacts', 0)),
        }

        gains['total'] = sum(gains.values())
        return gains

    def reset(self):
        """重置停止条件状态。"""
        self.history = []
        self.consecutive_no_gain = 0


# ---------- 便捷函数 ----------
def check_stop_condition(round_num: int, patience: int = 3) -> Dict:
    """全局停止条件检查（单例模式）。"""
    if not hasattr(check_stop_condition, '_instance'):
        check_stop_condition._instance = InformationGainStopCondition(patience=patience)
    return check_stop_condition._instance.check(round_num)

def reset_stop_condition():
    if hasattr(check_stop_condition, '_instance'):
        check_stop_condition._instance.reset()