"""Single-process LangGraph orchestration engine for PSV Trade OS 9.4.1."""

from __future__ import annotations

import atexit
import hashlib
import json
import logging
import sqlite3
import threading
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Mapping

from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

from core.config.settings import Settings

from .conditions import ConditionEdgeEngine
from .contracts import ContractRegistry
from .plan import ExecutionPlan, OrchestrationPlanGenerator
from .policies import Policy
from .recovery import TASK_FAILED, RecoveryManager, update_progress_state
from .experts import ExpertReviewer
from .recorder import NodeRecorder
from .registry import RegisteredWorkflow, WorkflowRegistry
from core.contracts.context import pop_providers, push_providers

from .providers import DatabaseProvider, DecisionLayerProvider
from .outlook_sender import OutlookMailSender
from .state import (
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_RUNNING,
    STATUS_TIMEOUT,
    TaskState,
)

LOGGER = logging.getLogger(__name__)

_SIGNATURE_KEYS = (
    "product_definition",
    "trade_nodes",
    "fragments",
    "evidence_pool",
    "entities",
    "relationships",
    "decisions",
)


class _EngineTimeout(Exception):
    """Internal signal raised when the hard task deadline is exceeded."""


class CheckpointAuditBridge(BaseCheckpointSaver):
    """Wrap a SqliteSaver and emit CHECKPOINT audit events for writes and reads."""

    def __init__(self, inner: BaseCheckpointSaver, event_sink: Callable[[str, dict], None]) -> None:
        super().__init__()
        self.inner = inner
        self.event_sink = event_sink

    @staticmethod
    def _thread_id(config: Mapping[str, Any] | None) -> str:
        configurable = (config or {}).get("configurable") or {}
        return str(configurable.get("thread_id") or "")

    def put(self, config, checkpoint, metadata, new_versions=None):
        result = self.inner.put(config, checkpoint, metadata, new_versions)
        payload = {"action": "write", "checkpoint_id": str(checkpoint.get("id", "")), "step": metadata.get("step")}
        self.event_sink(self._thread_id(config), payload)
        return result

    def get_tuple(self, config):
        item = self.inner.get_tuple(config)
        payload = {"action": "read", "found": item is not None}
        self.event_sink(self._thread_id(config), payload)
        return item

    def put_writes(self, config, writes, task_id, task_path=""):
        return self.inner.put_writes(config, writes, task_id, task_path)

    def list(self, config, *args, **kwargs):
        return self.inner.list(config, *args, **kwargs)

    def delete_thread(self, thread_id):
        return self.inner.delete_thread(thread_id)


class WorkflowEngine:
    """Compile and run workflow graphs in-process with audit, recovery and checkpoints.

    Design notes (Stage 1c skeleton):
    - Single process: ``compiled.invoke`` runs inside a daemon worker thread that
      the WorkflowScheduler already provides; the Flask thread never blocks.
    - Resume semantics: when the LangGraph checkpoint carries pending nodes the
      graph continues from them; after a clean boundary interruption the graph
      re-enters at START with the full persisted state merged on top. Stub nodes
      are idempotent and database rows use deterministic ids with INSERT OR
      REPLACE, so a re-run is duplication-free.
    - Hard timeout is cooperative: node wrappers and the router check a shared
      deadline, and ``run`` joins the worker thread with the effective timeout.
    """

    def __init__(
        self,
        registry: WorkflowRegistry,
        condition_engine: ConditionEdgeEngine,
        recovery_manager: RecoveryManager,
        policy: Policy,
        database: Any,
        settings: Settings,
    ) -> None:
        self.registry = registry
        self.condition_engine = condition_engine
        self.recovery_manager = recovery_manager
        self.policy = policy
        self.database = database
        self.settings = settings
        self._graphs: dict[str, Any] = {}
        self._plans: dict[str, ExecutionPlan] = {}
        self._contracts: dict[str, ContractRegistry] = {}
        self._functions: dict[str, dict[str, Callable]] = {}
        self._lock = threading.RLock()
        self._local = threading.local()
        self._saver_cm: Any = None
        self._saver: SqliteSaver | None = None
        self._bridge: CheckpointAuditBridge | None = None
        self._decision_layer: Any = None
        self._closed = False
        atexit.register(self.close)
        self._decision_layer_attempted = False
        self.contract_registry: ContractRegistry | None = None
        try:
            from .decision import DecisionLayer

            self.decision_layer = DecisionLayer()
        except Exception:
            self.decision_layer = None
            LOGGER.exception("DecisionLayer unavailable; graph continues without it")

    def _assert_state_serializable(self, state: TaskState) -> None:
        """Reject runtime objects in shared state; contextvars is the only channel."""
        forbidden_keys = ("database", "decision_layer", "reasoning_engine", "client", "saver", "bridge")
        orchestration = state.get("orchestration")
        if isinstance(orchestration, dict):
            for key in forbidden_keys:
                if key in orchestration:
                    raise ValueError(
                        f"State violation: orchestration['{key}'] must not hold runtime objects. "
                        "Use contextvars via core.contracts.context."
                    )

    # ------------------------------------------------------------------
    # Public API consumed by MissionDirector / WorkflowScheduler
    # ------------------------------------------------------------------

    def run(
        self,
        state: TaskState,
        workflow: RegisteredWorkflow,
        resume: bool = False,
        timeout_seconds: int | None = None,
    ) -> TaskState:
        """Run one workflow execution and return the final shared state."""
        workflow_id = str(getattr(workflow, "workflow_id", "") or state.get("workflow_id") or "")
        task_id = str(state.get("task_id") or "")
        if not workflow_id:
            raise ValueError("workflow_id is required to run a workflow")
        if not task_id:
            raise ValueError("task_id is required to run a workflow")
        self._assert_state_serializable(state)
        compiled = self._compiled_for(workflow_id)
        effective = timeout_seconds if timeout_seconds and timeout_seconds > 0 else self.policy.max_task_seconds
        deadline = time.monotonic() + max(1, int(effective))
        box: dict[str, Any] = {"state": dict(state), "deadline": deadline, "resume_skip": bool(resume)}
        config = {"configurable": {"thread_id": task_id, "checkpoint_ns": ""}}
        worker_errors: list[BaseException] = []

        def target() -> None:
            self._local.box = box
            token = None
            try:
                token = push_providers(DecisionLayerProvider(self._decision_layer_for_run()), DatabaseProvider(self.database),
                OutlookMailSender(),)
                result = compiled.invoke(dict(state), config)
                if isinstance(result, dict):
                    box["state"] = dict(result)
            except _EngineTimeout:
                LOGGER.warning("Task hit hard deadline: task_id=%s", task_id)
            except BaseException as exc:  # noqa: BLE001 - engine must contain node failures
                worker_errors.append(exc)
                LOGGER.exception("Workflow graph execution failed: task_id=%s", task_id)
                try:
                    self._emit(task_id, "TASK_EXECUTION_FAILED", status=STATUS_FAILED,
                               payload={"code": "ENGINE_FAILURE", "message": str(exc)})
                except Exception:
                    LOGGER.exception("Failed to record engine failure event")
            finally:
                if token is not None:
                    pop_providers(token)
                self._local.box = None

        thread = threading.Thread(target=target, name=f"psv-engine-{task_id}", daemon=True)
        thread.start()
        thread.join(max(1, int(effective)))

        final = box["state"]
        if thread.is_alive():
            final = dict(final)
            final["status"] = STATUS_TIMEOUT
            error = {
                "code": "MAX_TASK_SECONDS",
                "message": f"Task exceeded hard timeout of {int(effective)}s during graph execution",
            }
            final["error"] = error
            orchestration = dict(final.get("orchestration") or {})
            orchestration["recovery_action"] = "TIMEOUT"
            final["orchestration"] = orchestration
            self._emit(task_id, "TASK_TIMEOUT", status=STATUS_TIMEOUT, payload=error)
        elif worker_errors:
            final = dict(final)
            if final.get("status") != STATUS_TIMEOUT:
                final["status"] = STATUS_FAILED
            if not final.get("error"):
                final["error"] = {"code": "ENGINE_FAILURE", "message": str(worker_errors[0])}
        elif final.get("status") == STATUS_RUNNING:
            final = dict(final)
            final["status"] = STATUS_COMPLETED
        return final


    def close(self) -> None:
        """Release the SqliteSaver connection; safe to call repeatedly."""
        if self._closed:
            return
        self._closed = True
        try:
            if self._saver_cm is not None:
                self._saver_cm.__exit__(None, None, None)
        except Exception:
            LOGGER.exception("Failed to close the checkpoint saver cleanly")
        finally:
            self._saver_cm = None
            self._saver = None
            self._bridge = None

    def has_checkpoint(self, task_id: str) -> bool:
        """Return whether a durable LangGraph checkpoint exists for the task."""
        path = Path(self.settings.checkpoint_path_string)
        if not path.exists():
            return False
        connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(str(path), timeout=5)
            row = connection.execute(
                "SELECT 1 FROM checkpoints WHERE thread_id = ? LIMIT 1", (str(task_id),)
            ).fetchone()
            return row is not None
        except sqlite3.Error:
            LOGGER.exception("Checkpoint probe failed: task_id=%s", task_id)
            return False
        finally:
            if connection is not None:
                connection.close()

    # ------------------------------------------------------------------
    # Graph construction
    # ------------------------------------------------------------------

    def _compiled_for(self, workflow_id: str):
        with self._lock:
            compiled = self._graphs.get(workflow_id)
            if compiled is None:
                compiled = self._build_graph(workflow_id).compile(checkpointer=self._checkpointer())
                self._graphs[workflow_id] = compiled
            return compiled

    def _build_graph(self, workflow_id: str):
        workflow = self.registry.get(workflow_id)
        plan = self._plan_for(workflow_id)
        functions = self._functions_for(workflow)
        graph = StateGraph(state_schema=TaskState)
        for node_id in plan.order:
            graph.add_node(node_id, self._wrap_node(workflow_id, node_id, functions[node_id]))
        graph.add_edge(START, plan.order[0])
        mapping = {node_id: node_id for node_id in plan.order}
        mapping[END] = END
        for node_id in plan.order:
            graph.add_conditional_edges(node_id, self._make_router(workflow_id, node_id), mapping)
        return graph

    def _plan_for(self, workflow_id: str) -> ExecutionPlan:
        plan = self._plans.get(workflow_id)
        if plan is None:
            plan = OrchestrationPlanGenerator(self.registry).plan_for(workflow_id)
            self._plans[workflow_id] = plan
        return plan

    def _contracts_for(self, workflow_id: str) -> ContractRegistry:
        registry = self._contracts.get(workflow_id)
        if registry is None:
            workflow = self.registry.get(workflow_id)
            registry = ContractRegistry()
            registry.register_many(workflow.contracts)
            self._contracts[workflow_id] = registry
        self.contract_registry = registry
        self.expert_reviewer = ExpertReviewer()
        self.node_recorder = NodeRecorder()
        return registry

    def _functions_for(self, workflow: RegisteredWorkflow) -> dict[str, Callable]:
        functions = self._functions.get(workflow.workflow_id)
        if functions is None:
            functions = self.registry.node_functions(workflow)
            self._functions[workflow.workflow_id] = functions
        return functions

    def _checkpointer(self) -> CheckpointAuditBridge:
        with self._lock:
            if self._bridge is None:
                path = Path(self.settings.checkpoint_path_string)
                path.parent.mkdir(parents=True, exist_ok=True)
                self._saver_cm = SqliteSaver.from_conn_string(str(path))
                self._saver = self._saver_cm.__enter__()
                self._bridge = CheckpointAuditBridge(self._saver, self._emit_checkpoint_event)
            return self._bridge

    def _decision_layer_for_run(self) -> Any:
        return self.decision_layer

    # ------------------------------------------------------------------
    # Node wrapper: audit, contracts, recovery, progress control
    # ------------------------------------------------------------------

    def _current_box(self) -> dict:
        box = getattr(self._local, "box", None)
        if box is None:
            box = {"state": None, "deadline": None}
        return box

    def _wrap_node(self, workflow_id: str, node_id: str, func: Callable) -> Callable:
        def node(state: TaskState) -> TaskState:
            box = self._current_box()
            task_id = str(state.get("task_id") or "")
            orchestration = dict(state.get("orchestration") or {})
            reports = dict(state.get("node_reports") or {})
            existing_report = reports.get(node_id) or {}
            if box.get("resume_skip") and str(existing_report.get("status", "")) in {"ok", "committed"}:
                self._emit(task_id, "NODE_START", node_id=node_id, status=STATUS_RUNNING,
                           payload={"resumed_skip": True})
                self._emit(task_id, "NODE_COMPLETE", node_id=node_id, status=STATUS_RUNNING,
                           payload={"resumed_skip": True})
                return state
            step = int(orchestration.get("step_count") or 0) + 1
            orchestration["step_count"] = step
            state["orchestration"] = orchestration
            if box["deadline"] is not None and time.monotonic() >= box["deadline"]:
                return self._abort_for_timeout(state, task_id, box)
            if step > self.policy.max_steps:
                self._emit(task_id, "MAX_STEPS_REACHED", node_id=node_id, status=STATUS_FAILED,
                           payload={"step_count": step, "max_steps": self.policy.max_steps})
                outcome = self.recovery_manager.fail(
                    state, "MAX_STEPS_REACHED", f"step limit {self.policy.max_steps} reached at node {node_id}"
                )
                self._emit(task_id, "RECOVERY", node_id=node_id, status=STATUS_FAILED, payload=outcome)
                return state
            attempts = int(orchestration.get("attempts", {}).get(node_id) or 0)
            self._emit(task_id, "NODE_START", node_id=node_id, status=STATUS_RUNNING,
                       payload={"step": step, "attempt": attempts})
            contracts = self._contracts_for(workflow_id)
            decisions_before = len(state.get("decisions") or [])
            signature_before = self._state_signature(state)
            node._attempts = getattr(node, "_attempts", 0) + 1
            _attempt = node._attempts
            _t0 = time.perf_counter()
            self.node_recorder.begin(task_id, node_id, step, _attempt, state)
            try:
                self.contract_registry.validate_input(node_id, state)
                result = func(state)
                if not isinstance(result, dict):
                    raise TypeError(f"node {node_id} returned a non-dict result")
                state = dict(result)
                self.contract_registry.validate_output(node_id, state)
                self.expert_reviewer.review(state, task_id, node_id, workflow_id, step)
            except Exception as exc:
                self.node_recorder.end(task_id, node_id, step, _attempt, state, "failed",
                                       int((time.perf_counter() - _t0) * 1000), exc, traceback.format_exc())
                return self._handle_node_failure(state, task_id, node_id, exc, box)
            self._after_node_success(state, task_id, node_id, workflow_id, decisions_before, signature_before, step)
            self.node_recorder.end(task_id, node_id, step, _attempt, state, "ok",
                                   int((time.perf_counter() - _t0) * 1000), None, None)
            return state

        return node

    def _handle_node_failure(self, state: TaskState, task_id: str, node_id: str, exc: Exception, box: dict) -> TaskState:
        if box["deadline"] is not None and time.monotonic() >= box["deadline"]:
            return self._abort_for_timeout(state, task_id, box)
        failure_type = "timeout" if isinstance(exc, _EngineTimeout) else "node_failure"
        self._emit(task_id, "NODE_FAILURE", node_id=node_id, status=STATUS_FAILED,
                   payload={"failure_type": failure_type, "error": str(exc)})
        outcome = self.recovery_manager.prepare_retry(state, node_id, str(exc), failure_type)
        self._emit(task_id, "RECOVERY", node_id=node_id, status=str(state.get("status") or ""), payload=outcome)
        if outcome.get("action") == "RETRY":
            self._emit(task_id, "RETRY", node_id=node_id, status=STATUS_RUNNING, payload=outcome)
        return state

    def _abort_for_timeout(self, state: TaskState, task_id: str, box: dict) -> TaskState:
        state["status"] = STATUS_TIMEOUT
        error = {
            "code": "MAX_TASK_SECONDS",
            "message": f"Task exceeded hard timeout of {self.policy.max_task_seconds}s",
        }
        state["error"] = error
        orchestration = dict(state.get("orchestration") or {})
        orchestration["recovery_action"] = "TIMEOUT"
        state["orchestration"] = orchestration
        self._emit(task_id, "TASK_TIMEOUT", status=STATUS_TIMEOUT, payload=error)
        box["state"] = state
        raise _EngineTimeout(error["message"])

    def _after_node_success(
        self,
        state: TaskState,
        task_id: str,
        node_id: str,
        workflow_id: str,
        decisions_before: int,
        signature_before: str,
        step: int,
    ) -> None:
        decisions = state.get("decisions") or []
        for item in list(decisions)[decisions_before:]:
            payload = dict(item) if isinstance(item, dict) else {"decision": item}
            payload.setdefault("node_id", node_id)
            self._emit(task_id, "AI_DECISION", node_id=node_id, status=STATUS_RUNNING, payload=payload)
        signature_after = self._state_signature(state)
        orchestration = dict(state.get("orchestration") or {})
        if signature_after == signature_before:
            no_progress = int(orchestration.get("no_progress_count") or 0) + 1
            orchestration["no_progress_count"] = no_progress
            state["orchestration"] = orchestration
            if no_progress >= self.policy.no_progress_limit:
                failure = {"code": "NO_INFORMATION_GAIN",
                           "message": f"node {node_id} produced no state progress"}
                state["status"] = TASK_FAILED
                state["error"] = failure
                orchestration["recovery_action"] = "FAIL"
                state["orchestration"] = orchestration
                self._emit(task_id, "NO_INFORMATION_GAIN", node_id=node_id, status=TASK_FAILED,
                           payload={"no_progress_count": no_progress})
                self._emit(task_id, "RECOVERY", node_id=node_id, status=TASK_FAILED,
                           payload={"action": "FAIL", "error": failure})
                return
        else:
            orchestration["no_progress_count"] = 0
            orchestration["last_state_signature"] = signature_after
            state["orchestration"] = orchestration
        self._record_database_commit(state, task_id, node_id, workflow_id)
        reports = dict(state.get("node_reports") or {})
        if not (reports.get(node_id) or {}).get("status"):
            reports[node_id] = {"status": "ok", "step": step}
            state["node_reports"] = reports
        self._emit(task_id, "NODE_COMPLETE", node_id=node_id, status=STATUS_RUNNING, payload={"step": step})
        try:
            self.database.update_task(task_id, state, str(state.get("status") or STATUS_RUNNING))
        except Exception:
            LOGGER.exception("Failed to persist intermediate task state: task_id=%s", task_id)

    def _record_database_commit(self, state: TaskState, task_id: str, node_id: str, workflow_id: str) -> None:
        """Audit the single database write entrypoint after an authorised node."""
        try:
            contract = self._contracts_for(workflow_id).get(node_id)
            if contract.database_write_authority:
                report = (state.get("node_reports") or {}).get(node_id) or {}
                self._emit(task_id, "DATABASE_COMMIT", node_id=node_id, status=str(state.get("status") or ""),
                           payload={"authority": True, "report": report})
        except KeyError:
            LOGGER.warning("Contract missing for node: %s", node_id)

    # ------------------------------------------------------------------
    # Routing: Condition Edge Engine is the sole router
    # ------------------------------------------------------------------

    @staticmethod
    def _state_signature(state: dict) -> str:
        """关键集合的状态签名：同一节点连续相同即判定无进展。"""
        import hashlib, json as _json
        probe = {
            "trade_nodes": len(state.get("trade_nodes") or []),
            "evidence_pool": len(state.get("evidence_pool") or []),
            "entities": len(state.get("entities") or []),
            "relationships": len(state.get("relationships") or []),
            "node_reports": len(state.get("node_reports") or {}),
            "status": state.get("status"),
        }
        return hashlib.sha1(_json.dumps(probe, sort_keys=True).encode("utf-8")).hexdigest()

    def _make_router(self, workflow_id: str, current: str) -> Callable:
        def router(state: TaskState) -> str:
            update_progress_state(state)
            orchestration = dict(state.get("orchestration") or {})
            if orchestration.get("recovery_action") == "RETRY" and orchestration.get("resume_node") == current:
                orchestration.pop("recovery_action", None)
                orchestration.pop("resume_node", None)
                # 防死循环双闸：同节点连续重试上限(MAX_RETRIES,默认2) +
                # 状态签名无进展上限(NO_PROGRESS_LIMIT,默认3)，均从 policy 读取。
                max_retries = int(getattr(self.policy, "max_retries", 2) or 2)
                no_limit = int(getattr(self.policy, "no_progress_limit", 3) or 3)
                consecutive = 1 if orchestration.get("retry_last_node") != current else int(orchestration.get("retry_consecutive", 0) or 0) + 1
                orchestration["retry_last_node"] = current
                orchestration["retry_consecutive"] = consecutive
                signature = self._state_signature(state)
                if orchestration.get("retry_last_signature") == signature:
                    orchestration["retry_no_progress"] = int(orchestration.get("retry_no_progress", 0) or 0) + 1
                else:
                    orchestration["retry_no_progress"] = 0
                orchestration["retry_last_signature"] = signature
                state["orchestration"] = orchestration
                if consecutive > max_retries:
                    failure = {"code": "RETRY_LIMIT_EXCEEDED", "message": f"node {current} retried {consecutive - 1} times without success", "failure_type": "retry_limit"}
                    state["status"] = TASK_FAILED
                    state["error"] = failure
                    self._record_route(state, current, None, "retry_limit_exceeded", {"error": failure})
                    return END
                if int(orchestration.get("retry_no_progress", 0) or 0) >= no_limit:
                    failure = {"code": "NO_PROGRESS", "message": f"node {current} state unchanged for {no_limit} consecutive attempts", "failure_type": "no_progress"}
                    state["status"] = TASK_FAILED
                    state["error"] = failure
                    self._record_route(state, current, None, "no_progress_terminated", {"error": failure})
                    return END
                self._record_route(state, current, current, "retry_same_node", {})
                return current
            plan = self._plan_for(workflow_id)
            outcome = self.condition_engine.choose(plan, state, current)
            self._record_route(state, current, outcome.target, outcome.reason, dict(outcome.outcome or {}))
            if outcome.target is None:
                if outcome.reason == "workflow_completed":
                    state["status"] = STATUS_COMPLETED
                return END
            return outcome.target

        return router

    def _record_route(self, state: TaskState, current: str, target: str | None, reason: str, outcome: dict) -> None:
        task_id = str(state.get("task_id") or "")
        payload = {"current": current, "target": target, "reason": reason}
        payload.update(outcome)
        self._emit(task_id, "ROUTE_DECISION", node_id=current, status=str(state.get("status") or ""), payload=payload)

    # ------------------------------------------------------------------
    # Audit helpers
    # ------------------------------------------------------------------

    def _state_signature(self, state: Mapping[str, Any]) -> str:
        material = {key: state.get(key) for key in _SIGNATURE_KEYS}
        text = json.dumps(material, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def _emit(self, task_id: str, event_type: str, node_id: str | None = None,
              status: str | None = None, payload: Mapping[str, Any] | None = None) -> None:
        try:
            self.database.add_event(task_id, event_type, node_id=node_id, status=status, payload=dict(payload or {}))
        except Exception:
            LOGGER.exception("Failed to persist audit event %s for task %s", event_type, task_id)

    def _emit_checkpoint_event(self, thread_id: str, payload: Mapping[str, Any]) -> None:
        if not thread_id:
            return
        self._emit(thread_id, "CHECKPOINT", status=None, payload=dict(payload))
