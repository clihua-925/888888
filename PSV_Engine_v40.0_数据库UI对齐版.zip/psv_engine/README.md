# PSV Engine v35.0 · 统一架构版（Unified Architecture）

外贸贸易图谱智能体：从真实海关贸易数据构建 客户⇄供应商 贸易网络，分类入库，进入开发流程。

## 唯一生产链（9 节点，编排器唯一控制）

```text
MISSION_DIRECTOR（总统筹：只有决策权 action/reason/plan/questions，无 next_node）
   ↓
PRODUCT_DEFINITION 产品定义（16 维语义矩阵）
   ↓
TRADE_STRATEGY 贸易定位策略（12 要素）
   ↓
CUSTOMS_NODE_COLLECTION 海关节点采集（宽采集，UNRESOLVED 保留不删）
   ↓
TRADE_EDGE_BUILD 贸易关系建立（内存标准边，不写库）
   ↓
EVIDENCE_VERIFY 证据验证（STRONG/MEDIUM/WEAK/UNVERIFIED，降权不删除，内存分级+存量对账）
   ↓
ENTITY_RESOLUTION 企业实体解析（CUSTOMER/SUPPLIER/CUSTOMER_AND_SUPPLIER/UNKNOWN）
   ↓
GRAPH_EXPANSION 贸易网络扩张（递归双向：种子→挖矿→反向收割，动态停止）
   ↓
RESOURCE_CLASSIFICATION 资源分类（角色 × 贸易状态 × 开发状态，带理由）
   ↓
DATABASE_COMMIT 贸易资产入库（唯一写库出口：Entity + Edge + Evidence 三类资产）
```

v35 新增架构件：

- **Node Contract Registry**（`core/runtime/contracts.py`）：9 节点八要素契约（INPUT/RESPONSIBILITY/OUTPUT/
  SUCCESS/FAILURE/BLOCKING/SIDE EFFECTS/DB WRITE AUTHORITY），编排层真实执行校验——空字段不得冒充成功；
  `GET /api/contracts` 可读取注册表。
- **统一生命周期状态机**（`core/domain/lifecycle.py`）：pool→pending→dev→maint→won/discard 单轴，
  白名单迁移 + won 证据门槛 + lead_events 审计日志；UI 转池命令与 DATABASE_COMMIT 入库都走它。
- **伪实体拦截**（`trade_node.is_non_company_name`）：国家/城市/州/港口/占位文本精确拦截，
  四道防线（采集 identity_valid → 图谱登记 → 边同步 → DB upsert 最终闸），零误伤真实公司。
- **单一数据根**：`settings.DATABASE_PATH` 启动即绝对化；`run_webui.py` 打印数据根事实横幅；
  测试库一律 tempfile，不进项目数据根。

架构纪律：

- 编排器（`core/runtime/graph.py`）拥有唯一流程控制权；节点只有执行权，编排状态键由 `ORCHESTRATOR_KEYS` 统一剥离。
- `relationships` 表写库唯一出口是 `DATABASE_COMMIT`；任何执行器/采集层不得直写关系边。
- 证据分级唯一实现：`core/trade_graph/trade_node.evidence_level`（无第二套逻辑）。
- handoff 契约 v34.0：`node_id/from_node/to_node/task_id/run_id/contract_version/payload_keys/payload_checksum/node_report/status/metrics/errors/warnings/created_at`；checksum 对真实 payload（`PAYLOAD_KEYS` 快照）计算，summary 仅用于 UI/日志。
- 节点状态机唯一口径：`PENDING/RUNNING/SUCCESS/FAILED/BLOCKED/SKIPPED/CANCELLED`（`settings.NODE_STATUS`）。
- 节点「单独执行」是 DEBUG_ONLY 能力：设 `DEBUG_MODE=true` 才开放，且不回写正式任务状态。
- 数字口径（如 83/85/87）是不同阶段的资产口径，不是错误；语义固化在 `settings.COUNT_SEMANTICS`。

## 运行

```bash
pip install -r requirements.txt
python run_webui.py        # http://localhost:8000
```

数据库唯一生产源：`settings.DATABASE_PATH`（默认 `data/psv.db`，可用环境变量 `DATABASE_PATH` 覆盖）。
界面「任务仪表盘」顶部显示当前数据库路径——数量不一致时先核对该路径。

## 关于「Google 登录受限」

项目代码中**没有**任何 Google OAuth 流程。「登录受限」来自数据采集环境本身：
`start_chrome_debug.bat` 以 `--remote-debugging-port=9222` 启动的 CDP 自动化浏览器，
会被 Google 判定为「此浏览器或应用可能不安全」而拒绝登录。解决方案（任选）：

1. WebAI 默认引擎用 DeepSeek（`settings.WEBAI_ENGINE='deepseek'`），无需 Google 账号；
2. 需要用 ChatGPT 时，在该 CDP 浏览器里用「邮箱 + 密码」方式登录（不要点 Google 登录按钮）；
3. 日常采集不依赖 WebAI：第一数据源是本地海关提单库 + ImportYeti 公开海关页。

## 测试

```bash
python3 tests/test_v34_final_architecture.py   # 珐琅锅全链路 · 22 检查点
python3 tests/test_v35_unification.py          # BIRTHDAY_CANDLES 统一验收 · 7 检查点
```

`tests/` 下全部 22 个测试/冒烟文件均通过。
