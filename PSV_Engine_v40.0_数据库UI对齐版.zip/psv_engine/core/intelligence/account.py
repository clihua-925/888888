# -*- coding: utf-8 -*-
"""ACCOUNT_INTELLIGENCE_ENGINE v37：客户情报中心统一读模型。

每个客户必须能回答五件事：
  已知什么（字段+证据强度）/ 缺什么 / 下一步找什么 / 为什么 / 哪些有证据。
不新建平行 account 表——这是聚合读模型，数据仍归 leads/relationships/contacts 等单一事实源。
"""
import json
from core.memory.db import DB

WATCH_FIELDS = ['website', 'intro', 'emails', 'phones', 'contact_person', 'linkedin', 'address', 'country']
FIELD_LABELS = {'website': '官网', 'intro': '公司简介', 'emails': '邮箱', 'phones': '电话',
                'contact_person': '联系人', 'linkedin': 'LinkedIn', 'address': '地址', 'country': '国家'}


def _evidence_strength(lead, rels, events):
    ship = int(lead.get('shipments') or 0)
    strong = [r for r in rels if str(r.get('evidence_level') or '').upper() == 'STRONG']
    if ship > 0 and strong: return 'strong'
    if ship > 0 or rels: return 'medium'
    if events: return 'weak'
    return 'none'


def next_actions(lead, rels, contacts, icp):
    """规则化下一步建议（不依赖模型，可解释、可测试）。"""
    acts = []
    if not lead.get('website') or not lead.get('emails'):
        acts.append({'action': 'enrich', 'label': '运行字段级补全 waterfall',
                     'why': '缺 ' + '、'.join(FIELD_LABELS[f] for f in ('website', 'emails') if not lead.get(f))})
    if not contacts:
        acts.append({'action': 'contact', 'label': '发现联系人并生成验证邮箱',
                     'why': '没有可用联系人，开发信无人可发'})
    if len(rels) < 2:
        acts.append({'action': 'expand', 'label': '对该客户做网络扩张',
                     'why': f'贸易关系仅 {len(rels)} 条，供应链证据不足'})
    tier = str(icp.get('tier') or '')
    if tier in ('A', 'B') and lead.get('emails'):
        acts.append({'action': 'letter', 'label': '生成个性化开发信',
                     'why': f'ICP {tier} 带且已有邮箱，进入开发执行层'})
    elif tier in ('C', 'D'):
        acts.append({'action': 'watch', 'label': '暂不进开发，继续积累证据',
                     'why': f'ICP {tier} 带：' + '；'.join(icp.get('reasons') or ['证据不足'])})
    return acts


def get(norm):
    db = DB()
    lead = db.get_lead(norm)
    if not lead: return {'error': '客户不存在'}
    rels = db.list_relationships(norm=norm, limit=200)
    events = db.list_evidence_events(norm, limit=100)
    contacts = db.list_contacts(norm)
    enrichment = db.list_enrichment_events(norm, limit=50)
    msgs = db.list_messages(norm, limit=50)
    strength = _evidence_strength(lead, rels, events)
    # 逐字段来源 + 最后验证时间（来自 enrichment_events 留痕，v38）
    field_meta = {}
    for e in enrichment:
        f = e.get('field')
        if f and e.get('ok') and f not in field_meta:
            field_meta[f] = {'source': e.get('provider'), 'verified_at': e.get('ts')}
    known, missing = {}, []
    for f in WATCH_FIELDS:
        v = lead.get(f)
        if v:
            known[f] = {'label': FIELD_LABELS[f], 'value': v,
                        'source': (field_meta.get(f) or {}).get('source') or '第一采集链',
                        'verified_at': (field_meta.get(f) or {}).get('verified_at')}
        else:
            missing.append({'field': f, 'label': FIELD_LABELS[f]})
    completeness = round(len(known) / max(1, len(WATCH_FIELDS)), 2)
    # 明确区分"发现了公司"与"已补全并验证"：官网+邮箱齐备、完整度过半、邮箱经过验证
    is_enriched = bool(lead.get('website') and lead.get('emails')) and completeness >= 0.5 \
        and bool(lead.get('email_verified') or field_meta.get('emails'))
    bs_code, bs_label = DB.business_status({**lead,
        'outreach_state': 'sent' if any(m.get('direction') == 'out' and not m.get('draft') for m in msgs) else 'not_started'})
    # ICP：已评分用库里的，未评分即时算（只读不写）
    if lead.get('icp_tier'):
        icp = {'score': lead.get('icp_score'), 'tier': lead.get('icp_tier'),
               'reasons': json.loads(lead.get('icp_reasons') or '[]')}
    else:
        from core.intelligence import icp as icp_mod
        icp = icp_mod.score_lead(lead, rels, contacts)
    evidenced = {
        '海关票数': int(lead.get('shipments') or 0),
        '贸易关系': len(rels),
        '强证据边': len([r for r in rels if str(r.get('evidence_level') or '').upper() == 'STRONG']),
        '证据事件': len(events),
        '补全记录': len(enrichment),
    }
    return {'lead': lead, 'evidence_strength': strength, 'known': known, 'missing': missing,
            'completeness': completeness, 'is_enriched': is_enriched,
            'business_status': bs_code, 'business_status_label': bs_label,
            'icp': icp, 'next_actions': next_actions(lead, rels, contacts, icp),
            'evidenced': evidenced, 'contacts': contacts,
            'relationships': rels[:60], 'enrichment_events': enrichment,
            'messages': msgs[-20:], 'demand_window': lead.get('demand_window') or 'UNKNOWN',
            'opportunity_score': lead.get('opportunity_score')}
