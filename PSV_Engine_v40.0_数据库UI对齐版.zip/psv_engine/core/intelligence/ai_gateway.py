# -*- coding: utf-8 -*-
"""AI_REASONING_GATEWAY v38：所有 AI 调用的唯一入口（多模型 Fallback）。

v38 升级（任务书第四条）：
1) 多 provider 链路：local(本地DeepSeek) + webai:chatgpt(浏览器GPT) + webai:deepseek + webai:qwen(千问)。
   链路顺序由 settings.AI_PROVIDER_CHAIN 配置（默认 local,webai:chatgpt,webai:deepseek）——
   主备是运维配置，不写死"GPT 为主"。千问走用户在 CDP 浏览器已登录的通义会话，
   未登录预检诚实失败并自动切换下一家。
2) 失败切换：任一 provider 超时/异常/空返回 → 自动切下一家；全程记录 fallback_from 与每家失败原因。
3) 统一结构化解析：chat_json() 从任意模型的自然语言输出中提取 JSON，后续节点不依赖某家格式。
4) 观测：每次调用写 ai_calls 表（task/provider/model/latency/fallback_from/ok/note）。
5) 全灭诚实：所有 provider 不可用时返回 ok=False + errors 列表，绝不假装成功。
6) 对外给用户看的结论必须自然语言：conclude() 要求第一句是人话结论。
"""
import time, json
from core.config import settings
from core.memory.db import DB

CONCLUSION_FIRST = '重要：回答的第一句必须是一句自然语言结论（人话），然后再给出所需的结构化内容。'


def _local_chat(prompt, system=None, temperature=0.3, max_tokens=None, timeout=None, **kw):
    from core.model.client import ModelClient
    return ModelClient().chat(prompt, system=system, temperature=temperature,
                              max_tokens=max_tokens, timeout=timeout)


def _make_webai(engine):
    def _call(prompt, timeout=None, **kw):
        from core.tools import web_ai
        if not settings.WEBAI_ENABLED:
            return None
        return web_ai.ask(prompt, engine=engine, timeout=timeout or settings.WEBAI_TIMEOUT)
    return _call


PROVIDERS = {
    'local': ('本地DeepSeek ' + getattr(settings, 'LLM_MODEL', ''), _local_chat),
    'webai:chatgpt': ('浏览器GPT', _make_webai('chatgpt')),
    'webai:deepseek': ('浏览器DeepSeek', _make_webai('deepseek')),
    'webai:qwen': ('浏览器千问', _make_webai('qwen')),
}


def route_order():
    """链路顺序：AI_PROVIDER_CHAIN（逗号分隔）优先；兼容旧 AI_PRIMARY 单值配置。"""
    chain = str(getattr(settings, 'AI_PROVIDER_CHAIN', '') or '').strip()
    if chain:
        order = [p.strip() for p in chain.split(',') if p.strip() in PROVIDERS]
        if order: return order
    primary = str(getattr(settings, 'AI_PRIMARY', 'local') or 'local').lower()
    if primary not in PROVIDERS: primary = 'local'
    rest = [p for p in ('webai:chatgpt', 'webai:deepseek', 'webai:qwen') if p != primary]
    return [primary] + rest


def chat(prompt, task='general', system=None, temperature=0.3, max_tokens=None,
         timeout=None, require_conclusion=False):
    """统一入口：按链路顺序调用，失败自动切换，全量观测，全灭诚实报错。
    返回 {'text','provider','fallback_from','ok','errors'}。"""
    if require_conclusion and CONCLUSION_FIRST not in prompt:
        prompt = prompt + '\n\n' + CONCLUSION_FIRST
    db = DB(); fallback_from = ''; errors = []
    for i, name in enumerate(route_order()):
        label, fn = PROVIDERS[name]
        t = time.time(); text = None; err = ''
        try:
            text = fn(prompt, system=system, temperature=temperature, max_tokens=max_tokens, timeout=timeout)
        except Exception as e:
            err = str(e)[:160]
        lat = round(time.time() - t, 2)
        ok = bool(text and str(text).strip())
        if not ok and not err:
            err = '空返回/未登录/不可用'
        db.log_ai_call(task, name, label, lat, ok, fallback_from=fallback_from, note=err)
        if ok:
            return {'text': str(text).strip(), 'provider': name, 'fallback_from': fallback_from, 'ok': True, 'errors': errors}
        errors.append({'provider': name, 'reason': err})
        fallback_from = name if i == 0 else fallback_from + '>' + name
    return {'text': '', 'provider': '', 'fallback_from': fallback_from, 'ok': False, 'errors': errors}


def chat_json(prompt, task='general', **kw):
    """统一结构化解析：任意模型的输出 → JSON 对象。解析失败按调用失败处理（触发切换语义由调用方决定）。"""
    r = chat(prompt, task=task, **kw)
    if not r['ok']:
        return {'ok': False, 'json': None, 'errors': r.get('errors') or [], 'provider': ''}
    txt = r['text']
    j = None
    try:
        j = json.loads(txt[txt.find('{'):txt.rfind('}') + 1])
    except Exception:
        try:
            j = json.loads(txt[txt.find('['):txt.rfind(']') + 1])
        except Exception:
            j = None
    return {'ok': j is not None, 'json': j, 'provider': r['provider'],
            'fallback_from': r['fallback_from'], 'errors': r.get('errors') or [],
            'raw': txt if j is None else ''}


def conclude(prompt, task='general', **kw):
    """自然语言结论优先的问答：用于诊断、审计说明、情报摘要。给用户看的一律人话。"""
    kw['require_conclusion'] = True
    return chat(prompt, task=task, **kw)
