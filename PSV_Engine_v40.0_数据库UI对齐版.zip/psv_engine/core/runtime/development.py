# -*- coding: utf-8 -*-
"""第二流程：客户开发执行序列 v37（后半程重构）。

后半程定义：发现(第一链·冻结) → 情报 → 补全 → 联系人 → 资格 → 开发执行。
节点流：DEV_VERIFY → ACCOUNT_INTEL → ENRICH → CONTACT → ICP → DEV_OFFER → DEV_LETTER → DEV_REVIEW → DEV_SEND

设计原则：
1) 编排器唯一：本模块只有线性执行器（重试+断点恢复+状态留痕），
   不再私藏 _director/_diagnose/_handoff 小编排（v37 已删除，诊断/决策归 experts 工具层）。
2) 半自动开发信：DEV_REVIEW 是人工门（草稿置 review_pending）；DEV_SEND 绝不自动 SMTP 发送，
   只生成发送包（收件人+compose URL），真发送由人在 UI 打开邮箱完成并标记。
3) 所有需求判断必须有证据；证据不足明确 UNKNOWN，不把模型猜测当成客户需求。
4) 复用第一链已采集数据，只补缺失/新鲜数据（ENRICH 走字段级 waterfall）。
"""
import json, time, re, datetime as dt
from core.config import settings
from core.memory.db import DB
from core.tools import auditor, pitch
from core.runtime import experts

DEV_ORDER=['DEV_VERIFY','ACCOUNT_INTEL','ENRICH','CONTACT','ICP','DEV_OFFER','DEV_LETTER','DEV_REVIEW','DEV_SEND']
DEV_LABELS={
 'DEV_VERIFY':'客户真实性验证','ACCOUNT_INTEL':'客户情报整理','ENRICH':'字段级补全','CONTACT':'联系人发现',
 'ICP':'客户资格评分','DEV_OFFER':'Offer策略','DEV_LETTER':'个性化开发信','DEV_REVIEW':'人工审核门','DEV_SEND':'发送准备'
}


def _review(name, text, checks=None):
    try:
        return experts.review(name,text,checks or [])
    except Exception as e:
        return {'verdict':'warn','error':str(e)[:160]}


def _save(lead_norm, data):
    DB().save_development_blackboard(lead_norm, data)


def _base(state):
    db=DB(); lead=db.get_lead(state['lead_norm']) or {}
    rel=db.list_relationships(norm=state['lead_norm'],limit=200)
    ev=db.list_evidence_events(state['lead_norm'],limit=300)
    return db,lead,rel,ev


def _date_days(value):
    if not value:return None
    s=str(value).strip()
    candidates=[s,s[:10],s[:7],s[:4]]
    formats=['%Y-%m-%d','%Y/%m/%d','%m/%d/%Y','%Y-%m','%Y']
    for c in candidates:
        for fmt in formats:
            try:return (dt.date.today()-dt.datetime.strptime(c,fmt).date()).days
            except Exception:pass
    return None


def _trade_history(db, lead):
    """优先读取已导入的 buyers_90d / customs_raw；没有则使用 lead 上已有汇总字段。"""
    norm=str(lead.get('norm') or '')
    name=str(lead.get('name') or '')
    out={'shipments':int(lead.get('shipments') or 0),'first_seen':None,'last_seen':lead.get('last_shipment'),
         'supplier_count':0,'total_weight':0,'total_qty':0,'total_teu':0,'origins':[],'ports':[],'source':'lead_summary'}
    try:
        with db.c() as c:
            c.row_factory=__import__('sqlite3').Row
            r=c.execute('SELECT * FROM buyers_90d WHERE importer_norm=?',(norm,)).fetchone()
            if not r:
                r=c.execute('SELECT * FROM buyers_90d WHERE lower(importer)=lower(?)',(name,)).fetchone()
            if r:
                d=dict(r); out.update({'shipments':max(out['shipments'],int(d.get('shipments') or 0)),
                    'first_seen':d.get('first_seen'),'last_seen':d.get('last_seen') or out['last_seen'],
                    'supplier_count':int(d.get('supplier_count') or 0),'total_weight':float(d.get('total_weight') or 0),
                    'total_qty':float(d.get('total_qty') or 0),'total_teu':float(d.get('total_teu') or 0),
                    'origins':str(d.get('origins') or '').split(',')[:20],'ports':str(d.get('ports') or '').split(',')[:20],
                    'source':'buyers_90d'})
            rows=c.execute('SELECT ts,shipper,hs,descr,qty,weight,teu,origin,port_load,port_discharge FROM customs_raw WHERE importer_norm=? ORDER BY ts ASC LIMIT 5000',(norm,)).fetchall()
            if rows:
                out['source']='customs_raw'
                out['raw_count']=len(rows)
                dates=[]; suppliers=set(); desc=set(); total_qty=0; total_weight=0; total_teu=0
                for r in rows:
                    if r['ts']:
                        try: dates.append(dt.datetime.fromtimestamp(float(r['ts'])).date())
                        except Exception: pass
                    if r['shipper']: suppliers.add(str(r['shipper']).strip())
                    if r['descr']: desc.add(str(r['descr']).strip()[:120])
                    total_qty+=float(r['qty'] or 0); total_weight+=float(r['weight'] or 0); total_teu+=float(r['teu'] or 0)
                if dates:
                    out['first_seen']=str(min(dates)); out['last_seen']=str(max(dates))
                    out['shipment_dates']=[str(x) for x in dates[-60:]]
                out['supplier_count']=max(out['supplier_count'],len(suppliers)); out['supplier_names']=list(suppliers)[:40]
                out['sample_descriptions']=list(desc)[:30]
                out['total_qty']=max(out['total_qty'],total_qty); out['total_weight']=max(out['total_weight'],total_weight); out['total_teu']=max(out['total_teu'],total_teu)
    except Exception as e:
        out['warning']='trade history read failed: '+str(e)[:160]
    return out


def n_verify(state):
    db,lead,_,_= _base(state)
    if not lead:return {'_success':False,'_note':'客户不存在'}
    updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=None)
    if not updated:return {'_success':False,'_note':'客户资料验证失败'}
    hard = int(updated.get('shipments') or 0)>0 or bool(updated.get('audit'))
    verified = str(rep.get('verdict','')).lower()=='pass' and (hard or updated.get('website') or updated.get('emails'))
    status='dev_ready' if verified else 'pending'
    db.lead_update(state['lead_norm'],status=status,audit=json.dumps(rep,ensure_ascii=False))
    data={'verified':bool(verified),'audit':rep,'status':status,'updated':updated}
    _save(state['lead_norm'],{'verification':data})
    return {'lead':updated,'verification':data,'_success':bool(verified),'_note':'客户验证通过' if verified else '客户未通过开发前验证'}


def n_account_intel(state):
    """ACCOUNT_INTEL：情报整理（含原 DEV_INTELLIGENCE 的情报聚合 + 原 DEV_PROFILE 的画像落库）。"""
    db,lead,rel,ev=_base(state)
    if not lead:return {'_success':False,'_note':'缺少客户'}
    trade=_trade_history(db,lead)
    profile={k:lead.get(k) for k in ['name','country','website','emails','phones','address','contact_person','category','segment','shipments','last_shipment','desc_sample','source','score','grade']}
    suppliers=[]
    for r in rel:
        if str(r.get('from_type'))=='supplier' or str(r.get('to_type'))=='supplier':
            suppliers.append({'name':r.get('from_name') if r.get('from_type')=='supplier' else r.get('to_name'),
                              'relation':r.get('relation'),'confidence':r.get('confidence'),'source':r.get('source'),'evidence':r.get('evidence')})
    intel={'profile':profile,'supplier_relationships':suppliers[:50],'trade_history':trade,'evidence_events':ev[:120],
           'freshness':{'last_seen':lead.get('last_seen'),'last_shipment':trade.get('last_seen')},'unknowns':[]}
    for k,v in profile.items():
        if not v:intel['unknowns'].append(k)
    rep=_review('ACCOUNT_INTEL',json.dumps(intel,ensure_ascii=False)[:11000],
                [('实体存在',bool(profile.get('name')),str(profile.get('name') or '')),
                 ('贸易背景',bool(trade.get('shipments') or suppliers),f"shipments={trade.get('shipments')},suppliers={len(suppliers)}"),
                 ('证据可追溯',bool(ev or trade.get('shipments')),f"events={len(ev)}")])
    if rep.get('verdict')=='fail':
        return {'_success':False,'_note':'客户情报验收未通过：'+str(rep.get('notes') or '')[:180]}
    _save(state['lead_norm'],{'intelligence':intel})
    return {'intelligence':intel,'_success':True,'_note':f'客户情报整理完成，供应商关系{len(suppliers)}条，贸易记录{trade.get("shipments",0)}票，缺口{len(intel["unknowns"])}项'}


def n_enrich(state):
    """ENRICH：字段级 waterfall 补全（website/emails/phones/contact_person/address 逐字段、成功即停、最后验证）。"""
    from core.intelligence import waterfall
    r=waterfall.enrich_lead(state['lead_norm'])
    if not r.get('ok'):return {'_success':False,'_note':'补全失败：'+str(r.get('error') or '')[:160]}
    _save(state['lead_norm'],{'enrichment':r})
    # 补全是增益节点：有缺口但没补上不算失败（证据不足≠节点失败），全部耗尽也是正常终态
    return {'enrichment':r,'_success':True,
            '_note':f"补全完成：新填{len(r.get('filled') or {})}字段，仍缺{'、'.join(r.get('still_missing') or []) or '无'}"}


def n_contact(state):
    """CONTACT：联系人发现 + 邮箱排列生成 + MX 验证（推荐第一名，绝不群发）。"""
    from core.intelligence import contacts as contacts_mod
    r=contacts_mod.find_contacts(state['lead_norm'])
    if not r.get('ok'):return {'_success':False,'_note':'联系人发现失败：'+str(r.get('error') or '')[:160]}
    _save(state['lead_norm'],{'contacts':r})
    n=len(r.get('contacts') or [])
    rec=(r.get('recommended') or {}).get('email') or ''
    return {'contacts':r,'_success':True,'_note':f'联系人：{r.get("contact_person") or "未发现"} · 候选邮箱{n}个' + (f' · 推荐 {rec}' if rec else '')}


def n_icp(state):
    """ICP：需求机会（窗口）+ 客户资格评分（Fit×Intent×Timing，分数带A/B/C/D，可解释），并落画像。"""
    db,lead,rel,ev=_base(state)
    if not lead:return {'_success':False,'_note':'缺少客户'}
    intel=state.get('intelligence') or {}; trade=intel.get('trade_history') or _trade_history(db,lead)
    shipments=int(trade.get('shipments') or 0); score=0.0; reasons=[]; evidence=[]
    if shipments>0: score+=25; reasons.append(f'存在{shipments}票历史贸易记录'); evidence.append('trade_history')
    last=trade.get('last_seen') or lead.get('last_shipment'); days=_date_days(last)
    if days is not None:
        if days<=45: score+=25; reasons.append('最近45天内有提货记录'); evidence.append('recent_trade')
        elif days<=120: score+=20; reasons.append('最近120天内有提货记录'); evidence.append('recent_trade')
        elif days<=240: score+=10; reasons.append('最近240天内有提货记录'); evidence.append('trade_recency')
    suppliers=max(len(rel),int(trade.get('supplier_count') or 0))
    if suppliers>=2: score+=20; reasons.append(f'存在{suppliers}个供应商/供应链关系，可观察供应商变化'); evidence.append('supplier_cross_check')
    if trade.get('supplier_count',0)>=3: score+=5; reasons.append('供应商来源较多，存在供应链比较空间'); evidence.append('supplier_diversity')
    changes=[e for e in ev if str(e.get('kind','')).lower() in {'website_change','product_change','business_change','supplier_change','new_collection'}]
    if changes: score+=20; reasons.append(f'发现{len(changes)}条业务/供应链变化证据'); evidence.append('business_change')
    dates=[]
    for s in trade.get('shipment_dates') or []:
        try: dates.append(dt.datetime.strptime(s,'%Y-%m-%d').date())
        except Exception: pass
    if len(dates)>=3:
        gaps=sorted((dates[i]-dates[i-1]).days for i in range(1,len(dates)) if (dates[i]-dates[i-1]).days>0)
        if gaps:
            med=gaps[len(gaps)//2]; days_since=(dt.date.today()-dates[-1]).days
            if 0<=days_since<=max(15,med*1.25): score+=10; reasons.append(f'当前距离上次提货约{days_since}天，接近历史约{med}天采购间隔'); evidence.append('cycle_window')
    score=min(100,round(score,1))
    if score>=75: window='NOW'
    elif score>=50: window='SOON'
    elif score>=25: window='WATCH'
    elif shipments: window='DORMANT'
    else: window='UNKNOWN'
    confidence=min(0.95,round(0.30+0.08*len(evidence),2))
    opportunity={'score':score,'window':window,'confidence':confidence,'reasons':reasons,'evidence_types':evidence,
                 'historical_context':{'last_shipment':last,'days_since_last':days,'supplier_count':suppliers,'shipment_count':shipments},
                 'caveat':'机会评分是基于公开/已有交易证据的概率判断，不代表客户已经提出采购需求。证据不足时保持UNKNOWN。'}
    db.lead_update(state['lead_norm'],opportunity_score=score,demand_window=window,demand_confidence=confidence,opportunity=json.dumps(opportunity,ensure_ascii=False))
    # ICP 资格评分（写回 icp_score/icp_tier/icp_reasons）
    from core.intelligence import icp as icp_mod
    lead=db.get_lead(state['lead_norm']) or lead
    icp_r=icp_mod.score_lead(lead,rel,db.list_contacts(state['lead_norm']))
    db.lead_update(state['lead_norm'],icp_score=icp_r['score'],icp_tier=icp_r['tier'],
                   icp_reasons=json.dumps(icp_r['reasons']+['⚠ '+n for n in icp_r['negatives']],ensure_ascii=False))
    # 画像落库（原 DEV_PROFILE 合并于此）
    profile=dict(intel.get('profile') or {})
    profile.update({'demand_window':window,'opportunity_score':score,'demand_confidence':confidence,
                    'icp_score':icp_r['score'],'icp_tier':icp_r['tier'],
                    'supplier_relationships':intel.get('supplier_relationships') or [],'trade_history':intel.get('trade_history') or {},
                    'evidence_count':len(ev),'unknowns':intel.get('unknowns') or []})
    db.lead_update(state['lead_norm'],profile=json.dumps(profile,ensure_ascii=False))
    _save(state['lead_norm'],{'opportunity':opportunity,'icp':icp_r,'profile':profile})
    return {'opportunity':opportunity,'icp':icp_r,'profile':profile,'_success':True,
            '_note':f'需求窗口{window} · ICP {icp_r["tier"]}带{icp_r["score"]}分（可联系性{icp_r["contactability"]}）'}


def n_offer(state):
    _,lead,_,_= _base(state); opp=state.get('opportunity') or {}
    window=opp.get('window','UNKNOWN'); score=float(opp.get('score') or 0); segment=str(lead.get('segment') or lead.get('category') or '')
    offers=[]
    if window in {'NOW','SOON'}: offers.append('Lead with free samples and a fast quotation to test supplier fit with low risk.')
    if any(x in segment.lower() for x in ('birthday','candle','蜡烛')): offers.append('Offer relevant spiral, number and party birthday candles based on the buyer\'s product direction.')
    if lead.get('shipments'): offers.append('Factory-direct supply from Ningjin, flexible capacity and competitive cluster pricing.')
    offers.append('OEM/ODM support and low-barrier trial orders for standard products.')
    if score<50: offers=offers[-1:]
    strategy={'priority':'high' if score>=75 else ('medium' if score>=50 else 'low'),'offers':offers[:3],
              'cta':'Reply for catalog, quotation or a free sample','reason':opp.get('reasons') or ['Demand evidence is limited; use a low-risk exploratory offer'],
              'do_not_claim':['Do not say the buyer is currently buying unless an explicit source proves it.']}
    _save(state['lead_norm'],{'offer_strategy':strategy})
    return {'offer_strategy':strategy,'_success':True,'_note':'Offer策略已生成'}


def n_letter(state):
    db,lead,_,_= _base(state); offer=state.get('offer_strategy') or {}; opp=state.get('opportunity') or {}
    # v38 个性化：联系人/推荐邮箱/简介进入写信素材（开发信不得与客户信息脱节）
    contacts=db.list_contacts(state['lead_norm'])
    rec=next((c for c in contacts if c.get('email') and c.get('email_status') in ('mx_ok','pattern','syntax_ok')),None)
    contact_info='Contact person: '+str(lead.get('contact_person') or 'unknown')+'; recommended email: '+str((rec or {}).get('email') or 'none')
    ammo=contact_info+'\nOpportunity evidence: '+json.dumps(opp,ensure_ascii=False)[:2200]+'\nRecommended offer: '+json.dumps(offer,ensure_ascii=False)[:2200]
    from core.intelligence import ai_gateway
    r=ai_gateway.chat(pitch.letter_prompt(lead,ammo=ammo,industry_key=state.get('industry')),
                      task='letter',temperature=0.55,max_tokens=1200,timeout=300)
    if not r['ok']:
        return {'_success':False,'_note':'开发信模型调用失败（主备均不可用）'}
    txt=r['text']
    lines=txt.strip().splitlines(); subject_line=lines[0] if lines and lines[0].lower().startswith('subject:') else 'Subject: A quick sample idea for your team'
    body='\n'.join(lines[1:] if lines and lines[0].lower().startswith('subject:') else lines).strip()
    words=re.findall(r"\b[\w'-]+\b",body)
    if len(words)>120:
        body=' '.join(words[:120])
    txt=subject_line+'\n\n'+body
    db.add_message(state['lead_norm'],'out','email',txt,draft=1)
    msg=db.latest_out_message(state['lead_norm'])
    if msg: db.set_message_status(msg['id'],'drafted')
    _save(state['lead_norm'],{'letter':txt})
    return {'letter':txt,'_success':True,'_note':f'已生成个性化开发信草稿（正文约{len(words[:120])}词，via {r["provider"]}）'}


def n_review_gate(state):
    """DEV_REVIEW：AI 质检门（v39 用户明确要求免人工审核——不再停留等待人工）。
    只做机器质检：草稿存在、有主题、正文达标、无占位符；通过即 approved 进入发送执行。
    质检不过 → 失败留痕（不伪造通过），由 LETTER 重新生成。"""
    db=DB()
    msg=db.latest_out_message(state['lead_norm'])
    if not msg or not msg.get('draft'):
        return {'_success':False,'_note':'没有待审核的开发信草稿'}
    if msg.get('status') in ('approved','ready_to_send','opened','sent'):
        return {'review':{'status':msg.get('status'),'message_id':msg['id']},'_success':True,'_note':'草稿已通过质检'}
    content=str(msg.get('content') or '')
    problems=[]
    lines=content.splitlines()
    if not (lines and lines[0].lower().startswith('subject:') and lines[0].split(':',1)[1].strip()):
        problems.append('缺少有效主题行')
    body='\n'.join(lines[1:] if lines and lines[0].lower().startswith('subject:') else lines)
    words=re.findall(r"\b[\w'-]+\b",body)
    if len(words)<20: problems.append('正文过短（不足20词）')
    for ph in ('[Your Company Name]','[Your Name]','{{','}}','TODO','占位'):
        if ph in content: problems.append('含占位符 '+ph); break
    if problems:
        db.set_message_status(msg['id'],'drafted',reason='AI质检未过：'+'；'.join(problems))
        return {'_success':False,'_note':'开发信质检未通过：'+'；'.join(problems)}
    db.set_message_status(msg['id'],'approved')
    return {'review':{'status':'approved','message_id':msg['id'],'words':len(words)},'_success':True,
            '_note':'AI质检通过（免人工审核），进入发送执行'}


def n_send(state):
    """DEV_SEND：半自动发送准备——绝不自动 SMTP 发送。
    只负责：选定收件人（推荐联系人邮箱优先）+ 生成 compose URL + 置 ready_to_send。
    真发送 = 人在 UI 点"打开邮箱"（mailto 真跳转）→ 发完后点"标记已发送"。"""
    db,lead,_,_= _base(state)
    if not settings.DEVELOPMENT_SEQUENCE_ENABLED or db.get_setting('development_sequence_enabled','true').lower()!='true':
        return {'send':{'status':'sequence_paused'},'_success':True,'_note':'开发信序列已暂停，停止发送但保留前序结果'}
    sent=next((m for m in reversed(db.list_messages(state['lead_norm'])) if m.get('direction')=='out' and not m.get('draft')),None)
    if sent:return {'send':{'status':'already_sent','message_id':sent.get('id')},'_success':True,'_note':'该客户已有已发送邮件，本次跳过，防止重复发送'}
    msg=db.latest_out_message(state['lead_norm'])
    if not msg or not msg.get('draft'):return {'_success':False,'_note':'没有可发送草稿'}
    if msg.get('status') not in ('approved','review_pending','ready_to_send','drafted'):
        db.set_message_status(msg['id'],'review_pending')
    # 收件人：推荐联系人邮箱 > lead 邮箱（第一个含@）
    to=''
    contacts=db.list_contacts(state['lead_norm'])
    rec=next((c for c in contacts if c.get('email') and c.get('email_status') in ('mx_ok','pattern','syntax_ok')),None)
    if rec: to=rec['email']
    if not to:
        emails=re.split(r'[,;\s]+',str(lead.get('emails') or ''))
        to=next((e for e in emails if '@' in e), '')
    if not to:
        return {'send':{'status':'no_recipient'},'_success':True,
                '_note':'客户没有可发送邮箱——停在发送准备，建议先补全或扩张（证据不足≠节点失败）'}
    content=msg.get('content',''); subject='PSV introduction'; body=content
    lines=content.splitlines()
    if lines and lines[0].lower().startswith('subject:'):
        subject=lines[0].split(':',1)[1].strip() or subject; body='\n'.join(lines[1:]).strip()
    from core.tools import mailer
    url=mailer.compose_url(to,subject,body)
    db.set_message_status(msg['id'],'ready_to_send')
    # v39：用户明确要求免人工审核——默认尝试自动执行（打开微软邮箱→填充→点击发送）。
    # OUTLOOK_AUTO_SEND=false 可显式关停自动执行回到半自动；浏览器不可用/未登录 → 明确原因，绝不假装成功。
    if getattr(settings,'OUTLOOK_AUTO_SEND',True):
        from core.tools import outlook_send
        r=outlook_send.auto_send(state['lead_norm'])
        send={'status':r.get('status'),'to':to,'subject':subject,'message_id':msg['id'],'auto_send':r}
        _save(state['lead_norm'],{'send':send})
        if r.get('ok'):
            return {'send':send,'_success':True,'_note':f'已自动打开微软邮箱并完成发送：{to}'}
        send['compose_url']=url
        return {'send':send,'_success':True,'_note':'自动发送未完成（'+str(r.get('status') or 'ready_to_send')+'）：'+str(r.get('error') or '')[:180]}
    send={'status':'ready_to_send','to':to,'subject':subject,'compose_url':url,'message_id':msg['id']}
    _save(state['lead_norm'],{'send':send})
    return {'send':send,'_success':True,'_note':f'发送包已就绪：{to} —— 请在工作台打开邮箱人工发送并标记'}

FN={'DEV_VERIFY':n_verify,'ACCOUNT_INTEL':n_account_intel,'ENRICH':n_enrich,'CONTACT':n_contact,'ICP':n_icp,
    'DEV_OFFER':n_offer,'DEV_LETTER':n_letter,'DEV_REVIEW':n_review_gate,'DEV_SEND':n_send}


def run_sequence(lead_norm,persist=None,start_node=None,task_id=None):
    """线性执行器：重试 NODE_RETRIES 次 + 断点恢复 + 状态留痕。
    v37 删除小编排：失败只记录（dev_retry_history），不再 _director/_diagnose 私自改道——
    节点失败达到上限即停止并保留现场，由人/总统筹决定是否 resume。"""
    db=DB(); lead=db.get_lead(lead_norm)
    if not lead:return {'ok':False,'error':'lead not found','lead_norm':lead_norm}
    previous=db.latest_development(lead_norm)
    state=(previous.get('result') or {}) if previous else {}
    if not isinstance(state,dict):state={}
    state.update({'lead_norm':lead_norm,'task_id':task_id or state.get('task_id'),'lead':lead})
    # v39 品类隔离：开发信素材按客户所属产品域取品类配置，不混用其他品类事实
    state['industry']=str(lead.get('product_domain') or state.get('industry') or getattr(settings,'INDUSTRY','candle'))
    state.setdefault('dev_nodes',[]);state.setdefault('dev_status',{});state.setdefault('dev_handoffs',{});state.setdefault('dev_retry_history',[])
    start_idx=DEV_ORDER.index(start_node) if start_node in DEV_ORDER else 0
    if not start_node:
        start_idx=next((i for i,n in enumerate(DEV_ORDER) if state.get('dev_status',{}).get(n,{}).get('status') not in ('SUCCESS','SKIPPED')),0)
    for i in range(start_idx,len(DEV_ORDER)):
        name=DEV_ORDER[i]
        if name=='DEV_SEND' and state.get('dev_status',{}).get('DEV_SEND',{}).get('status')=='SUCCESS':continue
        state['current_dev_node']=name
        attempt=0; ok=False; note=''
        while attempt<max(1,settings.NODE_RETRIES):
            attempt+=1; state['dev_status'][name]={'status':'RUNNING','attempt':attempt,'updated_at':time.time()}
            if persist:persist(state)
            t=time.time()
            try:out=FN[name](state) or {}; ok=bool(out.pop('_success',True)); note=str(out.pop('_note','')); state.update(out)
            except Exception as e:ok=False; note=str(e)[:400]; out={}
            status='SUCCESS' if ok else 'FAILED'
            state['dev_status'][name]={'status':status,'attempt':attempt,'note':note,'updated_at':time.time(),'duration':round(time.time()-t,2)}
            state['dev_nodes'].append({'node':name,'status':status,'note':note,'attempt':attempt,'ts':time.time()})
            state['dev_handoffs'][name]={'from':name,'to':DEV_ORDER[i+1] if i+1<len(DEV_ORDER) else 'END',
                                         'accepted':bool(ok),'summary':note[:300],'ts':time.time()}
            if persist:persist(state)
            if ok:break
            state['dev_retry_history'].append({'node':name,'attempt':attempt,'error':note,'ts':time.time()})
        if not ok:
            state['error']=note or 'node failed'; state['ok']=False; state['current_dev_node']='END'
            if persist:persist(state)
            return state
    state['ok']=True; state['current_dev_node']='END'
    if persist:persist(state)
    return state
