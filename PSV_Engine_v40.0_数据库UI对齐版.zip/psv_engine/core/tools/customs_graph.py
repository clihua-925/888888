# -*- coding: utf-8 -*-
"""海关关系图谱核心。

所有“客户 -> 供应商 -> 客户”的关系优先从 customs_raw 中提取。
外部海关网站只作为同一类“贸易证据源”补充，不会把普通网页结果当成贸易关系。
"""
import re, sqlite3, time
from core.config import settings


def norm(name: str) -> str:
    s = str(name or '').lower().strip()
    s = re.sub(r'\b(the|inc|llc|co|ltd|corp|corporation|company|gmbh|sarl|limited|group|factory|trading|trade|international|intl)\b', ' ', s)
    return re.sub(r'[^a-z0-9]+', '', s)


def _db():
    return sqlite3.connect(settings.DATABASE_PATH, timeout=15)


def _rows_for_importer(names):
    norms = {norm(x) for x in names if norm(x)}
    if not norms:
        return []
    placeholders = ','.join('?' for _ in norms)
    with _db() as c:
        c.row_factory = sqlite3.Row
        rows = c.execute(
            f"SELECT id,bol,ts,importer,importer_norm,shipper,hs,descr,qty,weight,origin,port_load,port_discharge,source_file "
            f"FROM customs_raw WHERE importer_norm IN ({placeholders}) ORDER BY ts DESC", tuple(norms)
        ).fetchall()
    return [dict(r) for r in rows]


def _matching_shipper_names(target_norms):
    target_norms = {norm(x) for x in target_norms if norm(x)}
    if not target_norms:
        return []
    with _db() as c:
        vals = [r[0] for r in c.execute("SELECT DISTINCT shipper FROM customs_raw WHERE shipper IS NOT NULL AND TRIM(shipper)!=''").fetchall()]
    return [v for v in vals if norm(v) in target_norms]


def _rows_for_shippers(names):
    names = [x for x in names if x]
    if not names:
        return []
    placeholders = ','.join('?' for _ in names)
    with _db() as c:
        c.row_factory = sqlite3.Row
        rows = c.execute(
            f"SELECT id,bol,ts,importer,importer_norm,shipper,hs,descr,qty,weight,origin,port_load,port_discharge,source_file "
            f"FROM customs_raw WHERE shipper IN ({placeholders}) ORDER BY ts DESC", tuple(names)
        ).fetchall()
    return [dict(r) for r in rows]


def _group(rows, key):
    groups = {}
    for r in rows:
        nm = (r.get(key) or '').strip()
        n = norm(nm)
        if not n:
            continue
        g = groups.setdefault(n, {
            'name': nm, 'norm': n, 'trade_records': 0, 'shipments': 0,
            'last_shipment': '', 'hs': [], 'products': [], 'raw_ids': [],
            'source_files': [], 'customs': True
        })
        g['trade_records'] += 1
        g['shipments'] += 1
        ts = r.get('ts') or 0
        if not g['last_shipment'] or ts > _ts(g['last_shipment']):
            g['last_shipment'] = ts
        if r.get('hs') and r['hs'] not in g['hs']:
            g['hs'].append(str(r['hs']))
        if r.get('descr') and r['descr'] not in g['products']:
            g['products'].append(str(r['descr']))
        if r.get('id') is not None and len(g['raw_ids']) < 8:
            g['raw_ids'].append(r['id'])
        if r.get('source_file') and r['source_file'] not in g['source_files']:
            g['source_files'].append(r['source_file'])
    for g in groups.values():
        g['hs'] = g['hs'][:8]
        g['products'] = g['products'][:8]
        g['source_files'] = g['source_files'][:5]
    return list(groups.values())


def _ts(v):
    try: return float(v or 0)
    except Exception: return 0.0


def buyer_to_suppliers(buyers, limit_per=None):
    """从本地海关原始记录提取 importer -> shipper。"""
    limit_per = int(limit_per or settings.IY_WEB_MAX_SUPPLIERS)
    rows = _rows_for_importer([b.get('name') if isinstance(b, dict) else b for b in buyers])
    grouped = _group(rows, 'shipper')
    by_buyer = {}
    for r in rows:
        bn = norm(r.get('importer'))
        sn = norm(r.get('shipper'))
        if not bn or not sn: continue
        by_buyer.setdefault(bn, {}).setdefault(sn, {'name': r.get('shipper'), 'records': 0, 'shipments': 0, 'last_shipment': r.get('ts') or 0, 'hs': set(), 'products': set(), 'raw_ids': []})
        g = by_buyer[bn][sn]
        g['records'] += 1; g['shipments'] += 1
        g['last_shipment'] = max(_ts(g['last_shipment']), _ts(r.get('ts')))
        if r.get('hs'): g['hs'].add(str(r['hs']))
        if r.get('descr'): g['products'].add(str(r['descr']))
        if r.get('id') is not None and len(g['raw_ids']) < 8: g['raw_ids'].append(r['id'])
    suppliers=[]; relations=[]
    for bn, vals in by_buyer.items():
        ordered=sorted(vals.values(), key=lambda x:(-x['shipments'],-_ts(x['last_shipment'])))[:limit_per]
        buyer_name=next((r.get('importer') for r in rows if norm(r.get('importer'))==bn), '')
        for g in ordered:
            suppliers.append({
                'name':g['name'],'norm':norm(g['name']),'slug':'','shipments':g['shipments'],
                'last_seen':g['last_shipment'],'harvested':False,'bol_fetched':0,'via':'customs_raw',
                'evidence':{'customs':True,'trade_evidence':True,'trade_records':g['records'],'shipments':g['shipments'],
                            'last_shipment':g['last_shipment'],'hs':sorted(g['hs'])[:8],
                            'products':sorted(g['products'])[:8],'raw_ids':g['raw_ids']}
            })
            relations.append({'from_name':buyer_name,'from_type':'buyer','to_name':g['name'],'to_type':'supplier',
                              'relation':'buyer_to_supplier','evidence':suppliers[-1]['evidence'],'source':'customs_raw','confidence':1.0})
    # 合并同一供应商来自多个客户的证据
    merged={}
    for s in suppliers:
        m=merged.setdefault(s['norm'],s.copy())
        if m is not s:
            m['shipments'] += s['shipments']; m['evidence']['shipments'] += s['evidence']['shipments']
            m['evidence']['trade_records'] += s['evidence']['trade_records']
            m['evidence']['raw_ids'] = (m['evidence'].get('raw_ids') or []) + (s['evidence'].get('raw_ids') or [])
    return list(merged.values()), relations


def supplier_to_buyers(suppliers, limit_per=None):
    """从本地海关原始记录提取 shipper -> importer。"""
    limit_per=int(limit_per or settings.IY_WEB_MAX_CUSTOMERS)
    names=[s.get('name') if isinstance(s,dict) else s for s in suppliers]
    exact=_matching_shipper_names(names)
    rows=_rows_for_shippers(exact)
    by_supplier={}
    for r in rows:
        sn=norm(r.get('shipper')); bn=norm(r.get('importer'))
        if not sn or not bn: continue
        by_supplier.setdefault(sn, {}).setdefault(bn, {'name':r.get('importer'),'records':0,'shipments':0,'last_shipment':r.get('ts') or 0,'hs':set(),'products':set(),'raw_ids':[]})
        g=by_supplier[sn][bn]
        g['records'] += 1; g['shipments'] += 1; g['last_shipment']=max(_ts(g['last_shipment']),_ts(r.get('ts')))
        if r.get('hs'): g['hs'].add(str(r['hs']))
        if r.get('descr'): g['products'].add(str(r['descr']))
        if r.get('id') is not None and len(g['raw_ids']) < 8: g['raw_ids'].append(r['id'])
    buyers=[]; relations=[]
    for sn, vals in by_supplier.items():
        ordered=sorted(vals.values(), key=lambda x:(-x['shipments'],-_ts(x['last_shipment'])))[:limit_per]
        supplier_name=next((s.get('name') for s in suppliers if norm(s.get('name'))==sn), '')
        for g in ordered:
            evidence={'customs':True,'trade_evidence':True,'supplier_relation':supplier_name,'trade_records':g['records'],'shipments':g['shipments'],
                      'last_shipment':g['last_shipment'],'hs':sorted(g['hs'])[:8],'products':sorted(g['products'])[:8],'raw_ids':g['raw_ids']}
            buyers.append({'name':g['name'],'country':'USA','type':'importer','source':'customs_reverse','strength':5,'evidence':evidence})
            relations.append({'from_name':supplier_name,'from_type':'supplier','to_name':g['name'],'to_type':'buyer',
                              'relation':'supplier_to_customer','evidence':evidence,'source':'customs_raw','confidence':1.0})
    return buyers, relations
