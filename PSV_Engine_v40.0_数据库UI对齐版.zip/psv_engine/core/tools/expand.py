# -*- coding: utf-8 -*-
"""Customs Graph 网络扩张 v37：可编排任务 + 策略注册表 + 信息增益停止。

与旧版差异（后半程重构）：
- 扩张是任务不是页面：expansion_tasks 表驱动，进度面板可读，断点续跑（已完成策略不重跑）。
- 策略注册表 6 种（只保留有真实数据源的）：
  1 customer_suppliers   客户→供应商→客户（ImportYeti 网页，双向收割）
  2 supplier_customers   供应商→客户（供应商种子直接开 Customers 区）
  3 importer_suppliers   进口商→供应商（开发池买家种子，同1不同种子池）
  4 exporter_customers   出口商→客户（供应商池种子，同2不同种子池）
  5 same_product_importers 同产品进口商（本地：同产品域未开发实体提入开发候选，不造边）
  6 cross_market_entity  同实体跨市场（本地：证据显示既是客户又是供应商→kind='both'）
  （同品牌/同地址/网站/联系人组织 4 种无数据源，不做——做了就是假功能）
- 信息增益停止：单轮增益 < min_gain 切策略；连续 2 轮零增益停止；预算/深度只是安全帽。
- 交叉去重入库不变：所有实体经 db.commit_network_entity，已存在只合并证据，绝不重置区域/开发状态。
"""
import re,time
from core.config import settings
from core.memory.db import DB
from core.tools import suppliers as sup
from core.trade_graph.trade_node import evidence_level, EVIDENCE_DEMOTE

STRATEGIES={
 'customer_suppliers':{'label':'客户→供应商→客户','kind':'web'},
 'supplier_customers':{'label':'供应商→客户','kind':'web'},
 'importer_suppliers':{'label':'进口商→供应商','kind':'web'},
 'exporter_customers':{'label':'出口商→客户','kind':'web'},
 'same_product_importers':{'label':'同产品进口商','kind':'local'},
 'cross_market_entity':{'label':'同实体跨市场','kind':'local'},
}
DEFAULT_ORDER=['customer_suppliers','supplier_customers','same_product_importers','cross_market_entity']
# 种子池差异：1/3 与 2/4 共用收割函数，只是种子不同——注册表各策略真实可执行。
SEED_POOL={'customer_suppliers':('customer','dev'),'importer_suppliers':('customer','pending'),
           'supplier_customers':('supplier','dev'),'exporter_customers':('supplier','pool')}


class _WebSession:
    """一次 IY 会话内执行多个 web 策略：页访预算 + 连续失败熔断 共享。"""
    def __init__(self, task_id, stats, customers_per, suppliers_per, root_domain=''):
        from core.trade_graph import iy_network as iyn
        self.iyn=iyn; self.task_id=task_id; self.stats=stats
        self.customers_per=customers_per; self.suppliers_per=suppliers_per
        self.budget=iyn.PageBudget(); self.fails=0; self.w=None
        # v39 品类隔离：扩张产出实体与边全部打上根产品域，三品类不混
        self.root_domain=str(root_domain or '')

    def __enter__(self):
        from core.tools import iy_web
        if not iy_web.available(): raise RuntimeError('ImportYeti网页未就绪')
        self.w=iy_web.IYWeb(); return self

    def __exit__(self,*a):
        try: self.w.close()
        except Exception: pass

    def harvest_supplier(self, db, s_norm, s_name, s_slug, d, via):
        """打开供应商页拉客户：客户去重入库 + supplier→customer 边。返回(新增数,新frontier)。"""
        added=0; new_front=[]
        if self.iyn.node_fresh(s_norm,'supplier'): return 0,[]
        url=('https://www.importyeti.com/supplier/'+s_slug) if s_slug else self.iyn.node_url(s_norm,'supplier')
        if not url:
            if not self.budget.take('search:'+str(s_name)[:40]): return 0,[]
            url=self.w.supplier_page_for(s_name) or ''
        if not url:
            self.stats['errors'].append(f'{s_name}: 未解析到 ImportYeti 供应商主页'); return 0,[]
        if not self.budget.take('page:'+url[-60:]): return 0,[]
        try:
            custs=self.w.relationships(url,'Customers')[:self.customers_per]
            if not custs and self.w.last_error:
                self.fails+=1; return 0,[]
            self.fails=0
            self.iyn.mark_node(s_norm,'supplier',slug=s_slug or url.rstrip('/').split('/')[-1],url=url,run_id=self.task_id or '')
            for c in custs:
                nm=c.get('name') or ''
                if not DB._norm(nm): continue
                ev={'customs':True,'trade_evidence':True,'iy_verified':True,'shipments':c.get('shipments') or 0,
                    'products':c.get('products') or '','url':c.get('url') or url,'supplier_relation':s_name}
                r=db.commit_network_entity(nm,'customer',evidence=ev,source=f'network_expand:d{d}',zone_new='dev',product_domain=self.root_domain)
                try: db.upsert_trade_node(nm,role='buyer',url=ev.get('url',''),shipments=ev.get('shipments') or 0,products=ev.get('products',''),depth=d+1,via=s_name,source='network_expand')
                except Exception: pass
                if r.get('created'):
                    self.stats['new_leads']+=1; added+=1
                    db.mark_frontier(r['norm'],'pending',depth=d+1,task_id=self.task_id)
                    new_front.append(db.get_lead(r['norm']))
                _ev={'shipments':c.get('shipments'),'products':c.get('products') or '','url':url,'iy_verified':True}
                _lvl=evidence_level(_ev,'importyeti_web')
                db.add_relationship(self.task_id,s_name,'supplier',nm,'buyer','supplier_to_customer',
                                    _ev,'importyeti_web',
                                    confidence=min(.9 if c.get('shipments') else .75, EVIDENCE_DEMOTE.get(_lvl,1.0)),
                                    depth=d+1,evidence_level=_lvl,
                                    discovered_via=str(via or ''),parent_node=s_name,
                                    expansion_path=f'{s_name} → {nm}',product_domain=self.root_domain)
            sup.mark_harvested(s_norm,len(custs))
            sup.log_harvest(self.task_id or '',s_slug or '',s_name,'network_expand','ok',len(custs),f'depth={d};new={added};via={via}')
        except Exception as e:
            self.stats['errors'].append(f'{s_name}:{str(e)[:80]}')
        return added,new_front

    def scan_buyer(self, db, buyer, d, via):
        """打开买家页拉供应商（入库+buyer→supplier 边），并逐个收割供应商客户。返回(新增数,新frontier)。"""
        added=0; new_front=[]
        bn_=sup.norm(buyer['name'])
        if self.iyn.node_fresh(bn_,'company'): return 0,[]
        burl=str((buyer.get('evidence') or {}).get('url') or '') if isinstance(buyer.get('evidence'),dict) else ''
        if '/company/' not in burl: burl=self.iyn.node_url(bn_,'company')
        if '/company/' not in burl:
            if not self.budget.take('search:'+str(buyer['name'])[:40]): return 0,[]
            burl=self.w.company_page_for(buyer['name']) or ''
        if not burl:
            self.fails+=1; self.stats['errors'].append(f'{buyer["name"]}: 未解析到 ImportYeti 公司主页'); return 0,[]
        if not self.budget.take('page:'+burl[-60:]): return 0,[]
        rows=self.w.relationships(burl,'Suppliers')[:self.suppliers_per]
        if not rows and self.w.last_error: self.fails+=1; return 0,[]
        self.fails=0
        self.iyn.mark_node(bn_,'company',slug=burl.rstrip('/').split('/')[-1],url=burl,run_id=self.task_id or '')
        sup_entries=[]
        for r in rows:
            nm=r.get('name') or '';sn=sup.norm(nm)
            if not sn:continue
            sup_entries.append({'norm':sn,'name':nm,'slug':r.get('url','').rstrip('/').split('/')[-1] if r.get('url') else '','shipments':r.get('shipments') or 0,'last_seen':time.time(),'via':f'expand:d{d}:{buyer["name"]}'})
            ev={'customs':True,'trade_evidence':True,'iy_verified':True,'shipments':r.get('shipments') or 0,
                'products':r.get('products') or '','url':r.get('url') or burl,'customer_relation':buyer['name']}
            cr=db.commit_network_entity(nm,'supplier',evidence=ev,source=f'network_expand:d{d}',zone_new='dev',product_domain=self.root_domain)
            try: db.upsert_trade_node(nm,role='supplier',url=ev.get('url',''),shipments=ev.get('shipments') or 0,products=ev.get('products',''),depth=d,via=buyer['name'],source='network_expand')
            except Exception: pass
            if cr.get('created'): self.stats['new_suppliers']+=1
            _ev={'shipments':r.get('shipments'),'products':r.get('products') or '','url':r.get('url') or burl,'iy_verified':True}
            _lvl=evidence_level(_ev,'importyeti_web')
            db.add_relationship(self.task_id,buyer['name'],'buyer',nm,'supplier','buyer_to_supplier',
                                _ev,'importyeti_web',
                                confidence=min(.9 if r.get('shipments') else .75, EVIDENCE_DEMOTE.get(_lvl,1.0)),
                                depth=d,evidence_level=_lvl,
                                discovered_via=str(via or ''),parent_node=buyer['name'],
                                expansion_path=f'{buyer["name"]} → {nm}',product_domain=self.root_domain)
        if sup_entries: sup.upsert_pool(sup_entries)
        for se in sup_entries:
            a,nf=self.harvest_supplier(db,se['norm'],se['name'],se.get('slug') or '',d,via)
            added+=a; new_front.extend(nf)
            if self.fails>=2: break
        return added,new_front


def _local_same_product(db, root_domain, stats):
    """同产品进口商（本地策略）：同产品域内还在 pool/pending 的实体提入开发候选。
    不造关系边——候选资格本身是真实数据（同域实体已存在），只是优先级调整。"""
    if not root_domain: return 0
    leads=db.list_leads(kind='customer',zone='pool',limit=200,domain=root_domain)
    leads+=db.list_leads(kind='customer',zone='pending',limit=200,domain=root_domain)
    n=0
    for l in leads:
        db.lead_update(l['norm'],zone='dev')
        db.mark_frontier(l['norm'],'pending',depth=1,task_id=None)
        n+=1
    stats['new_leads']+=n
    return n


def _local_cross_market(db, stats):
    """同实体跨市场（本地策略）：证据显示实体既是客户又是供应商（关系边角色与 leads.kind 冲突）
    → kind='both'。真实证据驱动的实体角色修正，不造边。"""
    n=0
    for l in db.list_leads(limit=500):
        if l.get('kind')=='both': continue
        rels=db.list_relationships(norm=l['norm'],limit=50)
        roles=set()
        for r in rels:
            if r.get('from_norm')==l['norm']: roles.add(r.get('from_type'))
            if r.get('to_norm')==l['norm']: roles.add(r.get('to_type'))
        if 'supplier' in roles and ('buyer' in roles or l.get('kind')=='customer') and l.get('kind')!='both':
            db.lead_update(l['norm'],kind='both'); n+=1
    stats['new_leads']+=0  # 角色修正不产生新实体，增益记0（诚实计量）
    stats['kind_upgrades']=stats.get('kind_upgrades',0)+n
    return n


def run_network(task_id=None,seed_norms=None,depth=None,max_new=None,buyers_per=None,suppliers_per=None,
                customers_per=None,strategies=None,min_gain=1):
    """可编排扩张任务：策略轮转 + 信息增益停止 + 断点续跑。"""
    db=DB();depth=int(depth or settings.NETWORK_EXPANSION_DEPTH);max_new=int(max_new or settings.NETWORK_EXPANSION_MAX_NEW);buyers_per=int(buyers_per or settings.NETWORK_EXPANSION_BUYERS);suppliers_per=int(suppliers_per or settings.NETWORK_EXPANSION_SUPPLIERS);customers_per=int(customers_per or settings.NETWORK_EXPANSION_CUSTOMERS)
    task_id=task_id or 'exp_'+str(int(time.time()))
    strategies=[s for s in (strategies or DEFAULT_ORDER) if s in STRATEGIES]
    stats={'task_id':task_id,'depths':[],'rounds':[],'new_leads':0,'new_suppliers':0,'buyers_scanned':0,'suppliers_scanned':0,'errors':[],'stopped_by':'','stopped_by_budget':False}
    root_domain=''
    if seed_norms:
        l0=db.get_lead(seed_norms[0])
        root_domain=str((l0 or {}).get('product_domain') or '')
    # 断点续跑：已存在任务 → 跳过已完成策略
    prev=db.get_expansion_task(task_id)
    done={r.get('strategy') for r in (prev or {}).get('rounds',[])}
    db.save_expansion_task(task_id,root=','.join(seed_norms or []) or '(auto seeds)',
                           params={'depth':depth,'max_new':max_new,'buyers_per':buyers_per,'suppliers_per':suppliers_per,'customers_per':customers_per,'min_gain':min_gain},
                           strategies=strategies)
    def pick_seeds(strategy):
        if seed_norms:
            out=[]
            for n in seed_norms:
                l=db.get_lead(n)
                if l: out.append(l)
            return out
        kind,zone=SEED_POOL.get(strategy,('customer','dev'))
        return db.list_leads(kind=kind,zone=zone,limit=buyers_per)
    zero_streak=0
    web_strategies=[s for s in strategies if STRATEGIES[s]['kind']=='web' and s not in done]
    local_strategies=[s for s in strategies if STRATEGIES[s]['kind']=='local' and s not in done]
    try:
        ws=None
        if web_strategies:
            ws=_WebSession(task_id,stats,customers_per,suppliers_per,root_domain=root_domain); ws.__enter__()
        for s in web_strategies:
            if stats['new_leads']>=max_new or (ws and ws.fails>=2): break
            seeds=pick_seeds(s); frontier=seeds[:buyers_per]; round_gain=0
            is_supplier_strategy = s in ('supplier_customers','exporter_customers')
            for d in range(1,depth+1):
                if not frontier or stats['new_leads']>=max_new or ws.fails>=2: break
                next_frontier=[]; depth_new=0; bs=ss=0
                for buyer in frontier:
                    if stats['new_leads']>=max_new or ws.fails>=2: break
                    try:
                        kind=(buyer.get('kind') or '')
                        if is_supplier_strategy or kind=='supplier':
                            bn_=sup.norm(buyer['name'])
                            ev=buyer.get('evidence') if isinstance(buyer.get('evidence'),dict) else {}
                            surl=str((ev or {}).get('url') or '')
                            s_slug=surl.rstrip('/').split('/')[-1] if '/supplier/' in surl else ''
                            a,nf=ws.harvest_supplier(db,bn_,buyer['name'],s_slug,d,s); ss+=1
                        else:
                            a,nf=ws.scan_buyer(db,buyer,d,s); bs+=1
                        depth_new+=a; next_frontier.extend(nf)
                    except Exception as e:
                        ws.fails+=1; stats['errors'].append(f'{buyer["name"]}:{str(e)[:80]}')
                db.add_expansion_run(task_id,d,bs,ss,depth_new,max_new)
                stats['depths'].append({'strategy':s,'depth':d,'buyers':bs,'suppliers':ss,'new':depth_new})
                stats['buyers_scanned']+=bs; stats['suppliers_scanned']+=ss
                round_gain+=depth_new; frontier=next_frontier
                # 信息增益：本层零新增则该策略提前耗尽（不等深度帽）
                if depth_new==0: break
            stats['rounds'].append({'strategy':s,'label':STRATEGIES[s]['label'],'gain':round_gain})
            db.update_expansion_task(task_id,rounds=[{'strategy':s,'gain':round_gain,'ts':time.time()}],gained=stats['new_leads'])
            zero_streak=zero_streak+1 if round_gain< int(min_gain or 1) else 0
            if zero_streak>=2: stats['stopped_by']='consecutive_zero_gain'; break
        for s in local_strategies:
            if zero_streak>=2 and stats['stopped_by']: break
            if s=='same_product_importers':
                if not root_domain:
                    # 无根域时取实体最多的产品域
                    rows=db.list_leads(kind='customer',limit=500)
                    doms={}
                    for l in rows:
                        if l.get('product_domain'): doms[l['product_domain']]=doms.get(l['product_domain'],0)+1
                    root_domain=max(doms,key=doms.get) if doms else ''
                gain=_local_same_product(db,root_domain,stats)
            else:
                gain=_local_cross_market(db,stats)
            stats['rounds'].append({'strategy':s,'label':STRATEGIES[s]['label'],'gain':gain})
            db.update_expansion_task(task_id,rounds=[{'strategy':s,'gain':gain,'ts':time.time()}],gained=stats['new_leads'])
    except Exception as e:
        stats['errors'].append(str(e)[:160])
    finally:
        if ws:
            try: ws.__exit__(None,None,None)
            except Exception: pass
    if not stats['stopped_by']:
        if stats['new_leads']>=max_new: stats['stopped_by']='budget'; stats['stopped_by_budget']=True
        elif zero_streak>=2: stats['stopped_by']='consecutive_zero_gain'
        else: stats['stopped_by']='strategies_exhausted'
    db.update_expansion_task(task_id,gained=stats['new_leads'],status='done',stopped_by=stats['stopped_by'])
    return stats

def run(limit_buyers=None,customers_per=None,max_new=None):
    return run_network(max_new=max_new,buyers_per=limit_buyers,customers_per=customers_per)
