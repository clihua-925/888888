# -*- coding: utf-8 -*-
"""v18.0 邮件发送双通道：compose 半自动 + smtp 直发。
支持抄送多个邮箱。"""
import urllib.parse
from core.config import settings

COMPOSE={
 'gmail':'https://mail.google.com/mail/?view=cm&fs=1&to={to}&su={su}&body={body}&cc={cc}',
 'outlook':'https://outlook.live.com/mail/0/deeplink/compose?to={to}&subject={su}&body={body}&cc={cc}',
}

def compose_url(to,subject,body,cc_list=None,provider=None):
    tpl=COMPOSE.get(str(provider or getattr(settings,'MAIL_PROVIDER','outlook') or 'outlook').lower(),COMPOSE['outlook'])
    q=lambda s: urllib.parse.quote(str(s or ''),safe='')
    cc=','.join(cc_list) if cc_list else ''
    return tpl.format(to=q(to),su=q(subject),body=q(body),cc=q(cc))

def smtp_configured():
    return bool(getattr(settings,'SMTP_HOST','') and getattr(settings,'SMTP_USER','') and getattr(settings,'SMTP_PASS',''))

