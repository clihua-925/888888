import re,sqlite3,time,json
from core.config import settings

LEAD_COLS=[('category','TEXT'),('website','TEXT'),('emails','TEXT'),('phones','TEXT'),('address','TEXT'),('linkedin','TEXT'),('contact_person','TEXT'),('score','REAL'),('grade','TEXT'),('profile','TEXT'),('zone','TEXT'),('touch_status','TEXT'),('last_touch','REAL'),('audit','TEXT')]
MSG_SQL="""CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,lead_norm TEXT,direction TEXT,channel TEXT,content TEXT,draft INT,ts REAL);"""

class DB:
    def __init__(self,path=None): self.path=path or settings.DATABASE_PATH; self.init()
    def c(self): return sqlite3.connect(self.path,timeout=10)
    def init(self):
        with self.c() as x:
            x.executescript('''
            CREATE TABLE IF NOT EXISTS tasks(task_id TEXT PRIMARY KEY,request TEXT,status TEXT,result TEXT,created_at REAL,updated_at REAL);
            CREATE TABLE IF NOT EXISTS raw_sources(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT,query TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS clean_batches(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,stage TEXT,raw_count INT,clean_count INT,noise_count INT,duplicate_count INT,identity_only_count INT,hard_evidence_count INT,noise_ratio REAL,clean_ratio REAL,created_at REAL);
            CREATE TABLE IF NOT EXISTS expansion_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,depth INT,buyers_scanned INT,suppliers_scanned INT,new_customers INT,max_new INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS expansion_frontier(norm TEXT PRIMARY KEY,depth INT,source_task TEXT,status TEXT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS search_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,project_key TEXT,market TEXT,industry TEXT,limit_n INT,result_count INT,used_sources TEXT,source_errors TEXT,gate TEXT,evolved INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS project_evolution(project_key TEXT PRIMARY KEY,run_count INT,evolved INT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS source_quota(source TEXT,day TEXT,count INT,UNIQUE(source,day));
            CREATE TABLE IF NOT EXISTS source_checkpoints(source TEXT,project_key TEXT,run_count INT DEFAULT 0,cursor INT DEFAULT 0,watermark REAL DEFAULT 0,last_count INT DEFAULT 0,last_fingerprint TEXT,updated_at REAL,PRIMARY KEY(source,project_key));
            CREATE TABLE IF NOT EXISTS customs_raw(id INTEGER PRIMARY KEY AUTOINCREMENT,row_hash TEXT UNIQUE,bol TEXT,ts REAL,importer TEXT,importer_norm TEXT,shipper TEXT,notify TEXT,hs TEXT,descr TEXT,qty REAL,weight REAL,teu REAL,origin TEXT,port_load TEXT,port_discharge TEXT,source_file TEXT,direct_importer INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS buyers_90d(importer_norm TEXT PRIMARY KEY,importer TEXT,first_seen REAL,last_seen REAL,shipments INT,total_weight REAL,total_qty REAL,total_teu REAL,supplier_count INT,origins TEXT,ports TEXT,sample_desc TEXT,score REAL,reasons TEXT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS suppliers(supplier_norm TEXT PRIMARY KEY,name TEXT,slug TEXT,shipments INT,first_seen REAL,last_seen REAL,harvested_at REAL,bol_fetched INT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS company_state(norm TEXT PRIMARY KEY,name TEXT,first_seen REAL,last_seen REAL,runs_seen INT,profiled INT,source TEXT);
            CREATE TABLE IF NOT EXISTS harvest_log(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,slug TEXT,supplier TEXT,mode TEXT,status TEXT,items INT,note TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS iy_nodes(norm TEXT,kind TEXT,slug TEXT,url TEXT,shipments INT,first_seen REAL,last_visit REAL,visits INT,run_id TEXT,PRIMARY KEY(norm,kind));
            CREATE TABLE IF NOT EXISTS trade_nodes(norm TEXT PRIMARY KEY,name TEXT,role TEXT,url TEXT,shipments INT,products TEXT,hs TEXT,depth INT,via TEXT,source TEXT,first_seen REAL,last_seen REAL,runs_seen INT,raw TEXT);
            CREATE TABLE IF NOT EXISTS relationships(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,from_norm TEXT,from_name TEXT,from_type TEXT,to_norm TEXT,to_name TEXT,to_type TEXT,relation TEXT,evidence TEXT,source TEXT,confidence REAL,depth INT,created_at REAL,UNIQUE(task_id,from_norm,to_norm,relation));
            CREATE TABLE IF NOT EXISTS evidence_events(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,norm TEXT,kind TEXT,source TEXT,content TEXT,weight REAL,created_at REAL);
            CREATE TABLE IF NOT EXISTS query_stats(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,product_domain TEXT,query TEXT,query_type TEXT,expected_role TEXT,expected_product_relation TEXT,result_count INT,usable_trade_nodes INT,usable_trade_edges INT,precision_estimate REAL,recall_contribution REAL,runs_zero INT DEFAULT 0,status TEXT DEFAULT 'active',created_at REAL,updated_at REAL,UNIQUE(product_domain,query));
            CREATE TABLE IF NOT EXISTS product_intel_terms(id INTEGER PRIMARY KEY AUTOINCREMENT,product_domain TEXT,term TEXT,kind TEXT,hits INT DEFAULT 0,status TEXT DEFAULT 'learned',first_seen REAL,last_seen REAL,UNIQUE(product_domain,term));
            CREATE TABLE IF NOT EXISTS usitc_cache(id INTEGER PRIMARY KEY AUTOINCREMENT,hs TEXT,kind TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS leads(norm TEXT PRIMARY KEY,name TEXT,country TEXT,kind TEXT,hs_code TEXT,shipments INT,last_shipment TEXT,tags TEXT,segment TEXT,desc_sample TEXT,source TEXT,first_seen REAL,last_seen REAL,status TEXT);
            CREATE TABLE IF NOT EXISTS development_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,lead_norm TEXT,status TEXT,result TEXT,created_at REAL,updated_at REAL);
            CREATE TABLE IF NOT EXISTS schedules(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,job_type TEXT,market TEXT,industry TEXT,quantity INT,interval_minutes INT,enabled INT,next_run REAL,last_run REAL,last_status TEXT,params TEXT,created_at REAL,updated_at REAL,locked_until REAL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT,updated_at REAL);
            '''+MSG_SQL+'''
            ''')
            have={r[1] for r in x.execute('PRAGMA table_info(leads)')}
            for col,typ in LEAD_COLS + [('opportunity_score','REAL'),('demand_window','TEXT'),('demand_confidence','REAL'),('opportunity','TEXT'),('development_status','TEXT')]:
                if col not in have: x.execute('ALTER TABLE leads ADD COLUMN '+col+' '+typ)
            x.execute("UPDATE leads SET zone='pool' WHERE zone IS NULL OR zone=''")
            # 生产规模索引：客户→供应商→客户图谱和客户列表均需稳定走索引。
            x.executescript('''
            CREATE INDEX IF NOT EXISTS idx_customs_importer_norm_ts ON customs_raw(importer_norm,ts DESC);
            CREATE INDEX IF NOT EXISTS idx_customs_shipper_ts ON customs_raw(shipper,ts DESC);
            CREATE INDEX IF NOT EXISTS idx_customs_ts ON customs_raw(ts DESC);
            CREATE INDEX IF NOT EXISTS idx_relationships_from_norm ON relationships(from_norm,created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_relationships_to_norm ON relationships(to_norm,created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_evidence_events_norm ON evidence_events(norm,created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_leads_zone_score ON leads(zone,score DESC,shipments DESC,last_seen DESC);
            ''')
            have_s={r[1] for r in x.execute('PRAGMA table_info(schedules)')}
            if 'locked_until' not in have_s: x.execute('ALTER TABLE schedules ADD COLUMN locked_until REAL DEFAULT 0')
            # v30.8 Trade Edge 升级：shipment_count/hs/product/first_seen/last_seen 从 evidence JSON
            # 提升为真实列——图谱按边权重聚合查询不再依赖 JSON 解析。
            have_r={r[1] for r in x.execute('PRAGMA table_info(relationships)')}
            for col,typ in [('shipment_count','INT'),('hs','TEXT'),('product','TEXT'),('first_seen','REAL'),('last_seen','REAL')]:
                if col not in have_r: x.execute('ALTER TABLE relationships ADD COLUMN '+col+' '+typ)
            # v33.0：边的证据分级提升为真实列（STRONG/MEDIUM/WEAK/UNVERIFIED），
            # 图谱可按证据强度聚合，不再依赖 JSON 解析。
            if 'evidence_level' not in have_r: x.execute('ALTER TABLE relationships ADD COLUMN evidence_level TEXT')
            # v36：边的完整可追溯性——谁发现了它（discovered_via）、由哪个节点展开而来（parent_node）、
            # 完整扩张路径（expansion_path: A→B→C→D）；product_domain 严格产品域隔离。
            have_r={r[1] for r in x.execute('PRAGMA table_info(relationships)')}
            for col,typ in [('discovered_via','TEXT'),('parent_node','TEXT'),('expansion_path','TEXT'),('product_domain','TEXT')]:
                if col not in have_r: x.execute('ALTER TABLE relationships ADD COLUMN '+col+' '+typ)
            # v33.0 Trade Node 全字段：实体解析状态（RESOLVED / UNRESOLVED_TRADE_NODE）。
            have_t={r[1] for r in x.execute('PRAGMA table_info(trade_nodes)')}
            for col,typ in [('country','TEXT'),('entity_status','TEXT'),('product_domain','TEXT')]:
                if col not in have_t: x.execute('ALTER TABLE trade_nodes ADD COLUMN '+col+' '+typ)
            # v33.0 统一角色命名：importer→CUSTOMER 语义（值层面 kind: customer/supplier/both）。
            # 一个实体可同时是客户和供应商（CUSTOMER_AND_SUPPLIER → kind='both'）。
            x.execute("UPDATE leads SET kind='customer' WHERE kind='importer'")
            x.execute("""CREATE TABLE IF NOT EXISTS lead_events(id INTEGER PRIMARY KEY AUTOINCREMENT,
                norm TEXT, from_zone TEXT, to_zone TEXT, actor TEXT, reason TEXT, ts REAL)""")
            # v34 死表清理：icp_cards/companies/evidence 从未被业务读写（旧架构遗留）
            # v38 死表清理：expansion_jobs 与 expansion_tasks 双轨 → 统一为 expansion_tasks 单源
            for _t in ('icp_cards','companies','evidence','expansion_jobs'):
                x.execute(f"DROP TABLE IF EXISTS {_t}")
            have_l={r[1] for r in x.execute('PRAGMA table_info(leads)')}
            for col,typ in [('expansion_count','INTEGER DEFAULT 0'),('last_expansion','REAL'),('expansion_status','TEXT')]:
                if col not in have_l: x.execute('ALTER TABLE leads ADD COLUMN '+col+' '+typ)
            # v31.0 资源分类：贸易实体进入业务视图时携带生命周期与产品域（三产品域隔离）
            for col,typ in [('lifecycle','TEXT'),('product_domain','TEXT')]:
                if col not in have_l: x.execute('ALTER TABLE leads ADD COLUMN '+col+' '+typ)
            # v37 后半程重构：客户资格（ICP 分数/分数带/可解释原因）与邮箱验证状态成为真实列
            for col,typ in [('icp_score','REAL'),('icp_tier','TEXT'),('icp_reasons','TEXT'),('email_verified','TEXT')]:
                if col not in have_l: x.execute('ALTER TABLE leads ADD COLUMN '+col+' '+typ)
            # v38 信息补全完整链：公司简介成为补全字段
            if 'intro' not in have_l: x.execute('ALTER TABLE leads ADD COLUMN intro TEXT')
            # v37 半自动开发信：消息状态机（drafted/review_pending/approved/sent/followup）+ 发送时间
            have_m={r[1] for r in x.execute('PRAGMA table_info(messages)')}
            for col,typ in [('status','TEXT'),('sent_at','REAL'),('fail_reason','TEXT')]:
                if col not in have_m: x.execute('ALTER TABLE messages ADD COLUMN '+col+' '+typ)
            # v37 新表：联系人（邮箱排列+验证状态）、扩张任务（可编排+断点续跑）、
            # 发件人档案（USER_PROFILE 集中配置）、AI 调用观测、字段级补全事件
            x.executescript('''
            CREATE TABLE IF NOT EXISTS contacts(id INTEGER PRIMARY KEY AUTOINCREMENT,
                lead_norm TEXT, name TEXT, role TEXT, email TEXT, email_status TEXT,
                source TEXT, pattern TEXT, verified_at REAL, created_at REAL,
                UNIQUE(lead_norm,email));
            CREATE INDEX IF NOT EXISTS idx_contacts_lead ON contacts(lead_norm);
            CREATE TABLE IF NOT EXISTS expansion_tasks(task_id TEXT PRIMARY KEY,
                root TEXT, params TEXT, strategies TEXT, rounds TEXT, gained INT DEFAULT 0,
                status TEXT, stopped_by TEXT, created_at REAL, updated_at REAL);
            CREATE TABLE IF NOT EXISTS sender_profile(id INTEGER PRIMARY KEY CHECK(id=1),
                name_en TEXT, name_cn TEXT, company TEXT, phone TEXT, email TEXT,
                intro TEXT, signature TEXT, updated_at REAL);
            CREATE TABLE IF NOT EXISTS ai_calls(id INTEGER PRIMARY KEY AUTOINCREMENT,
                task TEXT, provider TEXT, model TEXT, latency REAL, fallback_from TEXT,
                ok INT, note TEXT, ts REAL);
            CREATE INDEX IF NOT EXISTS idx_ai_calls_ts ON ai_calls(ts DESC);
            CREATE TABLE IF NOT EXISTS enrichment_events(id INTEGER PRIMARY KEY AUTOINCREMENT,
                lead_norm TEXT, field TEXT, provider TEXT, value TEXT, ok INT, ts REAL);
            CREATE INDEX IF NOT EXISTS idx_enrichment_lead ON enrichment_events(lead_norm,ts DESC);
            ''')
    def save_task(self,tid,req,status,result):
        now=time.time()
        with self.c() as x: x.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?) ON CONFLICT(task_id) DO UPDATE SET status=excluded.status,result=excluded.result,updated_at=excluded.updated_at',(tid,req,status,json.dumps(result,ensure_ascii=False),now,now))
    @staticmethod
    def _norm(n): return re.sub(r'[^a-z0-9]+','',str(n or '').lower())
    @staticmethod
    def _db_value(v, max_len=None):
        # SQLite 不接受 list/dict 直接绑定；贸易数据里的 hs/emails/products 等字段经常是数组。
        if isinstance(v, (list, tuple, set)):
            v = ', '.join(str(x) for x in v if x is not None)
        elif isinstance(v, dict):
            v = json.dumps(v, ensure_ascii=False)
        if v is None: v=''
        v=str(v) if not isinstance(v,(int,float)) else v
        return v[:max_len] if max_len and isinstance(v,str) else v
    @staticmethod
    def _merge_text(old, new, sep=', '):
        vals=[]
        for v in (old, new):
            if isinstance(v,(list,tuple,set)): vals.extend(str(x).strip() for x in v if x is not None and str(x).strip())
            elif v is not None and str(v).strip(): vals.extend(x.strip() for x in str(v).replace(';',',').split(',') if x.strip())
        out=[]; seen=set()
        for v in vals:
            k=v.lower()
            if k not in seen: seen.add(k); out.append(v)
        return sep.join(out)

    @staticmethod
    def _merge_last_seen(old, new):
        if old in (None,''): return new or ''
        if new in (None,''): return old
        try:
            return new if float(new) >= float(old) else old
        except Exception:
            return new if str(new) > str(old) else old

    def upsert_leads(self,items):
        now=time.time()
        with self.c() as x:
            for c in items or []:
                nm=(c.get('name') or '').strip()
                if len(nm)<3: continue
                from core.trade_graph.trade_node import is_non_company_name
                if is_non_company_name(nm): continue  # v35 伪实体最终闸：绝不成为 leads 实体
                norm=self._norm(nm)
                old=x.execute('SELECT * FROM leads WHERE norm=?',(norm,)).fetchone()
                if old:
                    names=[d[0] for d in x.execute('PRAGMA table_info(leads)').fetchall()]
                    o=dict(zip(names,old))
                    old_tags=o.get('tags') or ''
                    tags=self._merge_text(old_tags,c.get('tags') or [],',')
                    hs=self._merge_text(o.get('hs_code') or '',c.get('hs_code') or '',', ')
                    desc=self._merge_text(o.get('desc_sample') or '',c.get('desc_sample') or '', ' | ')[:500]
                    src='+'.join(dict.fromkeys([v for part in (str(o.get('source') or ''),str(c.get('source') or '')) for v in part.split('+') if v]))
                    ship=max(int(o.get('shipments') or 0),int(c.get('shipments') or 0))
                    vals={
                        'name': nm or o.get('name') or '',
                        'country': c.get('country') or o.get('country') or '',
                        'kind': c.get('kind') or o.get('kind') or 'customer',
                        'hs_code': hs, 'shipments': ship,
                        'last_shipment': self._merge_last_seen(o.get('last_shipment'),c.get('last_shipment')),
                        'tags': tags, 'segment': c.get('segment') or o.get('segment') or '',
                        'category': c.get('category') or c.get('industry') or o.get('category') or '',
                        'desc_sample': desc, 'source': src, 'last_seen': now,
                        'status': c.get('status') or o.get('status') or 'new'
                    }
                    # 画像/联系方式只补空，不覆盖已有可信字段。
                    for col in ('website','emails','phones','address','linkedin','contact_person','profile'):
                        nv=c.get(col)
                        if nv:
                            vals[col]=self._db_value(nv)
                        else:
                            vals[col]=o.get(col) or ''
                    # 区域、开发状态、触达状态属于业务状态，增量采集绝不重置。
                    sets=','.join(k+'=?' for k in vals)
                    x.execute('UPDATE leads SET '+sets+' WHERE norm=?',tuple(self._db_value(v) for v in vals.values())+(norm,))
                else:
                    tags=self._db_value(c.get('tags') or [])
                    x.execute('INSERT INTO leads(norm,name,country,kind,hs_code,shipments,last_shipment,tags,segment,category,desc_sample,source,first_seen,last_seen,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        (norm,nm,self._db_value(c.get('country','')),self._db_value(c.get('kind','customer')),self._db_value(c.get('hs_code','')),int(c.get('shipments') or 0),self._db_value(c.get('last_shipment','')),tags,self._db_value(c.get('segment','')),self._db_value(c.get('category') or c.get('industry') or ''),self._db_value(c.get('desc_sample',''),500),self._db_value(c.get('source','')),now,now,self._db_value(c.get('status') or 'new')))
                # 每次看到该实体都更新增量状态，但不改变业务分区。
                x.execute("INSERT INTO company_state(norm,name,first_seen,last_seen,runs_seen,profiled,source) VALUES(?,?,?,?,?,?,?) ON CONFLICT(norm) DO UPDATE SET name=excluded.name,last_seen=excluded.last_seen,runs_seen=company_state.runs_seen+1,source=CASE WHEN company_state.source='' THEN excluded.source ELSE company_state.source || '+' || excluded.source END",
                          (norm,nm,now,now,1,0,self._db_value(c.get('source',''))))

    def get_source_checkpoint(self,source,project_key):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM source_checkpoints WHERE source=? AND project_key=?',(str(source),str(project_key))).fetchone()
            return dict(r) if r else {'source':source,'project_key':project_key,'run_count':0,'cursor':0,'watermark':0,'last_count':0,'last_fingerprint':''}

    def update_source_checkpoint(self,source,project_key,**kw):
        cur=self.get_source_checkpoint(source,project_key); cur.update(kw); cur['updated_at']=time.time()
        with self.c() as x:
            x.execute('INSERT INTO source_checkpoints(source,project_key,run_count,cursor,watermark,last_count,last_fingerprint,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source,project_key) DO UPDATE SET run_count=excluded.run_count,cursor=excluded.cursor,watermark=excluded.watermark,last_count=excluded.last_count,last_fingerprint=excluded.last_fingerprint,updated_at=excluded.updated_at',
                      (source,project_key,int(cur.get('run_count') or 0),int(cur.get('cursor') or 0),float(cur.get('watermark') or 0),int(cur.get('last_count') or 0),str(cur.get('last_fingerprint') or ''),cur['updated_at']))

    def list_leads(self,kind=None,segment=None,q=None,zone=None,limit=500,domain=None):
        sql='SELECT * FROM leads WHERE 1=1'; args=[]
        # v33.0：双角色实体（kind='both'）在客户视图与供应商视图中都可见
        if kind=='customer': sql+=" AND kind IN ('customer','both')"
        elif kind=='supplier': sql+=" AND kind IN ('supplier','both')"
        elif kind: sql+=' AND kind=?'; args.append(kind)
        if segment: sql+=' AND segment=?'; args.append(segment)
        if zone: sql+=' AND zone=?'; args.append(zone)
        if domain: sql+=' AND product_domain=?'; args.append(domain)
        if q: sql+=' AND name LIKE ?'; args.append('%'+q+'%')
        sql+=' ORDER BY COALESCE(score,0) DESC,shipments DESC,last_seen DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            rows=[dict(r) for r in x.execute(sql,args).fetchall()]
            # 通信界面需要直接知道：开发流程是否运行、是否生成过草稿、是否已经发送。
            for r in rows:
                n=r.get('norm') or ''
                sent=x.execute("SELECT 1 FROM messages WHERE lead_norm=? AND direction='out' AND draft=0 LIMIT 1",(n,)).fetchone()
                draft=x.execute("SELECT 1 FROM messages WHERE lead_norm=? AND direction='out' AND draft=1 LIMIT 1",(n,)).fetchone()
                running=x.execute("SELECT 1 FROM development_runs WHERE lead_norm=? AND status='running' ORDER BY id DESC LIMIT 1",(n,)).fetchone()
                r['outreach_state']='sent' if sent else ('draft' if draft else 'not_started')
                if running: r['development_status']='running'
                elif not r.get('development_status'): r['development_status']='not_started'
                # v38 业务状态机（派生，不落库——单一事实源是 zone/audit/icp/messages/development_runs）
                r['business_status'],r['business_status_label']=DB.business_status(r)
            # v40 数据库UI对齐：列表行直接携带 关系数/供应商数/信息完整度/AI验证状态（真实聚合，不造假）
            relc={};supc={}
            for fr,tn,ft,tt in x.execute('SELECT from_norm,to_norm,from_type,to_type FROM relationships'):
                # 去重口径：按"对手方实体"计数（同一对实体多任务证据行只算 1 个关系/1 个供应商）
                if fr and tn:
                    relc.setdefault(fr,set()).add(tn); relc.setdefault(tn,set()).add(fr)
                    if ft=='supplier': supc.setdefault(tn,set()).add(fr)
                    if tt=='supplier': supc.setdefault(fr,set()).add(tn)
            for r in rows:
                n=r.get('norm') or ''
                r['rel_count']=len(relc.get(n) or ()); r['sup_count']=len(supc.get(n) or ())
                filled=sum(1 for f in ('website','intro','emails','phones','contact_person','linkedin','address','country') if r.get(f))
                r['completeness']=round(filled/8.0,2)
                r['ai_status']='已验证' if r.get('audit') else '待验证'
            return rows
    @staticmethod
    def business_status(lead):
        """v38 客户业务状态机（派生状态，绝不另存一份）：
        已成交>维护中>已剔除>已联系>开发中>可开发>已验证>信息补全中>新发现。"""
        zone=str(lead.get('zone') or 'pool')
        if zone=='won': return ('won','已成交')
        if zone=='maint': return ('maint','维护中')
        if zone=='discard': return ('discard','已剔除')
        if lead.get('outreach_state')=='sent': return ('contacted','已联系')
        if str(lead.get('development_status') or '')=='running' or lead.get('outreach_state')=='draft':
            return ('developing','开发中')
        if str(lead.get('icp_tier') or '') in ('A','B') and lead.get('emails'): return ('developable','可开发')
        if lead.get('audit'): return ('verified','已验证')
        if zone=='dev': return ('enriching','信息补全中')
        return ('new','新发现')
    def get_lead(self,norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM leads WHERE norm=?',(norm,)).fetchone()
            return dict(r) if r else None
    def lead_update(self,norm,**kw):
        if not kw: return 0
        sql='UPDATE leads SET '+','.join(k+'=?' for k in kw)+' WHERE norm=?'
        with self.c() as x:
            vals=tuple(self._db_value(v) for v in kw.values())+(norm,)
            cur=x.execute(sql,vals)
            return cur.rowcount

    def commit_discovery_lead(self, company, zone='dev', kind=None):
        """增量入库：新实体才进入开发池；已存在实体只合并新海关证据，不重置区域/开发状态。
        v30.6：kind 感知——供应商节点以 kind='supplier' 入库，不再被硬编码误判成进口商。"""
        nm=(company.get('name') or '').strip()
        if not nm: return {'ok':False,'norm':'','created':False,'changed':False}
        n=self._norm(nm); before=self.get_lead(n)
        e=company.get('evidence') or {}
        kind=kind or ('supplier' if (company.get('type')=='supplier' or company.get('node_role')=='supplier') else 'customer')
        self.upsert_leads([{'name':nm,'country':company.get('country') or '','kind':kind,'shipments':e.get('shipments') or 0,
                            'last_shipment':e.get('last_shipment') or '','hs_code':e.get('hs') or '',
                            'segment':company.get('segment') or '','category':company.get('industry') or '',
                            'desc_sample':e.get('products') or '','tags':[],'source':company.get('source') or '',
                            'website':company.get('website') or '','emails':company.get('emails') or '',
                            'phones':company.get('phones') or '','address':company.get('address') or ''}])
        after=self.get_lead(n)
        if not after: return {'ok':False,'norm':n,'created':False,'changed':False}
        # v31.0：资源分类产物随实体落库——生命周期与产品域（已有实体只补空，不覆盖既有分类）
        lc=company.get('lifecycle'); pd=company.get('product_domain')
        fill={}
        if lc and not after.get('lifecycle'): fill['lifecycle']=lc
        if pd and not after.get('product_domain'): fill['product_domain']=pd
        if fill: self.lead_update(n,**fill)
        if before:
            return {'ok':True,'norm':n,'created':False,'updated':True,'zone':after.get('zone'),'changed':after!=before}
        self.lead_update(n,zone=zone,status='new',development_status='not_started')
        try: self.log_lead_event(n,'',zone,actor='database_commit',reason='首次入库分区')
        except Exception: pass
        return {'ok':True,'norm':n,'created':True,'updated':False,'zone':zone,'changed':True}

    def upsert_trade_node(self, name, role='', url='', shipments=0, products='', hs=None,
                          depth=0, via='', source='', raw=None, country='', entity_status='',
                          product_domain=''):
        """v30.7 贸易节点数据池：每一个被发现的真实贸易实体（含物流/货代等不能成为
        客户的节点）都登记在此。它是四大基础——组建图谱（节点）、验证客户（实体曾真实
        出现在海关数据里）、证明关系（配合 relationships 边）、反向收割（未展开节点清单）。
        v33.0：entity_status 标记 RESOLVED / UNRESOLVED_TRADE_NODE（解析状态不足≠删除）。
        重复出现只累加证据，不覆盖。"""
        nm=(name or '').strip()
        if len(nm)<3: return ''
        from core.trade_graph.trade_node import is_non_company_name
        if is_non_company_name(nm): return ''  # v35 伪实体最终闸：国家/城市/港口/地址不进图谱库
        n=self._norm(nm); now=time.time()
        hs_s=', '.join(str(h) for h in hs) if isinstance(hs,(list,tuple)) else str(hs or '')
        raw_s=json.dumps(raw,ensure_ascii=False)[:3000] if raw else ''
        with self.c() as x:
            old=x.execute('SELECT * FROM trade_nodes WHERE norm=?',(n,)).fetchone()
            if old:
                names=[d[0] for d in x.execute('PRAGMA table_info(trade_nodes)').fetchall()]
                o=dict(zip(names,old))
                x.execute('''UPDATE trade_nodes SET name=?, role=CASE WHEN role='' THEN ? ELSE role END,
                    url=CASE WHEN url='' THEN ? ELSE url END,
                    shipments=MAX(COALESCE(shipments,0),?), products=CASE WHEN products='' THEN ? ELSE products END,
                    hs=CASE WHEN hs='' THEN ? ELSE hs END, depth=MIN(COALESCE(depth,9),?),
                    via=CASE WHEN via='' THEN ? ELSE via END,
                    source=CASE WHEN source='' THEN ? ELSE source||'+'||? END,
                    last_seen=?, runs_seen=runs_seen+1,
                    country=CASE WHEN COALESCE(country,'')='' THEN ? ELSE country END,
                    entity_status=CASE WHEN COALESCE(entity_status,'')='' THEN ? ELSE entity_status END,
                    product_domain=CASE WHEN COALESCE(product_domain,'')='' THEN ? ELSE product_domain END,
                    raw=CASE WHEN raw='' THEN ? ELSE raw END WHERE norm=?''',
                    (nm,role,url,int(shipments or 0),str(products or '')[:300],hs_s,int(depth or 0),str(via or '')[:200],
                     str(source or '')[:120],str(source or '')[:120],now,str(country or ''),str(entity_status or ''),str(product_domain or '')[:80],raw_s,n))
            else:
                x.execute('INSERT INTO trade_nodes(norm,name,role,url,shipments,products,hs,depth,via,source,first_seen,last_seen,runs_seen,raw,country,entity_status,product_domain) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)',
                    (n,nm,role,str(url or '')[:300],int(shipments or 0),str(products or '')[:300],hs_s,int(depth or 0),str(via or '')[:200],str(source or '')[:120],now,now,raw_s,str(country or ''),str(entity_status or ''),str(product_domain or '')[:80]))
        return n

    def list_trade_nodes(self, role=None, limit=500, domain=None):
        sql='SELECT * FROM trade_nodes WHERE 1=1'; args=[]
        if role: sql+=' AND role=?'; args.append(role)
        if domain: sql+=' AND product_domain=?'; args.append(str(domain))
        sql+=' ORDER BY shipments DESC,last_seen DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]

    def commit_network_entity(self, name, kind, evidence=None, source='', zone_new='dev', extra=None, product_domain=''):
        """v30.6 交叉去重入库原语（二次开发专用）：
        客户开发挖到的供应商 / 供应商开发挖到的客户，都经此入库——
        已存在只合并证据与来源（绝不重置区域/开发状态），新实体才落到 zone_new。
        返回 {'norm','created','zone'}。"""
        nm=(name or '').strip()
        if len(nm)<3: return {'ok':False,'norm':'','created':False}
        n=self._norm(nm); e=evidence or {}; ex=extra or {}
        before=self.get_lead(n)
        item={'name':nm,'country':ex.get('country') or '','kind':'supplier' if kind=='supplier' else 'customer',
              'shipments':e.get('shipments') or 0,'last_shipment':e.get('last_shipment') or '',
              'hs_code':e.get('hs') or '','desc_sample':(e.get('products') or '')[:300],
              'source':source or '','website':ex.get('website') or '','emails':ex.get('emails') or '',
              'phones':ex.get('phones') or '','address':ex.get('address') or ''}
        self.upsert_leads([item])
        if before:
            return {'ok':True,'norm':n,'created':False,'zone':(before or {}).get('zone')}
        self.lead_update(n,zone=zone_new,status='new',development_status='not_started')
        if product_domain: self.lead_update(n,product_domain=str(product_domain)[:80])
        return {'ok':True,'norm':n,'created':True,'zone':zone_new}

    def network_analysis(self, limit=12):
        """v30.6 贸易网分析：基于 relationships 事实表 + leads 身份。
        回答：哪些供应商服务的客户最多（核心供应商）、哪些客户连接的供应商最多、
        哪些供应商被 ≥2 个客户共享（交叉点=渗透价值最高的节点）。"""
        with self.c() as x:
            x.row_factory=sqlite3.Row
            rel_total=x.execute('SELECT COUNT(*) FROM relationships').fetchone()[0]
            nodes=x.execute('SELECT COUNT(DISTINCT from_norm)+COUNT(DISTINCT to_norm) FROM relationships').fetchone()[0]
            iy=x.execute("SELECT COUNT(*) FROM relationships WHERE evidence LIKE '%iy_verified\": true%' OR evidence LIKE '%iy_verified\":true%'").fetchone()[0]
            top_sup=[dict(r) for r in x.execute("""
                SELECT to_name AS name, to_norm AS norm, COUNT(DISTINCT from_norm) AS customers, SUM(CAST(json_extract(evidence,'$.shipments') AS INT)) AS shipments
                FROM relationships WHERE relation='buyer_to_supplier'
                GROUP BY to_norm ORDER BY customers DESC, shipments DESC LIMIT ?""",(limit,)).fetchall()]
            top_sup2=[dict(r) for r in x.execute("""
                SELECT from_name AS name, from_norm AS norm, COUNT(DISTINCT to_norm) AS customers, SUM(CAST(json_extract(evidence,'$.shipments') AS INT)) AS shipments
                FROM relationships WHERE relation='supplier_to_customer'
                GROUP BY from_norm ORDER BY customers DESC, shipments DESC LIMIT ?""",(limit,)).fetchall()]
            # 两个方向合并取并集（同一供应商可能同时出现在两种关系里）
            merged={}
            for r in top_sup+top_sup2:
                m=merged.setdefault(r['norm'],{'name':r['name'],'norm':r['norm'],'customers':0,'shipments':0})
                m['customers']=max(m['customers'],r['customers'] or 0); m['shipments']=max(m['shipments'] or 0,r['shipments'] or 0)
            top_suppliers=sorted(merged.values(),key=lambda r:(-r['customers'],-(r['shipments'] or 0)))[:limit]
            top_customers=[dict(r) for r in x.execute("""
                SELECT from_name AS name, from_norm AS norm, COUNT(DISTINCT to_norm) AS suppliers
                FROM relationships WHERE relation='buyer_to_supplier'
                GROUP BY from_norm ORDER BY suppliers DESC LIMIT ?""",(limit,)).fetchall()]
            shared=[dict(r) for r in x.execute("""
                SELECT name, norm, COUNT(DISTINCT cust) AS shared_customers FROM (
                    SELECT to_name AS name, to_norm AS norm, from_norm AS cust FROM relationships WHERE relation='buyer_to_supplier'
                    UNION ALL
                    SELECT from_name AS name, from_norm AS norm, to_norm AS cust FROM relationships WHERE relation='supplier_to_customer'
                ) GROUP BY norm HAVING COUNT(DISTINCT cust)>=2
                ORDER BY shared_customers DESC LIMIT ?""",(limit,)).fetchall()]
            by_source=[dict(r) for r in x.execute('SELECT source, COUNT(*) AS n FROM relationships GROUP BY source ORDER BY n DESC').fetchall()]
            lead_kinds={r[0]:r[1] for r in x.execute('SELECT kind, COUNT(*) FROM leads GROUP BY kind').fetchall()}
        return {'relations_total':rel_total,'iy_verified_relations':iy,'top_suppliers':top_suppliers,
                'top_customers':top_customers,'shared_suppliers':shared,'by_source':by_source,
                'lead_kinds':lead_kinds}

    def set_zone(self,norm,zone,touch_status=None):
        kw={'zone':zone}
        if touch_status is not None: kw['touch_status']=touch_status; kw['last_touch']=time.time()
        self.lead_update(norm,**kw)
    def log_lead_event(self,norm,from_zone,to_zone,actor='system',reason=''):
        with self.c() as x:
            x.execute('INSERT INTO lead_events(norm,from_zone,to_zone,actor,reason,ts) VALUES(?,?,?,?,?,?)',
                      (norm,from_zone or '',to_zone or '',actor or 'system',str(reason or '')[:300],time.time()))

    def list_lead_events(self,norm,limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM lead_events WHERE norm=? ORDER BY id DESC LIMIT ?',(norm,int(limit))).fetchall()]

    def move_lead(self,norm,zone,actor='ui',reason=''):
        # v35：唯一生命周期状态机（core/domain/lifecycle.py）——迁移规则+证据门槛+审计日志
        from core.domain import lifecycle
        return lifecycle.transition(self,norm,zone,actor=actor,reason=reason)

    def get_lead_detail(self,norm):
        lead=self.get_lead(norm)
        if not lead:return None
        dev=self.latest_development(norm)
        msgs=self.list_messages(norm,limit=200)
        rel=self.list_relationships(norm=norm,limit=300)
        ev=self.list_evidence_events(norm,limit=300)
        hard=bool(int(lead.get('shipments') or 0)>0 or lead.get('source','').find('customs')>=0 or lead.get('source','').find('importyeti')>=0 or rel)
        eligible=lead.get('zone')=='dev' and lead.get('zone')!='discard'
        return {'lead':lead,'eligible':bool(eligible),'evidence_strength':'strong' if hard else 'identity_only','development':dev,'messages':msgs,'relationships':rel,'evidence_events':ev,'lifecycle_events':self.list_lead_events(norm,50)}

    def expansion_activity(self):
        """v38 单源化：扩张活动统一读 expansion_tasks（expansion_jobs 双轨已废弃）。"""
        with self.c() as x:
            x.row_factory=sqlite3.Row
            rows=[dict(r) for r in x.execute("SELECT task_id,root,status,created_at,gained FROM expansion_tasks WHERE status='running' ORDER BY created_at DESC LIMIT 100").fetchall()]
            for r in rows:
                r['seed_norm']=str(r.get('root') or '').split(',')[0].strip()
            return rows

    def add_message(self,norm,direction,channel,content,draft=0):
        with self.c() as x: x.execute('INSERT INTO messages(lead_norm,direction,channel,content,draft,ts) VALUES(?,?,?,?,?,?)',(norm,direction,channel,content,int(draft),time.time()))
        self.lead_update(norm,last_touch=time.time())
    def get_message(self,mid):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM messages WHERE id=?',(int(mid),)).fetchone()
            return dict(r) if r else None
    def delete_message(self,mid):
        with self.c() as x: x.execute('DELETE FROM messages WHERE id=?',(int(mid),))
    def update_message(self,mid,content):
        with self.c() as x: x.execute('UPDATE messages SET content=? WHERE id=?',(str(content),int(mid)))
    def list_messages(self,norm,limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM messages WHERE lead_norm=? ORDER BY ts ASC LIMIT ?',(norm,int(limit))).fetchall()]
    def add_relationship(self,task_id,from_name,from_type,to_name,to_type,relation,evidence,source,confidence=0.0,depth=1,evidence_level='',
                         discovered_via='',parent_node='',expansion_path='',product_domain=''):
        """v30.8：边携带真实列（shipment_count/hs/product/first_seen/last_seen）。
        v33.0：标准边字段补齐 evidence_level（STRONG/MEDIUM/WEAK/UNVERIFIED）。
        v36：边携带完整可追溯性（discovered_via/parent_node/expansion_path）+ product_domain 域隔离——
        数据库必须能回答“C 是通过 B 发现的”。
        同一对实体的边再次出现时累加证据（票数取大、last_seen 更新），不静默丢弃。"""
        fn=self._norm(from_name); tn=self._norm(to_name)
        if not fn or not tn: return
        e=evidence or {}
        hs=e.get('hs'); hs_s=', '.join(str(h) for h in hs) if isinstance(hs,(list,tuple)) else str(hs or '')
        ship=int(e.get('shipments') or 0); prod=str(e.get('products') or e.get('product_text') or '')[:300]
        lvl=str(evidence_level or e.get('evidence_level') or '')
        dvia=str(discovered_via or '')[:200]; pnode=str(parent_node or '')[:200]; epath=str(expansion_path or '')[:600]; pdom=str(product_domain or '')[:80]
        now=time.time()
        sql="INSERT OR IGNORE INTO relationships(task_id,from_norm,from_name,from_type,to_norm,to_name,to_type,relation,evidence,source,confidence,depth,created_at,shipment_count,hs,product,first_seen,last_seen,evidence_level,discovered_via,parent_node,expansion_path,product_domain) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        with self.c() as x:
            cur=x.execute(sql,(task_id,fn,from_name,from_type,tn,to_name,to_type,relation,json.dumps(e,ensure_ascii=False),source,float(confidence or 0),int(depth or 1),now,ship,hs_s,prod,now,now,lvl,dvia,pnode,epath,pdom))
            if cur.rowcount==0:
                # 已存在的边：累加证据而非忽略（追溯字段只补缺，不覆盖既有事实）
                x.execute("""UPDATE relationships SET shipment_count=MAX(COALESCE(shipment_count,0),?),
                    last_seen=?, confidence=MAX(COALESCE(confidence,0),?),
                    hs=CASE WHEN hs IS NULL OR hs='' THEN ? ELSE hs END,
                    product=CASE WHEN product IS NULL OR product='' THEN ? ELSE product END,
                    evidence_level=CASE WHEN COALESCE(evidence_level,'')='' THEN ? ELSE evidence_level END,
                    discovered_via=CASE WHEN COALESCE(discovered_via,'')='' THEN ? ELSE discovered_via END,
                    parent_node=CASE WHEN COALESCE(parent_node,'')='' THEN ? ELSE parent_node END,
                    expansion_path=CASE WHEN COALESCE(expansion_path,'')='' THEN ? ELSE expansion_path END,
                    product_domain=CASE WHEN COALESCE(product_domain,'')='' THEN ? ELSE product_domain END
                    WHERE task_id=? AND from_norm=? AND to_norm=? AND relation=?""",
                    (ship,now,float(confidence or 0),hs_s,prod,lvl,dvia,pnode,epath,pdom,task_id,fn,tn,relation))
    def list_relationships(self,task_id=None,norm=None,limit=500,domain=None):
        sql='SELECT * FROM relationships WHERE 1=1'; args=[]
        if task_id: sql+=' AND task_id=?'; args.append(task_id)
        if norm: sql+=' AND (from_norm=? OR to_norm=?)'; args += [norm,norm]
        if domain: sql+=' AND product_domain=?'; args.append(str(domain))
        sql+=' ORDER BY confidence DESC,created_at DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]
    def expansion_path_for(self, norm, max_hops=12):
        """v36：多跳扩张路径重建——沿 relationships.parent_node 逐级回溯，
        回答“C 是通过 B 发现的，D 是通过 C 发现的”。返回 [根, ..., 目标] 名称链。"""
        target=self._norm(norm)
        if not target: return []
        chain=[]; seen=set(); cur=target
        with self.c() as x:
            x.row_factory=sqlite3.Row
            while cur and cur not in seen and len(chain)<int(max_hops):
                seen.add(cur)
                r=x.execute("""SELECT from_name,from_norm,parent_node,to_name FROM relationships
                               WHERE to_norm=? AND COALESCE(parent_node,'')!=''
                               ORDER BY created_at ASC LIMIT 1""",(cur,)).fetchone()
                if not r: break
                chain.append(r['to_name'] or cur)
                pn=self._norm(r['parent_node'])
                if not pn or pn==cur: break
                cur=pn
            if cur and cur not in [self._norm(x0) for x0 in chain]:
                r2=x.execute("SELECT from_name FROM relationships WHERE to_norm=? LIMIT 1",(cur,)).fetchone()
                chain.append((r2['from_name'] if r2 else '') or cur)
        return list(reversed(chain))

    def add_evidence_event(self,task_id,norm,kind,source,content,weight=1.0):
        with self.c() as x:
            x.execute('INSERT INTO evidence_events(task_id,norm,kind,source,content,weight,created_at) VALUES(?,?,?,?,?,?,?)',(task_id,norm,kind,source,str(content or '')[:2000],float(weight or 0),time.time()))
    def save_raw_source(self,source,query,payload):
        with self.c() as x:
            x.execute('INSERT INTO raw_sources(source,query,payload,created_at) VALUES(?,?,?,?)',(str(source),str(query or ''),json.dumps(payload,ensure_ascii=False)[:50000],time.time()))
    def save_clean_batch(self,task_id,stage,stats):
        with self.c() as x:
            x.execute('INSERT INTO clean_batches(task_id,stage,raw_count,clean_count,noise_count,duplicate_count,identity_only_count,hard_evidence_count,noise_ratio,clean_ratio,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                (task_id,stage,int(stats.get('raw',0)),int(stats.get('clean',0)),int(stats.get('noise',0)),int(stats.get('duplicate',0)),int(stats.get('identity_only',0)),int(stats.get('hard_evidence',0)),float(stats.get('noise_ratio',0)),float(stats.get('clean_ratio',0)),time.time()))
    def add_expansion_run(self,task_id,depth,buyers_scanned,suppliers_scanned,new_customers,max_new):
        with self.c() as x:
            x.execute('INSERT INTO expansion_runs(task_id,depth,buyers_scanned,suppliers_scanned,new_customers,max_new,created_at) VALUES(?,?,?,?,?,?,?)',(task_id,int(depth),int(buyers_scanned),int(suppliers_scanned),int(new_customers),int(max_new),time.time()))
    def get_frontier(self,limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute("SELECT * FROM expansion_frontier WHERE status='pending' ORDER BY depth,updated_at LIMIT ?",(int(limit),)).fetchall()]
    def mark_frontier(self,norm,status,depth=None,task_id=None):
        with self.c() as x:
            x.execute('INSERT INTO expansion_frontier(norm,depth,source_task,status,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(norm) DO UPDATE SET depth=excluded.depth,source_task=excluded.source_task,status=excluded.status,updated_at=excluded.updated_at',(norm,int(depth or 0),task_id or '',status,time.time()))
    def get_task(self,tid):
        with self.c() as x: r=x.execute('SELECT request,status,result FROM tasks WHERE task_id=?',(tid,)).fetchone()
        return None if not r else {'request':r[0],'status':r[1],'result':json.loads(r[2] or '{}')}

    def list_evidence_events(self,norm,limit=200):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute("SELECT * FROM evidence_events WHERE norm=? ORDER BY created_at DESC LIMIT ?",(norm,int(limit))).fetchall()]
    def upsert_schedule(self,name,job_type,market,industry,quantity,interval_minutes,enabled=True,params=None,next_run=None):
        now=time.time(); interval=max(1,int(interval_minutes or 60)); nr=float(next_run if next_run is not None else now+interval*60)
        sql="""INSERT INTO schedules(name,job_type,market,industry,quantity,interval_minutes,enabled,next_run,last_run,last_status,params,created_at,updated_at,locked_until) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,0) ON CONFLICT(name) DO UPDATE SET job_type=excluded.job_type,market=excluded.market,industry=excluded.industry,quantity=excluded.quantity,interval_minutes=excluded.interval_minutes,enabled=excluded.enabled,next_run=excluded.next_run,params=excluded.params,updated_at=excluded.updated_at,locked_until=0"""
        with self.c() as x:x.execute(sql,(name,job_type,market,industry,int(quantity or 20),interval,int(bool(enabled)),nr,None,'idle',json.dumps(params or {},ensure_ascii=False),now,now))
    def list_schedules(self,enabled=None):
        sql='SELECT * FROM schedules';args=[]
        if enabled is not None:sql+=' WHERE enabled=?';args.append(int(bool(enabled)))
        sql+=' ORDER BY next_run ASC'
        with self.c() as x:
            x.row_factory=sqlite3.Row; rows=[dict(r) for r in x.execute(sql,args).fetchall()]
        for r in rows:r['params']=json.loads(r.get('params') or '{}')
        return rows
    def set_schedule_enabled(self,sid,enabled):
        now=time.time(); en=int(bool(enabled))
        with self.c() as x:
            row=x.execute('SELECT interval_minutes,next_run FROM schedules WHERE id=?',(int(sid),)).fetchone()
            if not row: return False
            interval=int(row[0] or 60)
            if en:
                # 启用后：若原计划已过期则立即进入下一轮，否则保持原计划时间。
                nr=float(row[1] or 0)
                if nr <= now: nr=now
                x.execute("UPDATE schedules SET enabled=1,next_run=?,last_status='enabled',updated_at=?,locked_until=0 WHERE id=?",(nr,now,int(sid)))
            else:
                x.execute("UPDATE schedules SET enabled=0,last_status='disabled',updated_at=?,locked_until=0 WHERE id=?",(now,int(sid)))
            return True

    def delete_schedule(self,sid):
        with self.c() as x:x.execute('DELETE FROM schedules WHERE id=?',(int(sid),))
    def claim_due_schedule(self,sid,lock_seconds=300):
        now=time.time(); until=now+max(10,int(lock_seconds))
        with self.c() as x:
            cur=x.execute("UPDATE schedules SET locked_until=?,last_status='running',updated_at=? WHERE id=? AND enabled=1 AND next_run<=? AND COALESCE(locked_until,0)<=?",(until,now,int(sid),now,now))
            return cur.rowcount==1
    def mark_schedule_run(self,sid,status,next_run=None):
        now=time.time()
        with self.c() as x:
            if next_run is None:
                row=x.execute('SELECT interval_minutes FROM schedules WHERE id=?',(int(sid),)).fetchone(); next_run=now+int(row[0] or 60)*60 if row else now+3600
            x.execute('UPDATE schedules SET last_run=?,last_status=?,next_run=?,updated_at=?,locked_until=0 WHERE id=?',(now,status,next_run,now,int(sid)))
    def save_development_blackboard(self,norm,result):
        now=time.time(); payload=json.dumps(result,ensure_ascii=False)
        with self.c() as x:
            row=x.execute("SELECT id FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1",(norm,)).fetchone()
            if row:x.execute("UPDATE development_runs SET status=?,result=?,updated_at=? WHERE id=?",('running',payload,now,row[0]))
            else:x.execute("INSERT INTO development_runs(lead_norm,status,result,created_at,updated_at) VALUES(?,?,?,?,?)",(norm,'running',payload,now,now))
    def save_development(self,norm,result):
        self.save_development_blackboard(norm,result)
    def finish_development(self,norm,result,status='done'):
        now=time.time(); payload=json.dumps(result,ensure_ascii=False)
        with self.c() as x:
            row=x.execute("SELECT id FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1",(norm,)).fetchone()
            if row:x.execute("UPDATE development_runs SET status=?,result=?,updated_at=? WHERE id=?",(status,payload,now,row[0]))
            else:x.execute("INSERT INTO development_runs(lead_norm,status,result,created_at,updated_at) VALUES(?,?,?,?,?)",(norm,status,payload,now,now))
            x.execute("UPDATE leads SET development_status=? WHERE norm=?",(status,norm))
    def latest_development(self,norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row; r=x.execute('SELECT * FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1',(norm,)).fetchone()
            if not r:return None
            d=dict(r); d['result']=json.loads(d.get('result') or '{}'); return d

    def save_query_stat(self, task_id, product_domain, item):
        """v33.0 逐查询计量：每条查询词的产出全程留痕。
        动态淘汰规则（不过度过滤）：仅当一条查询【连续两轮】result_count=0 且
        usable_trade_nodes=0 才标记 retired（下轮规划降权，不删除记录）；
        有任何产出立即回活。retire 是排序信号，不是数据删除。"""
        q=str(item.get('query') or '').strip()
        if not q: return
        dom=str(product_domain or ''); now=time.time()
        rc=int(item.get('result_count') or 0); un=int(item.get('usable_trade_nodes') or 0)
        ue=int(item.get('usable_trade_edges') or 0)
        pe=item.get('precision_estimate'); rc2=item.get('recall_contribution')
        with self.c() as x:
            old=x.execute('SELECT runs_zero,status FROM query_stats WHERE product_domain=? AND query=?',(dom,q)).fetchone()
            zero=((old[0] if old else 0)+1) if (rc==0 and un==0) else 0
            status='retired' if zero>=2 else 'active'
            x.execute('''INSERT INTO query_stats(task_id,product_domain,query,query_type,expected_role,expected_product_relation,
                result_count,usable_trade_nodes,usable_trade_edges,precision_estimate,recall_contribution,runs_zero,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(product_domain,query) DO UPDATE SET task_id=excluded.task_id,query_type=excluded.query_type,
                expected_role=excluded.expected_role,expected_product_relation=excluded.expected_product_relation,
                result_count=excluded.result_count,usable_trade_nodes=excluded.usable_trade_nodes,
                usable_trade_edges=excluded.usable_trade_edges,precision_estimate=excluded.precision_estimate,
                recall_contribution=excluded.recall_contribution,runs_zero=excluded.runs_zero,status=excluded.status,updated_at=excluded.updated_at''',
                (str(task_id or ''),dom,q,str(item.get('query_type') or ''),str(item.get('expected_role') or ''),
                 str(item.get('expected_product_relation') or ''),rc,un,ue,
                 float(pe) if pe is not None else None,float(rc2) if rc2 is not None else None,zero,status,now,now))
    def save_intel_terms(self, product_domain, terms, kind='customs_descr'):
        """v36 产品情报记忆：真实海关描述词反哺（幂等累加命中数，不覆盖）。"""
        dom=str(product_domain or ''); now=time.time(); n=0
        with self.c() as x:
            for t,hits in (terms or {}).items():
                t=str(t or '').strip()[:120]
                if not t: continue
                x.execute('''INSERT INTO product_intel_terms(product_domain,term,kind,hits,status,first_seen,last_seen)
                    VALUES(?,?,?,?, 'learned', ?,?)
                    ON CONFLICT(product_domain,term) DO UPDATE SET hits=hits+excluded.hits,last_seen=excluded.last_seen''',
                    (dom,t,str(kind),int(hits or 0),now,now))
                n+=1
        return n
    def list_intel_terms(self, product_domain, status='learned', min_hits=2, limit=50):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM product_intel_terms WHERE product_domain=? AND status=? AND hits>=? ORDER BY hits DESC LIMIT ?',
                                               (str(product_domain or ''),str(status),int(min_hits),int(limit))).fetchall()]

    def list_query_stats(self, product_domain=None, status=None, limit=500):
        sql='SELECT * FROM query_stats WHERE 1=1'; args=[]
        if product_domain: sql+=' AND product_domain=?'; args.append(str(product_domain))
        if status: sql+=' AND status=?'; args.append(str(status))
        sql+=' ORDER BY usable_trade_nodes DESC,result_count DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]

    def get_setting(self,key,default=None):
        with self.c() as x:
            r=x.execute("SELECT value FROM app_settings WHERE key=?",(str(key),)).fetchone()
            return r[0] if r else default
    def set_setting(self,key,value):
        with self.c() as x:x.execute("INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",(str(key),str(value),time.time()))

    # ---------------- v37 后半程重构：联系人 / 扩张任务 / 发件人档案 / AI 观测 / 补全事件 ----------------
    def upsert_contact(self, lead_norm, email, name='', role='', email_status='guessed', source='', pattern=''):
        em=str(email or '').strip().lower()
        if not em or '@' not in em: return False
        with self.c() as x:
            x.execute('''INSERT INTO contacts(lead_norm,name,role,email,email_status,source,pattern,verified_at,created_at)
                VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(lead_norm,email) DO UPDATE SET
                name=CASE WHEN excluded.name!='' THEN excluded.name ELSE name END,
                role=CASE WHEN excluded.role!='' THEN excluded.role ELSE role END,
                email_status=CASE WHEN excluded.email_status!='' THEN excluded.email_status ELSE email_status END,
                source=CASE WHEN excluded.source!='' THEN excluded.source ELSE source END,
                pattern=CASE WHEN excluded.pattern!='' THEN excluded.pattern ELSE pattern END,
                verified_at=CASE WHEN excluded.verified_at IS NOT NULL THEN excluded.verified_at ELSE verified_at END''',
                (str(lead_norm or ''),str(name or '')[:120],str(role or '')[:120],em,str(email_status or 'guessed'),
                 str(source or '')[:120],str(pattern or '')[:60],
                 time.time() if email_status in ('mx_ok','pattern') else None,time.time()))
        return True
    def list_contacts(self, lead_norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM contacts WHERE lead_norm=? ORDER BY created_at ASC',(str(lead_norm or ''),)).fetchall()]
    def set_message_status(self, mid, status, sent=False, reason=None):
        """v39 发送五态：drafted/ready_to_send(待发送)/opened(已打开)/sent(已发送)/send_failed(失败+原因)。
        reason 写入 fail_reason——失败必须带人话原因，绝不只改状态。"""
        with self.c() as x:
            if sent: x.execute('UPDATE messages SET status=?,sent_at=?,draft=0,fail_reason=NULL WHERE id=?',(str(status),time.time(),int(mid)))
            elif reason is not None: x.execute('UPDATE messages SET status=?,fail_reason=? WHERE id=?',(str(status),str(reason)[:300],int(mid)))
            else: x.execute('UPDATE messages SET status=? WHERE id=?',(str(status),int(mid)))
    def latest_out_message(self, norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute("SELECT * FROM messages WHERE lead_norm=? AND direction='out' ORDER BY ts DESC LIMIT 1",(str(norm or ''),)).fetchone()
            return dict(r) if r else None
    # --- 扩张任务：可编排、进度面板、断点续跑 ---
    def save_expansion_task(self, task_id, root, params, strategies):
        now=time.time()
        with self.c() as x:
            x.execute('''INSERT INTO expansion_tasks(task_id,root,params,strategies,rounds,gained,status,stopped_by,created_at,updated_at)
                VALUES(?,?,?,?,?,0,'running','',?,?)
                ON CONFLICT(task_id) DO UPDATE SET status='running',updated_at=excluded.updated_at''',
                (str(task_id),str(root or ''),json.dumps(params or {},ensure_ascii=False),
                 json.dumps(list(strategies or []),ensure_ascii=False),'[]',now,now))
    def update_expansion_task(self, task_id, rounds=None, gained=None, status=None, stopped_by=None):
        with self.c() as x:
            row=x.execute('SELECT rounds,gained FROM expansion_tasks WHERE task_id=?',(str(task_id),)).fetchone()
            if not row: return
            r=json.loads(row[0] or '[]'); g=int(row[1] or 0)
            if rounds: r.extend(rounds)
            if gained is not None: g=int(gained)
            x.execute('UPDATE expansion_tasks SET rounds=?,gained=?,status=COALESCE(?,status),stopped_by=COALESCE(?,stopped_by),updated_at=? WHERE task_id=?',
                      (json.dumps(r,ensure_ascii=False),g,status,stopped_by,time.time(),str(task_id)))
    def get_expansion_task(self, task_id):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM expansion_tasks WHERE task_id=?',(str(task_id),)).fetchone()
            if not r: return None
            d=dict(r); d['params']=json.loads(d.get('params') or '{}'); d['strategies']=json.loads(d.get('strategies') or '[]'); d['rounds']=json.loads(d.get('rounds') or '[]')
            return d
    def list_expansion_tasks(self, limit=20):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            out=[]
            for r in x.execute('SELECT * FROM expansion_tasks ORDER BY created_at DESC LIMIT ?',(int(limit),)).fetchall():
                d=dict(r); d['params']=json.loads(d.get('params') or '{}'); d['strategies']=json.loads(d.get('strategies') or '[]'); d['rounds']=json.loads(d.get('rounds') or '[]')
                out.append(d)
            return out
    # --- 发件人档案（USER_PROFILE 集中配置，单行表） ---
    def get_sender_profile(self):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM sender_profile WHERE id=1').fetchone()
            if r: return dict(r)
        # 首次读取：用 settings 里的 SENDER_* 播种，保证 UI 与既有签名一致
        prof={'name_en':settings.SENDER_NAME_EN,'name_cn':settings.SENDER_NAME,'company':settings.SENDER_COMPANY,
              'phone':settings.SENDER_PHONE,'email':settings.SENDER_EMAIL,'intro':'','signature':''}
        self.save_sender_profile(prof); prof=self.get_sender_profile()
        return prof
    def save_sender_profile(self, prof):
        p=prof or {}
        with self.c() as x:
            x.execute('''INSERT INTO sender_profile(id,name_en,name_cn,company,phone,email,intro,signature,updated_at)
                VALUES(1,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET name_en=excluded.name_en,name_cn=excluded.name_cn,company=excluded.company,
                phone=excluded.phone,email=excluded.email,intro=excluded.intro,signature=excluded.signature,updated_at=excluded.updated_at''',
                (str(p.get('name_en') or ''),str(p.get('name_cn') or ''),str(p.get('company') or ''),str(p.get('phone') or ''),
                 str(p.get('email') or ''),str(p.get('intro') or ''),str(p.get('signature') or ''),time.time()))
    # --- AI 网关观测 ---
    def log_ai_call(self, task, provider, model, latency, ok, fallback_from='', note=''):
        with self.c() as x:
            x.execute('INSERT INTO ai_calls(task,provider,model,latency,fallback_from,ok,note,ts) VALUES(?,?,?,?,?,?,?,?)',
                      (str(task)[:60],str(provider)[:40],str(model)[:80],float(latency or 0),str(fallback_from or '')[:40],
                       1 if ok else 0,str(note or '')[:200],time.time()))
    def list_ai_calls(self, limit=50):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM ai_calls ORDER BY ts DESC LIMIT ?',(int(limit),)).fetchall()]
    # --- 字段级补全事件（waterfall 每一步留痕） ---
    def add_enrichment_event(self, lead_norm, field, provider, value, ok):
        with self.c() as x:
            x.execute('INSERT INTO enrichment_events(lead_norm,field,provider,value,ok,ts) VALUES(?,?,?,?,?,?)',
                      (str(lead_norm or ''),str(field)[:40],str(provider)[:60],str(value or '')[:300],1 if ok else 0,time.time()))
    def list_enrichment_events(self, lead_norm, limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM enrichment_events WHERE lead_norm=? ORDER BY ts DESC LIMIT ?',(str(lead_norm or ''),int(limit))).fetchall()]
