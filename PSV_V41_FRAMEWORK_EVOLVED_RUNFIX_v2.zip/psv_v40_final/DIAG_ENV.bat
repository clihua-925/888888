@echo off
echo ==== PSV41 ENV CHECK ====
echo STEP-1 file-readable-and-cmd-ok
ver
echo.
echo STEP-2 workdir
cd
echo.
echo STEP-3 python-in-PATH
where python 2>nul || echo   [X] python NOT in PATH
python --version 2>nul
echo.
echo STEP-4 venv-local
if exist "%~dp0venv\Scripts\python.exe" (echo   venv-local: FOUND %~dp0venv) else (echo   venv-local: none)
echo STEP-5 venv-parent
if exist "%~dp0..\venv\Scripts\python.exe" (echo   venv-parent: FOUND %~dp0..\venv) else (echo   venv-parent: none)
echo.
echo STEP-6 key-deps
python -c "import fastapi,uvicorn,pydantic;print('   fastapi/uvicorn/pydantic: OK')" 2>&1
echo.
echo STEP-7 ports
netstat -ano | findstr "LISTENING" | findstr ":8000 :9222" || echo   no-8000-no-9222
echo.
echo STEP-8 start-log-tail
if exist "%~dp0logs\start.log" (powershell -NoProfile -Command "Get-Content '%~dp0logs\start.log' -Tail 10" 2>nul) else (echo   start.log NOT FOUND - bat died before line 8)
echo.
echo ==== CHECK DONE ====
pause
