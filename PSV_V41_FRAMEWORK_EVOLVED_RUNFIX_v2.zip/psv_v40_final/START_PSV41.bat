@echo off
REM PSV V41 launcher - pure ASCII (safe under any codepage: 936/65001)
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title PSV V41 Supply Chain Agent
set "LOG=%~dp0logs\start.log"
if not exist "%~dp0logs" mkdir "%~dp0logs" >nul 2>nul
echo ===== %DATE% %TIME% start ===== >> "%LOG%"

call :check_python
if errorlevel 1 goto fail
call :check_venv
if errorlevel 1 goto fail
call :check_deps
if errorlevel 1 goto fail
call :check_config
call :start_browser
call :start_backend
call :open_ui
if errorlevel 1 goto fail
goto done

:check_python
echo [1/6] Python check...
where python >nul 2>nul
if errorlevel 1 ( echo   [ERROR] Python not found in PATH. Install 3.10+ first. & exit /b 1 )
python -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul
if errorlevel 1 ( echo   [ERROR] Python 3.10+ required. & exit /b 1 )
echo   python OK >> "%LOG%"
exit /b 0

:check_venv
set "PY="
if exist "%~dp0venv\Scripts\python.exe" set "PY=%~dp0venv\Scripts\python.exe"
if not defined PY if exist "%~dp0..\venv\Scripts\python.exe" set "PY=%~dp0..\venv\Scripts\python.exe"
if defined PY ( echo [2/6] venv: %PY% & echo venv=%PY% >> "%LOG%" & exit /b 0 )
echo [2/6] Creating local venv ...
python -m venv "%~dp0venv"
set "PY=%~dp0venv\Scripts\python.exe"
if not exist "%PY%" ( echo   [ERROR] venv creation failed. & exit /b 1 )
echo venv=created >> "%LOG%"
exit /b 0

:check_deps
echo [3/6] Dependencies check...
"%PY%" -c "import fastapi, uvicorn, pydantic" >nul 2>nul
if not errorlevel 1 ( echo   deps OK & exit /b 0 )
echo   Installing requirements.txt ...
"%PY%" -m pip install -r "%~dp0requirements.txt" >> "%LOG%" 2>&1
if errorlevel 1 (
  echo   Retry with Tsinghua mirror ...
  "%PY%" -m pip install -r "%~dp0requirements.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple >> "%LOG%" 2>&1
)
"%PY%" -c "import fastapi, uvicorn, pydantic" >nul 2>nul
if errorlevel 1 ( echo   [ERROR] deps install failed, see logs\start.log & exit /b 1 )
exit /b 0

:check_config
echo [4/6] Config check...
if not exist "%~dp0.env" ( copy "%~dp0.env.example" "%~dp0.env" >nul 2>nul & echo   .env generated )
if not exist "%~dp0storage" mkdir "%~dp0storage" >nul 2>nul
exit /b 0

:start_browser
echo [5/6] AI browser (CDP :9222)...
netstat -ano | findstr ":9222" | findstr "LISTENING" >nul
if not errorlevel 1 ( echo   already running & exit /b 0 )
set "CHROME="
for %%P in ("C:\Program Files\Google\Chrome\Application\chrome.exe" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe") do if exist %%~P set "CHROME=%%~P"
if not defined CHROME for %%P in ("C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" "C:\Program Files\Microsoft\Edge\Application\msedge.exe") do if exist %%~P set "CHROME=%%~P"
if not defined CHROME ( echo   [WARN] Chrome/Edge not found. Explore mode unavailable. & exit /b 0 )
set "PROFILE=%~dp0storage\psv_chrome_profile"
if not exist "%PROFILE%" mkdir "%PROFILE%" >nul 2>nul
start "" "%CHROME%" --remote-debugging-port=9222 --user-data-dir="%PROFILE%" --no-first-run --no-default-browser-check
echo browser=%CHROME% >> "%LOG%"
exit /b 0

:start_backend
echo [6/6] Backend (:8000)...
powershell -WindowStyle Hidden -Command "cd '%~dp0'; & '%PY%' run_services.py" >> "%LOG%" 2>&1
exit /b 0

:open_ui
echo Waiting for :8000 ...
set /a TRY=0
:wait_loop
netstat -ano | findstr ":8000" | findstr "LISTENING" >nul
if not errorlevel 1 goto ui_ready
set /a TRY+=1
if !TRY! GEQ 45 ( echo   [ERROR] 45s timeout, see logs\start.log & exit /b 1 )
timeout /t 1 >nul
goto wait_loop
:ui_ready
start "" http://localhost:8000
echo.
echo ============================================
echo   READY: UI http://localhost:8000
echo   AI browser :9222   Backend :8000
echo ============================================
exit /b 0

:fail
echo.
echo [FAILED] See messages above; details in logs\start.log
pause
exit /b 1

:done
echo.
pause
exit /b 0
