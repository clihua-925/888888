"""L2 Domain Modeling：AI 领域专家生成 ProductKnowledgeModel。

V41：禁止写死 Industrial/Decorative/Automotive/Craft。AI 生成，规则校验非空与格式。
修复1：AI 输出结构轻微偏差时做**输入规范化**（非 fallback）——
容忍 children 的 3 种写法：对象数组 / 字符串数组 / 混合。
"""
from __future__ import annotations
import re
from contracts.task import TaskObject
from contracts.product import ProductKnowledgeModel, CategoryNode
from ai.ai_executor import AIExecutor


def _normalize_category(c):
    """容忍 AI 的 3 种 children 写法：
    - 对象数组 [{"name":"x","children":[]}]   → 标准，原样（递归规范化）
    - 字符串数组 ["x", "y"]                  → 展开为 [{"name":"x","children":[]}, ...]
    - 混合 / None / 其他类型                  → 过滤无效项
    """
    if isinstance(c, str):
        s = c.strip()
        return {"name": s, "children": []} if s else None
    if isinstance(c, dict):
        name = str(c.get("name") or "").strip()
        if not name:
            return None
        raw_children = c.get("children") or []
        if not isinstance(raw_children, list):
            raw_children = []
        children = [x for x in (_normalize_category(ch) for ch in raw_children) if x]
        return {"name": name, "children": children}
    return None  # 其他类型（None / 数字 / 列表）丢弃


_CJK = re.compile(r"[\u4e00-\u9fff]")


def _validate(d: dict) -> dict:
    # 修复3：product_name 强制英文（含 CJK 即拒绝重试）
    if _CJK.search(str(d.get("product_name") or "")):
        raise ValueError(f"L2 规则校验失败：product_name 必须为英文，当前为 {d.get('product_name')!r}")
    # 修复1：规范化 categories（容忍 children 字符串数组）
    raw_cats = d.get("categories") or []
    d["categories"] = [c for c in (_normalize_category(x) for x in raw_cats) if c]
    m = ProductKnowledgeModel(**{k: v for k, v in d.items()
                                 if k in ("product_name", "categories", "applications",
                                          "aliases", "hs_candidates")})
    cats = [c.name for c in m.categories if c.name.strip()]
    if not cats:
        raise ValueError("L2 规则校验失败：分类不能为空")
    return m.model_dump()


class DomainModelService:
    def __init__(self, executor: AIExecutor | None = None) -> None:
        self._ex = executor or AIExecutor()

    def build(self, task: TaskObject) -> ProductKnowledgeModel:
        ctx = {"task_object": task.model_dump()}
        data = self._ex.execute("L2_domain_modeling", ctx, validate=_validate)
        return ProductKnowledgeModel(**data)
