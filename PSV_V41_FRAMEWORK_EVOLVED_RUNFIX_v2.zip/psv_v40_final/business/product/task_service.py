"""L1 Task Understanding：AI 理解原始需求 -> TaskObject。

V41：禁止 if "毛毡" 字典。AI 生成，规则只校验 TaskObject 契约（pydantic）。
修复3：product 强制英文校验（含 CJK 即拒绝重试，督促 AI 输出英文标准名）。
"""
from __future__ import annotations
import re

from contracts.task import TaskObject
from ai.ai_executor import AIExecutor

_CJK = re.compile(r"[\u4e00-\u9fff]")


def _validate(d: dict) -> dict:
    t = TaskObject(**d)
    if _CJK.search(t.product):
        raise ValueError(f"L1 规则校验失败：product 必须为英文标准名，当前为 {t.product!r}")
    return t.model_dump()


class TaskService:
    def __init__(self, executor: AIExecutor | None = None) -> None:
        self._ex = executor or AIExecutor()

    def understand(self, user_input: str) -> TaskObject:
        if not (user_input or "").strip():
            raise ValueError("任务输入为空")
        data = self._ex.execute("L1_task_understanding", {"user_input": user_input},
                                validate=_validate)
        return TaskObject(**data)
