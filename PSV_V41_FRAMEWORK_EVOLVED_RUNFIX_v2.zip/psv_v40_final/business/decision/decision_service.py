"""L10 Decision Intelligence：AI 生成最终商业报告。

输入 = 各节点真实结果 JSON；规则校验六大必需段落齐全，缺段即失败重试。
"""
from __future__ import annotations
from ai.ai_executor import AIExecutor
from contracts.report import DecisionReport

_REQUIRED = ("product", "market", "top_suppliers", "top_buyers",
             "trade_relations", "evidence", "risks", "opportunities")


class DecisionService:
    def __init__(self, executor: AIExecutor | None = None) -> None:
        self._ex = executor or AIExecutor()

    def report(self, state: dict) -> dict:
        ctx = {}
        for k in ("task", "product_model", "fused_profiles", "graph_metrics", "task_id"):
            v = state.get(k)
            if v is None:
                continue
            ctx[k] = v.model_dump() if hasattr(v, "model_dump") else v

        def validate(d: dict) -> dict:
            missing = [k for k in _REQUIRED if k not in d]
            if missing:
                raise ValueError(f"L10 规则校验失败：缺少段落 {missing}")
            # 修复3：容忍字符串数组（AI 常见简化）→ 展开为对象数组
            def _norm_top(items, defaults: dict):
                if isinstance(items, str):   # 裸字符串 → 视为单项
                    items = [items] if items.strip() else []
                out = []
                for it in (items or []):
                    if isinstance(it, str) and it.strip():
                        o = {"name": it.strip()}; o.update(defaults); out.append(o)
                    elif isinstance(it, dict) and str(it.get("name") or "").strip():
                        it["name"] = str(it["name"]).strip()
                        for k, v in defaults.items():
                            it.setdefault(k, v)
                        out.append(it)
                return out
            d["top_suppliers"] = _norm_top(d.get("top_suppliers"), {"buyers": 0, "trade_count": 0})
            d["top_buyers"] = _norm_top(d.get("top_buyers"), {"supplier_sources": 0})
            r = DecisionReport(**d)  # C1：契约 model_validate；L10-4：pydantic 类型即非空约束
            return r.model_dump()

        return self._ex.execute("L10_decision", ctx, validate=validate)
