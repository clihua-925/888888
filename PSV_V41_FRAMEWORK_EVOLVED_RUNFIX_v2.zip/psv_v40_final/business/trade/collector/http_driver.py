"""HTTP 降级驱动：与 BrowserDriver 相同的步骤语义，但经 CollectorManager 策略链取静态页。

无浏览器/无 CDP 时使用，browser_session 标记 driver_type=http，表示非真实用户操作采集。
"""
from __future__ import annotations
import re
from urllib.parse import quote_plus, urljoin

from business.trade.collector.driver import BaseDriver, PageBundle
from business.trade.collector.page_snapshot import html_to_text
from business.shared import config

_TITLE_RE = re.compile(r"<title>([^<]+)", re.I)


class HttpDriver(BaseDriver):
    driver_type = "http"
    BASE = config.IY_BASE

    def __init__(self, fetch_fn, max_pages: int | None = None) -> None:
        self._fetch = fetch_fn
        self._max_pages = max_pages or config.MAX_SEARCH_PAGES

    def _bundle(self, html: str, url: str, page_type: str,
                keyword: str | None = None, page_number: int = 1) -> PageBundle:
        mt = _TITLE_RE.search(html or "")
        return PageBundle(html=html, url=url, page_type=page_type, keyword=keyword,
                          page_number=page_number, title=mt.group(1).strip() if mt else None)

    def homepage(self) -> PageBundle:
        html, final, _ = self._fetch(self.BASE + "/")
        return self._bundle(html, final, "homepage")

    def search(self, keyword: str, max_pages: int | None = None, advisor=None) -> list[PageBundle]:
        """降级模式：逐页请求 ?page=N（2/3 页内容重复时自然去重，由调用方判 hash）。"""
        import hashlib
        out = []
        seen: set[str] = set()
        for pno in range(1, (max_pages or config.MAX_SEARCH_PAGES) + 1):
            url = self.BASE + "/search?q=" + quote_plus(keyword)
            if pno > 1:
                url += f"&page={pno}"
            try:
                html, final, shot = self._fetch(url)
            except Exception:
                break
            h = hashlib.sha256(html.encode("utf-8", errors="replace")).hexdigest()[:16]
            if h in seen:
                break
            seen.add(h)
            out.append(self._bundle(html, final, "search_result", keyword, pno))
        return out

    def company_detail(self, slug: str) -> PageBundle | None:
        try:
            html, final, _ = self._fetch(urljoin(self.BASE, f"/company/{slug}"))
        except Exception:
            return None
        return self._bundle(html, final, "company_detail")

    def shipment_detail(self, url: str) -> PageBundle | None:
        try:
            html, final, _ = self._fetch(url)
        except Exception:
            return None
        return self._bundle(html, final, "shipment_detail")


def extract_company_slugs(html: str) -> list[str]:
    """IY 公司 slug 发现：HTML 任意 /company/{slug} + __NEXT_DATA__ JSON。"""
    import json
    slugs: list[str] = []
    seen: set[str] = set()

    def _add(s: str) -> None:
        s = (s or "").strip().strip("/")
        if s and s not in seen:
            seen.add(s)
            slugs.append(s)

    for m in re.finditer(r"/company/([a-z0-9][a-z0-9\-]{1,60})", html or ""):
        _add(m.group(1))
    m = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html or "", re.S)
    if m:
        try:
            data = json.loads(m.group(1))
        except json.JSONDecodeError:
            data = None
        if isinstance(data, dict):
            stack = [data]
            while stack:
                cur = stack.pop()
                if isinstance(cur, dict):
                    if isinstance(cur.get("slug"), str) and len(cur["slug"]) > 1:
                        _add(cur["slug"])
                    stack.extend(v for v in cur.values() if isinstance(v, (dict, list)))
                elif isinstance(cur, list):
                    stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return slugs[:20]


def find_shipment_link(html: str, base: str) -> str | None:
    """公司详情页中的贸易（shipment）入口链接。"""
    for m in re.finditer(r'href="([^"]*(?:shipment|bill-of-lading|bol)[^"]*)"', html or "", re.I):
        return urljoin(base, m.group(1))
    return None
