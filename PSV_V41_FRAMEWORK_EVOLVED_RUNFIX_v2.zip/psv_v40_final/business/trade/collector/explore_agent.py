"""ExploreAgent：AI 实时驱动的交互式采集（L4 explore 模式）。

分工原则（Skyvern/Browser-Use 验证过的配方）：
  AI 做决策（去哪、点哪个、够不够、何时停）；
  确定性代码做提取（search_parser 卡片解析 + supplier_page 提取器）；
  快照+截图留痕，不整页 HTML 入库。全程轨迹可追溯。
"""
from __future__ import annotations
import hashlib
from datetime import datetime, timezone

from ai.ai_executor import AIExecutor
from business.trade.collector.search_parser import parse_search_candidates
from business.trade.collector.supplier_page import parse_supplier_page, parse_buyer_list


class ExploreAgent:
    def __init__(self, driver, ai=None, max_steps: int = 40,
                 max_suppliers: int = 5, trace_saver=None):
        self._driver = driver
        self._ex = ai or AIExecutor()
        self._max_steps = max_steps
        self._max_suppliers = max_suppliers
        self._trace_saver = trace_saver
        self._page = None

    def run_from_search(self, search_url: str, keyword: str) -> dict:
        trace = {"keyword": keyword, "started_at": _now(), "status": "ok",
                 "steps": [], "suppliers": [], "buyers": []}
        self._page = self._driver.goto(search_url)
        for step in range(self._max_steps):
            info = self._driver.current_info(self._page)
            snap = self._driver.snapshot(self._page)
            cards = parse_search_candidates(snap, 0, keyword, 1)
            page_type = self._classify(info, snap)

            if page_type == "supplier":
                sup = parse_supplier_page(snap, info["url"])
                buyers = parse_buyer_list(snap, info["url"])
                if sup and not any(s["name"] == sup["name"] for s in trace["suppliers"]):
                    trace["suppliers"].append(sup)
                    for b in buyers:
                        if not any(x["name"] == b["name"] for x in trace["buyers"]):
                            trace["buyers"].append(b)
                    trace["steps"].append(self._step(step, info, "extract", None,
                                                     "supplier+buyers", sup, snap))
                    self._back(); continue

            if len(trace["suppliers"]) >= self._max_suppliers:
                trace["steps"].append(self._step(step, info, "done", None, "target reached", None, snap))
                break

            state = {"step": step, "url": info["url"], "page_type": page_type,
                     "keyword": keyword, "suppliers_found": len(trace["suppliers"]),
                     "suppliers_needed": self._max_suppliers,
                     "candidates": [{"name": c["company_name"], "url": c["company_url"],
                                     "shipments": c["shipment_count"]} for c in cards][:10],
                     "snapshot_head": snap[:1500]}
            action = self._ex.execute("L4_explore_decision", state)
            if not isinstance(action, dict):
                action = {"action": "done", "reason": f"AI 返回非 dict: {type(action).__name__}"}
            name, target = action.get("action", "done"), action.get("target")
            if name not in ("click", "back", "done"):
                name = "done"
            reason = action.get("reason", "")
            trace["steps"].append(self._step(step, info, name, target, reason, None, snap))
            if name == "click" and target:
                if not self._driver.click_text(target, page=self._page):
                    cand = next((c for c in cards if target.lower() in c["company_name"].lower()), None)
                    if cand and cand["company_url"]:
                        self._page = self._driver.goto(cand["company_url"], self._page)
            elif name == "back":
                self._back()
            elif name == "done":
                break
        else:
            trace["status"] = "limit_reached"
        trace["finished_at"] = _now()
        if self._trace_saver:
            self._trace_saver(trace)
        return trace

    def _back(self):
        try:
            self._page.go_back(wait_until="domcontentloaded", timeout=30_000)
            self._page.wait_for_timeout(1000)
        except Exception:
            pass

    @staticmethod
    def _classify(info, snap) -> str:
        u = info["url"]
        if "/search" in u:
            return "search"
        if "/supplier/" in u or "/company/" in u:
            low = (snap or "").lower()
            return "supplier" if ("top customers" in low or "us imports" in low) else "other"
        return "other"

    @staticmethod
    def _step(step, info, action, target, reason, extract, snap) -> dict:
        return {"step": step, "url": info["url"], "page_type": "", "action": action,
                "target": target, "ai_reason": reason, "extract": extract,
                "snapshot_hash": hashlib.sha1((snap or "").encode()).hexdigest()[:12]}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
