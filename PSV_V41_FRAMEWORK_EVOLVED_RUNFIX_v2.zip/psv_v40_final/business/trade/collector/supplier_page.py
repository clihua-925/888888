"""ImportYeti 供应商页提取：供应商信息 + 采购商名单。

复用搜索卡片解析的组件结构假设（ImportYeti 全站组件一致）：
客户表与搜索卡片同为 "名称链接 + Total Shipments" 组件。
待校准：拿到真实 /supplier/{slug} 页 HTML 后跑一遍验证，如有偏差
按 search_parser 同样的多级降级方式补正则。
"""
from __future__ import annotations
import re
from urllib.parse import urljoin
from business.shared import config

_LINK_RE = re.compile(r'<a[^>]+href="(/(?:company|supplier)/([a-z0-9][a-z0-9\-]{1,80}))"[^>]*>(.*?)</a>', re.S | re.I)
_TAG_RE = re.compile(r"<[^>]+>")
_SHIP_RE = re.compile(r'Total Shipments</div>\s*([\d,]+)')
_NAME_RE = re.compile(r'<h1[^>]*>(.*?)</h1>', re.S | re.I)


def _clean(t: str) -> str:
    return " ".join(_TAG_RE.sub(" ", t or "").split()).strip()


def parse_supplier_page(html: str, url: str) -> dict | None:
    m = _NAME_RE.search(html or "")
    name = _clean(m.group(1)) if m else ""
    if not name:
        m2 = _LINK_RE.search(html or "")
        name = _clean(m2.group(3)) if m2 else ""
    sm = _SHIP_RE.search(html or "")
    if not name:
        return None
    return {"name": name, "url": url, "shipments": int(sm.group(1).replace(",", "")) if sm else None,
            "entity_type": "supplier"}


def parse_buyer_list(html: str, supplier_url: str, limit: int = 10) -> list[dict]:
    buyers, seen = [], set()
    for m in _LINK_RE.finditer(html or ""):
        path, slug, raw = m.group(1), m.group(2), _clean(m.group(3))
        if slug in seen:
            continue
        seen.add(slug)
        seg = (html or "")[m.start(): m.end() + 400]
        sm = _SHIP_RE.search(seg)
        buyers.append({"name": raw or slug.replace("-", " ").title(),
                       "url": urljoin(config.IY_BASE, path),
                       "shipments": int(sm.group(1).replace(",", "")) if sm else None,
                       "entity_type": "buyer",
                       "evidence": f"出现在供应商页客户列表: {supplier_url}"})
        if len(buyers) >= limit:
            break
    return buyers
