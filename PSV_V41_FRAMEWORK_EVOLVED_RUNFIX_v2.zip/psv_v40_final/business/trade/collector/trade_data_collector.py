"""L4 采集调度（图节点入口）：按 sources/priority 分发，经 CollectorManager 策略链取数。"""
from __future__ import annotations
from contracts.search_plan import SearchPlan
from business.trade.collector.base import BaseCollector
from business.trade.collector.collector_manager import CollectorManager
from business.trade.collector.importyeti_collector import ImportYetiCollector
from data.repository.collector_repository import CollectorLogRepository


class TradeDataCollector:
    def __init__(self, collectors: list[BaseCollector] | None = None,
                 manager: CollectorManager | None = None,
                 raw_repo=None, max_pages_per_source: int = 3,
                 log_repo=None) -> None:
        if log_repo is None:
            conn = getattr(raw_repo, "_conn", None)
            log_repo = CollectorLogRepository(conn) if conn is not None else CollectorLogRepository()
        self._manager = manager or CollectorManager(log_repo=log_repo)
        self._collectors = collectors if collectors is not None else [
            ImportYetiCollector(fetch_fn=self._manager.fetch,
                                raw_repo=raw_repo, max_pages=max_pages_per_source),
        ]

    def collect(self, plan: SearchPlan) -> list[int]:
        if getattr(plan, "mode", "batch") == "explore":
            return self._collect_explore(plan)
        ids: list[int] = []
        order = {s: i for i, s in enumerate(plan.priority or [])}
        for c in sorted(self._collectors, key=lambda c: order.get(c.name, 99)):
            ids.extend(c.collect(plan))
        return ids

    def _collect_explore(self, plan: SearchPlan) -> list[int]:
        """explore 模式：AI 实时驱动浏览器，沿 搜索页 -> 供应商页 -> 采购商 路径采集，
        轨迹落 raw（page_type='explore_trace'），不整页 HTML 入库。"""
        import json as _json
        from business.trade.collector.browser_driver import BrowserDriver
        from business.trade.collector.explore_agent import ExploreAgent
        from data.repository.raw_repository import RawRepository
        from data.db import connect
        driver = BrowserDriver()
        conn = connect(); raw_repo = RawRepository(conn)
        page_ids: list[int] = []
        try:
            for kw in (plan.queries or [])[:3]:
                url = "https://www.importyeti.com/search?q=" + kw.replace(" ", "+")
                def _save(tr, _kw=kw, _url=url):
                    pid = raw_repo.create(source="importyeti_explore", url=_url,
                                          html_path=None,
                                          text=_json.dumps(tr, ensure_ascii=False),
                                          keyword=_kw, page_number=1,
                                          page_type="explore_trace")
                    page_ids.append(pid)
                agent = ExploreAgent(driver,
                                     max_suppliers=getattr(plan, "explore_max_suppliers", 5),
                                     trace_saver=_save)
                agent.run_from_search(url, kw)
        finally:
            driver.stop()
        return page_ids
