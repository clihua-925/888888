"""L4 Browser Agent：模拟真实用户操作采集 ImportYeti。

流程（严格按序）：
  启动检查 → 首页(homepage) → 按 L3 Search Plan 逐关键词：
    search_result 页（默认 3 页，按 content_hash 去重）
    → 解析结果列表 → candidate_companies 落库（company_name/url/country/shipment_count/source_page_id）
    → 动态选择 Top 10 候选（shipment_count 降序）→ 公司详情页(company_detail)
    → 贸易详情入口(shipment_detail)
铁律：禁止固定进入任何公司；禁止判断 Supplier/Buyer/Customer；只保存原始数据与公司候选。
"""
from __future__ import annotations
import time
from contracts.search_plan import SearchPlan
from business.trade.collector.base import BaseCollector, content_hash
from business.trade.collector.driver import BaseDriver, BrowserSession
from business.trade.collector.page_snapshot import html_to_text
from business.trade.collector.search_parser import parse_search_candidates
from business.trade.collector.http_driver import find_shipment_link
from business.shared.page_purifier import purify
from business.shared import config


class BrowserAgentCollector(BaseCollector):
    name = "importyeti"

    def __init__(self, driver: BaseDriver, candidate_repo=None,
                 max_detail_pages: int | None = None, advisor=None,
                 max_queries: int | None = None, **kw) -> None:
        super().__init__(**kw)
        self._driver = driver
        self._max_detail = max_detail_pages or config.MAX_DETAIL_PAGES
        self._max_queries = max_queries or config.MAX_QUERIES          # 查询条数上限（修复#5）
        self._advisor = advisor  # BrowserAIAdvisor（AI 控制翻页/停止），None 则规则默认
        if candidate_repo is None:
            from data.repository.candidate_repository import CandidateRepository
            candidate_repo = CandidateRepository(getattr(self._repo, "_conn", None))
        self._candidates = candidate_repo

    def collect(self, plan: SearchPlan) -> list[int]:
        ids: list[int] = []
        try:
            self._driver.start()
        except Exception:
            pass
        try:
            return self._collect_inner(plan, ids)
        finally:
            try:
                self._driver.stop()  # 只释放页面，不关共享浏览器
            except Exception:
                pass

    def _collect_inner(self, plan: SearchPlan, ids: list[int]) -> list[int]:
        session = BrowserSession(
            driver_type=getattr(self._driver, "driver_type", "unknown"),
            started_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
            login_status=getattr(self._driver, "login_status", "unknown"),
        )
        sess = session.as_text()

        try:
            home = self._driver.homepage()
            session.tick()
            rid = self._save(home, session, sess)
            if rid is not None:
                ids.append(rid)
        except Exception:
            pass

        for q in plan.queries[: self._max_queries]:
            try:
                pages = self._driver.search(q, max_pages=config.MAX_SEARCH_PAGES, advisor=self._advisor)
            except Exception:
                continue
            seen_hash: set[str] = set()
            for pg in pages:
                h = content_hash(pg.html)
                if h in seen_hash:   # 翻页无效/重复内容时停止（如末页重复）
                    continue
                seen_hash.add(h)
                session.tick()
                rid = self._save(pg, session, sess)
                if rid is None:  # Bug1修复：purify 拒页返回 None（L4-4 语义），<= 0 会 TypeError
                    continue
                ids.append(rid)
                cands = parse_search_candidates(pg.html, rid, q, pg.page_number)
                if not cands and pg.page_number >= 1:
                    break  # 修复4：本页解析不到公司 → 该 keyword 不再翻页（防空转 3 页）
                for c in cands:
                    self._candidates.create(
                        source_page_id=c["source_raw_page_id"], keyword=c["keyword"],
                        company_name=c["company_name"], company_url=c["company_url"],
                        country=c["country"], shipment_count=c["shipment_count"],
                        page_number=c["page_number"])
            # 动态选择 Top 10（按 shipment_count 降序），绝不固定公司
            for cand in self._candidates.top_for_keyword(q, limit=10):
                slug = (cand.get("company_url") or "").rstrip("/").split("/")[-1]
                if not slug:
                    continue
                cp = self._driver.company_detail(slug)
                if cp is None:
                    continue
                session.tick()
                cid = self._save(cp, session, sess)
                if cid is not None:
                    ids.append(cid)
                link = find_shipment_link(cp.html or "", config.IY_BASE)
                if link:
                    sp = self._driver.shipment_detail(link)
                    if sp is not None:
                        session.tick()
                        sid = self._save(sp, session, sess)
                        if sid is not None:
                            ids.append(sid)
        return ids

    def _save(self, pg, session: BrowserSession, sess_text: str) -> int | None:
        """返回 raw_id；被 purify 拒绝返回 None（调用方用 `is None` 判断）。
        写库失败必须抛 RawSaveError，禁止返回 None 表示失败——两者语义不同。"""
        text = html_to_text(pg.html)
        keep, _ = purify(pg.url, text)
        if not keep and pg.page_type != "homepage":
            return None  # L4-4：被净化规则过滤（区别于写库失败抛异常）
        raw_id = self._save_raw(pg.url, pg.html, text,
                                keyword=pg.keyword, page_number=pg.page_number,
                                page_type=pg.page_type, title=pg.title,
                                browser_session=sess_text,
                                screenshot=pg.screenshot)
        session.extra["last_page_type"] = pg.page_type
        return raw_id
