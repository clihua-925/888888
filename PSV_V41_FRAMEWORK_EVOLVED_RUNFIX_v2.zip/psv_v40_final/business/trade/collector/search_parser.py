"""ImportYeti 搜索结果页解析：五级备用机制提取公司候选（V41 修复版）。

L4 专用：只做"列表解析"，不做 Supplier/Buyer 判断。
  第一优先：__NEXT_DATA__ JSON（旧版站点）
  第二优先：RSC payload（self.__next_f.push，当前线上版本的真实数据来源）
  第三优先：DOM 结果卡片（当前结构：卡片内含名称/地址/Total Shipments/最近出货）
  第四优先：DOM 链接（仅名称+链接兜底）
  第五优先：文本正则（'Name | N shipments'）
任一级有产出即返回（上级优先）；结构变化时自动降级。

V41 修复：
  1) _DOM_LINK_RE 同时匹配 /company/ 与 /supplier/（原版本只认 /company/，
     而当前结果页 9/10 的详情链接是 /supplier/，导致 raw_2 只解析出 1 条、raw_3 解析出 0 条）；
  2) 名称做 HTML 实体解码（修复 "American Industrial Felt &amp; Supply I" 未解码为 & 的问题）；
  3) 新增 RSC payload 解析级（当前站点无 __NEXT_DATA__，数据在 __next_f.push 中）；
  4) 新增 DOM 卡片级解析，从卡片内提取 Total Shipments（修复 shipment_count 全为 None
     导致 top_for_keyword 排序失效的问题）。
"""
from __future__ import annotations
import html as _html
import json
import re
from urllib.parse import urljoin

from business.shared import config

_NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)
_RSC_RE = re.compile(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', re.S)
_DOM_LINK_RE = re.compile(
    r'<a[^>]+href="(/(?:company|supplier)/([a-z0-9][a-z0-9\-]{1,80}))"[^>]*>(.*?)</a>', re.S | re.I)
_CARD_SPLIT_RE = re.compile(r'<div class="mb-4">')
_CARD_RE = re.compile(
    r"([A-Z][A-Za-z0-9&.,'\-\s]{2,60}?)\s*[\|·\-–—]\s*(\d[\d,]{0,9})\s+shipments", re.I)
_TAG_RE = re.compile(r"<[^>]+>")
_SHIP_RE = re.compile(r'Total Shipments</div>\s*([\d,]+)')


def _clean(text: str) -> str:
    return " ".join(_TAG_RE.sub(" ", text or "").split()).strip(" -|·–—")


def _unescape(text: str) -> str:
    return _html.unescape(text or "")


def _unescape_rsc(s: str) -> str:
    """按 JS 字符串语义解码 RSC payload：先解双反斜杠，再解转义引号。
    顺序不能反：'\\\"' 必须解码为 '"' 而不是保留 '\\"'。"""
    return (s.replace("\\\\", "\\").replace('\\"', '"').replace("\\n", "\n")
             .replace("\\u0026", "&").replace("\\u003c", "<").replace("\\u003e", ">")
             .replace("\\/", "/"))


def parse_search_candidates(html: str, source_page_id: int, keyword: str | None,
                            page_number: int = 1) -> list[dict]:
    for parser in (_from_next_data, _from_rsc_payload, _from_dom_cards,
                   _from_dom_links, _from_text_cards):
        rows = parser(html or "")
        if rows:
            return [{"company_name": n, "company_url": u, "country": c,
                     "shipment_count": s, "source_raw_page_id": source_page_id,
                     "keyword": keyword, "page_number": page_number,
                     "parse_level": parser.__name__} for n, u, c, s in rows]
    return []


def _rows_from_html_blob(blob: str) -> list[tuple]:
    """从一段 HTML 中按结果卡片提取 (name, url, country, shipments)。"""
    out, seen = [], set()
    for card in _CARD_SPLIT_RE.split(blob or "")[1:]:
        m = _DOM_LINK_RE.search(card)
        if not m:
            continue
        path, slug, raw_name = m.group(1), m.group(2), m.group(3)
        if slug in seen:
            continue
        seen.add(slug)
        name = _unescape(_clean(raw_name))
        if len(name) < 3:
            name = slug.replace("-", " ").title()
        sm = _SHIP_RE.search(card)
        ships = int(sm.group(1).replace(",", "")) if sm else None
        out.append((name, urljoin(config.IY_BASE, path), None, ships))
    return out


def _from_next_data(html: str) -> list[tuple]:
    m = _NEXT_DATA_RE.search(html)
    if not m:
        return []
    try:
        data = json.loads(m.group(1))
    except json.JSONDecodeError:
        return []
    out: list[tuple] = []
    seen: set[str] = set()
    if isinstance(data, (dict, list)):
        stack = [data]
        while stack:
            cur = stack.pop()
            if isinstance(cur, dict):
                nm = (cur.get("name") or cur.get("company_name") or cur.get("title")
                      or cur.get("company") or cur.get("supplier"))
                ship = (cur.get("shipments") or cur.get("total_shipments")
                        or cur.get("shipment_count") or cur.get("count") or cur.get("total"))
                ship = ship if isinstance(ship, int) else (int(ship) if isinstance(ship, str) and ship.isdigit() else None)
                if isinstance(nm, str) and len(nm) > 2 and isinstance(ship, int) and ship > 0 \
                        and nm.lower() not in seen:
                    seen.add(nm.lower())
                    slug = cur.get("slug") if isinstance(cur.get("slug"), str) else None
                    out.append((nm, urljoin(config.IY_BASE, f"/company/{slug}") if slug else None,
                                cur.get("country") if isinstance(cur.get("country"), str) else None, ship))
                stack.extend(v for v in cur.values() if isinstance(v, (dict, list)))
            elif isinstance(cur, list):
                stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return out


def _from_rsc_payload(html: str) -> list[tuple]:
    """第二优先：RSC payload。push 字符串反转义后内含完整结果卡片 HTML。"""
    buf = [_unescape_rsc(m.group(1)) for m in _RSC_RE.finditer(html)]
    if not buf:
        return []
    return _rows_from_html_blob("\n".join(buf))


def _from_dom_cards(html: str) -> list[tuple]:
    """第三优先：当前线上 DOM 结果卡片（覆盖 /company/ 与 /supplier/ 链接）。"""
    return _rows_from_html_blob(html or "")


def _from_dom_links(html: str) -> list[tuple]:
    """第四优先：仅链接兜底（名称+URL，无 shipments）。"""
    out: list[tuple] = []
    seen: set[str] = set()
    for m in _DOM_LINK_RE.finditer(html or ""):
        slug, text = m.group(2), _unescape(_clean(m.group(3)))
        if not slug or slug in seen:
            continue
        seen.add(slug)
        name = text if len(text) >= 3 else slug.replace("-", " ").title()
        out.append((name, urljoin(config.IY_BASE, m.group(1)), None, None))
    return out


def _from_text_cards(html: str) -> list[tuple]:
    text = _clean(_unescape(html))
    out, seen = [], set()
    for m in _CARD_RE.finditer(text):
        name = m.group(1).strip()
        if len(name) >= 3 and name.lower() not in seen:
            seen.add(name.lower())
            out.append((name, None, None, int(m.group(2).replace(",", ""))))
    return out
