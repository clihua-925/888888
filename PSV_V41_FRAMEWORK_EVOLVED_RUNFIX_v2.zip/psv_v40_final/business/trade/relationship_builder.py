"""L7 Trade Relationship Construction：从 ImportYeti 提单/客户关系数据发现真实贸易关系。

职责：
  输入：L5 standard_company_data（供应商标准信息）+ L4 raw 中 IY 公司贸易页面
  流程：读取供应商 IY 页面 Customers/Shipment Records -> 提取客户候选
        -> 调用 L6 CustomerCompletionService（AI 验证/去重/画像，队列处理）
        -> 建立 Trade Shipment（supplier/customer/product/shipment_date/evidence/source_url/raw_page_id）
        -> 建立 Trade Edge：Supplier -[SUPPLIES]-> Customer（含 shipment_id/evidence/source_url/confidence）
  注意：供应商不做深度分析（不补全、不验证），保留 L5 标准化信息即可；
        供应商页面中的 Suppliers 区块不进入深度分析。
"""
from __future__ import annotations
import json
import re
import sqlite3
from data.db import connect
from data.repository.standard_company_repository import StandardCompanyRepository
from data.repository.raw_repository import RawRepository
from data.repository.entity_repository import EntityRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository
from business.trade.customer_service import CustomerCompletionService
from ai.ai_executor import AIExecutor
from business.trade.entity_resolver import normalize_key, name_similarity

_NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)
_CONSIGNEE_RE = re.compile(r"Consignee[^\n:]{0,20}:\s*([A-Z][A-Za-z0-9&.,'\-\s]{2,60})", re.I)


def _evidence_supported(evidence: str, source: str) -> bool:
    """证据允许空白差异，但必须能在原始页面文本中定位。"""
    norm = lambda s: re.sub(r"\s+", " ", str(s or "")).strip().lower()
    ev, src = norm(evidence), norm(source)
    return bool(ev and src and ev in src)


class RelationshipBuilder:
    def __init__(self, conn: sqlite3.Connection | None = None,
                 customer_service: CustomerCompletionService | None = None,
                 executor: AIExecutor | None = None) -> None:
        c = conn or connect()
        self._ex = executor or AIExecutor(conn=c)
        self._std = StandardCompanyRepository(c)
        self._raw = RawRepository(c)
        self._ent = EntityRepository(c)
        self._edge = EdgeRepository(c)
        self._ship = ShipmentRepository(c)
        self._customers = customer_service or CustomerCompletionService(conn=c)
        self.last_shipment_ids: list[int] = []

    def build(self, std_ids: list[int], raw_page_ids: list[int] | None = None,
              task_id: str | None = None) -> dict:
        """输入 L5 标准化数据 id 列表（+ 可选 raw 页）。返回 edge_ids/shipment_ids/customer_stats。
        前置检查：L4/L5 无真实公司时停止，不生成空关系。"""
        if not std_ids:
            return {"edge_ids": [], "shipment_ids": [], "entity_ids": [], "customer_stats": {},
                    "status": "skipped", "skipped": True,
                    "reason": "no_valid_supplier_candidates",
                    "skip_reason": "no_valid_supplier_candidates"}
        std_rows = self._std.list_by_ids(std_ids)
        # 有效供应商 = 有标准化记录且 company_detail_url 是 /company/ 链接（搜索页 URL 禁止进入 L7）
        valid = [r for r in std_rows
                 if (r.get("company_detail_url") or "").startswith("http")
                 and ("/company/" in (r.get("company_detail_url") or "")
                 or "/supplier/" in (r.get("company_detail_url") or ""))]
        if not valid:
            return {"edge_ids": [], "shipment_ids": [], "entity_ids": [], "customer_stats": {},
                    "status": "skipped", "skipped": True,
                    "reason": "no_valid_supplier_candidates",
                    "skip_reason": "no_valid_supplier_candidates"}
        std_rows = valid
        raw_pages = self._raw.list_by_ids(raw_page_ids or [])
        edge_ids: list[int] = []
        self.last_shipment_ids = []

        # 客户发现只计算一次。L7 只负责：发现客户 -> 写入 customer_queue -> 立即继续建关系，
        # 不等待 L6 AI 补全（异步 Worker 后台处理，L7 永不阻塞）。
        discovery = {id(row): self._discover_customers(row, raw_pages, task_id) for row in std_rows}
        queued = 0
        for row in std_rows:
            self._ensure_supplier(row)          # 供应商：仅 L5 标准化信息
            for cust_name, cust_country, _ev, _conf in discovery[id(row)]:
                self._customers.enqueue(cust_name, cust_country, row["raw_page_id"], task_id=task_id)
                queued += 1

        # 立即建 Shipment + SUPPLIES Edge（客户实体按候选名直接建立；AI 画像由 L6 异步补齐）
        involved: set[int] = set()
        for row in std_rows:
            supplier_id = self._ensure_supplier(row)
            involved.add(supplier_id)
            for cust_name, cust_country, evidence, conf in discovery[id(row)]:
                cust_ent = self._find_or_create_customer(cust_name, cust_country)
                involved.add(cust_ent)
                raw = self._raw.get(int(row["raw_page_id"])) or {}
                ship_id = self._ship.create_idempotent(
                    supplier_id=supplier_id, buyer_id=cust_ent,
                    product=row.get("product"), quantity=None,
                    ship_date=None, source_url=row.get("company_detail_url"),
                    evidence=evidence, confidence=conf,
                    raw_page_id=int(row["raw_page_id"]))
                self.last_shipment_ids.append(ship_id)
                edge_ids.append(self._edge.create_idempotent(
                    supplier_id, cust_ent, "SUPPLIES", evidence, conf,
                    source_url=row.get("company_detail_url"),
                    shipment_id=ship_id, raw_page_id=int(row["raw_page_id"])))
        return {"edge_ids": edge_ids, "shipment_ids": self.last_shipment_ids,
                "entity_ids": sorted(involved),
                "customer_queued": queued, "customer_stats": {"queued": queued},
                "status": "ok"}

    # ---- 供应商：仅用 L5 标准化信息建立/复用实体，不做补全 ----
    def _ensure_supplier(self, row: dict) -> int:
        found = self._ent.find_by_name("Company", row["company_name"])
        if found:
            return int(found["id"])
        return self._ent.create("Company", row["company_name"], aliases=[],
                                country=row.get("country"))

    # ---- 从 IY 公司贸易页提取客户候选（Customers / Shipment Records） ----
    def _discover_customers(self, row: dict, raw_pages: list[dict], task_id: str | None = None):
        """AI 主执行：读供应商 IY 页面文本，识别客户/收货人。规则：必须有 evidence。"""
        pages = []
        key = normalize_key(row["company_name"])
        for page in raw_pages:
            if page.get("page_type") not in ("company_detail", "shipment_detail"):
                continue
            title = (page.get("title") or "").lower()
            url = (page.get("url") or "").lower()
            text = page.get("text") or ""
            if page.get("html_path"):
                try:
                    with open(page["html_path"], encoding="utf-8", errors="replace") as f:
                        text = text + "\n" + f.read()[:12000]
                except OSError:
                    pass
            if key in normalize_key(title) or key in normalize_key(url) \
               or key in normalize_key(text[:400]):
                pages.append({"url": page.get("url"), "text": text[:6000]})
        if not pages:
            return []

        def validate(d: dict) -> list[tuple]:
            out = []
            for c in (d.get("customers") or []):
                name = " ".join(str(c.get("customer_name") or "").split()).strip(" -|·–—")
                ev = str(c.get("evidence") or "").strip()
                if len(name) < 3 or not ev or not any(_evidence_supported(ev, p["text"]) for p in pages):
                    continue  # 规则：无证据不生成客户关系
                out.append((name, c.get("country") if isinstance(c.get("country"), str) else None,
                            ev[:500], 0.7))
            return out

        found: list[tuple] = []
        for pg in pages:
            found.extend(self._ex.execute(
                "L7_trade_discovery",
                {"supplier": row["company_name"], "page_url": pg["url"],
                 "page_text": pg["text"], "task_id": task_id},
                validate=validate))
        dedup: dict[str, tuple] = {}
        for name, country, ev, conf in found:
            dedup.setdefault(name.lower(), (name, country, ev, conf))
        return list(dedup.values())

    def _find_or_create_customer(self, name: str, country: str | None) -> int:
        key = normalize_key(name)
        best_id, best = None, 0.0
        for e in self._ent.list_all():
            if e["entity_type"] != "Company":
                continue
            names = [e["canonical_name"], *e["aliases"]]
            if any(normalize_key(n) == key for n in names):
                return int(e["id"])  # L7-5：精确命中
            for n in names:
                sc = name_similarity(name, n)
                if sc > best:
                    best, best_id = sc, int(e["id"])
        if best_id is not None and best >= 0.9:
            self._ent.add_alias(best_id, name)  # 相似度合并，避免 ABC Import LLC / ABC Imports 双实体
            return best_id
        return self._ent.create("Company", name, aliases=[], country=country)

    def _find_customer_entity(self, name: str) -> int | None:
        key = normalize_key(name)
        for e in self._ent.list_all():
            if e["entity_type"] != "Company":
                continue
            if any(normalize_key(n) == key for n in [e["canonical_name"], *e["aliases"]]):
                return int(e["id"])
        return None


def _read(path: str) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""
