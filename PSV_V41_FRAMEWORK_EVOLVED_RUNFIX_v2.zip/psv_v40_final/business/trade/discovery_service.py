"""L3 Discovery Planning：AI 市场研究专家生成 SearchPlan。

V41：禁止 产品+supplier 模板拼接。规则：关键词非空/英文/长度上限/数据源白名单。
修复2：validate 强制校验——含 CJK 字符即拒绝重试；sources 强制锁定 importyeti（不信 AI）。
"""
from __future__ import annotations
import re

from contracts.task import TaskObject
from contracts.product import ProductKnowledgeModel
from contracts.search_plan import SearchPlan, SearchDirection
from ai.ai_executor import AIExecutor

MAX_QUERIES = 30
_CJK = re.compile(r"[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]")


def _validate(d: dict) -> dict:
    queries = [q.strip() for q in (d.get("queries") or []) if q and q.strip()]
    if not queries:
        raise ValueError("L3 规则校验失败：关键词不能为空")
    # 强制英文校验（含 CJK 字符即拒绝）
    bad = [q for q in queries if _CJK.search(q)]
    if bad:
        raise ValueError(f"L3 规则校验失败：关键词必须为英文，检出中文 {bad[:3]}")
    # 关键词长度校验
    long_ = [q for q in queries if len(q.split()) > 5]
    if long_:
        raise ValueError(f"L3 规则校验失败：关键词过长（>5 词）{long_[:3]}")
    # 数据源白名单（强制锁定 importyeti）
    return {"queries": queries[:MAX_QUERIES],
            "sources": ["importyeti"],       # 强制，不信 AI
            "priority_countries": d.get("priority_countries") or [],
            "priority_company_types": d.get("priority_company_types") or []}


class DiscoveryService:
    def __init__(self, executor: AIExecutor | None = None) -> None:
        self._ex = executor or AIExecutor()

    def plan(self, task: TaskObject, model: ProductKnowledgeModel) -> SearchPlan:
        ctx = {"task_object": task.model_dump(),
               "product_model": model.model_dump()}
        d = self._ex.execute("L3_discovery_planning", ctx, validate=_validate)
        return SearchPlan(
            queries=d["queries"],
            sources=d["sources"],
            directions=[SearchDirection.SUPPLIER_SIDE, SearchDirection.BUYER_SIDE,
                        SearchDirection.TRADE_EVIDENCE, SearchDirection.COMPANY_IDENTITY],
            priority=d["sources"],
        )
