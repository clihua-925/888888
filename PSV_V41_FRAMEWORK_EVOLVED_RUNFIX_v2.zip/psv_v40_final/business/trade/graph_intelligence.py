"""L9 Graph Intelligence：AI 基于真实图谱统计做分析。

统计（实体/边/国家分布/shipment 数）由规则从 DB 计算；AI 只产出解读
（核心供应商/买家/市场结构/机会/风险），禁止虚构数字（validate 强制非空）。
"""
from __future__ import annotations
import sqlite3
from collections import Counter
from data.db import connect
from data.repository.entity_repository import EntityRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository
from ai.ai_executor import AIExecutor


class GraphIntelligence:
    def __init__(self, conn: sqlite3.Connection | None = None,
                 executor: AIExecutor | None = None) -> None:
        c = conn or connect()
        self._ent = EntityRepository(c)
        self._edge = EdgeRepository(c)
        self._ship = ShipmentRepository(c)
        self._ex = executor or AIExecutor(conn=c)

    def analyze(self, edge_ids: list[int] | None = None,
                shipment_ids: list[int] | None = None,
                entity_ids: list[int] | None = None,
                task_id: str | None = None) -> dict:
        if not edge_ids:
            return {"status": "skipped", "reason": "no_edges_from_L7"}  # N1: 空列表即短路
        keep_edges = set(edge_ids)
        edges = [e for e in self._edge.list_all() if int(e["id"]) in keep_edges]
        # 任务边是唯一范围来源；显式 shipment_ids 可处理没有完整 edge 的旧数据。
        keep_shipments = set(shipment_ids or [e["shipment_id"] for e in edges if e.get("shipment_id")])
        ships = [s for s in self._ship.list_by_ids(sorted(keep_shipments))]
        keep_entities = set(entity_ids or [])
        for e in edges:
            keep_entities.update((int(e["source_id"]), int(e["target_id"])))
        for s in ships:
            keep_entities.update((int(s["supplier_id"]), int(s["buyer_id"])))
        entities = [e for e in self._ent.list_all() if int(e["id"]) in keep_entities]
        id2name = {int(e["id"]): e["canonical_name"] for e in entities}
        name = lambda i: id2name.get(int(i), str(i))
        # L9-3：L7 不建 LOCATED_IN 边，国家分布直接从本任务实体聚合
        country_dist = Counter(e["country"] for e in entities
                               if e["entity_type"] == "Company" and e.get("country"))
        stats = {
            "task_id": task_id,
            "entity_count": len(entities),
            "edge_count": len(edges),
            "shipment_count": len(ships),
            "companies": [e["canonical_name"] for e in entities if e["entity_type"] == "Company"][:50],
            "country_distribution": dict(country_dist.most_common()),
            "supply_pairs": [{"supplier": name(s["supplier_id"]), "buyer": name(s["buyer_id"])}
                             for s in ships[:100]],
        }

        def validate(d: dict) -> dict:
            # 修复3：容忍字符串数组（AI 常见简化）→ 展开为对象数组
            def _norm_names(items):
                if isinstance(items, str):   # 裸字符串 → 视为单项
                    items = [items] if items.strip() else []
                out = []
                for it in (items or []):
                    if isinstance(it, str) and it.strip():
                        out.append({"name": it.strip(), "reason": ""})
                    elif isinstance(it, dict) and str(it.get("name") or "").strip():
                        it["name"] = str(it["name"]).strip()
                        it.setdefault("reason", "")
                        out.append(it)
                return out
            d["core_suppliers"] = _norm_names(d.get("core_suppliers"))
            d["core_buyers"] = _norm_names(d.get("core_buyers"))
            if not isinstance(d.get("core_suppliers"), list):
                raise ValueError("L9 规则校验失败：core_suppliers 必须存在")
            return d

        # Bug3 方案A：输入统计一并返回，保证 _stage_detail 的 edge_count/shipment_count 有值
        # 修复2：stats 放后（优先级高），AI 输出无法覆盖真实统计
        out = self._ex.execute("L9_intelligence", stats, validate=validate)
        return {**out, **stats}
