"""L5 数据标准化：AI 将 raw 页归一为标准公司数据（V41 修复版）。

V41 修复：
  1) 原第 94 行引用未定义的 _read()，每页必抛 NameError 并被外层 except 静默吞掉
     （status=partial、零产出、无告警）——本版补齐 _read()；
  2) company_url 校验同时接受 /company/ 与 /supplier/（原版本只认 /company/，
     与实际结果页 9/10 为 /supplier/ 链接冲突，导致详情 URL 大量丢失）；
     相对路径用 config.IY_BASE 补全（原 urljoin 已导入却从未使用）；
  3) shipment_count 支持 "43,954" 这类带逗号字符串，统一清洗为 int 后再入库；
  4) 上下文改用结构化 result_cards（与 L4 同一解析器），不再把整页噪音文本
     和页尾 "Sample Response"(Walmart 示例) 交给 AI，杜绝样板数据污染；
  5) extract_embedded_json 增加 RSC payload 分支（当前站点无 __NEXT_DATA__）。
"""
from __future__ import annotations
import datetime
import html as _html
import json
import re
import sqlite3
from urllib.parse import urljoin, urlparse, urlunparse, parse_qs, parse_qsl, urlencode, unquote

from contracts.search_plan import SearchPlan
from data.db import connect
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from ai.ai_executor import AIExecutor
from business.shared import config

MODEL_VERSION = "std-1"
_NEXT_RE = re.compile(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.S)
_RSC_RE = re.compile(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', re.S)


def _evidence_supported(evidence: str, source: str) -> bool:
    norm = lambda s: re.sub(r"\s+", " ", str(s or "")).strip().lower()
    ev, src = norm(evidence), norm(source)
    return bool(ev and src and ev in src)


def _card_evidence(page: dict, company_name: str, company_url: str | None = None) -> str:
    """Return a verbatim fragment from the captured page for a parsed card."""
    raw = (page.get("text") or "") + "\n" + _read(page.get("html_path"))
    if not raw:
        return ""
    variants = [str(company_name or "").strip()]
    if variants[0]:
        variants.extend([_html.escape(variants[0]), _html.unescape(variants[0])])
    for value in variants:
        if not value:
            continue
        pos = raw.lower().find(value.lower())
        if pos >= 0:
            return raw[pos:pos + len(value)]
    if company_url:
        for value in (company_url, urlparse(company_url).path):
            if value:
                pos = raw.lower().find(value.lower())
                if pos >= 0:
                    return raw[pos:pos + len(value)]
    return ""


def _canonicalize_url(raw: str | None) -> str | None:
    """V42: raw_url -> 解代理内层 url -> 提取 importyeti 原始地址 -> 规范化。
    顺序必须是 canonicalize 先于 filter（代理/重写 URL 不得被直接跳过）。"""
    if not raw:
        return None
    u = raw.strip()
    try:
        parsed = urlparse(u)
        qs = parse_qs(parsed.query)
        for key in ("url", "target", "dest", "u", "redirect"):
            if qs.get(key):
                inner = unquote(qs[key][0])
                if inner.startswith("http"):
                    r = _canonicalize_url(inner)
                    if r:
                        return r
    except Exception:
        pass
    m = re.search(r"https?://(?:www\.)?importyeti\.com/[^\s#]+", u)
    if m:
        u = m.group(0)
    try:
        p = urlparse(u)
        if not p.netloc:
            return None
        host = p.netloc.lower().replace("www.", "")
        path = re.sub(r"/+", "/", p.path)
        query = urlencode(sorted(parse_qsl(p.query, keep_blank_values=True)))
        return urlunparse(("https", host, path, "", query, ""))
    except Exception:
        return None


def _read(path: str | None) -> str:
    """V41 修复：原代码引用了不存在的 _read，导致每页 NameError 静默失败。"""
    if not path:
        return ""
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def extract_embedded_json(html: str):
    """提取页内嵌数据：先 __NEXT_DATA__（旧版），再 RSC payload（当前线上版本）。"""
    m = _NEXT_RE.search(html or "")
    if m:
        try:
            data = json.loads(m.group(1))
            if isinstance(data, (dict, list)):
                return data
        except json.JSONDecodeError:
            pass
    buf = []
    for rm in _RSC_RE.finditer(html or ""):
        s = (rm.group(1).replace("\\\\", "\\").replace('\\"', '"').replace("\\n", "\n")
             .replace("\\u0026", "&").replace("\\/", "/"))
        buf.append(s)
    if not buf:
        return None
    blob = "\n".join(buf)
    try:
        data = json.loads(blob)
        return data if isinstance(data, (dict, list)) else None
    except json.JSONDecodeError:
        return {"__rsc_text__": blob}


def _to_int(v) -> int | None:
    """'43,954' / 43954 / '43954' -> 43954；其余 -> None。bool 显式拒绝（True==1 会泄漏为票数）。"""
    if isinstance(v, bool):
        return None
    if isinstance(v, int) and v >= 0:
        return v
    if isinstance(v, float) and v >= 0:
        return int(v)
    if isinstance(v, str) and v.replace(",", "").isdigit():
        return int(v.replace(",", ""))
    return None


def validate(data):
    if not isinstance(data, dict) or "companies" not in data:
        return []
    out = []
    for item in data.get("companies") or []:
        if not isinstance(item, dict):
            continue
        name = (item.get("company_name") or "").strip()
        ev = (item.get("evidence") or "").strip()
        if not name or not ev:
            continue
        detail = item.get("company_url")
        if not isinstance(detail, str) or detail.strip().lower() == "null":
            detail = None
        else:
            if detail.startswith("/"):
                detail = urljoin(config.IY_BASE, detail)
            parsed = urlparse(detail)
            if parsed.netloc.lower().replace("www.", "") != "importyeti.com":
                detail = None
            elif "/company/" not in parsed.path and "/supplier/" not in parsed.path:
                detail = None
        out.append({
            "company_name": name,
            "country": item.get("country") if isinstance(item.get("country"), str) else None,
            "product": item.get("product") if isinstance(item.get("product"), str) else None,
            "shipment_count": _to_int(item.get("shipment_count")),
            "company_url": detail,
            "evidence": ev[:200],
            "page_id": _to_int(item.get("page_id")),
            "page_index": _to_int(item.get("page_index")),
            "entity_type": item.get("entity_type") if item.get("entity_type") in ("supplier", "buyer") else "supplier",
        })
    return out


class TradeStandardizer:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()
        self._raw = RawRepository(self._conn)
        self._std = StandardCompanyRepository(self._conn)
        self._ex = AIExecutor()

    BATCH_SIZE = 10   # 每批 AI 调用合并的搜索页数

    def standardize(self, raw_page_ids: list[int], task_id: str | None = None) -> list[int]:
        """V42: canonicalize 先行 -> 软过滤(记 skip_reason) -> 分批 -> 逐条隔离
        -> 部分成功可返回，0 产出显式失败。完整指标存 self.last_run_metrics。"""
        from business.trade.collector.search_parser import parse_search_candidates
        output: list[int] = []
        errs: list[dict] = []
        metrics: dict = {"input_ids": len(raw_page_ids), "skipped": {}, "skip_reasons": {},
                         "kept_search_pages": 0, "batch_count": 0,
                         "item_failures": 0, "invalid_page_refs": 0, "output_count": 0}

        # ---- 1. 取页 + canonicalize + 软过滤（不硬丢，只记录原因） ----
        seen: set[str] = set()
        pages: list[dict] = []
        for pid in raw_page_ids:
            page = self._raw.get(pid)
            if not page:
                metrics["skip_reasons"]["missing"] = metrics["skip_reasons"].get("missing", 0) + 1
                continue
            canon = _canonicalize_url(page.get("url"))
            if not canon:
                metrics["skip_reasons"]["empty_url"] = metrics["skip_reasons"].get("empty_url", 0) + 1
                continue
            if "importyeti.com" not in canon:
                metrics["skip_reasons"]["non_importyeti"] = metrics["skip_reasons"].get("non_importyeti", 0) + 1
                continue
            if canon in seen:
                metrics["skip_reasons"]["duplicate"] = metrics["skip_reasons"].get("duplicate", 0) + 1
                continue
            seen.add(canon)
            page["_canon"] = canon
            pages.append(page)
        metrics["kept_pages"] = len(pages)
        # L5 职责是搜索候选标准化；详情页记录为跳过原因而非静默消失
        search_pages = [p for p in pages if "/search" in p["_canon"]]
        n_detail = len(pages) - len(search_pages)
        if n_detail:
            metrics["skip_reasons"]["detail_page_not_l5_scope"] = n_detail
        metrics["kept_search_pages"] = len(search_pages)

        # ---- 2. 分批 + 逐条隔离 ----
        page_by_id = {p["id"]: p for p in search_pages}
        for bi in range(0, len(search_pages), self.BATCH_SIZE):
            batch = search_pages[bi:bi + self.BATCH_SIZE]
            metrics["batch_count"] += 1
            try:
                batch_cards = []
                for page in batch:
                    html = _read(page.get("html_path"))
                    text = page.get("text") or ""
                    cards = parse_search_candidates(html or text, page["id"], page.get("keyword"),
                                                    page.get("page_number") or 1)
                    for c in cards:
                        # V42: 引用用真实 page id，杜绝 0/1-based 索引歧义
                        evidence = _card_evidence(page, c["company_name"], c.get("company_url"))
                        batch_cards.append({"name": c["company_name"], "url": c["company_url"],
                                            "shipments": c["shipment_count"], "page_id": page["id"],
                                            "evidence": evidence})
                if not batch_cards:
                    continue
                ctx = {
                    "task_id": task_id,
                    "batch": [{"page_id": p["id"], "url": p["_canon"], "keyword": p.get("keyword")}
                              for p in batch],
                    "result_cards": batch_cards[:200],
                }
                ships = self._ex.execute("L5_standardization", ctx, validate=validate)
                if not isinstance(ships, list):
                    raise ValueError("L5_standardization 未返回列表")
            except Exception as e:  # 批级失败：记 errs，继续下一批
                errs.append({"code": type(e).__name__, "batch": bi // self.BATCH_SIZE,
                             "message": str(e)[:200], "recoverable": True})
                continue
            # 条级隔离：单条坏数据只丢该条；证据必须能回到原始页。
            batch_output = 0
            for item_idx, ship in enumerate(ships):
                try:
                    ref = ship.get("page_id")
                    page = page_by_id.get(ref) if isinstance(ref, int) else None
                    if page is None and len(batch) == 1:
                        page = batch[0]   # 兼容：单页批容忍模型省略 page_id
                    if page is None:
                        metrics["invalid_page_refs"] += 1
                        errs.append({"code": "InvalidPageRef", "batch": bi // self.BATCH_SIZE,
                                     "item_idx": item_idx, "raw_ref": ref, "recoverable": True})
                        continue
                    raw_text = page.get("text") or ""
                    html_text = _read(page.get("html_path"))
                    if not _evidence_supported(ship.get("evidence", ""), raw_text + "\n" + html_text):
                        errs.append({"code": "EvidenceNotFound", "batch": bi // self.BATCH_SIZE,
                                     "item_idx": item_idx, "raw_ref": ref, "recoverable": True})
                        continue
                    sid = self._std.create(
                        raw_page_id=page["id"],
                        company_name=ship["company_name"],
                        original_text=ship.get("evidence", ""),
                        country=ship.get("country"),
                        product=ship.get("product"),
                        shipment_count=ship.get("shipment_count"),
                        source_url=page["_canon"],
                        company_detail_url=ship.get("company_url"),
                        model_version=MODEL_VERSION,
                        entity_type=ship.get("entity_type") or "supplier",
                    )
                    output.append(sid)
                    batch_output += 1
                except Exception as e:  # noqa: BLE001
                    metrics["item_failures"] += 1
                    errs.append({"code": type(e).__name__, "batch": bi // self.BATCH_SIZE,
                                 "item_idx": item_idx, "message": str(e)[:200], "recoverable": True})

            # L4 已经从原始页面确定性解析出这些卡片。模型返回空数组、
            # 省略 page_id 或证据校验全部失败时，保留这些已验证卡片，
            # 避免一次模型格式问题把整条任务判为失败。
            if batch_output == 0:
                seen_fallback: set[tuple[int, str, str | None]] = set()
                for card in batch_cards:
                    page = page_by_id.get(card.get("page_id"))
                    name = str(card.get("name") or "").strip()
                    url = card.get("url")
                    evidence = card.get("evidence") or (_card_evidence(page or {}, name, url) if page else "")
                    if page is None or not name or not evidence:
                        continue
                    key = (int(page["id"]), name.casefold(), url)
                    if key in seen_fallback:
                        continue
                    seen_fallback.add(key)
                    try:
                        sid = self._std.create(
                            raw_page_id=page["id"], company_name=name,
                            original_text=evidence, country=None,
                            product=page.get("keyword"),
                            shipment_count=_to_int(card.get("shipments")),
                            source_url=page["_canon"], company_detail_url=url,
                            model_version=MODEL_VERSION + "+deterministic",
                            entity_type="supplier")
                        output.append(sid)
                    except Exception as e:  # noqa: BLE001
                        metrics["item_failures"] += 1
                        errs.append({"code": type(e).__name__, "batch": bi // self.BATCH_SIZE,
                                     "item_idx": "fallback", "message": str(e)[:200],
                                     "recoverable": True})

        # ---- 3. 结果契约 ----
        metrics["output_count"] = len(output)
        metrics["item_errors"] = errs[:100]
        self.last_page_errors = errs
        self.last_run_metrics = metrics
        if metrics["kept_search_pages"] > 0 and not output:
            raise RuntimeError(
                f"L5 zero output from non-empty input: {json.dumps(metrics, ensure_ascii=False)[:500]}")
        return output

    def standardize_legacy(self, raw_page_ids: list[int]) -> list[int]:
        """原逐页版，保留备查/回滚。"""
        from business.trade.collector.search_parser import parse_search_candidates
        output: list[int] = []
        errs: list[dict] = []
        for pid in raw_page_ids:
            page = self._raw.get(pid)
            if not page:
                continue
            try:
                html = _read(page.get("html_path"))          # 修复点1：_read 已定义
                text = page.get("text") or ""
                keyword = page.get("keyword")
                page_number = page.get("page_number") or 1
                # 修复点4：结构化卡片作为主输入，避免整页噪音 + 页尾 Walmart 样板污染
                cards = parse_search_candidates(html or text, pid, keyword, page_number)
                ctx = {
                    "source_url": page["url"],
                    "keyword": keyword,
                    "page_number": page_number,
                    "embedded_json": extract_embedded_json(html),
                    "result_cards": [
                        {"name": c["company_name"], "url": c["company_url"],
                         "shipments": c["shipment_count"], "entity_type": "supplier"} for c in cards[:20]
                    ],
                    "page_text_head": text[:800],
                }
                ships = self._ex.execute("L5_standardization", ctx, validate=validate)
                if not isinstance(ships, list):
                    raise ValueError("L5_standardization 未返回列表")
                ids = []
                for ship in ships:
                    sid = self._std.create(
                        raw_page_id=pid,
                        company_name=ship["company_name"],
                        original_text=ship.get("evidence", ""),
                        country=ship.get("country"),
                        product=ship.get("product"),
                        shipment_count=ship.get("shipment_count"),
                        source_url=page["url"],
                        company_detail_url=ship.get("company_url"),
                        model_version=MODEL_VERSION,
                        entity_type=ship.get("entity_type") or "supplier",
                    )
                    ids.append(sid)
                output.extend(ids)
            except Exception as e:  # noqa: BLE001
                errs.append({"raw_page_id": pid, "error": str(e)})
        self.last_page_errors = errs
        return output
