"""兼容层：DeepSeekWebClient 即 DeepSeekWebAgent（单一实现，禁止复制）。

旧代码/测试的 import 入口；新代码请直接用 ai.deepseek_web_agent。
"""
from ai.deepseek_web_agent import (  # noqa: F401
    DeepSeekWebAgent as DeepSeekWebClient,
    AIExecutionError as DeepSeekWebError,
    parse_loose_json,
)
