"""V41 链路 wiring 验证：注入 FakeAI 跑通 9 节点（审核方要求的工程验证）。

断言（非 tautology）：
  1. fused_profiles 的 keys ⊆ L7 输出的 entity_ids（防"多处理"，给出越界 id）
  2. fused_profiles 的 keys == L7 输出的 entity_ids 且数量正确（防"漏处理"）
  3. 脏库隔离：预塞 10 个无关 Company + 1 条无关 Shipment，
     fused_profiles 的 keys/buyers/suppliers/shipments 统计全部不混入历史数据
  4. L7 正常路径：entity_ids 含 supplier + customer；L9 空 edges 短路
数据流：seed 经 Fake collector 从 L4 进入，std_ids 由 L5 节点产出，不手写 state。
"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from data.repository.entity_repository import EntityRepository
from data.repository.shipment_repository import ShipmentRepository
from business.trade.relationship_builder import RelationshipBuilder
from business.trade.fusion_service import FusionService
from business.trade.graph_intelligence import GraphIntelligence
from orchestration.graph import _NODES, PIPELINE_ORDER

AI_REPLIES = {
    "L1_task_understanding": {"product": "Felt", "target_market": "美国",
                              "target_country": None,
                              "company_types": ["manufacturer", "importer"],
                              "analysis_goal": "供应链结构分析"},
    "L2_domain_modeling": {"product_name": "Felt",
                           "categories": [{"name": "Industrial Felt", "children": []}],
                           "applications": ["filtration"], "aliases": ["wool felt"],
                           "hs_candidates": ["5602"]},
    "L3_discovery_planning": {"queries": ["Industrial Felt supplier"], "sources": ["importyeti"]},
    "L5_standardization": {"companies": [{"company_name": "Shinwon Felt",
                                          "country": "Korea", "shipment_count": 180,
                                          "company_url": "https://www.importyeti.com/company/shinwon-felt",
                                          "evidence": "180 shipments"}]},
    "L7_trade_discovery": {"customers": [{"customer_name": "ABC Import LLC",
                                          "country": "USA", "evidence": "consignee ABC on record",
                                          "shipment_hint": "120"}]},
    "L8_fusion": {"merge_plan": [], "confirmed_edges": [], "notes": ""},
    "L9_intelligence": {"core_suppliers": [{"name": "Shinwon Felt", "reason": "r"}],
                        "core_buyers": [], "market_structure": "", "relationship_strengths": [],
                        "opportunities": [], "risks": []},
    "L10_decision": {"product": "Felt", "market": "美国",
                     "product_analysis": {"categories": [], "applications": [], "hs_candidates": []},
                     "top_suppliers": [], "top_buyers": [],
                     "trade_relations": {"shipment_count": 0, "edge_count": 0, "country_distribution": {}},
                     "evidence": {"total_evidence": 0, "source_urls": []},
                     "opportunities": [], "risks": [], "recommendations": []},
}

class _FakeAI:
    def execute(self, node, context, validate=None):
        d = AI_REPLIES[node]
        return validate(d) if validate else d


_WIRED = []
def _wire():
    import business.trade.relationship_builder as rb
    import business.trade.fusion_service as fs
    import business.trade.graph_intelligence as gi
    import business.product.task_service as ts
    import business.product.domain_model_service as dm
    import business.trade.discovery_service as ds
    import business.decision.decision_service as dc
    import business.trade.customer_service as cs
    import business.trade.standardizer as st
    pairs = [(rb.RelationshipBuilder, rb.RelationshipBuilder.__init__),
             (fs.FusionService, fs.FusionService.__init__),
             (gi.GraphIntelligence, gi.GraphIntelligence.__init__),
             (ts.TaskService, ts.TaskService.__init__),
             (dm.DomainModelService, dm.DomainModelService.__init__),
             (ds.DiscoveryService, ds.DiscoveryService.__init__),
             (dc.DecisionService, dc.DecisionService.__init__),
             (cs.CustomerCompletionService, cs.CustomerCompletionService.__init__),   # 问题C
             (st.TradeStandardizer, st.TradeStandardizer.__init__)]                  # 问题D需要
    def _mk(orig):
        def wrapped(self, *a, **k):
            orig(self, *a, **k)
            self._ex = _FakeAI()  # 构造后统一替换内部执行器（两类都安全）
        return wrapped
    for cls, orig in pairs:
        cls.__init__ = _mk(orig)
        _WIRED.append((cls, orig))


def _unwire():
    for cls, orig in _WIRED:
        cls.__init__ = orig
    _WIRED.clear()


_SEED_HTML = ('<div class="mb-4"><div class="x">'
              '<a class="hover:underline" href="/company/shinwon-felt">Shinwon Felt</a>'
              '</div><div class="text-sm flex"><div class="text-yeti-text-3 text-xs">'
              'Total Shipments</div>180</div></div></div>')


def _seed(conn):
    raw = RawRepository(conn)
    # V42: L5 只处理搜索页；L7 客户发现需要 company_detail 页——fixture 各建一个
    raw.create("importyeti", "https://www.importyeti.com/search?q=felt", None,
               _SEED_HTML, keyword="felt", page_number=1, page_type="search_result")
    # 返回值给 L7 build() 作 raw_page_ids，必须是 company_detail 页（客户发现只认它）
    rid = raw.create("importyeti", "https://www.importyeti.com/company/shinwon-felt", None,
                     _SEED_HTML, page_type="company_detail")
    return rid


def _seed_dirty(conn):
    """脏库：10 个无关实体（供 keys 断言用）。"""
    ent_r = EntityRepository(conn)
    for i in range(10):
        ent_r.create("Company", f"Dirty Historical Co {i}", aliases=[], country="Nowhere")


def _seed_dirty_shipment_for(conn, supplier_id: int):
    """问题A 场景：同一供应商实体在"历史任务"中的 shipment（不在本任务 shipment_ids 内）。"""
    ent_r = EntityRepository(conn)
    old_buy = ent_r.create("Company", "Dirty Historical Buyer", aliases=[], country="YY")
    dirty_rid = RawRepository(conn).create("importyeti", "http://old", None, "old",
                                           page_type="company_detail")
    ShipmentRepository(conn).create(
        supplier_id=supplier_id, buyer_id=old_buy, evidence="old shipment",
        confidence=0.9, raw_page_id=dirty_rid)


def test_l8_isolation_from_dirty_db():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    import data.db as _dbmod
    _old = _dbmod.DEFAULT_PATH
    _dbmod.DEFAULT_PATH = path
    try:
        _seed_dirty(conn)
        rid = _seed(conn)                      # 问题D：seed 在 L4 之前，经 Fake collector 进数据流
        _wire()
        from orchestration import graph as gmod
        class _OneCollector:                   # 问题D：L4 产出 raw_page_ids，不手写 state
            def __init__(self, rid): self._rid = rid
            def collect(self, plan): return [self._rid]
        orig = gmod.TradeDataCollector
        gmod.TradeDataCollector = lambda *a, **k: _OneCollector(rid)
        try:
            state = {"user_input": "毛毡"}
            for name in ("L1_task_understanding", "L2_domain_modeling", "L3_discovery_planning",
                         "L4_data_acquisition", "L5_data_standardization",
                         "L7_trade_relationship", "L8_knowledge_fusion"):
                state.update(_NODES[name](state))
            l7_ids = set(state.get("entity_ids") or [])
        finally:
            gmod.TradeDataCollector = orig
            _dbmod.DEFAULT_PATH = _old
            _unwire()
        # 问题A 场景构造：给本任务供应商实体挂一条"历史任务"shipment（不在本任务范围内）
        ent_r2 = EntityRepository(conn)
        shinwon_id = next(e["id"] for e in ent_r2.list_all()
                          if e["canonical_name"] == "Shinwon Felt")
        _seed_dirty_shipment_for(conn, shinwon_id)
        # 用本任务 ids 重新融合（等价于图内 L8 输入），buyers 不得包含历史买家
        from business.trade.fusion_service import FusionService as _FS
        _wire()
        try:
            fused = _FS(conn=conn).fuse(
                sorted(l7_ids),
                edge_ids=state.get("edge_ids") or [],
                shipment_ids=state.get("shipment_ids") or [])
        finally:
            _unwire()
        fused_keys = set(fused.keys())
        # 第1行（子集）：防"多处理"；第2行（等值+数量）：防"漏处理"（漏处理只有第2行能抓）
        assert fused_keys <= l7_ids, f"L8 多处理: {fused_keys - l7_ids}"
        # 建议1：数量从 AI_REPLIES 动态派生（supplier 1 + discovery 客户数），改回复不静默失效
        expected_count = 1 + len(AI_REPLIES["L7_trade_discovery"]["customers"])
        assert len(fused_keys) == expected_count and fused_keys == l7_ids, \
            f"L8 漏处理或数量异常: fused={sorted(fused_keys)} l7={sorted(l7_ids)} expected={expected_count}"
        # 问题B：脏 shipment 存在时，buyers/suppliers/shipments 统计也不得混入。
        # 注意：范围外实体在 id2name 中无名，会泄露为 id 字符串（数字）——两种形态都要抓。
        for eid, p in fused.items():
            assert "Dirty Historical Buyer" not in p["buyers"], f"profile {eid} 混入历史买家"
            assert "Dirty Historical Supplier" not in p["suppliers"], f"profile {eid} 混入历史供应商"
            # 建议2：这是数据一致性防线，不只是逻辑防线——
            # 生产路径在 FK 约束下不应触发该 fallback，但旧库残留/外键未开/跨任务
            # shipment 混入时 id2name.get(..., str(id)) 仍可能泄露数字 id。
            leaked = [x for x in p["buyers"] + p["suppliers"] if str(x).strip().isdigit()]
            assert not leaked, \
                f"profile {eid} buyers/suppliers 泄露范围外实体id: {leaked}（数据一致性防线被触发）"
        print("  fused_keys == L7 entity_ids == 本任务2实体；脏实体+脏shipment 零混入 ✓")
    finally:
        conn.close(); os.unlink(path)


def test_l7_normal_path_entity_ids():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        _wire()
        try:
            rid = _seed(conn)
            std = StandardCompanyRepository(conn).create(
                rid, "Shinwon Felt", "180 shipments", country="Korea", shipment_count=180,
                source_url="https://www.importyeti.com/search?q=x",
                company_detail_url="https://www.importyeti.com/company/shinwon-felt")
            r = RelationshipBuilder(conn=conn).build([std], [rid])
        finally:
            _unwire()
        assert r["status"] == "ok"
        names = {e["canonical_name"] for e in EntityRepository(conn).list_all()}
        assert {"Shinwon Felt", "ABC Import LLC"} <= names
        assert len(r["entity_ids"]) == 2 and r["edge_ids"] and r["shipment_ids"]
    finally:
        conn.close(); os.unlink(path)


def test_l9_skip_without_ai():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        out = GraphIntelligence(conn=conn, executor=_FakeAI()).analyze([])
        assert out == {"status": "skipped", "reason": "no_edges_from_L7"}
    finally:
        conn.close(); os.unlink(path)


def test_l9_stats_priority():
    """修复2：AI 输出含 edge_count=999 时，analyze() 返回的真实统计不得被覆盖。"""
    class _FakeAI_BadL9:
        def execute(self, node, context, validate=None):
            if node == "L9_intelligence":
                d = {"core_suppliers": [], "core_buyers": [], "market_structure": "",
                     "relationship_strengths": [], "opportunities": [], "risks": [],
                     "edge_count": 999}  # AI 试图污染统计
                return validate(d) if validate else d
            return AI_REPLIES[node]

    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        gi = GraphIntelligence(conn=conn)
        gi._ex = _FakeAI_BadL9()
        out = gi.analyze([1])   # 非空 edge_ids 走真实路径（库内无边，真实 edge_count=0）
        assert out["edge_count"] != 999, f"AI 覆盖了真实统计: {out['edge_count']}"
        assert out["edge_count"] == 0, f"真实统计丢失: {out['edge_count']}"
    finally:
        conn.close(); os.unlink(path)
