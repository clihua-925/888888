"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""问题2验收：L7 只入队不等 AI；边立即生成；retry≤3。"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from data.repository.customer_queue_repository import CustomerQueueRepository
from data.repository.edge_repository import EdgeRepository
from business.trade.relationship_builder import RelationshipBuilder
from business.trade.customer_service import CustomerCompletionService

SUP = ("<html><title>Shinwon Felt | ImportYeti</title><body>180 Shipments"
       '<script id="__NEXT_DATA__" type="application/json">'
       '{"props":{"pageProps":{"records":[{"consignee":"ABC Import LLC","country":"USA"}]}}}'
       "</script></body></html>")


def _write_tmp(html):
    fd, p = tempfile.mkstemp(suffix=".html"); os.close(fd)
    open(p, "w", encoding="utf-8").write(html); return p


def test_l7_queues_without_waiting():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        raw = RawRepository(conn)
        rid = raw.create("importyeti", "http://iy/company/shinwon-felt", None, "t",
                         page_type="company_detail")
        raw.update_html_path(rid, _write_tmp(SUP))
        std_id = StandardCompanyRepository(conn).create(
            rid, "Shinwon Felt", "180 shipments", country="Korea", shipment_count=180,
            source_url="https://www.importyeti.com/search?q=x",
            company_detail_url="https://www.importyeti.com/company/shinwon-felt")
        r = RelationshipBuilder(conn=conn).build([std_id], [rid])
        # L7 立即产出关系，不等 AI
        assert r["status"] == "ok" and r["edge_ids"] and r["shipment_ids"]
        assert r["customer_queued"] == 1
        # 客户已在队列（pending，由 L6 异步 Worker 消费）
        jobs = CustomerQueueRepository(conn).list_by_status("pending")
        assert any(j["customer_name"] == "ABC Import LLC" for j in jobs)
        edge = EdgeRepository(conn).get(r["edge_ids"][0])
        assert edge["relation"] == "SUPPLIES" and "/company/" in edge["source_url"]
    finally:
        conn.close(); os.unlink(path)


def test_retry_max_3():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        svc = CustomerCompletionService(conn=conn)
        svc._complete_one = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("AI down"))
        svc.enqueue("Flaky Co", "USA")
        rounds = [svc.process_pending() for _ in range(4)]
        # 第1轮 processing->pending(retry1)，第2轮 retry2，第3轮 retry3后 failed
        jobs = CustomerQueueRepository(conn).list_by_status("failed")
        assert jobs and jobs[0]["customer_name"] == "Flaky Co"
        assert jobs[0]["attempts"] == 3, jobs[0]["attempts"]
        assert not CustomerQueueRepository(conn).list_by_status("pending")
    finally:
        conn.close(); os.unlink(path)
