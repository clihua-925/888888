"""L4 修复验收：搜索→解析候选→Top10 动态详情，绝不固定公司。

陷阱场景：搜索页含 wal-mart 热门链接 + 低 shipment 条目，
正确行为：详情页访问 = 候选按 shipment 降序的 Top10，不含任何固定公司。
"""
import os, tempfile, json
from contracts.search_plan import SearchPlan
from business.trade.collector.browser_agent import BrowserAgentCollector
from business.trade.collector.driver import BaseDriver, PageBundle
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.candidate_repository import CandidateRepository

SEARCH = ("<html><title>Industrial Felt supplier - ImportYeti Search</title><body>"
          "Industrial Felt supplier importer exporter "
          '<a href="/company/wal-mart-stores">Wal-Mart Stores Inc</a>'
          '<script id="__NEXT_DATA__" type="application/json">'
          '{"props":{"pageProps":{"companies":['
          '{"slug":"shinwon-felt","name":"Shinwon Felt","shipments":180,"country":"Korea"},'
          '{"slug":"abc-import-llc","name":"ABC Import LLC","shipments":120,"country":"USA"},'
          '{"slug":"feltworks-gmbh","name":"FeltWorks GmbH","shipments":77,"country":"Germany"},'
          '{"slug":"craft-felt-co","name":"Craft Felt Co","shipments":30,"country":"USA"}]}}}'
          "</script></body></html>")


class _RecordingDriver(BaseDriver):
    driver_type = "fake"
    def __init__(self):
        self.visited = []
    def homepage(self):
        return PageBundle("<html><title>ImportYeti</title><body>home</body>",
                          "https://www.importyeti.com/", "homepage")
    def search(self, keyword, max_pages=3, advisor=None):
        return [PageBundle(SEARCH, "https://www.importyeti.com/search?q=x",
                           "search_result", keyword, 1)]
    def company_detail(self, slug):
        self.visited.append(slug)
        return PageBundle(f"<html><title>{slug}</title><body>5 Shipments supplier</body>",
                          f"https://www.importyeti.com/company/{slug}", "company_detail")
    def shipment_detail(self, url):
        return None


def test_dynamic_top10_not_fixed():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        drv = _RecordingDriver()
        collector = BrowserAgentCollector(driver=drv, raw_repo=RawRepository(conn),
                                          max_pages=1)
        ids = collector.collect(SearchPlan(queries=["Industrial Felt supplier"],
                                           sources=[], directions=[], priority=[]))
        repo = CandidateRepository(conn)
        cands = [c for i in ids for c in repo.list_by_source(i)]
        names = [c["company_name"] for c in cands]
        assert "Shinwon Felt" in names and "ABC Import LLC" in names and len(cands) == 4
        # 详情访问 = shipment 降序 Top10 的真实候选；无 wal-mart、无重复、无固定
        assert drv.visited == ["shinwon-felt", "abc-import-llc", "feltworks-gmbh", "craft-felt-co"], drv.visited
        assert not any("wal-mart" in v for v in drv.visited)
        detail_rows = [RawRepository(conn).get(i) for i in ids]
        assert sum(1 for r in detail_rows if r["page_type"] == "company_detail") == 4
        assert sum(1 for r in detail_rows if r["page_type"] == "search_result") == 1
    finally:
        conn.close(); os.unlink(path)
