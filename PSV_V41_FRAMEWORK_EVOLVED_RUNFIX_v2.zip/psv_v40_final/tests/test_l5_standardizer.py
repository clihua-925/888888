"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""L5 标准化：raw -> standard_company_data（不做去重/验证/关系判断）。"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from business.trade.standardizer import TradeStandardizer

_HTML = ('<html><title>Felt - ImportYeti Search</title><body>'
         '<script id="__NEXT_DATA__" type="application/json">'
         '{"props":{"pageProps":{"companies":['
         '{"name":"Shinwon Felt","shipments":180,"country":"Korea"},'
         '{"name":"ABC Import LLC","shipments":45,"country":"USA"}]}}}'
         '</script></body></html>')


def test_standardize_produces_standard_rows():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        rid = RawRepository(conn).create("importyeti", "http://iy/search", None, "x", page_type="search_result")
        raw = RawRepository(conn)
        raw.update_html_path(rid, _write_tmp(_HTML))
        ids = TradeStandardizer(conn=conn).standardize([rid])
        assert len(ids) == 2
        rows = StandardCompanyRepository(conn).list_by_ids(ids)
        names = {r["company_name"] for r in rows}
        assert names == {"Shinwon Felt", "ABC Import LLC"}
        r0 = rows[0]
        assert r0["source_url"] == "http://iy/search" and r0["raw_page_id"] == rid
        assert r0["original_text"] and r0["shipment_count"] in (180, 45)
    finally:
        conn.close(); os.unlink(path)


def _write_tmp(html: str) -> str:
    import tempfile
    fd, p = tempfile.mkstemp(suffix=".html"); os.close(fd)
    open(p, "w", encoding="utf-8").write(html)
    return p
