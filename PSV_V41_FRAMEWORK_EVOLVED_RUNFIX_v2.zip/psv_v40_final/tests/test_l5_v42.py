"""L5 V42 健壮性离线测试（报告 5 个 case）。"""
from business.trade.standardizer import _canonicalize_url, TradeStandardizer


def test_canonicalize_proxy_url():
    u = "https://proxy.local/fetch?url=https%3A%2F%2Fwww.importyeti.com%2Fsearch%3Fq%3DWool%2BFelt"
    c = _canonicalize_url(u)
    assert c and "importyeti.com/search" in c and "q=Wool" in c.replace("+", " ") or c and "q=Wool%2BFelt" in c or "q=Wool+Felt" in (c or "")
    assert _canonicalize_url(None) is None
    assert _canonicalize_url("") is None
    assert "importyeti.com" in _canonicalize_url("https://www.importyeti.com/company/x")


class _FakeRaw:
    def __init__(self, pages): self._p = {p["id"]: p for p in pages}
    def get(self, pid): return self._p.get(pid)


class _FakeStdRepo:
    def __init__(self): self.rows = []
    def create(self, **kw): self.rows.append(kw); return len(self.rows)


class _FakeAI:
    def __init__(self, ships): self._s = ships
    def execute(self, node, ctx, validate=None):
        return validate({"companies": self._s}) if validate else self._s


def _mk(pages, ai):
    ts = TradeStandardizer.__new__(TradeStandardizer)
    ts._raw, ts._std, ts._ex = _FakeRaw(pages), _FakeStdRepo(), ai
    return ts


_MINI_HTML = (
    '<div class="mb-4"><div class="x">'
    '<a class="hover:underline" href="/supplier/acme-felt">Acme Felt</a>'
    '</div><div class="text-sm flex"><div class="text-yeti-text-3 text-xs">Total Shipments</div>5'
    '</div></div></div>'
)


def _pg(i, url):
    return {"id": i, "url": url, "keyword": "k", "page_number": 1,
            "text": _MINI_HTML, "html_path": None}


def test_invalid_page_ref_does_not_kill_batch():
    pages = [_pg(1, "https://www.importyeti.com/search?q=a"), _pg(2, "https://www.importyeti.com/search?q=b")]
    ai = _FakeAI([
        {"company_name": "Good A", "evidence": "e", "page_id": 1},
        {"company_name": "Bad", "evidence": "e", "page_id": 999},
        {"company_name": "Good B", "evidence": "e", "page_id": 2},
    ])
    ts = _mk(pages, ai)
    out = ts.standardize([1, 2])
    assert len(out) == 2, out
    assert ts.last_run_metrics["invalid_page_refs"] == 1
    assert ts.last_page_errors[0]["code"] == "InvalidPageRef"


def test_zero_output_raises():
    pages = [_pg(1, "https://www.importyeti.com/search?q=a")]
    ai = _FakeAI([])   # AI 返回空
    ts = _mk(pages, ai)
    try:
        ts.standardize([1])
        assert False, "0 产出应显式失败"
    except RuntimeError as e:
        assert "zero output" in str(e)


def test_empty_input_ok():
    ts = _mk([], _FakeAI([]))
    assert ts.standardize([]) == []
    assert ts.last_run_metrics["output_count"] == 0


def test_duplicate_and_detail_skip_reasons():
    pages = [_pg(1, "https://www.importyeti.com/search?q=a"),
             _pg(2, "https://www.importyeti.com/search?q=a"),     # 重复 URL
             _pg(3, "https://www.importyeti.com/company/x")]     # 详情页
    ai = _FakeAI([{"company_name": "A", "evidence": "e", "page_id": 1}])
    ts = _mk(pages, ai)
    out = ts.standardize([1, 2, 3])
    assert len(out) == 1
    sr = ts.last_run_metrics["skip_reasons"]
    assert sr.get("duplicate") == 1 and sr.get("detail_page_not_l5_scope") == 1
