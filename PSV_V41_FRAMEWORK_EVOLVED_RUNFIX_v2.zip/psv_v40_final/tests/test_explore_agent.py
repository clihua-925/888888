"""ExploreAgent 离线单测：FakeDriver + FakeAI，不触网。"""
from business.trade.collector.explore_agent import ExploreAgent


class FakePage:
    url = "https://www.importyeti.com/search?q=felt"
    title = "felt - ImportYeti Search"
    def go_back(self, **k): self.url = "https://www.importyeti.com/search?q=felt"
    def wait_for_timeout(self, ms): pass


class FakeDriver:
    def __init__(self): self.page = FakePage()
    def goto(self, url, page=None): self.page.url = url; return self.page
    def snapshot(self, page=None, max_chars=6000):
        if "/supplier/" in self.page.url:
            return "Shinwon Felt\nTotal Shipments\n180\nTop Customers\nACME Trading"
        return "Industrial Felt search\nShinwon Felt\nTotal Shipments\n180"
    def click_text(self, text, nth=0, page=None): return True
    def current_info(self, page=None): return {"url": self.page.url, "title": "t"}


class FakeAI:
    def __init__(self, node): pass
    def execute(self, node, ctx, validate=None):
        return {"action": "done", "reason": "unit test"}


def test_explore_agent_trace_not_empty():
    agent = ExploreAgent(FakeDriver(), ai=FakeAI("L4_explore_decision"), max_steps=5, max_suppliers=1)
    tr = agent.run_from_search("https://www.importyeti.com/search?q=felt", "felt")
    assert tr["status"] in ("ok", "limit_reached")
    assert tr["steps"], "轨迹不能为空"
