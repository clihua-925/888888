"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""Test 3：L3 Discovery Planning —— SearchPlan 含 supplier/buyer 双向查询。"""
from business.trade.discovery_service import DiscoveryService
from business.product.domain_model_service import DomainModelService
from business.product.task_service import TaskService


def test_search_plan_supplier_and_buyer_queries():
    task = TaskService().understand("毛毡")
    plan = DiscoveryService().plan(task, DomainModelService().build(task))
    assert plan.queries and plan.sources and plan.priority
    joined = " ".join(plan.queries).lower()
    assert "supplier" in joined and "manufacturer" in joined
    assert "importer" in joined and "buyer" in joined
    assert "Industrial Felt supplier" in plan.queries
