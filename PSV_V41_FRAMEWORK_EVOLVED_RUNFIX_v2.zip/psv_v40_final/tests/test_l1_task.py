"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""Test 1：L1 Task Understanding —— 输入『毛毡』输出 TaskObject。"""
from business.product.task_service import TaskService


def test_task_object_from_felt():
    t = TaskService().understand("毛毡")
    assert t.product == "Felt"
    assert t.target_market
    assert t.analysis_goal
    assert "supplier" in t.company_types and "importer" in t.company_types
