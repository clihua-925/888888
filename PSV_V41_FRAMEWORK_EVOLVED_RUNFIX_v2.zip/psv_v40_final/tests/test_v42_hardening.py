"""V42 安全与健壮性加固测试（全部离线，不触网、不需登录）。"""
import importlib
import os
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))


# ---------- 1. 监听地址与 CORS ----------
def test_host_localonly():
    src = (PROJ / "run_services.py").read_text(encoding="utf-8")
    assert '"127.0.0.1"' in src and '"0.0.0.0"' not in src


def test_cors_not_wildcard():
    src = (PROJ / "api/app.py").read_text(encoding="utf-8")
    assert 'allow_origins=["*"]' not in src
    assert "127.0.0.1:8000" in src


# ---------- 5. 模型名优先级 ----------
def _model_with(env: dict) -> str:
    for k in ("PSV_LLM_MODEL", "LLM_MODEL", "MODEL_NAME"):
        os.environ.pop(k, None)
    os.environ.update(env)
    return (os.getenv("PSV_LLM_MODEL") or os.getenv("LLM_MODEL")
            or os.getenv("MODEL_NAME") or "gpt-4o-mini")


def test_model_name_priority():
    # 与 client.py 的读取链一致：PSV_LLM_MODEL > LLM_MODEL > MODEL_NAME > 默认
    assert _model_with({"PSV_LLM_MODEL": "A", "LLM_MODEL": "B", "MODEL_NAME": "C"}) == "A"
    assert _model_with({"LLM_MODEL": "B", "MODEL_NAME": "C"}) == "B"
    assert _model_with({"MODEL_NAME": "C"}) == "C"
    assert _model_with({}) == "gpt-4o-mini"
    for k in ("PSV_LLM_MODEL", "LLM_MODEL", "MODEL_NAME"):
        os.environ.pop(k, None)


# ---------- 4. 审计 provider 动态化 ----------
def test_ai_type_dynamic():
    from ai.ai_executor import AIExecutor
    from business.shared import config as cfg
    os.environ["PSV_WEBAI_PROVIDER"] = "gpt"
    importlib.reload(cfg)
    assert AIExecutor.ai_type("L6_customer_completion") == "gpt_web"
    os.environ["PSV_WEBAI_PROVIDER"] = "deepseek"
    importlib.reload(cfg)
    assert AIExecutor.ai_type("L6_customer_completion") == "deepseek_web"
    os.environ["PSV_WEBAI_PROVIDER"] = "gpt"
    importlib.reload(cfg)
    assert AIExecutor.ai_type("L5_standardization") == "local_ai"


# ---------- 3. 受阻截图（成功/失败两路径） ----------
class _FakePageShot:
    def __init__(self, fail): self._fail = fail
    def screenshot(self, path=None):
        if self._fail:
            raise RuntimeError("disk full")
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_bytes(b"png")


def test_blocked_screenshot_ok():
    from ai.gpt_web_agent import GPTWebAgent, GPTWebError
    ag = GPTWebAgent(); ag._page = _FakePageShot(False)
    try:
        ag._raise_blocked("模拟受阻"); assert False
    except GPTWebError as e:
        assert "模拟受阻" in str(e) and ".png" in str(e)


def test_blocked_screenshot_fail_still_clear():
    from ai.gpt_web_agent import GPTWebAgent, GPTWebError
    ag = GPTWebAgent(); ag._page = _FakePageShot(True)
    try:
        ag._raise_blocked("模拟受阻"); assert False
    except GPTWebError as e:
        assert "模拟受阻" in str(e)   # 截图失败不掩盖受阻原因


# ---------- 2. 竞态防回归：base_count 必须在 Enter 之前 ----------
def test_ask_records_base_before_send():
    src = (PROJ / "ai/gpt_web_agent.py").read_text(encoding="utf-8")
    i_base = src.find("base_count = page.locator")
    i_enter = src.find('page.keyboard.press("Enter")')
    assert 0 < i_base < i_enter
