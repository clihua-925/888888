"""问题3验收：三级解析降级（无 __NEXT_DATA__ 时 DOM 链接/文本正则兜底）。"""
from business.trade.collector.search_parser import parse_search_candidates


def test_level2_dom_links_when_no_next_data():
    html = ('<html><body><ul>'
            '<li><a href="/company/shinwon-felt">Shinwon Felt</a></li>'
            '<li><a href="/company/abc-import-llc">ABC Import LLC</a></li>'
            "</ul></body></html>")
    rows = parse_search_candidates(html, 7, "Industrial Felt supplier")
    assert len(rows) == 2 and rows[0]["parse_level"] == "_from_dom_links"
    assert rows[0]["company_url"].endswith("/company/shinwon-felt")
    assert rows[0]["source_raw_page_id"] == 7


def test_level3_text_cards():
    html = "<html><body>Shinwon Felt | 180 shipments  ABC Import LLC - 45 shipments</body></html>"
    rows = parse_search_candidates(html, 9, "felt")
    assert {r["company_name"] for r in rows} == {"Shinwon Felt", "ABC Import LLC"}
    assert rows[0]["parse_level"] == "_from_text_cards"


def test_level1_priority():
    html = ('<html><body><a href="/company/x">X Co</a>'
            '<script id="__NEXT_DATA__" type="application/json">'
            '{"props":{"pageProps":{"companies":[{"name":"Shinwon Felt","shipments":5,"slug":"shinwon-felt"}]}}}'
            "</script></body></html>")
    rows = parse_search_candidates(html, 1, "felt")
    assert rows[0]["parse_level"] == "_from_next_data" and len(rows) == 1
