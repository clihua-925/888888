"""Live-AI 门控（V41 修正版：按 AI 类型检查真实依赖，禁 mock AI）。

local_ai_available()  : 本地 70B（LLM_API_KEY 已配置且 LLM_BASE_URL 可达）
deepseek_web_available(): CDP :9222 可达（L6 网页AI通道）
"""
import os
import socket
from urllib.parse import urlsplit


def local_ai_available() -> bool:
    if os.getenv("PSV_LIVE_AI") != "1":
        return False
    if not (os.getenv("LLM_API_KEY") or os.getenv("PSV_LLM_API_KEY")):
        return False
    base = os.getenv("LLM_BASE_URL") or os.getenv("PSV_LLM_BASE_URL") or "http://192.168.1.26:8081/v1"
    u = urlsplit(base)
    try:
        return socket.socket().connect_ex((u.hostname or "192.168.1.26", u.port or 8081)) == 0
    except OSError:
        return False


def deepseek_web_available() -> bool:
    if os.getenv("PSV_LIVE_AI") != "1":
        return False
    try:
        return socket.socket().connect_ex(("127.0.0.1", 9222)) == 0
    except OSError:
        return False
