"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""问题1验收：L5 区分 search_url 与 company_detail_url；搜索页 URL 禁止作为 detail。"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from business.trade.standardizer import TradeStandardizer


def _write_tmp(html):
    fd, p = tempfile.mkstemp(suffix=".html"); os.close(fd)
    open(p, "w", encoding="utf-8").write(html); return p


def test_search_url_vs_company_detail_url():
    html = ("<html><body>supplier importer"
            '<script id="__NEXT_DATA__" type="application/json">'
            '{"props":{"pageProps":{"companies":['
            '{"name":"Shinwon Felt","shipments":180,"country":"Korea","slug":"shinwon-felt"},'
            '{"name":"Link Only Co","slug":"link-only-co","shipments":10}]}}}'
            "</script></body></html>")
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        raw = RawRepository(conn)
        rid = raw.create("importyeti", "https://www.importyeti.com/search?q=Industrial+Felt",
                         None, "text", keyword="Industrial Felt supplier", page_type="search_result")
        raw.update_html_path(rid, _write_tmp(html))
        ids = TradeStandardizer(conn=conn).standardize([rid])
        rows = {r["company_name"]: r for r in StandardCompanyRepository(conn).list_by_ids(ids)}
        shin = rows["Shinwon Felt"]
        assert shin["source_url"] == "https://www.importyeti.com/search?q=Industrial+Felt"  # search_url
        assert shin["company_detail_url"] == "https://www.importyeti.com/company/shinwon-felt"
        assert "/search" not in (shin["company_detail_url"] or "")
        assert rows["Link Only Co"]["company_detail_url"] == "https://www.importyeti.com/company/link-only-co"
    finally:
        conn.close(); os.unlink(path)
