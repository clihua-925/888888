"""V43 演进回归：任务隔离、单模型队列、证据回溯与幂等写入。"""
import os
import tempfile
import threading
import time

from data.db import init_db
from data.repository.customer_queue_repository import CustomerQueueRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.entity_repository import EntityRepository
from data.repository.raw_repository import RawRepository
from data.repository.shipment_repository import ShipmentRepository
from business.trade.fusion_service import FusionService
from business.trade.graph_intelligence import GraphIntelligence
from business.trade.relationship_builder import RelationshipBuilder
from business.trade.standardizer import TradeStandardizer
from ai.local_ai_executor import LocalAIExecutor


class _FakeL7:
    def execute(self, node, context, validate=None):
        d = {"customers": [{"customer_name": "Buyer A", "country": "USA",
                             "evidence": "consignee Buyer A"}]}
        return validate(d) if validate else d


class _FakeL9:
    def execute(self, node, context, validate=None):
        d = {"core_suppliers": [], "core_buyers": [], "market_structure": "",
             "relationship_strengths": [], "opportunities": [], "risks": []}
        return validate(d) if validate else d


def _db():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    return path, init_db(path)


def test_queue_claim_is_atomic_and_task_scoped():
    path, conn = _db()
    try:
        q = CustomerQueueRepository(conn)
        q.enqueue("A", "USA", task_id="task-a")
        q.enqueue("B", "USA", task_id="task-b")
        got = q.claim_pending(owner="worker-1", task_id="task-a")
        assert [x["customer_name"] for x in got] == ["A"]
        assert q.stats("task-a") == {"processing": 1}
        assert q.claim_pending(owner="worker-2", task_id="task-a") == []
    finally:
        conn.close(); os.unlink(path)


def test_graph_intelligence_does_not_read_other_run():
    path, conn = _db()
    try:
        raw = RawRepository(conn)
        rid = raw.create("test", "https://example.test", None, "evidence")
        ent = EntityRepository(conn)
        s1, b1 = ent.create("Company", "Supplier A", country="Korea"), ent.create("Company", "Buyer A", country="USA")
        s2, b2 = ent.create("Company", "Supplier B", country="China"), ent.create("Company", "Buyer B", country="Germany")
        ships = ShipmentRepository(conn)
        sh1 = ships.create(s1, b1, "shipment A", .8, rid)
        sh2 = ships.create(s2, b2, "shipment B", .8, rid)
        edges = EdgeRepository(conn)
        e1 = edges.create(s1, b1, "SUPPLIES", "shipment A", .8, "https://example.test", sh1, rid)
        edges.create(s2, b2, "SUPPLIES", "shipment B", .8, "https://example.test", sh2, rid)
        out = GraphIntelligence(conn=conn, executor=_FakeL9()).analyze([e1], [sh1], [s1, b1])
        assert out["edge_count"] == 1 and out["shipment_count"] == 1
        assert out["companies"] == ["Supplier A", "Buyer A"]
    finally:
        conn.close(); os.unlink(path)


def test_relationship_requires_source_evidence_and_is_idempotent():
    path, conn = _db()
    try:
        raw = RawRepository(conn)
        rid = raw.create("test", "https://www.importyeti.com/company/supplier-a", None,
                         "consignee Buyer A", page_type="company_detail")
        from data.repository.standard_company_repository import StandardCompanyRepository
        sid = StandardCompanyRepository(conn).create(
            rid, "Supplier A", "consignee Buyer A",
            company_detail_url="https://www.importyeti.com/company/supplier-a")
        rb = RelationshipBuilder(conn=conn, executor=_FakeL7())
        first = rb.build([sid], [rid], task_id="task-a")
        second = rb.build([sid], [rid], task_id="task-a")
        assert len(first["edge_ids"]) == 1 and second["edge_ids"] == first["edge_ids"]
        assert second["shipment_ids"] == first["shipment_ids"]
    finally:
        conn.close(); os.unlink(path)


def test_fusion_keeps_canonical_entity_in_any_position():
    path, conn = _db()
    try:
        ent = EntityRepository(conn)
        a = ent.create("Company", "Alias Co")
        keep = ent.create("Company", "Canonical Co")
        class _FakeFusion:
            def execute(self, node, context, validate=None):
                d = {"merge_plan": [{"canonical": "Canonical Co", "aliases": [],
                                     "entity_ids": [a, keep]}]}
                return validate(d) if validate else d
        out = FusionService(conn=conn, executor=_FakeFusion()).fuse([a, keep], [], [])
        assert keep in out and a not in out
        assert "Alias Co" in ent.get(keep)["aliases"]
    finally:
        conn.close(); os.unlink(path)


def test_local_llama_queue_never_runs_concurrently():
    class Client:
        active = 0
        maximum = 0
        lock = threading.Lock()

        def chat(self, *args, **kwargs):
            with self.lock:
                self.active += 1
                self.maximum = max(self.maximum, self.active)
            time.sleep(0.02)
            with self.lock:
                self.active -= 1
            return {"ok": True}

    client = Client()
    errors = []

    def run():
        try:
            LocalAIExecutor(client=client).execute("L1_task_understanding", "prompt", {})
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=run) for _ in range(3)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors and client.maximum == 1


def test_l5_deterministic_recovery_when_model_returns_empty():
    class Raw:
        def get(self, pid):
            return {"id": pid, "url": "https://www.importyeti.com/search?q=felt",
                    "keyword": "Felt", "page_number": 1,
                    "text": ('<div class="mb-4"><a href="/supplier/acme-felt">'
                              'Acme Felt</a><div>Total Shipments</div>5</div>'),
                    "html_path": None}

    class Std:
        def __init__(self): self.rows = []
        def create(self, **kw): self.rows.append(kw); return len(self.rows)

    class EmptyAI:
        def execute(self, node, context, validate=None):
            return validate({"companies": []}) if validate else []

    ts = TradeStandardizer.__new__(TradeStandardizer)
    ts._raw, ts._std, ts._ex = Raw(), Std(), EmptyAI()
    ids = ts.standardize([1], task_id="fallback-test")
    assert ids == [1]
    assert ts._std.rows[0]["company_name"] == "Acme Felt"
    assert ts._std.rows[0]["model_version"].endswith("+deterministic")
