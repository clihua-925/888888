"""L7 输入保护：无有效供应商（含无 detail url）-> status=skipped / no_valid_supplier_candidates。"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from business.trade.relationship_builder import RelationshipBuilder


def test_l7_skipped_no_candidates():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        r = RelationshipBuilder(conn=conn).build([], [])
        assert r["status"] == "skipped" and r["reason"] == "no_valid_supplier_candidates"
        assert r["edge_ids"] == [] and r["shipment_ids"] == []
    finally:
        conn.close(); os.unlink(path)


def test_l7_skipped_no_detail_url():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        rid = RawRepository(conn).create("importyeti", "http://iy/search", None, "t")
        sid = StandardCompanyRepository(conn).create(
            rid, "Ghost Co", "ev", source_url=None)   # 无 company_detail_url
        r = RelationshipBuilder(conn=conn).build([sid], [rid])
        assert r["status"] == "skipped" and r["reason"] == "no_valid_supplier_candidates"
        assert r["edge_ids"] == []
    finally:
        conn.close(); os.unlink(path)
