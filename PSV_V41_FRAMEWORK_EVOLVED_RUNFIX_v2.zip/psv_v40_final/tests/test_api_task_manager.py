"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""V40.3：任务管理器离线集成 —— 创建任务 → 十阶段状态 → 结果与图谱。"""
import time
import os
from api.task_manager import TaskManager


class _NoCollector:
    def collect(self, plan):
        return []


def _run_offline(tm, monkeypatch=None):
    from orchestration import graph as g
    orig = g.TradeDataCollector
    g.TradeDataCollector = lambda *a, **k: _NoCollector()
    try:
        tid = tm.create("毛毡 销往 美国")
        for _ in range(200):
            s = tm.status(tid)
            if s["status"] in ("done", "failed"):
                break
            time.sleep(0.05)
        return tid, s
    finally:
        g.TradeDataCollector = orig


def test_task_full_cycle():
    tm = TaskManager()
    tid, s = _run_offline(tm)
    assert s["status"] == "done", s.get("error")
    assert len(s["stages"]) == 10
    assert all(st["status"] == "done" for st in s["stages"])

    r = tm.result(tid)
    assert r["product_model"]["product_name"] == "Felt"
    assert "Industrial Felt" in r["product_model"]["categories"]
    assert r["report"]["market"] == "美国"
    for k in ("top_suppliers", "top_buyers", "trade_relations", "evidence",
              "risks", "opportunities"):
        assert k in r["report"]

    g = tm.graph(tid)
    assert g and "elements" in g
    assert isinstance(g["elements"]["nodes"], list)
    assert isinstance(g["elements"]["edges"], list)


def test_task_not_found():
    tm = TaskManager()
    assert tm.status("nope") is None
    assert tm.result("nope") is None
