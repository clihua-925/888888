"""Bug1 故障注入：search_result 页被 purify 拒绝时（_save 返回 None），
collect() 不得 TypeError，应正常 continue 处理后续页。"""
import os, tempfile
from contracts.search_plan import SearchPlan
from business.trade.collector.browser_agent import BrowserAgentCollector
from business.trade.collector.driver import BaseDriver, PageBundle
from data.db import init_db
from data.repository.raw_repository import RawRepository

GOOD_HTML = "<html><body>Industrial Felt supplier - 120 shipments importer</body></html>"
JUNK_URL = "https://en.wikipedia.org/wiki/Felt"   # purify: junk_domain 拒绝


class _JunkThenGoodDriver(BaseDriver):
    driver_type = "fake"
    def homepage(self):
        return PageBundle(GOOD_HTML, "https://www.importyeti.com/", "homepage")
    def search(self, keyword, max_pages=3, advisor=None):
        return [
            PageBundle("<html><body>Felt is a textile</body></html>", JUNK_URL,
                       "search_result", keyword, 1),          # 会被 purify 拒绝
            PageBundle(GOOD_HTML, "https://www.importyeti.com/search?q=x",
                       "search_result", keyword, 2),          # 正常页
        ]
    def company_detail(self, slug):
        return None
    def shipment_detail(self, url):
        return None


def test_junk_search_page_does_not_crash():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        c = BrowserAgentCollector(driver=_JunkThenGoodDriver(),
                                  raw_repo=RawRepository(conn), max_pages=1)
        ids = c.collect(SearchPlan(queries=["felt"], sources=[], directions=[], priority=[]))
        rows = RawRepository(conn).list_by_ids(ids)
        types = [r["page_type"] for r in rows]
        urls = [r["url"] for r in rows]
        # 崩溃场景已排除；junk 页不落库；homepage 与第 2 页 search_result 正常保存
        assert "search_result" in types
        assert JUNK_URL not in urls
        assert "homepage" in types
    finally:
        conn.close(); os.unlink(path)
