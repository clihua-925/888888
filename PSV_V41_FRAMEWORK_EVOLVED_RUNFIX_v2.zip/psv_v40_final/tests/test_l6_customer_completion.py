import os, tempfile, json
from data.db import init_db
from data.repository.customer_queue_repository import CustomerQueueRepository
from data.repository.customer_profile_repository import CustomerProfileRepository
from business.trade.customer_service import CustomerCompletionService


class _FakeDS:
    def ask(self, prompt):
        return json.dumps({"company_name": "UNUSED", "website": None, "industry": None,
                           "products": [], "business_type": "importer", "sources": [],
                           "confidence": 0.6})


def test_queue_dedup_and_profile():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        svc = CustomerCompletionService(conn=conn, web_client=_FakeDS())
        svc.enqueue("ABC Import LLC", "USA")
        svc.enqueue("ABC Imports", "USA")
        svc.enqueue("XYZ Manufacturing", "Germany")
        stats = svc.process_pending()
        assert stats["processed"] == 3 and stats["success"] == 3, stats
        queue = CustomerQueueRepository(conn)
        assert all(j["status"] == "success" for j in queue.list_by_status("success"))
        profiles = CustomerProfileRepository(conn).list_all()
        assert len(profiles) == 2, "ABC Import LLC / ABC Imports 应去重为一个画像"
        abc = next(p for p in profiles if p["canonical_name"] == "ABC Import LLC")
        assert "ABC Imports" in abc["aliases"]
        assert abc["country"] == "USA" and abc["company_type"] == "importer"
    finally:
        conn.close(); os.unlink(path)
