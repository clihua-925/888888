import os, tempfile, json
from data.db import init_db
from data.repository.customer_queue_repository import CustomerQueueRepository
from data.repository.customer_profile_repository import CustomerProfileRepository
from data.repository.customer_ai_session_repository import CustomerAISessionRepository
from data.repository.customer_raw_page_repository import CustomerRawPageRepository
from business.trade.customer_service import CustomerCompletionService
from business.trade.deepseek_web_client import DeepSeekWebError

REPLY = json.dumps({
    "company_name": "ABC Import LLC", "website": "https://abcimport.example.com",
    "country": "USA", "address": "123 Trade St, Los Angeles, CA",
    "industry": "Automotive", "business": "Auto parts import and distribution",
    "products": ["Industrial Felt", "Gasket Materials"],
    "business_type": "importer",
    "sources": ["https://abcimport.example.com/about"],
    "confidence": 0.85}, ensure_ascii=False)


class _FakeDeepSeekOK:
    def ask(self, prompt: str) -> str:
        assert "企业信息调查分析助手" in prompt and "ABC Import LLC" in prompt
        return REPLY
    def browser_session_text(self) -> str:
        return '{"engine":"deepseek-web","fake":true}'


class _FakeDeepSeekDown:
    def ask(self, prompt: str) -> str:
        raise DeepSeekWebError("DeepSeek 网页操作失败: timeout")


def test_deepseek_web_completion_full_chain():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        svc = CustomerCompletionService(conn=conn, web_client=_FakeDeepSeekOK())
        qid = svc.enqueue("ABC Import LLC", "USA")
        stats = svc.process_pending()
        assert stats["success"] == 1, stats
        profiles = CustomerProfileRepository(conn).list_all()
        assert len(profiles) == 1
        p = profiles[0]
        assert p["canonical_name"] == "ABC Import LLC"
        assert p["website"] == "https://abcimport.example.com"
        assert p["industry"] == "Automotive"
        assert p["products"] == ["Industrial Felt", "Gasket Materials"]
        assert p["company_type"] == "importer"
        assert abs(p["confidence"] - 0.85) < 1e-6
        assert p["sources"] == ["https://abcimport.example.com/about"]
        assert p["country"] == "USA" and p["address"]
        # 留痕：AI 会话 + 浏览器取证页
        sess = CustomerAISessionRepository(conn).list_by_customer(qid)
        assert sess and "企业信息调查分析助手" in sess[0]["prompt"]
        assert "abcimport.example.com" in (sess[0]["deepseek_response"] or "")
        raw = CustomerRawPageRepository(conn).list_by_customer(qid)
        assert raw and raw[0]["url"] == "https://chat.deepseek.com/" and raw[0]["page_text"]
        print("  画像 ✓ 会话留痕 ✓ 取证页 ✓")
    finally:
        conn.close(); os.unlink(path)


def test_deepseek_down_no_fake_profile():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        svc = CustomerCompletionService(conn=conn, web_client=_FakeDeepSeekDown())
        svc.enqueue("Ghost Buyer Co", "USA")
        for _ in range(4):
            svc.process_pending()
        jobs = CustomerQueueRepository(conn).list_by_status("failed")
        assert jobs and jobs[0]["customer_name"] == "Ghost Buyer Co"
        assert "deepseek_browser_error" in (jobs[0]["error"] or "")
        assert jobs[0]["attempts"] == 3, jobs[0]["attempts"]
        assert CustomerProfileRepository(conn).list_all() == [], "浏览器失败绝不允许生成虚假画像"
        print("  失败不伪造 ✓ attempts=3 ✓")
    finally:
        conn.close(); os.unlink(path)


def test_unknown_fields_become_none():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        class _FakeUnknown:
            def ask(self, prompt):
                return json.dumps({"company_name": "XYZ Trading", "website": "unknown",
                                   "industry": "unknown", "products": [],
                                   "business_type": "distributor", "sources": [],
                                   "confidence": "unknown"})
        svc = CustomerCompletionService(conn=conn, web_client=_FakeUnknown())
        svc.enqueue("XYZ Trading", "Germany")
        svc.process_pending()
        p = CustomerProfileRepository(conn).list_all()[0]
        assert p["website"] is None and p["industry"] is None
        assert 0 <= p["confidence"] <= 1
        print("  unknown→null ✓")
    finally:
        conn.close(); os.unlink(path)
