"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""L7：IY 客户关系 -> L6 补全 -> Shipment + SUPPLIES Edge（含全链字段）。"""
import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository
from business.trade.relationship_builder import RelationshipBuilder

_SUPPLIER_PAGE = ('<html><title>Shinwon Felt | ImportYeti</title><body>Shinwon Felt '
                  '<script id="__NEXT_DATA__" type="application/json">'
                  '{"props":{"pageProps":{"records":['
                  '{"consignee":"ABC Import LLC","country":"USA","shipments":120},'
                  '{"consignee":"XYZ Manufacturing","country":"Germany","shipments":30}]}}}'
                  '</script></body></html>')


def _write_tmp(html: str) -> str:
    import tempfile
    fd, p = tempfile.mkstemp(suffix=".html"); os.close(fd)
    open(p, "w", encoding="utf-8").write(html)
    return p


def test_supplies_chain():
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    conn = init_db(path)
    try:
        raw = RawRepository(conn)
        rid = raw.create("importyeti", "http://iy/company/shinwon-felt", None,
                         "Shinwon Felt 180 Shipments", page_type="company_detail")
        raw.update_html_path(rid, _write_tmp(_SUPPLIER_PAGE))
        std_id = StandardCompanyRepository(conn).create(
            rid, "Shinwon Felt", "180 shipments", country="Korea",
            shipment_count=180, source_url="https://www.importyeti.com/search?q=x",
            company_detail_url="https://www.importyeti.com/company/shinwon-felt")
        result = RelationshipBuilder(conn=conn).build([std_id], [rid])
        assert result["customer_queued"] == 2, result
        assert result["status"] == "ok"
        assert len(result["shipment_ids"]) == 2
        edges = [EdgeRepository(conn).get(i) for i in result["edge_ids"]]
        assert all(e["relation"] == "SUPPLIES" for e in edges)
        for e in edges:
            assert e["shipment_id"] and e["raw_page_id"] == rid
            assert e["evidence"].strip() and e["source_url"] and 0 <= e["confidence"] <= 1
        trace = EdgeRepository(conn).trace(edges[0]["id"])
        assert trace["shipment"]["supplier_id"] == edges[0]["source_id"]
        assert trace["raw_page"]["url"] == "http://iy/company/shinwon-felt"
        from data.repository.entity_repository import EntityRepository
        ents = {e["canonical_name"] for e in EntityRepository(conn).list_all()}
        assert {"Shinwon Felt", "ABC Import LLC", "XYZ Manufacturing"} <= ents
    finally:
        conn.close(); os.unlink(path)
