"""真实采集集成测试（需外网）。ImportYeti 搜索页 → Raw 落库 → L5 标准化。

网络不可用时自动 skip，绝不伪造结果。使用权威模块：HttpCollector / TradeStandardizer。
"""
import os, tempfile
import pytest


def test_live_standardizer_roundtrip():
    try:
        from business.trade.collector.http_collector import HttpCollector
        html, url, _ = HttpCollector(timeout=15).fetch(
            "https://www.importyeti.com/search?q=industrial+felt")
    except Exception as e:
        pytest.skip(f"外网不可用: {e}")
    assert "importyeti" in url
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    from data.db import init_db
    from data.repository.raw_repository import RawRepository
    from business.trade.standardizer import TradeStandardizer
    from data.repository.standard_company_repository import StandardCompanyRepository
    conn = init_db(path)
    try:
        raw = RawRepository(conn)
        rid = raw.create("importyeti", url, None, html[:200000], page_type="search_result")
        assert raw.get(rid)["url"]
        # L5 标准化需要 AI；未配置时按预期失败并 skip（禁 fallback）
        try:
            ids = TradeStandardizer(conn=conn).standardize([rid])
        except Exception as e:
            pytest.skip(f"本地AI不可用（L5 主执行依赖）: {type(e).__name__}")
        rows = StandardCompanyRepository(conn).list_by_ids(ids)
        assert all(r["company_name"] for r in rows)
        print(f"live standardized: {len(rows)}")
    finally:
        conn.close(); os.unlink(path)
