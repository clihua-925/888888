"""V41：本模块测试依赖真实 AI（DeepSeek 网页通道）。离线环境自动跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（PSV_LIVE_AI=1 且 LLM_API_KEY 已配置、LLM_BASE_URL 可达）", allow_module_level=True)

"""Test 2：L2 Domain Modeling —— ProductKnowledgeModel 含四大毛毡分类。"""
from business.product.domain_model_service import DomainModelService
from business.product.task_service import TaskService


def test_felt_categories():
    task = TaskService().understand("毛毡")
    model = DomainModelService().build(task)
    names = [c.name for c in model.categories]
    assert "Industrial Felt" in names
    assert "Decorative Felt" in names
    assert "Automotive Felt" in names
    assert "Craft Felt" in names
    assert model.aliases and model.hs_candidates
