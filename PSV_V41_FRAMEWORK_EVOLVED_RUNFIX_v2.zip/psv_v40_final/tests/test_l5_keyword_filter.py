"""V41：含本地AI链路调用，离线跳过（禁 mock AI）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.conftest_live import local_ai_available
if not local_ai_available():
    import pytest
    pytest.skip("需要本地AI（LLM_API_KEY+LLM_BASE_URL 可达）", allow_module_level=True)

import os, tempfile
from data.db import init_db
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from business.trade.standardizer import TradeStandardizer


def _write_tmp(html):
    fd, p = tempfile.mkstemp(suffix=".html")
    os.close(fd)
    open(p, "w", encoding="utf-8").write(html)
    return p


HTML = (
    "<html><title>x</title><body>"
    '<script id="__NEXT_DATA__" type="application/json">'
    '{"props":{"pageProps":{"companies":['
    '{"name":"Shinwon Felt","shipments":180,"country":"Korea"},'
    '{"name":"Industrial Felt supplier"},'
    '{"name":"Industrial Felt manufacturer"},'
    '{"name":"Industrial Felt"},'
    '{"name":"ABC Felt Supplier Ltd","shipments":120,"country":"China","slug":"abc-felt-supplier"},'
    '{"name":"Felt Manufacturer Inc","shipments":60,"country":"USA"}]}}}'
    "</script></body></html>"
)


def test_query_dropped_real_company_with_evidence_kept():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    conn = init_db(path)
    try:
        raw = RawRepository(conn)
        rid = raw.create("importyeti", "http://iy/search", None, "text",
                         keyword="Industrial Felt supplier", page_type="search_result")
        raw.update_html_path(rid, _write_tmp(HTML))
        ids = TradeStandardizer(conn=conn).standardize([rid])
        names = {r["company_name"] for r in StandardCompanyRepository(conn).list_by_ids(ids)}
        # 关键词全部拦截；含角色词但有 country/shipments/url 的真实企业保留
        assert names == {"Shinwon Felt", "ABC Felt Supplier Ltd", "Felt Manufacturer Inc"}, names
        abc = next(r for r in StandardCompanyRepository(conn).list_by_ids(ids)
                   if r["company_name"] == "ABC Felt Supplier Ltd")
        assert abc["country"] == "China" and abc["shipment_count"] == 120
    finally:
        conn.close()
        os.unlink(path)
