"""流水线执行器（框架层）：优先 LangGraph 编译图；无 langgraph 时按节点顺序执行。

多流水线：run_pipeline(user_input, pipeline="trade") 从注册表取 spec；
节点错误策略按 spec.policies（默认 fail_fast = 原行为）。
import orchestration.pipelines_trade 即完成 trade 流水线注册；
新增业务流水线只需在入口 import 对应的 pipelines_xxx 模块。
"""
from __future__ import annotations
from orchestration.graph import _NODES, PIPELINE_ORDER
from orchestration.state import PipelineState
from orchestration.pipeline_registry import NodePolicy, try_get_pipeline


def _wrap(name: str, fn, policy: NodePolicy | None):
    """按错误策略包装节点函数：默认（None/fail_fast）零包装、零行为变化。"""
    if policy is None or policy.on_error == "fail_fast":
        return fn

    def wrapped(state: PipelineState) -> dict:
        try:
            return fn(state)
        except Exception as e:  # noqa: BLE001 —— 策略化容错，错误入 state 不中断流水线
            errs = dict(state.get("node_errors") or {})   # 合并而非覆盖：多节点出错全保留
            errs[name] = f"{type(e).__name__}: {e}"
            return {"node_errors": errs}
    return wrapped


def _resolve(pipeline: str = "trade"):
    spec = try_get_pipeline(pipeline)
    if spec is not None:
        return list(spec.order), spec.nodes, spec.policies
    return list(PIPELINE_ORDER), dict(_NODES), {}   # 兼容：注册表未加载时按 trade 默认


def run_pipeline(user_input: str, pipeline: str = "trade", checkpointer=None) -> PipelineState:
    order, nodes, policies = _resolve(pipeline)
    state: PipelineState = {"user_input": user_input}
    wrapped = {n: _wrap(n, nodes[n], policies.get(n)) for n in order}
    try:
        from orchestration.graph import build_graph
        return build_graph(nodes=wrapped, order=order, checkpointer=checkpointer).invoke(state)
    except ImportError:
        pass
    for name in order:
        state.update(wrapped[name](state))
    return state
