"""贸易数据流水线声明（业务层）：唯一顺序来源仍是 graph.PIPELINE_ORDER。

新增业务流水线时仿照本文件新建 pipelines_xxx.py 并 register() 即可，
graph.py / runner.py / state.py 均不需要改动。
"""
from __future__ import annotations
from orchestration.graph import _NODES, PIPELINE_ORDER
from orchestration.state import PipelineState
from orchestration.pipeline_registry import register, PipelineSpec, NodePolicy

register(PipelineSpec(
    name="trade",
    state_schema=PipelineState,
    order=tuple(PIPELINE_ORDER),
    nodes=dict(_NODES),
    policies={},  # 全部 fail_fast（默认）：单节点失败即中断，保持现有行为
))
