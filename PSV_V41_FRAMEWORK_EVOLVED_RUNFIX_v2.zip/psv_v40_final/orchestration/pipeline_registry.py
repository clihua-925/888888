"""流水线注册表（框架层）：业务流水线在此声明，graph.py 不感知具体业务。

解耦原则：
  - 框架提供：注册、查询、组装所需的全部机制；
  - 业务提供：节点函数、执行顺序、错误策略；
  - 新增第二条业务流水线 = 新建 pipelines_xxx.py 声明并注册，graph.py / runner.py 零改动。
"""
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(frozen=True)
class NodePolicy:
    """节点级错误策略：fail_fast（默认，中断整条流水线）| continue（记录后跳过）。"""
    on_error: str = "fail_fast"


@dataclass(frozen=True)
class PipelineSpec:
    name: str                                  # 流水线名，如 "trade"
    state_schema: type                         # LangGraph state TypedDict
    order: tuple[str, ...]                     # 节点执行顺序（唯一顺序来源）
    nodes: dict                                # node_name -> fn(state) -> dict
    policies: dict[str, NodePolicy] = field(default_factory=dict)


_REGISTRY: dict[str, PipelineSpec] = {}


def register(spec: PipelineSpec) -> None:
    if spec.name in _REGISTRY:
        raise ValueError(f"pipeline already registered: {spec.name}")
    missing = [n for n in spec.order if n not in spec.nodes]
    if missing:
        raise ValueError(f"pipeline {spec.name}: nodes missing in spec.nodes: {missing}")
    _REGISTRY[spec.name] = spec


def get_pipeline(name: str = "trade") -> PipelineSpec:
    return _REGISTRY[name]


def list_pipelines() -> list[str]:
    return sorted(_REGISTRY)


def try_get_pipeline(name: str = "trade") -> PipelineSpec | None:
    return _REGISTRY.get(name)
