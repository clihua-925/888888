"""trade_shipments 读写。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class ShipmentRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, supplier_id: int, buyer_id: int, evidence: str,
               confidence: float, raw_page_id: int,
               product: str | None = None, quantity: str | None = None,
               ship_date: str | None = None, source_url: str | None = None) -> int:
        if not evidence or not evidence.strip():
            raise ValueError("trade_shipments.evidence 禁止为空")
        cur = self._conn.execute(
            "INSERT INTO trade_shipments"
            "(supplier_id,buyer_id,product,quantity,ship_date,source_url,evidence,confidence,raw_page_id,created_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (supplier_id, buyer_id, product, quantity, ship_date, source_url,
             evidence, confidence, raw_page_id, _dt.datetime.utcnow().isoformat()),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def create_idempotent(self, supplier_id: int, buyer_id: int, evidence: str,
                          confidence: float, raw_page_id: int,
                          product: str | None = None, quantity: str | None = None,
                          ship_date: str | None = None, source_url: str | None = None) -> int:
        """同一原始页、双方和产品重复运行时复用已有 Shipment。"""
        row = self._conn.execute(
            "SELECT id FROM trade_shipments WHERE supplier_id=? AND buyer_id=? AND raw_page_id=? "
            "AND COALESCE(product,'')=COALESCE(?, '') AND COALESCE(ship_date,'')=COALESCE(?, '') "
            "ORDER BY id LIMIT 1",
            (supplier_id, buyer_id, raw_page_id, product, ship_date)).fetchone()
        if row:
            return int(row["id"])
        return self.create(supplier_id, buyer_id, evidence, confidence, raw_page_id,
                           product, quantity, ship_date, source_url)

    def get(self, shipment_id: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM trade_shipments WHERE id=?", (shipment_id,)).fetchone()
        return dict(row) if row else None

    def list_by_ids(self, ids: list[int]) -> list[dict]:
        if not ids:
            return []
        ph = ",".join("?" * len(ids))
        rows = self._conn.execute(
            f"SELECT * FROM trade_shipments WHERE id IN ({ph}) ORDER BY id", ids).fetchall()
        return [dict(r) for r in rows]

    def list_by_supplier(self, entity_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_shipments WHERE supplier_id=? ORDER BY id", (entity_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def list_by_buyer(self, entity_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM trade_shipments WHERE buyer_id=? ORDER BY id", (entity_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def list_all(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM trade_shipments ORDER BY id").fetchall()
        return [dict(r) for r in rows]
