"""candidate_companies 读写（L4 搜索结果解析输出）。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class CandidateRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, source_page_id: int, company_name: str, keyword: str | None = None,
               company_url: str | None = None, country: str | None = None,
               shipment_count: int | None = None, page_number: int = 1) -> int:
        cur = self._conn.execute(
            "INSERT INTO candidate_companies"
            "(source_page_id,keyword,company_name,company_url,country,shipment_count,page_number,created_at)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (source_page_id, keyword, company_name, company_url, country,
             shipment_count, page_number, _dt.datetime.utcnow().isoformat()))
        self._conn.commit()
        return int(cur.lastrowid)

    def list_by_source(self, source_page_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM candidate_companies WHERE source_page_id=? ORDER BY id",
            (source_page_id,)).fetchall()
        return [dict(r) for r in rows]

    def list_by_keyword(self, keyword: str, limit: int = 50) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM candidate_companies WHERE keyword=? ORDER BY id LIMIT ?",
            (keyword, limit)).fetchall()
        return [dict(r) for r in rows]

    def top_for_keyword(self, keyword: str, limit: int = 10) -> list[dict]:
        """详情页选择依据：shipment 数量降序（同量按 id），与关键词相关性由 L3 保证。"""
        rows = self._conn.execute(
            "SELECT * FROM candidate_companies WHERE keyword=?"
            " ORDER BY COALESCE(shipment_count,0) DESC, id LIMIT ?",
            (keyword, limit)).fetchall()
        return [dict(r) for r in rows]
