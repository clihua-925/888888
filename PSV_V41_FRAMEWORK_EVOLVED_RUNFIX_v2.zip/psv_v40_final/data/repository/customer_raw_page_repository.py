"""customer_raw_pages 读写（L6 浏览器取证页）。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class CustomerRawPageRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, customer_id: int, url: str | None = None, page_text: str | None = None,
               screenshot: str | None = None) -> int:
        cur = self._conn.execute(
            "INSERT INTO customer_raw_pages(customer_id,url,page_text,screenshot,timestamp)"
            " VALUES(?,?,?,?,?)",
            (customer_id, url, page_text, screenshot, _dt.datetime.utcnow().isoformat()))
        self._conn.commit()
        return int(cur.lastrowid)

    def list_by_customer(self, customer_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM customer_raw_pages WHERE customer_id=? ORDER BY id",
            (customer_id,)).fetchall()
        return [dict(r) for r in rows]
