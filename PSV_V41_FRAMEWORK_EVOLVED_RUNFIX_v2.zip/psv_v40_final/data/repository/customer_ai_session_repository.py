"""customer_ai_sessions 读写（L6 DeepSeek 网页 AI 调用记录）。唯一入口。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class CustomerAISessionRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def create(self, customer_id: int, prompt: str, deepseek_response: str | None = None,
               browser_session: str | None = None) -> int:
        cur = self._conn.execute(
            "INSERT INTO customer_ai_sessions(customer_id,prompt,deepseek_response,created_time,browser_session)"
            " VALUES(?,?,?,?,?)",
            (customer_id, prompt, deepseek_response,
             _dt.datetime.utcnow().isoformat(), browser_session))
        self._conn.commit()
        return int(cur.lastrowid)

    def list_by_customer(self, customer_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM customer_ai_sessions WHERE customer_id=? ORDER BY id",
            (customer_id,)).fetchall()
        return [dict(r) for r in rows]
