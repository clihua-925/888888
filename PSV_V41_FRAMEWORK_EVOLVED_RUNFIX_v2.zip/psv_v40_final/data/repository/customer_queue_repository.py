"""customer_queue 读写（L6 任务队列：pending/processing/success/failed）。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
import socket
import uuid
from data.db import connect


class CustomerQueueRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def enqueue(self, customer_name: str, country: str | None = None,
                raw_page_id: int | None = None, task_id: str | None = None) -> int:
        existing = self._conn.execute(
            "SELECT id FROM customer_queue WHERE customer_name=? AND COALESCE(task_id,'')=COALESCE(?, '') "
            "AND status IN ('pending','processing','success') ORDER BY id LIMIT 1",
            (customer_name, task_id)).fetchone()
        if existing:
            return int(existing["id"])
        now = _dt.datetime.utcnow().isoformat()
        cur = self._conn.execute(
            "INSERT INTO customer_queue(customer_name,country,raw_page_id,task_id,status,created_at,updated_at)"
            " VALUES(?,?,?,?, 'pending',?,?)",
            (customer_name, country, raw_page_id, task_id, now, now))
        self._conn.commit()
        return int(cur.lastrowid)

    def set_status(self, qid: int, status: str, profile_id: int | None = None,
                   error: str | None = None, increment: bool = True) -> None:
        bump = "attempts=attempts+1," if increment else ""
        self._conn.execute(
            f"UPDATE customer_queue SET status=?, profile_id=?, error=?,"
            f" {bump} locked_by=NULL, lease_until=NULL, updated_at=? WHERE id=?",
            (status, profile_id, error, _dt.datetime.utcnow().isoformat(), qid))
        self._conn.commit()

    def get_attempts(self, qid: int) -> int:
        row = self._conn.execute("SELECT attempts FROM customer_queue WHERE id=?", (qid,)).fetchone()
        return int(row["attempts"]) if row else 0

    def list_by_status(self, status: str, limit: int = 100) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM customer_queue WHERE status=? ORDER BY id LIMIT ?", (status, limit)).fetchall()
        return [dict(r) for r in rows]

    def claim_pending(self, limit: int = 50, owner: str | None = None,
                      lease_seconds: int = 300, task_id: str | None = None) -> list[dict]:
        """原子领取队列任务，兼容单模型串行执行和进程重启恢复。"""
        owner = owner or f"{socket.gethostname()}:{uuid.uuid4().hex[:8]}"
        now = _dt.datetime.utcnow()
        now_s = now.isoformat()
        lease_s = (now + _dt.timedelta(seconds=lease_seconds)).isoformat()
        where = "(status='pending' OR (status='processing' AND lease_until IS NOT NULL AND lease_until<?))"
        args: list = [now_s]
        if task_id is not None:
            where += " AND task_id=?"
            args.append(task_id)
        self._conn.execute("BEGIN IMMEDIATE")
        try:
            rows = self._conn.execute(
                f"SELECT * FROM customer_queue WHERE {where} ORDER BY id LIMIT ?",
                (*args, limit)).fetchall()
            out = []
            for row in rows:
                self._conn.execute(
                    "UPDATE customer_queue SET status='processing', attempts=attempts+1, "
                    "locked_by=?, lease_until=?, updated_at=? WHERE id=?",
                    (owner, lease_s, now_s, row["id"]))
                item = dict(row)
                item["status"] = "processing"
                item["attempts"] = int(item.get("attempts") or 0) + 1
                item["locked_by"] = owner
                item["lease_until"] = lease_s
                out.append(item)
            self._conn.commit()
            return out
        except Exception:
            self._conn.rollback()
            raise

    def try_acquire_worker_lease(self, name: str, owner: str,
                                 lease_seconds: int = 300) -> bool:
        """跨进程单 Worker 租约，避免 uvicorn 多进程重复消费本地模型。"""
        now = _dt.datetime.utcnow()
        now_s = now.isoformat()
        lease_s = (now + _dt.timedelta(seconds=lease_seconds)).isoformat()
        self._conn.execute("BEGIN IMMEDIATE")
        try:
            row = self._conn.execute(
                "SELECT owner, lease_until FROM customer_worker_leases WHERE name=?", (name,)).fetchone()
            if row and row["owner"] != owner and row["lease_until"] > now_s:
                self._conn.rollback()
                return False
            self._conn.execute(
                "INSERT INTO customer_worker_leases(name,owner,lease_until,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(name) DO UPDATE SET owner=excluded.owner, lease_until=excluded.lease_until, "
                "updated_at=excluded.updated_at",
                (name, owner, lease_s, now_s))
            self._conn.commit()
            return True
        except Exception:
            self._conn.rollback()
            raise

    def stats(self, task_id: str | None = None) -> dict:
        if task_id is None:
            rows = self._conn.execute(
                "SELECT status, COUNT(*) AS n FROM customer_queue GROUP BY status").fetchall()
        else:
            rows = self._conn.execute(
                "SELECT status, COUNT(*) AS n FROM customer_queue WHERE task_id=? GROUP BY status",
                (task_id,)).fetchall()
        return {r["status"]: r["n"] for r in rows}
