"""持久化任务运行元数据与节点检查点。

检查点只保存 JSON 可表达的状态；恢复时由 TaskManager 将已知 contracts
重新构造成 Pydantic 对象。这样服务重启后至少可以恢复到最近完成的节点。
"""
from __future__ import annotations

import datetime as _dt
import json
import sqlite3
from data.db import connect


def _now() -> str:
    return _dt.datetime.utcnow().isoformat()


class TaskRunRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def upsert(self, task_id: str, user_input: str, status: str,
               stages: list[dict], state: dict | None = None,
               error: str | None = None, error_stage: str | None = None,
               created_at: str | None = None) -> None:
        now = _now()
        self._conn.execute(
            "INSERT INTO task_runs(id,input,status,stages_json,state_json,error,error_stage,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET status=excluded.status, stages_json=excluded.stages_json, "
            "state_json=excluded.state_json, error=excluded.error, error_stage=excluded.error_stage, "
            "updated_at=excluded.updated_at",
            (task_id, user_input, status, json.dumps(stages, ensure_ascii=False),
             json.dumps(state, ensure_ascii=False) if state is not None else None,
             error, error_stage, created_at or now, now),
        )
        self._conn.commit()

    def get(self, task_id: str) -> dict | None:
        row = self._conn.execute("SELECT * FROM task_runs WHERE id=?", (task_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["stages"] = json.loads(d.pop("stages_json") or "[]")
        d["state"] = json.loads(d.pop("state_json") or "null")
        return d

    def list_incomplete(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT id FROM task_runs WHERE status IN ('queued','running') ORDER BY created_at").fetchall()
        return [self.get(r["id"]) for r in rows]
