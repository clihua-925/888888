# PSV V41 — Supply Chain Knowledge Agent（LangGraph 十层流水线）

## 分层

```
orchestration/   LangGraph 十阶段流程，节点只读 state → 调 service → 写 state
contracts/       全部数据结构（pydantic）：task / product / search_plan / extracted / entities / edges
business/        全部业务逻辑唯一住处（product / trade / decision / shared）
ai/              LLM 调用与 Prompt 唯一住处（business 只能经 ai/client）
data/repository/ 数据库唯一访问点（raw → extracted → entity → edge 四层表）
storage/         Raw 文件落盘（HTML 等），db 只存路径
tests/           test_contracts.py / test_repository.py
```

## 依赖红线

- orchestration 不得出现：网络 / HTML解析 / db / LLM / prompt
- business 不得直接访问 db（只能经 repository）、不得直接调 LLM（只能经 ai/client）
- 只有 repository 允许访问数据库
- Edge 必须有非空 evidence（contracts + 表约束 + repository 三层防御）

## 运行

```bash
pip install -r requirements.txt        # pydantic / langgraph / sqlalchemy / playwright / pytest
pytest tests/ -v                       # 骨架验收（当前 12/12）
python -c "from orchestration.graph import build_graph; build_graph(); print('graph OK')"
```

建库：`from data.db import init_db; init_db()`

## 阶段路线

- Phase 1 ✅ 骨架（本目录）
- Phase 2  L1–L3：Task Object / Product Knowledge Model / Search Plan（+ ai/client 接入）
- Phase 3  L4–L5：Raw 落库 + AI 抽取
- Phase 4  L6–L7：实体解析 + 关系构建（带 evidence/confidence/source_url）
- Phase 5  L8–L10：知识融合 + 图谱智能 + 商业决策输出

---

# PSV V40.3 产品化

## 一键启动

Windows：双击 `start_psv.bat`（首次自动执行 `install.bat`）
Linux/macOS：`./start_psv.sh`

启动后浏览器自动打开 `http://localhost:8000`。默认仅监听本机；任务检查点与 L6 客户队列均持久化到 SQLite。

## API

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/task/create` | `{product, country, goal}` → `{task_id}` |
| GET | `/task/status/{id}` | 十阶段实时状态 |
| GET | `/task/result/{id}` | 产品模型 / 企业列表 / 商业报告 |
| GET | `/graph/{id}` | Cytoscape.js 图谱元素（节点可点击） |

## 目录新增

```
api/           FastAPI 应用 + 任务管理器（后台线程执行十阶段流水线）
frontend/      单页应用（产品输入 → 阶段状态 → 产品知识/企业/贸易关系/图谱/报告）
logs/          运行日志
start_psv.*    一键启动（环境检查 → 建库 → 起服务 → 开浏览器）
install.*      安装（venv → 依赖 → playwright → 建库 → 生成 .env）
.env.example   LLM_API_KEY / DATABASE_URL / CHROME_CDP_URL / IMPORTYETI_CONFIG / MODEL_NAME
```

## 浏览器采集（可选增强）

启动 Chrome 时加 `--remote-debugging-port=9222`，CollectorManager 将优先
使用真实浏览器（可处理懒加载/截图）；不可用时自动降级 HTTP 并留痕 collector_failures。

## V41 快速开始（双击启动）
1. 安装依赖（仅首次）：`pip install -r requirements.txt`
2. 双击 `启动-PSV41.bat`：自动拉起 AI 浏览器（CDP :9222）+ 后端（:8000）+ 浏览器打开 UI
3. 手工启动备选：`python run_services.py`（仅后端），访问 http://localhost:8000

## 运行约束与恢复

- 本地 llama.cpp 按有限队列串行调用，后台 Worker 使用 SQLite 租约避免多进程重复消费。
- L6 客户补全按 `task_id` 隔离；L7 关系写入、Shipment 和 Edge 使用幂等检查，重复运行不会重复累计。
- TaskManager 在 `task_runs` 表中保存阶段状态和最近检查点。服务重启后会从最近完成的阶段继续执行。
- 证据必须能够在原始页面文本中定位；无法回溯的 AI 证据会被丢弃并记录为 `EvidenceNotFound`。
