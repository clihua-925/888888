"""网页AI通道工厂：按 PSV_WEBAI_PROVIDER 选择 ChatGPT / DeepSeek 网页版。

L6 客户背调的网页 AI 通道统一入口。默认 gpt（ChatGPT，会话复用版）；
deepseek 为旧版（每次新开会话，易触发风控，仅兼容保留）。
"""
from __future__ import annotations
from business.shared import config


def create_web_agent():
    if config.WEBAI_PROVIDER == "deepseek":
        from ai.deepseek_web_agent import DeepSeekWebAgent
        return DeepSeekWebAgent()
    if config.WEBAI_PROVIDER != "gpt":
        raise ValueError(f"不支持的网页 AI provider: {config.WEBAI_PROVIDER}")
    from ai.gpt_web_agent import GPTWebAgent
    return GPTWebAgent.shared()      # 单例复用：跨背调任务共用同一 tab/会话


class WebChatError(RuntimeError):
    pass
