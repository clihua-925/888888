"""V41 统一网页 AI 通道（DeepSeek 网页版，CDP）：CDP 控制本地 Chrome（psv_chrome_profile，保持登录态）操作 DeepSeek 网页版。

铁律：
  - 不调用任何 LLM API（不走 192.168.1.26:8081，不走 api.deepseek.com）
  - 只通过 Playwright/CDP 连接 :9222 的 Chrome，在 chat.deepseek.com 网页上提问并读取回复
  - 会话式 start/stop：只关自己的页面，绝不关闭共享浏览器
  - 打不开网页/拿不到回复 → 抛 AIExecutionError（上层记 deepseek_browser_error，不伪造资料）
测试注入 FakeDeepSeekClient 即可离线验证全链。
"""
from __future__ import annotations
import json
import re
import time

from business.shared import config

DEEPSEEK_URL = "https://chat.deepseek.com/"
_INPUT_SELECTORS = ["textarea#chat-input", "textarea[placeholder*='问']", "div[contenteditable='true']"]
_REPLY_SELECTORS = [".ds-markdown", ".markdown-body", "[class*='markdown']"]


class AIExecutionError(RuntimeError):
    pass


def parse_loose_json(text: str) -> dict:
    """从 DeepSeek 回复中稳健提取 JSON 对象（容忍 ```json 围栏与前后说明文字）。"""
    t = (text or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```(json)?", "", t).strip("`").strip()
    s, e = t.find("{"), t.rfind("}")
    if s < 0 or e <= s:
        raise AIExecutionError(f"DeepSeek 回复不含 JSON: {(text or '')[:120]}")
    try:
        return json.loads(t[s:e + 1])
    except json.JSONDecodeError as ex:
        raise AIExecutionError(f"DeepSeek 回复 JSON 解析失败: {ex}") from ex


class DeepSeekWebAgent:
    """真实 CDP 客户端。ask(prompt) -> 回复原文。"""

    def __init__(self, cdp_url: str | None = None, timeout_ms: int | None = None) -> None:
        self._cdp_url = cdp_url or config.CDP_URL
        self._timeout = timeout_ms or config.BROWSER_TIMEOUT_MS
        self._pw = self._browser = self._ctx = self._page = None

    # ---- 会话生命周期（与 BrowserDriver 同一铁律：不关共享浏览器）----
    def start(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as e:
            raise AIExecutionError("playwright 未安装") from e
        self._pw = sync_playwright().start()
        try:
            self._browser = self._pw.chromium.connect_over_cdp(self._cdp_url, timeout=self._timeout)
        except Exception as e:
            self._pw.stop()
            self._pw = None
            raise AIExecutionError(f"无法连接 Chrome CDP {self._cdp_url}: {e}") from e
        self._ctx = self._browser.contexts[0] if self._browser.contexts else self._browser.new_context()

    def stop(self) -> None:
        try:
            if self._page and not self._page.is_closed():
                self._page.close()
        except Exception:
            pass
        self._page = None
        if self._pw is not None:
            try:
                self._pw.stop()
            except Exception:
                pass
        self._pw = self._browser = self._ctx = None

    # ---- 网页操作 ----
    def ask(self, prompt: str) -> str:
        self.start()
        try:
            self._page = self._ctx.new_page()
            page = self._page
            page.goto(DEEPSEEK_URL, timeout=self._timeout, wait_until="domcontentloaded")
            page.wait_for_timeout(2500)
            box = None
            for sel in _INPUT_SELECTORS:
                loc = page.locator(sel).first
                if loc.count() > 0:
                    box = loc
                    break
            if box is None:
                raise AIExecutionError("DeepSeek 页面未找到输入框（可能未登录或页面改版）")
            box.click()
            box.fill(prompt)
            page.keyboard.press("Enter")
            # 等待回复出现并稳定
            reply_sel = None
            for sel in _REPLY_SELECTORS:
                if page.locator(sel).count() > 0:
                    reply_sel = sel
                    break
            if reply_sel is None:
                raise AIExecutionError("DeepSeek 回复容器未出现")
            last_len = 0
            stable = 0
            for _ in range(60):  # 最长 ~120s（本地 70B 推理慢）
                page.wait_for_timeout(2000)
                text = page.locator(reply_sel).last.inner_text()
                if len(text) == last_len and len(text) > 10:
                    stable += 1
                    if stable >= 3:
                        return text
                else:
                    stable = 0
                last_len = len(text)
            return page.locator(reply_sel).last.inner_text()
        except AIExecutionError:
            raise
        except Exception as e:
            raise AIExecutionError(f"DeepSeek 网页操作失败: {e}") from e
        finally:
            self.stop()

    def browser_session_text(self) -> str:
        return json.dumps({"engine": "deepseek-web", "cdp": self._cdp_url,
                           "url": DEEPSEEK_URL}, ensure_ascii=False)
