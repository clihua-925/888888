"""GPT 网页版通道（ChatGPT，CDP 复用会话版）。

与 DeepSeekWebAgent 的关键差异（防风控设计）：
  - 会话复用：类级单例，CDP 连接 + 页面 tab 全程复用，同一对话连续提问，
    绝不每次 ask 都新开页面/重连浏览器（旧版 DeepSeek 每次 new_page 是风控主因）
  - 人机节奏：ask 之间随机 jitter（2-5s），等待回复用 DOM 稳定检测而非固定 sleep
  - 验证感知：检测登录墙/验证码时截图留证并抛错等人工，不硬闯
铁律：只连 :9222 共享 Chrome（psv_chrome_profile 保持登录态），绝不关共享浏览器。
"""
from __future__ import annotations
import json
import random
import re
import time
from pathlib import Path as _Path

from business.shared import config

_INPUT_SEL = "#prompt-textarea"                      # contenteditable 输入框
_REPLY_SEL = '[data-message-author-role="assistant"]'  # assistant 消息
_STOP_SEL = '[data-testid="stop-button"]'              # 生成中标志
_BLOCK_HINTS = ("sign in", "log in", "captcha", "verify you are human",
                "Cloudflare", "安全验证", "登录")


class GPTWebError(RuntimeError):
    pass


class GPTWebAgent:
    _shared: "GPTWebAgent | None" = None   # 类级单例：worker 跨轮复用

    @classmethod
    def shared(cls) -> "GPTWebAgent":
        if cls._shared is None:
            cls._shared = cls()
        return cls._shared

    def __init__(self, cdp_url: str | None = None, timeout_ms: int | None = None) -> None:
        self._cdp_url = cdp_url or config.CDP_URL
        self._timeout = timeout_ms or config.BROWSER_TIMEOUT_MS
        self._pw = self._browser = self._ctx = self._page = None
        self._connected = False

    # ---- 连接（幂等）：复用已有 tab；只连一次 ----
    def start(self) -> None:
        if self._connected and self._ctx is not None:
            return
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as e:
            raise GPTWebError("playwright 未安装") from e
        self._pw = sync_playwright().start()
        try:
            self._browser = self._pw.chromium.connect_over_cdp(self._cdp_url, timeout=self._timeout)
        except Exception as e:
            self._pw.stop(); self._pw = None
            raise GPTWebError(f"无法连接 Chrome CDP {self._cdp_url}: {e}") from e
        self._ctx = self._browser.contexts[0] if self._browser.contexts else self._browser.new_context()
        self._connected = True

    # ---- 提问（同会话续问，保留上下文）----
    def ask(self, prompt: str) -> str:
        self.start()
        # 每次客户补全都创建独立 tab，避免复用同一对话造成跨客户上下文污染；
        # CDP/Playwright 连接仍复用，符合本地模型串行队列约束。
        page = self._ctx.new_page()
        self._page = page
        try:
            page.goto(config.CHATGPT_URL, timeout=self._timeout, wait_until="domcontentloaded")
            page.wait_for_timeout(3000)
            time.sleep(random.uniform(2.0, 5.0))   # 人机节奏：随机间隔，不连发
            box = page.locator(_INPUT_SEL).first
            if box.count() == 0:
                self._raise_blocked("未找到输入框（可能未登录或触发验证）")
            # 竞态修复：发送【前】记录 assistant 消息数，只接受新出现的回复。
            base_count = page.locator(_REPLY_SEL).count()
            box.click()
            box.fill("")
            page.keyboard.insert_text(prompt)
            page.keyboard.press("Enter")
            deadline = time.monotonic() + self._timeout / 1000
            last_text, stable = "", 0
            while time.monotonic() < deadline:
                page.wait_for_timeout(2000)
                if page.locator(_STOP_SEL).count() > 0:
                    continue
                msgs = page.locator(_REPLY_SEL)
                if msgs.count() <= base_count:
                    continue
                text = msgs.last.inner_text()
                if text == last_text and len(text) > 10:
                    stable += 1
                    if stable >= 2:
                        return text
                else:
                    stable = 0
                last_text = text
            raise GPTWebError(f"GPT 回复等待超时（{self._timeout}ms）")
        finally:
            try:
                if not page.is_closed():
                    page.close()
            except Exception:
                pass
            self._page = None

    def _raise_blocked(self, reason: str):
        shot = ""
        try:
            # 项目根由模块位置推导（ai/ 的上级），不依赖 config 中不存在的常量
            d = _Path(__file__).resolve().parent.parent / "storage" / "files"
            d.mkdir(parents=True, exist_ok=True)
            f = d / f"webai_blocked_{int(time.time())}.png"
            self._page.screenshot(path=str(f))
            shot = str(f)
        except Exception:
            pass
        raise GPTWebError(f"GPT 网页受阻：{reason}（截图: {shot}），请人工在浏览器完成验证/登录后重试")

    def stop(self) -> None:
        """仅服务关闭时调用：断开 Playwright，不关页面不关浏览器。"""
        self._connected = False
        if self._pw is not None:
            try: self._pw.stop()
            except Exception: pass
        self._pw = self._browser = self._ctx = self._page = None
        GPTWebAgent._shared = None

    def browser_session_text(self) -> str:
        return json.dumps({"engine": "gpt-web", "cdp": self._cdp_url,
                           "url": config.CHATGPT_URL}, ensure_ascii=False)
