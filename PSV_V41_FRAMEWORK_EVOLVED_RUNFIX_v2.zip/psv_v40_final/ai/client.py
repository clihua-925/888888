"""统一 LLM 出入口。Business 层禁止直接 import 任何模型 SDK，只能调这里。

配置（环境变量）：
  PSV_LLM_API_KEY / OPENAI_API_KEY   有值则启用真实 LLM 调用
  PSV_LLM_BASE_URL                   默认 https://api.openai.com/v1
  PSV_LLM_MODEL                      默认 gpt-4o-mini
未配置时 configured=False，业务层走确定性规则路径（不会伪造 AI 结果）。
"""
from __future__ import annotations
import json
import time
import os
import urllib.request
from typing import Any


class AIClientError(RuntimeError):
    pass


def _load_dotenv_fallback() -> None:
    """AIClient 自身兜底加载 .env（独立于 config.py，防导入顺序问题）；零依赖。
    多路径（修复1）：PSV_V40/.env 优先，psv_v40_final/.env 兜底。"""
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for cand in (os.path.abspath(os.path.join(base, "..", ".env")),
                 os.path.join(base, ".env")):
        if os.path.isfile(cand):
            _env_path_to_load[0] = cand
            break
    try:
        with open(_env_path_to_load[0], encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                k = k.strip()
                v = v.strip().strip('"').strip("'")
                if k and k not in os.environ:
                    os.environ[k] = v
    except OSError:
        pass


_env_path_to_load = [""]


class AIClient:
    def __init__(self, api_key: str | None = None, base_url: str | None = None,
                 model: str | None = None, timeout: int | None = None) -> None:
        _load_dotenv_fallback()
        # 与原系统（v30.5 settings.py）变量名兼容：LLM_API_KEY / LLM_BASE_URL / LLM_MODEL / LLM_TIMEOUT
        self._api_key = (api_key or os.getenv("PSV_LLM_API_KEY")
                         or os.getenv("LLM_API_KEY") or os.getenv("OPENAI_API_KEY"))
        self._base_url = (base_url or os.getenv("PSV_LLM_BASE_URL")
                          or os.getenv("LLM_BASE_URL")
                          or "https://api.openai.com/v1").rstrip("/")
        # 优先级：PSV_LLM_MODEL > LLM_MODEL > MODEL_NAME（.env.example 使用的键名）> 默认
        self._model = (model or os.getenv("PSV_LLM_MODEL") or os.getenv("LLM_MODEL")
                       or os.getenv("MODEL_NAME") or "gpt-4o-mini")
        if timeout is None:
            try:
                timeout = int(os.getenv("PSV_LLM_TIMEOUT") or os.getenv("LLM_TIMEOUT") or "480")
            except ValueError:
                timeout = 480
        self._timeout = timeout

    @property
    def configured(self) -> bool:
        return bool(self._api_key)

    def chat(self, prompt: str, context: dict[str, Any] | None = None,
             timeout: float | None = None, max_tokens: int | None = None) -> dict[str, Any]:
        """调用 LLM，要求模型返回 JSON；返回解析后的 dict。未配置或未成功时抛 AIClientError。"""
        if not self.configured:
            base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            cands = [os.path.abspath(os.path.join(base, "..", ".env")),
                     os.path.join(base, ".env")]
            found = [p for p in cands if os.path.isfile(p)]
            raise AIClientError(
                "LLM 未配置。请按顺序检查：\n"
                "  1) 是否存在 .env 文件（PSV_V40\\.env 或 psv_v40_final\\.env），"
                f"当前找到: {found or '无'}\n"
                "  2) .env 里的 LLM_API_KEY 是否非空\n"
                "  3) 是否已重启 backend（.env 修改后需重启）\n"
                f"  当前读取: LLM_API_KEY={'<空>' if not self._api_key else '<已设置>'}, "
                f"LLM_BASE_URL={self._base_url}")
        content = (
            prompt
            + "\n\n[上下文]\n"
            + json.dumps(context or {}, ensure_ascii=False)
            + "\n\n只输出 JSON，不要输出其他文字。"
        )
        body: dict[str, Any] = {
            "model": self._model,
            "messages": [{"role": "user", "content": content}],
            "temperature": 0.2,
            # 质量优先开思维链：不启用服务端 json_object 语法约束（会压制推理链），
            # 模型可自由"先分析后输出 JSON"，由 _parse_json_loose 稳健提取。
            # max_tokens 提高 2-3 倍，防止长思考被服务端默认上限截断。
        }
        if max_tokens:
            body["max_tokens"] = max_tokens
        payload = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            f"{self._base_url}/chat/completions", data=payload,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self._api_key}"},
        )
        try:
            deadline = time.monotonic() + (timeout or self._timeout)
            with urllib.request.urlopen(req, timeout=timeout or self._timeout) as resp:
                # 分块读并检查累计耗时：覆盖"服务端挂死/无限生成"场景——
                # socket timeout 只管单次 recv 空闲，管不住连接活着但响应永不结束。
                chunks: list[bytes] = []
                while True:
                    if time.monotonic() > deadline:
                        raise TimeoutError(f"LLM 响应超时（{timeout or self._timeout}s）：服务端未在时限内完成")
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    chunks.append(chunk)
                data = json.loads(b"".join(chunks).decode("utf-8"))
            text = data["choices"][0]["message"]["content"]
        except Exception as e:  # 网络/解析/限流统一上抛（修复4：带 URL 与可执行建议）
            raise AIClientError(
                f"LLM 调用失败: {e}\n"
                f"  URL: {self._base_url}/chat/completions\n"
                f"  建议: 确认服务可达（curl {self._base_url}/models 应返回 JSON）") from e
        return _parse_json_loose(text)

    def extract(self, prompt: str, raw_text: str) -> dict[str, Any]:
        """L5 专用：对单页 Raw 文本做结构化抽取，返回 {"candidates": [...]}。"""
        return self.chat(prompt, {"raw_text": raw_text[:8000]})

    def model_version(self) -> str:
        return f"llm:{self._model}" if self.configured else "none"


def _parse_json_loose(text: str) -> dict[str, Any]:
    """从 LLM 输出中稳健提取 JSON 对象（容忍 ```json 围栏与前后噪音）。"""
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`")
        if t.lower().startswith("json"):
            t = t[4:]
    s, e = t.find("{"), t.rfind("}")
    if s < 0 or e <= s:
        raise AIClientError(f"LLM 输出不是 JSON: {text[:200]}")
    try:
        return json.loads(t[s:e + 1])
    except json.JSONDecodeError as ex:
        raise AIClientError(f"LLM 输出 JSON 解析失败: {ex}") from ex
