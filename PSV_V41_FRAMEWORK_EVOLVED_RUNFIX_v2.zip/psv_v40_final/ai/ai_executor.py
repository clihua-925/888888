"""AI 调度器：按节点类型分流（V41 修正版）。

  本地AI节点（理解/推理/规划/分析）：L1 L2 L3 L5 L7 L8 L9 L10  -> LocalAIExecutor
  浏览器决策：L4_page_advisor                                     -> LocalAIExecutor（本地推理，非网页）
  网页AI增强：L6_customer_completion                               -> DeepSeekWebAgent（唯一网页节点）
审计记录 ai_type：local_ai / browser_agent / deepseek_web。
失败重试3次后抛 AIExecutionFailed（FAILED），禁止 fallback 假结果。
"""
from __future__ import annotations
import json
import sqlite3
import time
from typing import Any, Callable

from ai.prompt_manager import get
from ai.web_chat import create_web_agent
from ai.deepseek_web_agent import DeepSeekWebAgent, AIExecutionError, parse_loose_json
from ai.local_ai_executor import LocalAIExecutor
from ai.ai_audit_log import AIAuditLog
from ai.ai_memory import remember

LOCAL_NODES = {"L1_task_understanding", "L2_domain_modeling", "L3_discovery_planning",
               "L4_page_advisor", "L4_explore_decision", "L5_standardization", "L7_trade_discovery",
               "L8_fusion", "L9_intelligence", "L10_decision"}
WEB_NODES = {"L6_customer_completion"}


class AIExecutionFailed(RuntimeError):
    pass


class AIExecutor:
    MAX_RETRY = 3

    def __init__(self, local: LocalAIExecutor | None = None, web: DeepSeekWebAgent | None = None,
                 audit: AIAuditLog | None = None, conn: sqlite3.Connection | None = None) -> None:
        self._local = local or LocalAIExecutor(conn=conn)
        self._web = web or create_web_agent()   # V42: 按 PSV_WEBAI_PROVIDER 选择（默认 gpt 会话复用）
        self._audit = audit or AIAuditLog(conn)
        self._last: dict = {}
        self._conn = conn

    @staticmethod
    def ai_type(node: str) -> str:
        if node in WEB_NODES:
            # V42: 审计 provider 按实际网页通道记录（gpt_web / deepseek_web），不伪装
            from business.shared import config as _cfg
            return "gpt_web" if _cfg.WEBAI_PROVIDER == "gpt" else "deepseek_web"
        if node == "L4_page_advisor":
            return "browser_agent"
        return "local_ai"

    def execute(self, node: str, context: dict[str, Any],
                validate: Callable[[dict], Any] | None = None) -> Any:
        if node in LOCAL_NODES:  # 本地AI（含 L4 浏览器决策）
            return self._local.execute(node, get(node), context, validate)
        if node in WEB_NODES:    # 唯一网页AI节点：L6
            return self._run_web(node, context, validate)
        raise KeyError(f"未注册节点: {node}")

    def _run_web(self, node: str, context: dict, validate) -> dict:
        NL = chr(10)
        ctx_json = json.dumps(context, ensure_ascii=False)[:12000]
        prompt = get(node) + NL*2 + "[上下文]" + NL + ctx_json + NL*2 + "只输出 JSON。"
        last_err = ""
        for _ in range(1, self.MAX_RETRY + 1):
            t0 = time.time()
            try:
                raw = self._web.ask(prompt)
                data = parse_loose_json(raw)
                if validate is not None:
                    data = validate(data)
                self._audit.record(node, prompt, raw, True, provider=self.ai_type(node),
                                   duration_s=round(time.time() - t0, 2))
                remember(node, data, task_id=str(context.get("task_id") or "global"))
                self._last = {"prompt": prompt, "response": raw}
                return data
            except Exception as e:
                last_err = f"{type(e).__name__}: {e}"
                self._audit.record(node, prompt, None, False, provider=self.ai_type(node),
                                   error=last_err[:400], duration_s=round(time.time() - t0, 2))
        raise AIExecutionFailed(f"{node} 网页AI重试{self.MAX_RETRY}次仍失败: {last_err}")
