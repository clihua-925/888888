"""L4 浏览器决策 Agent：AI 决定页面下一步动作，规则只做边界护栏。

动作空间被规则限死：search_input / click / scroll / read / stop；
页面数、超时、存储格式由规则控制；AI 不判断公司价值。
"""
from __future__ import annotations
from ai.ai_executor import AIExecutor

ALLOWED_ACTIONS = {"search_input", "click", "scroll", "read", "stop"}


class BrowserAIAdvisor:
    def __init__(self, executor: AIExecutor | None = None) -> None:
        self._ex = executor or AIExecutor()

    def decide(self, page_text: str, url: str, keyword: str, page_number: int,
               history: list[str]) -> dict:
        """AI 决策下一步。规则护栏：动作必须在白名单内，否则回 stop。"""
        ctx = {"url": url, "keyword": keyword, "page_number": page_number,
               "page_text": page_text[:4000], "history": history[-10:]}
        out = self._ex.execute("L4_page_advisor", ctx, validate=self._validate)
        return out

    @staticmethod
    def _validate(d: dict) -> dict:
        if d.get("action") not in ALLOWED_ACTIONS:
            d["action"] = "stop"  # 规则：越界动作强制停止
        if not isinstance(d.get("reason"), str):
            d["reason"] = ""
        return d
