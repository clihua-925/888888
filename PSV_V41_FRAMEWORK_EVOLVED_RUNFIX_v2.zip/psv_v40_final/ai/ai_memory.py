"""AI 记忆：节点产出的结构化记忆（JSONL），供后续节点引用。"""
from __future__ import annotations
import json
import os

MEM_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "runs", "ai_memory.jsonl")


def remember(node: str, payload: dict, task_id: str = "global") -> None:
    os.makedirs(os.path.dirname(MEM_PATH), exist_ok=True)
    with open(MEM_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps({"task_id": task_id, "node": node, "payload": payload},
                           ensure_ascii=False) + "\n")


def recall(node: str, task_id: str = "global") -> dict | None:
    if not os.path.exists(MEM_PATH):
        return None
    last = None
    with open(MEM_PATH, encoding="utf-8") as f:
        for line in f:
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            if d.get("node") == node and d.get("task_id", "global") == task_id:
                last = d.get("payload")
    return last
