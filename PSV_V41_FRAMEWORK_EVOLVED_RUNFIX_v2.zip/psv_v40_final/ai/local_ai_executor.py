"""Local AI Executor：本地大模型（llama.cpp OpenAI 兼容服务）。

负责节点：L1/L2/L3/L5/L7/L8/L9/L10（理解/推理/规划/分析/总结/判断）
以及 L4 Browser Agent 的页面决策（本地推理，非网页聊天）。
配置：LLM_BASE_URL（默认 http://192.168.1.26:8081/v1）/ LLM_MODEL / LLM_API_KEY / LLM_TIMEOUT(默认480)。
"""
from __future__ import annotations
import json
import queue
import sqlite3
import threading
import time
from typing import Any, Callable

from ai.client import AIClient, AIClientError
from ai.deepseek_web_agent import parse_loose_json, AIExecutionError
from ai.ai_audit_log import AIAuditLog
from ai.ai_memory import remember


# 质量优先：两档超时（秒）与两档 token 上限。加长档用于深度判断节点。
DEFAULT_TIMEOUT_S = 1200     # 正常档 20 分钟
LONG_TIMEOUT_S = 3600        # 加长档 60 分钟
DEFAULT_MAX_TOKENS = 16384   # 常规档（服务端默认的 2-3 倍）
LONG_MAX_TOKENS = 24576      # 深度档
LONG_NODES = frozenset({"L6_customer_completion", "L8_fusion", "L9_intelligence", "L10_decision"})
FAST_NODE_TIMEOUT_S = 900     # L5 事实抽取不需要长思维链
FAST_NODE_MAX_TOKENS = 12288


class _LocalAIJob:
    def __init__(self, fn):
        self.fn = fn
        self.done = threading.Event()
        self.result = None
        self.error: Exception | None = None


class _SerializedLocalAIQueue:
    """单 Worker、有限容量的 llama.cpp 调用队列。"""
    def __init__(self) -> None:
        from business.shared import config
        self._q: queue.Queue[_LocalAIJob] = queue.Queue(maxsize=max(1, config.LOCAL_AI_QUEUE_SIZE))
        self._started = False
        self._lock = threading.Lock()

    def _ensure_worker(self) -> None:
        with self._lock:
            if self._started:
                return
            self._started = True
            threading.Thread(target=self._run, daemon=True, name="psv-local-ai-queue").start()

    def _run(self) -> None:
        while True:
            job = self._q.get()
            try:
                try:
                    job.result = job.fn()
                except Exception as e:  # 将模型异常传回提交方，保持原有重试/审计逻辑
                    job.error = e
            finally:
                job.done.set()
                self._q.task_done()

    def submit(self, fn, timeout_s: float):
        from business.shared import config
        self._ensure_worker()
        job = _LocalAIJob(fn)
        try:
            self._q.put(job, timeout=max(1, config.LOCAL_AI_QUEUE_WAIT_S))
        except queue.Full as e:
            raise AIClientError("本地 llama.cpp 队列已满，请稍后重试") from e
        if not job.done.wait(timeout=timeout_s):
            raise TimeoutError(f"本地 llama.cpp 队列任务超时（{timeout_s}s）")
        if job.error:
            raise job.error
        return job.result


_LOCAL_QUEUE = _SerializedLocalAIQueue()


class LocalAIExecutor:
    MAX_RETRY = 3

    def __init__(self, client: AIClient | None = None, audit: AIAuditLog | None = None,
                 conn: sqlite3.Connection | None = None) -> None:
        self._client = client or AIClient()
        self._audit = audit or AIAuditLog(conn)
        self._last: dict = {}

    def execute(self, node: str, prompt: str, context: dict[str, Any],
                validate: Callable[[dict], Any] | None = None) -> Any:
        NL = chr(10)
        ctx_json = json.dumps(context, ensure_ascii=False)[:12000]
        full = prompt + NL*2 + "[上下文]" + NL + ctx_json + NL*2 + "只输出 JSON。"
        # 按节点分档：L5 直接抽取；深度判断节点给 60 分钟；其余节点走常规档。
        long_node = node in LONG_NODES
        fast_node = node == "L5_standardization"
        timeout_s = (FAST_NODE_TIMEOUT_S if fast_node else
                     LONG_TIMEOUT_S if long_node else DEFAULT_TIMEOUT_S)
        max_tokens = (FAST_NODE_MAX_TOKENS if fast_node else
                      LONG_MAX_TOKENS if long_node else DEFAULT_MAX_TOKENS)
        last_err = ""
        for attempt in range(1, self.MAX_RETRY + 1):
            t0 = time.time()
            try:
                data = _LOCAL_QUEUE.submit(
                    lambda: self._client.chat(full, timeout=timeout_s, max_tokens=max_tokens),
                    timeout_s=timeout_s)
                if validate is not None:
                    data = validate(data)
                provider = "browser_agent" if node == "L4_page_advisor" else "local_ai"
                self._audit.record(node, full, json.dumps(data, ensure_ascii=False), True,
                                   provider=provider,
                                   duration_s=round(time.time() - t0, 2))
                remember(node, data if isinstance(data, dict) else {"result": data},
                         task_id=str(context.get("task_id") or "global"))
                self._last = {"prompt": full, "response": json.dumps(data, ensure_ascii=False)}
                return data
            except (AIClientError, ValueError, Exception) as e:
                last_err = f"{type(e).__name__}: {e}"
                provider = "browser_agent" if node == "L4_page_advisor" else "local_ai"
                self._audit.record(node, full, None, False, provider=provider,
                                   error=last_err[:400], duration_s=round(time.time() - t0, 2))
                # 超时类失败不再重试：长思考被时限掐断后，重试大概率同样超时（浪费 2 倍时间）
                if "timed out" in last_err or "超时" in last_err:
                    break
        raise AIExecutionError(f"{node} 本地AI重试{self.MAX_RETRY}次仍失败: {last_err}")
