"""PSV V41 服务启动器（由 启动-PSV41.bat 经 powershell 隐藏调用）。

V41 接口统一：UI 不再单独起 :3000 http.server，统一由后端 FastAPI(:8000) 托管
（api.app 已 mount frontend/，index.html 从 :8000 访问时走相对路径）。
拉起 Backend 子进程（无窗口），日志写入 logs/backend.log，端口就绪后返回。
"""
from __future__ import annotations
import os
import socket
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from business.shared import config as _cfg

APP = os.path.dirname(os.path.abspath(__file__))
BPORT = _cfg.BACKEND_PORT            # UI 统一入口：http://localhost:{BPORT}
LOGS = os.path.join(APP, "logs")
PY = sys.executable
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)


def _wait_port(port: int, timeout: int = 40) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = socket.socket()
        try:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        except OSError:
            pass
        finally:
            s.close()
        time.sleep(0.5)
    return False


def main() -> int:
    os.makedirs(LOGS, exist_ok=True)
    probe = socket.socket()
    try:
        running = probe.connect_ex(("127.0.0.1", BPORT)) == 0
    finally:
        probe.close()
    if running:
        print(f"[OK] Backend 已在运行 :{BPORT}")
        return 0
    f = open(os.path.join(LOGS, "backend.log"), "ab")
    subprocess.Popen(
        [PY, "-m", "uvicorn", "api.app:app", "--host", "127.0.0.1", "--port", str(BPORT)],
        cwd=APP, stdout=f, stderr=subprocess.STDOUT, creationflags=CREATE_NO_WINDOW)
    if _wait_port(BPORT):
        print(f"[OK] Backend 就绪 :{BPORT}  UI: http://localhost:{BPORT}")
        return 0
    print(f"[FAIL] Backend 未在 40s 内就绪 :{BPORT}，见 logs/backend.log")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
