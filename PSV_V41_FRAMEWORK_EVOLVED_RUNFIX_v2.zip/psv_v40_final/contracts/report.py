"""L10 最终报告契约（与前端/测试三方对齐的唯一定义处）。"""
from __future__ import annotations
from pydantic import BaseModel, Field


class TradeRelations(BaseModel):
    shipment_count: int = 0
    edge_count: int = 0
    country_distribution: dict = Field(default_factory=dict)


class Evidence(BaseModel):
    total_evidence: int = 0
    source_urls: list[str] = Field(default_factory=list)


class NamedCount(BaseModel):
    name: str
    buyers: int = 0
    trade_count: int = 0


class NamedSources(BaseModel):
    name: str
    supplier_sources: int = 0


class DecisionReport(BaseModel):
    product: str | None = None
    market: str | None = None
    product_analysis: dict = Field(default_factory=dict)
    top_suppliers: list[NamedCount] = Field(default_factory=list)
    top_buyers: list[NamedSources] = Field(default_factory=list)
    trade_relations: TradeRelations = Field(default_factory=TradeRelations)
    evidence: Evidence = Field(default_factory=Evidence)
    opportunities: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
