"""ExploreAgent 交互式采集契约（框架层契约，业务无关字段定义）。"""
from __future__ import annotations
from typing import Optional
from typing_extensions import TypedDict


class ExploreStep(TypedDict, total=False):
    step: int                     # 步序号
    url: Optional[str]            # 当前页面 URL
    page_type: str                # search | supplier | buyer | other
    action: str                   # goto | click | extract | scroll | back | done
    target: Optional[str]         # 动作目标（链接文本/URL）
    ai_reason: Optional[str]      # AI 决策理由
    extract: Optional[dict]       # 确定性工具提取结果（supplier_info / buyers）
    snapshot_hash: Optional[str]  # 页面快照哈希（留痕）
    screenshot_path: Optional[str]


class ExploreTrace(TypedDict, total=False):
    keyword: Optional[str]
    started_at: str
    finished_at: Optional[str]
    status: str                   # ok | limit_reached | error
    steps: list[ExploreStep]
    suppliers: list[dict]         # 提取到的供应商信息（entity_type=supplier）
    buyers: list[dict]            # 提取到的采购商信息（entity_type=buyer）
