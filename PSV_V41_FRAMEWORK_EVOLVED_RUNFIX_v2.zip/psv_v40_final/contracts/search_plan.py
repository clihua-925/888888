"""L3 Discovery Planning 的输出契约。"""
from __future__ import annotations
from enum import Enum
from pydantic import BaseModel, Field


class SearchDirection(str, Enum):
    SUPPLIER_SIDE = "supplier_side"      # 找生产/出口方
    BUYER_SIDE = "buyer_side"            # 找采购/进口方
    TRADE_EVIDENCE = "trade_evidence"    # 找提单/海关记录
    COMPANY_IDENTITY = "company_identity"  # 找官网/企业身份


class SearchPlan(BaseModel):
    """搜索计划。L3 输出，禁止包含采集结果。"""

    queries: list[str] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)     # importyeti / usitc / official_site / b2b
    directions: list[SearchDirection] = Field(default_factory=list)
    priority: list[str] = Field(default_factory=list)    # 按优先级排序的 sources
    mode: str = "batch"                # L4 采集模式：batch(批量) | explore(交互式)
    explore_max_suppliers: int = 5     # explore 模式：每个关键词最多探索的供应商数
