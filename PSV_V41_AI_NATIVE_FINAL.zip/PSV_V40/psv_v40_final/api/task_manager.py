"""任务管理器：创建任务、后台执行十阶段流水线、维护阶段状态与详细数据。

每个阶段记录：status / started_at / finished_at / duration_s / detail（该层产物摘要）。
detail 内容（便于定位哪一层有问题）：
  L1: TaskObject 摘要        L2: 分类/应用/同义词/HS 数量
  L3: 查询词/数据源数量      L4: Raw 页数 + id 列表 + 采集失败记录数
  L5: 抽取候选数 + id 列表   L6: 实体数 + 归并映射数
  L7: 边数 + Shipment 数     L8: 画像数   L9: 指标摘要   L10: 报告字段
"""
from __future__ import annotations
import json
import logging
import os
import re
import threading
import time
import traceback
import uuid
from typing import Any

from orchestration.graph import _NODES
from orchestration.state import PipelineState

RUNS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "runs")

logger = logging.getLogger("psv.pipeline")
if not logger.handlers:
    import os
    os.makedirs(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"), exist_ok=True)
    _h = logging.FileHandler(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs", "pipeline.log"), encoding="utf-8")
    _h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


def _stage_detail(name: str, state: PipelineState) -> dict[str, Any]:
    # 方案A后 _stage_detail 覆盖范围：L1/L2/L3/L4/L5/L7/L8/L9/L10 共 9 个节点；
    # L6 已移出图（后台 Worker 独立维护，不写 stages，见 customer_queue /
    # customer_profiles / customer_ai_sessions 表）。后续读者请勿误以为漏了 L6。
    try:
        if name == "L1_task_understanding":
            t = state.get("task")
            return {"product": getattr(t, "product", None), "market": getattr(t, "target_market", None),
                    "company_types": getattr(t, "company_types", None), "goal": getattr(t, "analysis_goal", None)}
        if name == "L2_domain_modeling":
            m = state.get("product_model")
            return {"product_name": getattr(m, "product_name", None),
                    "categories": [c.name for c in getattr(m, "categories", [])],
                    "n_applications": len(getattr(m, "applications", []) or []),
                    "aliases": getattr(m, "aliases", None), "hs": getattr(m, "hs_candidates", None)}
        if name == "L3_discovery_planning":
            p = state.get("search_plan")
            return {"n_queries": len(getattr(p, "queries", []) or []), "queries": getattr(p, "queries", None),
                    "sources": getattr(p, "sources", None), "priority": getattr(p, "priority", None)}
        if name == "L4_data_acquisition":
            ids = state.get("raw_page_ids") or []
            detail: dict[str, Any] = {"n_raw_pages": len(ids), "raw_ids": ids}
            try:
                from data.db import connect
                from data.repository.raw_repository import RawRepository
                conn = connect()
                try:
                    pages = RawRepository(conn).list_by_ids(ids)
                finally:
                    conn.close()
                detail["pages"] = [{"id": p["id"], "page_type": p.get("page_type"),
                                    "url": p["url"], "keyword": p.get("keyword"),
                                    "quality": p.get("quality_score")}
                                   for p in pages]
            except Exception:
                pass
            try:
                from data.db import connect
                from data.repository.collector_repository import CollectorLogRepository
                conn = connect()
                try:
                    fails = CollectorLogRepository(conn).recent_failures(10)
                finally:
                    conn.close()
                detail["collector_failures"] = len(fails)
                if fails:
                    detail["last_failure"] = fails[0]
            except Exception:
                pass
            try:
                from data.db import connect
                from data.repository.candidate_repository import CandidateRepository
                conn = connect()
                try:
                    cands = []
                    for rid in ids:
                        cands.extend(CandidateRepository(conn).list_by_source(rid))
                finally:
                    conn.close()
                detail["n_candidates"] = len(cands)
                detail["candidates"] = [{"name": c["company_name"],
                                         "shipments": c["shipment_count"],
                                         "country": c["country"]} for c in cands[:15]]
            except Exception:
                pass
            return detail
        if name == "L5_data_standardization":
            ids = state.get("std_ids") or []
            detail: dict = {"n_standardized": len(ids), "std_ids": ids}
            try:
                from data.db import connect
                from data.repository.standard_company_repository import StandardCompanyRepository
                conn = connect()
                try:
                    rows = StandardCompanyRepository(conn).list_by_ids(ids)
                finally:
                    conn.close()
                detail["companies"] = [{"name": r["company_name"], "country": r.get("country"),
                                        "shipments": r.get("shipment_count"),
                                        "search_url": r.get("source_url"),
                                        "company_detail_url": r.get("company_detail_url")} for r in rows]
            except Exception:
                pass
            return detail
        if name == "L7_trade_relationship":
            return {"n_edges": len(state.get("edge_ids") or []),
                    "n_shipments": len(state.get("shipment_ids") or []),
                    "customer_processing": (state.get("customer_stats") or {}),
                    "skipped": state.get("l7_skipped", False),
                    "skip_reason": state.get("l7_skip_reason"),
                    "rule": "Supplier-[SUPPLIES]->Customer，边含 shipment_id/evidence/source_url/confidence；L4无真实公司时L7停止"}
        if name == "L8_knowledge_fusion":
            return {"n_profiles": len(state.get("fused_profiles") or {})}
        if name == "L9_graph_intelligence":
            m = state.get("graph_metrics") or {}
            return {"edge_count": m.get("edge_count"), "shipment_count": m.get("shipment_count"),
                    "n_suppliers": len(m.get("core_suppliers") or []),   # 修复1：对齐 V41 AI schema
                    "n_buyers": len(m.get("core_buyers") or []),
                    "risks": m.get("risks")}
        if name == "L10_decision_intelligence":
            r = state.get("report") or {}
            return {"report_keys": sorted(r.keys()), "top_suppliers": len(r.get("top_suppliers") or []),
                    "top_buyers": len(r.get("top_buyers") or [])}
    except Exception as e:
        return {"detail_error": str(e)}
    return {}


class TaskManager:
    def __init__(self) -> None:
        self._tasks: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()

    # ---------- 任务生命周期 ----------
    def create(self, user_input: str) -> str:
        tid = uuid.uuid4().hex[:12]
        task = {
            "id": tid, "input": user_input, "status": "queued",
            "stages": [{"name": n, "status": "waiting"} for n in _NODES],
            "state": None, "error": None, "error_stage": None,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        task["run_file"] = self._write_run_file(task)
        with self._lock:
            self._tasks[tid] = task
        threading.Thread(target=self._run, args=(tid,), daemon=True).start()
        return tid

    def _run(self, tid: str) -> None:
        task = self._tasks[tid]
        task["status"] = "running"
        state: PipelineState = {"user_input": task["input"]}
        logger.info("task %s start: %s", tid, task["input"])
        for stage in task["stages"]:
            stage["status"] = "running"
            stage["started_at"] = time.strftime("%H:%M:%S")
            t0 = time.time()
            try:
                state.update(_NODES[stage["name"]](state))
                stage["detail"] = _stage_detail(stage["name"], state)
                stage["detail"]["ai"] = True  # V41：该层由 AI 主执行（审计见 ai_audit）
                stage["status"] = "done"
                self._write_run_file(task)
                logger.info("task %s %s done in %.1fs detail=%s", tid, stage["name"],
                            time.time() - t0, stage["detail"])
            except Exception as e:
                stage["status"] = "failed"
                stage["error"] = f"{type(e).__name__}: {e}"
                stage["traceback"] = traceback.format_exc()
                task["status"] = "failed"
                task["error"] = f"{stage['name']}: {e}"
                task["error_stage"] = stage["name"]
                task["state"] = dict(state)
                self._write_run_file(task)
                logger.error("task %s %s failed: %s\n%s", tid, stage["name"], e, stage["traceback"])
                return
            finally:
                stage["finished_at"] = time.strftime("%H:%M:%S")
                stage["duration_s"] = round(time.time() - t0, 2)
        task["state"] = dict(state)
        task["status"] = "done"
        self._write_run_file(task)
        logger.info("task %s done", tid)

    # ---------- 运行记录文件 ----------
    def _queue_stats(self) -> dict:
        """后台 L6 客户补全队列状态分组计数；表为空返回 {}。"""
        try:
            from data.db import connect
            from data.repository.customer_queue_repository import CustomerQueueRepository
            conn = connect()
            try:
                return CustomerQueueRepository(conn).stats()
            finally:
                conn.close()
        except Exception:
            return {}

    def _ai_stats(self) -> dict:
        try:
            from data.db import connect
            from ai.ai_audit_log import AIAuditLog
            conn = connect()
            try:
                stats = AIAuditLog(conn).node_stats()
            finally:
                conn.close()
            return stats
        except Exception:
            return {}

    def _write_run_file(self, task: dict) -> str:
        """每次执行一个 JSON 文件：逐阶段写入（含 detail/耗时/错误），用于事后诊断。"""
        os.makedirs(RUNS_DIR, exist_ok=True)
        path = os.path.join(RUNS_DIR, f"run_{task['id']}.json")
        ai_stats = self._ai_stats()
        payload = {
            "ai": True,                       # V41：AI 主执行标记
            "ai_audit": ai_stats,             # 各节点调用/成功计数
            "task_id": task["id"],
            "input": task["input"],
            "created_at": task["created_at"],
            "status": task["status"],
            "error": task.get("error"),
            "error_stage": task.get("error_stage"),
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "stages": task["stages"],
        }
        # 执行完成后：把本次产出的节点/边/企业全量数据写入运行文件
        if task.get("state") and task["status"] in ("done", "failed"):
            try:
                g = self.graph(task["id"])
                if g:
                    payload["nodes"] = g["elements"]["nodes"]
                    payload["edges"] = g["elements"]["edges"]
                r = self.result(task["id"])
                if r:
                    payload["companies"] = r.get("companies")
                    payload["report"] = r.get("report")
            except Exception as e:
                payload["export_error"] = str(e)
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        except OSError as e:
            logger.error("write run file failed: %s", e)
        return path

    def list_runs(self, limit: int = 50) -> list[dict]:
        """历史运行记录（从 runs 目录读取）。"""
        os.makedirs(RUNS_DIR, exist_ok=True)
        out = []
        for name in sorted(os.listdir(RUNS_DIR), reverse=True):
            if not name.endswith(".json"):
                continue
            p = os.path.join(RUNS_DIR, name)
            try:
                d = json.load(open(p, encoding="utf-8"))
                out.append({"file": name, "task_id": d.get("task_id"),
                            "input": d.get("input"), "status": d.get("status"),
                            "created_at": d.get("created_at"),
                            "error_stage": d.get("error_stage"),
                            "size": os.path.getsize(p)})
            except Exception:
                out.append({"file": name, "status": "unreadable", "size": os.path.getsize(p)})
            if len(out) >= limit:
                break
        return out

    def read_run(self, name: str) -> dict | None:
        """读取运行记录文件（文件名白名单校验，防目录穿越）。"""
        if not re.fullmatch(r"run_[0-9a-f]{12}\.json", name or ""):
            return None
        p = os.path.join(RUNS_DIR, name)
        if not os.path.isfile(p):
            return None
        try:
            return json.load(open(p, encoding="utf-8"))
        except Exception:
            return None

    # ---------- 查询 ----------
    def status(self, tid: str) -> dict | None:
        t = self._tasks.get(tid)
        if not t:
            return None
        done = sum(1 for s in t["stages"] if s["status"] == "done")
        current = next((s["name"] for s in t["stages"] if s["status"] == "running"), None)
        return {"id": t["id"], "input": t["input"], "status": t["status"],
                "stages": t["stages"], "error": t["error"], "error_stage": t["error_stage"],
                "created_at": t["created_at"],
                "progress": {"done": done, "total": len(t["stages"])},
                "current_stage": current,
                "run_file": t.get("run_file"),
                "customer_queue": self._queue_stats()}  # 修复4方案A：后台L6队列可观测

    def result(self, tid: str) -> dict | None:
        t = self._tasks.get(tid)
        if not t or not t["state"]:
            return None
        s = t["state"]
        report = s.get("report") or {}
        model = s.get("product_model")
        profiles = s.get("fused_profiles") or {}
        companies = [
            {"id": eid, "company": p.get("company"), "countries": p.get("countries"),
             "roles": p.get("roles"), "products": p.get("products"),
             "shipments": p.get("shipments"), "confidence": p.get("confidence")}
            for eid, p in profiles.items() if p.get("entity_type") == "Company"
        ]
        return {
            "task_id": tid, "status": t["status"],
            "product_model": {
                "product_name": getattr(model, "product_name", None),
                "categories": [c.name for c in getattr(model, "categories", [])],
                "applications": getattr(model, "applications", []),
                "hs_candidates": getattr(model, "hs_candidates", []),
            } if model else None,
            "companies": companies,
            "report": report,
        }

    def graph(self, tid: str) -> dict | None:
        """输出 Cytoscape.js 元素：Company/Product/Location/ShipmentEvent 节点 + 关系边。"""
        t = self._tasks.get(tid)
        if not t or not t["state"]:
            return None
        s = t["state"]
        from data.db import connect
        from data.repository.entity_repository import EntityRepository
        from data.repository.edge_repository import EdgeRepository
        from data.repository.shipment_repository import ShipmentRepository
        conn = connect()
        try:
            ent_r, edge_r, ship_r = EntityRepository(conn), EdgeRepository(conn), ShipmentRepository(conn)
            eids = set(s.get("entity_ids") or [])
            edges = [edge_r.get(i) for i in (s.get("edge_ids") or [])]
            edges = [e for e in edges if e]
            node_ids = set(eids)
            for e in edges:
                node_ids.add(e["source_id"]); node_ids.add(e["target_id"])
            nodes = []
            for nid in sorted(node_ids):
                e = ent_r.get(nid)
                if e:
                    nodes.append({"data": {"id": str(nid), "name": e["canonical_name"],
                                           "type": e["entity_type"], "country": e["country"]}})
            cy_edges = [{"data": {"id": f"e{e['id']}", "source": str(e["source_id"]),
                                  "target": str(e["target_id"]), "label": e["relation"],
                                  "confidence": e["confidence"], "evidence": e["evidence"],
                                  "source_url": e["source_url"]}} for e in edges]
            shipments = [ship_r.get(i) for i in (s.get("shipment_ids") or [])]
            shipments = [x for x in shipments if x]
            for sh in shipments:
                nodes.append({"data": {"id": f"sh{sh['id']}", "name": f"SHIP-{sh['id']}",
                                       "type": "Shipment", "product": sh.get("product"),
                                       "quantity": sh.get("quantity")}})
                cy_edges.append({"data": {"id": f"se{sh['id']}", "source": str(sh["supplier_id"]),
                                          "target": f"sh{sh['id']}", "label": "EXPORTS",
                                          "confidence": sh["confidence"], "evidence": sh["evidence"],
                                          "source_url": sh.get("source_url")}})
                cy_edges.append({"data": {"id": f"se{sh['id']}b", "source": f"sh{sh['id']}",
                                          "target": str(sh["buyer_id"]), "label": "IMPORTS",
                                          "confidence": sh["confidence"], "evidence": sh["evidence"],
                                          "source_url": sh.get("source_url")}})
            return {"task_id": tid, "elements": {"nodes": nodes, "edges": cy_edges}}
        finally:
            conn.close()


_manager = TaskManager()


def get_manager() -> TaskManager:
    return _manager
