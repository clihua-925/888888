"""L8 Knowledge Fusion：AI 融合去重（merge_plan），规则执行合并并保证 ID 一致。

统计与 ID 全部来自真实图谱（DB）；AI 只产出 merge_plan（canonical/aliases/entity_ids），
规则校验：entity_ids 必须全部存在于实体表，否则该条 plan 丢弃。
"""
from __future__ import annotations
import sqlite3
from data.db import connect
from data.repository.entity_repository import EntityRepository
from data.repository.edge_repository import EdgeRepository
from data.repository.shipment_repository import ShipmentRepository
from ai.ai_executor import AIExecutor


class FusionService:
    def __init__(self, conn: sqlite3.Connection | None = None,
                 executor: AIExecutor | None = None) -> None:
        c = conn or connect()
        self._ent = EntityRepository(c)
        self._edge = EdgeRepository(c)
        self._ship = ShipmentRepository(c)
        self._ex = executor or AIExecutor(conn=c)
        self._conn = c

    def fuse(self, entity_ids: list[int], edge_ids: list[int] | None = None,
             shipment_ids: list[int] | None = None) -> dict[int, dict]:
        if not entity_ids:
            return {}  # 上游无数据时短路，不调 AI
        entities = [self._ent.get(e) for e in entity_ids]
        entities = [e for e in entities if e]
        valid_ids = {int(e["id"]) for e in entities}
        if edge_ids is not None:  # N2：限定本任务范围，不取全库
            edges = [self._edge.get(i) for i in edge_ids]
            edges = [e for e in edges if e]
        else:
            edges = self._edge.list_all()
        if shipment_ids is not None:
            ships = [self._ship.get(i) for i in shipment_ids]
            ships = [s for s in ships if s]
        else:
            ships = self._ship.list_all()
        ctx = {"entities": [{"id": e["id"], "name": e["canonical_name"], "type": e["entity_type"],
                             "aliases": e["aliases"], "country": e["country"]} for e in entities],
               "edge_count": len(edges), "shipment_count": len(ships)}

        def validate(d: dict) -> dict:
            plans = []
            for p in (d.get("merge_plan") or []):
                ids = [int(i) for i in (p.get("entity_ids") or []) if str(i).isdigit()]
                ids = [i for i in ids if i in valid_ids]  # 规则：ID 必须真实存在
                if len(ids) >= 2 and p.get("canonical"):
                    plans.append({"canonical": p["canonical"], "aliases": p.get("aliases") or [],
                                  "entity_ids": ids})
            return {"merge_plan": plans}

        plan = self._ex.execute("L8_fusion", ctx, validate=validate)

        # 规则执行合并（保持 canonical 实体，其余并入 aliases）
        alias_of: dict[int, int] = {}
        for p in plan["merge_plan"]:
            keep = p["entity_ids"][0]
            for other in p["entity_ids"][1:]:
                e = self._ent.get(other)
                if e:
                    self._ent.add_alias(keep, e["canonical_name"])
                    for a in e["aliases"]:
                        self._ent.add_alias(keep, a)
                alias_of[other] = keep
        id2name = {int(e["id"]): e["canonical_name"] for e in entities}  # L8-4：预建字典防 O(n^2)
        ship_set = {int(s2["id"]) for s2 in ships} if shipment_ids is not None else None
        edge_set = {int(e2["id"]) for e2 in edges} if edge_ids is not None else None
        profiles: dict[int, dict] = {}
        for e in entities:
            root = alias_of.get(int(e["id"]), int(e["id"]))
            ent = self._ent.get(root) or e
            out_e = self._edge.list_by_source(root) + self._edge.list_by_target(root)
            in_s = self._ship.list_by_supplier(root) + self._ship.list_by_buyer(root)
            if edge_set is not None:   # 问题6修复：画像统计同样限定本任务范围
                out_e = [x for x in out_e if int(x["id"]) in edge_set]
            if ship_set is not None:
                in_s = [x for x in in_s if int(x["id"]) in ship_set]
            all_ev = out_e + in_s
            # 问题A修复：buyers/suppliers 从"已限定范围"的 in_s 派生，禁止再发全库查询
            supplier_ships = [x for x in in_s if int(x["supplier_id"]) == root]
            buyer_ships = [x for x in in_s if int(x["buyer_id"]) == root]
            profiles[root] = {
                "company": ent["canonical_name"], "entity_type": ent["entity_type"],
                "aliases": ent["aliases"],
                "countries": sorted({id2name.get(x["target_id"], str(x["target_id"]))
                                     for x in out_e if x["relation"] == "LOCATED_IN"}),
                "products": sorted({s["product"] for s in in_s if s["product"]}),
                "buyers": sorted({id2name.get(x["buyer_id"], str(x["buyer_id"]))
                                  for x in supplier_ships}),
                "suppliers": sorted({id2name.get(x["supplier_id"], str(x["supplier_id"]))
                                     for x in buyer_ships}),
                "shipments": len(in_s),
                "evidence_count": len(all_ev),
                "confidence": round(sum(float(x["confidence"]) for x in all_ev) / max(1, len(all_ev)), 3),
                "source_urls": sorted({x["source_url"] for x in all_ev if x.get("source_url")}),
            }
        return profiles

    def _name(self, entity_id: int) -> str:
        e = self._ent.get(entity_id)
        return e["canonical_name"] if e else str(entity_id)
