"""L5 Data Standardization：AI 抽取网页中的公司对象 -> standard_company_data。

V41：AI 主执行（经 AIExecutor，Prompt=L5_standardization）；规则只做契约校验：
  - 每家公司必须有 evidence（逐字来自原文）
  - 关键词污染综合判定（角色词+无任何企业证据字段 -> 丢弃）
  - company_detail_url 仅接受 /company/ 链接
"""
from __future__ import annotations
import re
import sqlite3
from urllib.parse import urljoin

from data.db import connect
from data.repository.raw_repository import RawRepository
from data.repository.standard_company_repository import StandardCompanyRepository
from ai.ai_executor import AIExecutor
from business.shared import config

_ROLE_WORDS = ("supplier", "manufacturer", "exporter", "buyer", "importer", "distributor")


class TradeStandardizer:
    def __init__(self, conn: sqlite3.Connection | None = None,
                 executor: AIExecutor | None = None) -> None:
        c = conn or connect()
        self._raw = RawRepository(c)
        self._std = StandardCompanyRepository(c)
        self._ex = executor or AIExecutor(conn=c)

    def standardize(self, raw_page_ids: list[int]) -> list[int]:
        out: list[int] = []
        for rid in raw_page_ids or []:
            page = self._raw.get(rid)
            if not page:
                continue
            text = page.get("text") or ""
            if not text.strip():
                continue
            rows = self._extract(page, text)
            for row in rows:
                out.append(self._std.create(
                    raw_page_id=rid, company_name=row["company_name"],
                    country=row.get("country"), product=row.get("product"),
                    shipment_count=row.get("shipment_count"),
                    source_url=page.get("url"),
                    company_detail_url=row.get("company_detail_url"),
                    original_text=row["evidence"] or row["company_name"]))
        return out

    # ---- AI 抽取 + 规则校验 ----
    _NEXT_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)

    def _build_context(self, page: dict, html: str, text: str) -> dict:
        """构造 AI 上下文：Next.js 数据在页尾，单送前 8000 字会切掉数据区。
        双通道：页头文本 + 页尾文本 + 内嵌 JSON 块（数据准备，非结果生成）。"""
        ctx: dict = {"page_url": page.get("url"), "keyword": page.get("keyword")}
        if html:
            m = self._NEXT_RE.search(html)
            if m:
                ctx["embedded_json"] = m.group(1)[:8000]
        ctx["page_text_head"] = text[:6000]
        ctx["page_text_tail"] = text[-6000:] if len(text) > 6000 else ""
        return ctx

    def _extract(self, page: dict, text: str) -> list[dict]:
        keyword = page.get("keyword")

        def validate(d: dict) -> list[dict]:
            companies = d.get("companies") or []
            if not isinstance(companies, list):
                raise ValueError("L5 规则校验失败：companies 必须为数组")
            ok = []
            seen: set[str] = set()
            for c in companies:
                name = " ".join(str(c.get("company_name") or "").split()).strip(" -|·–—")
                ev = str(c.get("evidence") or "").strip()
                if len(name) < 3 or not ev:
                    continue  # 规则：无证据不入库
                if self._is_query_keyword(name, keyword, bool(c.get("company_url")),
                                          c.get("shipment_count") is not None,
                                          bool(c.get("country") or c.get("address"))):
                    continue  # 规则：关键词污染丢弃
                if name.lower() in seen:
                    continue
                seen.add(name.lower())
                detail = c.get("company_url")
                ok.append({"company_name": name, "country": c.get("country"),
                           "product": c.get("product"),
                           "shipment_count": c.get("shipment_count"),
                           "company_detail_url": detail if (detail and "/company/" in detail) else None,
                           "evidence": ev[:500]})
            return ok

        html = page.get("html_path") and _read(page["html_path"]) or ""
        return self._ex.execute("L5_standardization",
                                self._build_context(page, html, text),
                                validate=validate)

    @staticmethod
    def _is_query_keyword(name: str, keyword: str | None,
                          has_url: bool = False, has_ship: bool = False,
                          has_country: bool = False) -> bool:
        low = (name or "").lower().strip()
        if not low:
            return True
        if keyword:
            kw_base = " ".join(w for w in re.findall(r"[a-z]+", keyword.lower())
                               if w not in _ROLE_WORDS).strip()
            if low == kw_base or low == keyword.lower().strip():
                return True
        toks = set(re.findall(r"[a-z]+", low))
        has_role = any(w in toks for w in _ROLE_WORDS)
        if has_role and not (has_url or has_ship or has_country):
            return True
        return False
