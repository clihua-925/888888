"""L6 Customer Information Completion：只处理采购商/客户，不碰供应商。

数据流（V40.3 网页AI版）：
  L7 客户候选 -> customer_queue(pending) -> Worker(processing)
    -> 本地 Chrome CDP -> DeepSeek 网页版提问 -> 解析回复 JSON
    -> customer_ai_sessions + customer_raw_pages 留痕
    -> customer_profile 生成（unknown 字段置 null，不猜测）
    -> success / failed（retry_count<3 回 pending）
铁律：
  - 不调用任何 LLM API（本地 70B 也不走）；只用网页 AI
  - DeepSeek 打不开/无信息 -> 记 deepseek_browser_error，绝不生成虚假资料
"""
from __future__ import annotations
import json
import sqlite3
import threading
import time

from data.db import connect
from data.repository.customer_queue_repository import CustomerQueueRepository
from data.repository.customer_profile_repository import CustomerProfileRepository
from data.repository.customer_ai_session_repository import CustomerAISessionRepository
from data.repository.customer_raw_page_repository import CustomerRawPageRepository
from data.repository.entity_repository import EntityRepository
from business.trade.entity_resolver import normalize_key, normalize_country, name_similarity
from business.trade.deepseek_web_client import DeepSeekWebClient, DeepSeekWebError
from ai.ai_executor import AIExecutor
from ai.deepseek_web_agent import parse_loose_json

SIMILARITY_THRESHOLD = 0.9

PROMPT_TEMPLATE = """你是企业信息调查分析助手。
请根据以下客户名称，搜索并整理公开信息。
客户名称：{company_name}
国家：{country}
请返回 JSON：
{{
 "company_name": "", "website": "", "country": "", "address": "",
 "industry": "", "business": "", "products": [],
 "business_type": "importer/buyer/distributor/manufacturer",
 "sources": [], "confidence": 0.0
}}
要求：所有信息必须标注依据；无法确认填 unknown；不要猜测。只输出 JSON。"""


def _unknown_to_none(v):
    if v is None:
        return None
    if isinstance(v, str) and (v.strip().lower() in ("unknown", "", "n/a", "null")):
        return None
    return v


class CustomerCompletionService:
    MAX_RETRY = 3  # 失败重试上限

    def __init__(self, conn: sqlite3.Connection | None = None,
                 web_client=None) -> None:
        c = conn or connect()
        self._conn = c
        self._queue = CustomerQueueRepository(c)
        self._profiles = CustomerProfileRepository(c)
        self._sessions = CustomerAISessionRepository(c)
        self._raw_pages = CustomerRawPageRepository(c)
        self._ent = EntityRepository(c)
        self._web = web_client
        self._ex = AIExecutor(conn=c)

    # ---- 队列 ----
    def enqueue(self, customer_name: str, country: str | None = None,
                raw_page_id: int | None = None) -> int:
        return self._queue.enqueue(customer_name, country, raw_page_id)

    def process_pending(self, limit: int = 50) -> dict:
        """Worker 一轮：pending -> processing -> DeepSeek 网页补全 -> success/failed(retry<3)。"""
        stats = {"processed": 0, "success": 0, "failed": 0, "retried": 0}
        for job in self._queue.list_by_status("pending", limit):
            self._queue.set_status(job["id"], "processing")
            try:
                pid = self._complete_one(job["id"], job["customer_name"], job.get("country"))
                self._queue.set_status(job["id"], "success", profile_id=pid, increment=False)
                stats["success"] += 1
            except Exception as e:
                if self._queue.get_attempts(job["id"]) < self.MAX_RETRY:
                    self._rollback(job["id"])
                    stats["retried"] += 1
                else:
                    self._queue.set_status(job["id"], "failed",
                                           error=f"deepseek_browser_error: {str(e)[:280]}",
                                           increment=False)
                    stats["failed"] += 1
            stats["processed"] += 1
        return stats

    def _rollback(self, qid: int) -> None:
        import datetime as _dt
        self._queue._conn.execute(
            "UPDATE customer_queue SET status='pending', updated_at=? WHERE id=?",
            (_dt.datetime.utcnow().isoformat(), qid))
        self._queue._conn.commit()

    # ---- DeepSeek 网页补全 ----
    def _complete_one(self, queue_id: int, name: str, country: str | None) -> int:
        existing = self._match_existing(name)
        if existing is not None:
            self._profiles.add_alias(existing, name)
            return existing
        country_n = normalize_country(country)
        if self._web is not None:
            prompt = PROMPT_TEMPLATE.format(company_name=name, country=country_n or "unknown")
            reply = self._web.ask(prompt)  # 兼容旧直连接口（测试/降级留口）
            data = parse_loose_json(reply)
        else:
            # V41 主路径：统一执行器（审计/重试/记忆集中管理）
            def _validate(d: dict) -> dict:
                if not isinstance(d, dict):
                    raise ValueError("L6 规则校验失败：结果必须为对象")
                return d
            data = self._ex.execute("L6_customer_completion",
                                    {"customer_name": name, "country": country_n or "unknown"},
                                    validate=_validate)
            reply = self._ex._last.get("response", "")
            prompt = self._ex._last.get("prompt", "")

        sources = [_unknown_to_none(s) for s in (data.get("sources") or [])]
        sources = [s for s in sources if s]
        conf_raw = data.get("confidence", 0.5)
        try:
            confidence = min(1.0, max(0.0, float(conf_raw)))
        except (TypeError, ValueError):
            confidence = 0.5
        products = [_unknown_to_none(p) for p in (data.get("products") or [])]
        products = [p for p in products if p]

        # 留痕：AI 会话 + 浏览器取证页（取真实通道的 session，主路径在 executor._web）
        _web = self._web if self._web is not None else getattr(self._ex, "_web", None)
        sess_txt = getattr(_web, "browser_session_text", lambda: "{}")()
        self._sessions.create(queue_id, prompt, deepseek_response=reply[:20000],
                              browser_session=sess_txt)
        self._raw_pages.create(queue_id, url="https://chat.deepseek.com/",
                               page_text=(reply or "")[:20000], screenshot=None)

        pid = self._profiles.create(
            canonical_name=name,
            country=_unknown_to_none(data.get("country")) or country_n,
            industry=_unknown_to_none(data.get("industry")),
            products=products,
            company_type=_unknown_to_none(data.get("business_type")),
            website=_unknown_to_none(data.get("website")),
            address=_unknown_to_none(data.get("address")),
            confidence=confidence, sources=sources)
        data_name = _unknown_to_none(data.get("company_name"))
        if data_name and data_name.lower() != name.lower():
            self._profiles.add_alias(pid, data_name)  # DeepSeek 返回的全称作画像别名
        # L6-2 修复：回写 trade_entities（alias + country），画像字段进图谱
        ent = self._ent.find_by_name("Company", name)
        if ent:
            if data_name and data_name.lower() != name.lower():
                self._ent.add_alias(int(ent["id"]), data_name)
            if not ent.get("country"):
                country_val = _unknown_to_none(data.get("country")) or country_n
                if country_val:
                    self._ent.update_country(int(ent["id"]), country_val)
        else:
            self._ent.create("Company", name, aliases=[],
                             country=_unknown_to_none(data.get("country")) or country_n)
        return pid

    def _match_existing(self, name: str) -> int | None:
        key = normalize_key(name)
        best_id, best = None, 0.0
        for p in self._profiles.list_all():
            names = [p["canonical_name"], *p["aliases"]]
            if any(normalize_key(n) == key for n in names):
                return int(p["id"])
            for n in names:
                s = name_similarity(name, n)
                if s > best:
                    best, best_id = s, int(p["id"])
        return best_id if best >= SIMILARITY_THRESHOLD else None

    def queue_stats(self) -> dict:
        return self._queue.stats()

    def summary(self) -> dict:
        """L6 节点入口：兜底处理队列 + 返回画像/实体统计（连接在此层内管理）。"""
        stats = self.process_pending()
        profiles = self._profiles.list_all()
        entities = [e for e in self._ent.list_all() if e["entity_type"] == "Company"]
        return {"customer_queue_stats": {**self.queue_stats(), **stats},
                "customer_profile_ids": [p["id"] for p in profiles],
                "entity_ids": [int(e["id"]) for e in entities]}

    # ---- 后台异步 Worker（单例守护线程，不阻塞 L7）----
    _worker_started = False

    @classmethod
    def start_background_worker(cls, interval_s: int = 5) -> None:
        if cls._worker_started:
            return
        cls._worker_started = True

        import logging
        logger = logging.getLogger("psv.customer_worker")
        def _loop():
            while True:
                try:
                    cls().process_pending()
                except Exception as e:  # 不再静默：记日志，队列状态保持 pending 等下轮
                    logger.error("customer worker round failed: %s", e)
                time.sleep(interval_s)
        threading.Thread(target=_loop, daemon=True, name="psv-customer-worker").start()
