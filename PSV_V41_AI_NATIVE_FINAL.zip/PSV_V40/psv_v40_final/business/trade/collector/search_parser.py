"""ImportYeti 搜索结果页解析：三级备用机制提取公司候选。

L4 专用：只做"列表解析"，不做 Supplier/Buyer 判断。
  第一优先：__NEXT_DATA__ JSON（name+shipments+slug）
  第二优先：DOM 链接（<a href="/company/xxx">公司名</a>）
  第三优先：文本正则（'Name | N shipments'）
任一级有产出即返回（上级优先）；结构变化时自动降级。
"""
from __future__ import annotations
import json
import re
from urllib.parse import urljoin

from business.shared import config

_NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)
_DOM_LINK_RE = re.compile(
    r'<a[^>]+href="(/company/([a-z0-9][a-z0-9\-]{1,60}))"[^>]*>(.*?)</a>', re.S | re.I)
_CARD_RE = re.compile(
    r"([A-Z][A-Za-z0-9&.,'\-\s]{2,60}?)\s*[\|·\-–—]\s*(\d[\d,]{0,9})\s+shipments", re.I)
_TAG_RE = re.compile(r"<[^>]+>")


def _clean(text: str) -> str:
    return " ".join(_TAG_RE.sub(" ", text or "").split()).strip(" -|·–—")


def parse_search_candidates(html: str, source_page_id: int, keyword: str | None,
                            page_number: int = 1) -> list[dict]:
    for parser in (_from_next_data, _from_dom_links, _from_text_cards):
        rows = parser(html or "")
        if rows:
            return [{"company_name": n, "company_url": u, "country": c,
                     "shipment_count": s, "source_raw_page_id": source_page_id,
                     "keyword": keyword, "page_number": page_number,
                     "parse_level": parser.__name__} for n, u, c, s in rows]
    return []


def _from_next_data(html: str) -> list[tuple]:
    m = _NEXT_DATA_RE.search(html)
    if not m:
        return []
    try:
        data = json.loads(m.group(1))
    except json.JSONDecodeError:
        return []
    out: list[tuple] = []
    seen: set[str] = set()
    if isinstance(data, (dict, list)):
        stack = [data]
        while stack:
            cur = stack.pop()
            if isinstance(cur, dict):
                nm = (cur.get("name") or cur.get("company_name") or cur.get("title")
                      or cur.get("company") or cur.get("supplier"))
                ship = (cur.get("shipments") or cur.get("total_shipments")
                        or cur.get("shipment_count") or cur.get("count") or cur.get("total"))
                ship = ship if isinstance(ship, int) else (int(ship) if isinstance(ship, str) and ship.isdigit() else None)
                if isinstance(nm, str) and len(nm) > 2 and isinstance(ship, int) and ship > 0 \
                        and nm.lower() not in seen:
                    seen.add(nm.lower())
                    slug = cur.get("slug") if isinstance(cur.get("slug"), str) else None
                    out.append((nm, urljoin(config.IY_BASE, f"/company/{slug}") if slug else None,
                                cur.get("country") if isinstance(cur.get("country"), str) else None, ship))
                stack.extend(v for v in cur.values() if isinstance(v, (dict, list)))
            elif isinstance(cur, list):
                stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return out


def _from_dom_links(html: str) -> list[tuple]:
    """第二优先：DOM 中 /company/ 链接（锚文本即公司名）。"""
    out: list[tuple] = []
    seen: set[str] = set()
    for m in _DOM_LINK_RE.finditer(html):
        slug, text = m.group(2), _clean(m.group(3))
        if not slug or slug in seen:
            continue
        seen.add(slug)
        name = text if len(text) >= 3 else slug.replace("-", " ").title()
        out.append((name, urljoin(config.IY_BASE, m.group(1)), None, None))
    return out


def _from_text_cards(html: str) -> list[tuple]:
    text = _clean(html)
    out, seen = [], set()
    for m in _CARD_RE.finditer(text):
        name = m.group(1).strip()
        if len(name) >= 3 and name.lower() not in seen:
            seen.add(name.lower())
            out.append((name, None, None, int(m.group(2).replace(",", ""))))
    return out
