"""浏览器驱动（真实用户操作层）：Chrome CDP + playwright。

生命周期：start() 建立一次连接并复用；stop() 只关闭本进程打开的页面 ——
绝不调用 browser.close()（共享 Chrome 由 start_ai_browser.bat 管理，登录态属于用户）。
"""
from __future__ import annotations
from business.trade.collector.driver import BaseDriver, PageBundle
from business.shared import config


class BrowserUnavailable(RuntimeError):
    pass


class BrowserDriver(BaseDriver):
    driver_type = "browser"
    CDP_URL = config.CDP_URL

    def __init__(self, cdp_url: str | None = None, timeout_ms: int | None = None,
                 max_pages: int | None = None) -> None:
        self._cdp_url = cdp_url or self.CDP_URL
        self._timeout = timeout_ms or config.BROWSER_TIMEOUT_MS
        self._max_pages = max_pages or config.MAX_SEARCH_PAGES
        self.login_status = "unknown"
        self._pw = None
        self._browser = None
        self._ctx = None
        self._page = None

    # ---- 会话生命周期：连接一次，复用到底 ----
    def start(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as e:
            raise BrowserUnavailable("playwright 未安装") from e
        self._pw = sync_playwright().start()
        try:
            self._browser = self._pw.chromium.connect_over_cdp(self._cdp_url, timeout=self._timeout)
        except Exception as e:
            self._pw.stop()
            self._pw = None
            raise BrowserUnavailable(f"无法连接 Chrome CDP {self._cdp_url}: {e}") from e
        self._ctx = self._browser.contexts[0] if self._browser.contexts else self._browser.new_context()

    def stop(self) -> None:
        """只关闭本进程创建的页面；共享浏览器保持运行。"""
        try:
            if self._page and not self._page.is_closed():
                self._page.close()
        except Exception:
            pass
        self._page = None
        if self._pw is not None:
            try:
                self._pw.stop()   # 断开 CDP 连接；不触碰浏览器进程
            except Exception:
                pass
        self._pw = self._browser = self._ctx = None

    def _ensure_page(self):
        if self._ctx is None:
            self.start()
        if self._page is None or self._page.is_closed():
            self._page = self._ctx.new_page()
        return self._page

    def homepage(self) -> PageBundle:
        page = self._ensure_page()
        page.goto(config.IY_BASE + "/", timeout=self._timeout,
                  wait_until="domcontentloaded")
        page.wait_for_timeout(2000)
        try:
            self.login_status = "logged_in" if page.locator("text=/log\\s*out|account/i").count() else "anonymous"
        except Exception:
            self.login_status = "unknown"
        return PageBundle(html=page.content(), url=page.url, page_type="homepage",
                          title=page.title(), screenshot=page.screenshot(full_page=False))

    def search(self, keyword: str, max_pages: int | None = None, advisor=None) -> list[PageBundle]:
        page = self._ensure_page()
        max_pages = max_pages or config.MAX_SEARCH_PAGES
        out: list[PageBundle] = []
        history: list[str] = []
        page.goto(config.IY_BASE + "/", timeout=self._timeout,
                  wait_until="domcontentloaded")
        page.wait_for_timeout(1500)
        box = page.locator("input[type='search'], input[placeholder*='earch'], input[role='searchbox']").first
        box.click()
        box.fill(keyword)
        page.keyboard.press("Enter")
        page.wait_for_timeout(3000)
        for pno in range(1, max_pages + 1):
            page.mouse.wheel(0, 4000)
            page.wait_for_timeout(1200)
            out.append(PageBundle(html=page.content(), url=page.url,
                                  page_type="search_result", keyword=keyword,
                                  page_number=pno, title=page.title(),
                                  screenshot=page.screenshot(full_page=False)))
            history.append(f"p{pno} captured")
            if pno >= max_pages:
                break
            if advisor is not None:  # AI 决策是否继续翻页；规则护栏：仍受 max_pages 限制
                try:
                    decision = advisor.decide(page.locator("body").inner_text(), page.url,
                                              keyword, pno, history)
                    if decision.get("action") == "stop":
                        break
                except Exception:
                    pass  # L4-3：AI 故障降级规则翻页，不静默停止
            try:
                nxt = page.locator("button:has-text('Next'), a:has-text('Next'), [aria-label*='next' i]").first
                if nxt.count() == 0:
                    break
                nxt.click()
                page.wait_for_timeout(2500)
            except Exception:
                break
        return out

    def company_detail(self, slug: str) -> PageBundle | None:
        try:
            page = self._ensure_page()
            page.goto(f"{config.IY_BASE}/company/{slug}", timeout=self._timeout,
                      wait_until="domcontentloaded")
            page.wait_for_timeout(2500)
            page.mouse.wheel(0, 3000)
            page.wait_for_timeout(1200)
            return PageBundle(html=page.content(), url=page.url, page_type="company_detail",
                              title=page.title(), screenshot=page.screenshot(full_page=False))
        except Exception:
            return None

    def shipment_detail(self, url: str) -> PageBundle | None:
        try:
            page = self._ensure_page()
            page.goto(url, timeout=self._timeout, wait_until="domcontentloaded")
            page.wait_for_timeout(2500)
            return PageBundle(html=page.content(), url=page.url, page_type="shipment_detail",
                              title=page.title(), screenshot=page.screenshot(full_page=False))
        except Exception:
            return None
