"""PSV 配置中心：.env 优先，硬编码默认值兜底。

唯一允许集中定义"环境类常量"的地方。业务代码禁止再写死端口/URL/超时。
.env 查找优先级（修复1）：
  1. PSV_V40/.env        （脚本同级，优先——用户期望位置）
  2. psv_v40_final/.env  （包内，兜底）
零依赖内置解析器（不依赖 python-dotenv，老 venv 也生效）。
"""
from __future__ import annotations
import os

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

_ENV_CANDIDATES = [
    os.path.abspath(os.path.join(_BASE, "..", ".env")),   # PSV_V40/.env（脚本同级，优先）
    os.path.join(_BASE, ".env"),                          # psv_v40_final/.env（包内，兜底）
]

ENV_LOADED_FROM: str | None = None


def _load_env_file(path: str) -> None:
    """零依赖 .env 解析：KEY=VALUE 逐行载入 os.environ（不覆盖已存在的变量）。"""
    global ENV_LOADED_FROM
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = value
        ENV_LOADED_FROM = path
    except OSError:
        pass


for _p in _ENV_CANDIDATES:
    if os.path.isfile(_p):
        _load_env_file(_p)
        break
try:  # 有 dotenv 时兜底（可选增强，非依赖）
    from dotenv import load_dotenv
    if ENV_LOADED_FROM:
        load_dotenv(ENV_LOADED_FROM, override=False)
except Exception:
    pass


def _get(key: str, default: str) -> str:
    return os.getenv(key, default)


def _int(key: str, default: int) -> int:
    try:
        return int(_get(key, str(default)))
    except ValueError:
        return default


# 浏览器采集
CDP_URL = _get("CHROME_CDP_URL", "http://localhost:9222")
BROWSER_TIMEOUT_MS = _int("BROWSER_TIMEOUT_MS", 30000)
# ImportYeti
IY_BASE = _get("IMPORTYETI_BASE_URL", "https://www.importyeti.com")
MAX_SEARCH_PAGES = _int("IMPORTYETI_MAX_PAGES", 3)          # 每关键词翻页数
MAX_DETAIL_PAGES = _int("IMPORTYETI_MAX_DETAIL_PAGES", 3)   # 每关键词详情页上限
MAX_QUERIES = _int("IMPORTYETI_MAX_QUERIES", 10)            # 每轮采集关键词条数上限
# 服务端口（bat 脚本需同步修改）
BACKEND_PORT = _int("PSV_BACKEND_PORT", 8000)
FRONTEND_PORT = _int("PSV_FRONTEND_PORT", 3000)
