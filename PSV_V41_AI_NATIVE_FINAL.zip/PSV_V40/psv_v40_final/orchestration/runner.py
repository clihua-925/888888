"""流水线执行器：优先 LangGraph 编译图；无 langgraph 时按节点顺序执行。"""
from __future__ import annotations
from orchestration.graph import _NODES, PIPELINE_ORDER
from orchestration.state import PipelineState


def run_pipeline(user_input: str) -> PipelineState:
    state: PipelineState = {"user_input": user_input}
    try:
        from orchestration.graph import build_graph
        return build_graph().invoke(state)
    except ImportError:
        pass
    for name in PIPELINE_ORDER:
        state.update(_NODES[name](state))
    return state
