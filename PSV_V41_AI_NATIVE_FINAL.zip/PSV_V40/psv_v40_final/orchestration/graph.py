"""十阶段流水线图定义。

红线：节点函数只负责 读state -> 调service -> 写state -> 路由。
本文件不允许出现网络、HTML解析、数据库、模型调用与提示词相关代码，
以红线词表做静态检查（词表维护在架构文档中，不写入本文件）。
"""
from __future__ import annotations
from business.product.task_service import TaskService
from business.product.domain_model_service import DomainModelService
from business.trade.discovery_service import DiscoveryService
from business.trade.collector import TradeDataCollector
from business.trade.standardizer import TradeStandardizer
from business.trade.relationship_builder import RelationshipBuilder
from business.trade.fusion_service import FusionService
from business.trade.graph_intelligence import GraphIntelligence
from business.decision.decision_service import DecisionService
from orchestration.state import PipelineState


def l1_task_understanding(state: PipelineState) -> dict:
    task = TaskService().understand(state["user_input"])
    return {"task": task}


def l2_domain_modeling(state: PipelineState) -> dict:
    model = DomainModelService().build(state["task"])
    return {"product_model": model}


def l3_discovery_planning(state: PipelineState) -> dict:
    plan = DiscoveryService().plan(state["task"], state["product_model"])
    return {"search_plan": plan}


def l4_data_acquisition(state: PipelineState) -> dict:
    ids = TradeDataCollector().collect(state["search_plan"])
    return {"raw_page_ids": ids}


def l5_data_standardization(state: PipelineState) -> dict:
    ids = TradeStandardizer().standardize(state.get("raw_page_ids") or [])
    return {"std_ids": ids}


def l7_trade_relationship(state: PipelineState) -> dict:
    """L7 在 L6 之前执行：发现客户关系 -> 调用 L6 补全 -> 建 Shipment + SUPPLIES Edge。"""
    result = RelationshipBuilder().build(
        state.get("std_ids") or [], state.get("raw_page_ids") or [])
    return {"edge_ids": result["edge_ids"], "shipment_ids": result["shipment_ids"],
            "entity_ids": result.get("entity_ids", []),
            "customer_stats": result["customer_stats"],
            "l7_skipped": result.get("skipped", False),
            "l7_skip_reason": result.get("skip_reason")}


def l8_knowledge_fusion(state: PipelineState) -> dict:
    profiles = FusionService().fuse(
        state.get("entity_ids") or [],
        edge_ids=state.get("edge_ids") or [],
        shipment_ids=state.get("shipment_ids") or [])
    return {"fused_profiles": profiles}


def l9_graph_intelligence(state: PipelineState) -> dict:
    metrics = GraphIntelligence().analyze(state.get("edge_ids") or [])  # N1: [] 必须短路
    return {"graph_metrics": metrics}


def l10_decision_intelligence(state: PipelineState) -> dict:
    report = DecisionService().report(dict(state))
    return {"report": report}


_NODES = {
    "L1_task_understanding": l1_task_understanding,
    "L2_domain_modeling": l2_domain_modeling,
    "L3_discovery_planning": l3_discovery_planning,
    "L4_data_acquisition": l4_data_acquisition,
    "L5_data_standardization": l5_data_standardization,
    "L7_trade_relationship": l7_trade_relationship,
    "L8_knowledge_fusion": l8_knowledge_fusion,
    "L9_graph_intelligence": l9_graph_intelligence,
    "L10_decision_intelligence": l10_decision_intelligence,
}

# 唯一执行顺序来源（A1 修复）：build_graph 与 runner 均遍历此常量
PIPELINE_ORDER = ["L1_task_understanding", "L2_domain_modeling", "L3_discovery_planning",
                  "L4_data_acquisition", "L5_data_standardization", "L7_trade_relationship",
                  "L8_knowledge_fusion", "L9_graph_intelligence", "L10_decision_intelligence"]


def build_graph():
    """构建 LangGraph 图（懒加载 langgraph，无该依赖也能 import 本模块）。"""
    from langgraph.graph import StateGraph, END
    g = StateGraph(PipelineState)
    for name in PIPELINE_ORDER:
        g.add_node(name, _NODES[name])
    for a, b in zip(PIPELINE_ORDER, PIPELINE_ORDER[1:]):
        g.add_edge(a, b)
    g.set_entry_point(PIPELINE_ORDER[0])
    g.add_edge(PIPELINE_ORDER[-1], END)
    return g.compile()
