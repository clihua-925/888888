"""Local AI Executor：本地大模型（llama.cpp OpenAI 兼容服务）。

负责节点：L1/L2/L3/L5/L7/L8/L9/L10（理解/推理/规划/分析/总结/判断）
以及 L4 Browser Agent 的页面决策（本地推理，非网页聊天）。
配置：LLM_BASE_URL（默认 http://192.168.1.26:8081/v1）/ LLM_MODEL / LLM_API_KEY / LLM_TIMEOUT(默认480)。
"""
from __future__ import annotations
import json
import sqlite3
import time
from typing import Any, Callable

from ai.client import AIClient, AIClientError
from ai.deepseek_web_agent import parse_loose_json, AIExecutionError
from ai.ai_audit_log import AIAuditLog
from ai.ai_memory import remember


class LocalAIExecutor:
    MAX_RETRY = 3

    def __init__(self, client: AIClient | None = None, audit: AIAuditLog | None = None,
                 conn: sqlite3.Connection | None = None) -> None:
        self._client = client or AIClient()
        self._audit = audit or AIAuditLog(conn)
        self._last: dict = {}

    def execute(self, node: str, prompt: str, context: dict[str, Any],
                validate: Callable[[dict], Any] | None = None) -> Any:
        NL = chr(10)
        ctx_json = json.dumps(context, ensure_ascii=False)[:12000]
        full = prompt + NL*2 + "[上下文]" + NL + ctx_json + NL*2 + "只输出 JSON。"
        last_err = ""
        for _ in range(1, self.MAX_RETRY + 1):
            t0 = time.time()
            try:
                data = self._client.chat(full)
                if validate is not None:
                    data = validate(data)
                provider = "browser_agent" if node == "L4_page_advisor" else "local_ai"
                self._audit.record(node, full, json.dumps(data, ensure_ascii=False), True,
                                   provider=provider,
                                   duration_s=round(time.time() - t0, 2))
                remember(node, data  # TODO(B1): task_id 参数已就位，调用链未传；待任务隔离大版本一并处理
 if isinstance(data, dict) else {"result": data})
                self._last = {"prompt": full, "response": json.dumps(data, ensure_ascii=False)}
                return data
            except (AIClientError, ValueError, Exception) as e:
                last_err = f"{type(e).__name__}: {e}"
                provider = "browser_agent" if node == "L4_page_advisor" else "local_ai"
                self._audit.record(node, full, None, False, provider=provider,
                                   error=last_err[:400], duration_s=round(time.time() - t0, 2))
        raise AIExecutionError(f"{node} 本地AI重试{self.MAX_RETRY}次仍失败: {last_err}")
