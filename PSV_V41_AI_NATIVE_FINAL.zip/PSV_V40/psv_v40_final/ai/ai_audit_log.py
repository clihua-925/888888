"""AI 调用审计：每次调用必须留痕（节点/提供者/prompt/response/时间/成功与否）。

表 ai_audit_log；节点详情与运行文件从此取 "AI=true" 证据。
"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


def ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ai_audit_log (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            node       TEXT NOT NULL,
            provider   TEXT NOT NULL,
            ai_type    TEXT NOT NULL DEFAULT 'local_ai',
            prompt     TEXT NOT NULL,
            response   TEXT,
            time       TEXT NOT NULL,
            success    INTEGER NOT NULL DEFAULT 0,
            error      TEXT,
            duration_s REAL NOT NULL DEFAULT 0
        )""")
    conn.commit()


class AIAuditLog:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()
        ensure_table(self._conn)

    def record(self, node: str, prompt: str, response: str | None,
               success: bool, error: str | None = None, duration_s: float = 0.0,
               provider: str = "local_ai", ai_type: str | None = None) -> int:
        if ai_type is None:
            ai_type = {"local_ai": "local_ai", "browser_agent": "browser_agent", "deepseek_web": "deepseek_web"}.get(provider, "local_ai")
        cur = self._conn.execute(
            "INSERT INTO ai_audit_log(node,provider,ai_type,prompt,response,time,success,error,duration_s)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (node, provider, ai_type, prompt[:20000], (response or "")[:20000],
             _dt.datetime.utcnow().isoformat(), 1 if success else 0,
             (error or "")[:500], duration_s))
        self._conn.commit()
        return int(cur.lastrowid)

    def node_stats(self, limit_nodes: int = 20) -> dict[str, dict]:
        rows = self._conn.execute(
            "SELECT node, ai_type, COUNT(*) AS n, SUM(success) AS ok FROM ai_audit_log"
            " GROUP BY node, ai_type ORDER BY MIN(id) LIMIT ?", (limit_nodes,)).fetchall()
        return {r["node"]: {"ai_type": r["ai_type"], "calls": r["n"], "success": r["ok"] or 0}
                for r in rows}

    def recent(self, limit: int = 50) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM ai_audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
