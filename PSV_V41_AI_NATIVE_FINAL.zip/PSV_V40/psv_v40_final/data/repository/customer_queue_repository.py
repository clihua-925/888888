"""customer_queue 读写（L6 任务队列：pending/processing/success/failed）。"""
from __future__ import annotations
import datetime as _dt
import sqlite3
from data.db import connect


class CustomerQueueRepository:
    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn or connect()

    def enqueue(self, customer_name: str, country: str | None = None,
                raw_page_id: int | None = None) -> int:
        now = _dt.datetime.utcnow().isoformat()
        cur = self._conn.execute(
            "INSERT INTO customer_queue(customer_name,country,raw_page_id,status,created_at,updated_at)"
            " VALUES(?,?,?,'pending',?,?)", (customer_name, country, raw_page_id, now, now))
        self._conn.commit()
        return int(cur.lastrowid)

    def set_status(self, qid: int, status: str, profile_id: int | None = None,
                   error: str | None = None, increment: bool = True) -> None:
        bump = "attempts=attempts+1," if increment else ""
        self._conn.execute(
            f"UPDATE customer_queue SET status=?, profile_id=?, error=?,"
            f" {bump} updated_at=? WHERE id=?",
            (status, profile_id, error, _dt.datetime.utcnow().isoformat(), qid))
        self._conn.commit()

    def get_attempts(self, qid: int) -> int:
        row = self._conn.execute("SELECT attempts FROM customer_queue WHERE id=?", (qid,)).fetchone()
        return int(row["attempts"]) if row else 0

    def list_by_status(self, status: str, limit: int = 100) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM customer_queue WHERE status=? ORDER BY id LIMIT ?", (status, limit)).fetchall()
        return [dict(r) for r in rows]

    def stats(self) -> dict:
        rows = self._conn.execute(
            "SELECT status, COUNT(*) AS n FROM customer_queue GROUP BY status").fetchall()
        return {r["status"]: r["n"] for r in rows}
