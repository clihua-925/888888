﻿param(
  [Parameter(Mandatory=$true)][string]$Chrome,
  [Parameter(Mandatory=$true)][string]$Profile
)
# 单次启动 AI Browser 并记录主进程 PID（供 stop_psv.bat 整树击杀）
$p = Start-Process -FilePath $Chrome -ArgumentList `
  "--remote-debugging-port=9222",`
  "--user-data-dir=`"$Profile`"",`
  "--no-first-run",`
  "--no-default-browser-check" -PassThru
Start-Sleep -Milliseconds 500
Set-Content -LiteralPath (Join-Path $Profile "ai_browser.pid") -Value $p.Id
Write-Output "LAUNCHED_PID=$($p.Id)"
