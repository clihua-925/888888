﻿@echo off
chcp 65001 >nul
REM PSV AI Browser：启动 Chrome CDP 模式（强单例：PID文件 + 9222监听 + 残留清理）
setlocal EnableDelayedExpansion
set PROFILE=%~dp0psv_chrome_profile
set PIDFILE=%PROFILE%\ai_browser.pid
if not exist "%PROFILE%" mkdir "%PROFILE%"

set CHROME=
for %%P in ("C:\Program Files\Google\Chrome\Application\chrome.exe" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe") do (
  if exist %%~P set CHROME=%%~P
)
if not defined CHROME ( echo [WARN] 未找到 Chrome，浏览器采集层将降级为 HTTP & exit /b 0 )

REM 检查1：9222 已监听 -> 直接退出
netstat -ano | findstr ":9222" | findstr "LISTENING" >nul
if not errorlevel 1 ( echo [OK] Chrome CDP 已在运行 (9222) & exit /b 0 )

REM 检查2：PID 文件且进程存活 -> 直接退出
if exist "%PIDFILE%" (
  set /p OLDPID=<"%PIDFILE%"
  if not "!OLDPID!"=="" (
    tasklist /FI "PID eq !OLDPID!" 2>nul | findstr /C:"!OLDPID!" >nul
    if not errorlevel 1 ( echo [OK] Chrome CDP 已在运行 (PID !OLDPID!) & exit /b 0 )
  )
)

REM 清理残留（上次未正常停止的孤儿），等待句柄释放
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Where-Object { $_.CommandLine -like '*psv_chrome_profile*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
timeout /t 2 >nul

REM 启动前二次确认（防止清理期间另一实例已起）
netstat -ano | findstr ":9222" | findstr "LISTENING" >nul
if not errorlevel 1 ( echo [OK] Chrome CDP 已在运行 & exit /b 0 )

REM 单次启动（ps1 内部原子完成启动+写PID，不会二次拉起）
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_launch_ai_browser.ps1" -Chrome "%CHROME%" -Profile "%PROFILE%" >nul 2>&1
if errorlevel 1 (
  echo [ERROR] AI Browser 启动失败，浏览器采集层将降级为 HTTP
  exit /b 1
)
echo [OK] Chrome AI Browser 已启动（CDP :9222，配置 %PROFILE%）
