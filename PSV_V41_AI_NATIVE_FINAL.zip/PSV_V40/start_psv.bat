﻿@echo off
chcp 65001 >nul
REM ============================================================
REM  PSV V40.3 一键启动（双击即可，无需命令行/手动激活）
REM  流程：检查 venv+依赖 → AI Browser → Backend :8000 → Frontend :3000 → 打开浏览器
REM ============================================================
setlocal EnableDelayedExpansion
cd /d %~dp0
set APP=%~dp0psv_v40_final
title PSV V40.3

REM --- 1. 检查 Python 环境（优先共享环境 ..\venv，兼容 根目录\venv）---
set PY=
if exist "%~dp0..\venv\Scripts\python.exe" set PY=%~dp0..\venv\Scripts\python.exe
if not defined PY if exist "%~dp0venv\Scripts\python.exe" set PY=%~dp0venv\Scripts\python.exe
if not defined PY (
  echo [ERROR] 未找到 venv。请先双击运行 install_psv.bat
  pause
  exit /b 1
)
echo [1/5] Python 环境: %PY%

REM --- 1b. 依赖预检：缺 FastAPI/uvicorn 直接引导安装（避免静默失败）---
"%PY%" -c "import fastapi, uvicorn" >nul 2>&1
if errorlevel 1 (
  echo [ERROR] 依赖未安装或 venv 不完整。请先双击运行 install_psv.bat
  pause
  exit /b 1
)

REM --- 1c. 检查 .env：优先 PSV_V40\.env，其次 psv_v40_final\.env ---
set ENV_FILE=
if exist "%~dp0.env" set ENV_FILE=%~dp0.env
if not defined ENV_FILE if exist "%APP%\.env" set ENV_FILE=%APP%\.env

if not defined ENV_FILE (
  echo.
  echo [WARN] 未找到配置文件 .env，将自动从 .env.example 生成到脚本同级目录
  echo        位置: %~dp0.env
  if exist "%~dp0.env.example" ( copy "%~dp0.env.example" "%~dp0.env" >nul 2>&1 ) else ( copy "%APP%\.env.example" "%~dp0.env" >nul 2>&1 )
  if exist "%~dp0.env" (
    echo [OK] 已生成 %~dp0.env，请按需修改后重新运行 start_psv.bat
    echo      （默认配置指向本地 70B：http://192.168.1.26:8081/v1）
    pause
    exit /b 0
  ) else (
    echo [ERROR] 无法生成 .env：找不到 .env.example
    pause
    exit /b 1
  )
)

REM --- 1d. 首次部署：把 .env.example 准备到脚本同级 ---
if not exist "%~dp0.env.example" if exist "%APP%\.env.example" (
  copy "%APP%\.env.example" "%~dp0.env.example" >nul 2>&1
)

REM --- 1e. AI 通道连通性预检（3 秒超时，不阻塞；不可达给 3 条可操作建议）---
"%PY%" -c "import os,socket; from urllib.parse import urlsplit; base=os.getenv('LLM_BASE_URL') or 'http://192.168.1.26:8081/v1'; u=urlsplit(base); s=socket.socket(); s.settimeout(3); rc=s.connect_ex((u.hostname,u.port or 80)); s.close(); print('AI_LLM_REACHABLE' if rc==0 else 'AI_LLM_UNREACHABLE')" > "%TEMP%\psv_ai_check.txt" 2>&1
findstr /C:"AI_LLM_REACHABLE" "%TEMP%\psv_ai_check.txt" >nul
if errorlevel 1 (
  echo.
  echo [WARN] 本地 AI 通道不可达（LLM_BASE_URL 见 %ENV_FILE%）
  echo        任务将在 L1 阶段失败。三种方案：
  echo        1^) 启动本地 70B 服务（llama.cpp）
  echo        2^) 修改 %ENV_FILE% 里的 LLM_BASE_URL 指向其他可用 LLM
  echo        3^) 继续启动以仅测试 UI 与前端流程
  echo.
  choice /C YN /M "是否继续启动"
  if errorlevel 2 exit /b 0
)

REM --- 2. 启动 AI Browser（Chrome CDP :9222）---
echo [2/5] 启动 AI Browser...
call "%~dp0start_ai_browser.bat"

REM --- 3+4. 隐藏启动 Backend(:8000) + Frontend(:3000)，日志写入 psv_v40_final\logs\ ---
netstat -ano | findstr ":8000" | findstr "LISTENING" >nul
if not errorlevel 1 (
  netstat -ano | findstr ":3000" | findstr "LISTENING" >nul
  if not errorlevel 1 ( echo [3/5] Backend 与 Frontend 已在运行，跳过启动 & goto READY_WAIT )
)
echo [3/5] 后台启动 Backend + Frontend（无窗口，日志：psv_v40_final\logs\）...
powershell -NoProfile -Command "Start-Process -FilePath '%PY%' -ArgumentList '\"%APP%\run_services.py\"' -WorkingDirectory '%APP%' -WindowStyle Hidden" >nul 2>&1
if errorlevel 1 (
  echo [WARN] 隐藏启动失败，改用最小化窗口启动
  start "PSV-Services" /min "%PY%" "%APP%\run_services.py"
)

REM --- 5. 等待服务就绪并打开浏览器 ---
:READY_WAIT
echo [5/5] 等待服务就绪...
set /a WAIT=0
:WAIT_LOOP
"%PY%" -c "import socket,sys;sys.exit(0 if socket.socket().connect_ex(('127.0.0.1',8000))==0 and socket.socket().connect_ex(('127.0.0.1',3000))==0 else 1)" >nul 2>&1
if not errorlevel 1 goto OPEN
set /a WAIT+=1
if %WAIT% GEQ 30 ( echo [WARN] 等待超时，仍尝试打开页面 & goto OPEN )
timeout /t 1 >nul
goto WAIT_LOOP

:OPEN
start "" http://localhost:3000
echo.
echo ==========================================
echo   PSV V40.3 已启动
echo   UI:      http://localhost:3000
echo   API:     http://localhost:8000
echo   日志:    psv_v40_final\logs\backend.log / frontend.log / pipeline.log
echo   AI Browser CDP: 9222
echo   停止：双击 stop_psv.bat
echo ==========================================
timeout /t 5 >nul
