﻿@echo off
chcp 65001 >nul
REM PSV V40.3 一键停止：关闭 Backend / Frontend / AI Browser
setlocal EnableDelayedExpansion
title PSV V40.3 Stop

echo 停止 Backend (8000) 与 Frontend (3000)...
for %%P in (8000 3000) do (
  for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P" ^| findstr "LISTENING"') do (
    if not "%%a"=="*" taskkill /F /T /PID %%a >nul 2>&1
  )
)

echo 停止 AI Browser（psv_chrome_profile）...
REM 方案0：SingletonLock 定位占用 profile 的实例 PID（对"无父孤儿"最有效）
set LOCKFILE=%~dp0psv_chrome_profile\SingletonLock
if exist "%LOCKFILE%" (
  set /p LOCKDATA=<"%LOCKFILE%"
  call :KILLFROMLOCK !LOCKDATA!
  del "%LOCKFILE%" >nul 2>&1
)
REM 方案1：9222 监听者整树击杀（/T 带走所有子进程，最可靠）
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":9222" ^| findstr "LISTENING"') do (
  if not "%%a"=="*" taskkill /F /T /PID %%a >nul 2>&1
)
REM 方案2：PID 文件（start_ai_browser.bat 启动时记录）
set PIDFILE=%~dp0psv_chrome_profile\ai_browser.pid
if exist "%PIDFILE%" (
  set /p BPID=<"%PIDFILE%"
  if not "!BPID!"=="" taskkill /F /T /PID !BPID! >nul 2>&1
  del "%PIDFILE%" >nul 2>&1
)
REM 方案3：PowerShell 命令行匹配（兜底；注意 Chrome 子进程 CommandLine 常为空会漏）
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Where-Object { $_.CommandLine -like '*psv_chrome_profile*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
REM 方案4：wmic 兜底
for /f "tokens=2 delims=," %%a in ('wmic process where "name='chrome.exe' and commandline like '%%psv_chrome_profile%%'" get processid /format:csv 2^>nul ^| findstr /r "[0-9]"') do (
  taskkill /F /T /PID %%a >nul 2>&1
)
REM 核验：报告仍占用 profile 的残留
powershell -NoProfile -Command "$n = @(Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" ^| Where-Object { $_.CommandLine -like '*psv_chrome_profile*' }).Count; Write-Output ('REMAINING=' + $n)" 2>nul | findstr REMAINING
echo [OK] 已停止。可直接关闭本窗口。
timeout /t 5 >nul
exit /b 0

:KILLFROMLOCK
REM 参数形如 hostname-12345（SingletonLock 内容），取末段 PID 整树击杀
set RAW=%1
set SPACED=%RAW:-= %
set LASTTOK=
for %%q in (%SPACED%) do set LASTTOK=%%q
if not "%LASTTOK%"=="" taskkill /F /T /PID %LASTTOK% >nul 2>&1
exit /b 0
