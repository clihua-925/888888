"""WebUI launcher for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
import sys

from core.config.settings import settings
from core.webui.app import app

LOGGER = logging.getLogger(__name__)


def main() -> int:
    """Run the Flask WebUI process."""
    LOGGER.info("Starting WebUI at http://%s:%s", settings.web_host, settings.web_port)
    print(f"PSV Trade OS {settings.app_version}")
    print(f"WebUI: http://{settings.web_host}:{settings.web_port}")
    app.run(
        host=settings.web_host,
        port=settings.web_port,
        threaded=True,
        use_reloader=False,
        debug=False,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
