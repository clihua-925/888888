# PSV Trade OS 9.4.0
# LangGraph v1 Upgrade Script

$Python = "D:\chang\venv\Scripts\python.exe"

Write-Host "=== Recording current LangGraph versions ==="
& $Python -m pip freeze |
    Select-String "langgraph" |
    Out-File -Encoding utf8 upgrade_before_versions.txt

Write-Host "=== Removing old LangGraph packages ==="
& $Python -m pip uninstall -y `
    langgraph `
    langgraph-checkpoint `
    langgraph-checkpoint-sqlite `
    langgraph-prebuilt `
    langgraph-sdk

Write-Host "=== Installing LangGraph v1 frozen versions ==="
& $Python -m pip install `
    "langgraph==1.2.11" `
    "langgraph-checkpoint==4.1.1" `
    "langgraph-checkpoint-sqlite==3.1.1"

Write-Host "=== Verify installed packages ==="
& $Python -m pip list | Select-String "langgraph|langchain-core"

Write-Host "Upgrade completed."
