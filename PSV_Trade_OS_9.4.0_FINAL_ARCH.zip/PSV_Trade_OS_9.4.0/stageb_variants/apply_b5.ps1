# 阶段 B 第 5 步：应用 EVIDENCE_VERIFY（备份外置，项目树零残留）
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$BackupDir = "D:\chang\backups"
if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir | Out-Null }
$target = "$root\business\workflows\trade_collection\nodes.py"
Copy-Item $target "$BackupDir\nodes.py.before_b5" -Force
Copy-Item "$PSScriptRoot\nodes_B5_EVIDENCE_VERIFY.py" $target -Force
"APPLIED B5 (EVIDENCE_VERIFY)"
"BACKUP $BackupDir\nodes.py.before_b5"
Get-FileHash $target -Algorithm SHA256 | Select-Object -ExpandProperty Hash
Set-Location $root
D:\chang\venv\Scripts\python.exe -c "import business.workflows.trade_collection.nodes as n; print('IMPORT_OK', len(n.NODE_FUNCTIONS))"
