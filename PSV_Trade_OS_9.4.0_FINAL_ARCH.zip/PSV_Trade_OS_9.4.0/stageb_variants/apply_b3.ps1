# 阶段 B 第 3 步：应用 CUSTOMS_NODE_COLLECTION（备份外置，项目树零残留）
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$BackupDir = "D:\chang\backups"
if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir | Out-Null }
$target = "$root\business\workflows\trade_collection\nodes.py"
Copy-Item $target "$BackupDir\nodes.py.before_b3" -Force
Copy-Item "$PSScriptRoot\nodes_B3_CUSTOMS_NODE_COLLECTION.py" $target -Force
"APPLIED B3 (CUSTOMS_NODE_COLLECTION)"
"BACKUP $BackupDir\nodes.py.before_b3"
Get-FileHash $target -Algorithm SHA256 | Select-Object -ExpandProperty Hash
Set-Location $root
D:\chang\venv\Scripts\python.exe -c "import business.workflows.trade_collection.nodes as n; print('IMPORT_OK', len(n.NODE_FUNCTIONS))"
