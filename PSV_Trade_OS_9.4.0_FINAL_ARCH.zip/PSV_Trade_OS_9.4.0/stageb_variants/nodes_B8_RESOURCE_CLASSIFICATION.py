"""Business nodes for PSV Trade OS 9.4.0 (Stage B: real/stub hybrid)."""


from __future__ import annotations

import json

import logging

import re

from copy import deepcopy

from difflib import SequenceMatcher

from typing import Any, Mapping

from core.config.industry import load_industry

from core.config.settings import ROOT

from core.orchestration.state import TaskState

from core.orchestration.runtime import get_decision_layer, get_database

_PRODUCT_RULES: tuple[tuple[tuple[str, ...], str, str, tuple[str, ...]], ...] = (
    (("solar", "photovoltaic", "pv"), "Solar photovoltaic equipment", "8501", ("solar", "photovoltaic", "pv")),
    (("battery", "energy storage", "storage"), "Energy storage equipment", "8507", ("battery", "energy storage", "storage")),
    (("inverter", "inverters"), "Power inverter equipment", "8504", ("inverter", "power conversion")),
    (("semiconductor", "chip", "chips", "integrated circuit"), "Semiconductor components", "8542", ("semiconductor", "chip", "integrated circuit")),
    (("steel", "stainless steel", "steel product"), "Steel products", "7200", ("steel", "metal", "industrial")),
    (("aluminum", "aluminium"), "Aluminum products", "7600", ("aluminum", "metal", "industrial")),
    (("coffee", "cocoa", "cacao", "tea"), "Agricultural beverage products", "0900", ("agricultural", "beverage", "food")),
    (("machinery", "machine", "equipment", "industrial equipment"), "Industrial machinery and equipment", "8400", ("machinery", "equipment", "industrial")),
    (("textile", "apparel", "garment", "clothing"), "Textile and apparel products", "6100", ("textile", "apparel", "garment")),
    (("plastic", "polymer", "resin"), "Plastic and polymer products", "3900", ("plastic", "polymer", "resin")),
)

DECISION_ENTITY_RESOLUTION = "entity_resolution"

DECISION_EVIDENCE_VERIFICATION = "evidence_verification"

DECISION_RELATIONSHIP_JUDGMENT = "relationship_judgment"

DECISION_RESOURCE_CLASSIFICATION = "resource_classification"

LOGGER = logging.getLogger(__name__)

REPORT_STATUS_COMMITTED = "committed"

_COUNTRY_BY_MARKET = {
    "us": "United States",
    "usa": "United States",
    "united states": "United States",
    "china": "China",
    "cn": "China",
    "germany": "Germany",
    "de": "Germany",
    "japan": "Japan",
    "jp": "Japan",
    "south korea": "South Korea",
    "korea": "South Korea",
    "uk": "United Kingdom",
    "united kingdom": "United Kingdom",
    "france": "France",
    "italy": "Italy",
    "singapore": "Singapore",
    "india": "India",
    "vietnam": "Vietnam",
    "australia": "Australia",
    "canada": "Canada",
    "mexico": "Mexico",
    "brazil": "Brazil",
}

def _decision_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, Mapping):
        for key in ("verified", "merge", "related", "match", "relevant", "approve"):
            if key in value:
                return bool(value[key])
        return False
    if isinstance(value, str):
        return value.strip().lower() in {"true", "yes", "verified", "merge", "related", "match", "approve"}
    return bool(value) if isinstance(value, (int, float)) else False

def _decision_layer(state: TaskState) -> Any:
    """Return the process-local orchestration decision service."""
    candidate = get_decision_layer()
    if not callable(getattr(candidate, "decide", None)):
        raise RuntimeError("DecisionLayer runtime context is invalid")
    return candidate

def _decision_text(value: Any, default: str = "") -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        for key in ("rationale", "verification_reason", "canonical_name", "resource_class"):
            item = value.get(key)
            if item:
                return str(item)
    return default

def _decision_value(result: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    decision = result.get("decision")
    if isinstance(decision, Mapping):
        for key in keys:
            if key in decision:
                return decision[key]
    metadata = result.get("metadata")
    if isinstance(metadata, Mapping):
        for key in keys:
            if key in metadata:
                return metadata[key]
    for key in keys:
        if key in result:
            return result[key]
    return default

def _entity_id_for_node(node: Mapping[str, Any], index: int) -> str:
    existing = str(node.get("entity_id", "")).strip()
    if existing:
        return existing
    node_id = str(node.get("node_id", "")).strip()
    if node_id:
        return f"ENTITY_{node_id}"
    return f"ENTITY_{index + 1}"

def _entity_map(entities: list[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    return {
        str(entity.get("entity_id")): entity
        for entity in entities
        if entity.get("entity_id")
    }

def _industry_profile(industry: str) -> Mapping[str, Any]:
    """Load optional bundled industry metadata without affecting orchestration."""
    try:
        profile = load_industry(industry)
    except (OSError, ValueError, TypeError):
        return {}
    return profile if isinstance(profile, Mapping) else {}

def _keywords_for_product(text: str, industry: str) -> list[str]:
    lowered = text.lower()
    keywords: list[str] = []
    for triggers, _, _, rule_keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            keywords.extend(rule_keywords)
    if industry:
        keywords.append(industry.strip().lower())
    if not keywords:
        words = re.findall(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}", lowered)
        keywords.extend(words[:6])
    return list(dict.fromkeys(keyword for keyword in keywords if keyword))[:12]

def _load_import_records(state: TaskState) -> list[Mapping[str, Any]]:
    """Load optional normalized local trade records for business-node processing."""
    mission = state.get("mission", {})
    market = str(mission.get("market") or state.get("market") or "").strip().lower()
    industry = str(mission.get("industry") or state.get("industry") or "").strip().lower()
    candidates = [
        ROOT / "data" / "imports" / f"{market}_{industry}.json",
        ROOT / "data" / "imports" / "records.json",
    ]
    for path in candidates:
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"Invalid local trade record file: {path}") from exc
        records = payload.get("records", []) if isinstance(payload, Mapping) else payload
        if not isinstance(records, list):
            raise ValueError(f"Trade record file must contain a list: {path}")
        return [item for item in records if isinstance(item, Mapping)]
    return []

def _market_name(value: Any) -> str:
    text = str(value or "").strip()
    return _COUNTRY_BY_MARKET.get(text.lower(), text)

def _mission_text(mission: Mapping[str, Any]) -> str:
    values = [
        mission.get("objective", ""),
        mission.get("task_type", ""),
        mission.get("intent", ""),
        mission.get("industry", ""),
        mission.get("market", ""),
    ]
    targets = mission.get("targets", [])
    if isinstance(targets, (list, tuple)):
        values.extend(str(item) for item in targets)
    return " ".join(str(item) for item in values if item).strip()

def _normalize_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()

def _product_rule(text: str) -> tuple[str, str, tuple[str, ...]]:
    lowered = text.lower()
    for triggers, product_name, hs_code, keywords in _PRODUCT_RULES:
        if any(trigger in lowered for trigger in triggers):
            return product_name, hs_code, keywords
    targets = _target_values({"targets": [text]})
    product_name = targets[0] if targets else "Target trade product"
    return product_name, "UNSPECIFIED", ()

def _target_values(mission: Mapping[str, Any]) -> list[str]:
    targets = mission.get("targets", [])
    if isinstance(targets, str):
        candidates = re.split(r"[,;|/]+", targets)
    elif isinstance(targets, (list, tuple, set)):
        candidates = [str(item) for item in targets]
    else:
        candidates = []
    cleaned = [item.strip() for item in candidates if item and item.strip()]
    return list(dict.fromkeys(cleaned))

STUB_SOURCE = "stub"

def _decision(node_id: str, summary: str) -> dict[str, Any]:
    return {
        "decision_type": "stub",
        "node_id": node_id,
        "confidence": 1.0,
        "rationale": summary,
        "decision": summary,
        "metadata": {"source": STUB_SOURCE},
    }

def _finish(state: TaskState, node_id: str) -> TaskState:
    reports = dict(state.get("node_reports") or {})
    reports[node_id] = {"status": "stub_completed", "step": "stub"}
    state["node_reports"] = reports
    return state

def PRODUCT_DEFINITION(state: TaskState) -> TaskState:
    """Build a deterministic product definition from the Mission payload."""
    result = deepcopy(state)
    mission = dict(result.get("mission", {}))
    targets = _target_values(mission)
    mission_text = _mission_text(mission)
    industry = str(mission.get("industry", "")).strip()
    market = _market_name(mission.get("market", ""))

    target_text = " ".join(targets) if targets else mission_text
    product_name, hs_code, rule_keywords = _product_rule(target_text)
    profile = _industry_profile(industry)
    profile_keywords = [str(item).strip() for item in profile.get("keywords", []) if str(item).strip()]
    profile_hs_codes = [str(item).strip() for item in profile.get("hs_codes", []) if str(item).strip()]
    if product_name == "Target trade product" and profile.get("name"):
        product_name = str(profile["name"])
    if hs_code == "UNSPECIFIED" and profile_hs_codes:
        hs_code = profile_hs_codes[0]
    keywords = _keywords_for_product(target_text, industry)
    keywords.extend(rule_keywords)
    keywords.extend(profile_keywords)
    keywords = list(dict.fromkeys(keywords))[:12]

    description = (
        f"Trade product definition for {product_name} in the {market or 'target'} "
        f"market, serving the {industry or 'specified'} industry."
    )

    target_customer = "business buyers"
    lowered = mission_text.lower()
    if any(word in lowered for word in ("consumer", "retail", "ecommerce", "end user")):
        target_customer = "consumer and retail buyers"
    elif any(word in lowered for word in ("manufacturer", "factory", "industrial")):
        target_customer = "manufacturers and industrial buyers"
    elif any(word in lowered for word in ("distributor", "wholesaler", "importer")):
        target_customer = "importers, distributors, and wholesalers"

    result["product_definition"] = {
        "product_name": product_name,
        "description": description,
        "keywords": keywords,
        "hs_code_guess": hs_code,
        "market": market,
        "industry": industry,
        "target_customer_type": target_customer,
        "source_targets": targets,
        "industry_profile": dict(profile),
    }
    return result

def TRADE_STRATEGY(state: TaskState) -> TaskState:
    """Generate deterministic trade-search strategy fragments."""
    result = deepcopy(state)
    product = dict(result.get("product_definition", {}))
    market = str(product.get("market", "")).strip()
    keywords = list(product.get("keywords", []))
    product_name = str(product.get("product_name", "Target trade product"))

    keyword_text = list(dict.fromkeys([product_name.lower(), *[str(item) for item in keywords]]))
    fragments = [
        {
            "type": "buyer_search",
            "market": market,
            "keywords": keyword_text[:10],
            "priority": 1,
        },
        {
            "type": "supplier_search",
            "market": market,
            "keywords": keyword_text[:10],
            "priority": 1,
        },
        {
            "type": "market_entry",
            "market": market,
            "keywords": keyword_text[:8],
            "priority": 2,
        },
    ]

    result["fragments"] = fragments
    return result

def CUSTOMS_NODE_COLLECTION(state: TaskState) -> TaskState:
    """Collect normalized local records, with deterministic fallback fixtures when absent."""
    result = deepcopy(state)
    product = dict(result.get("product_definition", {}))
    fragments = list(result.get("fragments", []))
    market = _market_name(product.get("market", "")) or "Target market"
    industry = str(product.get("industry", "")).strip()
    product_name = str(product.get("product_name", "Target trade product"))

    existing_nodes = list(result.get("trade_nodes", []))
    existing_evidence = list(result.get("evidence_pool", []))
    existing_node_ids = {str(item.get("node_id")) for item in existing_nodes}
    existing_evidence_ids = {str(item.get("evidence_id")) for item in existing_evidence}

    records = _load_import_records(result)
    source_nodes: list[dict[str, Any]] = []
    for index, item in enumerate(records, start=1):
        name = str(item.get("name") or item.get("company") or "").strip()
        if not name:
            continue
        country = _market_name(item.get("country") or market)
        role = str(item.get("role") or "unknown").strip().lower()
        if role not in {"buyer", "supplier", "importer", "exporter", "unknown"}:
            role = "unknown"
        source_nodes.append({
            "node_id": str(item.get("node_id") or f"IMPORT_NODE_{index:03d}"),
            "name": name,
            "role": role,
            "country": country,
            "source": str(item.get("source") or "local_import"),
            "shipments": int(item.get("shipments") or 0),
            "industry": str(item.get("industry") or industry),
            "metadata": dict(item.get("metadata", {})) if isinstance(item.get("metadata"), Mapping) else {},
        })

    if not source_nodes:
        source_nodes = [
            {"node_id": "SYNTHETIC_BUYER_001", "name": f"{product_name} Buyer Group A", "role": "buyer", "country": market, "source": "synthetic", "shipments": 18, "contact": "unknown_contact", "industry": industry},
            {"node_id": "SYNTHETIC_SUPPLIER_001", "name": f"{product_name} Supplier Group A", "role": "supplier", "country": "China", "source": "synthetic", "shipments": 26, "contact": "unknown_contact", "industry": industry},
            {"node_id": "SYNTHETIC_IMPORTER_001", "name": f"{product_name} Importer Group A", "role": "importer", "country": market, "source": "synthetic", "shipments": 14, "contact": "unknown_contact", "industry": industry},
            {"node_id": "SYNTHETIC_EXPORTER_001", "name": f"{product_name} Exporter Group A", "role": "exporter", "country": "China", "source": "synthetic", "shipments": 22, "contact": "unknown_contact", "industry": industry},
        ]

    for node in source_nodes:
        node_id = str(node.get("node_id") or "").strip()
        if not node_id or node_id in existing_node_ids:
            continue
        existing_nodes.append(node)
        existing_node_ids.add(node_id)

    for index, node in enumerate(existing_nodes, start=1):
        node_id = str(node.get("node_id") or f"TRADE_NODE_{index:03d}")
        node["node_id"] = node_id
        evidence_id = f"EVIDENCE_{index:03d}"
        if evidence_id in existing_evidence_ids:
            continue
        existing_evidence.append({
            "evidence_id": evidence_id,
            "entity_name": str(node.get("name", "")),
            "evidence_type": "trade_record",
            "source": str(node.get("source", "local_import")),
            "shipments": int(node.get("shipments", 0) or 0),
            "verified": False,
            "evidence_json": {
                "node_id": node_id,
                "product": product_name,
                "strategy_fragments": [item.get("type") for item in fragments if isinstance(item, Mapping)],
            },
        })
        existing_evidence_ids.add(evidence_id)

    result["trade_nodes"] = existing_nodes
    result["evidence_pool"] = existing_evidence
    return result

def TRADE_EDGE_BUILD(state: TaskState) -> TaskState:
    """Use the DecisionLayer to judge candidate buyer-seller relationships."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence = list(result.get("evidence_pool", []))
    relationships = list(result.get("relationships", []))
    entities = list(result.get("entities", []))
    ai = _decision_layer(result)
    entity_by_id = _entity_map(entities)
    node_to_entity: dict[str, Mapping[str, Any]] = {}
    for entity in entities:
        metadata = entity.get("metadata", {})
        if isinstance(metadata, Mapping):
            for source_node_id in metadata.get("merged_from", []):
                node_to_entity[str(source_node_id)] = entity

    role_pairs = {
        ("buyer", "supplier"),
        ("buyer", "exporter"),
        ("importer", "supplier"),
        ("importer", "exporter"),
    }

    existing_edges = {str(item.get("edge_id")) for item in relationships}
    evidence_by_name = {
        str(item.get("entity_name", "")): item
        for item in evidence
    }

    for left_index, left in enumerate(nodes):
        for right_index in range(left_index + 1, len(nodes)):
            right = nodes[right_index]
            pair = (
                str(left.get("role", "")).lower(),
                str(right.get("role", "")).lower(),
            )
            reverse_pair = (pair[1], pair[0])
            if pair not in role_pairs and reverse_pair not in role_pairs:
                continue

            left_node_id = str(left.get("node_id") or f"SYNTHETIC_NODE_{left_index + 1:03d}")
            right_node_id = str(right.get("node_id") or f"SYNTHETIC_NODE_{right_index + 1:03d}")
            left_entity_record = node_to_entity.get(left_node_id)
            right_entity_record = node_to_entity.get(right_node_id)
            left_id = str(
                left_entity_record.get("entity_id")
                if left_entity_record
                else _entity_id_for_node(left, left_index)
            )
            right_id = str(
                right_entity_record.get("entity_id")
                if right_entity_record
                else _entity_id_for_node(right, right_index)
            )
            left_entity = entity_by_id.get(left_id, left)
            right_entity = entity_by_id.get(right_id, right)
            prompt = (
                "Judge whether these two trade entities have a commercially plausible "
                "buyer-seller or importer-exporter relationship. Use the supplied roles, "
                "countries, shipment counts, and evidence. Do not infer a relationship "
                "solely because both entities exist."
            )
            payload = {
                "source": left_entity or left,
                "target": right_entity or right,
                "source_role": left.get("role"),
                "target_role": right.get("role"),
                "source_country": left.get("country"),
                "target_country": right.get("country"),
                "source_shipments": left.get("shipments", 0),
                "target_shipments": right.get("shipments", 0),
                "source_evidence": evidence_by_name.get(str(left.get("name", "")), {}),
                "target_evidence": evidence_by_name.get(str(right.get("name", "")), {}),
            }
            decision = ai.decide(
                result,
                DECISION_RELATIONSHIP_JUDGMENT,
                prompt,
                payload,
            )
            accepted = _decision_bool(decision.get("decision"))
            confidence = float(decision.get("confidence", 0.0))
            if not accepted or confidence < 0.5:
                continue

            edge_id = f"EDGE_{left_id}_{right_id}"
            if edge_id in existing_edges:
                continue

            relation_type = _decision_value(
                decision,
                "relation_type",
                "relationship_type",
                default="trade_partner_candidate",
            )
            rationale = str(
                decision.get(
                    "rationale",
                    _decision_text(decision.get("decision")),
                )
            )
            evidence_ids = []
            for node in (left, right):
                evidence_item = evidence_by_name.get(str(node.get("name", "")))
                if evidence_item and evidence_item.get("evidence_id"):
                    evidence_ids.append(str(evidence_item["evidence_id"]))

            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": left_id,
                    "target_entity_id": right_id,
                    "relation_type": str(relation_type),
                    "confidence": confidence,
                    "evidence_ids": evidence_ids,
                    "rationale": rationale,
                    "source_node_id": left_node_id,
                    "target_node_id": right_node_id,
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result

def EVIDENCE_VERIFY(state: TaskState) -> TaskState:
    """Use the DecisionLayer to verify every evidence item in the shared pool."""
    result = deepcopy(state)
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_layer(result)

    for evidence in evidence_pool:
        prompt = (
            "Verify whether this evidence is internally coherent and sufficiently supports "
            "the stated trade entity. Return a boolean verification judgment, a confidence "
            "score, a concise verification reason, and any material issues."
        )
        decision = ai.decide(
            result,
            DECISION_EVIDENCE_VERIFICATION,
            prompt,
            {
                "evidence": evidence,
                "trade_nodes": result.get("trade_nodes", []),
            },
        )
        verified = _decision_value(
            decision,
            "verified",
            default=_decision_bool(decision.get("decision")),
        )
        if isinstance(verified, str):
            verified = verified.strip().lower() in {"true", "yes", "verified"}

        issues = _decision_value(
            decision,
            "issues",
            default=decision.get("metadata", {}).get("issues", [])
            if isinstance(decision.get("metadata"), Mapping)
            else [],
        )
        if isinstance(issues, str):
            issues = [issues]
        elif not isinstance(issues, list):
            issues = [str(issues)] if issues else []

        reason = _decision_value(
            decision,
            "verification_reason",
            default=decision.get("rationale", ""),
        )
        evidence["verified"] = bool(verified)
        evidence["verification_confidence"] = float(decision.get("confidence", 0.0))
        evidence["verification_reason"] = str(reason or "")
        evidence["issues"] = issues

    result["evidence_pool"] = evidence_pool
    return result

def ENTITY_RESOLUTION(state: TaskState) -> TaskState:
    """Resolve similar trade nodes into canonical entities using AI judgment."""
    result = deepcopy(state)
    nodes = list(result.get("trade_nodes", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_layer(result)

    parent: dict[str, str] = {}
    node_records: dict[str, dict[str, Any]] = {}

    for index, node in enumerate(nodes):
        node_id = str(node.get("node_id") or f"SYNTHETIC_NODE_{index + 1:03d}")
        node_records[node_id] = node
        parent[node_id] = node_id

    def find(node_id: str) -> str:
        current = node_id
        while parent[current] != current:
            parent[current] = parent[parent[current]]
            current = parent[current]
        return current

    def merge(first: str, second: str) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parent[second_root] = first_root

    candidates: list[tuple[str, str]] = []
    resolution_overrides: dict[str, dict[str, Any]] = {}
    for left_index, left in enumerate(nodes):
        left_name = _normalize_name(left.get("name"))
        for right in nodes[left_index + 1 :]:
            right_name = _normalize_name(right.get("name"))
            if not left_name or not right_name:
                continue
            similarity = SequenceMatcher(None, left_name, right_name).ratio()
            same_country = str(left.get("country", "")).lower() == str(right.get("country", "")).lower()
            same_role = str(left.get("role", "")).lower() == str(right.get("role", "")).lower()
            if similarity >= 0.65 or (same_country and same_role and similarity >= 0.45):
                candidates.append((str(left.get("node_id")), str(right.get("node_id"))))

    for left_id, right_id in candidates:
        left = node_records[left_id]
        right = node_records[right_id]
        decision = ai.decide(
            result,
            DECISION_ENTITY_RESOLUTION,
            (
                "Determine whether the two supplied trade records represent the same "
                "underlying entity. If they are duplicates, provide a canonical name. "
                "Use name similarity, role, country, and evidence context."
            ),
            {
                "left": left,
                "right": right,
                "evidence_pool": evidence_pool,
            },
        )
        should_merge = _decision_value(
            decision,
            "merge",
            default=_decision_bool(decision.get("decision")),
        )
        if isinstance(should_merge, str):
            should_merge = should_merge.strip().lower() in {"true", "yes", "merge"}
        if bool(should_merge) and float(decision.get("confidence", 0.0)) >= 0.5:
            merge(left_id, right_id)
            canonical_name = _decision_value(decision, "canonical_name", default="")
            if canonical_name:
                resolution_overrides[find(left_id)] = {
                    "canonical_name": str(canonical_name).strip(),
                    "confidence": float(decision.get("confidence", 0.0)),
                    "rationale": str(decision.get("rationale", "")),
                }

    groups: dict[str, list[dict[str, Any]]] = {}
    for node_id, node in node_records.items():
        groups.setdefault(find(node_id), []).append(node)

    entities: list[dict[str, Any]] = []
    for index, group in enumerate(groups.values(), start=1):
        canonical = max(
            group,
            key=lambda item: int(item.get("shipments", 0) or 0),
        )
        merged_from = [str(item.get("node_id")) for item in group]
        confidence = 1.0 if len(group) == 1 else 0.75
        root_id = find(str(group[0].get("node_id")))
        override = resolution_overrides.get(root_id, {})
        canonical_name = str(override.get("canonical_name", "")).strip() or str(canonical.get("name", "")).strip()
        if override.get("confidence") is not None:
            confidence = float(override["confidence"])
        entity_id = f"ENTITY_{index:03d}"
        entities.append(
            {
                "entity_id": entity_id,
                "canonical_name": canonical_name,
                "role": canonical.get("role"),
                "country": canonical.get("country"),
                "source": canonical.get("source", "synthetic"),
                "metadata": {
                    "confidence": confidence,
                    "merged_from": merged_from,
                    "shipments": sum(int(item.get("shipments", 0) or 0) for item in group),
                    "resolution_rationale": str(override.get("rationale", "")),
                },
            }
        )

    node_to_entity: dict[str, str] = {}
    for entity in entities:
        for source_id in entity["metadata"]["merged_from"]:
            node_to_entity[source_id] = entity["entity_id"]

    for relationship in result.get("relationships", []):
        source_id = str(relationship.get("source_node_id", ""))
        target_id = str(relationship.get("target_node_id", ""))
        if source_id in node_to_entity:
            relationship["source_entity_id"] = node_to_entity[source_id]
        if target_id in node_to_entity:
            relationship["target_entity_id"] = node_to_entity[target_id]

    result["entities"] = entities
    return result

def GRAPH_EXPANSION(state: TaskState) -> TaskState:
    """Add deterministic expanded relationships from existing canonical entities."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    existing_edges = {str(item.get("edge_id")) for item in relationships}

    for left_index, left in enumerate(entities):
        for right in entities[left_index + 1 :]:
            if not left.get("entity_id") or not right.get("entity_id"):
                continue
            same_country = str(left.get("country", "")).strip().lower() == str(right.get("country", "")).strip().lower()
            same_role = str(left.get("role", "")).strip().lower() == str(right.get("role", "")).strip().lower()
            if not same_country and not same_role:
                continue
            source_id = str(left["entity_id"])
            target_id = str(right["entity_id"])
            edge_id = f"EXPANDED_{source_id}_{target_id}"
            if edge_id in existing_edges:
                continue
            relation_type = "same_country_partner" if same_country else "same_role_network"
            relationships.append(
                {
                    "edge_id": edge_id,
                    "source_entity_id": source_id,
                    "target_entity_id": target_id,
                    "relation_type": relation_type,
                    "confidence": 0.55,
                    "evidence_ids": [],
                    "rationale": "Deterministic graph expansion from shared entity attributes.",
                    "metadata": {"expansion": "expanded"},
                }
            )
            existing_edges.add(edge_id)

    result["relationships"] = relationships
    return result

def RESOURCE_CLASSIFICATION(state: TaskState) -> TaskState:
    """Classify every canonical entity with the DecisionLayer."""
    result = deepcopy(state)
    entities = list(result.get("entities", []))
    relationships = list(result.get("relationships", []))
    evidence_pool = list(result.get("evidence_pool", []))
    ai = _decision_layer(result)

    for entity in entities:
        decision = ai.decide(
            result,
            DECISION_RESOURCE_CLASSIFICATION,
            (
                "Classify this trade entity by commercial resource value. Return a resource "
                "class, a priority value, confidence, and rationale. Consider role, country, "
                "relationship count, shipments, and verified evidence."
            ),
            {
                "entity": entity,
                "relationships": relationships,
                "evidence_pool": evidence_pool,
            },
        )
        resource_class = _decision_value(
            decision,
            "resource_class",
            "class",
            default="unclassified_resource",
        )
        priority = _decision_value(
            decision,
            "priority",
            default=decision.get("metadata", {}).get("priority", 3)
            if isinstance(decision.get("metadata"), Mapping)
            else 3,
        )
        entity.setdefault("metadata", {})
        entity["metadata"]["resource_class"] = str(resource_class)
        entity["metadata"]["priority"] = priority
        entity["metadata"]["classification_confidence"] = float(decision.get("confidence", 0.0))
        entity["metadata"]["classification_rationale"] = str(decision.get("rationale", ""))

    result["entities"] = entities
    return result

def DATABASE_COMMIT(state: TaskState) -> TaskState:
    """Stub: DATABASE_COMMIT scaffold writing one real row per trade table."""
    task_id = str(state.get("task_id") or "unknown")
    entities = [{
        "entity_id": f"ent-stub-1-{task_id}", "canonical_name": "Stub Exporter Alpha",
        "role": "exporter", "country": "US", "source": STUB_SOURCE, "metadata": {},
    }]
    edges = [{
        "edge_id": f"edge-stub-1-{task_id}", "source_entity_id": f"ent-stub-1-{task_id}",
        "target_entity_id": f"ent-stub-2-{task_id}", "relation_type": "supplier_of",
        "confidence": 0.9, "evidence_ids": [f"ev-stub-1-{task_id}"], "metadata": {},
    }]
    evidence = [{
        "evidence_id": f"ev-stub-1-{task_id}", "entity_name": "Stub Exporter Alpha",
        "evidence_type": "shipment_record", "source": STUB_SOURCE, "shipments": [],
        "verified": True, "evidence_json": {},
    }]
    committed = {"trade_entities": 0, "trade_edges": 0, "evidence": 0}
    try:
        database = get_database()
        committed = database.commit_trade_data(task_id, entities, edges, evidence)
    except Exception:
        committed = {"trade_entities": 0, "trade_edges": 0, "evidence": 0}
    reports = dict(state.get("node_reports") or {})
    reports["DATABASE_COMMIT"] = {"status": "committed", "committed": committed, "step": "stub"}
    state["node_reports"] = reports
    return state



NODE_FUNCTIONS = {
    "PRODUCT_DEFINITION": PRODUCT_DEFINITION,
    "TRADE_STRATEGY": TRADE_STRATEGY,
    "CUSTOMS_NODE_COLLECTION": CUSTOMS_NODE_COLLECTION,
    "TRADE_EDGE_BUILD": TRADE_EDGE_BUILD,
    "EVIDENCE_VERIFY": EVIDENCE_VERIFY,
    "ENTITY_RESOLUTION": ENTITY_RESOLUTION,
    "GRAPH_EXPANSION": GRAPH_EXPANSION,
    "RESOURCE_CLASSIFICATION": RESOURCE_CLASSIFICATION,
    "DATABASE_COMMIT": DATABASE_COMMIT,
}


def get_node_function(node_id: str):
    """Return a registered business node callable."""
    try:
        return NODE_FUNCTIONS[node_id]
    except KeyError as exc:
        raise KeyError(f"Unknown business node: {node_id}") from exc
