# 阶段 B 第 4 步：应用 TRADE_EDGE_BUILD（备份外置，项目树零残留）
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$BackupDir = "D:\chang\backups"
if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir | Out-Null }
$target = "$root\business\workflows\trade_collection\nodes.py"
Copy-Item $target "$BackupDir\nodes.py.before_b4" -Force
Copy-Item "$PSScriptRoot\nodes_B4_TRADE_EDGE_BUILD.py" $target -Force
"APPLIED B4 (TRADE_EDGE_BUILD)"
"BACKUP $BackupDir\nodes.py.before_b4"
Get-FileHash $target -Algorithm SHA256 | Select-Object -ExpandProperty Hash
Set-Location $root
D:\chang\venv\Scripts\python.exe -c "import business.workflows.trade_collection.nodes as n; print('IMPORT_OK', len(n.NODE_FUNCTIONS))"
