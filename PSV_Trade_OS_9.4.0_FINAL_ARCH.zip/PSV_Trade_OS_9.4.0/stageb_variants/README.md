# 阶段 B：逐节点替换真实业务（B1 -> B9，用户指定顺序）

B1 PRODUCT_DEFINITION(确定性) -> B2 TRADE_STRATEGY(确定性) -> B3 CUSTOMS_NODE_COLLECTION(确定性)
-> B4 EVIDENCE_VERIFY(AI) -> B5 ENTITY_RESOLUTION(AI) -> B6 TRADE_EDGE_BUILD(AI,最重)
-> B7 GRAPH_EXPANSION(确定性) -> B8 RESOURCE_CLASSIFICATION(AI) -> B9 DATABASE_COMMIT(确定性,全真实)

每步：
  powershell -File stageb_variants\apply_bX.ps1     # 自动备份 nodes.py.before_bX
  D:\chang\venv\Scripts\python.exe -m pytest tests -q     # 23 passed
  # 启动 WebUI 跑真实任务 -> COMPLETED，核对该节点事件/数据足迹（见方案文档）
回滚：Copy-Item "business\workflows\trade_collection\nodes.py.before_bX" "business\workflows\trade_collection\nodes.py" -Force
B9 后总验证：D:\chang\venv\Scripts\python.exe verify_install.py --runtime
