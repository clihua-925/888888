@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "CDP_PORT=9222"
set "PROFILE=%~dp0chrome_profile"

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

if not defined BROWSER (
    echo [ERROR] Chrome or Edge was not found.
    pause
    exit /b 1
)

if not exist "%PROFILE%" mkdir "%PROFILE%"

echo Starting CDP browser on port %CDP_PORT%...
echo Profile: %PROFILE%
start "PSV CDP 9222" "%BROWSER%" --remote-debugging-port=%CDP_PORT% --user-data-dir="%PROFILE%" http://127.0.0.1:8090
if errorlevel 1 (
    echo [ERROR] Browser startup failed.
    pause
    exit /b 1
)

echo [OK] CDP browser started on port %CDP_PORT%.
endlocal
