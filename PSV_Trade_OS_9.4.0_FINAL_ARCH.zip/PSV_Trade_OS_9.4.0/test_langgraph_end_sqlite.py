import time
import os
import sqlite3

from typing import TypedDict

from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver


class TestState(TypedDict):
    status: str


def node_a(state: TestState):
    print("[NODE] node_a start")

    return {
        "status": "COMPLETED"
    }


def router(state: TestState):
    print("[ROUTER] status =", state["status"])

    if state["status"] == "COMPLETED":
        print("[ROUTER] returning END")
        return END

    return "node_a"


def main():

    db_path = "test_langgraph_end.sqlite"

    if os.path.exists(db_path):
        os.remove(db_path)

    print("=== Creating SqliteSaver ===")

    conn = sqlite3.connect(
        db_path,
        check_same_thread=False
    )

    checkpointer = SqliteSaver(conn)


    print("=== Building graph ===")

    graph = StateGraph(TestState)

    graph.add_node(
        "node_a",
        node_a
    )

    graph.set_entry_point(
        "node_a"
    )


    graph.add_conditional_edges(
        "node_a",
        router,
        {
            END: END
        }
    )


    app = graph.compile(
        checkpointer=checkpointer
    )


    print("=== Invoke start ===")

    start = time.time()


    result = app.invoke(
        {
            "status": "RUNNING"
        },
        config={
            "configurable": {
                "thread_id": "test-thread"
            }
        }
    )


    cost = time.time() - start


    print()
    print("=== RESULT ===")
    print(result)

    print(
        "Elapsed:",
        round(cost, 3),
        "seconds"
    )


    print("=== Closing sqlite ===")

    conn.close()

    print("DONE")


if __name__ == "__main__":

    main()