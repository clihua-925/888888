# PSV Trade OS 9.4.0
# LangGraph Rollback Script

$Python = "D:\chang\venv\Scripts\python.exe"
$beforeFile = "upgrade_before_versions.txt"

Write-Host "=== LangGraph Rollback ==="

if (Test-Path $beforeFile) {
    Write-Host "Using recorded versions from $beforeFile"
    $lines = Get-Content $beforeFile -Encoding utf8
    $packages = $lines | Where-Object { $_ -match "^langgraph" }

    & $Python -m pip uninstall -y `
        langgraph `
        langgraph-checkpoint `
        langgraph-checkpoint-sqlite `
        langgraph-prebuilt `
        langgraph-sdk

    foreach ($pkg in $packages) {
        & $Python -m pip install $pkg.Trim()
    }
}
else {
    Write-Host "upgrade_before_versions.txt missing, using fallback versions"

    & $Python -m pip uninstall -y `
        langgraph `
        langgraph-checkpoint `
        langgraph-checkpoint-sqlite `
        langgraph-prebuilt `
        langgraph-sdk

    & $Python -m pip install `
        "langgraph==0.6.11" `
        "langgraph-checkpoint==3.0.1" `
        "langgraph-checkpoint-sqlite==3.0.3" `
        "langgraph-prebuilt==0.6.5" `
        "langgraph-sdk==0.2.15"
}

Write-Host "=== Current LangGraph versions ==="
& $Python -m pip list | Select-String "langgraph"
