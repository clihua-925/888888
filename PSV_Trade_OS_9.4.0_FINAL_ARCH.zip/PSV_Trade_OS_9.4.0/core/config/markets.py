"""Market configuration loader for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
from typing import Any

from core.config.settings import ROOT


def markets() -> list[dict[str, Any]]:
    """Load normalized market definitions from data/markets.json."""
    path = ROOT / "data" / "markets.json"
    if not path.exists():
        return []
    payload = json.loads(path.read_text(encoding="utf-8"))
    values = payload.get("markets", []) if isinstance(payload, dict) else payload
    return [item for item in values if isinstance(item, dict)] if isinstance(values, list) else []
