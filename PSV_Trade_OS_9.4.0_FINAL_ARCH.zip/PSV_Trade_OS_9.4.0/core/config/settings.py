"""Central runtime configuration for PSV Trade OS 9.4.0."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - dependency gate reports missing package
    load_dotenv = None

APP_VERSION = "9.4.0"
ROOT = Path(__file__).resolve().parents[2]

if load_dotenv is not None:
    load_dotenv(ROOT / ".env", override=False)


def _read_int(name: str, default: int) -> int:
    value = os.getenv(name, str(default)).strip()
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc


@dataclass(frozen=True)
class Settings:
    """Immutable application configuration."""

    app_version: str = APP_VERSION
    web_host: str = os.getenv("WEB_HOST", "127.0.0.1")
    web_port: int = _read_int("WEB_PORT", 8090)
    llm_base_url: str = os.getenv("LLM_BASE_URL", "http://127.0.0.1:8081/v1")
    llm_api_key: str = os.getenv("LLM_API_KEY", "")
    llm_model: str = os.getenv("LLM_MODEL", "deepseek-r1-distill-llama-70b")
    database_path: Path = Path(os.getenv("DATABASE_PATH", "data/psv.db"))
    checkpoint_path: Path = Path(os.getenv("CHECKPOINT_PATH", "data/checkpoints.db"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    max_task_seconds: int = _read_int("MAX_TASK_SECONDS", 1800)
    max_steps: int = _read_int("MAX_STEPS", 40)
    max_retries: int = _read_int("MAX_RETRIES", 2)
    no_progress_limit: int = _read_int("NO_PROGRESS_LIMIT", 3)

    def ensure_directories(self) -> None:
        """Create runtime parent directories when they do not exist."""
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)

    @property
    def database_path_string(self) -> str:
        return str(self.database_path)

    @property
    def checkpoint_path_string(self) -> str:
        return str(self.checkpoint_path)


settings = Settings()
