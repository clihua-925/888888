"""Industry configuration loader for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
from typing import Any

from core.config.settings import ROOT


def load_industry(name: str | None) -> dict[str, Any]:
    """Load a named industry profile, falling back to the bundled candle profile."""
    safe = str(name or "candle").strip().lower()
    path = ROOT / "data" / "industry_configs" / f"{safe}.json"
    if not path.exists():
        path = ROOT / "data" / "industry_configs" / "candle.json"
    if not path.exists():
        return {"name": safe, "keywords": [], "hs_codes": [], "product_terms": [], "icp_reject": []}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Industry profile must be an object: {path}")
    return payload
