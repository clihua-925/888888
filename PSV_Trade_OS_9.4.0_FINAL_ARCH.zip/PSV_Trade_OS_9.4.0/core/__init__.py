"""PSV Trade OS core package."""

__version__ = "9.4.0"
