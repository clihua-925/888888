"""SQLite persistence for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


class Database:
    """SQLite database gateway for task and trade persistence."""

    def __init__(self, database_path: str | Path) -> None:
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=60)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA busy_timeout = 60000")
        return connection

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)

    def initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id TEXT PRIMARY KEY, workflow_id TEXT NOT NULL, status TEXT NOT NULL,
                state_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS task_events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL,
                event_type TEXT NOT NULL, node_id TEXT, status TEXT, payload TEXT,
                created_at TEXT NOT NULL, FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_task_events_task_id ON task_events(task_id);
            CREATE TABLE IF NOT EXISTS trade_entities (
                entity_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, canonical_name TEXT NOT NULL,
                role TEXT, country TEXT, source TEXT, metadata TEXT,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_trade_entities_task_id ON trade_entities(task_id);
            CREATE TABLE IF NOT EXISTS trade_edges (
                edge_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, source_entity_id TEXT NOT NULL,
                target_entity_id TEXT NOT NULL, relation_type TEXT NOT NULL, confidence REAL,
                evidence_ids TEXT, metadata TEXT,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_trade_edges_task_id ON trade_edges(task_id);
            CREATE TABLE IF NOT EXISTS evidence (
                evidence_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, entity_name TEXT NOT NULL,
                evidence_type TEXT, source TEXT, shipments TEXT, verified INTEGER NOT NULL DEFAULT 0,
                evidence_json TEXT, created_at TEXT NOT NULL,
                FOREIGN KEY(task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_evidence_task_id ON evidence(task_id);
            """)

    def create_task(self, task_id: str, workflow_id: str, state: Mapping[str, Any], status: str) -> dict[str, Any]:
        timestamp = self._now()
        with self._connect() as connection:
            connection.execute("""INSERT INTO tasks(task_id,workflow_id,status,state_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?)""", (task_id, workflow_id, status, self._json(dict(state)), timestamp, timestamp))
        return self.get_task(task_id)

    def update_task(self, task_id: str, state: Mapping[str, Any], status: str) -> dict[str, Any]:
        with self._connect() as connection:
            cursor = connection.execute("""UPDATE tasks SET status=?,state_json=?,updated_at=? WHERE task_id=?""",
                (status, self._json(dict(state)), self._now(), task_id))
            if cursor.rowcount == 0:
                raise KeyError(f"Task not found: {task_id}")
        return self.get_task(task_id)

    def get_tasks_by_status(self, statuses: tuple[str, ...]) -> list[dict[str, Any]]:
        """Return persisted tasks whose lifecycle status requires scheduler recovery."""
        normalized = tuple(str(status).strip() for status in statuses if str(status).strip())
        if not normalized:
            return []
        bindings = ",".join("?" for _ in normalized)
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT task_id,workflow_id,status,state_json,created_at,updated_at "
                f"FROM tasks WHERE status IN ({bindings}) ORDER BY created_at ASC",
                normalized,
            ).fetchall()
        tasks: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["state"] = json.loads(item.pop("state_json"))
            tasks.append(item)
        return tasks

    def get_task(self, task_id: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute("""SELECT task_id,workflow_id,status,state_json,created_at,updated_at
                FROM tasks WHERE task_id=?""", (task_id,)).fetchone()
        if row is None:
            raise KeyError(f"Task not found: {task_id}")
        result = dict(row)
        result["state"] = json.loads(result.pop("state_json"))
        return result

    def add_event(self, task_id: str, event_type: str, node_id: str | None = None,
                  status: str | None = None, payload: Mapping[str, Any] | None = None) -> int:
        with self._connect() as connection:
            exists = connection.execute("SELECT 1 FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            cursor = connection.execute("""INSERT INTO task_events(task_id,event_type,node_id,status,payload,created_at)
                VALUES(?,?,?,?,?,?)""", (task_id, event_type, node_id, status, self._json(payload or {}), self._now()))
            return int(cursor.lastrowid)

    def get_task_events(self, task_id: str) -> list[dict[str, Any]]:
        """Return all persisted events for a task in chronological order."""
        with self._connect() as connection:
            exists = connection.execute(
                "SELECT 1 FROM tasks WHERE task_id=?", (task_id,)
            ).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            rows = connection.execute(
                """SELECT event_id,event_type,node_id,status,payload,created_at
                   FROM task_events
                   WHERE task_id=?
                   ORDER BY created_at ASC, event_id ASC""",
                (task_id,),
            ).fetchall()
        events: list[dict[str, Any]] = []
        for row in rows:
            event = dict(row)
            raw_payload = event.get("payload")
            if isinstance(raw_payload, str):
                try:
                    event["payload"] = json.loads(raw_payload)
                except json.JSONDecodeError:
                    event["payload"] = {"raw": raw_payload}
            elif raw_payload is None:
                event["payload"] = {}
            events.append(event)
        return events

    def commit_trade_data(self, task_id: str, trade_entities: list[Mapping[str, Any]],
                          trade_edges: list[Mapping[str, Any]], evidence: list[Mapping[str, Any]]) -> dict[str, int]:
        timestamp = self._now()
        with self._connect() as connection:
            exists = connection.execute("SELECT 1 FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if exists is None:
                raise KeyError(f"Task not found: {task_id}")
            for entity in trade_entities:
                connection.execute("""INSERT OR REPLACE INTO trade_entities
                    (entity_id,task_id,canonical_name,role,country,source,metadata) VALUES(?,?,?,?,?,?,?)""",
                    (str(entity["entity_id"]), task_id, str(entity["canonical_name"]), entity.get("role"),
                     entity.get("country"), entity.get("source"), self._json(entity.get("metadata", {}))))
            for edge in trade_edges:
                connection.execute("""INSERT OR REPLACE INTO trade_edges
                    (edge_id,task_id,source_entity_id,target_entity_id,relation_type,confidence,evidence_ids,metadata)
                    VALUES(?,?,?,?,?,?,?,?)""", (str(edge["edge_id"]), task_id, str(edge["source_entity_id"]),
                    str(edge["target_entity_id"]), str(edge["relation_type"]), edge.get("confidence"),
                    self._json(edge.get("evidence_ids", [])), self._json(edge.get("metadata", {}))))
            for item in evidence:
                connection.execute("""INSERT OR REPLACE INTO evidence
                    (evidence_id,task_id,entity_name,evidence_type,source,shipments,verified,evidence_json,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?)""", (str(item["evidence_id"]), task_id, str(item["entity_name"]),
                    item.get("evidence_type"), item.get("source"), self._json(item.get("shipments", [])),
                    1 if bool(item.get("verified", False)) else 0, self._json(item.get("evidence_json", {})),
                    item.get("created_at", timestamp)))
        return {"trade_entities": len(trade_entities), "trade_edges": len(trade_edges), "evidence": len(evidence)}
