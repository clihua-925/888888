"""AI Decision Layer for PSV Trade OS 9.4.0."""

from __future__ import annotations

import logging
from typing import Any, Mapping, MutableMapping

from core.model.reasoning import ReasoningEngine, ReasoningEngineError
from core.orchestration.state import TaskState

LOGGER = logging.getLogger(__name__)
DECISION_MISSION_UNDERSTANDING = "mission_understanding"
DECISION_ENTITY_RESOLUTION = "entity_resolution"
DECISION_RELATIONSHIP_JUDGMENT = "relationship_judgment"
DECISION_EVIDENCE_VERIFICATION = "evidence_verification"
DECISION_RESOURCE_CLASSIFICATION = "resource_classification"
SUPPORTED_DECISION_TYPES = frozenset({
    DECISION_MISSION_UNDERSTANDING,
    DECISION_ENTITY_RESOLUTION,
    DECISION_RELATIONSHIP_JUDGMENT,
    DECISION_EVIDENCE_VERIFICATION,
    DECISION_RESOURCE_CLASSIFICATION,
})
REQUIRED_RESULT_FIELDS = ("decision", "confidence", "rationale", "metadata")


class DecisionLayerError(RuntimeError):
    """Raised when an AI decision cannot be produced safely."""


class DecisionLayer:
    """Central AI judgment layer without orchestration authority."""

    def __init__(self, reasoning_engine: ReasoningEngine | None = None) -> None:
        self.reasoning = reasoning_engine if reasoning_engine is not None else ReasoningEngine()

    def decide(
        self,
        state: MutableMapping[str, Any] | TaskState,
        decision_type: str,
        prompt: str,
        payload: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Perform an AI judgment through the single reasoning boundary."""
        normalized_type = decision_type.strip() if isinstance(decision_type, str) else ""
        if normalized_type not in SUPPORTED_DECISION_TYPES:
            message = (
                f"Unsupported decision_type: {decision_type!r}. Supported types: "
                + ", ".join(sorted(SUPPORTED_DECISION_TYPES))
            )
            LOGGER.error(message)
            raise DecisionLayerError(message)

        normalized_prompt = prompt.strip() if isinstance(prompt, str) else ""
        if not normalized_prompt:
            message = "Decision prompt must not be empty"
            LOGGER.error(message)
            raise DecisionLayerError(message)

        decision_payload = dict(payload) if payload is not None else {}
        try:
            response_schema = self._response_schema(normalized_type)
            max_tokens = 4096 if normalized_type == DECISION_MISSION_UNDERSTANDING else 2048
            review_kwargs: dict[str, Any] = {
                "prompt": self._build_prompt(normalized_type, normalized_prompt, decision_payload),
                "system": self._system_prompt(normalized_type),
                "response_schema": response_schema,
                "max_tokens": max_tokens,
            }
            try:
                model_result = self.reasoning.review(**review_kwargs)
            except TypeError as exc:
                # Keep compatibility with legacy test doubles that predate max_tokens.
                if "max_tokens" not in str(exc):
                    raise
                review_kwargs.pop("max_tokens")
                model_result = self.reasoning.review(**review_kwargs)
        except ReasoningEngineError as exc:
            LOGGER.exception("AI decision failed: type=%s", normalized_type)
            raise DecisionLayerError(f"AI decision failed for {normalized_type}: {exc}") from exc
        except Exception as exc:
            LOGGER.exception("Unexpected AI decision failure: type=%s", normalized_type)
            raise DecisionLayerError(f"Unexpected AI decision failure for {normalized_type}: {exc}") from exc

        LOGGER.debug("Structured model result received: %r", model_result)

        try:
            decision = self._validate_result(model_result)
        except (TypeError, ValueError) as exc:
            LOGGER.exception("Invalid structured AI decision: type=%s", normalized_type)
            raise DecisionLayerError(f"Invalid AI decision result for {normalized_type}: {exc}") from exc

        record = {
            "decision_type": normalized_type,
            "decision": decision["decision"],
            "confidence": decision["confidence"],
            "rationale": decision["rationale"],
            "metadata": decision["metadata"],
        }
        decisions = state.get("decisions")
        if decisions is None:
            decisions = []
            state["decisions"] = decisions
        if not isinstance(decisions, list):
            message = "state['decisions'] must be a list"
            LOGGER.error(message)
            raise DecisionLayerError(message)
        decisions.append(record)
        return decision

    def _system_prompt(self, decision_type: str) -> str:
        configured_model = str(
            getattr(getattr(self.reasoning, "settings", None), "llm_model", "")
        ).strip()
        model_name = configured_model or "deepseek-r1-distill-llama-70b"
        decision_value_rule = (
            "For mission_understanding, the `decision` value MUST itself be a JSON object "
            "containing the Mission fields requested by the caller. Do not stringify that object.\n"
            if decision_type == DECISION_MISSION_UNDERSTANDING
            else "The `decision` value must contain the semantic judgment requested by the caller.\n"
        )
        return (
            "You are the PSV Trade OS 9.4.0 AI Decision Layer.\n"
            f"Declared reasoning model: {model_name}\n"
            "Your responsibility is semantic judgment only.\n"
            f"Decision type: {decision_type}\n\n"
            "You must not decide workflow routing, retry behavior, timeout behavior, "
            "recovery strategy, scheduling, or database write boundaries.\n\n"
            "Return exactly one valid JSON object with these outer fields: "
            '`decision`, `confidence`, `rationale`, and `metadata`.\n'
            f"{decision_value_rule}"
            "For mission_understanding, do not place Mission fields directly beside the outer fields; "
            "nest them under `decision`.\n"
            "Do not return Markdown, a code fence, or explanatory prose outside the JSON object."
        )

    @staticmethod
    def _response_schema(decision_type: str) -> dict[str, Any] | None:
        """Return the flat JSON Schema for a supported semantic decision."""
        decision_schemas: dict[str, dict[str, Any]] = {
            DECISION_MISSION_UNDERSTANDING: {
                "type": "object",
                "properties": {
                    "intent": {"type": "string"},
                    "task_type": {"type": "string"},
                    "objective": {"type": "string"},
                    "targets": {"type": "array", "items": {"type": "string"}},
                    "constraints": {"type": "array", "items": {"type": "string"}},
                    "success_criteria": {"type": "array", "items": {"type": "string"}},
                    "market": {"type": "string"},
                    "industry": {"type": "string"},
                },
                "required": [
                    "intent", "task_type", "objective", "targets",
                    "constraints", "success_criteria", "market", "industry",
                ],
                "additionalProperties": False,
            },
            DECISION_ENTITY_RESOLUTION: {
                "type": "object",
                "properties": {
                    "merge": {"type": "boolean"},
                    "canonical_name": {"type": "string"},
                },
                "required": ["merge", "canonical_name"],
                "additionalProperties": False,
            },
            DECISION_RELATIONSHIP_JUDGMENT: {
                "type": "object",
                "properties": {
                    "related": {"type": "boolean"},
                    "relation_type": {"type": "string"},
                    "evidence_ids": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["related", "relation_type", "evidence_ids"],
                "additionalProperties": False,
            },
            DECISION_EVIDENCE_VERIFICATION: {
                "type": "object",
                "properties": {
                    "verified": {"type": "boolean"},
                    "verification_reason": {"type": "string"},
                    "issues": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["verified", "verification_reason", "issues"],
                "additionalProperties": False,
            },
            DECISION_RESOURCE_CLASSIFICATION: {
                "type": "object",
                "properties": {
                    "resource_class": {"type": "string"},
                    "priority": {"type": "integer"},
                },
                "required": ["resource_class", "priority"],
                "additionalProperties": False,
            },
        }
        decision_schema = decision_schemas.get(decision_type)
        if decision_schema is None:
            return None
        return {
            "type": "object",
            "properties": {
                "decision": decision_schema,
                "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                "rationale": {"type": "string"},
                "metadata": {"type": "object", "additionalProperties": False},
            },
            "required": ["decision", "confidence", "rationale", "metadata"],
            "additionalProperties": False,
        }

    @staticmethod
    def _build_prompt(decision_type: str, prompt: str, payload: Mapping[str, Any]) -> str:
        return (
            f"Decision type: {decision_type}\n\n"
            f"Judgment instructions:\n{prompt}\n\n"
            f"Structured input payload:\n{dict(payload)}\n\n"
            "Return only the required JSON decision object."
        )

    @staticmethod
    def _validate_result(result: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(result, Mapping):
            raise TypeError("Decision result must be a mapping")
        missing = [field for field in REQUIRED_RESULT_FIELDS if field not in result]
        if missing:
            raise ValueError("Decision result is missing fields: " + ", ".join(missing))

        decision = result["decision"]
        confidence = result["confidence"]
        rationale = result["rationale"]
        metadata = result["metadata"]
        if not isinstance(decision, (str, dict, list, bool, int, float, type(None))):
            raise ValueError("decision must be JSON-compatible")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
            raise ValueError("confidence must be numeric")
        if not 0.0 <= float(confidence) <= 1.0:
            raise ValueError("confidence must be between 0.0 and 1.0")
        if not isinstance(rationale, str):
            raise ValueError("rationale must be a string")
        if not isinstance(metadata, Mapping):
            raise ValueError("metadata must be a mapping")
        return {
            "decision": decision,
            "confidence": float(confidence),
            "rationale": rationale,
            "metadata": dict(metadata),
        }
