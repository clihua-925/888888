"""Orchestration-side provider adapters for PSV Trade OS 9.4.0.

Dependency direction:
core.orchestration.providers -> core.contracts.providers -> (DecisionLayer / Database)
No cycle: core.contracts never imports core.orchestration.
"""

from __future__ import annotations

from typing import Any

from core.contracts.providers import DataProvider, DecisionProvider


class DecisionLayerProvider(DecisionProvider):
    """Adapt the orchestration DecisionLayer to the DecisionProvider interface."""

    def __init__(self, decision_layer: Any) -> None:
        self._decision_layer = decision_layer

    def decide(self, state: Any, decision_type: str, prompt: str, context: Any) -> dict:
        return self._decision_layer.decide(state, decision_type, prompt, context)


class DatabaseProvider(DataProvider):
    """Adapt the infrastructure Database to the DataProvider interface."""

    def __init__(self, database: Any) -> None:
        self._database = database

    def commit_trade_data(self, task_id: str, entities: Any, edges: Any, evidence: Any) -> dict[str, int]:
        return self._database.commit_trade_data(task_id, entities, edges, evidence)
