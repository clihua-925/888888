"""Natural-language mission understanding for PSV Trade OS 9.4.0."""

from __future__ import annotations

import json
import logging
from typing import Any, Mapping

from .decision import DecisionLayer, DecisionLayerError

LOGGER = logging.getLogger(__name__)
MISSION_FIELDS = (
    "intent", "task_type", "objective", "targets",
    "constraints", "success_criteria", "market", "industry",
)


class TaskUnderstandingError(RuntimeError):
    """Raised when natural-language task understanding fails."""


class TaskUnderstanding:
    """Convert natural-language requests into a standard Mission through DecisionLayer."""

    def __init__(self, decision_layer: DecisionLayer | None = None) -> None:
        self.decision_layer = decision_layer if decision_layer is not None else DecisionLayer()
        self.last_decision: dict[str, Any] = {}

    def understand(self, request: str) -> dict[str, Any]:
        """Understand a user request without executing business work."""
        normalized_request = request.strip() if isinstance(request, str) else ""
        if not normalized_request:
            message = "Natural-language task request must not be empty"
            LOGGER.error(message)
            raise TaskUnderstandingError(message)

        system_prompt = """
You are the Mission Understanding component of PSV Trade OS 9.4.0.

Your only responsibility is semantic understanding of the user's natural-language request.
Do not execute business operations. Do not call business nodes. Do not select workflow routes.
Do not decide retries, recovery, timeout, scheduling, or database actions. Do not invent execution results.

Return exactly one valid JSON object as the value of the outer DecisionLayer field `decision`.
The `decision` value MUST be a JSON object, not a sentence or scalar, with these fields:
{
  "intent": "",
  "task_type": "",
  "objective": "",
  "targets": [],
  "constraints": [],
  "success_criteria": [],
  "market": "",
  "industry": ""
}
Do not put the Mission fields directly at the outer DecisionLayer level.
If a field is not explicitly specified, use a neutral empty value. Do not return Markdown.
""".strip()
        user_prompt = (
            "Understand the following user request and return the standard Mission JSON structure only.\n\n"
            f"User request:\n{normalized_request}"
        )
        decision_state: dict[str, Any] = {
            "decisions": [],
            "mission": {},
        }

        try:
            decision = self.decision_layer.decide(
                decision_state,
                "mission_understanding",
                user_prompt,
                {
                    "request": normalized_request,
                    "required_fields": list(MISSION_FIELDS),
                },
            )
            self.last_decision = dict(decision_state["decisions"][-1])
        except DecisionLayerError as exc:
            LOGGER.exception("DecisionLayer failed during task understanding")
            raise TaskUnderstandingError(f"Task understanding failed: {exc}") from exc
        except Exception as exc:
            LOGGER.exception("Unexpected task understanding failure")
            raise TaskUnderstandingError(f"Task understanding failed unexpectedly: {exc}") from exc

        try:
            result = decision.get("decision") if isinstance(decision, Mapping) else None
            # Some OpenAI-compatible reasoning templates serialize the nested
            # Mission object as a JSON string inside the DecisionLayer envelope.
            # Accept that representation without changing the orchestration contract.
            if isinstance(result, str):
                candidate = result.strip()
                if candidate.startswith("{") and candidate.endswith("}"):
                    try:
                        result = json.loads(candidate)
                    except json.JSONDecodeError:
                        result = candidate
            return self._validate_mission(result)
        except (TypeError, ValueError) as exc:
            LOGGER.exception("DecisionLayer result does not satisfy Mission schema")
            raise TaskUnderstandingError(f"Invalid Mission result: {exc}") from exc

    @staticmethod
    def _validate_mission(result: Mapping[str, Any]) -> dict[str, Any]:
        """Validate and normalize the standard Mission structure."""
        if not isinstance(result, Mapping):
            raise TypeError("Mission result must be a mapping")
        missing = [field for field in MISSION_FIELDS if field not in result]
        if missing:
            raise ValueError("Mission result is missing fields: " + ", ".join(missing))

        mission: dict[str, Any] = {}
        for field in ("intent", "task_type", "objective", "market", "industry"):
            value = result[field]
            if not isinstance(value, str):
                raise ValueError(f"Mission field '{field}' must be a string")
            mission[field] = value.strip()

        for field in ("targets", "constraints", "success_criteria"):
            value = result[field]
            if not isinstance(value, (list, tuple)):
                raise ValueError(f"Mission field '{field}' must be a collection")
            mission[field] = list(value)
        return mission
