"""Compatibility shim: provider binding lives in core.contracts.context."""

from core.contracts.context import (  # noqa: F401
    get_data_provider,
    get_decision_provider,
    pop_providers,
    push_providers,
)

# Legacy aliases kept for orchestration internals during migration.
push_engine_context = push_providers
pop_engine_context = pop_providers
get_database = get_data_provider
get_decision_layer = get_decision_provider
