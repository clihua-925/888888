"""Contract registry and validation primitives for PSV Trade OS 9.4.0."""

from __future__ import annotations

from dataclasses import field
from typing import Iterable, Mapping

from core.contracts.nodes import ContractDefinition, NodeContract  # noqa: F401




@dataclass
class ContractRegistry:
    contracts: dict[str, ContractDefinition] = field(default_factory=dict)

    def register(self, contract: ContractDefinition) -> None:
        if contract.node_id in self.contracts:
            raise ValueError(f"Contract already registered: {contract.node_id}")
        self.contracts[contract.node_id] = contract

    def register_many(self, contracts: Iterable[ContractDefinition]) -> None:
        pending = list(contracts)
        node_ids = [contract.node_id for contract in pending]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("Duplicate node_id found in contract collection")
        duplicates = [node_id for node_id in node_ids if node_id in self.contracts]
        if duplicates:
            raise ValueError(f"Contracts already registered: {', '.join(duplicates)}")
        for contract in pending:
            self.contracts[contract.node_id] = contract

    def get(self, node_id: str) -> ContractDefinition:
        try:
            return self.contracts[node_id]
        except KeyError as exc:
            raise KeyError(f"Contract not registered: {node_id}") from exc

    def validate(self, node_id: str, state: Mapping[str, Any], *, phase: str) -> bool:
        contract = self.get(node_id)
        normalized_phase = phase.strip().lower()
        if normalized_phase == "input":
            contract.validate_input(state)
        elif normalized_phase == "output":
            contract.validate_output(state)
        else:
            raise ValueError("phase must be either 'input' or 'output'")
        return True

    def validate_input(self, node_id: str, state: Mapping[str, Any]) -> bool:
        return self.validate(node_id, state, phase="input")

    def validate_output(self, node_id: str, state: Mapping[str, Any]) -> bool:
        return self.validate(node_id, state, phase="output")
