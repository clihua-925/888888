"""Initial orchestration plan generation for PSV Trade OS 9.4.0."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .registry import RegisteredWorkflow, WorkflowRegistry


@dataclass(frozen=True)
class ExecutionPlan:
    """Declarative initial node order used only while building the LangGraph."""

    workflow_id: str
    version: str
    order: tuple[str, ...]


class OrchestrationPlanGenerator:
    """Build the initial node order from contract dependencies."""

    def __init__(self, registry: WorkflowRegistry) -> None:
        self.registry = registry

    def plan_for(self, workflow_id: str) -> ExecutionPlan:
        """Generate only the initial node order for a registered workflow."""
        workflow = self.registry.get(workflow_id)
        contracts = {contract.node_id: contract for contract in workflow.contracts}
        order = self._dependency_order(workflow, contracts)
        return ExecutionPlan(
            workflow_id=workflow.workflow_id,
            version=workflow.version,
            order=order,
        )

    @staticmethod
    def _dependency_order(
        workflow: RegisteredWorkflow,
        contracts: dict[str, Any],
    ) -> tuple[str, ...]:
        """Derive the initial node order from declared input/output dependencies."""
        node_ids = tuple(workflow.node_ids)
        produced_by: dict[str, set[str]] = {}

        for node_id in node_ids:
            for output_key in contracts[node_id].output_keys:
                produced_by.setdefault(output_key, set()).add(node_id)

        dependencies: dict[str, set[str]] = {
            node_id: set() for node_id in node_ids
        }
        for node_id in node_ids:
            for input_key in contracts[node_id].input_keys:
                dependencies[node_id].update(
                    producer
                    for producer in produced_by.get(input_key, set())
                    if producer != node_id
                )

        remaining = set(node_ids)
        resolved: list[str] = []
        while remaining:
            ready_candidates = [
                node_id
                for node_id in remaining
                if dependencies[node_id].issubset(set(resolved))
            ]
            if not ready_candidates:
                unresolved = ", ".join(sorted(remaining))
                raise ValueError(
                    f"Workflow '{workflow.workflow_id}' has cyclic or "
                    f"unresolved contract dependencies: {unresolved}"
                )

            previous_capabilities = (
                tuple(workflow.node_specs[resolved[-1]].get("capabilities", ()))
                if resolved
                else ()
            )

            def ready_key(node_id: str) -> tuple[int, int]:
                capabilities = tuple(
                    workflow.node_specs[node_id].get("capabilities", ())
                )
                if (
                    "evidence_verification" in previous_capabilities
                    and "entity_resolution" in capabilities
                ):
                    return (0, node_ids.index(node_id))
                if (
                    "evidence_verification" in capabilities
                    and "entity_resolution" not in capabilities
                ):
                    return (0, node_ids.index(node_id))
                return (1, node_ids.index(node_id))

            ready = sorted(ready_candidates, key=ready_key)
            resolved.extend(ready)
            remaining.difference_update(ready)

        return tuple(resolved)
