"""Provider interfaces: the only dependency channel Business may use."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class DecisionProvider(ABC):
    """AI decision interface available to business nodes."""

    @abstractmethod
    def decide(self, state: Any, decision_type: str, prompt: str, context: Any) -> dict:
        """Return a structured decision record."""


class DataProvider(ABC):
    """Data write interface available to business nodes."""

    @abstractmethod
    def commit_trade_data(self, task_id: str, entities: Any, edges: Any, evidence: Any) -> dict[str, int]:
        """Atomically commit trade data and return per-table counts."""
