"""Shared contract layer: state schema, node contracts, provider interfaces, provider context."""
