"""Shared pytest fixtures for PSV Trade OS 9.4.0 acceptance tests."""

from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any

# Acceptance tests must not create bytecode artifacts inside the deployable tree.
# Python normally creates __pycache__/pyc on import; disabling bytecode output keeps
# the source tree clean during iterative Windows development and test runs.
sys.dont_write_bytecode = True

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.memory.db import Database
from core.orchestration.state import (
    STATUS_COMPLETED,
    STATUS_PENDING,
    TaskState,
)


class FixedDecisionReasoning:
    """Test-only reasoning substitute; it never performs network I/O."""

    def review(
        self, prompt: str, system: str, response_schema: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return {
            "decision": "test_decision",
            "confidence": 0.95,
            "rationale": "fixed deterministic test judgment",
            "metadata": {"test_double": True},
        }


class IntegrationSchedulerDouble:
    """Isolated test substitute; this is not the real orchestration execution chain.

    The real API -> Scheduler -> Mission -> Task Understanding -> WorkflowRegistry
    -> LangGraph -> Condition Edge -> Business Nodes -> Checkpoint -> DATABASE_COMMIT
    path is verified only by ``verify_install.py --runtime``.
    """

    def __init__(self, database: Database) -> None:
        self.database = database

    def submit(
        self,
        workflow_id: str | None,
        request: str,
        market: str,
        industry: str,
    ) -> str:
        import uuid

        task_id = str(uuid.uuid4())
        selected = workflow_id or "trade_collection"
        state: TaskState = {
            "mission": {
                "request": request,
                "market": market,
                "industry": industry,
            },
            "product_definition": {"product": request},
            "trade_nodes": [
                {"node_id": "test-node-1", "role": "buyer"},
                {"node_id": "test-node-2", "role": "supplier"},
            ],
            "fragments": [{"fragment_id": "test-fragment"}],
            "evidence_pool": [
                {"evidence_id": "test-evidence", "entity_name": "Test Buyer", "verified": True}
            ],
            "entities": [
                {"entity_id": "test-entity-1", "canonical_name": "Test Buyer"}
            ],
            "relationships": [
                {
                    "edge_id": "test-edge-1",
                    "source_entity_id": "test-entity-1",
                    "target_entity_id": "test-entity-1",
                    "relation_type": "test_relation",
                }
            ],
            "decisions": [
                {
                    "decision_type": "mission_understanding",
                    "decision": "test_decision",
                    "confidence": 0.95,
                    "rationale": "test",
                    "metadata": {"test_double": True},
                }
            ],
            "history": [],
            "orchestration": {"step_count": 9, "no_progress_count": 0},
            "error": {},
            "node_reports": {
                "DATABASE_COMMIT": {
                    "status": "committed",
                    "entity_count": 1,
                    "relationship_count": 1,
                    "evidence_count": 1,
                }
            },
            "status": STATUS_COMPLETED,
            "task_id": task_id,
            "workflow_id": selected,
            "workflow_version": "9.4.0",
        }
        self.database.create_task(task_id, selected, state, STATUS_PENDING)
        self.database.add_event(
            task_id,
            "TASK_CREATED",
            status=STATUS_PENDING,
            payload={"test_double": True},
        )
        self.database.add_event(
            task_id,
            "AI_DECISION",
            node_id="TASK_UNDERSTANDING",
            status=STATUS_COMPLETED,
            payload={"test_double": True},
        )
        self.database.commit_trade_data(
            task_id,
            state["entities"],
            state["relationships"],
            state["evidence_pool"],
        )
        self.database.add_event(
            task_id,
            "DATABASE_COMMIT",
            node_id="DATABASE_COMMIT",
            status=STATUS_COMPLETED,
            payload={"test_double": True},
        )
        self.database.update_task(task_id, state, STATUS_COMPLETED)
        return task_id


@pytest.fixture
def temp_database_path(tmp_path: Path) -> Path:
    """Provide an isolated SQLite path for every test."""
    return tmp_path / "test_psv.db"


@pytest.fixture
def database(temp_database_path: Path) -> Database:
    """Provide an isolated Database gateway."""
    return Database(temp_database_path)


@pytest.fixture
def test_decision_layer():
    """Provide a DecisionLayer using a deterministic test-only reasoning substitute."""
    from core.orchestration.decision import DecisionLayer

    return DecisionLayer(reasoning_engine=FixedDecisionReasoning())


@pytest.fixture
def test_flask_client(database: Database, monkeypatch):
    """Provide a Flask client with an isolated database and scheduler double."""
    from core.orchestration.registry import WorkflowRegistry
    from core.webui.app import create_app

    registry = WorkflowRegistry()
    registry.discover()
    scheduler = IntegrationSchedulerDouble(database)
    monkeypatch.setenv("LLM_API_KEY", "test-only-not-used")
    application = create_app(database=database, registry=registry, scheduler=scheduler)
    application.config["TESTING"] = True
    return application.test_client()
