"""Frozen architecture, unit, persistence, and Flask acceptance tests."""

from __future__ import annotations

import ast
from dataclasses import fields
from pathlib import Path
import re
import sqlite3
import time

import pytest

from core.orchestration.state import (
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_PENDING,
    STATUS_PAUSED,
    STATUS_RUNNING,
    STATUS_TIMEOUT,
    TaskState,
)
from core.memory.db import Database

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_STATE_FIELDS = (
    "mission", "product_definition", "trade_nodes", "fragments", "evidence_pool",
    "entities", "relationships", "decisions", "history", "orchestration", "error", "node_reports",
)
REQUIRED_NODES = (
    "PRODUCT_DEFINITION", "TRADE_STRATEGY", "CUSTOMS_NODE_COLLECTION",
    "TRADE_EDGE_BUILD", "EVIDENCE_VERIFY", "ENTITY_RESOLUTION",
    "GRAPH_EXPANSION", "RESOURCE_CLASSIFICATION", "DATABASE_COMMIT",
)
FORBIDDEN_MARKERS = ("pa" + "ss", "TO" + "DO", "FIX" + "ME", "Not" + "Implemented" + "Error")
LEGACY_ROUTES = ("/api/search", "/api/products", "/api/trade", "/api/customs")
LEGACY_SEMANTICS = ("trade_" + "first_collection", "第" + "一采集链")


def source_files() -> list[Path]:
    """Return source files used by static acceptance checks."""
    return [
        path for path in ROOT.rglob("*")
        if path.is_file() and path.suffix.lower() in {".py", ".html", ".bat"}
        and ".venv" not in path.parts
    ]


def test_architecture_forbidden_items() -> None:
    """Ensure forbidden source markers and deployable artifacts are absent.

    Python bytecode caches are excluded from this source-tree assertion because the
    test harness disables bytecode generation in ``tests/conftest.py``; any caches
    left by an earlier run are cleaned by the test before the final artifact scan.
    """
    import shutil

    for path in list(ROOT.rglob("*")):
        if ".venv" not in path.parts and path.is_dir() and path.name == "__pycache__":
            shutil.rmtree(path)

    for path in ROOT.rglob("*"):
        if ".venv" in path.parts:
            continue
        assert path.suffix.lower() not in {".pyc", ".tmp", ".bak", ".swp"}
    for path in source_files():
        text = path.read_text(encoding="utf-8")
        for marker in FORBIDDEN_MARKERS:
            assert marker not in text
        if path.suffix.lower() == ".py":
            tree = ast.parse(text, filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    body = [
                        item for item in node.body
                        if not (
                            isinstance(item, ast.Expr)
                            and isinstance(getattr(item, "value", None), ast.Constant)
                            and isinstance(item.value.value, str)
                        )
                    ]
                    assert body, f"empty function: {path}:{node.name}"
    all_text = "\n".join(path.read_text(encoding="utf-8") for path in source_files())
    forbidden_ui_word = "place" + "holder"
    assert forbidden_ui_word not in all_text.lower()
    app = (ROOT / "core/webui/app.py").read_text(encoding="utf-8")
    page = (ROOT / "core/webui/static/mission.html").read_text(encoding="utf-8")
    for route in LEGACY_ROUTES:
        assert route not in app
        assert route not in page
    for semantic in LEGACY_SEMANTICS:
        assert semantic not in all_text
    assert not (ROOT / "core/webui/static/collection.html").exists()


def test_status_constants_have_single_definition_source() -> None:
    """Ensure task status values are defined only by shared state."""
    state_text = (ROOT / "core/orchestration/state.py").read_text(encoding="utf-8")
    assert all(name in state_text for name in (
        "STATUS_PENDING", "STATUS_RUNNING", "STATUS_COMPLETED", "STATUS_FAILED", "STATUS_PAUSED", "STATUS_TIMEOUT",
    ))
    for path in (ROOT / "core/orchestration").glob("*.py"):
        if path.name == "state.py":
            continue
        text = path.read_text(encoding="utf-8")
        assert not re.search(r"^STATUS_(?:PENDING|RUNNING|COMPLETED|FAILED|PAUSED|TIMEOUT)\s*=", text, re.MULTILINE)


def test_workflow_spec_has_no_orchestration_fields() -> None:
    """WorkflowSpec remains declarative and free of routing or recovery declarations."""
    spec = (ROOT / "business/workflows/trade_collection/spec.py").read_text(encoding="utf-8")
    assert not re.search(r"\b(ORDER|EDGES|RECOVERY)\s*=", spec)
    assert "ContractDefinition" in spec


def test_registry_is_generic() -> None:
    """Registry discovers workflow packages dynamically instead of importing business nodes."""
    registry = (ROOT / "core/orchestration/registry.py").read_text(encoding="utf-8")
    assert "pkgutil.iter_modules" in registry
    assert not re.search(r"from\s+business\.workflows\.trade_collection|import\s+business\.workflows\.trade_collection", registry)


def test_recovery_has_no_business_ids() -> None:
    """RecoveryManager contains generic policy behavior only."""
    recovery = (ROOT / "core/orchestration/recovery.py").read_text(encoding="utf-8")
    for node_id in REQUIRED_NODES:
        assert node_id not in recovery
    assert "failure_type" in recovery
    assert "node_failure" in recovery
    assert "contract_input_failure" in recovery
    assert "contract_output_failure" in recovery
    assert "timeout" in recovery
    assert "no_information_gain" in recovery
    assert "engine_failure" in recovery


def test_nine_nodes_are_complete() -> None:
    """All nine frozen business node functions and registry mapping are present."""
    nodes = (ROOT / "business/workflows/trade_collection/nodes.py").read_text(encoding="utf-8")
    for node_id in REQUIRED_NODES:
        assert re.search(rf"^def\s+{node_id}\(state:\s*TaskState\)\s*->\s*TaskState:", nodes, re.MULTILINE)
        assert f'"{node_id}"' in nodes


def test_task_state_fields_are_required_and_assignable() -> None:
    """TaskState is total and every frozen shared-state field can be assigned."""
    annotations = TaskState.__annotations__
    assert tuple(name for name in annotations if name in REQUIRED_STATE_FIELDS) == REQUIRED_STATE_FIELDS
    assert set(REQUIRED_STATE_FIELDS).issubset(annotations)
    assert getattr(TaskState, "__required_keys__", frozenset()) >= set(REQUIRED_STATE_FIELDS)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [], "fragments": [],
        "evidence_pool": [], "entities": [], "relationships": [], "decisions": [],
        "history": [], "orchestration": {}, "error": {}, "node_reports": {},
        "status": STATUS_PENDING, "task_id": "state-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    state["mission"] = {"request": "test"}
    state["trade_nodes"] = [{"node_id": "n1"}]
    assert state["mission"]["request"] == "test"
    assert state["trade_nodes"][0]["node_id"] == "n1"


def test_policy_dataclass_fields_and_defaults() -> None:
    """Policy exposes the frozen fields and validates its defaults."""
    from core.orchestration.policies import DEFAULT_POLICY, Policy
    names = [item.name for item in fields(Policy)]
    assert names == ["max_task_seconds", "max_steps", "max_retries", "no_progress_limit", "version"]
    assert DEFAULT_POLICY.max_task_seconds > 0
    assert DEFAULT_POLICY.max_steps > 0
    assert DEFAULT_POLICY.max_retries >= 0
    assert DEFAULT_POLICY.no_progress_limit > 0
    assert DEFAULT_POLICY.version == "9.4.0"


def test_contract_registry_register_get_validate() -> None:
    """ContractRegistry registers, retrieves, and validates both contract phases."""
    from core.orchestration.contracts import ContractDefinition, ContractRegistry
    registry = ContractRegistry()
    contract = ContractDefinition(
        "TEST_NODE", ("mission",), ("product_definition",), "test responsibility", "ok", "failed"
    )
    registry.register(contract)
    assert registry.get("TEST_NODE") is contract
    assert registry.validate("TEST_NODE", {"mission": {}}, phase="input") is True
    assert registry.validate("TEST_NODE", {"product_definition": {}}, phase="output") is True
    with pytest.raises(ValueError):
        registry.validate("TEST_NODE", {}, phase="input")
    with pytest.raises(ValueError):
        registry.validate("TEST_NODE", {}, phase="other")


def test_workflow_registry_discovers_trade_collection() -> None:
    """Dynamic registry discovery includes the trade collection workflow."""
    from core.orchestration.registry import WorkflowRegistry
    registry = WorkflowRegistry()
    workflows = registry.discover()
    workflow = registry.get("trade_collection")
    assert workflow in workflows
    assert workflow.workflow_id == "trade_collection"
    assert workflow.version == "9.4.0"
    assert len(workflow.node_ids) == 9


def test_condition_edge_verified_evidence_gate_route() -> None:
    """A verified evidence state routes from evidence verification to entity resolution."""
    from core.orchestration.conditions import ConditionEdgeEngine
    from core.orchestration.plan import OrchestrationPlanGenerator
    from core.orchestration.registry import WorkflowRegistry

    registry = WorkflowRegistry()
    registry.discover()
    registered = registry.get("trade_collection")
    plan = OrchestrationPlanGenerator(registry).plan_for(registered.workflow_id)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [{"node_id": "n1"}], "fragments": [],
        "evidence_pool": [{"evidence_id": "e1", "verified": True}], "entities": [], "relationships": [],
        "decisions": [], "history": [], "orchestration": {}, "error": {}, "node_reports": {},
        "status": STATUS_RUNNING, "task_id": "condition-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    outcome = ConditionEdgeEngine().choose(plan, state, "EVIDENCE_VERIFY")
    assert outcome.target == "ENTITY_RESOLUTION"
    assert outcome.reason == "verified_evidence_gate"
    assert outcome.outcome["success"] is True


def test_condition_edge_verified_evidence_gate_failure() -> None:
    """Unverified evidence terminates routing and marks the shared state failed."""
    from core.orchestration.conditions import ConditionEdgeEngine
    from core.orchestration.plan import OrchestrationPlanGenerator
    from core.orchestration.registry import WorkflowRegistry

    registry = WorkflowRegistry()
    registry.discover()
    plan = OrchestrationPlanGenerator(registry).plan_for("trade_collection")
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [{"node_id": "n1"}], "fragments": [],
        "evidence_pool": [{"evidence_id": "e1", "verified": False}], "entities": [], "relationships": [],
        "decisions": [], "history": [], "orchestration": {}, "error": {}, "node_reports": {},
        "status": STATUS_RUNNING, "task_id": "condition-failure-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    outcome = ConditionEdgeEngine().choose(plan, state, "EVIDENCE_VERIFY")
    assert outcome.target is None
    assert outcome.reason == "verified_evidence_gate_failed"
    assert state["status"] == STATUS_FAILED
    assert state["error"]["code"] == "VERIFIED_EVIDENCE_REQUIRED"


def test_recovery_manager_failure_types() -> None:
    """RecoveryManager evaluates retry policy using explicit failure types."""
    from core.orchestration.policies import Policy
    from core.orchestration.recovery import RecoveryManager

    policy = Policy(60, 10, 2, 3)
    manager = RecoveryManager(policy)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [], "fragments": [], "evidence_pool": [],
        "entities": [], "relationships": [], "decisions": [], "history": [],
        "orchestration": {"attempts": {}}, "error": {}, "node_reports": {},
        "status": STATUS_RUNNING, "task_id": "recovery-test", "workflow_id": "trade_collection",
        "workflow_version": "9.4.0",
    }
    assert manager.can_retry(state, "TEST_NODE", "node_failure") is True
    assert manager.can_retry(state, "TEST_NODE", "timeout") is False
    retry = manager.prepare_retry(state, "TEST_NODE", "broken", "contract_output_failure")
    assert retry["action"] == "RETRY"
    assert retry["failure_type"] == "contract_output_failure"
    assert manager.can_retry(state, "TEST_NODE", "engine_failure") is True
    failed = manager.fail(state, "TEST_FAILURE", "final failure")
    assert failed["action"] == "FAIL"
    assert state["status"] == STATUS_FAILED
    with pytest.raises(ValueError):
        manager.can_retry(state, "TEST_NODE", "unknown_failure")


def test_decision_layer_registered_decision_types(test_decision_layer) -> None:
    """DecisionLayer accepts every registered semantic decision type without network access."""
    from core.orchestration.decision import SUPPORTED_DECISION_TYPES
    expected = {
        "mission_understanding", "entity_resolution", "relationship_judgment",
        "evidence_verification", "resource_classification",
    }
    assert expected.issubset(SUPPORTED_DECISION_TYPES)
    state: TaskState = {
        "mission": {}, "product_definition": {}, "trade_nodes": [], "fragments": [], "evidence_pool": [],
        "entities": [], "relationships": [], "decisions": [], "history": [], "orchestration": {},
        "error": {}, "node_reports": {}, "status": STATUS_RUNNING, "task_id": "decision-test",
        "workflow_id": "trade_collection", "workflow_version": "9.4.0",
    }
    for decision_type in sorted(expected):
        result = test_decision_layer.decide(state, decision_type, "make a deterministic test judgment", {})
        assert result["confidence"] == 0.95
    assert len(state["decisions"]) == len(expected)


def test_database_create_get_event_and_commit(database) -> None:
    """Database supports task lifecycle, audit events, and trade-data persistence."""
    from core.memory.db import Database

    state = {
        "task_id": "database-test", "mission": {}, "product_definition": {}, "trade_nodes": [],
        "fragments": [], "evidence_pool": [], "entities": [], "relationships": [], "decisions": [],
        "history": [], "orchestration": {}, "error": {}, "node_reports": {}, "status": STATUS_PENDING,
        "workflow_id": "trade_collection", "workflow_version": "9.4.0",
    }
    database.create_task("database-test", "trade_collection", state, STATUS_PENDING)
    record = database.get_task("database-test")
    assert record["task_id"] == "database-test"
    event_id = database.add_event("database-test", "TEST_EVENT", node_id="TEST", status=STATUS_PENDING, payload={"ok": True})
    assert event_id >= 1
    events = database.get_task_events("database-test")
    assert events[-1]["event_type"] == "TEST_EVENT"
    entities = [{"entity_id": "e1", "canonical_name": "Entity 1", "role": "buyer", "country": "US", "source": "test"}]
    edges = [{"edge_id": "r1", "source_entity_id": "e1", "target_entity_id": "e1", "relation_type": "self", "confidence": 1.0, "evidence_ids": ["v1"]}]
    evidence = [{"evidence_id": "v1", "entity_name": "Entity 1", "evidence_type": "test", "source": "test", "shipments": [], "verified": True, "evidence_json": {}}]
    counts = database.commit_trade_data("database-test", entities, edges, evidence)
    assert counts == {"trade_entities": 1, "trade_edges": 1, "evidence": 1}
    connection = sqlite3.connect(database.database_path)
    try:
        assert connection.execute("SELECT COUNT(*) FROM trade_entities WHERE task_id=?", ("database-test",)).fetchone()[0] == 1
        assert connection.execute("SELECT COUNT(*) FROM trade_edges WHERE task_id=?", ("database-test",)).fetchone()[0] == 1
        assert connection.execute("SELECT COUNT(*) FROM evidence WHERE task_id=?", ("database-test",)).fetchone()[0] == 1
    finally:
        connection.close()


def test_contract_runtime_hooks_and_condition_router_are_preserved() -> None:
    """Static checks confirm A+B runtime contract and sole-router hooks remain present."""
    engine = (ROOT / "core/orchestration/engine.py").read_text(encoding="utf-8")
    assert "self.contract_registry.validate_input" in engine
    assert "self.contract_registry.validate_output" in engine
    assert "self.condition_engine.choose" in engine
    assert "self.decision_layer = DecisionLayer()" in engine
    assert "_record_database_commit" in engine
    assert 'push_engine_context' in engine
    assert 'pop_engine_context' in engine
    assert '_assert_state_serializable' in engine
    assert "CHECKPOINT" in engine
    nodes = (ROOT / "business/workflows/trade_collection/nodes.py").read_text(encoding="utf-8")
    assert 'get_database' in nodes
    assert "fallback Database" not in nodes
    task_understanding = (ROOT / "core/orchestration/task_understanding.py").read_text(encoding="utf-8")
    assert "DecisionLayer" in task_understanding
    assert "ReasoningEngine" not in task_understanding


def test_flask_health_workflows_run_and_poll(test_flask_client) -> None:
    """Exercise Flask routes with isolated persistence and an explicit test substitute.

    This is an isolated API integration test, not proof of the real orchestration chain.
    The real API -> Scheduler -> Mission -> Task Understanding -> WorkflowRegistry
    -> LangGraph -> Condition Edge -> Business Nodes -> Checkpoint -> DATABASE_COMMIT
    path is verified by ``verify_install.py --runtime``.
    """
    health = test_flask_client.get("/api/health")
    assert health.status_code == 200
    health_payload = health.get_json()
    assert health_payload["version"] == "9.4.0"

    workflows = test_flask_client.get("/api/orchestration/workflows")
    assert workflows.status_code == 200
    assert any(item["workflow_id"] == "trade_collection" for item in workflows.get_json()["workflows"])

    submitted = test_flask_client.post(
        "/api/orchestration/run",
        json={
            "request": "Test trade collection",
            "market": "US",
            "industry": "renewable energy",
            "workflow_id": "trade_collection",
        },
    )
    assert submitted.status_code == 202
    task_id = submitted.get_json()["task_id"]
    assert task_id

    deadline = time.monotonic() + 5
    task_payload = None
    while time.monotonic() < deadline:
        response = test_flask_client.get(f"/api/orchestration/tasks/{task_id}")
        assert response.status_code == 200
        task_payload = response.get_json()
        if task_payload["status"] in {STATUS_COMPLETED, STATUS_FAILED, STATUS_TIMEOUT, STATUS_PAUSED}:
            break
        time.sleep(0.02)
    assert task_payload is not None
    assert task_payload["status"] == STATUS_COMPLETED
    assert task_payload["state"]["entities"]
    assert task_payload["state"]["relationships"]
    assert task_payload["state"]["evidence_pool"]
    assert task_payload["database_commit"]["status"] == "committed"


def test_project_venv_launcher_is_frozen() -> None:
    """The Windows launcher uses the project-local .venv and retains the runtime gate."""
    launcher = (ROOT / "start.bat").read_text(encoding="utf-8")
    assert 'set "ENV_DIR=%~dp0.venv"' in launcher
    assert "%~dp0..\\venv" not in launcher
    assert "verify_install.py" in launcher
    assert "--runtime" in launcher
    assert "%ENV_PYTHON%" in launcher


def _is_generated_file(rel_path: str) -> bool:
    """判断一个文件是否是运行时生成文件（不参与 Manifest 计数）。"""
    # 1. SQLite 数据文件及 WAL/SHM 辅助文件
    if rel_path.startswith("data/") and ".db" in rel_path:
        return True
    # 2. WebUI 运行日志
    if rel_path in {"webui.out.log", "webui.err.log"}:
        return True
    # 3. apply_b*.ps1 生成的备份文件（防御性保留，备份已外置）
    if re.search(r"\.before_b\d+$", rel_path):
        return True
    return False


def test_manifest_matches_project_files() -> None:
    """Manifest count and listed source files match the deployable tree."""
    manifest_path = ROOT / "PROJECT_SOURCE_MANIFEST.txt"
    text = manifest_path.read_text(encoding="utf-8")
    match = re.search(r"^File count:\s*(\d+)\s*$", text, re.MULTILINE)
    assert match
    listed = [line.strip() for line in text.splitlines() if line.strip() and not line.startswith("PSV Trade OS") and not line.startswith("File count:")]
    generated_dirs = {".venv", ".pytest_cache", "__pycache__", "stageb_variants"}
    actual = [
        str(path.relative_to(ROOT)).replace("\\", "/")
        for path in ROOT.rglob("*")
        if path.is_file()
        and not any(part in generated_dirs for part in path.parts)
        and not _is_generated_file(str(path.relative_to(ROOT)).replace("\\", "/"))
        and path.suffix.lower() not in {".pyc", ".tmp", ".bak", ".swp"}
    ]
    assert int(match.group(1)) == len(actual)
    assert sorted(listed) == sorted(actual)


def test_decision_layer_forwards_mission_schema_to_reasoning() -> None:
    """The production DecisionLayer contract forwards the Mission schema when supported."""
    from core.orchestration.decision import DecisionLayer

    class SchemaSpy:
        def __init__(self) -> None:
            self.schema = None

        def review(self, prompt: str, system: str, response_schema=None):
            self.schema = response_schema
            return {
                "decision": {
                    "intent": "trade research",
                    "task_type": "collection",
                    "objective": "find partners",
                    "targets": ["solar panels"],
                    "constraints": [],
                    "success_criteria": ["verified evidence"],
                    "market": "US",
                    "industry": "solar",
                },
                "confidence": 0.99,
                "rationale": "deterministic test",
                "metadata": {},
            }

    spy = SchemaSpy()
    layer = DecisionLayer(reasoning_engine=spy)
    state = {"decisions": []}
    result = layer.decide(state, "mission_understanding", "understand this", {})
    assert result["decision"]["constraints"] == []
    assert spy.schema is not None
    assert spy.schema["properties"]["decision"]["properties"]["constraints"]["type"] == "array"


def test_mission_create_is_ai_deferred(tmp_path: Path) -> None:
    """Mission creation persists a pending task without invoking Task Understanding."""
    from core.orchestration.mission import MissionDirector
    from core.orchestration.registry import WorkflowRegistry

    class NoAI:
        def understand(self, request: str):
            raise AssertionError("AI must not run during create_pending")

    class EngineStub:
        def run(self, state, workflow, resume=False):
            return state

    registry = WorkflowRegistry()
    registry.discover()
    database_path = tmp_path / "test_mission_pending.db"
    mission = MissionDirector(database=Database(database_path), registry=registry, task_understanding=NoAI(), engine=EngineStub())
    task_id = mission.create_pending("Find solar partners", "US", "solar", "trade_collection")
    record = mission.database.get_task(task_id)
    assert record["status"] == STATUS_PENDING
    assert record["state"]["mission"]["objective"] == "Find solar partners"
    assert record["state"]["mission"]["constraints"] == []


def test_scheduler_recovers_pending_and_marks_interrupted_running(tmp_path: Path) -> None:
    """Scheduler startup recovers PENDING work and safely closes RUNNING work without a checkpoint."""
    from core.orchestration.scheduler import WorkflowScheduler
    from core.orchestration.state import STATUS_FAILED, STATUS_PENDING, STATUS_RUNNING

    class StubEngine:
        policy = type("Policy", (), {"max_task_seconds": 1800})()
        settings = type("Settings", (), {"checkpoint_path": tmp_path / "checkpoints.db"})()
        def has_checkpoint(self, task_id: str) -> bool:
            return False

    class StubMission:
        def __init__(self):
            self.database = Database(tmp_path / "recovery.db")
            self.engine = StubEngine()
            self.pending_executed = []
        def execute(self, task_id):
            self.pending_executed.append(task_id)
        def resume(self, task_id):
            raise AssertionError("resume must not be used without a checkpoint")

    mission = StubMission()
    for task_id, status in (("pending-1", STATUS_PENDING), ("running-1", STATUS_RUNNING)):
        state = {"mission": {"request": "x"}, "orchestration": {}, "status": status, "task_id": task_id, "workflow_id": "trade_collection"}
        mission.database.create_task(task_id, "trade_collection", state, status)
    WorkflowScheduler(mission)
    assert mission.database.get_task("running-1")["status"] == STATUS_FAILED
    assert mission.database.get_task("pending-1")["status"] == STATUS_PENDING
    assert mission.database.get_task_events("running-1")[-1]["event_type"] == "TASK_RECOVERY_FAILED"


def test_pack_manifest_builder_excludes_transients(tmp_path: Path) -> None:
    """The release packer rejects and excludes transient Python/build artifacts."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("pack_fused", ROOT / "pack_fused.py")
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "__pycache__" / "x.pyc").write_bytes(b"x")
    (tmp_path / "ok.py").write_text("x=1", encoding="utf-8")
    assert module._is_excluded(tmp_path / "__pycache__" / "x.pyc")
    assert module._is_excluded(tmp_path / "a.tmp")
