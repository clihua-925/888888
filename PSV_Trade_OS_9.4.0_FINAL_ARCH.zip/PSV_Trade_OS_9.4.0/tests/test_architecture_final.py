"""Final architecture gates: provider isolation, business isolation, timeout."""

from __future__ import annotations

import time
import uuid

import pytest

from core.contracts.context import (
    get_data_provider,
    get_decision_provider,
    pop_providers,
    push_providers,
)
from core.contracts.providers import DataProvider, DecisionProvider
from core.contracts.state import TaskState


class MockDecisionProvider(DecisionProvider):
    def __init__(self) -> None:
        self.calls = 0

    def decide(self, state, decision_type, prompt, context) -> dict:
        self.calls += 1
        return {"decision": True, "confidence": 0.9, "rationale": "mock"}


class MockDataProvider(DataProvider):
    def __init__(self) -> None:
        self.committed: dict[str, int] = {}

    def commit_trade_data(self, task_id, entities, edges, evidence) -> dict[str, int]:
        self.committed = {
            "trade_entities": len(entities),
            "trade_edges": len(edges),
            "evidence": len(evidence),
        }
        return dict(self.committed)


def _base_state() -> TaskState:
    return {
        "mission": {"request": "find solar buyers", "market": "US", "industry": "solar",
                    "objective": "solar", "targets": ["solar panel"]},
        "product_definition": {}, "trade_nodes": [], "fragments": [], "evidence_pool": [],
        "entities": [], "relationships": [], "decisions": [], "history": [],
        "orchestration": {}, "error": {}, "node_reports": {},
        "status": "RUNNING", "task_id": str(uuid.uuid4()),
        "workflow_id": "trade_collection", "workflow_version": "1.0.0",
    }


def test_provider_context_missing_raises() -> None:
    with pytest.raises(RuntimeError):
        get_decision_provider()
    with pytest.raises(RuntimeError):
        get_data_provider()


def test_business_runs_on_mock_providers() -> None:
    from business.workflows.trade_collection import nodes as biz

    mock_ai, mock_db = MockDecisionProvider(), MockDataProvider()
    token = push_providers(mock_ai, mock_db)
    try:
        state = _base_state()
        state = biz.PRODUCT_DEFINITION(state)
        state = biz.TRADE_STRATEGY(state)
        state = biz.CUSTOMS_NODE_COLLECTION(state)
        state = biz.TRADE_EDGE_BUILD(state)
        state = biz.EVIDENCE_VERIFY(state)
        state = biz.ENTITY_RESOLUTION(state)
        state = biz.GRAPH_EXPANSION(state)
        state = biz.RESOURCE_CLASSIFICATION(state)
        state = biz.DATABASE_COMMIT(state)
        assert state["node_reports"]["DATABASE_COMMIT"]["status"] == "committed"
        assert mock_ai.calls > 0
        assert mock_db.committed["evidence"] >= 1
    finally:
        pop_providers(token)


def test_scheduler_hard_timeout_terminates_worker(tmp_path) -> None:
    from core.orchestration.scheduler import _SELFTEST_SLEEP_MODE, WorkflowScheduler

    class _StubPolicy:
        max_task_seconds = 1800

    class _StubEngine:
        policy = _StubPolicy()

    class _StubMission:
        engine = _StubEngine()

        def _settings_values(self) -> dict:
            return {"app_version": "9.4.0", "web_host": "127.0.0.1", "web_port": 8090,
                    "llm_base_url": "http://x", "llm_api_key": "", "llm_model": "m",
                    "database_path": str(tmp_path / "p.db"), "checkpoint_path": str(tmp_path / "c.db"),
                    "log_level": "INFO", "max_task_seconds": 1800, "max_steps": 40,
                    "max_retries": 2, "no_progress_limit": 3, "sleep_seconds": 30}

    scheduler = WorkflowScheduler.__new__(WorkflowScheduler)
    scheduler.mission_director = _StubMission()
    started = time.monotonic()
    scheduler._run_task_in_worker("t-selftest", _SELFTEST_SLEEP_MODE, deadline_seconds=3)
    assert time.monotonic() - started < 20
