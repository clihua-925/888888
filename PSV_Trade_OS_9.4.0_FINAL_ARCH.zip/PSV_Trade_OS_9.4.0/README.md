# PSV Trade OS 9.4.0

PSV Trade OS 9.4.0 是 Windows 原生的外贸智能执行系统，以冻结架构为唯一运行基线。

## 冻结架构

五层边界：
1. WebUI / API
2. Orchestration Agent
3. Business
4. Contract / Runtime / State
5. Infrastructure

Business 层保持九个纯执行节点：
1. PRODUCT_DEFINITION
2. TRADE_STRATEGY
3. CUSTOMS_NODE_COLLECTION
4. TRADE_EDGE_BUILD
5. EVIDENCE_VERIFY
6. ENTITY_RESOLUTION
7. GRAPH_EXPANSION
8. RESOURCE_CLASSIFICATION
9. DATABASE_COMMIT

业务节点不负责路由、重试、恢复、超时、调度或 checkpoint 生命周期控制。DATABASE_COMMIT 是唯一正式业务数据库写入边界。

## Condition Edge verified_evidence_gate

`core/orchestration/conditions.py` 是唯一正式运行时路由器。当前节点为 `EVIDENCE_VERIFY` 时，路由器检查 `state["evidence_pool"]`：

- 存在 `verified=True` 的证据：路由到 `ENTITY_RESOLUTION`。
- 不存在：将状态设置为 `STATUS_FAILED`，写入 `VERIFIED_EVIDENCE_REQUIRED` 错误，并终止路由。

该条件逻辑不在 Business Node 或 WorkflowSpec。

## DATABASE 注入边界

`DATABASE_COMMIT` 不再创建 Database fallback。WorkflowEngine 在执行业务节点前向 `state["orchestration"]["database"]` 注入 Database 实例，节点执行完成后移除该瞬态对象；缺失注入时 `DATABASE_COMMIT` 直接抛出 RuntimeError。

## 测试分层

`tests/conftest.py` 中的 `FixedDecisionReasoning` 和 `IntegrationSchedulerDouble` 都是隔离测试替身，不代表真实生产编排链路。Flask 测试用于 API、隔离数据库和路由契约验证。

真实全链路：

`API -> Scheduler -> Mission -> Task Understanding -> WorkflowRegistry -> LangGraph -> Condition Edge -> Business Nodes -> Checkpoint -> DATABASE_COMMIT -> SQLite`

由：

```text
python verify_install.py --runtime
```

执行验证。

## Windows 部署

1. 安装 Python 3.10–3.13。
2. 根据 `.env.example` 配置环境。
3. 配置可访问的 OpenAI-compatible LLM endpoint，并使用 `deepseek-r1-distill-llama-70b`。
4. 运行 `start.bat`。
5. 启动脚本创建项目内 `.venv`、安装 requirements、执行静态/运行时门禁，然后启动 `127.0.0.1:8090`。
6. 如需 Chrome/Edge CDP 9222，运行 `start_chrome_debug.bat`。

## 验证

静态验证：

```text
.venv\Scripts\python.exe verify_install.py
.venv\Scripts\python.exe -m pytest tests -q
```

完整运行时验证：

```text
.venv\Scripts\python.exe verify_install.py --runtime
```

Runtime Gate 要求真实第三方依赖和可访问的 OpenAI-compatible endpoint；不会使用 Mock LLM 替代真实运行。

## 固定配置

- APP_VERSION=9.4.0
- WEB_HOST=127.0.0.1
- WEB_PORT=8090
- LLM_BASE_URL=http://127.0.0.1:8081/v1
- LLM_MODEL=deepseek-r1-distill-llama-70b
- DATABASE_PATH=data/psv.db
- CHECKPOINT_PATH=data/checkpoints.db
- MAX_TASK_SECONDS=1800
- MAX_STEPS=40
- MAX_RETRIES=2
- NO_PROGRESS_LIMIT=3

## 环境目录

Windows 启动链使用项目内 `.venv`，环境目录与源码项目同级且属于项目部署目录的一部分。
