from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "PSV_Trade_OS_9.4.0_FUSED_COMPLETE.zip"
EXCLUDE_DIRS = {"__pycache__", ".git", ".venv", ".pytest_cache"}
EXCLUDE_SUFFIXES = {".pyc", ".tmp", ".bak", ".swp"}
MANIFEST = ROOT / "PROJECT_SOURCE_MANIFEST.txt"


def _is_excluded(path: Path) -> bool:
    return any(part in EXCLUDE_DIRS for part in path.parts) or path.suffix.lower() in EXCLUDE_SUFFIXES


def clean_transients() -> None:
    for path in sorted(ROOT.rglob("*"), reverse=True):
        if path.is_dir() and path.name in EXCLUDE_DIRS:
            shutil.rmtree(path, ignore_errors=True)
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in EXCLUDE_SUFFIXES:
            path.unlink()


def deployable_files() -> list[Path]:
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file() and not _is_excluded(path)
    )


def write_manifest(files: list[Path]) -> None:
    relative = [path.relative_to(ROOT).as_posix() for path in files]
    content = "PSV Trade OS 9.4.0\n" + f"File count: {len(relative)}\n\n" + "\n".join(relative) + "\n"
    MANIFEST.write_text(content, encoding="utf-8")


def validate_clean_archive(files: list[Path]) -> None:
    forbidden = [path for path in files if _is_excluded(path)]
    if forbidden:
        raise RuntimeError("Forbidden transient files remain: " + ", ".join(map(str, forbidden)))


def build() -> None:
    clean_transients()
    write_manifest(deployable_files())
    files = deployable_files()
    validate_clean_archive(files)
    if OUTPUT.exists():
        OUTPUT.unlink()
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(OUTPUT, "r") as archive:
        names = archive.namelist()
        bad = [name for name in names if any(part in EXCLUDE_DIRS for part in Path(name).parts) or Path(name).suffix.lower() in EXCLUDE_SUFFIXES]
        if bad:
            raise RuntimeError("Archive contains forbidden transient artifacts: " + ", ".join(bad))
    print(f"Fused package: {OUTPUT}")
    print(f"Files: {len(files)}")


if __name__ == "__main__":
    build()
