@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo PSV Trade OS 9.4.0 - Windows Startup
echo ============================================================
echo [INFO] Project: %CD%
echo [INFO] Project environment: %~dp0.venv
echo.

set "PYTHON_EXE="
set "PYTHON_VERSION="
set "PYTHON_MAJOR="
set "PYTHON_MINOR="

for /f "tokens=2 delims= " %%V in ('python --version 2^>^&1') do set "PYTHON_VERSION=%%V"
if defined PYTHON_VERSION (
    for /f "tokens=1,2 delims=." %%A in ("!PYTHON_VERSION!") do (
        set "PYTHON_MAJOR=%%A"
        set "PYTHON_MINOR=%%B"
    )
    if "!PYTHON_MAJOR!"=="3" if !PYTHON_MINOR! GEQ 10 if !PYTHON_MINOR! LEQ 13 set "PYTHON_EXE=python"
)

if not defined PYTHON_EXE (
    for %%V in (3.13 3.12 3.11 3.10) do (
        py -%%V -c "import sys; raise SystemExit(0 if sys.version_info[:2] >= (3,10) and sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1
        if not errorlevel 1 if not defined PYTHON_EXE set "PYTHON_EXE=py -%%V"
    )
)

if not defined PYTHON_EXE (
    echo [ERROR] Python 3.10-3.13 was not found.
    echo Install a supported Python version and run this script again.
    pause
    exit /b 1
)

echo [OK] Python launcher: !PYTHON_EXE!

rem The frozen startup contract uses a project-local .venv.
rem Iterative external testing may use a separate parent\venv, but this launcher does not.
set "ENV_DIR=%~dp0.venv"
set "ENV_PYTHON=%ENV_DIR%\Scripts\python.exe"
set "ENV_ACTIVATE=%ENV_DIR%\Scripts\activate.bat"

if not exist "%ENV_PYTHON%" (
    echo [INFO] Project venv not found. Creating: %ENV_DIR%
    !PYTHON_EXE! -m venv "%ENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to create external venv.
        pause
        exit /b 1
    )
) else (
    echo [OK] Project venv found: %ENV_DIR%
)

call "%ENV_ACTIVATE%"
if errorlevel 1 (
    echo [ERROR] Failed to activate external venv.
    pause
    exit /b 1
)

rem Clean only project-generated transient files. The external venv is never touched.
for /d /r "%~dp0" %%D in (__pycache__) do if exist "%%D" rd /s /q "%%D" >nul 2>&1
if exist ".pytest_cache" rd /s /q ".pytest_cache" >nul 2>&1
for /r "%~dp0" %%F in (*.pyc *.tmp *.bak *.swp) do if exist "%%F" del /q "%%F" >nul 2>&1

echo [INFO] Upgrading pip in external environment ...
"%ENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 (
    echo [ERROR] pip upgrade failed.
    pause
    exit /b 1
)

echo [INFO] Installing or validating requirements in external environment ...
"%ENV_PYTHON%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo [ERROR] Dependency installation failed.
    pause
    exit /b 1
)

echo [INFO] Running runtime verification ...
"%ENV_PYTHON%" "%~dp0verify_install.py" --runtime
if errorlevel 1 (
    echo [ERROR] Runtime verification failed. WebUI will not start.
    pause
    exit /b 1
)

echo [OK] Runtime verification succeeded.
echo [INFO] Starting WebUI ...
start "PSV Trade OS 9.4.0" cmd /k "cd /d \"%~dp0\" ^&^& \"%ENV_PYTHON%\" run_webui.py"
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:8090"

echo [OK] WebUI started at http://127.0.0.1:8090
echo Project environment remains at: %ENV_DIR%
echo This launcher window will remain open.
pause
endlocal
