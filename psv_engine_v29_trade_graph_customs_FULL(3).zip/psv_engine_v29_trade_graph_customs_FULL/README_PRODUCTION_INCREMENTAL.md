# PSV v27.3.0 — Customs Incremental Production Final

## Production source policy
1. ImportYeti remains the primary public U.S. customs/BOL relationship source.
2. ImportKey public company customs pages are an additional hard-evidence relationship source, used only for entity-known supplier/customer enrichment; it is not a generic web-search source.
3. Local customs_raw/customs_bulk remain first-class sources.
4. Ordinary web/B2B/exhibition sources remain secondary enrichment/verification only.
5. No login, CAPTCHA, paywall, robots/access-control bypass, or private endpoint is attempted.

## Incremental behavior
- New entities are prioritized.
- Existing entities are refreshed and field-level merged.
- Customs graph continues buyer -> supplier -> buyer expansion.
- Only genuinely new customers enter the development pool.
- Existing customers keep their lifecycle zone.
- Checkpoints + overlap prevent repeated top-N exhaustion and boundary misses.

## ImportKey limitation
The public ImportKey pages expose U.S. customs shipment/relationship information and state that records are refreshed daily. Free visibility is limited and may change. The adapter therefore treats ImportKey as an opportunistic public hard-evidence source, never as a guaranteed unlimited feed. If public access changes, the pipeline skips it and continues with other configured customs sources.

## Safety / compliance
Use only publicly accessible or properly authorized data paths and comply with each provider's current terms and access rules. The collector must fail closed rather than attempt to bypass authentication, CAPTCHA, rate limits, or other access controls.
