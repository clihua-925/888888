# -*- coding:utf-8 -*-
import sqlite3, os
from core.config import settings
print("PSV v28 check")
print("DB:", settings.DATABASE_PATH)
if os.path.exists(settings.DATABASE_PATH):
    c=sqlite3.connect(settings.DATABASE_PATH)
    for t in ["leads","customs_raw","relationships","development_blackboard"]:
        try: print(t, c.execute("select count(*) from "+t).fetchone()[0])
        except Exception as e: print(t,e)
    c.close()
else: print("database missing")
