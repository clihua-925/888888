# PSV Engine v27 · Customs Graph Core

## 这版的核心原则

PSV 的第一采集链只把**可追溯的海关/提单贸易数据**当作硬数据源。普通网页、展会、B2B、企业目录不会被混进第一轮客户采集，更不会凭普通搜索结果制造“客户→供应商”关系。

核心链：

```text
海关贸易数据
   ↓
第一轮客户（Importer / Buyer）
   ↓
首轮清洗 + 清洗质量闸门
   ↓
客户 → 供应商（仍然从海关贸易记录提取）
   ↓
供应商池
   ↓
供应商 → 客户（仍然从海关贸易记录提取）
   ↓
二次清洗 / 去重 / 交叉验证
   ↓
证据资格闸门
   ↓
客户数据库 / 开发池
```

### 数据源分层

**Tier 1：第一采集层（硬贸易源）**

- `customs_bulk`
- `customs_raw`
- `importyeti`
- `importyeti_web`
- `CUSTOMS_WEB_SOURCES` 中明确配置、且确实返回海关/提单贸易字段的公开或授权端点

**Tier 2：补充/验证层**

- 用户配置的公开爬虫网站
- 展会资料
- 企业官网、公开网络信息
- Web AI 画像验证

Tier 2 不会自动补齐第一轮客户数量，也不能生成硬贸易关系。

### 重要的数据保留规则

- 已经确定是 importer/buyer/customer 的记录，即使只有公司名称，也必须保留。
- 电话、邮箱、网站、地址缺失属于“画像不完整”，不是“客户无效”。
- 真正垃圾主体（货代、物流、包装、咨询、百科、媒体、展会等）进入隔离区。
- 每条贸易关系尽量保存 `source + evidence + raw_ids`，可以追溯为什么产生这条关系。
- 网络扩张必须受到 `depth / buyers / suppliers / customers / max_new` 预算限制，不无限循环。

## 目录

- `core/runtime/`：专家节点、图编排、失败恢复、开发信第二流程
- `core/tools/customs_graph.py`：海关关系图核心，负责 Buyer→Supplier / Supplier→Buyer
- `core/tools/data_sources/`：海关数据源统一管理与额度策略
- `core/tools/iy_web.py`：ImportYeti 浏览器数据采集
- `core/tools/expand.py`：客户数据库网络扩张
- `core/tools/contact_finder.py`：客户画像补全
- `core/tools/web_ai.py`：网页 AI 验证/补全
- `core/runtime/development.py`：开发信序列
- `core/webui/app.py`：Web UI
- `data/industry_configs/`：品类配置
- `data/markets.json`：地区配置

## 通信 / 开发信序列

通信页提供全局“开发信序列”开关：关闭后不会启动新的第二流程/定时开发任务；已运行任务不强行中断。客户行实时显示执行中的黄色闪烁、已发送的蓝色状态、已生成草稿的紫色状态。

## Windows 启动

1. 保持项目文件夹和 `venv` 同级（如果你原来的 venv 已经安装好依赖，可以继续使用）。
2. 双击 `start.bat`。
3. `start.bat` 会检查 Python、LangGraph、Playwright，并自动准备浏览器环境。
4. ImportYeti 网页关系采集需要桌面 Chrome/Edge 的 CDP 时，启动脚本会自动准备 9222 端口。
5. 浏览器窗口不要在采集过程中关闭。

Web UI：`http://localhost:8090`

## 环境配置

复制 `.env.example` 为 `.env`，按机器实际情况修改。

第一轮测试建议：

```text
OUTREACH_ENABLED=false
IMPORTYETI_ENABLED=false
IY_WEB_ENABLED=true
HARVEST_ENABLED=true
PUBLIC_CRAWLER_ENABLED=false
```

如果有其他合法可访问、并且确实返回海关贸易数据的网站，可加入：

```text
CUSTOMS_WEB_SOURCES=NAME|https://example.com/api/search?q={query};NAME2|https://example2.com/search?q={query}
```

系统不会登录、绕验证码、绕付费墙或绕访问控制。

## 测试

在项目根目录执行：

```bash
python -m pytest -q
```

部署包应保持干净：`data/psv.db` 不随包提供，第一次启动时自动创建数据库；真实客户数据、海关原始数据和运行日志由部署机器自己产生。

## 27.1.1 修复与优化

- 修复“发现流程显示开发池 N 家，但客户数据库开发池为空”的入池提交问题：入池现在采用 `commit_discovery_lead()`，UPDATE 0 行会自动补写并二次校验。
- 第一轮有效客户全部进入海关关系图；本地 `customs_raw` 全量跑客户→供应商，ImportYeti 网页只负责外部补缺并受预算限制。
- 第一轮仍严格禁止普通网页/展会补数量；它们只能作为后续扩张、交叉验证、画像补全来源。
- 通信页新增“开发信序列”全局开关；关闭时不会启动新的开发序列或定时开发任务，正在运行的任务不强制中断。
- 通信页增加客户状态视觉反馈：执行中黄色闪烁、已发送蓝色、已生成草稿紫色，并自动刷新。
- 增加回归测试，覆盖客户入池和开发信状态。

## v27.1.2 修复说明
- 修复 DISCOVERY_COMMIT 的 SQLite `type 'list' is not supported`：海关 HS/产品等数组字段入库前统一标量化。
- 第一采集链继续锁定海关/提单数据源；总统筹提示也明确禁止 B2B/普通搜索/展会替代第一采集证据。
- 客户数据库改为“客户列表 + 右侧详情”，支持开发池/维护池/待验证/剔除/未分区之间迁移。
- 客户详情增加开发资格、海关票数、来源、客户↔供应商关系、证据事件、网络扩张入口。
- 网络扩张支持针对当前客户执行，并显示执行中的客户闪烁、累计扩张次数。
- 通信页面增加开发信序列总开关和“启动本轮开发信序列”按钮；客户列表与详情分栏，详情包含开发信/发送记录。
- 仪表盘增加开发池、维护池、待验证、扩张执行中等统计。
- 运行全套测试：11 passed。


## v27.2.0 生产稳定版：海关多源增量图谱

本版将采集源头与重复执行逻辑固定为生产策略：

1. **海关/提单源 fan-out**：`customs_bulk`、`customs_raw`、ImportYeti API/网页以及用户明确配置的海关 JSON 端点属于第一采集层；不会因为第一个源达到数量就跳过后续硬证据源。
2. **增量 delta**：每个 `(source, market, industry, query variants)` 保存独立 checkpoint；优先处理上次运行后出现的新/变化海关记录。
3. **历史轮换窗口**：没有新数据时，不返回空结果，而从完整海关客户集合按游标轮换，避免第 5 次、第 N 次任务因重复 TOP N 而“没有数据”。
4. **实体解析与跨源合并**：同一客户来自多个海关源时合并 shipments、最后提货、HS、产品、来源等证据。
5. **画像增量合并**：已有客户只补充新字段/新证据，保留原有网站、联系方式、开发状态和区域；海关票数取更高值、最后提货取更新值。
6. **新客户才进入开发池**：第二次及以后再次发现已有客户不会把维护客户重新扔回开发池；只有真正新实体才进入 `dev`。
7. **客户→供应商→客户图谱继续增量扩张**：已有客户仍可以因为新的海关记录进入关系挖掘，不能因为“客户已经存在”而跳过关系。

这一策略借鉴了生产级 Customer 360 / Entity Resolution 的增量处理模式：只处理新增或变化记录、保留 source record 与统一实体的映射、使用 checkpoint/idempotent upsert，并将图关系作为可持续更新的数据产品。
