import json
import sqlite3


def test_discovery_commit_reliably_merges_existing_lead_without_reentering_dev(tmp_path, monkeypatch):
    db_path = tmp_path / 'psv.db'
    monkeypatch.setenv('DATABASE_PATH', str(db_path))
    from core.memory import db as dbmod
    from core.runtime import nodes
    from core.config import settings
    monkeypatch.setattr(settings, 'DATABASE_PATH', str(db_path))
    db = dbmod.DB(str(db_path))
    monkeypatch.setattr(nodes.experts, 'review', lambda *a, **k: {'verdict': 'pass', 'notes': ''})
    name = 'The Felt Store Inc.'
    db.upsert_leads([{'name': name, 'country': 'USA', 'kind': 'importer', 'shipments': 4, 'source': 'customs_raw'}])
    state = {'task_id': 't1', 'industry': 'candle', 'new_companies': [
        {'name': name, 'country': 'USA', 'industry': 'candle', 'source': 'customs_raw',
         'evidence': {'shipments': 4, 'customs': True}}
    ], 'node_reports': {}}
    out = nodes.n_discovery_commit(state)
    assert out['_success'] is True
    assert out['discovery_commit']['dev'] == 0
    assert out['discovery_commit']['updated'] == 1
    assert db.list_leads(zone='dev') == []
    assert db.get_lead(db._norm(name))['name'] == name


def test_lead_outreach_state(tmp_path):
    from core.memory.db import DB
    db = DB(str(tmp_path / 'psv.db'))
    name = 'Example Importer LLC'
    db.upsert_leads([{'name': name, 'country': 'USA', 'kind': 'importer', 'source': 'customs_raw'}])
    norm = db._norm(name)
    assert db.list_leads()[0]['outreach_state'] == 'not_started'
    db.add_message(norm, 'out', 'email', 'Subject: test\n\nbody', draft=1)
    assert db.list_leads()[0]['outreach_state'] == 'draft'
    db.add_message(norm, 'out', 'email', 'Subject: test\n\nbody', draft=0)
    assert db.list_leads()[0]['outreach_state'] == 'sent'


def test_clean_verify_does_not_preinsert_new_customer_before_discovery_commit(tmp_path, monkeypatch):
    db_path = tmp_path / 'psv.db'
    monkeypatch.setenv('DATABASE_PATH', str(db_path))
    from core.memory import db as dbmod
    from core.runtime import nodes
    from core.config import settings
    monkeypatch.setattr(settings, 'DATABASE_PATH', str(db_path))
    db = dbmod.DB(str(db_path))
    monkeypatch.setattr(nodes.experts, 'review', lambda *a, **k: {'verdict': 'pass', 'notes': ''})
    state = {'task_id': 't-clean-commit', 'industry': 'candle', 'companies': [
        {'name': 'Brand New Candle LLC', 'country': 'USA', 'source': 'customs_raw',
         'evidence': {'shipments': 5, 'customs': True, 'trade_evidence': True}}
    ], 'node_reports': {}}
    cleaned = nodes.n_clean_verify(state)
    assert db.get_lead(db._norm('Brand New Candle LLC')) is None
    state.update(cleaned)
    committed = nodes.n_discovery_commit(state)
    assert committed['_success'] is True
    assert committed['discovery_commit']['dev'] == 1
    assert db.get_lead(db._norm('Brand New Candle LLC'))['zone'] == 'dev'
