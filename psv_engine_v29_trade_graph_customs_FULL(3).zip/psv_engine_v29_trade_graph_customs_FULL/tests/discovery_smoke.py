import os,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(root))
os.environ['DATABASE_PATH']=str(root/'data'/'discovery_smoke.db')
os.environ['EXPERT_MODE']='false'; os.environ['MISSION_DIRECTOR_ENABLED']='false'; os.environ['WEBAI_ENABLED']='false'; os.environ['IY_WEB_ENABLED']='false'; os.environ['HARVEST_ENABLED']='false'; os.environ['SCHEDULER_ENABLED']='false'
try:(root/'data'/'discovery_smoke.db').unlink()
except:pass
from core.memory.db import DB
import core.tools.data_sources.manager as mgr
import core.tools.suppliers as sup
from core.runtime.orchestrator import Orchestrator

def fake_search(self,market,industry,quantity,variants_override=None,source_queries=None):
    return ([{'name':f'Acme Buyer {i} LLC','country':market,'industry':industry,'type':'importer','website':f'https://acme{i}.example','source':'fake','strength':5,'evidence':{'shipments':12}} for i in range(1,4)],['fake'],[],{'ok':True,'raw':1,'qualified':1,'strong':1})
mgr.DataSourceManager.search=fake_search
sup.pool=lambda days=90,min_shipments=1:[{'norm':'supplierone','name':'Supplier One','slug':'supplier-one','shipments':20,'harvested':True,'via':'fake'}]
sup.upsert_pool=lambda p:None
orch=Orchestrator(); out=orch.run('smoke discovery','USA','candle',5,task_id='disc-smoke')
assert out.get('success') is True, out.get('error')
assert out.get('companies'),out
print('DISCOVERY_SMOKE_OK',out.get('companies'))
