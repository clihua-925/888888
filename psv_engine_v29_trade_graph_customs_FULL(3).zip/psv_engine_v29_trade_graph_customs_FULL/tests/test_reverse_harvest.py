import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from core.tools.data_sources.manager import identity_valid,hard_evidence,norm
from core.runtime import graph

def test_identity_only_is_kept():
    assert identity_valid({'name':'ABC Importer LLC','type':'importer','evidence':{}})
    assert not identity_valid({'name':'ABC Logistics','type':'lead','evidence':{}})

def test_graph_contains_clean_gates_and_harvest():
    expected=['A_COLLECT','CLEAN_PASS1','CLEAN_QUALITY_GATE','SEED_BUYERS','SUPPLIER_MINING','REVERSE_HARVEST','CLEAN_VERIFY','A_GATE']
    for x in expected: assert x in graph.ORDER

def test_hard_evidence():
    assert hard_evidence({'evidence':{'shipments':3}})
    assert not hard_evidence({'evidence':{}})

def test_norm():
    assert norm('ABC, Inc.')=='abc'
