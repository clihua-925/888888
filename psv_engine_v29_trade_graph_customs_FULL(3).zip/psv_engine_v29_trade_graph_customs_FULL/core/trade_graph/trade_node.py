class TradeNode:
    def __init__(self, company, source='importyeti'):
        self.company=company
        self.source=source
        self.edges=[]
