"""v29 Trade Graph pipeline placeholder.
Flow: keyword -> ImportYeti trade node -> network expand -> supplier verify -> customer reverse
"""

STAGES=["TRADE_ENTRY","NETWORK_EXPAND","SUPPLIER_VERIFY","CUSTOMER_REVERSE"]
