# -*- coding: utf-8 -*-
"""v15 ExpertGraph 专家层：每个节点一位有验收标准的专家。
三段式：执行(确定性代码) → 专家复核(LLM 人设+验收清单) → 判定(pass/fail/degraded)。
复核结论写入 state['node_reports'] 共享认知通道：下游节点可读上游判断，UI 可展开验收明细。
LLM 离线时自动降级为规则验收（verdict=degraded），流程不中断。"""
import time, json
from core.config import settings
from core.model.reasoning import ReasoningEngine
# ---------- 专家注册表：人设 + 使命 + 验收标准说明 ----------
EXPERTS={
 'ICP':{'role':'资深外贸客户画像师','mission':'把行业输入转化为可执行的客户画像契约：必收信号、拒收信号、关键词、HS 编码。契约是后续所有节点的判定基准。',
        'accept':['契约含明确的必收信号','契约含明确的拒收信号','关键词/HS 编码与行业强相关']},
 'STRATEGY':{'role':'搜索策略师','mission':'基于 ICP 契约、进化变体与复盘建议，制定本轮搜索查询词组合，覆盖买家直搜与供应商反查两条线。',
        'accept':['至少1个查询词','查询词与 ICP 关键词一致','有复盘建议时必须回应建议']},
 'A_COLLECT':{'role':'采集质检员','mission':'检验采集到的候选公司：是否真实存在、是否 ICP 相关、是否垃圾名片（词典/电商/货代）、覆盖度是否足够。',
        'accept':['候选数≥1','无明显的词典/翻译/电商垃圾','至少部分候选带出货量等硬证据']},
 'SUPPLIER_MINING':{'role':'供应链分析师','mission':'评估同行工厂池质量：供应商是否真实蜡烛/家居香氛工厂、出货量是否值得收割、slug 是否可用于反查。',
        'accept':['池内供应商与行业相关','至少1家未收割供应商（或均已收割属正常终态）']},
 'REVERSE_HARVEST':{'role':'收割评估员','mission':'评估反向收割产出：透视出的新同行、收割到的新买家数量与质量、失败原因归类（风控/结构变化/无数据）。',
        'accept':['透视或收割至少产生新线索','失败原因已正确归类']},
 'CLEAN_VERIFY':{'role':'数据管家','mission':'核对清洗分流结果：跨轮去重是否正确、新增/已知/剔除三类计数是否自洽。',
        'accept':['计数自洽（新增+已知+剔除=输入）','已知公司只做记录不进下游']},
 'A_GATE':{'role':'资格审判官','mission':'逐家审判新增候选： accept/reject 并给出理由。只放行有真实进口证据或强相关的美国公司，宁缺毋滥。',
        'accept':['逐家给出 accept/reject 理由','放行标准与 ICP 契约一致','合格数达到闸门阈值才放行']},
 'USITC':{'role':'宏观情报员','mission':'把 USITC 数据/手工情报浓缩成开发信可用的一句话弹药（趋势、数字、来源）。无数据时明确跳过。',
        'accept':['有数据→产出可引用的一句弹药','无数据→明确标记跳过不编造']},
 'RANK':{'role':'采购优先级顾问','mission':'按证据强度与采购潜力排序，给每家公司一句排序理由，硬证据优先。',
        'accept':['排序覆盖全部合格公司','每家有一句排序理由']},
 'CONTACT':{'role':'联系方式提取员','mission':'为合格进口商补全官网/邮箱/电话/地址，并把评分与等级落库。提取失败不阻断流程，如实记录。',
        'accept':['评分与等级已写入客户库','有联系方式缺口时尝试补全并记录结果']},
 'AUDIT':{'role':'资料审核员','mission':'对补全后的联系方式进行多重校验，包括格式、黑名单、交叉一致、活性和GPT复核，确保资料真实可用。',
        'accept':['所有字段通过或达到重试上限','审核结论已写入共享状态']},
 'CORRECT':{'role':'资料修正员','mission':'根据审核反馈修正联系方式，优先使用AI建议，无建议则清空失败字段等待重新补全或人工处理。',
        'accept':['修正后进入重新审核','修正次数不超过最大重试上限']},
 'B_PROFILE':{'role':'客户画像专家','mission':'为 TopN 公司生成采购画像（产品线、规模、渠道、切入点）。',
        'accept':['画像份数=预期 TopN','每份画像含切入点建议']},
 'C_ANALYSIS':{'role':'采购机会分析师','mission':'评估每家公司的采购机会与优先级，优先分析有提单硬证据的公司。',
        'accept':['分析份数=预期 TopN','结论有证据支撑不空泛']},
 'D_OUTREACH':{'role':'开发信撰稿人','mission':'为 TopN 公司写简短英文开发信，自然引用品类相关性/宏观数据，不编造数字。',
        'accept':['信件份数=预期 TopN','英文、简短、无编造数据']},
 'MISSION_DIRECTOR':{'role':'任务总统筹与决策规划专家','mission':'掌握全局任务状态、节点交接、证据质量和失败诊断，决定下一步执行、重试、换策略、跳过或终止。不得编造事实；优先保护证据质量。','accept':['计划与当前任务一致','失败时给出可执行的替代方案','不得让无硬证据候选直接进入高质量客户池']},
 'REFLECT':{'role':'复盘诊断师','mission':'诊断上游失败根因（查询词太窄/垃圾结果/风控/闸门过严），开出可执行的纠正处方：新查询词+调整建议。',
        'accept':['诊断指到具体根因','给出新的查询词或明确放弃理由']},
}
_SYS='你是{role}。{mission}\n以专家标准复核给你的工作结果，只输出JSON：{{"verdict":"pass或fail","thinking":"推理过程,150字内","criteria":[{{"name":"验收项","ok":true或false,"detail":"一句依据"}}],"notes":"给下游节点的一句话交接建议"}}'
def _engine():
    global _ENG
    try: return _ENG
    except NameError:
        _ENG=ReasoningEngine(); return _ENG
def review(node,subject,rule_checks=None,critical=None):
    """专家复核主入口。
    node: 节点名；subject: 给专家看的工作结果摘要；
    rule_checks: [(name,ok,detail)] 确定性规则验收；critical: 其中一票否决的项名集合。
    返回 report: {role,verdict,criteria,thinking,notes,offline,ts}"""
    rule_checks=rule_checks or []; critical=critical or set()
    exp=EXPERTS.get(node,{'role':'专家','mission':'复核工作结果','accept':[]})
    report={'role':exp['role'],'mission':exp['mission'],'verdict':'pass',
            'criteria':[{'name':n,'ok':bool(ok),'detail':d,'by':'rule'} for n,ok,d in rule_checks],
            'thinking':'','notes':'','offline':False,'ts':time.time()}
    rule_fail=[c for c in report['criteria'] if not c['ok'] and c['name'] in critical]
    if not settings.EXPERT_MODE:
        report['thinking']='EXPERT_MODE 关闭，仅规则验收'
        report['verdict']='fail' if rule_fail else 'pass'
        return report
    eng=_engine()
    if not eng.available:
        report['offline']=True
        report['thinking']='LLM 离线，降级为规则验收'
        report['verdict']='fail' if rule_fail else 'degraded'
        return report
    accept_txt='\n'.join('- '+a for a in exp['accept']) or '- 结果合理可用'
    prompt=('验收标准：\n'+accept_txt+'\n\n规则预检结果（可参考，可推翻非关键项）：\n'
            +('\n'.join('- %s: %s %s'%(c['name'],'OK' if c['ok'] else 'FAIL',c['detail']) for c in report['criteria']) or '（无）')
            +'\n\n待验收的工作结果：\n'+str(subject)[:3500])
    r=eng.review(prompt,system=_SYS.format(**exp))
    if not r:
        report['offline']=True
        report['thinking']='LLM 复核未返回有效JSON，降级为规则验收'
        report['verdict']='fail' if rule_fail else 'degraded'
        return report
    # LLM 结论并入（规则关键项失败不可被推翻——硬底线）
    report['thinking']=str(r.get('thinking') or '')[:600]
    report['notes']=str(r.get('notes') or '')[:300]
    for c in (r.get('criteria') or [])[:8]:
        report['criteria'].append({'name':str(c.get('name') or '?')[:60],'ok':bool(c.get('ok')),
                                   'detail':str(c.get('detail') or '')[:160],'by':'llm'})
    llm_verdict=str(r.get('verdict') or '').lower()
    if rule_fail: report['verdict']='fail'
    elif llm_verdict=='fail': report['verdict']='fail'
    else: report['verdict']='pass'
    return report
def diagnose(fail_node,fail_report,context):
    """REFLECT 节点的诊断调用 → {diagnosis,advice,new_queries[]}；LLM 离线给规则处方"""
    exp=EXPERTS['REFLECT']
    eng=_engine()
    if eng.available:
        prompt=(f'失败节点：{fail_node}\n失败验收报告：\n{fail_report}\n\n任务上下文：\n{context}'
                '\n\n只输出JSON：{"diagnosis":"根因,120字内","advice":"纠正处方,120字内","new_queries":["改写后的英文搜索词,最多4个"]}')
        r=eng.review(prompt,system='你是'+exp['role']+'。'+exp['mission'])
        if r:
            qs=[str(x).strip() for x in (r.get('new_queries') or []) if str(x).strip()][:4]
            return {'diagnosis':str(r.get('diagnosis') or '')[:300],'advice':str(r.get('advice') or '')[:300],
                    'new_queries':qs,'by':'llm'}
    # 规则处方：换一批未用过的进化变体
    return {'diagnosis':'LLM 离线，按规则处方：换用更宽/更窄的查询词组合重试',
            'advice':'试试加 importer/buyer/wholesale 后缀，或换成 HS 3406 相关词',
            'new_queries':[],'by':'rule'}

def mission_plan(state, event='continue', failure=None):
    """总统筹独立模型调用：输出下一步计划，不直接执行节点。"""
    if not settings.MISSION_DIRECTOR_ENABLED:
        return {'action':'continue','reason':'总统筹模型关闭','next_node':None,'plan':[],'by':'rule'}
    eng=_engine()
    if not eng.available:
        return {'action':'continue','reason':'本地模型不可用，按固定拓扑继续','next_node':None,'plan':[],'by':'rule'}
    snapshot={
      'task_id':state.get('task_id'),'goal':state.get('request'),'market':state.get('market'),'industry':state.get('industry'),
      'current_node':state.get('current_node'),'event':event,'failure':failure or {},
      'node_status':state.get('node_status',{}),'handoffs':state.get('handoffs',{}),
      'evidence_summary':state.get('evidence_summary',{}),'candidate_counts':{'companies':len(state.get('companies') or []),'new':len(state.get('new_companies') or []),'suppliers':len(state.get('suppliers') or [])},
      'reflection':state.get('reflection',{}), 'constraints':['FIRST ROUND DATA SOURCES MUST BE CUSTOMS/SHIPMENT DATA PROVIDERS ONLY','derive buyer→supplier→supplier→buyer relations from customs/shipment data only','public crawlers may be used only for enrichment/verification after the customs graph','exhibitions/web directories are fallback verification only and must never replace customs evidence','do not bypass access controls','prefer stable public evidence']
    }
    prompt=('你是整个外贸客户采集任务的总统筹。你不直接执行工具，只负责决定下一步。\n'
            '任务状态：\n'+json.dumps(snapshot,ensure_ascii=False)[:10000]+
            '\n请输出JSON：{"action":"continue|retry|replan|skip|abort","reason":"简短原因","next_node":"节点名或空","plan":["最多3个具体动作"],"questions":["需要补查的问题"]}')
    r=eng.review(prompt,system='你是任务总统筹与决策规划专家。第一采集链只能使用海关/提单数据源（包括ImportYeti及其他有海关数据的站点）；禁止用B2B、普通搜索、展会替代第一采集。供应商和反向客户也必须优先从海关关系图谱提取。证据优先，宁缺毋滥。只输出JSON。')
    if not r:
        return {'action':'continue','reason':'总统筹未返回有效方案','next_node':None,'plan':[],'by':'fallback'}
    return {'action':str(r.get('action') or 'continue'),'reason':str(r.get('reason') or '')[:500],
            'next_node':str(r.get('next_node') or ''), 'plan':[str(x)[:300] for x in (r.get('plan') or [])[:3]],
            'questions':[str(x)[:200] for x in (r.get('questions') or [])[:5]],'by':'llm'}

def build_diagnostic_package(state,node,error,attempts):
    """给网页GPT的详细事实包：描述事实、已尝试、可用工具和约束，不把错误当作根因。"""
    return {
      'task':{'id':state.get('task_id'),'goal':state.get('request'),'market':state.get('market'),'industry':state.get('industry')},
      'stage':{'node':node,'attempts':attempts,'current':state.get('current_node')},
      'observed_error':str(error or '')[:1500],
      'successful_work':{'node_status':state.get('node_status',{}),'handoffs':state.get('handoffs',{}),
                         'companies':len(state.get('companies') or []),'suppliers':len(state.get('suppliers') or []),
                         'new_companies':len(state.get('new_companies') or [])},
      'evidence':state.get('evidence_summary',{}),
      'source_errors':(state.get('source_errors') or [])[-10:],
      'attempt_history':(state.get('retry_history') or [])[-8:],
      'constraints':['use public/stable data paths','do not bypass login/captcha/access controls','do not treat generic search results as trade evidence'],
      'required_answer':['likely root causes ranked','what to test next','what to skip if blocked','whether the task can continue safely']
    }


def build_development_diagnostic_package(state,node,error,attempts):
    """第二流程专用诊断事实包：错误只是观察结果，供本地/网页GPT判断根因。"""
    return {
        'task':{'task_id':state.get('task_id'),'lead_norm':state.get('lead_norm'),'current_node':state.get('current_dev_node')},
        'stage':{'node':node,'attempts':attempts},
        'observed_error':str(error or '')[:1500],
        'lead_snapshot':{k:state.get('lead',{}).get(k) for k in ['name','country','website','emails','phones','address','shipments','last_shipment','category','segment']},
        'dev_status':state.get('dev_status',{}),
        'handoffs':state.get('dev_handoffs',{}),
        'opportunity':state.get('opportunity',{}),
        'profile':state.get('profile',{}),
        'offer_strategy':state.get('offer_strategy',{}),
        'retry_history':(state.get('dev_retry_history') or [])[-10:],
        'constraints':['do not invent demand','reuse existing verified evidence','do not bypass login/captcha/access controls','do not send duplicate email'],
        'required_answer':['rank likely root causes','give next tests/actions','state whether it is safe to continue','say if node should be skipped']
    }
