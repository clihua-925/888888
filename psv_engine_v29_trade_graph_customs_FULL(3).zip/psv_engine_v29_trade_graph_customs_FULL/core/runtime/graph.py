# -*- coding: utf-8 -*-
"""v24 编排引擎：总统筹 + 独立专家节点 + 结构化上下交接 + 三次失败换方案。

设计原则：
1) 每个专家节点独立调用自己的模型复核/技能，不把一个大模型贯穿全流程。
2) 所有节点通过共享黑板(state)共享任务、证据、状态、失败与交接；节点之间仍有明确 handoff。
3) 节点失败最多自动重试 NODE_RETRIES 次；三次仍失败不机械循环，而生成详细诊断包给网页GPT顾问，再由总统筹决定 retry/replan/skip/abort。
4) Discovery 可以宽，Evidence/Qualification 必须严；普通搜索结果不得直接成为高质量客户证据。
5) 每次节点状态实时落盘，UI 可看到 running/success/fail/retry/handoff/diagnosis。
"""
import time, traceback, json
from typing import TypedDict
from core.config import settings
from core.runtime import nodes as N
from core.runtime import experts

class S(TypedDict,total=False):
    task_id:str; request:str; market:str; industry:str; quantity:int
    icp:dict; strategy:dict; query_override:list
    companies:list; new_companies:list; suppliers:list; supplier_new:list
    harvest:dict; usitc:dict; gate:dict; collect_gate:dict; evolution:dict
    profiles:list; analyses:list; letters:list; nodes:list
    node_reports:dict; reflection:dict
    source:str; source_errors:list; known_count:int; dropped_count:int
    abort:str; skip_llm:bool; error:str; warning:str; success:bool; duration_sec:float
    engine:str; traceback:str
    contact_leads:list; audit_results:dict; corrections:dict
    audit_retry_count:int; audit_max_retries:int; audit_pass:bool
    current_node:str; node_status:dict; handoffs:dict; retry_history:list; plans:list
    evidence_summary:dict; diagnostics:list; mission_decisions:list; current_handoff:dict

# 主流程：第二阶段 CONTACT 后进入客户验证/画像/开发信。
ORDER=['ICP','STRATEGY','A_COLLECT','CLEAN_PASS1','CLEAN_QUALITY_GATE','SEED_BUYERS','SUPPLIER_MINING','REVERSE_HARVEST','CLEAN_VERIFY','A_GATE','DISCOVERY_COMMIT']
FN={'ICP':N.n_icp,'STRATEGY':N.n_strategy,'A_COLLECT':N.n_collect,'CLEAN_PASS1':N.n_clean_pass1,'CLEAN_QUALITY_GATE':N.n_clean_quality_gate,'SEED_BUYERS':N.n_seed_buyers,
    'SUPPLIER_MINING':N.n_supplier_mining,
    'REVERSE_HARVEST':N.n_reverse_harvest,'CLEAN_VERIFY':N.n_clean_verify,'A_GATE':N.n_gate,
    'DISCOVERY_COMMIT':N.n_discovery_commit,'REFLECT':N.n_reflect}

# 上游产物的最低结构要求；这些是交接验收，不替代专家判断。
CONTRACTS={
 'ICP':(), 'STRATEGY':('icp',), 'A_COLLECT':('market','industry','quantity'),
 'CLEAN_PASS1':('companies',), 'CLEAN_QUALITY_GATE':('task_data',), 'SEED_BUYERS':('task_data',), 'SUPPLIER_MINING':('seed_buyers',), 'REVERSE_HARVEST':('suppliers',), 'CLEAN_VERIFY':('companies',),
 'A_GATE':('companies',), 'DISCOVERY_COMMIT':('new_companies',)
}
# 真正需要强证据的节点：不允许“搜索看起来像”替代证据。
STRICT_EVIDENCE={'CLEAN_QUALITY_GATE','A_GATE','DISCOVERY_COMMIT'}


def _entry(name,status='success',note='',dur=0.0,attempt=1,**kw):
    e={'node':name,'status':status,'success':status in ('success','skipped'),'attempt':attempt,'ts':time.time()}
    if note: e['note']=note
    if dur: e['duration']=round(dur,2)
    e.update(kw); return e

def _persist(persist,state):
    # 清理不可序列化对象，只保留可观察黑板
    try: persist(state)
    except Exception: pass

def _handoff_check(state,name,out):
    missing=[k for k in CONTRACTS.get(name,()) if out.get(k,state.get(k)) is None]
    # 结果级最低质量检查
    issues=[]
    if name in ('ICP','STRATEGY') and not (out.get('icp',state.get('icp')) if name=='ICP' else out.get('strategy',state.get('strategy'))):
        issues.append('上游专家未产出结构化契约/策略')
    if name in ('A_COLLECT','CLEAN_PASS1') and not (out.get('companies',state.get('companies'))):
        issues.append('采集未产出候选')
    if name=='SUPPLIER_MINING' and 'suppliers' in out and out.get('suppliers') is None:
        issues.append('供应商池缺失')
    if name=='REVERSE_HARVEST' and state.get('companies') is None:
        issues.append('反向收割后客户集合缺失')
    if name=='A_GATE':
        g=out.get('gate',state.get('gate')) or {}
        if g.get('ok') and not (g.get('qualified_companies') or out.get('new_companies') or state.get('new_companies')):
            issues.append('闸门标记通过但没有放行候选')
    if name in STRICT_EVIDENCE:
        candidates=out.get('new_companies',state.get('new_companies')) or []
        if candidates:
            no_evidence=0
            for c in candidates:
                e=c.get('evidence') or {}
                src=str(c.get('source') or '').lower()
                hard=bool(e.get('shipments') or e.get('bill_of_lading') or e.get('customs') or e.get('trade_evidence'))
                if not hard and 'importyeti' not in src and 'customs' not in src: no_evidence+=1
            if no_evidence and name in {'A_GATE','RANK'}:
                issues.append(f'{no_evidence}个候选缺少硬贸易证据')
    return missing+issues

def _set_status(state,name,status,**extra):
    ns=dict(state.get('node_status') or {})
    ns[name]={'status':status,'updated_at':time.time(),'attempt':extra.pop('attempt',ns.get(name,{}).get('attempt',0))}
    ns[name].update(extra); state['node_status']=ns


def _record_handoff(state,name,prev_name,out,accepted,issues):
    hs=dict(state.get('handoffs') or {})
    item={'from':prev_name,'to':name,'accepted':bool(accepted),'issues':issues[:8],'ts':time.time(),
          'summary':{'keys':sorted([k for k in out.keys() if not k.startswith('_')]),
                     'companies':len(out.get('companies') or state.get('companies') or []),
                     'new_companies':len(out.get('new_companies') or state.get('new_companies') or []),
                     'suppliers':len(out.get('suppliers') or state.get('suppliers') or [])}}
    hs[name]=item; state['handoffs']=hs; state['current_handoff']=item
    return item


def _run_once(state,name,attempt,persist):
    fn=FN[name]; state['current_node']=name; _set_status(state,name,'running',attempt=attempt)
    state['nodes']=state.get('nodes',[])+[_entry(name,'running','开始执行',attempt=attempt)]
    _persist(persist,state)
    # 清理上次同节点running尾巴的视觉歧义：追加最终事件即可，UI取最后一条状态。
    missing=[k for k in CONTRACTS.get(name,()) if state.get(k) is None]
    if missing:
        err=f'{name} 交接输入缺失: {missing}'
        _set_status(state,name,'failed',attempt=attempt,error=err)
        state['error']=err; state['nodes'].append(_entry(name,'failed',err,attempt=attempt))
        _persist(persist,state); return False,{},err
    t0=time.time(); out={}
    try:
        out=fn(state) or {}
        ok=bool(out.pop('_success',True)); note=str(out.pop('_note',''))
        issues=_handoff_check(state,name,out)
        if not ok: issues.append(note or '专家节点返回失败')
        if issues and settings.HANDOFF_VALIDATION_ENABLED:
            ok=False
        # 更新状态前先生成交接验收信息
        prev=(ORDER[ORDER.index(name)-1] if name in ORDER and ORDER.index(name)>0 else 'MISSION_DIRECTOR')
        _record_handoff(state,name,prev,out,ok,issues)
        if out: state.update(out)
        status='success' if ok else 'failed'
        _set_status(state,name,status,attempt=attempt,note=note,error='; '.join(issues[:3]) if issues else '')
        state['nodes'].append(_entry(name,status,note,time.time()-t0,attempt=attempt,issues=issues[:8]))
        _persist(persist,state)
        return ok,out,'' if ok else ('; '.join(issues[:4]) or note or '节点返回失败')
    except Exception as e:
        err=f'{name} 节点异常: {str(e)[:500]}'
        state['traceback']=traceback.format_exc()[-1600:]
        state['error']=err
        _set_status(state,name,'failed',attempt=attempt,error=err)
        state['nodes'].append(_entry(name,'failed',err,time.time()-t0,attempt=attempt,exception=True))
        _persist(persist,state); return False,out,err


def _web_diagnose(state,name,error,attempts,persist):
    package=experts.build_diagnostic_package(state,name,error,attempts)
    diag={'node':name,'attempts':attempts,'package':package,'ts':time.time(),'by':'local'}
    # 本地诊断先做一次：不是让本地模型猜错误，而是总结事实。
    try:
        d=experts.diagnose(name,json.dumps(package,ensure_ascii=False)[:9000],json.dumps(state.get('node_reports',{}).get(name,{}),ensure_ascii=False)[:2500])
        diag['local']=d
    except Exception as e: diag['local']={'diagnosis':'本地诊断失败','advice':str(e)[:200]}
    # 三次失败后才咨询网页GPT，并把完整事实包交给它。
    if settings.WEBAI_ENABLED and attempts >= settings.WEB_AI_AFTER_RETRIES:
        try:
            from core.tools import web_ai
            prompt='''你是外贸客户采集系统的故障诊断顾问。下面是结构化事实包。注意：observed_error只是“观察到的错误”，绝不能直接当作根因。请根据成功路径、尝试历史、节点职责、数据状态和约束，给出根因候选排序与下一步方案。不要要求付费API，不要绕过登录/验证码/访问控制。输出JSON：{"diagnosis":"最可能根因","alternatives":["其他可能根因"],"actions":["按优先级最多4个动作"],"continue_safe":true,"skip_node":false,"confidence":0.0}'''
            ans=web_ai.solve(prompt,context=json.dumps(package,ensure_ascii=False),timeout=settings.WEBAI_TIMEOUT)
            if ans:
                from core.utils import jsonutil
                j=jsonutil.j(ans)
                if j:
                    diag['web_ai']={'diagnosis':str(j.get('diagnosis') or '')[:500],
                                    'alternatives':[str(x)[:300] for x in (j.get('alternatives') or [])[:5]],
                                    'actions':[str(x)[:300] for x in (j.get('actions') or [])[:5]],
                                    'continue_safe':bool(j.get('continue_safe',True)),
                                    'skip_node':bool(j.get('skip_node',False)),
                                    'confidence':float(j.get('confidence') or 0), 'ts':time.time()}
                    diag['by']='web_ai'
        except Exception as e:
            diag['web_ai_error']=str(e)[:300]
    state['diagnostics']=list(state.get('diagnostics') or [])+[diag]
    _persist(persist,state)
    return diag


def _director(state,event,failure,persist):
    decision=experts.mission_plan(state,event=event,failure=failure)
    state['mission_decisions']=list(state.get('mission_decisions') or [])+[dict(decision,ts=time.time(),event=event)]
    state['plans']=list(state.get('plans') or [])+[decision]
    _persist(persist,state)
    return decision


def _recovery(state,name,error,attempts,persist):
    # 先做总统筹规划；三次失败后再增加网页GPT诊断。
    failure={'node':name,'error':error,'attempts':attempts,'last_report':(state.get('node_reports') or {}).get(name,{}),
             'diagnostic_count':len(state.get('diagnostics') or [])}
    decision=_director(state,'node_failed',failure,persist)
    if attempts >= settings.NODE_RETRIES:
        diag=_web_diagnose(state,name,error,attempts,persist)
        decision=_director(state,'diagnosis_ready',{'node':name,'diagnosis':diag},persist)
    action=str(decision.get('action') or 'replan')
    if action not in {'retry','replan','skip','abort','continue'}: action='replan'
    # 保护证据质量：严格节点无硬证据时不能简单“skip”成通过。
    if name in STRICT_EVIDENCE and action=='skip':
        state['warning']='严格证据节点被总统筹建议跳过：保持阻断，不把不合格数据当合格客户。'
        action='abort'
    return action,decision


def run_graph(state,persist):
    state.setdefault('engine','expert-orchestrator-v24'); state.setdefault('node_status',{}); state.setdefault('handoffs',{})
    state.setdefault('retry_history',[]); state.setdefault('plans',[]); state.setdefault('diagnostics',[]); state.setdefault('mission_decisions',[])
    state.setdefault('evidence_summary',{}); state.setdefault('nodes',[])
    # 初始总统筹计划：决定整体任务模式，但不越权执行节点。
    _director(state,'task_start',{},persist)
    i=0; steps=0; attempts={}; max_steps=settings.GRAPH_MAX_STEPS
    while i < len(ORDER) and steps < max_steps:
        steps+=1; name=ORDER[i]
        # A_GATE / A_COLLECT 失败不再用无限 reflect loop；统一进入恢复机制。
        ok,out,error=_run_once(state,name,attempts.get(name,0)+1,persist)
        attempts[name]=attempts.get(name,0)+1
        if ok:
            attempts[name]=0
            # A_GATE失败被视为节点失败，理论上不会到这里。
            i+=1
            continue
        # 节点失败：结构化诊断→总统筹换方案
        state['retry_history']=list(state.get('retry_history') or [])+[{'node':name,'attempt':attempts[name],'error':error,'ts':time.time()}]
        action,decision=_recovery(state,name,error,attempts[name],persist)
        if action in ('retry','continue') and attempts[name] < settings.NODE_RETRIES:
            state['current_node']=name; _set_status(state,name,'retry_wait',attempt=attempts[name],reason=decision.get('reason',''))
            _persist(persist,state); continue
        if action=='replan' and attempts[name] < settings.NODE_RETRIES:
            # 总统筹可以要求更换查询策略；最常见的恢复路径回到STRATEGY，而不是原地循环。
            if name in {'A_COLLECT','CLEAN_QUALITY_GATE','A_GATE','REVERSE_HARVEST'}:
                state['query_override']=(decision.get('plan') or [])[:6] or state.get('query_override')
                target='STRATEGY' if name in {'A_COLLECT','A_GATE'} else 'SUPPLIER_MINING'
                attempts[name]=0; i=ORDER.index(target); continue
            attempts[name]=0; i=max(0,i-1); continue
        if action=='skip' and name not in STRICT_EVIDENCE:
            _set_status(state,name,'skipped',attempt=attempts[name],reason=decision.get('reason',''))
            i+=1; continue
        # 到这里表示安全终止，不把失败伪装成成功。
        state['abort']='failed'; state['error']=error or f'{name} 无法安全完成'
        break
    if steps>=max_steps and not state.get('abort'):
        state['abort']='error'; state['error']='达到编排最大步数，防止循环失控'
    state['current_node']='END'; _persist(persist,state); return state
