# -*- coding: utf-8 -*-
"""v21.4 恢复优化版：A_COLLECT 确定性通过，A_GATE 放宽硬证据要求，保留所有质量优化"""
import json, re, sqlite3, time
import requests
from pathlib import Path
from core.config import settings
from core.config.industry import load_industry
from core.model.reasoning import ReasoningEngine
from core.runtime import experts
from core.tools.data_sources.manager import DataSourceManager, Evolution, gate_check, norm, noise, identity_valid, hard_evidence
from core.tools import suppliers as sup
from core.tools import apify_client as apify
from core.tools import expand as expand_tool

BAD = re.compile(r'on behalf of|freight|forwarder|logistics|express|cargo|shipping|customs broker|packaging|consulting|翻译|词典|物流|货代', re.I)
_engine = None

def _eng():
    global _engine
    if _engine is None:
        _engine = ReasoningEngine()
    return _engine

def _report(state, node, rep):
    nr = dict(state.get('node_reports') or {})
    nr[node] = rep
    return nr

def _ev(c):
    e = c.get('evidence') or {}
    bits = []
    if e.get('shipments'):
        bits.append(f"shipments={e['shipments']}")
    if e.get('score'):
        bits.append(f"score={e['score']}")
    if e.get('last_seen'):
        bits.append(f"last_seen={e['last_seen']}")
    return (' [' + ', '.join(str(b) for b in bits) + ']') if bits else ''

def _brief(cs, n=12):
    return '\n'.join('- ' + c.get('name','') + ' | ' + str(c.get('country','')) + ' | ' + str(c.get('source','')) + _ev(c) for c in (cs or [])[:n])

# ---------- 1. ICP 客户画像师 ----------
def n_icp(state):
    ind = state['industry']
    icp = None
    industry_cfg = load_industry(ind)
    # 优先使用配置中的 ICP，避免不必要的 LLM 调用
    if settings.EXPERT_MODE and _eng().available:
        icp = _eng().review(
            f'市场:{state["market"]} 行业:{ind}\n生成客户画像契约JSON：'
            '{"must":["必收信号3-5条"],"reject":["拒收信号3-5条"],"keywords":["英文关键词5-8个"],"hs":["相关HS编码"]}',
            system='你是资深外贸客户画像师，只输出JSON')
    if not icp or not icp.get('must'):
        icp = {'must': industry_cfg.get('icp_must', ['USA company', 'import or trade evidence']),
               'reject': industry_cfg.get('icp_reject', ['dictionary', 'marketplace retail page', 'freight forwarder']),
               'keywords': industry_cfg.get('keywords', [ind]),
               'hs': industry_cfg.get('hs_codes', [])}
    rep = experts.review('ICP', '契约：\n' + json.dumps(icp, ensure_ascii=False),
                         [('含必收信号', bool(icp.get('must')), 'must 非空' if icp.get('must') else 'must 缺失'),
                          ('含拒收信号', bool(icp.get('reject')), 'reject 非空' if icp.get('reject') else 'reject 缺失'),
                          ('关键词与行业相关', bool(icp.get('keywords')), ','.join((icp.get('keywords') or [])[:5]))],
                         critical={'含必收信号','含拒收信号'})
    return {'icp': icp, 'node_reports': _report(state, 'ICP', rep), '_note': '客户画像契约已锁定'}

# ---------- 2. STRATEGY 搜索策略师：只规划两类硬证据源 ----------
def n_strategy(state):
    industry_cfg = load_industry(state.get('industry'))
    plan = Evolution().plan(state['market'], state['industry'])
    # 生产模式固定为“海关多源并行 + 增量轮换”，不能因为某个源首轮返回足量就停止后续硬源。
    configured=list(industry_cfg.get('search_terms') or [])
    keywords=list(industry_cfg.get('keywords') or [])
    defaults=[]
    for q in configured + [f"{x} importer" for x in keywords[:3]]:
        if q and q not in defaults: defaults.append(q)
    base=[v for v in (state.get('query_override') or defaults or [state['industry']]) if v][:6]
    rationale='第一层只用海关/提单数据源并行采集；每次运行做增量 delta + 历史轮换；已有客户只合并新证据，新客户才进入开发池；展会/普通网络仅后置补充验证'
    strategy={'queries':base,'source_queries':{x:base for x in ('customs','importyeti','importyeti_web')},
              'sources':['customs_bulk','customs_raw','importyeti','importyeti_web','customs_web'],
              'secondary_sources':['public_crawler','exhibition','web_verify'],'hs_codes':industry_cfg.get('hs_codes') or [],
              'rationale':rationale,'evolution':plan,'incremental':True,'fanout_hard_sources':True}
    rep=experts.review('STRATEGY','查询参数：'+json.dumps(base,ensure_ascii=False)+'\n策略：'+rationale,
                       [('至少2个产品/行业查询变体',len(base)>=2,f'{len(base)}个'),
                        ('主证据源为海关贸易源',True,'customs fan-out'),
                        ('增量运行已启用',True,'delta + rotating window')],critical={'主证据源为海关贸易源','增量运行已启用'})
    return {'strategy':strategy,'node_reports':_report(state,'STRATEGY',rep),'_note':f'查询参数{len(base)}个·海关多源并行·增量轮换'}

# ---------- 3. A_COLLECT 采集质检员（确定性通过，保留噪声过滤） ----------
def n_collect(state):
    mgr=DataSourceManager(); qs=(state.get('strategy') or {}).get('queries'); sq=(state.get('strategy') or {}).get('source_queries')
    companies,used,errors,gate=mgr.search(state['market'],state['industry'],state['quantity'],variants_override=qs,source_queries=sq)
    # RAW 保留：这里不因资料缺失淘汰客户。明确非客户才进入 quarantine。
    raw=list(companies); identity=[]; quarantine=[]
    for c in raw:
        if not identity_valid(c):
            quarantine.append(c)
        else:
            identity.append(c)
    stats={'raw':len(raw),'clean':len(identity),'noise':len(quarantine),'duplicate':0,'identity_only':0,'hard_evidence':sum(1 for c in identity if (c.get('evidence') or {}).get('shipments') or (c.get('evidence') or {}).get('customs') or (c.get('evidence') or {}).get('trade_evidence')),
           'new_candidates':int(gate.get('new_candidates') or 0),'existing_enriched':int(gate.get('existing_enriched') or 0),'source_fanout':True,'incremental':True}
    stats['noise_ratio']=stats['noise']/max(1,stats['raw']);stats['clean_ratio']=stats['clean']/max(1,stats['raw'])
    for c in identity:
        e=c.setdefault('evidence',{}); is_hard=any(e.get(k) for k in ('shipments','customs','trade_evidence','bill_of_lading','supplier_relation'))
        e.setdefault('evidence_level','hard_trade' if is_hard else 'identity_only')
        if not is_hard: stats['identity_only']+=1
    rep={'verdict':'pass' if identity else 'fail','role':'SOURCE_COLLECTOR','criteria':[{'name':'有身份即保留','ok':bool(identity),'detail':f'{len(identity)}家'},{'name':'明确垃圾隔离','ok':True,'detail':f'{len(quarantine)}家'}], 'notes':f'RAW {len(raw)} · clean候选 {len(identity)} · quarantine {len(quarantine)}'}
    try:
        from core.memory.db import DB; DB().save_clean_batch(state.get('task_id',''),'collect',stats)
    except Exception:pass
    return {'raw_companies':raw,'companies':identity,'quarantine':quarantine,'source':'+'.join(used) if used else 'none','source_errors':errors,'collect_gate':gate,'clean_stats':stats,'evolution':mgr.last_evolution,'node_reports':_report(state,'A_COLLECT',rep),'_success':bool(identity),'_note':f'增量采集 {len(raw)} · 新候选 {stats["new_candidates"]} · 已有客户补充 {stats["existing_enriched"]} · 隔离 {len(quarantine)}'}

def n_clean_pass1(state):
    companies=list(state.get('companies') or []); out=[];seen=set();dups=0;identity_only=0
    for c in companies:
        n=norm(c.get('name'))
        if not n or noise(c.get('name')):continue
        if n in seen:dups+=1;continue
        seen.add(n);e=c.setdefault('evidence',{})
        if not any(e.get(k) for k in ('shipments','customs','trade_evidence','bill_of_lading','supplier_relation')):identity_only+=1
        out.append(c)
    prev=state.get('clean_stats') or {}
    raw_total=int(prev.get('raw',len(companies)));noise_total=int(prev.get('noise',0));dup_total=int(prev.get('duplicate',0))+dups
    stats={'raw':raw_total,'clean':len(out),'noise':noise_total,'duplicate':dup_total,'identity_only':identity_only,'hard_evidence':sum(1 for c in out if hard_evidence_local(c))}
    stats['noise_ratio']=noise_total/max(1,raw_total);stats['clean_ratio']=len(out)/max(1,raw_total)
    try:
        from core.memory.db import DB;DB().save_clean_batch(state.get('task_id',''),'pass1',stats)
    except Exception:pass
    rep=experts.review('CLEAN_PASS1',f'首轮清洗 {len(companies)}→{len(out)}，重复{dups}，仅身份{identity_only}',[('公司身份有效',len(out)>0,f'{len(out)}家'),('重复隔离',dups>=0,f'{dups}家')],critical={'公司身份有效'})
    return {'task_data':out,'companies':out,'clean_stats':stats,'node_reports':_report(state,'CLEAN_PASS1',rep),'_success':bool(out),'_note':f'首轮清洗 {len(companies)}→{len(out)} · 仅姓名保留 {identity_only}'}

def hard_evidence_local(c):
    e=c.get('evidence') or {};return bool(e.get('shipments') or e.get('customs') or e.get('trade_evidence') or e.get('bill_of_lading') or e.get('supplier_relation'))

def n_clean_quality_gate(state):
    st=state.get('clean_stats') or {}; raw=int(st.get('raw',0));clean=int(st.get('clean',0));noise_r=float(st.get('noise_ratio',0));dup_r=float(st.get('duplicate',0))/max(1,raw);hard_r=float(st.get('hard_evidence',0))/max(1,clean)
    ok=bool(clean>=settings.RAW_MIN_CLEAN and noise_r<=settings.RAW_MAX_NOISE_RATIO and dup_r<=settings.RAW_MAX_DUP_RATIO)
    gate={'ok':ok,'raw':raw,'clean':clean,'noise_ratio':noise_r,'duplicate_ratio':dup_r,'hard_evidence_ratio':hard_r,'reason':'clean数据有效占比达标' if ok else '未清洗数据/重复数据占比过高'}
    rep=experts.review('CLEAN_QUALITY_GATE',json.dumps(gate,ensure_ascii=False),[('有效数据存在',clean>=settings.RAW_MIN_CLEAN,f'{clean}'),('垃圾率不过高',noise_r<=settings.RAW_MAX_NOISE_RATIO,f'{noise_r:.1%}'),('重复率不过高',dup_r<=settings.RAW_MAX_DUP_RATIO,f'{dup_r:.1%}')],critical={'有效数据存在','垃圾率不过高'})
    return {'clean_quality_gate':gate,'node_reports':_report(state,'CLEAN_QUALITY_GATE',rep),'_success':ok,'_note':f'清洗质量 {'PASS' if ok else 'FAIL'} · 有效{clean} · 垃圾率{noise_r:.1%}'}

def n_seed_buyers(state):
    cs=list(state.get('task_data') or state.get('companies') or []);seeds=[]
    for c in cs:
        # seed必须尽量来自硬贸易源；身份-only也保留，但作为低证据种子
        c=dict(c);c['seed_role']='buyer_seed';seeds.append(c)
    # 关系图应覆盖本轮全部有效客户；外部网页补缺由 SUPPLIER_MINING_BUYERS 控制。
    seeds=seeds[:max(1, min(len(seeds), int(state.get('quantity') or settings.SEED_BUYERS_PER_TASK)))]
    rep=experts.review('SEED_BUYERS',f'种子客户{len(seeds)}家', [('种子存在',bool(seeds),str(len(seeds)))],critical={'种子存在'})
    return {'seed_buyers':seeds,'companies':seeds,'node_reports':_report(state,'SEED_BUYERS',rep),'_success':bool(seeds),'_note':f'形成种子客户 {len(seeds)} 家'}

def n_supplier_mining(state):
    """客户→供应商：第一优先级必须来自海关贸易记录；ImportYeti网页仅作为同类海关数据源补充。"""
    # 本地 customs_raw 没有逐票成本，第一轮清洗通过的客户全部进入关系图；
    # SUPPLIER_MINING_BUYERS 只限制需要访问 ImportYeti 网页补缺的外部客户数，避免免费额度被浪费。
    seeds=list(state.get('seed_buyers') or state.get('companies') or [])
    results=[]; supplier_rows=[]; relations=[]; errors=[]
    try:
        from core.tools.customs_graph import buyer_to_suppliers
        supplier_rows, relations = buyer_to_suppliers(seeds, settings.IY_WEB_MAX_SUPPLIERS)
        for rel in relations:
            try:
                from core.memory.db import DB
                DB().add_relationship(state.get('task_id'), rel['from_name'], rel['from_type'], rel['to_name'], rel['to_type'], rel['relation'], rel['evidence'], rel['source'], rel['confidence'], 1)
            except Exception: pass
        results.append({'source':'customs_raw','buyers':len(seeds),'suppliers':len(supplier_rows),'relations':len(relations)})
    except Exception as e:
        errors.append('customs_raw:'+str(e)[:160])
    # 如果本地原始海关库没有覆盖某个种子，再使用 ImportYeti 这一同类海关数据网站的免费网页关系。
    covered={x['norm'] for x in supplier_rows}
    missing=[b for b in seeds if not any(norm(r.get('from_name'))==norm(b.get('name')) for r in relations)]
    if missing and settings.IY_WEB_ENABLED:
        missing=missing[:settings.SUPPLIER_MINING_BUYERS]
        try:
            from core.tools import iy_web
            if iy_web.available():
                with iy_web.IYWeb() as w:
                    for buyer in missing:
                        try:
                            slug=re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',str(buyer.get('name','')).lower())).strip('-')
                            rows=w.relationships('https://www.importyeti.com/company/'+slug,'Suppliers')[:settings.IY_WEB_MAX_SUPPLIERS]
                            for r in rows:
                                nm=r.get('name') or ''; sn=norm(nm)
                                if not sn: continue
                                e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'products':r.get('products') or '', 'hs':r.get('hs') or [], 'supplier_relation':buyer.get('name'),'url':r.get('url') or ''}
                                supplier_rows.append({'norm':sn,'name':nm,'slug':r.get('url','').rstrip('/').split('/')[-1] if r.get('url') else '', 'shipments':r.get('shipments') or 0,'last_seen':time.time(),'harvested':False,'bol_fetched':0,'via':'importyeti_web','evidence':e})
                                relations.append({'from_name':buyer.get('name'),'from_type':'buyer','to_name':nm,'to_type':'supplier','relation':'buyer_to_supplier','evidence':e,'source':'importyeti_web','confidence':.95})
                                try:
                                    from core.memory.db import DB; DB().add_relationship(state.get('task_id'),buyer.get('name',''),'buyer',nm,'supplier','buyer_to_supplier',e,'importyeti_web',.95,1)
                                except Exception: pass
                            results.append({'source':'importyeti_web','buyer':buyer.get('name'),'suppliers':len(rows)})
                        except Exception as e: errors.append(f"{buyer.get('name')}: {str(e)[:100]}")
        except Exception as e: errors.append('importyeti_web:'+str(e)[:160])
    # 第三层：ImportKey公开海关公司页。仅补没有本地/ImportYeti覆盖的种子；不做普通搜索。
    if missing and settings.IMPORTKEY_ENABLED:
        try:
            from core.tools.data_sources.sources import ImportKeyPublicSource
            ik=ImportKeyPublicSource()
            for buyer in missing[:settings.SUPPLIER_MINING_BUYERS]:
                rows=ik.company_relationships(buyer.get('name',''),'suppliers',settings.IMPORTKEY_MAX_RELATIONS)
                for r in rows:
                    nm=r.get('name') or ''; sn=norm(nm)
                    if not sn: continue
                    e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'supplier_relation':buyer.get('name'),'url':r.get('url') or ''}
                    supplier_rows.append({'norm':sn,'name':nm,'slug':'','shipments':r.get('shipments') or 0,'last_seen':time.time(),'harvested':False,'bol_fetched':0,'via':'importkey_public','evidence':e})
                    relations.append({'from_name':buyer.get('name'),'from_type':'buyer','to_name':nm,'to_type':'supplier','relation':'buyer_to_supplier','evidence':e,'source':'importkey_public','confidence':.9})
                    try:
                        from core.memory.db import DB; DB().add_relationship(state.get('task_id'),buyer.get('name',''),'buyer',nm,'supplier','buyer_to_supplier',e,'importkey_public',.9,1)
                    except Exception: pass
                if rows: results.append({'source':'importkey_public','buyer':buyer.get('name'),'suppliers':len(rows)})
        except Exception as e: errors.append('importkey_public:'+str(e)[:160])
    # 去重但不丢失“来自多个客户”的关系证据
    merged={}
    for x in supplier_rows:
        n=x.get('norm') or norm(x.get('name'))
        if not n: continue
        if n not in merged: merged[n]=dict(x)
        else:
            merged[n]['shipments']=max(int(merged[n].get('shipments') or 0),int(x.get('shipments') or 0))
            if not merged[n].get('slug') and x.get('slug'): merged[n]['slug']=x['slug']
            merged[n]['via']=merged[n].get('via','')+'+'+x.get('via','')
    p=sorted(merged.values(),key=lambda x:-int(x.get('shipments') or 0))[:settings.SUPPLIER_MINING_MAX_SUPPLIERS]
    new=[x for x in p if not x.get('harvested')]
    rep=experts.review('SUPPLIER_MINING',f'客户→供应商：种子{len(seeds)}，海关关系{len(p)}，未收割{len(new)}，错误{len(errors)}', [('关系链存在',bool(p) or bool(errors),f'{len(p)}家')])
    ok=bool(p) or (not seeds) or (not settings.HARVEST_ENABLED)
    return {'suppliers':p,'supplier_new':new,'supplier_mining':{'buyers':results,'errors':errors,'relation_source_policy':'customs_trade_only'},'node_reports':_report(state,'SUPPLIER_MINING',rep),'_success':ok,'_note':f'客户→供应商 {len(p)} 家·新工厂 {len(new)} 家·海关关系优先'}


def n_reverse_harvest(state):
    """供应商→客户：优先从 customs_raw 反查；无本地覆盖时才使用 ImportYeti 海关网页关系。"""
    if not settings.HARVEST_ENABLED:
        return {'harvest':{'mode':'disabled'},'_success':True,'_note':'收割禁用'}
    new=state.get('supplier_new') or []; merged=list(state.get('companies') or []); have={norm(c.get('name')) for c in merged}; results=[]; errors=[]; added_total=0
    if not new:
        return {'harvest':{'mode':'idle','results':[]},'node_reports':_report(state,'REVERSE_HARVEST',experts.review('REVERSE_HARVEST','供应商已收割完毕，正常终态')),'_success':True,'_note':'本轮无新工厂可收割'}
    # 第一层：本地海关原始记录
    try:
        from core.tools.customs_graph import supplier_to_buyers
        buyers, relations=supplier_to_buyers(new[:settings.NETWORK_EXPANSION_SUPPLIERS], settings.IY_WEB_MAX_CUSTOMERS)
        for c in buyers:
            rn=norm(c.get('name'))
            if not rn: continue
            if rn not in have:
                have.add(rn); merged.append(c); added_total+=1
        for rel in relations:
            try:
                from core.memory.db import DB
                DB().add_relationship(state.get('task_id'),rel['from_name'],rel['from_type'],rel['to_name'],rel['to_type'],rel['relation'],rel['evidence'],rel['source'],rel['confidence'],2)
            except Exception: pass
        results.append({'source':'customs_raw','suppliers':len(new),'customers':len(buyers),'new':added_total})
    except Exception as e:
        errors.append('customs_raw:'+str(e)[:160])
    # 第二层：ImportYeti，同样是海关/提单关系源；仅补没有本地海关覆盖的供应商
    covered_supplier_names={norm(x.get('from_name')) for x in relations} if 'relations' in locals() else set()
    fallback=[s for s in new[:settings.NETWORK_EXPANSION_SUPPLIERS] if norm(s.get('name')) not in covered_supplier_names]
    if fallback and settings.IY_WEB_ENABLED:
        try:
            from core.tools import iy_web
            if iy_web.available():
                with iy_web.IYWeb() as w:
                    for s in fallback:
                        try:
                            url='https://www.importyeti.com/supplier/'+(s.get('slug') or re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',str(s.get('name','')).lower())).strip('-'))
                            rows=w.relationships(url,'Customers')[:settings.IY_WEB_MAX_CUSTOMERS]
                            added=0
                            for r in rows:
                                nm=r.get('name') or '';rn=norm(nm)
                                if not rn:continue
                                e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'products':r.get('products') or '', 'hs':r.get('hs') or [], 'supplier_relation':s.get('name'),'url':url}
                                c={'name':nm,'country':'USA','industry':state.get('industry',''),'type':'importer','website':'','source':'importyeti_reverse','strength':5,'evidence':e}
                                if rn not in have:
                                    have.add(rn);merged.append(c);added+=1;added_total+=1
                                try:
                                    from core.memory.db import DB;DB().add_relationship(state.get('task_id'),s.get('name',''),'supplier',nm,'buyer','supplier_to_customer',e,'importyeti_web',.95,2)
                                except Exception: pass
                            results.append({'source':'importyeti_web','supplier':s.get('name'),'customers':len(rows),'new':added})
                        except Exception as e: errors.append(f"{s.get('name')}: {str(e)[:100]}")
        except Exception as e: errors.append('importyeti_web:'+str(e)[:160])
    # 第三层：ImportKey公开海关公司页，补没有本地/ImportYeti覆盖的供应商反向客户。
    if fallback and settings.IMPORTKEY_ENABLED:
        try:
            from core.tools.data_sources.sources import ImportKeyPublicSource
            ik=ImportKeyPublicSource()
            for s in fallback[:settings.NETWORK_EXPANSION_SUPPLIERS]:
                rows=ik.company_relationships(s.get('name',''),'buyers',settings.IMPORTKEY_MAX_RELATIONS)
                added=0
                for r in rows:
                    nm=r.get('name') or ''; rn=norm(nm)
                    if not rn: continue
                    e={'customs':True,'trade_evidence':True,'shipments':r.get('shipments') or 0,'supplier_relation':s.get('name'),'url':r.get('url') or ''}
                    c={'name':nm,'country':'USA','industry':state.get('industry',''),'type':'importer','website':'','source':'importkey_public','strength':5,'evidence':e}
                    if rn not in have: have.add(rn); merged.append(c); added+=1; added_total+=1
                    try:
                        from core.memory.db import DB; DB().add_relationship(state.get('task_id'),s.get('name',''),'supplier',nm,'buyer','supplier_to_customer',e,'importkey_public',.9,2)
                    except Exception: pass
                if rows: results.append({'source':'importkey_public','supplier':s.get('name'),'customers':len(rows),'new':added})
        except Exception as e: errors.append('importkey_public:'+str(e)[:160])
    rep=experts.review('REVERSE_HARVEST',f'供应商→客户：透视{len(new)}家，新客户{added_total}，错误{len(errors)}',[('双向海关关系执行',added_total>0 or not errors,f'{added_total}家新增')])
    return {'harvest':{'mode':'customs_graph','results':results,'errors':errors,'policy':'customs_only_relationships'},'companies':merged,'reverse_new':[x for x in merged if norm(x.get('name')) not in {norm(c.get('name')) for c in state.get('companies',[])}],'node_reports':_report(state,'REVERSE_HARVEST',rep),'_success':True,'_note':f'反向收割 {len(new)} 家工厂·新增客户 {added_total}·全部关系来自海关数据源'}

def n_clean_verify(state):
    companies=list(state.get('companies') or []);out=[];seen=set();dropped=0;known=0;identity_only=0;new_entities=[];existing_entities=[]
    from core.memory.db import DB
    db=DB()
    for x in companies:
        nm=(x.get('name') or '').strip();n=norm(nm)
        if not n or noise(nm):dropped+=1;continue
        if n in seen:continue
        seen.add(n)
        old=db.get_lead(n)
        if old: known+=1; existing_entities.append(x)
        else: new_entities.append(x)
        if not hard_evidence_local(x):identity_only+=1
        out.append(x)
    # 这里故意不写 leads。CLEAN_VERIFY 只负责“识别已有/新实体”，
    # 真正的画像合并与业务分区必须由最后的 DISCOVERY_COMMIT 原子完成。
    # 否则新客户会在这里提前进入 leads，最后节点再看时就会被误判成“已有客户”，
    # 从而出现“采集有结果、开发池却没有客户”的生产级逻辑错误。
    rep=experts.review('CLEAN_VERIFY',f'二轮清洗 输入{len(companies)}→{len(out)}·已有{known}·新增{len(new_entities)}·隔离{dropped}·仅身份{identity_only}',
                       [('计数可解释',len(out)+dropped<=len(companies),f'{len(out)}+{dropped}'),
                        ('增量身份已区分',known+len(new_entities)==len(out),f'已有{known}+新增{len(new_entities)}={len(out)}'),
                        ('身份客户不因缺字段删除',True,'policy locked')],critical={'计数可解释','增量身份已区分'})
    return {'task_data':out,'companies':out,'new_companies':new_entities,'new_entity_companies':new_entities,'existing_enriched_companies':existing_entities,
            'known_count':known,'new_entity_count':len(new_entities),'dropped_count':dropped,'identity_only_count':identity_only,
            'node_reports':_report(state,'CLEAN_VERIFY',rep),'_success':True,'_note':f'二轮清洗 {len(out)} 家·新增 {len(new_entities)}·已有补充 {known}'}

def n_gate(state):
    cs=list(state.get('companies') or state.get('task_data') or []);accepted=[];rejects=[];judgments=[]
    for c in cs:
        e=c.get('evidence') or {}; hard=hard_evidence_local(c); relation=bool(e.get('supplier_relation'))
        # 客户身份和证据强度分离：只有明确非客户才剔除；低完整度客户进入 pending，而不是 reject。
        if noise(c.get('name')):
            decision='reject';reason='明确非客户/服务商'
            rejects.append({'name':c.get('name'),'reason':reason})
        else:
            decision='accept';reason='硬贸易证据' if hard else ('反向供应链关系' if relation else '身份候选（待画像补全）')
            accepted.append(c)
        judgments.append({'name':c.get('name'),'decision':decision,'reason':reason,'hard_evidence':hard})
    strong=sum(1 for c in accepted if hard_evidence_local(c));g={'ok':len(accepted)>=settings.GATE_MIN_QUALIFIED,'raw':len(cs),'qualified':len(accepted),'strong':strong,'rejects':rejects,'judgments':judgments,'qualified_companies':accepted,'identity_only':sum(1 for c in accepted if not hard_evidence_local(c))}
    rep=experts.review('A_GATE',f'候选{len(cs)}·放行{len(accepted)}·强证据{strong}·仅身份{g["identity_only"]}',[('逐家有结论',len(judgments)==len(cs),f'{len(judgments)}/{len(cs)}'),('数量达标',g['ok'],f'{len(accepted)}/{settings.GATE_MIN_QUALIFIED}')],critical={'逐家有结论','数量达标'})
    prior_new={norm(c.get('name')) for c in (state.get('new_companies') or [])}
    new_qualified=[c for c in accepted if norm(c.get('name')) in prior_new]
    g['new_qualified']=len(new_qualified); g['existing_refresh']=len(accepted)-len(new_qualified)
    return {'gate':g,'qualified_companies':accepted,'new_companies':new_qualified,'node_reports':_report(state,'A_GATE',rep),'_success':g['ok'],'_note':f'证据资格：放行{len(accepted)}·新增开发{len(new_qualified)}·已有画像刷新{len(accepted)-len(new_qualified)}·强证据{strong}'}

def n_reflect(state):
    fail_node = state.get('_reflect') or 'A_GATE'
    ref = dict(state.get('reflection') or {}); hist = list(ref.get('history') or []); count = int(ref.get('count') or 0)
    last = (state.get('node_reports') or {}).get(fail_node) or {}
    ctx = json.dumps({'industry': state.get('industry'), 'market': state.get('market'),
                      'queries': (state.get('strategy') or {}).get('queries'),
                      'sources': (state.get('strategy') or {}).get('sources') or ['customs','importyeti'],
                      'gate': {k:v for k,v in (state.get('gate') or {}).items() if k in ('raw','qualified','strong')},
                      'companies': len(state.get('companies') or []),
                      'evidence_samples': [{'name':c.get('name'),'source':c.get('source'),'evidence':c.get('evidence') or {}} for c in (state.get('companies') or [])[:5]],
                      'errors': (state.get('source_errors') or [])[:5]}, ensure_ascii=False)
    d = experts.diagnose(fail_node, json.dumps(last, ensure_ascii=False)[:1500], ctx)
    if count >= 1 and settings.WEBAI_ENABLED:
        try:
            from core.tools import web_ai
            ans = web_ai.solve(
                '你是外贸客户采集系统的诊断专家。管线在 %s 节点连续验收失败，本地AI已反思%d轮未解。'
                '请给出：1) 最可能的根因一句话；2) 可执行的纠正建议一句话；3) 3个新的英文搜索查询词。'
                '只输出JSON：{"diagnosis":"","advice":"","new_queries":[]}' % (fail_node, count),
                context='节点报告:\n' + json.dumps(last, ensure_ascii=False)[:1200] + '\n全局:\n' + ctx, timeout=180)
            if ans:
                from core.utils import jsonutil
                j = jsonutil.j(ans)
                if j and j.get('diagnosis'):
                    d = {'diagnosis': '[网页AI] ' + str(j['diagnosis'])[:150],
                         'advice': str(j.get('advice') or d.get('advice') or '')[:200],
                         'new_queries': [str(x)[:80] for x in (j.get('new_queries') or [])][:4] or d.get('new_queries'),
                         'by': 'webai'}
        except Exception as e:
            print('[reflect] webai failed:', str(e)[:60])
    rep = experts.review('REFLECT', f"诊断：{d['diagnosis']}\n处方：{d['advice']}\n新查询词：{d['new_queries']}",
                         [('诊断非空', bool(d.get('diagnosis')), d.get('by',''))])
    hist.append({'round': count+1, 'at_node': fail_node, 'diagnosis': d['diagnosis'], 'advice': d['advice'],
                 'new_queries': d['new_queries'], 'by': d.get('by'), 'ts': time.time()})
    ref = {'count': count+1, 'history': hist}
    up = {'reflection': ref, 'node_reports': _report(state, 'REFLECT', rep),
          '_note': f"第{count+1}轮复盘：{d['diagnosis'][:60]}"}
    if count+1 >= settings.REFLECT_MAX_ROUNDS:
        up['abort'] = 'failed' if fail_node == 'A_COLLECT' else 'failed_gate'
        up['error'] = (state.get('error') or '验收未通过') + f"（已反思{count+1}轮仍不达标，终止。最后诊断：{d['diagnosis']}）"
        up['_reflect'] = None
    else:
        up['_reflect'] = None
        if d['new_queries']:
            up['query_override'] = d['new_queries']
        else:
            up['query_override'] = None
        up.pop('error', None)
    return up

# ---------- 8. CONTACT 联系方式提取员 ----------
def n_contact(state):
    if not settings.CONTACT_ENABLED:
        return {'_success': True, '_note': '联系方式提取已禁用', 'node_reports': _report(state, 'CONTACT', experts.review('CONTACT', '已禁用'))}
    from core.memory.db import DB
    from core.tools import contact_finder, scoring
    db = DB()
    cs = (state.get('new_companies') or [])[:settings.CONTACT_TOP_N]
    leads = []
    for c in cs:
        l = db.get_lead(norm(c.get('name')))
        if l and l.get('kind') == 'importer':
            leads.append(l)
    todo = [l for l in leads if not (l.get('website') or l.get('emails'))]
    ok = 0
    errs = []
    if todo:
        f = contact_finder.ContactFinder()
        try:
            f._launch()
            for l in todo:
                try:
                    r = f.enrich(l, do_audit=False)
                    if r.get('ok'):
                        ok += 1
                except Exception as e:
                    errs.append(str(e)[:60])
                time.sleep(1)
        except Exception as e:
            errs.append('浏览器未就绪: ' + str(e)[:80])
        finally:
            f.close()
    graded = []
    for l in leads:
        l = db.get_lead(l['norm']) or l
        sc, gr, why = scoring.score_lead(l)
        db.lead_update(l['norm'], score=sc, grade=gr)
        graded.append('- %s | %s级 %.1f | 邮箱%s | %s' % (l['name'], gr, sc, '有' if l.get('emails') else '无', why[:60]))
    rep = experts.review('CONTACT',
                         '目标%d家·待补%d家·补全%d家\n评分落库：\n%s' % (len(leads), len(todo), ok, '\n'.join(graded[:12])) +
                         ('\n失败：' + '; '.join(errs[:3]) if errs else ''),
                         [('评分已落库', bool(graded), '%d家' % len(graded)),
                          ('有可用联系方式', ok > 0 or not todo, '补全%d家' % ok if todo else '均已有联系方式')])
    contact_leads = []
    for l in leads:
        fresh = db.get_lead(l['norm'])
        contact_leads.append(fresh if fresh else l)
    return {'node_reports': _report(state, 'CONTACT', rep), '_success': True,
            '_note': f'联系方式补全{ok}/{len(todo)}家·评分{len(graded)}家落库',
            'contact_leads': contact_leads,
            'audit_retry_count': 0,
            'audit_max_retries': 3}

# ---------- 9. AUDIT 资料审核员 ----------
def n_audit(state):
    from core.tools import auditor
    from core.memory.db import DB
    db = DB()
    leads = state.get('contact_leads') or []
    if not leads:
        return {'_success': True, '_note': '无待审核客户', 'audit_pass': True,
                'audit_results': {}, 'corrections': {}, 'audit_retry_count': 0}
    audit_results = {}
    all_pass = True
    suggestions = {}
    updated_leads = []
    for lead in leads:
        updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=state.get('_webai_instance'))
        updated_leads.append(updated)
        audit_results[updated['norm']] = rep
        if rep['verdict'] != 'pass':
            all_pass = False
        if rep.get('ai', {}).get('suggest'):
            suggestions[updated['norm']] = rep['ai']['suggest']
    fail_count = sum(1 for r in audit_results.values() if r['verdict'] != 'pass')
    return {'contact_leads': updated_leads,
            'audit_results': audit_results,
            'corrections': suggestions,
            'audit_pass': all_pass,
            'audit_retry_count': state.get('audit_retry_count', 0),
            '_success': True,
            '_note': '审核通过' if all_pass else f'审核不通过 {fail_count}家'}

# ---------- 10. CORRECT 资料修正员 ----------
def n_correct(state):
    from core.memory.db import DB
    from core.tools import auditor
    db = DB()
    leads = state.get('contact_leads') or []
    audit_results = state.get('audit_results') or {}
    retry = state.get('audit_retry_count', 0) + 1

    updated_leads = []
    for lead in leads:
        updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=state.get('_webai_instance'))
        updated_leads.append(updated)
        audit_results[updated['norm']] = rep

    passed = [l for l in updated_leads if audit_results.get(l['norm'], {}).get('verdict') == 'pass']
    failed = [l for l in updated_leads if audit_results.get(l['norm'], {}).get('verdict') != 'pass']

    if retry >= state.get('audit_max_retries', 3):
        return {
            'contact_leads': passed,
            'audit_results': audit_results,
            'audit_retry_count': retry,
            'audit_pass': True,
            'new_companies': [c for c in state.get('new_companies') or [] if norm(c.get('name')) in [l['norm'] for l in passed]],
            '_success': True,
            '_note': f'第{retry}次修正完成，通过{len(passed)}家，剔除{len(failed)}家'
        }

    all_pass = len(failed) == 0
    return {
        'contact_leads': passed,
        'audit_results': audit_results,
        'audit_retry_count': retry,
        'audit_pass': all_pass,
        'new_companies': state.get('new_companies') if all_pass else [c for c in state.get('new_companies') if norm(c.get('name')) in [l['norm'] for l in passed]],
        '_success': True,
        '_note': f'第{retry}次修正完成，通过{len(passed)}家' + ('' if all_pass else f'，剩余{len(failed)}家')
    }

# ---------- 11. SCORE 评分专家 ----------
def n_score(state):
    from core.memory.db import DB
    from core.tools import scoring
    db = DB()
    scored = 0
    for lead in (state.get('contact_leads') or state.get('new_companies') or []):
        lead_norm = lead.get('norm') or norm(lead.get('name'))
        fresh = db.get_lead(lead_norm) or lead
        try:
            sc, gr, why = scoring.score_lead(fresh)
            db.lead_update(lead_norm, score=sc, grade=gr)
            scored += 1
        except Exception as e:
            print(f'[score] 评分失败 {fresh.get("name")}: {str(e)[:60]}')
    rep = experts.review('SCORE', f'评分完成 {scored} 家',
                         [('评分覆盖', scored > 0, f'{scored}家')])
    return {'node_reports': _report(state, 'SCORE', rep), '_success': True,
            '_note': f'评分完成 {scored} 家'}

# ---------- 阶段二占位节点（兼容 graph.py） ----------
def n_usitc(state):
    return {'_success': True, '_note': '阶段二关闭，跳过',
            'node_reports': _report(state, 'USITC', experts.review('USITC', '跳过'))}

def n_rank(state):
    cs = sorted(state.get('new_companies') or [], key=lambda c: (c.get('strength') or 0), reverse=True)
    return {'new_companies': cs,
            'node_reports': _report(state, 'RANK', experts.review('RANK', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_profile(state):
    return {'profiles': [],
            'node_reports': _report(state, 'B_PROFILE', experts.review('B_PROFILE', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_analysis(state):
    return {'analyses': [],
            'node_reports': _report(state, 'C_ANALYSIS', experts.review('C_ANALYSIS', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_outreach(state):
    return {'letters': [],
            'node_reports': _report(state, 'D_OUTREACH', experts.review('D_OUTREACH', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_learn(state):
    return {'_success': True, '_note': '学习模块已移至后台进化引擎', 'learn_summary': {}}

# ---------- Discovery commit：第一流程只负责把真实客户安全送入客户数据库 ----------
def n_discovery_commit(state):
    from core.memory.db import DB
    db=DB(); accepted=state.get('new_companies') or []
    created=0; updated=0; pending=0; failed=[]; unchanged=0
    for c in accepted:
        e=c.get('evidence') or {}
        hard=bool(e.get('shipments') or e.get('bill_of_lading') or e.get('customs') or e.get('trade_evidence'))
        zone='dev' if hard else 'pending'
        before=db.get_lead(db._norm(c.get('name')))
        result=db.commit_discovery_lead(c,zone=zone)
        if not result.get('ok'):
            failed.append((c.get('name') or '')[:120])
        elif result.get('created'):
            if zone=='dev': created+=1
            else: pending+=1
        elif result.get('changed'):
            updated+=1
        else:
            unchanged+=1
        if result.get('ok'):
            try:
                db.add_evidence_event(state.get('task_id',''), db._norm(c.get('name')), 'customs_incremental', c.get('source') or 'customs', json.dumps(e, ensure_ascii=False)[:1800], 1.0 if hard else 0.5)
            except Exception:
                pass
    ok=(len(failed)==0 and len(accepted)==created+pending+updated+unchanged)
    rep=experts.review('DISCOVERY_COMMIT',f'增量入库{len(accepted)}·新客户开发池{created}·已有画像更新{updated}·无变化{unchanged}·待验证{pending}·失败{len(failed)}',
                       [('候选已可靠入库',ok,f'{len(accepted)}=新{created}+更新{updated}+无变化{unchanged}+待验证{pending}，失败{len(failed)}')],critical={'候选已可靠入库'})
    return {'discovery_commit':{'accepted':len(accepted),'dev':created,'updated':updated,'unchanged':unchanged,'pending':pending,'failed':failed,
                                'policy':'new_only_to_dev; existing_only_merge_evidence'},
            'node_reports':_report(state,'DISCOVERY_COMMIT',rep),'_success':ok,
            '_note':f'增量入库完成：新开发池{created}·已有客户补充{updated}·无变化{unchanged}·待验证{pending}' if ok else f'客户入库失败 {len(failed)} 家：{failed[:3]}'}

