# -*- coding: utf-8 -*-
"""第二流程：客户开发情报与开发信序列。

设计原则：
1) 第一流程只负责发现真实客户；第二流程负责深度验证、需求机会、画像、Offer、开发信与发送。
2) 每个专家节点独立执行，节点间使用开发黑板交接。
3) 每个节点最多局部重试 NODE_RETRIES 次；达到上限后进入 Diagnostic Package -> Mission Director，改变方案而不是原地死循环。
4) 所有需求判断必须有证据；证据不足明确 UNKNOWN，不把模型猜测当成客户需求。
5) 第二流程复用第一流程已经采集的数据，只补缺失/新鲜数据，避免重复采集。
"""
import json, time, re, datetime as dt
from core.config import settings
from core.memory.db import DB
from core.tools import auditor, pitch
from core.runtime import experts

DEV_ORDER=['DEV_VERIFY','DEV_INTELLIGENCE','DEV_OPPORTUNITY','DEV_PROFILE','DEV_OFFER','DEV_LETTER','DEV_SEND']
DEV_LABELS={
 'DEV_VERIFY':'客户真实性验证','DEV_INTELLIGENCE':'客户开发情报','DEV_OPPORTUNITY':'需求机会发现',
 'DEV_PROFILE':'客户画像完善','DEV_OFFER':'Offer策略','DEV_LETTER':'个性化开发信','DEV_SEND':'发送/序列'
}


def _review(name, text, checks=None):
    try:
        return experts.review(name,text,checks or [])
    except Exception as e:
        return {'verdict':'warn','error':str(e)[:160]}


def _save(lead_norm, data):
    DB().save_development_blackboard(lead_norm, data)


def _base(state):
    db=DB(); lead=db.get_lead(state['lead_norm']) or {}
    rel=db.list_relationships(norm=state['lead_norm'],limit=200)
    ev=db.list_evidence_events(state['lead_norm'],limit=300)
    return db,lead,rel,ev


def _date_days(value):
    if not value:return None
    s=str(value).strip()
    candidates=[s,s[:10],s[:7],s[:4]]
    formats=['%Y-%m-%d','%Y/%m/%d','%m/%d/%Y','%Y-%m','%Y']
    for c in candidates:
        for fmt in formats:
            try:return (dt.date.today()-dt.datetime.strptime(c,fmt).date()).days
            except Exception:pass
    return None


def _trade_history(db, lead):
    """优先读取已导入的 buyers_90d / customs_raw；没有则使用 lead 上已有汇总字段。"""
    norm=str(lead.get('norm') or '')
    name=str(lead.get('name') or '')
    out={'shipments':int(lead.get('shipments') or 0),'first_seen':None,'last_seen':lead.get('last_shipment'),
         'supplier_count':0,'total_weight':0,'total_qty':0,'total_teu':0,'origins':[],'ports':[],'source':'lead_summary'}
    try:
        with db.c() as c:
            c.row_factory=__import__('sqlite3').Row
            r=c.execute('SELECT * FROM buyers_90d WHERE importer_norm=?',(norm,)).fetchone()
            if not r:
                r=c.execute('SELECT * FROM buyers_90d WHERE lower(importer)=lower(?)',(name,)).fetchone()
            if r:
                d=dict(r); out.update({'shipments':max(out['shipments'],int(d.get('shipments') or 0)),
                    'first_seen':d.get('first_seen'),'last_seen':d.get('last_seen') or out['last_seen'],
                    'supplier_count':int(d.get('supplier_count') or 0),'total_weight':float(d.get('total_weight') or 0),
                    'total_qty':float(d.get('total_qty') or 0),'total_teu':float(d.get('total_teu') or 0),
                    'origins':str(d.get('origins') or '').split(',')[:20],'ports':str(d.get('ports') or '').split(',')[:20],
                    'source':'buyers_90d'})
            # 进一步从原始记录提取时间序列，最多5000行，避免大库拖慢开发流程。
            rows=c.execute('SELECT ts,shipper,hs,descr,qty,weight,teu,origin,port_load,port_discharge FROM customs_raw WHERE importer_norm=? ORDER BY ts ASC LIMIT 5000',(norm,)).fetchall()
            if rows:
                out['source']='customs_raw'
                out['raw_count']=len(rows)
                dates=[]; suppliers=set(); desc=set(); total_qty=0; total_weight=0; total_teu=0
                for r in rows:
                    if r['ts']:
                        try: dates.append(dt.datetime.fromtimestamp(float(r['ts'])).date())
                        except Exception: pass
                    if r['shipper']: suppliers.add(str(r['shipper']).strip())
                    if r['descr']: desc.add(str(r['descr']).strip()[:120])
                    total_qty+=float(r['qty'] or 0); total_weight+=float(r['weight'] or 0); total_teu+=float(r['teu'] or 0)
                if dates:
                    out['first_seen']=str(min(dates)); out['last_seen']=str(max(dates))
                    out['shipment_dates']=[str(x) for x in dates[-60:]]
                out['supplier_count']=max(out['supplier_count'],len(suppliers)); out['supplier_names']=list(suppliers)[:40]
                out['sample_descriptions']=list(desc)[:30]
                out['total_qty']=max(out['total_qty'],total_qty); out['total_weight']=max(out['total_weight'],total_weight); out['total_teu']=max(out['total_teu'],total_teu)
    except Exception as e:
        out['warning']='trade history read failed: '+str(e)[:160]
    return out


def n_verify(state):
    db,lead,_,_= _base(state)
    if not lead:return {'_success':False,'_note':'客户不存在'}
    updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=None)
    if not updated:return {'_success':False,'_note':'客户资料验证失败'}
    hard = int(updated.get('shipments') or 0)>0 or bool(updated.get('audit'))
    verified = str(rep.get('verdict','')).lower()=='pass' and (hard or updated.get('website') or updated.get('emails'))
    status='dev_ready' if verified else 'pending'
    db.lead_update(state['lead_norm'],status=status,audit=json.dumps(rep,ensure_ascii=False))
    data={'verified':bool(verified),'audit':rep,'status':status,'updated':updated}
    _save(state['lead_norm'],{'verification':data})
    return {'lead':updated,'verification':data,'_success':bool(verified),'_note':'客户验证通过' if verified else '客户未通过开发前验证'}


def n_intelligence(state):
    db,lead,rel,ev=_base(state)
    if not lead:return {'_success':False,'_note':'缺少客户'}
    trade=_trade_history(db,lead)
    profile={k:lead.get(k) for k in ['name','country','website','emails','phones','address','contact_person','category','segment','shipments','last_shipment','desc_sample','source','score','grade']}
    suppliers=[]
    for r in rel:
        if str(r.get('from_type'))=='supplier' or str(r.get('to_type'))=='supplier':
            suppliers.append({'name':r.get('from_name') if r.get('from_type')=='supplier' else r.get('to_name'),
                              'relation':r.get('relation'),'confidence':r.get('confidence'),'source':r.get('source'),'evidence':r.get('evidence')})
    intel={'profile':profile,'supplier_relationships':suppliers[:50],'trade_history':trade,'evidence_events':ev[:120],
           'freshness':{'last_seen':lead.get('last_seen'),'last_shipment':trade.get('last_seen')},'unknowns':[]}
    for k,v in profile.items():
        if not v:intel['unknowns'].append(k)
    rep=_review('DEV_INTELLIGENCE',json.dumps(intel,ensure_ascii=False)[:11000],
                [('实体存在',bool(profile.get('name')),str(profile.get('name') or '')),
                 ('贸易背景',bool(trade.get('shipments') or suppliers),f"shipments={trade.get('shipments')},suppliers={len(suppliers)}"),
                 ('证据可追溯',bool(ev or trade.get('shipments')),f"events={len(ev)}")])
    if rep.get('verdict')=='fail':
        return {'_success':False,'_note':'客户情报验收未通过：'+str(rep.get('notes') or '')[:180]}
    _save(state['lead_norm'],{'intelligence':intel})
    return {'intelligence':intel,'_success':True,'_note':f'客户情报整理完成，供应商关系{len(suppliers)}条，贸易记录{trade.get("shipments",0)}票'}


def n_opportunity(state):
    db,lead,rel,ev=_base(state)
    if not lead:return {'_success':False,'_note':'缺少客户'}
    intel=state.get('intelligence') or {}; trade=intel.get('trade_history') or _trade_history(db,lead)
    shipments=int(trade.get('shipments') or 0); score=0.0; reasons=[]; evidence=[]
    if shipments>0: score+=25; reasons.append(f'存在{shipments}票历史贸易记录'); evidence.append('trade_history')
    last=trade.get('last_seen') or lead.get('last_shipment'); days=_date_days(last)
    if days is not None:
        if days<=45: score+=25; reasons.append('最近45天内有提货记录'); evidence.append('recent_trade')
        elif days<=120: score+=20; reasons.append('最近120天内有提货记录'); evidence.append('recent_trade')
        elif days<=240: score+=10; reasons.append('最近240天内有提货记录'); evidence.append('trade_recency')
    suppliers=max(len(rel),int(trade.get('supplier_count') or 0))
    if suppliers>=2: score+=20; reasons.append(f'存在{suppliers}个供应商/供应链关系，可观察供应商变化'); evidence.append('supplier_cross_check')
    if trade.get('supplier_count',0)>=3: score+=5; reasons.append('供应商来源较多，存在供应链比较空间'); evidence.append('supplier_diversity')
    changes=[e for e in ev if str(e.get('kind','')).lower() in {'website_change','product_change','business_change','supplier_change','new_collection'}]
    if changes: score+=20; reasons.append(f'发现{len(changes)}条业务/供应链变化证据'); evidence.append('business_change')
    # 采购周期：有日期序列时计算中位间隔，窗口只作为概率，不作为事实。
    dates=[]
    for s in trade.get('shipment_dates') or []:
        try: dates.append(dt.datetime.strptime(s,'%Y-%m-%d').date())
        except Exception: pass
    if len(dates)>=3:
        gaps=sorted((dates[i]-dates[i-1]).days for i in range(1,len(dates)) if (dates[i]-dates[i-1]).days>0)
        if gaps:
            med=gaps[len(gaps)//2]; days_since=(dt.date.today()-dates[-1]).days
            if 0<=days_since<=max(15,med*1.25): score+=10; reasons.append(f'当前距离上次提货约{days_since}天，接近历史约{med}天采购间隔'); evidence.append('cycle_window')
    score=min(100,round(score,1))
    if score>=75: window='NOW'
    elif score>=50: window='SOON'
    elif score>=25: window='WATCH'
    elif shipments: window='DORMANT'
    else: window='UNKNOWN'
    confidence=min(0.95,round(0.30+0.08*len(evidence),2))
    opportunity={'score':score,'window':window,'confidence':confidence,'reasons':reasons,'evidence_types':evidence,
                 'historical_context':{'last_shipment':last,'days_since_last':days,'supplier_count':suppliers,'shipment_count':shipments},
                 'caveat':'机会评分是基于公开/已有交易证据的概率判断，不代表客户已经提出采购需求。证据不足时保持UNKNOWN。'}
    rep=_review('DEV_OPPORTUNITY',json.dumps(opportunity,ensure_ascii=False),
                [('有证据才评分',bool(evidence),str(evidence)),('允许未知',window in {'UNKNOWN','DORMANT','WATCH','SOON','NOW'},window)])
    if rep.get('verdict')=='fail': return {'_success':False,'_note':'需求机会验收未通过：'+str(rep.get('notes') or '')[:180]}
    db.lead_update(state['lead_norm'],opportunity_score=score,demand_window=window,demand_confidence=confidence,opportunity=json.dumps(opportunity,ensure_ascii=False))
    _save(state['lead_norm'],{'opportunity':opportunity})
    return {'opportunity':opportunity,'_success':True,'_note':f'需求机会{score}分·窗口{window}'}


def n_profile(state):
    db,lead,rel,ev=_base(state); intel=state.get('intelligence') or {}; opp=state.get('opportunity') or {}
    profile=dict(intel.get('profile') or {})
    profile.update({'demand_window':opp.get('window'),'opportunity_score':opp.get('score'),'demand_confidence':opp.get('confidence'),
                    'supplier_relationships':intel.get('supplier_relationships') or [],'trade_history':intel.get('trade_history') or {},
                    'evidence_count':len(ev),'unknowns':intel.get('unknowns') or []})
    db.lead_update(state['lead_norm'],profile=json.dumps(profile,ensure_ascii=False))
    _save(state['lead_norm'],{'profile':profile})
    return {'profile':profile,'_success':True,'_note':f'客户画像完成，已知字段{len([v for v in profile.values() if v])}项'}


def n_offer(state):
    _,lead,_,_= _base(state); opp=state.get('opportunity') or {}; profile=state.get('profile') or {}
    window=opp.get('window','UNKNOWN'); score=float(opp.get('score') or 0); segment=str(lead.get('segment') or lead.get('category') or '')
    offers=[]
    if window in {'NOW','SOON'}: offers.append('Lead with free samples and a fast quotation to test supplier fit with low risk.')
    if any(x in segment.lower() for x in ('birthday','candle','蜡烛')): offers.append('Offer relevant spiral, number and party birthday candles based on the buyer\'s product direction.')
    if lead.get('shipments'): offers.append('Factory-direct supply from Ningjin, flexible capacity and competitive cluster pricing.')
    offers.append('OEM/ODM support and low-barrier trial orders for standard products.')
    if score<50: offers=offers[-1:]
    strategy={'priority':'high' if score>=75 else ('medium' if score>=50 else 'low'),'offers':offers[:3],
              'cta':'Reply for catalog, quotation or a free sample','reason':opp.get('reasons') or ['Demand evidence is limited; use a low-risk exploratory offer'],
              'do_not_claim':['Do not say the buyer is currently buying unless an explicit source proves it.']}
    _save(state['lead_norm'],{'offer_strategy':strategy})
    return {'offer_strategy':strategy,'_success':True,'_note':'Offer策略已生成'}


def n_letter(state):
    db,lead,_,_= _base(state); offer=state.get('offer_strategy') or {}; opp=state.get('opportunity') or {}
    ammo='Opportunity evidence: '+json.dumps(opp,ensure_ascii=False)[:2200]+'\nRecommended offer: '+json.dumps(offer,ensure_ascii=False)[:2200]
    try:
        from core.model.client import ModelClient
        txt=ModelClient().chat(pitch.letter_prompt(lead,ammo=ammo,industry_key=state.get('industry')),temperature=0.55,max_tokens=1200,timeout=300)
    except Exception as e:
        return {'_success':False,'_note':'开发信模型调用失败: '+str(e)[:180]}
    if not txt:return {'_success':False,'_note':'开发信模型未返回内容'}
    # 防止模型超长：保留 Subject + 前120词正文；签名由模型按固定模板生成。
    lines=txt.strip().splitlines(); subject_line=lines[0] if lines and lines[0].lower().startswith('subject:') else 'Subject: A quick sample idea for your team'
    body='\n'.join(lines[1:] if lines and lines[0].lower().startswith('subject:') else lines).strip()
    words=re.findall(r"\b[\w'-]+\b",body)
    if len(words)>120:
        body=' '.join(words[:120])
    txt=subject_line+'\n\n'+body
    db.add_message(state['lead_norm'],'out','email',txt,draft=1)
    _save(state['lead_norm'],{'letter':txt})
    return {'letter':txt,'_success':True,'_note':f'已生成个性化开发信草稿（正文约{len(words[:120])}词）'}


def n_send(state):
    db,lead,_,_= _base(state)
    if not settings.DEVELOPMENT_SEQUENCE_ENABLED or db.get_setting('development_sequence_enabled','true').lower()!='true':
        return {'send':{'status':'sequence_paused'},'_success':True,'_note':'开发信序列已暂停，停止发送但保留前序结果'}
    # 幂等保护：已发送过则不重复发送。
    sent=next((m for m in reversed(db.list_messages(state['lead_norm'])) if m.get('direction')=='out' and not m.get('draft')),None)
    if sent:return {'send':{'status':'already_sent','message_id':sent.get('id')},'_success':True,'_note':'该客户已有已发送邮件，本次跳过，防止重复发送'}
    if not settings.OUTREACH_ENABLED:
        return {'send':{'status':'draft_only','reason':'OUTREACH_ENABLED=false'},'_success':True,'_note':'发送功能未开启，保留草稿'}
    msg=next((m for m in reversed(db.list_messages(state['lead_norm'])) if m.get('direction')=='out' and m.get('draft')),None)
    if not msg:return {'_success':False,'_note':'没有可发送草稿'}
    try:
        from core.tools import mailer
        content=msg.get('content',''); subject='PSV introduction'; body=content
        lines=content.splitlines()
        if lines and lines[0].lower().startswith('subject:'):
            subject=lines[0].split(':',1)[1].strip() or subject; body='\n'.join(lines[1:]).strip()
        emails=re.split(r'[,;\s]+',str(lead.get('emails') or ''))
        to=next((e for e in emails if '@' in e), '')
        if not to:return {'_success':False,'_note':'客户没有可发送邮箱'}
        mailer.smtp_send(to,subject,body)
        db.add_message(state['lead_norm'],'out','email',content,draft=0)
        return {'send':{'status':'sent','to':to},'_success':True,'_note':'邮件已发送'}
    except Exception as e:return {'_success':False,'_note':'发送失败: '+str(e)[:180]}

FN={'DEV_VERIFY':n_verify,'DEV_INTELLIGENCE':n_intelligence,'DEV_OPPORTUNITY':n_opportunity,'DEV_PROFILE':n_profile,'DEV_OFFER':n_offer,'DEV_LETTER':n_letter,'DEV_SEND':n_send}


def _diagnose(state,node,error,attempt):
    package=experts.build_development_diagnostic_package(state,node,error,attempt)
    diag={'node':node,'attempt':attempt,'package':package,'ts':time.time(),'by':'local'}
    try: diag['local']=experts.diagnose(node,json.dumps(package,ensure_ascii=False)[:10000],json.dumps(state.get('dev_status',{}),ensure_ascii=False)[:4000])
    except Exception as e: diag['local']={'diagnosis':'local diagnostic failed','advice':str(e)[:180]}
    if settings.WEBAI_ENABLED and attempt>=settings.WEB_AI_AFTER_RETRIES:
        try:
            from core.tools import web_ai
            prompt='''你是外贸客户开发流程的故障诊断顾问。下面是完整事实包。observed_error只是观察结果，不是根因。请给出根因候选排序和可执行的下一步方案。不得绕过登录、验证码或访问控制，不得建议付费API。输出JSON：{"diagnosis":"","alternatives":[],"actions":[],"continue_safe":true,"skip_node":false,"confidence":0.0}'''
            ans=web_ai.solve(prompt,context=json.dumps(package,ensure_ascii=False),timeout=settings.WEBAI_TIMEOUT)
            from core.utils import jsonutil
            j=jsonutil.j(ans) if ans else None
            if j:
                diag['web_ai']={'diagnosis':str(j.get('diagnosis') or '')[:500],'alternatives':[str(x)[:300] for x in (j.get('alternatives') or [])[:5]],
                                'actions':[str(x)[:300] for x in (j.get('actions') or [])[:5]],'continue_safe':bool(j.get('continue_safe',True)),
                                'skip_node':bool(j.get('skip_node',False)),'confidence':float(j.get('confidence') or 0)}; diag['by']='web_ai'
        except Exception as e:diag['web_ai_error']=str(e)[:300]
    state.setdefault('dev_diagnostics',[]).append(diag); return diag


def _director(state,event,failure=None):
    snap={'task_id':state.get('task_id'),'lead_norm':state.get('lead_norm'),'current_node':state.get('current_dev_node'),
          'event':event,'failure':failure or {},'dev_status':state.get('dev_status',{}),'handoffs':state.get('dev_handoffs',{}),
          'opportunity':state.get('opportunity',{}),'profile':state.get('profile',{}),'offer_strategy':state.get('offer_strategy',{}),
          'constraints':['do not invent demand','reuse verified data','do not bypass access controls','do not send duplicate email']}
    try:return experts.mission_plan({'task_id':state.get('task_id'),'request':'Customer development sequence','market':state.get('market'),'industry':state.get('industry'),
                                     'current_node':state.get('current_dev_node'),'node_status':state.get('dev_status',{}),'handoffs':state.get('dev_handoffs',{}),
                                     'evidence_summary':snap,'companies':[],'suppliers':[]},event=event,failure=snap)
    except Exception as e:return {'action':'continue','reason':'director unavailable: '+str(e)[:160],'plan':[],'next_node':''}


def _handoff(state,name,out,ok):
    state.setdefault('dev_handoffs',{})[name]={'from':name,'to':DEV_ORDER[DEV_ORDER.index(name)+1] if name in DEV_ORDER and DEV_ORDER.index(name)+1<len(DEV_ORDER) else 'END',
                                              'accepted':bool(ok),'summary':str(out.get('_note') or '')[:300],'ts':time.time()}


def run_sequence(lead_norm,persist=None,start_node=None,task_id=None):
    db=DB(); lead=db.get_lead(lead_norm)
    if not lead:return {'ok':False,'error':'lead not found','lead_norm':lead_norm}
    previous=db.latest_development(lead_norm)
    state=(previous.get('result') or {}) if previous else {}
    if not isinstance(state,dict):state={}
    state.update({'lead_norm':lead_norm,'task_id':task_id or state.get('task_id'),'lead':lead})
    state.setdefault('dev_nodes',[]);state.setdefault('dev_status',{});state.setdefault('dev_handoffs',{});state.setdefault('dev_diagnostics',[]);state.setdefault('dev_retry_history',[])
    start_idx=DEV_ORDER.index(start_node) if start_node in DEV_ORDER else 0
    # 从中断位置恢复；手动指定节点则从该节点开始，但仍保留黑板。
    if not start_node:
        start_idx=next((i for i,n in enumerate(DEV_ORDER) if state.get('dev_status',{}).get(n,{}).get('status') not in ('success','skipped')),0)
    attempts={}
    for i in range(start_idx,len(DEV_ORDER)):
        name=DEV_ORDER[i]
        if name=='DEV_SEND' and state.get('dev_status',{}).get('DEV_SEND',{}).get('status')=='success':continue
        state['current_dev_node']=name
        attempt=0
        while attempt<max(1,settings.NODE_RETRIES):
            attempt+=1; state['dev_status'][name]={'status':'running','attempt':attempt,'updated_at':time.time()}
            if persist:persist(state)
            t=time.time()
            try:out=FN[name](state) or {}; ok=bool(out.pop('_success',True)); note=str(out.pop('_note','')); state.update(out)
            except Exception as e:ok=False; note=str(e)[:400];out={}
            status='success' if ok else 'failed'; state['dev_status'][name]={'status':status,'attempt':attempt,'note':note,'updated_at':time.time(),'duration':round(time.time()-t,2)}
            state['dev_nodes'].append({'node':name,'status':status,'note':note,'attempt':attempt,'ts':time.time()})
            _handoff(state,name,out,ok)
            if persist:persist(state)
            if ok:break
            state['dev_retry_history'].append({'node':name,'attempt':attempt,'error':note,'ts':time.time()})
            if attempt>=settings.NODE_RETRIES:
                diag=_diagnose(state,name,note,attempt)
                decision=_director(state,'development_node_failed',{'node':name,'error':note,'diagnostic':diag})
                state.setdefault('dev_director_decisions',[]).append(dict(decision,ts=time.time()))
                action=str(decision.get('action') or 'replan')
                if action=='skip' and name not in {'DEV_VERIFY','DEV_OPPORTUNITY','DEV_PROFILE'}:
                    state['dev_status'][name]['status']='skipped'; _handoff(state,name,{'_note':'director skip'},True); break
                if action in {'continue','skip'} and name=='DEV_VERIFY':
                    state['error']='客户真实性验证失败，禁止继续开发'; state['ok']=False; state['current_dev_node']='END'
                    if persist:persist(state); return state
                if action=='abort':
                    state['error']=note; state['ok']=False; state['current_dev_node']='END'
                    if persist:persist(state); return state
                # replan：重新执行当前节点；如果仍失败，外层任务会保留诊断而不会伪造成功。
                attempt=0
                continue
        if state.get('dev_status',{}).get(name,{}).get('status') not in ('success','skipped'):
            state['error']=state['dev_status'][name].get('note','node failed'); state['ok']=False; state['current_dev_node']='END'
            if persist:persist(state); return state
    state['ok']=True; state['current_dev_node']='END'
    if persist:persist(state)
    return state
