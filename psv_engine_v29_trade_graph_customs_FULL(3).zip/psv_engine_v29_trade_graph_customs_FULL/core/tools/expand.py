# -*- coding: utf-8 -*-
"""Customs Graph 网络扩张：有限预算、可重复执行、双向收割、永不无限循环。"""
import re,time
from core.config import settings
from core.memory.db import DB
from core.tools import suppliers as sup

def slug(name):
    return re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',str(name or '').lower())).strip('-')

def run_network(task_id=None,seed_norms=None,depth=None,max_new=None,buyers_per=None,suppliers_per=None,customers_per=None):
    db=DB();depth=int(depth or settings.NETWORK_EXPANSION_DEPTH);max_new=int(max_new or settings.NETWORK_EXPANSION_MAX_NEW);buyers_per=int(buyers_per or settings.NETWORK_EXPANSION_BUYERS);suppliers_per=int(suppliers_per or settings.NETWORK_EXPANSION_SUPPLIERS);customers_per=int(customers_per or settings.NETWORK_EXPANSION_CUSTOMERS)
    seeds=[]
    if seed_norms:
        for n in seed_norms:
            l=db.get_lead(n)
            if l:seeds.append(l)
    else: seeds=db.list_leads(kind='importer',limit=buyers_per)
    have={x['norm'] for x in db.list_leads(limit=10000)};stats={'depths':[],'new_leads':0,'buyers_scanned':0,'suppliers_scanned':0,'errors':[],'stopped_by_budget':False}
    frontier=seeds[:buyers_per]
    try:
        from core.tools import iy_web
        if not iy_web.available():return {**stats,'error':'ImportYeti网页未就绪'}
        with iy_web.IYWeb() as w:
            for d in range(1,depth+1):
                if not frontier or stats['new_leads']>=max_new:break
                next_frontier=[];depth_new=0;bs=ss=0
                for buyer in frontier[:buyers_per]:
                    if stats['new_leads']>=max_new:break
                    try:
                        rows=w.relationships('https://www.importyeti.com/company/'+slug(buyer['name']),'Suppliers')[:suppliers_per];bs+=1
                        sup_entries=[]
                        for r in rows:
                            nm=r.get('name') or '';sn=sup.norm(nm)
                            if not sn:continue
                            sup_entries.append({'norm':sn,'name':nm,'slug':slug(nm),'shipments':r.get('shipments') or 0,'last_seen':time.time(),'via':f'expand:d{d}:{buyer["name"]}'})
                        if sup_entries:sup.upsert_pool(sup_entries)
                        for se in sup_entries:
                            if stats['new_leads']>=max_new:break
                            s_norm=se['norm'];url='https://www.importyeti.com/supplier/'+(se.get('slug') or slug(se['name']))
                            try:
                                custs=w.relationships(url,'Customers')[:customers_per];ss+=1
                                added=0
                                for c in custs:
                                    nm=c.get('name') or '';cn=DB._norm(nm)
                                    if not cn or cn in have:continue
                                    have.add(cn);item={'name':nm,'country':'USA','kind':'importer','segment':'','shipments':c.get('shipments') or 0,'desc_sample':(c.get('products') or '')[:300],'source':f'network_expand:d{d}'};db.upsert_leads([item]);db.mark_frontier(cn,d+1,task_id,'pending');next_frontier.append(db.get_lead(cn));added+=1;stats['new_leads']+=1;depth_new+=1
                                    db.add_relationship(task_id,se['name'],'supplier',nm,'buyer','supplier_to_customer',{'shipments':c.get('shipments'),'products':c.get('products') or '','url':url},'importyeti_web',confidence=.9 if c.get('shipments') else .75,depth=d+1)
                                sup.mark_harvested(s_norm,len(custs));sup.log_harvest(task_id or '','',se['name'],'network_expand','ok',len(custs),f'depth={d};new={added}')
                            except Exception as e:stats['errors'].append(f'{se["name"]}:{str(e)[:80]}')
                    except Exception as e:stats['errors'].append(f'{buyer["name"]}:{str(e)[:80]}')
                db.add_expansion_run(task_id or '',d,bs,ss,depth_new,max_new);stats['depths'].append({'depth':d,'buyers':bs,'suppliers':ss,'new':depth_new});stats['buyers_scanned']+=bs;stats['suppliers_scanned']+=ss
                frontier=next_frontier
            if stats['new_leads']>=max_new:stats['stopped_by_budget']=True
    except Exception as e:stats['errors'].append(str(e)[:160])
    return stats

def run(limit_buyers=None,customers_per=None,max_new=None):
    return run_network(max_new=max_new,buyers_per=limit_buyers,customers_per=customers_per)
