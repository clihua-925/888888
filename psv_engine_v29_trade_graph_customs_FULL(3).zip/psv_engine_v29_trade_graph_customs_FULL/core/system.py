# -*- coding: utf-8 -*-
"""PSV Engine 25.1 Deployment Edition.
长期运行安全：任务队列、开发队列、定时任务 claim lock、服务重启恢复、幂等开发序列。
"""
import json,threading,time,uuid,queue
from core.runtime.orchestrator import Orchestrator
from core.memory.db import DB
from core.runtime import graph,development
from core.tools import expand as expand_tool
from core.config import settings

class PSVSystem:
    def __init__(self):
        self.orch=Orchestrator(); self.db=DB(); self.q=queue.Queue(); self.dev_q=queue.Queue(); self._stopping=False
        self._recover_queues()
        threading.Thread(target=self._worker,daemon=True,name='psv-discovery-worker').start()
        threading.Thread(target=self._dev_worker,daemon=True,name='psv-development-worker').start()
        if settings.SCHEDULER_ENABLED: threading.Thread(target=self._scheduler,daemon=True,name='psv-scheduler').start()
    def _recover_queues(self):
        now=time.time()
        with self.db.c() as x:
            rows=x.execute("SELECT task_id,request,status,result FROM tasks WHERE status IN ('running','queued')").fetchall()
        for tid,req,status,res in rows:
            try:p=json.loads(res or '{}')
            except Exception:p={}
            mode=p.get('mode')
            if status=='running':
                p['error']='服务重启：任务曾在运行中，已安全标记为可恢复'; p['recovered_at']=now
                self.db.save_task(tid,req,'queued',p)
            if mode=='development' or str(tid).startswith('dev-'):
                lead=p.get('lead_norm')
                if lead:self.dev_q.put((lead,tid))
            else:
                params=p.get('params') or {}
                if params.get('industry'):
                    self.q.put((tid,req,params.get('market') or 'USA',params['industry'],params.get('quantity') or 20))
    def _worker(self):
        while not self._stopping:
            item=self.q.get()
            if item is None: continue
            tid,request,market,industry,quantity=item
            try:self.orch.run(request,market,industry,int(quantity or 20),task_id=tid)
            except Exception as e:self.db.save_task(tid,request,'failed',{'error':str(e)[:800],'recovered':True})
    def _dev_worker(self):
        while not self._stopping:
            item=self.dev_q.get()
            if not item:continue
            lead_norm,tid=item
            try:self.orch.run_development(lead_norm,task_id=tid)
            except Exception as e:self.db.save_task(tid,'Development sequence: '+lead_norm,'failed',{'error':str(e)[:800]})
    def _scheduler(self):
        while not self._stopping:
            try:
                now=time.time()
                for s in self.db.list_schedules(enabled=True):
                    if float(s.get('next_run') or 0)>now: continue
                    if not self.db.claim_due_schedule(s['id'],lock_seconds=max(120,int(s.get('interval_minutes') or 60)*60)): continue
                    try:
                        if s['job_type']=='discovery':
                            tid=self.start(f"Scheduled discovery: {s['industry']} / {s['market']}",s['market'],s['industry'],s['quantity'])
                            self.db.mark_schedule_run(s['id'],'queued')
                        elif s['job_type']=='development':
                            if not settings.DEVELOPMENT_SEQUENCE_ENABLED or self.db.get_setting('development_sequence_enabled','true').lower()!='true':
                                self.db.mark_schedule_run(s['id'],'paused:development_sequence_disabled'); continue
                            max_n=int((s.get('params') or {}).get('max_customers') or settings.DEVELOPMENT_MAX_CUSTOMERS)
                            leads=self.db.list_leads(kind='importer',zone='dev',limit=max_n)
                            queued=0
                            for lead in leads:
                                if str(lead.get('development_status') or '') in {'done','running'}: continue
                                self.start_development(lead['norm']); queued+=1
                            self.db.mark_schedule_run(s['id'],f'queued:{queued}')
                        else:self.db.mark_schedule_run(s['id'],'invalid_job')
                    except Exception as e:self.db.mark_schedule_run(s['id'],'error:'+str(e)[:120])
            except Exception as e: print('[scheduler]',str(e)[:200])
            time.sleep(max(2,settings.SCHEDULER_POLL_SECONDS))
    def start(self,request,market,industry,quantity):
        tid=uuid.uuid4().hex[:8]
        self.db.save_task(tid,request,'queued',{'mode':'discovery','params':{'market':market,'industry':industry,'quantity':int(quantity or 20)}})
        self.q.put((tid,request,market,industry,quantity)); return tid
    def start_development(self,lead_norm):
        if not settings.DEVELOPMENT_SEQUENCE_ENABLED or self.db.get_setting('development_sequence_enabled','true').lower()!='true':
            return 'development-sequence-disabled'
        lead=self.db.get_lead(lead_norm)
        if not lead:return 'lead-not-found'
        if str(lead.get('zone') or '')!='dev':return 'lead-not-in-development-pool'
        existing=self.db.latest_development(lead_norm)
        if existing and existing.get('status')=='running': return existing.get('result',{}).get('task_id') or 'already-running'
        tid='dev-'+uuid.uuid4().hex[:8]
        self.db.save_task(tid,'Development sequence: '+lead_norm,'queued',{'mode':'development','lead_norm':lead_norm})
        self.db.lead_update(lead_norm,development_status='running')
        self.dev_q.put((lead_norm,tid)); return tid
    def start_development_batch(self,max_customers=20):
        if not settings.DEVELOPMENT_SEQUENCE_ENABLED or self.db.get_setting('development_sequence_enabled','true').lower()!='true':
            return {'ok':False,'error':'development-sequence-disabled','queued':0}
        leads=self.db.list_leads(kind='importer',zone='dev',limit=max(1,int(max_customers or settings.DEVELOPMENT_MAX_CUSTOMERS)))
        queued=0;ids=[]
        for lead in leads:
            if str(lead.get('development_status') or '') in {'running','done'}: continue
            tid=self.start_development(lead['norm'])
            if tid.startswith('dev-'): ids.append(tid);queued+=1
        return {'ok':True,'queued':queued,'task_ids':ids}

    def run_network(self,tid,params=None):
        params=params or {}
        seed_norms=params.get('seed_norms') or []
        if isinstance(seed_norms,str): seed_norms=[seed_norms]
        try:
            if seed_norms:
                for n in seed_norms[:1]: self.db.begin_expansion(tid,n)
            out=expand_tool.run_network(task_id=tid,seed_norms=seed_norms,depth=params.get('depth'),max_new=params.get('max_new'),buyers_per=params.get('buyers_per'),suppliers_per=params.get('suppliers_per'),customers_per=params.get('customers_per'))
            task=self.db.get_task(tid) or {'request':'network expansion'}
            status='done' if not out.get('error') else 'failed'
            if seed_norms: self.db.finish_expansion(tid,status,out.get('new_leads',0),str(out.get('errors') or '')[:500])
            self.db.save_task(tid,task.get('request','Network expansion'),'done' if status=='done' else 'failed',{'mode':'network_expansion','seed_norms':seed_norms,'expansion':out})
            return {'ok':status=='done','result':out}
        except Exception as e:
            if seed_norms:
                try:self.db.finish_expansion(tid,'failed',0,str(e)[:500])
                except Exception:pass
            return {'ok':False,'error':str(e)[:500]}
    def run_node(self,tid,node):
        task=self.db.get_task(tid)
        if not task:return {'error':'task not found'}
        if (task.get('result') or {}).get('mode')=='development' or tid.startswith('dev-'): return self.run_dev_node(tid,node)
        state=task.get('result') or {}; state['task_id']=tid
        if node not in graph.FN:return {'error':'unknown node','allowed':list(graph.FN)}
        def persist(st):self.db.save_task(tid,task.get('request',''),'running',st)
        ok,out,error=graph._run_once(state,node,1,persist); self.db.save_task(tid,task.get('request',''),'running',state)
        return {'ok':ok,'node':node,'error':error,'result':state}
    def run_dev_node(self,tid,node):
        task=self.db.get_task(tid)
        if not task:return {'ok':False,'error':'task not found'}
        result=task.get('result') or {}; lead_norm=result.get('lead_norm')
        if node not in development.FN:return {'ok':False,'error':'unknown development node','allowed':list(development.FN)}
        try:
            out=self.orch.run_development(lead_norm,task_id=tid,start_node=node)
            status='done' if out.get('ok') else 'failed'
            self.db.save_task(tid,task.get('request',''),'done' if status=='done' else 'failed',out)
            return {'ok':bool(out.get('ok')),'node':node,'error':out.get('error',''),'result':out}
        except Exception as e:return {'ok':False,'node':node,'error':str(e)[:500]}
    def get(self,tid): return self.db.get_task(tid)
