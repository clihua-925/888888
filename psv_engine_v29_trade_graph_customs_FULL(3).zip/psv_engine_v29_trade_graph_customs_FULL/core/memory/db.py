import re,sqlite3,time,json
from core.config import settings

LEAD_COLS=[('category','TEXT'),('website','TEXT'),('emails','TEXT'),('phones','TEXT'),('address','TEXT'),('linkedin','TEXT'),('contact_person','TEXT'),('score','REAL'),('grade','TEXT'),('profile','TEXT'),('zone','TEXT'),('touch_status','TEXT'),('last_touch','REAL'),('audit','TEXT')]
MSG_SQL="""CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,lead_norm TEXT,direction TEXT,channel TEXT,content TEXT,draft INT,ts REAL);"""

class DB:
    def __init__(self,path=None): self.path=path or settings.DATABASE_PATH; self.init()
    def c(self): return sqlite3.connect(self.path,timeout=10)
    def init(self):
        with self.c() as x:
            x.executescript('''
            CREATE TABLE IF NOT EXISTS tasks(task_id TEXT PRIMARY KEY,request TEXT,status TEXT,result TEXT,created_at REAL,updated_at REAL);
            CREATE TABLE IF NOT EXISTS icp_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,market TEXT,industry TEXT,card TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS companies(norm TEXT PRIMARY KEY,name TEXT,country TEXT,industry TEXT,type TEXT,website TEXT,source TEXT,strength INT,freshness REAL,updated_at REAL);
            CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY AUTOINCREMENT,norm TEXT,kind TEXT,content TEXT,source TEXT,ts REAL);
            CREATE TABLE IF NOT EXISTS raw_sources(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT,query TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS clean_batches(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,stage TEXT,raw_count INT,clean_count INT,noise_count INT,duplicate_count INT,identity_only_count INT,hard_evidence_count INT,noise_ratio REAL,clean_ratio REAL,created_at REAL);
            CREATE TABLE IF NOT EXISTS expansion_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,depth INT,buyers_scanned INT,suppliers_scanned INT,new_customers INT,max_new INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS expansion_frontier(norm TEXT PRIMARY KEY,depth INT,source_task TEXT,status TEXT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS search_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,project_key TEXT,market TEXT,industry TEXT,limit_n INT,result_count INT,used_sources TEXT,source_errors TEXT,gate TEXT,evolved INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS project_evolution(project_key TEXT PRIMARY KEY,run_count INT,evolved INT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS source_quota(source TEXT,day TEXT,count INT,UNIQUE(source,day));
            CREATE TABLE IF NOT EXISTS source_checkpoints(source TEXT,project_key TEXT,run_count INT DEFAULT 0,cursor INT DEFAULT 0,watermark REAL DEFAULT 0,last_count INT DEFAULT 0,last_fingerprint TEXT,updated_at REAL,PRIMARY KEY(source,project_key));
            CREATE TABLE IF NOT EXISTS customs_raw(id INTEGER PRIMARY KEY AUTOINCREMENT,row_hash TEXT UNIQUE,bol TEXT,ts REAL,importer TEXT,importer_norm TEXT,shipper TEXT,notify TEXT,hs TEXT,descr TEXT,qty REAL,weight REAL,teu REAL,origin TEXT,port_load TEXT,port_discharge TEXT,source_file TEXT,direct_importer INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS buyers_90d(importer_norm TEXT PRIMARY KEY,importer TEXT,first_seen REAL,last_seen REAL,shipments INT,total_weight REAL,total_qty REAL,total_teu REAL,supplier_count INT,origins TEXT,ports TEXT,sample_desc TEXT,score REAL,reasons TEXT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS suppliers(supplier_norm TEXT PRIMARY KEY,name TEXT,slug TEXT,shipments INT,first_seen REAL,last_seen REAL,harvested_at REAL,bol_fetched INT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS company_state(norm TEXT PRIMARY KEY,name TEXT,first_seen REAL,last_seen REAL,runs_seen INT,profiled INT,source TEXT);
            CREATE TABLE IF NOT EXISTS harvest_log(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,slug TEXT,supplier TEXT,mode TEXT,status TEXT,items INT,note TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS relationships(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,from_norm TEXT,from_name TEXT,from_type TEXT,to_norm TEXT,to_name TEXT,to_type TEXT,relation TEXT,evidence TEXT,source TEXT,confidence REAL,depth INT,created_at REAL,UNIQUE(task_id,from_norm,to_norm,relation));
            CREATE TABLE IF NOT EXISTS evidence_events(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,norm TEXT,kind TEXT,source TEXT,content TEXT,weight REAL,created_at REAL);
            CREATE TABLE IF NOT EXISTS usitc_cache(id INTEGER PRIMARY KEY AUTOINCREMENT,hs TEXT,kind TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS leads(norm TEXT PRIMARY KEY,name TEXT,country TEXT,kind TEXT,hs_code TEXT,shipments INT,last_shipment TEXT,tags TEXT,segment TEXT,desc_sample TEXT,source TEXT,first_seen REAL,last_seen REAL,status TEXT);
            CREATE TABLE IF NOT EXISTS development_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,lead_norm TEXT,status TEXT,result TEXT,created_at REAL,updated_at REAL);
            CREATE TABLE IF NOT EXISTS schedules(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,job_type TEXT,market TEXT,industry TEXT,quantity INT,interval_minutes INT,enabled INT,next_run REAL,last_run REAL,last_status TEXT,params TEXT,created_at REAL,updated_at REAL,locked_until REAL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS expansion_jobs(task_id TEXT PRIMARY KEY,seed_norm TEXT,status TEXT,started_at REAL,finished_at REAL,new_leads INT DEFAULT 0,note TEXT);
            '''+MSG_SQL+'''
            ''')
            have={r[1] for r in x.execute('PRAGMA table_info(leads)')}
            for col,typ in LEAD_COLS + [('opportunity_score','REAL'),('demand_window','TEXT'),('demand_confidence','REAL'),('opportunity','TEXT'),('development_status','TEXT')]:
                if col not in have: x.execute('ALTER TABLE leads ADD COLUMN '+col+' '+typ)
            x.execute("UPDATE leads SET zone='pool' WHERE zone IS NULL OR zone=''")
            # 生产规模索引：客户→供应商→客户图谱和客户列表均需稳定走索引。
            x.executescript('''
            CREATE INDEX IF NOT EXISTS idx_customs_importer_norm_ts ON customs_raw(importer_norm,ts DESC);
            CREATE INDEX IF NOT EXISTS idx_customs_shipper_ts ON customs_raw(shipper,ts DESC);
            CREATE INDEX IF NOT EXISTS idx_customs_ts ON customs_raw(ts DESC);
            CREATE INDEX IF NOT EXISTS idx_relationships_from_norm ON relationships(from_norm,created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_relationships_to_norm ON relationships(to_norm,created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_evidence_events_norm ON evidence_events(norm,created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_leads_zone_score ON leads(zone,score DESC,shipments DESC,last_seen DESC);
            ''')
            have_s={r[1] for r in x.execute('PRAGMA table_info(schedules)')}
            if 'locked_until' not in have_s: x.execute('ALTER TABLE schedules ADD COLUMN locked_until REAL DEFAULT 0')
            have_l={r[1] for r in x.execute('PRAGMA table_info(leads)')}
            for col,typ in [('expansion_count','INTEGER DEFAULT 0'),('last_expansion','REAL'),('expansion_status','TEXT')]:
                if col not in have_l: x.execute('ALTER TABLE leads ADD COLUMN '+col+' '+typ)
    def save_task(self,tid,req,status,result):
        now=time.time()
        with self.c() as x: x.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?) ON CONFLICT(task_id) DO UPDATE SET status=excluded.status,result=excluded.result,updated_at=excluded.updated_at',(tid,req,status,json.dumps(result,ensure_ascii=False),now,now))
    @staticmethod
    def _norm(n): return re.sub(r'[^a-z0-9]+','',str(n or '').lower())
    @staticmethod
    def _db_value(v, max_len=None):
        # SQLite 不接受 list/dict 直接绑定；贸易数据里的 hs/emails/products 等字段经常是数组。
        if isinstance(v, (list, tuple, set)):
            v = ', '.join(str(x) for x in v if x is not None)
        elif isinstance(v, dict):
            v = json.dumps(v, ensure_ascii=False)
        if v is None: v=''
        v=str(v) if not isinstance(v,(int,float)) else v
        return v[:max_len] if max_len and isinstance(v,str) else v
    @staticmethod
    def _merge_text(old, new, sep=', '):
        vals=[]
        for v in (old, new):
            if isinstance(v,(list,tuple,set)): vals.extend(str(x).strip() for x in v if x is not None and str(x).strip())
            elif v is not None and str(v).strip(): vals.extend(x.strip() for x in str(v).replace(';',',').split(',') if x.strip())
        out=[]; seen=set()
        for v in vals:
            k=v.lower()
            if k not in seen: seen.add(k); out.append(v)
        return sep.join(out)

    @staticmethod
    def _merge_last_seen(old, new):
        if old in (None,''): return new or ''
        if new in (None,''): return old
        try:
            return new if float(new) >= float(old) else old
        except Exception:
            return new if str(new) > str(old) else old

    def upsert_leads(self,items):
        now=time.time()
        with self.c() as x:
            for c in items or []:
                nm=(c.get('name') or '').strip()
                if len(nm)<3: continue
                norm=self._norm(nm)
                old=x.execute('SELECT * FROM leads WHERE norm=?',(norm,)).fetchone()
                if old:
                    names=[d[0] for d in x.execute('PRAGMA table_info(leads)').fetchall()]
                    o=dict(zip(names,old))
                    old_tags=o.get('tags') or ''
                    tags=self._merge_text(old_tags,c.get('tags') or [],',')
                    hs=self._merge_text(o.get('hs_code') or '',c.get('hs_code') or '',', ')
                    desc=self._merge_text(o.get('desc_sample') or '',c.get('desc_sample') or '', ' | ')[:500]
                    src='+'.join(dict.fromkeys([v for part in (str(o.get('source') or ''),str(c.get('source') or '')) for v in part.split('+') if v]))
                    ship=max(int(o.get('shipments') or 0),int(c.get('shipments') or 0))
                    vals={
                        'name': nm or o.get('name') or '',
                        'country': c.get('country') or o.get('country') or '',
                        'kind': c.get('kind') or o.get('kind') or 'importer',
                        'hs_code': hs, 'shipments': ship,
                        'last_shipment': self._merge_last_seen(o.get('last_shipment'),c.get('last_shipment')),
                        'tags': tags, 'segment': c.get('segment') or o.get('segment') or '',
                        'category': c.get('category') or c.get('industry') or o.get('category') or '',
                        'desc_sample': desc, 'source': src, 'last_seen': now,
                        'status': c.get('status') or o.get('status') or 'new'
                    }
                    # 画像/联系方式只补空，不覆盖已有可信字段。
                    for col in ('website','emails','phones','address','linkedin','contact_person','profile'):
                        nv=c.get(col)
                        if nv:
                            vals[col]=self._db_value(nv)
                        else:
                            vals[col]=o.get(col) or ''
                    # 区域、开发状态、触达状态属于业务状态，增量采集绝不重置。
                    sets=','.join(k+'=?' for k in vals)
                    x.execute('UPDATE leads SET '+sets+' WHERE norm=?',tuple(self._db_value(v) for v in vals.values())+(norm,))
                else:
                    tags=self._db_value(c.get('tags') or [])
                    x.execute('INSERT INTO leads(norm,name,country,kind,hs_code,shipments,last_shipment,tags,segment,category,desc_sample,source,first_seen,last_seen,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        (norm,nm,self._db_value(c.get('country','')),self._db_value(c.get('kind','importer')),self._db_value(c.get('hs_code','')),int(c.get('shipments') or 0),self._db_value(c.get('last_shipment','')),tags,self._db_value(c.get('segment','')),self._db_value(c.get('category') or c.get('industry') or ''),self._db_value(c.get('desc_sample',''),500),self._db_value(c.get('source','')),now,now,self._db_value(c.get('status') or 'new')))
                # 每次看到该实体都更新增量状态，但不改变业务分区。
                x.execute("INSERT INTO company_state(norm,name,first_seen,last_seen,runs_seen,profiled,source) VALUES(?,?,?,?,?,?,?) ON CONFLICT(norm) DO UPDATE SET name=excluded.name,last_seen=excluded.last_seen,runs_seen=company_state.runs_seen+1,source=CASE WHEN company_state.source='' THEN excluded.source ELSE company_state.source || '+' || excluded.source END",
                          (norm,nm,now,now,1,0,self._db_value(c.get('source',''))))

    def get_source_checkpoint(self,source,project_key):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM source_checkpoints WHERE source=? AND project_key=?',(str(source),str(project_key))).fetchone()
            return dict(r) if r else {'source':source,'project_key':project_key,'run_count':0,'cursor':0,'watermark':0,'last_count':0,'last_fingerprint':''}

    def update_source_checkpoint(self,source,project_key,**kw):
        cur=self.get_source_checkpoint(source,project_key); cur.update(kw); cur['updated_at']=time.time()
        with self.c() as x:
            x.execute('INSERT INTO source_checkpoints(source,project_key,run_count,cursor,watermark,last_count,last_fingerprint,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source,project_key) DO UPDATE SET run_count=excluded.run_count,cursor=excluded.cursor,watermark=excluded.watermark,last_count=excluded.last_count,last_fingerprint=excluded.last_fingerprint,updated_at=excluded.updated_at',
                      (source,project_key,int(cur.get('run_count') or 0),int(cur.get('cursor') or 0),float(cur.get('watermark') or 0),int(cur.get('last_count') or 0),str(cur.get('last_fingerprint') or ''),cur['updated_at']))

    def list_leads(self,kind=None,segment=None,q=None,zone=None,limit=500):
        sql='SELECT * FROM leads WHERE 1=1'; args=[]
        if kind: sql+=' AND kind=?'; args.append(kind)
        if segment: sql+=' AND segment=?'; args.append(segment)
        if zone: sql+=' AND zone=?'; args.append(zone)
        if q: sql+=' AND name LIKE ?'; args.append('%'+q+'%')
        sql+=' ORDER BY COALESCE(score,0) DESC,shipments DESC,last_seen DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            rows=[dict(r) for r in x.execute(sql,args).fetchall()]
            # 通信界面需要直接知道：开发流程是否运行、是否生成过草稿、是否已经发送。
            for r in rows:
                n=r.get('norm') or ''
                sent=x.execute("SELECT 1 FROM messages WHERE lead_norm=? AND direction='out' AND draft=0 LIMIT 1",(n,)).fetchone()
                draft=x.execute("SELECT 1 FROM messages WHERE lead_norm=? AND direction='out' AND draft=1 LIMIT 1",(n,)).fetchone()
                running=x.execute("SELECT 1 FROM development_runs WHERE lead_norm=? AND status='running' ORDER BY id DESC LIMIT 1",(n,)).fetchone()
                r['outreach_state']='sent' if sent else ('draft' if draft else 'not_started')
                if running: r['development_status']='running'
                elif not r.get('development_status'): r['development_status']='not_started'
            return rows
    def get_lead(self,norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM leads WHERE norm=?',(norm,)).fetchone()
            return dict(r) if r else None
    def lead_update(self,norm,**kw):
        if not kw: return 0
        sql='UPDATE leads SET '+','.join(k+'=?' for k in kw)+' WHERE norm=?'
        with self.c() as x:
            vals=tuple(self._db_value(v) for v in kw.values())+(norm,)
            cur=x.execute(sql,vals)
            return cur.rowcount

    def commit_discovery_lead(self, company, zone='dev'):
        """增量入库：新实体才进入开发池；已存在实体只合并新海关证据，不重置区域/开发状态。"""
        nm=(company.get('name') or '').strip()
        if not nm: return {'ok':False,'norm':'','created':False,'changed':False}
        n=self._norm(nm); before=self.get_lead(n)
        e=company.get('evidence') or {}
        self.upsert_leads([{'name':nm,'country':company.get('country') or '','kind':'importer','shipments':e.get('shipments') or 0,
                            'last_shipment':e.get('last_shipment') or '','hs_code':e.get('hs') or '',
                            'segment':company.get('segment') or '','category':company.get('industry') or '',
                            'desc_sample':e.get('products') or '','tags':[],'source':company.get('source') or '',
                            'website':company.get('website') or '','emails':company.get('emails') or '',
                            'phones':company.get('phones') or '','address':company.get('address') or ''}])
        after=self.get_lead(n)
        if not after: return {'ok':False,'norm':n,'created':False,'changed':False}
        if before:
            return {'ok':True,'norm':n,'created':False,'updated':True,'zone':after.get('zone'),'changed':after!=before}
        self.lead_update(n,zone=zone,status='new',development_status='not_started')
        return {'ok':True,'norm':n,'created':True,'updated':False,'zone':zone,'changed':True}

    def set_zone(self,norm,zone,touch_status=None):
        kw={'zone':zone}
        if touch_status is not None: kw['touch_status']=touch_status; kw['last_touch']=time.time()
        self.lead_update(norm,**kw)
    def move_lead(self,norm,zone):
        allowed={'dev','maint','pending','discard','pool'}
        zone=str(zone or '').strip().lower()
        if zone not in allowed: return {'ok':False,'error':'invalid zone'}
        lead=self.get_lead(norm)
        if not lead:return {'ok':False,'error':'lead not found'}
        self.lead_update(norm,zone=zone)
        return {'ok':True,'norm':norm,'zone':zone}

    def get_lead_detail(self,norm):
        lead=self.get_lead(norm)
        if not lead:return None
        dev=self.latest_development(norm)
        msgs=self.list_messages(norm,limit=200)
        rel=self.list_relationships(norm=norm,limit=300)
        ev=self.list_evidence_events(norm,limit=300)
        hard=bool(int(lead.get('shipments') or 0)>0 or lead.get('source','').find('customs')>=0 or lead.get('source','').find('importyeti')>=0 or rel)
        eligible=lead.get('zone')=='dev' and lead.get('zone')!='discard'
        return {'lead':lead,'eligible':bool(eligible),'evidence_strength':'strong' if hard else 'identity_only','development':dev,'messages':msgs,'relationships':rel,'evidence_events':ev}

    def begin_expansion(self,task_id,seed_norm):
        now=time.time(); self.lead_update(seed_norm,expansion_status='running',last_expansion=now)
        with self.c() as x:x.execute('INSERT OR REPLACE INTO expansion_jobs(task_id,seed_norm,status,started_at,finished_at,new_leads,note) VALUES(?,?,?,?,?,?,?)',(task_id,seed_norm,'running',now,None,0,''))
    def finish_expansion(self,task_id,status,new_leads=0,note=''):
        now=time.time()
        with self.c() as x:
            row=x.execute('SELECT seed_norm FROM expansion_jobs WHERE task_id=?',(task_id,)).fetchone()
            if row:
                seed=row[0]
                x.execute('UPDATE expansion_jobs SET status=?,finished_at=?,new_leads=?,note=? WHERE task_id=?',(status,now,int(new_leads or 0),str(note)[:500],task_id))
                x.execute("UPDATE leads SET expansion_status=?,expansion_count=COALESCE(expansion_count,0)+CASE WHEN ?='done' THEN 1 ELSE 0 END,last_expansion=? WHERE norm=?",(status,status,now,seed))
    def expansion_activity(self):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute("SELECT * FROM expansion_jobs WHERE status='running' ORDER BY started_at DESC LIMIT 100").fetchall()]

    def add_message(self,norm,direction,channel,content,draft=0):
        with self.c() as x: x.execute('INSERT INTO messages(lead_norm,direction,channel,content,draft,ts) VALUES(?,?,?,?,?,?)',(norm,direction,channel,content,int(draft),time.time()))
        self.lead_update(norm,last_touch=time.time())
    def get_message(self,mid):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM messages WHERE id=?',(int(mid),)).fetchone()
            return dict(r) if r else None
    def delete_message(self,mid):
        with self.c() as x: x.execute('DELETE FROM messages WHERE id=?',(int(mid),))
    def update_message(self,mid,content):
        with self.c() as x: x.execute('UPDATE messages SET content=? WHERE id=?',(str(content),int(mid)))
    def list_messages(self,norm,limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM messages WHERE lead_norm=? ORDER BY ts ASC LIMIT ?',(norm,int(limit))).fetchall()]
    def add_relationship(self,task_id,from_name,from_type,to_name,to_type,relation,evidence,source,confidence=0.0,depth=1):
        fn=self._norm(from_name); tn=self._norm(to_name)
        if not fn or not tn: return
        sql="INSERT OR IGNORE INTO relationships(task_id,from_norm,from_name,from_type,to_norm,to_name,to_type,relation,evidence,source,confidence,depth,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)"
        with self.c() as x:
            x.execute(sql,(task_id,fn,from_name,from_type,tn,to_name,to_type,relation,json.dumps(evidence or {},ensure_ascii=False),source,float(confidence or 0),int(depth or 1),time.time()))
    def list_relationships(self,task_id=None,norm=None,limit=500):
        sql='SELECT * FROM relationships WHERE 1=1'; args=[]
        if task_id: sql+=' AND task_id=?'; args.append(task_id)
        if norm: sql+=' AND (from_norm=? OR to_norm=?)'; args += [norm,norm]
        sql+=' ORDER BY confidence DESC,created_at DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]
    def add_evidence_event(self,task_id,norm,kind,source,content,weight=1.0):
        with self.c() as x:
            x.execute('INSERT INTO evidence_events(task_id,norm,kind,source,content,weight,created_at) VALUES(?,?,?,?,?,?,?)',(task_id,norm,kind,source,str(content or '')[:2000],float(weight or 0),time.time()))
    def save_raw_source(self,source,query,payload):
        with self.c() as x:
            x.execute('INSERT INTO raw_sources(source,query,payload,created_at) VALUES(?,?,?,?)',(str(source),str(query or ''),json.dumps(payload,ensure_ascii=False)[:50000],time.time()))
    def save_clean_batch(self,task_id,stage,stats):
        with self.c() as x:
            x.execute('INSERT INTO clean_batches(task_id,stage,raw_count,clean_count,noise_count,duplicate_count,identity_only_count,hard_evidence_count,noise_ratio,clean_ratio,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                (task_id,stage,int(stats.get('raw',0)),int(stats.get('clean',0)),int(stats.get('noise',0)),int(stats.get('duplicate',0)),int(stats.get('identity_only',0)),int(stats.get('hard_evidence',0)),float(stats.get('noise_ratio',0)),float(stats.get('clean_ratio',0)),time.time()))
    def add_expansion_run(self,task_id,depth,buyers_scanned,suppliers_scanned,new_customers,max_new):
        with self.c() as x:
            x.execute('INSERT INTO expansion_runs(task_id,depth,buyers_scanned,suppliers_scanned,new_customers,max_new,created_at) VALUES(?,?,?,?,?,?,?)',(task_id,int(depth),int(buyers_scanned),int(suppliers_scanned),int(new_customers),int(max_new),time.time()))
    def get_frontier(self,limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute("SELECT * FROM expansion_frontier WHERE status='pending' ORDER BY depth,updated_at LIMIT ?",(int(limit),)).fetchall()]
    def mark_frontier(self,norm,status,depth=None,task_id=None):
        with self.c() as x:
            x.execute('INSERT INTO expansion_frontier(norm,depth,source_task,status,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(norm) DO UPDATE SET depth=excluded.depth,source_task=excluded.source_task,status=excluded.status,updated_at=excluded.updated_at',(norm,int(depth or 0),task_id or '',status,time.time()))
    def get_task(self,tid):
        with self.c() as x: r=x.execute('SELECT request,status,result FROM tasks WHERE task_id=?',(tid,)).fetchone()
        return None if not r else {'request':r[0],'status':r[1],'result':json.loads(r[2] or '{}')}

    def list_evidence_events(self,norm,limit=200):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute("SELECT * FROM evidence_events WHERE norm=? ORDER BY created_at DESC LIMIT ?",(norm,int(limit))).fetchall()]
    def save_development(self,norm,result):
        now=time.time(); payload=json.dumps(result,ensure_ascii=False)
        with self.c() as x:
            row=x.execute("SELECT id FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1",(norm,)).fetchone()
            if row:x.execute("UPDATE development_runs SET status=?,result=?,updated_at=? WHERE id=?",('running',payload,now,row[0]))
            else:x.execute("INSERT INTO development_runs(lead_norm,status,result,created_at,updated_at) VALUES(?,?,?,?,?)",(norm,'running',payload,now,now))
    def finish_development(self,norm,result,status='done'):
        now=time.time(); payload=json.dumps(result,ensure_ascii=False)
        with self.c() as x:
            row=x.execute("SELECT id FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1",(norm,)).fetchone()
            if row:x.execute("UPDATE development_runs SET status=?,result=?,updated_at=? WHERE id=?",(status,payload,now,row[0]))
            else:x.execute("INSERT INTO development_runs(lead_norm,status,result,created_at,updated_at) VALUES(?,?,?,?,?)",(norm,status,payload,now,now))
            x.execute("UPDATE leads SET development_status=? WHERE norm=?",(status,norm))
    def latest_development(self,norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute("SELECT * FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1",(norm,)).fetchone()
            if not r:return None
            d=dict(r); d['result']=json.loads(d.get('result') or '{}'); return d
    def upsert_schedule(self,name,job_type,market,industry,quantity,interval_minutes,enabled=True,params=None,next_run=None):
        now=time.time(); interval=max(1,int(interval_minutes or 60)); nr=float(next_run if next_run is not None else now+interval*60)
        sql="""INSERT INTO schedules(name,job_type,market,industry,quantity,interval_minutes,enabled,next_run,last_run,last_status,params,created_at,updated_at,locked_until) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,0) ON CONFLICT(name) DO UPDATE SET job_type=excluded.job_type,market=excluded.market,industry=excluded.industry,quantity=excluded.quantity,interval_minutes=excluded.interval_minutes,enabled=excluded.enabled,next_run=excluded.next_run,params=excluded.params,updated_at=excluded.updated_at,locked_until=0"""
        with self.c() as x:x.execute(sql,(name,job_type,market,industry,int(quantity or 20),interval,int(bool(enabled)),nr,None,'idle',json.dumps(params or {},ensure_ascii=False),now,now))
    def list_schedules(self,enabled=None):
        sql='SELECT * FROM schedules';args=[]
        if enabled is not None:sql+=' WHERE enabled=?';args.append(int(bool(enabled)))
        sql+=' ORDER BY next_run ASC'
        with self.c() as x:
            x.row_factory=sqlite3.Row; rows=[dict(r) for r in x.execute(sql,args).fetchall()]
        for r in rows:r['params']=json.loads(r.get('params') or '{}')
        return rows
    def set_schedule_enabled(self,sid,enabled):
        now=time.time(); en=int(bool(enabled))
        with self.c() as x:
            row=x.execute('SELECT interval_minutes,next_run FROM schedules WHERE id=?',(int(sid),)).fetchone()
            if not row: return False
            interval=int(row[0] or 60)
            if en:
                # 启用后：若原计划已过期则立即进入下一轮，否则保持原计划时间。
                nr=float(row[1] or 0)
                if nr <= now: nr=now
                x.execute("UPDATE schedules SET enabled=1,next_run=?,last_status='enabled',updated_at=?,locked_until=0 WHERE id=?",(nr,now,int(sid)))
            else:
                x.execute("UPDATE schedules SET enabled=0,last_status='disabled',updated_at=?,locked_until=0 WHERE id=?",(now,int(sid)))
            return True

    def delete_schedule(self,sid):
        with self.c() as x:x.execute('DELETE FROM schedules WHERE id=?',(int(sid),))
    def claim_due_schedule(self,sid,lock_seconds=300):
        now=time.time(); until=now+max(10,int(lock_seconds))
        with self.c() as x:
            cur=x.execute("UPDATE schedules SET locked_until=?,last_status='running',updated_at=? WHERE id=? AND enabled=1 AND next_run<=? AND COALESCE(locked_until,0)<=?",(until,now,int(sid),now,now))
            return cur.rowcount==1
    def mark_schedule_run(self,sid,status,next_run=None):
        now=time.time()
        with self.c() as x:
            if next_run is None:
                row=x.execute('SELECT interval_minutes FROM schedules WHERE id=?',(int(sid),)).fetchone(); next_run=now+int(row[0] or 60)*60 if row else now+3600
            x.execute('UPDATE schedules SET last_run=?,last_status=?,next_run=?,updated_at=?,locked_until=0 WHERE id=?',(now,status,next_run,now,int(sid)))
    def save_development_blackboard(self,norm,result):
        now=time.time(); payload=json.dumps(result,ensure_ascii=False)
        with self.c() as x:
            row=x.execute("SELECT id FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1",(norm,)).fetchone()
            if row:x.execute("UPDATE development_runs SET status=?,result=?,updated_at=? WHERE id=?",('running',payload,now,row[0]))
            else:x.execute("INSERT INTO development_runs(lead_norm,status,result,created_at,updated_at) VALUES(?,?,?,?,?)",(norm,'running',payload,now,now))
    def save_development(self,norm,result):
        self.save_development_blackboard(norm,result)
    def finish_development(self,norm,result,status='done'):
        now=time.time(); payload=json.dumps(result,ensure_ascii=False)
        with self.c() as x:
            row=x.execute("SELECT id FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1",(norm,)).fetchone()
            if row:x.execute("UPDATE development_runs SET status=?,result=?,updated_at=? WHERE id=?",(status,payload,now,row[0]))
            else:x.execute("INSERT INTO development_runs(lead_norm,status,result,created_at,updated_at) VALUES(?,?,?,?,?)",(norm,status,payload,now,now))
            x.execute("UPDATE leads SET development_status=? WHERE norm=?",(status,norm))
    def latest_development(self,norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row; r=x.execute('SELECT * FROM development_runs WHERE lead_norm=? ORDER BY id DESC LIMIT 1',(norm,)).fetchone()
            if not r:return None
            d=dict(r); d['result']=json.loads(d.get('result') or '{}'); return d

    def get_setting(self,key,default=None):
        with self.c() as x:
            r=x.execute("SELECT value FROM app_settings WHERE key=?",(str(key),)).fetchone()
            return r[0] if r else default
    def set_setting(self,key,value):
        with self.c() as x:x.execute("INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",(str(key),str(value),time.time()))
