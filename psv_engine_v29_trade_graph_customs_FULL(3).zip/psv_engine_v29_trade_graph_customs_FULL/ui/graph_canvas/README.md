Graph UI node-edge layout specification.
