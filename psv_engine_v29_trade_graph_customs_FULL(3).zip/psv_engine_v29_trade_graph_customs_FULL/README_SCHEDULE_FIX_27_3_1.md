# v27.3.1 定时任务开关修复

本版本修复定时任务页面“启用”无法点击的问题。

## 根因

此前列表中的“启用/停用”只是 `<span>` 状态标签，没有任何点击事件，也没有对应的切换 API。创建任务时虽然数据库 `enabled=1`，但前端无法对既有任务执行启停。

## 修复

- 定时任务列表的“启用/停用”改为真正可点击按钮。
- 新增 `POST /api/schedules/{id}/toggle`。
- 新增 `DB.set_schedule_enabled()`。
- 启用时：如果原 `next_run` 已到期，下一轮立即可被 scheduler claim；未到期则保留原计划。
- 停用时：释放 scheduler lock，并记录 `disabled` 状态。
- 增加 `tests/test_schedule_toggle.py` 回归测试。

## 运行前检查

确保 `.env` 中 `SCHEDULER_ENABLED=true`，服务进程保持运行。创建/启用任务后，后台 scheduler 每 `SCHEDULER_POLL_SECONDS` 秒检查一次到期任务。
