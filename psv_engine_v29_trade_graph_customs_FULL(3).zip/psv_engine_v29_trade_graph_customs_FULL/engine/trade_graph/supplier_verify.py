def verify_supplier(record):
    return bool(record.get('customs_evidence'))
