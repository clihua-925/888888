def expand_trade_node(node):
    return {'parent': node, 'edges': [], 'status':'pending_customs_validation'}
