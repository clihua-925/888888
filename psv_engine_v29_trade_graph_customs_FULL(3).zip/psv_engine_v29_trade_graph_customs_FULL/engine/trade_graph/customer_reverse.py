def reverse_customers(supplier):
    return {'supplier':supplier,'buyers':[]}
