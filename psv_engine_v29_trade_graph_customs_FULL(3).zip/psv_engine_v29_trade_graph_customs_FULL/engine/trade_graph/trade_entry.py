class TradeEntryNode:
    def create(self, keyword, source='importyeti'):
        return {'node_type':'trade_entry','keyword':keyword,'source':source,'evidence_required':True}
