# PSV Engine v27.4.0 Production Final

Merged production build.

- Customs-first collection and customs graph expansion
- First-pass cleaning and quality gate
- Buyer -> supplier -> buyer reverse harvest
- Incremental customs graph and profile merge
- Existing leads are updated rather than duplicated
- Only genuinely new customers enter the development pool
- Schedule switch and recurring jobs
- Communication/development sequence UI with per-customer detail and send history
- Customer zones: development / maintenance / pending / discard / pool
- Network expansion on the selected customer
- SQLite list/dict binding normalization for final commit stability

Start with `start.bat` or `python run_webui.py`.
