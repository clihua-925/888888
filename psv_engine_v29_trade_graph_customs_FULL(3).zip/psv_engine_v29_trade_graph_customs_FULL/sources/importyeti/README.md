Tier-0 trade relationship entry source placeholder.
