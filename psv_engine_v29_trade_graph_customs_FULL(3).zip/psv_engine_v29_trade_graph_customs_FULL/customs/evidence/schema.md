Trade edges require shipment evidence, source, date, HS/product mapping and confidence.
