class CustomsEvidence:
    def __init__(self, source, shipment=None, hs=None, date=None):
        self.source=source
        self.shipment=shipment
        self.hs=hs
        self.date=date
