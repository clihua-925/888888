from core.webui.app import run
if __name__=='__main__': run()
