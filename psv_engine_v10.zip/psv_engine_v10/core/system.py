import json,threading,time,uuid,queue
from core.runtime.orchestrator import Orchestrator
from core.memory.db import DB

class PSVSystem:
    """单 worker 串行队列：同一时刻只跑一个任务。
    采集共享同一个桌面浏览器/CDP 会话和同一个 SQLite，并发跑会互相打架。
    v15.1.1: 任务ID全程统一（队列与编排同一个 tid，侧边栏一行一任务）；
    启动时收割上一进程留下的僵尸任务：running 标记中断，带参数的 queued 自动续跑。"""

    def __init__(self):
        self.orch=Orchestrator(); self.db=DB(); self.q=queue.Queue()
        self._reap()
        threading.Thread(target=self._worker,daemon=True).start()

    def _reap(self):
        """worker 只活在内存里：进程重启后库里的 running/queued 必然是僵尸。"""
        now=time.time(); resumed=0
        with self.db.c() as x:
            running=x.execute("SELECT task_id,result FROM tasks WHERE status='running'").fetchall()
            for tid,res in running:
                try: r=json.loads(res or '{}')
                except Exception: r={}
                r['error']='服务重启：任务被中断（可重新 RUN）'
                x.execute('UPDATE tasks SET status=?,result=?,updated_at=? WHERE task_id=?',
                          ('failed',json.dumps(r,ensure_ascii=False),now,tid))
                print('[queue] reaped interrupted task',tid)
            queued=x.execute("SELECT task_id,request,result FROM tasks WHERE status='queued' ORDER BY created_at").fetchall()
        for tid,req,res in queued:
            try: p=json.loads(res or '{}').get('params') or {}
            except Exception: p={}
            if p.get('industry'):
                self.q.put((tid,req,p.get('market') or 'USA',p['industry'],p.get('quantity') or 20)); resumed+=1
                print('[queue] resumed queued task',tid)
            else:
                with self.db.c() as x:
                    x.execute("UPDATE tasks SET status='failed',result=?,updated_at=? WHERE task_id=?",
                              (json.dumps({'error':'服务重启：排队任务已清理（请重新 RUN）'},ensure_ascii=False),now,tid))
                print('[queue] dropped legacy queued task',tid)
        if resumed: print('[queue]',resumed,'queued task(s) will run now')

    def _worker(self):
        while True:
            tid,request,market,industry,quantity=self.q.get()
            try:
                self.orch.run(request,market,industry,int(quantity or 20),task_id=tid)
            except Exception as e:
                self.db.save_task(tid,request,'error',{'error':str(e)[:300]})

    def start(self,request,market,industry,quantity):
        tid=uuid.uuid4().hex[:8]
        self.db.save_task(tid,request,'queued',{'params':{'market':market,'industry':industry,'quantity':int(quantity or 20)}})
        self.q.put((tid,request,market,industry,quantity)); return tid

    def get(self,tid): return self.db.get_task(tid)
