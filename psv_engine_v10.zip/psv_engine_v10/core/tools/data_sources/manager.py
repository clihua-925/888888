# -*- coding: utf-8 -*-
"""数据源管理器：稳定版，强过滤搜索引擎结果"""
import re, json, time
from pathlib import Path
import requests
from bs4 import BeautifulSoup
from core.config import settings

NOISE = re.compile(r'freight|forwarder|logistics|cargo|shipping|customs broker|packaging|consulting|翻译|词典|物流|货代', re.I)

def norm(s):
    if not s: return ''
    s = s.lower().strip()
    s = re.sub(r'\b(inc|llc|co|ltd|corp|corporation|company|gmbh|sarl)\b', '', s)
    s = re.sub(r'[^a-z0-9]+', ' ', s)
    return ' '.join(s.split())

def noise(name):
    return bool(NOISE.search(name or ''))

def gate_check(companies):
    return {'ok': True, 'raw': len(companies), 'qualified': len(companies), 'strong': len(companies), 'rejects': []}

def _is_garbage_result(name, link):
    name_lower = (name or '').lower()
    link_lower = (link or '').lower()
    garbage_domains = [
        'baidu.com', 'zhihu.com', 'csdn.net', 'github.com', 'wikipedia.org',
        'youtube.com', 'facebook.com', 'linkedin.com', 'amazon.com', 'ebay.com',
        'alibaba.com', 'made-in-china.com', 'globalsources.com', 'tradekey.com',
        'ec21.com', 'dhgate.com', 'aliexpress.com', 'dictionary.com', 'cambridge.org',
        'merriam-webster.com', 'thefreedictionary.com', 'wordreference.com',
        'collinsdictionary.com', 'ldoceonline.com', 'oxfordlearnersdictionaries.com',
        'moegirl.org', 'fandom.com', 'quora.com', 'reddit.com', 'pinterest.com',
        'instagram.com', 'twitter.com', 'tiktok.com', 'yandex.ru'
    ]
    for domain in garbage_domains:
        if domain in link_lower:
            return True
    garbage_keywords = [
        '词典', '翻译', '百科', '百度', '知乎', 'csdn', 'github', 'wikipedia',
        'dictionary', 'translate', 'meaning', 'usage', 'example', 'cambridge',
        'oxford', 'collins', 'merriam', 'wordreference'
    ]
    for kw in garbage_keywords:
        if kw in name_lower:
            return True
    # 如果名称看起来像公司名（含常见后缀）则保留，否则可能为文章标题
    company_suffix = [' inc', ' llc', ' ltd', ' corp', ' co', ' company', ' gmbh', ' sa', ' ag', ' group', ' international', ' trading', ' import', ' export', ' wholesale', ' distribution', ' manufacturing', ' industries', ' enterprises']
    if not any(suffix in name_lower for suffix in company_suffix):
        # 没有公司后缀，但可能名称较短且无空格？提高门槛
        if len(name_lower) > 40 or ' ' not in name_lower:
            return True
    return False

class Evolution:
    def __init__(self):
        self.variants = []
    def plan(self, market, industry):
        return {'variants': [industry, f'{industry} importer', f'{industry} buyer', f'{industry} wholesale']}

class BingSearch:
    def __init__(self, enabled=None):
        self.name = "bing"
        self.enabled = settings.BING_ENABLED if enabled is None else enabled

    def search(self, query, market='USA', limit=20):
        if not self.enabled:
            return [], f"{self.name}_disabled", None
        results = []
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            url = f"https://www.bing.com/search?q={requests.utils.quote(query)}&count={limit}"
            resp = requests.get(url, headers=headers, timeout=15)
            soup = BeautifulSoup(resp.text, 'html.parser')
            for li in soup.select('li.b_algo')[:limit]:
                a = li.select_one('h2 a')
                if not a:
                    continue
                title = a.get_text(strip=True)
                link = a.get('href')
                snippet = li.select_one('.b_caption p')
                desc = snippet.get_text(strip=True) if snippet else ''
                name = title.split('|')[0].strip()
                if not name or len(name) < 2:
                    continue
                if _is_garbage_result(name, link):
                    continue
                results.append({
                    'name': name,
                    'country': market,
                    'industry': '',
                    'type': 'importer',
                    'website': link or '',
                    'source': 'bing',
                    'strength': 3,
                    'evidence': {'url': link, 'description': desc}
                })
            return results, self.name, None
        except Exception as e:
            return [], self.name, str(e)[:120]

class DuckDuckGoSearch:
    def __init__(self, enabled=None):
        self.name = "duckduckgo"
        self.enabled = settings.DDG_ENABLED if enabled is None else enabled

    def search(self, query, market='USA', limit=20):
        if not self.enabled:
            return [], f"{self.name}_disabled", None
        results = []
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            url = "https://html.duckduckgo.com/html/"
            resp = requests.post(url, data={'q': query}, headers=headers, timeout=15)
            soup = BeautifulSoup(resp.text, 'html.parser')
            for res in soup.select('.result')[:limit]:
                a = res.select_one('.result__a')
                if not a:
                    continue
                title = a.get_text(strip=True)
                link = a.get('href')
                snippet = res.select_one('.result__snippet')
                desc = snippet.get_text(strip=True) if snippet else ''
                name = title.split('|')[0].strip()
                if not name or len(name) < 2:
                    continue
                if _is_garbage_result(name, link):
                    continue
                results.append({
                    'name': name,
                    'country': market,
                    'industry': '',
                    'type': 'importer',
                    'website': link or '',
                    'source': 'duckduckgo',
                    'strength': 3,
                    'evidence': {'url': link, 'description': desc}
                })
            return results, self.name, None
        except Exception as e:
            return [], self.name, str(e)[:120]

class DataSourceManager:
    def __init__(self):
        self.last_evolution = None

    def search(self, market, industry, quantity, variants_override=None, source_queries=None):
        companies = []
        used = []
        errors = []
        queries = variants_override or [industry]

        if settings.BING_ENABLED:
            bing_queries = source_queries.get('bing') if source_queries else queries[:3]
            for q in bing_queries[:3]:
                try:
                    bing = BingSearch()
                    bing_companies, _, err = bing.search(q, market, quantity)
                    if bing_companies:
                        companies.extend(bing_companies)
                        used.append('bing')
                except Exception as e:
                    errors.append('bing: ' + str(e)[:60])

        if settings.DDG_ENABLED:
            ddg_queries = source_queries.get('duckduckgo') if source_queries else queries[:2]
            for q in ddg_queries[:2]:
                try:
                    ddg = DuckDuckGoSearch()
                    ddg_companies, _, err = ddg.search(q, market, quantity)
                    if ddg_companies:
                        companies.extend(ddg_companies)
                        used.append('duckduckgo')
                except Exception as e:
                    errors.append('duckduckgo: ' + str(e)[:60])

        seen = set()
        unique = []
        for c in companies:
            n = norm(c.get('name'))
            if n and n not in seen:
                seen.add(n)
                unique.append(c)
        return unique, used, errors, {'ok': True, 'raw': len(unique), 'qualified': len(unique), 'strong': len(unique)}
