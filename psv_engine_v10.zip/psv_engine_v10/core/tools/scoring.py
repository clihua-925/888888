# -*- coding: utf-8 -*-
"""v16.1: 客户评分（确定性公式，LLM 离线也可算）。
评分维度：提单量(40) + 品类信号(20) + 榜单标签(15) + 联系方式完整度(15) + 美国本土(5) + 最近活跃度(5)。
等级：>=75 A（优先开发），>=55 B，其余 C。写回 leads.score / leads.grade。"""
import math,time

def score_lead(lead):
    s=0.0; why=[]
    ship=int(lead.get('shipments') or 0)
    if ship>0:
        pts=min(40.0, math.log10(ship+1)/math.log10(2000)*40)  # 2000提单≈满分40
        s+=pts; why.append('提单%d(+%.0f)'%(ship,pts))
    seg=lead.get('segment') or ''
    if seg=='birthday': s+=20; why.append('生日蜡烛信号(+20)')
    elif seg=='candle': s+=10; why.append('蜡烛品类(+10)')
    tags=str(lead.get('tags') or '')
    tp=0
    if 'Top' in tags: tp+=10
    if 'New' in tags: tp+=5
    if 'Fast Growing' in tags or 'FG' in tags: tp+=5
    tp=min(15,tp)
    if tp: s+=tp; why.append('榜单标签(+%d)'%tp)
    if lead.get('emails'): s+=10; why.append('有邮箱(+10)')
    if lead.get('website'): s+=5; why.append('有官网(+5)')
    if (lead.get('country') or '').upper()=='US': s+=5; why.append('美国(+5)')
    ls=lead.get('last_shipment') or ''
    if ls:
        try:
            y=int(str(ls)[-4:])
            if y>=time.localtime().tm_year-1: s+=5; why.append('近期活跃(+5)')
        except Exception: pass
    s=round(min(100.0,s),1)
    grade='A' if s>=75 else ('B' if s>=55 else 'C')
    return s,grade,'; '.join(why)

def rescore_all():
    """全库重算评分（联系方式补全后调用）。"""
    from core.memory.db import DB
    db=DB(); n=0
    for l in db.list_leads(limit=5000):
        s,g,_=score_lead(l)
        db.lead_update(l['norm'],score=s,grade=g); n+=1
    return n

if __name__=='__main__':
    print(rescore_all(),'leads rescored')
