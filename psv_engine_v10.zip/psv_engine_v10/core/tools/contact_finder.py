# -*- coding: utf-8 -*-
"""联系方式提取：正则优先 + 本地模型辅助 + 网页 AI 兜底，质量优先"""
import re, time, json, os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from core.config import settings
from core.memory.db import DB

PROGRESS = None
LAST = {}

def _prog(msg):
    try:
        if PROGRESS: PROGRESS(msg)
    except Exception:
        pass

class ContactFinder:
    def __init__(self):
        self.db = DB()
        self.web = None

    def _launch(self):
        try:
            from core.tools import web_ai
            self.web = web_ai.WebAI()
            self.web._launch()
        except Exception as e:
            self.web = None
            raise Exception('网页AI未就绪: ' + str(e)[:80])

    def close(self):
        if self.web:
            try: self.web.close()
            except Exception: pass
        self.web = None

    def _extract_from_html(self, html):
        if not html:
            return {}
        emails = re.findall(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', html)
        phones = re.findall(r'(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}', html)
        websites = re.findall(r'https?://[A-Za-z0-9./_-]+', html)
        addresses = re.findall(r'\d{1,6}\s+[A-Za-z0-9][\w .#-]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Parkway|Pkwy)[\w .,#-]*', html)
        out = {}
        if websites:
            out['website'] = websites[0].strip('.,;')
        if emails:
            out['emails'] = list(dict.fromkeys(emails[:5]))
        if phones:
            out['phones'] = list(dict.fromkeys(phones[:2]))
        if addresses:
            out['address'] = addresses[0].strip()
        return out

    def _search_website_by_company(self, name, country='USA'):
        try:
            import requests
            from bs4 import BeautifulSoup
            query = f"{name} official website"
            headers = {'User-Agent': 'Mozilla/5.0'}
            url = f"https://www.bing.com/search?q={requests.utils.quote(query)}"
            resp = requests.get(url, headers=headers, timeout=15)
            soup = BeautifulSoup(resp.text, 'html.parser')
            first = soup.select_one('li.b_algo h2 a')
            if first:
                link = first.get('href')
                if link and 'http' in link:
                    return link
        except Exception:
            pass
        return None

    def _extract_json_from_text(self, txt):
        """从文本中提取 JSON 对象，优先尝试标准 JSON"""
        try:
            start = txt.find('{')
            end = txt.rfind('}')
            if start != -1 and end != -1:
                return json.loads(txt[start:end+1])
        except Exception:
            pass
        return None

    def _enrich_with_local_model(self, lead, html):
        try:
            from core.model.client import ModelClient
            prompt = f"从以下公司官网HTML中提取联系方式（官网、邮箱、电话、地址），只输出JSON：\n公司: {lead.get('name')}\nHTML前5000字符: {html[:5000]}"
            txt = ModelClient().chat(prompt, temperature=0.1, max_tokens=300, timeout=120)
            if txt:
                j = self._extract_json_from_text(txt)
                if j:
                    return {k: v for k, v in j.items() if k in ('website','emails','phones','address')}
        except Exception:
            pass
        return {}

    def _enrich_with_webai(self, lead):
        if not self.web:
            return {}
        try:
            name = lead.get('name') or ''
            prompt = (f'请提供 "{name}" 这家公司的详细公开联系信息。\n'
                      '只返回一个JSON对象，格式如下：\n'
                      '{"website":"官网URL","emails":["邮箱1","邮箱2"],"phones":["电话1"],"address":"地址"}\n'
                      '如果某个字段不知道，就省略该字段。不要输出任何多余文字。')
            txt = self.web.ask(prompt)
            if txt:
                j = self._extract_json_from_text(txt)
                if j:
                    return j
                # 回退到正则提取
                return self._extract_from_text(txt)
        except Exception:
            pass
        return {}

    def _extract_from_text(self, txt):
        emails = re.findall(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', txt)
        websites = re.findall(r'https?://[A-Za-z0-9./_-]+|www\.[A-Za-z0-9.-]+\.[A-Za-z]{2,}', txt)
        phones = re.findall(r'(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}', txt)
        addresses = re.findall(r'\d{1,6}\s+[A-Za-z0-9][\w .#-]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Parkway|Pkwy)[\w .,#-]*', txt)
        out = {}
        if websites:
            out['website'] = websites[0].strip('.,;')
        if emails:
            out['emails'] = list(dict.fromkeys(emails[:5]))
        if phones:
            out['phones'] = list(dict.fromkeys(phones[:2]))
        if addresses:
            out['address'] = addresses[0].strip()
        return out

    def enrich(self, lead, do_audit=False):
        norm = lead.get('norm')
        _prog(f'补全 {lead.get("name")}')
        if lead.get('website') and lead.get('emails'):
            return {'ok': True, 'complete': True}
        # 1. 从已有官网 HTML 提取
        if lead.get('website'):
            try:
                import requests
                resp = requests.get(lead['website'], headers={'User-Agent': 'Mozilla/5.0'}, timeout=15)
                extracted = self._extract_from_html(resp.text)
                if extracted:
                    update = {k: v for k, v in extracted.items() if not lead.get(k)}
                    if update:
                        if isinstance(update.get('emails'), list):
                            update['emails'] = ','.join(update['emails'])
                        if isinstance(update.get('phones'), list):
                            update['phones'] = ','.join(update['phones'])
                        self.db.lead_update(norm, **update)
                        lead = self.db.get_lead(norm) or lead
            except Exception:
                pass
        # 2. 本地模型提取
        if not (lead.get('emails') and lead.get('phones')):
            if lead.get('website'):
                try:
                    import requests
                    html = requests.get(lead['website'], headers={'User-Agent': 'Mozilla/5.0'}, timeout=15).text
                    extracted = self._enrich_with_local_model(lead, html)
                    if extracted:
                        update = {k: v for k, v in extracted.items() if not lead.get(k)}
                        if update:
                            if isinstance(update.get('emails'), list):
                                update['emails'] = ','.join(update['emails'])
                            if isinstance(update.get('phones'), list):
                                update['phones'] = ','.join(update['phones'])
                            self.db.lead_update(norm, **update)
                            lead = self.db.get_lead(norm) or lead
                except Exception:
                    pass
        # 3. 网页AI 兜底
        if not lead.get('emails'):
            if self.web:
                info = self._enrich_with_webai(lead)
                if info:
                    update = {k: v for k, v in info.items() if not lead.get(k)}
                    if update:
                        if isinstance(update.get('emails'), list):
                            update['emails'] = ','.join(update['emails'])
                        if isinstance(update.get('phones'), list):
                            update['phones'] = ','.join(update['phones'])
                        self.db.lead_update(norm, **update)
                        lead = self.db.get_lead(norm) or lead
        # 4. 搜索官网
        if not lead.get('website'):
            website = self._search_website_by_company(lead.get('name'), lead.get('country'))
            if website:
                self.db.lead_update(norm, website=website)
                lead = self.db.get_lead(norm) or lead
                return self.enrich(lead)
        ok = bool(lead.get('website') or lead.get('emails'))
        complete = bool(lead.get('website') and lead.get('emails') and lead.get('phones'))
        return {'ok': ok, 'complete': complete}

    def enrich_one(self, norm):
        lead = self.db.get_lead(norm)
        if not lead:
            return {'ok': False, 'missing': '客户不存在'}
        return self.enrich(lead)

    def run(self, limit=15):
        leads = self.db.list_leads(kind='importer', limit=limit)
        results = []
        for lead in leads:
            if not lead.get('website') or not lead.get('emails'):
                r = self.enrich(lead)
                results.append(r)
        return results