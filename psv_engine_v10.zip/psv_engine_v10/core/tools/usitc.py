# -*- coding: utf-8 -*-
"""USITC 宏观情报节点：给开发信提供权威市场弹药。
三级降级：① data/usitc_notes.txt 手工情报（永远生效，推荐）② USITC_TOKEN API 尝试（实验性）③ 跳过不阻塞。"""
import json,sqlite3,time,urllib.request
from pathlib import Path
from core.config import settings
def _from_file():
    p=Path(settings.USITC_NOTES_FILE)
    if p.exists():
        try:
            raw=p.read_bytes()
            for enc in ('utf-8-sig','gb18030','utf-16'):
                try: t=raw.decode(enc); break
                except Exception: continue
            else: t=raw.decode('utf-8','ignore')
            t=t.replace('\x00','').strip()
            if t: return t
        except Exception: pass
    return ''
def _cached():
    try:
        conn=sqlite3.connect(settings.DATABASE_PATH)
        r=conn.execute('SELECT payload,created_at FROM usitc_cache WHERE hs=? ORDER BY id DESC LIMIT 1',(settings.USITC_HS_CODE,)).fetchone()
        conn.close()
        if r and time.time()-r[1]<7*86400: return r[0]
    except Exception: pass
    return ''
def _from_api():
    """实验性：USITC DataWeb API（需在 dataweb.usitc.gov 免费注册拿 token）。任何异常都降级。"""
    if not settings.USITC_TOKEN: return ''
    cached=_cached()
    if cached: return cached
    payload={'dataType':'IMPORTS','dataSource':'GEN','timePeriod':'ANNUAL','years':['2024','2025'],
             'htsCodes':[settings.USITC_HS_CODE],'countries':['World','China'],'tradeDirection':'IMPORTS'}
    req=urllib.request.Request(settings.USITC_API_URL,data=json.dumps(payload).encode(),
        headers={'Content-Type':'application/json','Authorization':'Bearer '+settings.USITC_TOKEN})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=30) as r:
        d=json.loads(r.read().decode('utf-8','ignore'))
    txt=json.dumps(d,ensure_ascii=False)
    if len(txt)>20:
        with sqlite3.connect(settings.DATABASE_PATH) as c:
            c.execute('INSERT INTO usitc_cache(hs,kind,payload,created_at) VALUES(?,?,?,?)',(settings.USITC_HS_CODE,'api',txt,time.time()))
        return txt
    return ''
def intel():
    """返回 {'ok':bool,'source':'file|api|none','text':str}。永不抛异常。"""
    try:
        t=_from_api()
        if t: return {'ok':True,'source':'api','text':t[:2000]}
    except Exception: pass
    t=_from_file()
    if t: return {'ok':True,'source':'file','text':t[:2000]}
    return {'ok':False,'source':'none','text':''}
