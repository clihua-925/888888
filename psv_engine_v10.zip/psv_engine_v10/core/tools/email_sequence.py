# -*- coding: utf-8 -*-
"""阶段二：开发信序列执行器（按品类隔离，质量优先）"""
import time, json
from core.config import settings
from core.memory.db import DB
from core.tools import pitch

def run_sequence(zone='dev', max_customers=20, progress_cb=None):
    """执行开发信序列：从客户库筛选，生成草稿并保存"""
    db = DB()
    leads = db.list_leads(zone=zone, kind='importer', limit=max_customers)
    if progress_cb: progress_cb(f'筛选到 {len(leads)} 家待开发客户')

    for lead in leads:
        name = lead.get('name') or lead['norm']
        if progress_cb: progress_cb(f'正在为 {name} 生成开发信...')

        # 检查是否已发送过该阶段
        msgs = db.list_messages(lead['norm'])
        if any(m.get('direction')=='out' and not m.get('draft') for m in msgs):
            continue

        # 生成开发信
        try:
            from core.model.client import ModelClient
            prompt = pitch.letter_prompt(lead)
            txt = ModelClient().chat(prompt, temperature=0.6, max_tokens=1200, timeout=300)
            if txt:
                db.add_message(lead['norm'], 'out', 'email', txt, draft=1)
                if progress_cb: progress_cb(f'已生成 {name} 的开发信草稿')
            else:
                if progress_cb: progress_cb(f'{name} 开发信生成失败')
        except Exception as e:
            if progress_cb: progress_cb(f'{name} 处理异常: {str(e)[:80]}')

        time.sleep(0.5)  # 避免过快

    if progress_cb: progress_cb('开发信序列完成')