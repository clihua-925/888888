# -*- coding: utf-8 -*-
"""v17: 关系网络循环扩张。
原理：每个买家有它的供应商，每个供应商有它的客户——沿着 ImportYeti 关系图逐层外扩：
  客户库 TopN 进口商 → 公司主页 Suppliers 区 → 新同行工厂入池
                     → 每家工厂 Customers 区 → 新买家进客户库（带来源链 via=expand:买家名）
去重闸门：leads 表 norm 去重 + suppliers.harvested_at 收割标记，跑多少次都不会重复劳动。
预算控制：EXPAND_BUYERS（每轮最多透视几家买家）、EXPAND_CUSTOMERS（每家工厂最多翻几个客户）、
EXPAND_MAX_NEW（每轮最多新增多少条线索，到量即停）。"""
import re,time
from core.config import settings

def _slug(name):
    return re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',str(name or '').lower())).strip('-')

def run(limit_buyers=None,customers_per=None,max_new=None):
    from core.memory.db import DB
    from core.tools import suppliers as sup
    from core.tools import iy_web
    db=DB()
    limit_buyers=int(limit_buyers or settings.EXPAND_BUYERS)
    customers_per=int(customers_per or settings.EXPAND_CUSTOMERS)
    max_new=int(max_new or settings.EXPAND_MAX_NEW)
    # 按评分选种子买家：开发区优先，然后线索池高分
    seeds=[l for l in db.list_leads(kind='importer',limit=200) if l.get('kind')=='importer']
    seeds.sort(key=lambda l:((l.get('zone')=='dev')*2+(l.get('zone')=='maint'),l.get('score') or 0),reverse=True)
    seeds=seeds[:limit_buyers]
    print('[expand] 种子买家 %d 家: %s'%(len(seeds),'、'.join(l['name'] for l in seeds)))
    if not seeds: return {'buyers':0,'new_leads':0}
    stats={'buyers':0,'suppliers':0,'new_leads':0,'errors':[]}
    have={l['norm'] for l in db.list_leads(limit=10000)}
    done_sups={r[0] for r in __import__('sqlite3').connect(settings.DATABASE_PATH)
               .execute('SELECT supplier_norm FROM suppliers WHERE harvested_at IS NOT NULL')} if True else set()
    with iy_web.IYWeb() as w:
        if not w.ok:
            print('[expand] 浏览器未就绪'); return stats
        for lead in seeds:
            if stats['new_leads']>=max_new: break
            url='https://www.importyeti.com/company/'+_slug(lead['name'])
            try:
                rows=w.relationships(url,'Suppliers')
            except Exception as e:
                stats['errors'].append('%s: %s'%(lead['name'],str(e)[:60])); continue
            if not rows:
                print('[expand] %s 透视不到供应商（slug猜错或无数据）'%lead['name']); continue
            stats['buyers']+=1
            newsups=[r for r in rows if DB._norm(r['name']) not in done_sups]
            print('[expand] %s -> %d 供应商（%d 新）'%(lead['name'],len(rows),len(newsups)))
            sup.upsert_pool([{'norm':DB._norm(r['name']),'name':r['name'],'slug':_slug(r['name']),
                              'shipments':r.get('shipments') or 0,'last_seen':time.time(),'via':'expand:'+lead['name']} for r in rows])
            for r in sorted(newsups,key=lambda x:-(x.get('shipments') or 0))[:3]:  # 每家买家最多深挖3家新工厂
                if stats['new_leads']>=max_new: break
                sn=DB._norm(r['name'])
                surl='https://www.importyeti.com/supplier/'+_slug(r['name'])
                try:
                    custs=w.relationships(surl,'Customers')[:customers_per]
                except Exception as e:
                    stats['errors'].append('%s: %s'%(r['name'],str(e)[:60])); continue
                added=[]
                for c in custs:
                    cn=DB._norm(c['name'])
                    if not cn or cn in have: continue
                    have.add(cn)
                    added.append({'name':c['name'],'country':'US','kind':'importer','shipments':c.get('shipments') or 0,
                                  'segment':'candle' if re.search(r'candle|wax',c.get('products') or '',re.I) else '',
                                  'desc_sample':(c.get('products') or '')[:300],'source':'expand:'+lead['name']})
                if added: db.upsert_leads(added)
                stats['suppliers']+=1; stats['new_leads']+=len(added)
                sup.upsert_pool([{'norm':sn,'name':r['name'],'slug':_slug(r['name']),
                                  'shipments':r.get('shipments') or 0,'last_seen':time.time()}])
                sup.mark_harvested(sn,len(custs))
                sup.log_harvest('expand',_slug(r['name']),r['name'],'expand','ok',len(custs),'新增买家%d'%len(added))
                print('[expand]   工厂 %s -> 客户 %d（新增 %d）'%(r['name'],len(custs),len(added)))
    print('[expand] done: 透视%d买家·挖%d工厂·新增线索%d'%(stats['buyers'],stats['suppliers'],stats['new_leads']))
    return stats

if __name__=='__main__':
    run()
