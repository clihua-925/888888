# -*- coding: utf-8 -*-
"""v18.0 邮件发送双通道：compose 半自动 + smtp 直发。
支持抄送多个邮箱。"""
import urllib.parse
from core.config import settings

COMPOSE={
 'gmail':'https://mail.google.com/mail/?view=cm&fs=1&to={to}&su={su}&body={body}&cc={cc}',
 'outlook':'https://outlook.live.com/mail/0/deeplink/compose?to={to}&subject={su}&body={body}&cc={cc}',
}

def compose_url(to,subject,body,cc_list=None,provider=None):
    tpl=COMPOSE.get(str(provider or getattr(settings,'MAIL_PROVIDER','outlook') or 'outlook').lower(),COMPOSE['outlook'])
    q=lambda s: urllib.parse.quote(str(s or ''),safe='')
    cc=','.join(cc_list) if cc_list else ''
    return tpl.format(to=q(to),su=q(subject),body=q(body),cc=q(cc))

def open_compose(to,subject,body,cc_list=None,provider=None):
    """在AI控制浏览器里新开一页，打开预填好的写信页。"""
    from core.tools.contact_finder import _cdp_alive
    if not _cdp_alive(settings.IY_WEB_CDP_URL):
        raise RuntimeError('AI浏览器(9222)未启动——先双击 start_chrome_debug.bat')
    from playwright.sync_api import sync_playwright
    pw=sync_playwright().start()
    try:
        br=pw.chromium.connect_over_cdp(settings.IY_WEB_CDP_URL)
        ctx=br.contexts[0]
        pg=ctx.new_page()
        pg.goto(compose_url(to,subject,body,cc_list,provider),timeout=60000,wait_until='domcontentloaded')
    finally:
        try: pw.stop()
        except Exception: pass

def smtp_configured():
    return bool(getattr(settings,'SMTP_HOST','') and getattr(settings,'SMTP_USER','') and getattr(settings,'SMTP_PASS',''))

def smtp_send(to,subject,body,cc_list=None):
    """SMTP直发，支持抄送。"""
    import smtplib
    from email.mime.text import MIMEText
    from email.header import Header
    if not smtp_configured():
        raise RuntimeError('未配置SMTP：.env 里加 SMTP_HOST / SMTP_USER / SMTP_PASS(授权码)')
    msg=MIMEText(str(body),'plain','utf-8')
    msg['Subject']=Header(str(subject),'utf-8')
    msg['From']=getattr(settings,'SMTP_FROM','') or settings.SMTP_USER
    msg['To']=to
    if cc_list:
        msg['Cc']=','.join(cc_list)
    port=int(getattr(settings,'SMTP_PORT',587))
    last_err=None
    try:
        if port==465:
            s=smtplib.SMTP_SSL(settings.SMTP_HOST,port,timeout=25)
        else:
            s=smtplib.SMTP(settings.SMTP_HOST,port,timeout=25)
            s.starttls()
        s.login(settings.SMTP_USER,settings.SMTP_PASS)
        s.sendmail(msg['From'],[to]+(cc_list or []),msg.as_string())
        s.quit()
        return
    except Exception as e:
        last_err=e
        print('[mailer] SMTP失败:',str(e)[:100])
    raise RuntimeError('SMTP发送失败：%s'%str(last_err)[:120])
