# -*- coding: utf-8 -*-
"""Apify 官方 REST 客户端：异步跑 actor → 轮询 → 拉数据集 → 扁平化为 CSV 落进 data/customs。
按结果付费，0 结果 = $0。只走 Apify 云端，零直接抓取。"""
import csv,json,time,urllib.request,urllib.parse
from pathlib import Path
from core.config import settings
BASE='https://api.apify.com/v2'
def _opener():
    px=settings.SCRAPE_PROXY_URL or ''
    return urllib.request.build_opener(urllib.request.ProxyHandler({'http':px,'https':px} if px else {}))
def _req(method,url,payload=None,timeout=60):
    data=json.dumps(payload).encode() if payload is not None else None
    r=urllib.request.Request(url,data=data,method=method,headers={'Content-Type':'application/json'})
    with _opener().open(r,timeout=timeout) as resp:
        body=resp.read().decode('utf-8','ignore')
        return json.loads(body) if body.strip() else {}
def _tok(url): return url+('&' if '?' in url else '?')+'token='+urllib.parse.quote(settings.APIFY_TOKEN)
def start_run(actor,input_json):
    d=_req('POST',_tok(f'{BASE}/acts/{actor}/runs'),payload=input_json,timeout=60)
    info=d.get('data') or {}
    if not info.get('id'): raise RuntimeError('Apify 启动失败: '+json.dumps(d,ensure_ascii=False)[:160])
    return info
def wait_run(run_id):
    t0=time.time()
    while time.time()-t0<settings.APIFY_RUN_TIMEOUT:
        d=_req('GET',_tok(f'{BASE}/actor-runs/{run_id}'),timeout=30)
        st=(d.get('data') or {}).get('status')
        if st=='SUCCEEDED': return d.get('data') or {}
        if st in ('FAILED','ABORTED','TIMED-OUT'): raise RuntimeError(f'Apify 运行{st}')
        time.sleep(8)
    raise RuntimeError('Apify 运行超时')
def dataset_items(dataset_id,limit=1000):
    d=_req('GET',_tok(f'{BASE}/datasets/{dataset_id}/items')+f'&limit={limit}&clean=true',timeout=120)
    return d if isinstance(d,list) else []
def flatten(obj,prefix=''):
    """嵌套 JSON → Apify CSV 导出同款斜杠路径（hs_codes/0/hs_code），与 customs_clean.MAP 对齐"""
    out={}
    if isinstance(obj,dict):
        for k,v in obj.items(): out.update(flatten(v,f'{prefix}/{k}' if prefix else str(k)))
    elif isinstance(obj,list):
        for i,v in enumerate(obj): out.update(flatten(v,f'{prefix}/{i}'))
    else:
        out[prefix]=obj
    return out
def save_csv(items,fp):
    rows=[flatten(x) for x in items]
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with open(fp,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader()
        for r in rows: w.writerow(r)
def company_input(slug):
    tpl=settings.APIFY_COMPANY_INPUT
    try:
        return json.loads(tpl.replace('{slug}',slug))
    except Exception:
        return {'mode':'companySearch','companySlug':slug,'maxResults':50}
def harvest_company(slug):
    """对一个公司 slug 跑 companySearch，CSV 落盘 data/customs。返回 (条数, CSV文件名)"""
    if not settings.APIFY_TOKEN: raise RuntimeError('未配置 APIFY_TOKEN')
    info=start_run(settings.APIFY_ACTOR,company_input(slug))
    fin=wait_run(info['id'])
    ds=fin.get('defaultDatasetId') or info.get('defaultDatasetId')
    if not ds: raise RuntimeError('Apify 未返回数据集ID')
    items=dataset_items(ds)
    fp=Path(settings.CUSTOMS_DIR)/f'apify_company_{slug}_{int(time.time())}.csv'
    if items: save_csv(items,fp)
    return len(items),fp.name if items else ''
