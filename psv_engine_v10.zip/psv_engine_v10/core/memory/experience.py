# -*- coding: utf-8 -*-
"""经验库模块"""
import sqlite3, time, json
from core.config import settings

SQL_EXPERIENCE = '''CREATE TABLE IF NOT EXISTS experience(
id INTEGER PRIMARY KEY AUTOINCREMENT,
type TEXT NOT NULL,
key TEXT,
value TEXT,
score REAL DEFAULT 0,
count INTEGER DEFAULT 0,
updated_at REAL
)'''

SQL_RULES = '''CREATE TABLE IF NOT EXISTS runtime_rules(
id INTEGER PRIMARY KEY AUTOINCREMENT,
rule_type TEXT,
rule_key TEXT,
rule_value TEXT,
enabled INTEGER DEFAULT 1,
updated_at REAL
)'''

class Experience:
    def __init__(self, db_path=None):
        self.db_path = db_path or settings.DATABASE_PATH
        self._init()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def _init(self):
        with self._conn() as c:
            c.execute(SQL_EXPERIENCE)
            c.execute(SQL_RULES)

    def record(self, exp_type, key, value, score=0.0):
        now = time.time()
        with self._conn() as c:
            row = c.execute('SELECT id, score, count FROM experience WHERE type=? AND key=?', (exp_type, key)).fetchone()
            if row:
                new_count = row[2] + 1
                new_score = (row[1] * (new_count - 1) + score) / new_count
                c.execute('UPDATE experience SET value=?, score=?, count=?, updated_at=? WHERE id=?',
                          (json.dumps(value, ensure_ascii=False), new_score, new_count, now, row[0]))
            else:
                c.execute('INSERT INTO experience(type, key, value, score, count, updated_at) VALUES(?,?,?,?,?,?)',
                          (exp_type, key, json.dumps(value, ensure_ascii=False), score, 1, now))

    def get(self, exp_type, key):
        with self._conn() as c:
            row = c.execute('SELECT value, score, count FROM experience WHERE type=? AND key=?', (exp_type, key)).fetchone()
        if row:
            return {'value': json.loads(row[0]), 'score': row[1], 'count': row[2]}
        return None

    def best(self, exp_type, limit=5):
        with self._conn() as c:
            rows = c.execute('SELECT key, value, score, count FROM experience WHERE type=? ORDER BY score DESC LIMIT ?',
                             (exp_type, limit)).fetchall()
        return [{'key': r[0], 'value': json.loads(r[1]), 'score': r[2], 'count': r[3]} for r in rows]

    def all(self, exp_type=None):
        with self._conn() as c:
            if exp_type:
                rows = c.execute('SELECT type, key, value, score, count FROM experience WHERE type=?', (exp_type,)).fetchall()
            else:
                rows = c.execute('SELECT type, key, value, score, count FROM experience').fetchall()
        return [
            {'type': r[0], 'key': r[1], 'value': json.loads(r[2]), 'score': r[3], 'count': r[4]}
            for r in rows
        ]

    def add_rule(self, rule_type, rule_key, rule_value):
        now = time.time()
        with self._conn() as c:
            c.execute('INSERT OR REPLACE INTO runtime_rules(rule_type, rule_key, rule_value, enabled, updated_at) VALUES(?,?,?,?,?)',
                      (rule_type, rule_key, rule_value, 1, now))

    def get_rules(self, rule_type=None):
        with self._conn() as c:
            if rule_type:
                rows = c.execute('SELECT rule_type, rule_key, rule_value FROM runtime_rules WHERE rule_type=? AND enabled=1', (rule_type,)).fetchall()
            else:
                rows = c.execute('SELECT rule_type, rule_key, rule_value FROM runtime_rules WHERE enabled=1').fetchall()
        return [{'rule_type': r[0], 'rule_key': r[1], 'rule_value': r[2]} for r in rows]