import re,sqlite3,time,json
from core.config import settings

LEAD_COLS=[('website','TEXT'),('emails','TEXT'),('phones','TEXT'),('address','TEXT'),('linkedin','TEXT'),('contact_person','TEXT'),('score','REAL'),('grade','TEXT'),('profile','TEXT'),('zone','TEXT'),('touch_status','TEXT'),('last_touch','REAL'),('audit','TEXT')]
MSG_SQL="""CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,lead_norm TEXT,direction TEXT,channel TEXT,content TEXT,draft INT,ts REAL);"""

class DB:
    def __init__(self,path=None): self.path=path or settings.DATABASE_PATH; self.init()
    def c(self): return sqlite3.connect(self.path,timeout=10)
    def init(self):
        with self.c() as x:
            x.executescript('''
            CREATE TABLE IF NOT EXISTS tasks(task_id TEXT PRIMARY KEY,request TEXT,status TEXT,result TEXT,created_at REAL,updated_at REAL);
            CREATE TABLE IF NOT EXISTS icp_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,market TEXT,industry TEXT,card TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS companies(norm TEXT PRIMARY KEY,name TEXT,country TEXT,industry TEXT,type TEXT,website TEXT,source TEXT,strength INT,freshness REAL,updated_at REAL);
            CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY AUTOINCREMENT,norm TEXT,kind TEXT,content TEXT,source TEXT,ts REAL);
            CREATE TABLE IF NOT EXISTS raw_sources(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT,query TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS search_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,project_key TEXT,market TEXT,industry TEXT,limit_n INT,result_count INT,used_sources TEXT,source_errors TEXT,gate TEXT,evolved INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS project_evolution(project_key TEXT PRIMARY KEY,run_count INT,evolved INT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS source_quota(source TEXT,day TEXT,count INT,UNIQUE(source,day));
            CREATE TABLE IF NOT EXISTS customs_raw(id INTEGER PRIMARY KEY AUTOINCREMENT,row_hash TEXT UNIQUE,bol TEXT,ts REAL,importer TEXT,importer_norm TEXT,shipper TEXT,notify TEXT,hs TEXT,descr TEXT,qty REAL,weight REAL,teu REAL,origin TEXT,port_load TEXT,port_discharge TEXT,source_file TEXT,direct_importer INT,created_at REAL);
            CREATE TABLE IF NOT EXISTS buyers_90d(importer_norm TEXT PRIMARY KEY,importer TEXT,first_seen REAL,last_seen REAL,shipments INT,total_weight REAL,total_qty REAL,total_teu REAL,supplier_count INT,origins TEXT,ports TEXT,sample_desc TEXT,score REAL,reasons TEXT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS suppliers(supplier_norm TEXT PRIMARY KEY,name TEXT,slug TEXT,shipments INT,first_seen REAL,last_seen REAL,harvested_at REAL,bol_fetched INT,updated_at REAL);
            CREATE TABLE IF NOT EXISTS company_state(norm TEXT PRIMARY KEY,name TEXT,first_seen REAL,last_seen REAL,runs_seen INT,profiled INT,source TEXT);
            CREATE TABLE IF NOT EXISTS harvest_log(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,slug TEXT,supplier TEXT,mode TEXT,status TEXT,items INT,note TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS usitc_cache(id INTEGER PRIMARY KEY AUTOINCREMENT,hs TEXT,kind TEXT,payload TEXT,created_at REAL);
            CREATE TABLE IF NOT EXISTS leads(norm TEXT PRIMARY KEY,name TEXT,country TEXT,kind TEXT,hs_code TEXT,shipments INT,last_shipment TEXT,tags TEXT,segment TEXT,desc_sample TEXT,source TEXT,first_seen REAL,last_seen REAL,status TEXT);
            '''+MSG_SQL+'''
            ''')
            have={r[1] for r in x.execute('PRAGMA table_info(leads)')}
            for col,typ in LEAD_COLS:
                if col not in have: x.execute('ALTER TABLE leads ADD COLUMN '+col+' '+typ)
            x.execute("UPDATE leads SET zone='pool' WHERE zone IS NULL OR zone=''")
    def save_task(self,tid,req,status,result):
        now=time.time()
        with self.c() as x: x.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?) ON CONFLICT(task_id) DO UPDATE SET status=excluded.status,result=excluded.result,updated_at=excluded.updated_at',(tid,req,status,json.dumps(result,ensure_ascii=False),now,now))
    @staticmethod
    def _norm(n): return re.sub(r'[^a-z0-9]+','',str(n or '').lower())
    def upsert_leads(self,items):
        now=time.time()
        with self.c() as x:
            for c in items or []:
                nm=(c.get('name') or '').strip()
                if len(nm)<3: continue
                norm=self._norm(nm)
                old=x.execute('SELECT tags,shipments,segment,source,first_seen FROM leads WHERE norm=?',(norm,)).fetchone()
                tags=c.get('tags') or []
                if isinstance(tags,list): tags=','.join(tags)
                if old:
                    ot=set(t for t in (old[0] or '').split(',') if t); nt=set(t for t in tags.split(',') if t)
                    tags=','.join(sorted(ot|nt))
                    ship=max(old[1] or 0,int(c.get('shipments') or 0))
                    seg=c.get('segment') or old[2] or ''
                    src=old[3] if c.get('source') in (old[3] or '') else (old[3]+'+'+c.get('source','')).strip('+')
                    x.execute('UPDATE leads SET name=?,country=?,kind=?,hs_code=?,shipments=?,last_shipment=?,tags=?,segment=?,desc_sample=?,source=?,last_seen=?,status=? WHERE norm=?',
                        (nm,c.get('country',''),c.get('kind',''),c.get('hs_code',''),ship,c.get('last_shipment',''),tags,seg,c.get('desc_sample','')[:300],src,now,c.get('status') or 'new',norm))
                else:
                    x.execute('INSERT INTO leads(norm,name,country,kind,hs_code,shipments,last_shipment,tags,segment,desc_sample,source,first_seen,last_seen,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        (norm,nm,c.get('country',''),c.get('kind',''),c.get('hs_code',''),int(c.get('shipments') or 0),c.get('last_shipment',''),tags,c.get('segment',''),c.get('desc_sample','')[:300],c.get('source',''),now,now,c.get('status') or 'new'))
    def list_leads(self,kind=None,segment=None,q=None,zone=None,limit=500):
        sql='SELECT * FROM leads WHERE 1=1'; args=[]
        if kind: sql+=' AND kind=?'; args.append(kind)
        if segment: sql+=' AND segment=?'; args.append(segment)
        if zone: sql+=' AND zone=?'; args.append(zone)
        if q: sql+=' AND name LIKE ?'; args.append('%'+q+'%')
        sql+=' ORDER BY COALESCE(score,0) DESC,shipments DESC,last_seen DESC LIMIT ?'; args.append(int(limit))
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute(sql,args).fetchall()]
    def get_lead(self,norm):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM leads WHERE norm=?',(norm,)).fetchone()
            return dict(r) if r else None
    def lead_update(self,norm,**kw):
        if not kw: return
        sql='UPDATE leads SET '+','.join(k+'=?' for k in kw)+' WHERE norm=?'
        with self.c() as x: x.execute(sql,tuple(kw.values())+(norm,))
    def set_zone(self,norm,zone,touch_status=None):
        kw={'zone':zone}
        if touch_status is not None: kw['touch_status']=touch_status; kw['last_touch']=time.time()
        self.lead_update(norm,**kw)
    def add_message(self,norm,direction,channel,content,draft=0):
        with self.c() as x: x.execute('INSERT INTO messages(lead_norm,direction,channel,content,draft,ts) VALUES(?,?,?,?,?,?)',(norm,direction,channel,content,int(draft),time.time()))
        self.lead_update(norm,last_touch=time.time())
    def get_message(self,mid):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            r=x.execute('SELECT * FROM messages WHERE id=?',(int(mid),)).fetchone()
            return dict(r) if r else None
    def delete_message(self,mid):
        with self.c() as x: x.execute('DELETE FROM messages WHERE id=?',(int(mid),))
    def update_message(self,mid,content):
        with self.c() as x: x.execute('UPDATE messages SET content=? WHERE id=?',(str(content),int(mid)))
    def list_messages(self,norm,limit=100):
        with self.c() as x:
            x.row_factory=sqlite3.Row
            return [dict(r) for r in x.execute('SELECT * FROM messages WHERE lead_norm=? ORDER BY ts ASC LIMIT ?',(norm,int(limit))).fetchall()]
    def get_task(self,tid):
        with self.c() as x: r=x.execute('SELECT request,status,result FROM tasks WHERE task_id=?',(tid,)).fetchone()
        return None if not r else {'request':r[0],'status':r[1],'result':json.loads(r[2] or '{}')}
