# -*- coding: utf-8 -*-
"""行业品类配置加载模块"""
import json
from pathlib import Path
from core.config import settings

CONFIG_DIR = Path(settings.PROJECT_ROOT) / "data" / "industry_configs"

def load_industry(key=None):
    key = key or getattr(settings, 'INDUSTRY', 'candle')
    path = CONFIG_DIR / f"{key}.json"
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "key": key,
        "name": key,
        "name_en": key,
        "search_terms": [key],
        "hs_codes": [],
        "keywords": [key],
        "pitch_facts": [f"We specialize in {key}."],
        "industry_context": key,
    }

def list_industries():
    out = []
    for fp in CONFIG_DIR.glob("*.json"):
        with open(fp, "r", encoding="utf-8") as f:
            out.append(json.load(f))
    return out
