# -*- coding: utf-8 -*-
import os
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[2]
def _env():
    p=PROJECT_ROOT/'.env'
    if p.exists():
        raw=p.read_bytes()
        text=''
        for enc in ('utf-8-sig','utf-16'):
            try: text=raw.decode(enc); break
            except Exception: continue
        if not text: text=raw.decode('utf-8','ignore')
        for line in text.replace('\x00','').splitlines():
            line=line.strip()
            if line and not line.startswith('#') and '=' in line:
                k,v=line.split('=',1); os.environ.setdefault(k.strip(), v.strip())
_env()

# 当前品类
INDUSTRY=os.getenv('INDUSTRY','candle')
VERSION='v18.3.0'
LLM_BASE_URL=os.getenv('LLM_BASE_URL','http://192.168.1.26:8081/v1')
LLM_MODEL=os.getenv('LLM_MODEL','deepseek-r1-distill-llama-70b')
LLM_API_KEY=os.getenv('LLM_API_KEY','not-needed')
LLM_TIMEOUT=int(os.getenv('LLM_TIMEOUT','480'))
LLM_MAX_TOKENS=int(os.getenv('LLM_MAX_TOKENS','4096'))
DATABASE_PATH=os.getenv('DATABASE_PATH', str(PROJECT_ROOT/'data'/'psv.db'))
IMPORT_DIR=str(PROJECT_ROOT/'data'/'imports')
CUSTOMS_DIR=str(PROJECT_ROOT/'data'/'customs')
WEB_HOST=os.getenv('WEB_HOST','0.0.0.0'); WEB_PORT=int(os.getenv('WEB_PORT','8090'))
SOURCE_PER_LIMIT=int(os.getenv('SOURCE_PER_LIMIT','30'))
AGGREGATE_MIN_RESULTS=int(os.getenv('AGGREGATE_MIN_RESULTS','25'))
PROFILE_TOP_N=int(os.getenv('PROFILE_TOP_N','10')); ANALYSIS_TOP_N=int(os.getenv('ANALYSIS_TOP_N','10')); LETTER_TOP_N=int(os.getenv('LETTER_TOP_N','5'))
IMPORTYETI_ENABLED=os.getenv('IMPORTYETI_ENABLED','false').lower()=='true'
IMPORTYETI_SEARCH_URL=os.getenv('IMPORTYETI_SEARCH_URL','https://www.importyeti.com/api/search')
IMPORTYETI_DAILY_QUOTA=int(os.getenv('IMPORTYETI_DAILY_QUOTA','25'))
IMPORTYETI_QUOTA_RESERVE=int(os.getenv('IMPORTYETI_QUOTA_RESERVE','5'))
IMPORTYETI_MAX_PAGES=int(os.getenv('IMPORTYETI_MAX_PAGES','1'))
BING_CN_ENABLED=os.getenv('BING_CN_ENABLED','false').lower()=='true'
HS_FINDER_ENABLED=os.getenv('HS_FINDER_ENABLED','true').lower()=='true'
HS_CODES=os.getenv('HS_CODES','3406')
CONTACT_ENABLED=os.getenv('CONTACT_ENABLED','true').lower()=='true'
CONTACT_TOP_N=int(os.getenv('CONTACT_TOP_N','10'))
CONTACT_HARD_STD=os.getenv('CONTACT_HARD_STD','true').lower()=='true'
CONTACT_MODE=os.getenv('CONTACT_MODE','webai_first')
# ---- v18.3.0 资料审核 ----
AUDIT_ENABLED=os.getenv('AUDIT_ENABLED','true').lower()=='true'
AUDIT_AI_MODE=os.getenv('AUDIT_AI_MODE','always')
AUDIT_AI_PER_RUN=int(os.getenv('AUDIT_AI_PER_RUN','30'))
# ---- v18.0 邮件发送 ----
MAIL_PROVIDER=os.getenv('MAIL_PROVIDER','outlook')
SMTP_HOST=os.getenv('SMTP_HOST','smtp-mail.outlook.com')
SMTP_PORT=int(os.getenv('SMTP_PORT','587'))
SMTP_USER=os.getenv('SMTP_USER','changlihua925@outlook.com')
SMTP_PASS=os.getenv('SMTP_PASS','')
SMTP_FROM=os.getenv('SMTP_FROM','')
# ---- v16.5 网页AI ----
WEBAI_ENABLED=os.getenv('WEBAI_ENABLED','true').lower()=='true'
WEBAI_ENGINE=os.getenv('WEBAI_ENGINE','chatgpt')   # 主引擎 GPT，备用 DeepSeek
WEBAI_DAILY_MAX=int(os.getenv('WEBAI_DAILY_MAX','200'))
WEBAI_MIN_INTERVAL=int(os.getenv('WEBAI_MIN_INTERVAL','15'))
WEBAI_TIMEOUT=int(os.getenv('WEBAI_TIMEOUT','150'))
WEBAI_PER_RUN=int(os.getenv('WEBAI_PER_RUN','50'))
# ---- v17 署名与工厂档案 ----
SENDER_NAME=os.getenv('SENDER_NAME','常立华')
SENDER_NAME_EN=os.getenv('SENDER_NAME_EN','Lihua Chang')
SENDER_PHONE=os.getenv('SENDER_PHONE','+86 17303304256')
SENDER_EMAIL=os.getenv('SENDER_EMAIL','changlihua925@outlook.com')
SENDER_COMPANY=os.getenv('SENDER_COMPANY','Ningjin Birthday Candle Factory')
# ---- v17 网络扩张预算 ----
EXPAND_BUYERS=int(os.getenv('EXPAND_BUYERS','5'))
EXPAND_CUSTOMERS=int(os.getenv('EXPAND_CUSTOMERS','15'))
EXPAND_MAX_NEW=int(os.getenv('EXPAND_MAX_NEW','40'))
DDG_ENABLED=os.getenv('DDG_ENABLED','false').lower()=='true'
DATA_SOURCE_TIMEOUT=int(os.getenv('DATA_SOURCE_TIMEOUT','12'))
SCRAPE_PROXY_URL=os.getenv('SCRAPE_PROXY_URL','')
EVOLUTION_TRIGGER_RUNS=int(os.getenv('EVOLUTION_TRIGGER_RUNS','3'))
EVOLUTION_MAX_QUERY_VARIANTS=int(os.getenv('EVOLUTION_MAX_QUERY_VARIANTS','2'))
GATE_MIN_QUALIFIED=int(os.getenv('GATE_MIN_QUALIFIED','3'))
GATE_MIN_STRONG=int(os.getenv('GATE_MIN_STRONG','1'))
# ---- v14 反向收割 ----
APIFY_TOKEN=os.getenv('APIFY_TOKEN','')
APIFY_ACTOR=os.getenv('APIFY_ACTOR','logiover~importyeti-scraper')
APIFY_RUN_TIMEOUT=int(os.getenv('APIFY_RUN_TIMEOUT','420'))
APIFY_MAX_SUPPLIERS_PER_RUN=int(os.getenv('APIFY_MAX_SUPPLIERS_PER_RUN','3'))
APIFY_COMPANY_INPUT=os.getenv('APIFY_COMPANY_INPUT','{"mode":"companySearch","companySlug":"{slug}","maxResults":50}')
HARVEST_ENABLED=os.getenv('HARVEST_ENABLED','true').lower()=='true'
HARVEST_MIN_SHIPMENTS=int(os.getenv('HARVEST_MIN_SHIPMENTS','1'))
# ---- v14.1 ImportYeti 网页收割 ----
IY_WEB_ENABLED=os.getenv('IY_WEB_ENABLED','true').lower()=='true'
IY_WEB_HEADLESS=os.getenv('IY_WEB_HEADLESS','true').lower()=='true'
IY_WEB_AUTO_HEADED=os.getenv('IY_WEB_AUTO_HEADED','true').lower()=='true'
IY_WEB_CHALLENGE_WAIT=float(os.getenv('IY_WEB_CHALLENGE_WAIT','30'))
IY_WEB_CDP_ENABLED=os.getenv('IY_WEB_CDP_ENABLED','true').lower()=='true'
IY_WEB_CDP_URL=os.getenv('IY_WEB_CDP_URL','http://127.0.0.1:9222')
IY_WEB_DELAY_MIN=float(os.getenv('IY_WEB_DELAY_MIN','4'))
IY_WEB_DELAY_MAX=float(os.getenv('IY_WEB_DELAY_MAX','8'))
IY_WEB_SEARCH_LIMIT=int(os.getenv('IY_WEB_SEARCH_LIMIT','25'))
IY_WEB_TOP_BUYERS=int(os.getenv('IY_WEB_TOP_BUYERS','5'))
IY_WEB_MAX_SUPPLIERS=int(os.getenv('IY_WEB_MAX_SUPPLIERS','5'))
IY_WEB_MAX_CUSTOMERS=int(os.getenv('IY_WEB_MAX_CUSTOMERS','25'))
# ---- v15 ExpertGraph ----
EXPERT_MODE=os.getenv('EXPERT_MODE','true').lower()=='true'
REFLECT_MAX_ROUNDS=int(os.getenv('REFLECT_MAX_ROUNDS','3'))
LLM_REVIEW_MAX_TOKENS=int(os.getenv('LLM_REVIEW_MAX_TOKENS','900'))
LLM_REVIEW_TIMEOUT=int(os.getenv('LLM_REVIEW_TIMEOUT','240'))
# ---- v14 USITC ----
USITC_TOKEN=os.getenv('USITC_TOKEN','')
USITC_API_URL=os.getenv('USITC_API_URL','https://datawebws.usitc.gov/dataweb/api/v2/report2/runReport')
USITC_HS_CODE=os.getenv('USITC_HS_CODE','3406')
USITC_NOTES_FILE=os.getenv('USITC_NOTES_FILE', str(PROJECT_ROOT/'data'/'usitc_notes.txt'))
for p in (Path(DATABASE_PATH).parent, Path(IMPORT_DIR), Path(CUSTOMS_DIR)): p.mkdir(parents=True, exist_ok=True)

# === 自动补齐的配置 ===

OUTREACH_ENABLED=os.getenv('OUTREACH_ENABLED','false').lower()=='true'

BING_ENABLED=os.getenv('BING_ENABLED','true').lower()=='true'
