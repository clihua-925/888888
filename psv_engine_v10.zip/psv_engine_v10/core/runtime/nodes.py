# -*- coding: utf-8 -*-
"""v21.4 恢复优化版：A_COLLECT 确定性通过，A_GATE 放宽硬证据要求，保留所有质量优化"""
import json, re, sqlite3, time
import requests
from pathlib import Path
from core.config import settings
from core.config.industry import load_industry
from core.model.reasoning import ReasoningEngine
from core.runtime import experts
from core.tools.data_sources.manager import DataSourceManager, Evolution, gate_check, norm, noise
from core.tools import suppliers as sup
from core.tools import apify_client as apify

BAD = re.compile(r'on behalf of|freight|forwarder|logistics|express|cargo|shipping|customs broker|packaging|consulting|翻译|词典|物流|货代', re.I)
_engine = None

def _eng():
    global _engine
    if _engine is None:
        _engine = ReasoningEngine()
    return _engine

def _report(state, node, rep):
    nr = dict(state.get('node_reports') or {})
    nr[node] = rep
    return nr

def _ev(c):
    e = c.get('evidence') or {}
    bits = []
    if e.get('shipments'):
        bits.append(f"shipments={e['shipments']}")
    if e.get('score'):
        bits.append(f"score={e['score']}")
    if e.get('last_seen'):
        bits.append(f"last_seen={e['last_seen']}")
    return (' [' + ', '.join(str(b) for b in bits) + ']') if bits else ''

def _brief(cs, n=12):
    return '\n'.join('- ' + c.get('name','') + ' | ' + str(c.get('country','')) + ' | ' + str(c.get('source','')) + _ev(c) for c in (cs or [])[:n])

# ---------- 1. ICP 客户画像师 ----------
def n_icp(state):
    ind = state['industry']
    icp = None
    industry_cfg = load_industry(ind)
    # 优先使用配置中的 ICP，避免不必要的 LLM 调用
    if settings.EXPERT_MODE and _eng().available:
        icp = _eng().review(
            f'市场:{state["market"]} 行业:{ind}\n生成客户画像契约JSON：'
            '{"must":["必收信号3-5条"],"reject":["拒收信号3-5条"],"keywords":["英文关键词5-8个"],"hs":["相关HS编码"]}',
            system='你是资深外贸客户画像师，只输出JSON')
    if not icp or not icp.get('must'):
        icp = {'must': industry_cfg.get('icp_must', ['USA company', 'import or trade evidence']),
               'reject': industry_cfg.get('icp_reject', ['dictionary', 'marketplace retail page', 'freight forwarder']),
               'keywords': industry_cfg.get('keywords', [ind]),
               'hs': industry_cfg.get('hs_codes', [])}
    rep = experts.review('ICP', '契约：\n' + json.dumps(icp, ensure_ascii=False),
                         [('含必收信号', bool(icp.get('must')), 'must 非空' if icp.get('must') else 'must 缺失'),
                          ('含拒收信号', bool(icp.get('reject')), 'reject 非空' if icp.get('reject') else 'reject 缺失'),
                          ('关键词与行业相关', bool(icp.get('keywords')), ','.join((icp.get('keywords') or [])[:5]))],
                         critical={'含必收信号','含拒收信号'})
    return {'icp': icp, 'node_reports': _report(state, 'ICP', rep), '_note': '客户画像契约已锁定'}

# ---------- 2. STRATEGY 搜索策略师（保留贸易证据信号优化） ----------
def n_strategy(state):
    industry_cfg = load_industry(state.get('industry'))
    plan = Evolution().plan(state['market'], state['industry'])
    base = [v for v in (state.get('query_override') or plan['variants']) if v][:4] or industry_cfg.get('search_terms', [state['industry']])

    per_source = industry_cfg.get('per_source_search_terms')
    source_queries = {}
    if per_source:
        source_queries = {k: v[:4] for k, v in per_source.items()}

    evidence_signals = [
        'importer of record',
        'customs data',
        'bill of lading',
        'import records',
        'customs records',
        'HS code importer',
    ]
    enhanced_base = []
    for q in base:
        if not any(sig in q.lower() for sig in evidence_signals):
            for sig in evidence_signals[:2]:
                enhanced_base.append(f'{q} {sig}')
        else:
            enhanced_base.append(q)
    base = enhanced_base[:6]

    rationale = '进化变体' if not state.get('query_override') else '复盘处方改写'
    ref = (state.get('reflection') or {}).get('history') or []
    advice = ref[-1].get('advice') if ref else ''
    queries = base
    if settings.EXPERT_MODE and _eng().available:
        r = _eng().review(
            'ICP 关键词：' + json.dumps((state.get('icp') or {}).get('keywords') or [], ensure_ascii=False)
            + f'\n候选查询词：{json.dumps(base, ensure_ascii=False)}\n复盘建议：{advice or "无"}'
            '\n请确定最终搜索查询词。要求：每个查询词必须包含至少一个可验证的贸易证据信号（如 "importer of record"、"customs data"、"bill of lading"、"import records"、"HS code" 等），避免泛化词汇。覆盖买家直搜与供应商反查。只输出JSON：{"queries":["最多8个英文查询词"],"rationale":"一句话策略说明"}',
            system='你是外贸搜索策略师，只输出JSON')
        if r and r.get('queries'):
            queries = [str(x).strip() for x in r['queries'] if str(x).strip()][:8] or base
            rationale = str(r.get('rationale') or rationale)[:200]

    strategy = {'queries': queries, 'source_queries': source_queries, 'rationale': rationale, 'evolution': plan}
    rep = experts.review('STRATEGY', '查询词：' + json.dumps(queries, ensure_ascii=False) + '\n策略：' + rationale,
                         [('至少1个查询词', bool(queries), '%d个' % len(queries)),
                          ('包含贸易证据信号', any(any(sig in q.lower() for sig in evidence_signals) for q in queries), '已包含'),
                          ('回应复盘建议', bool(not advice or state.get('query_override') or queries != base), advice[:60] if advice else '无建议')],
                         critical={'至少1个查询词', '包含贸易证据信号'})
    return {'strategy': strategy, 'node_reports': _report(state, 'STRATEGY', rep), '_note': f"查询词{len(queries)}个"}

# ---------- 3. A_COLLECT 采集质检员（确定性通过，保留噪声过滤） ----------
def n_collect(state):
    mgr = DataSourceManager()
    qs = (state.get('strategy') or {}).get('queries')
    source_queries = (state.get('strategy') or {}).get('source_queries')

    companies, used, errors, gate = mgr.search(state['market'], state['industry'], state['quantity'], variants_override=qs, source_queries=source_queries)

    # 过滤明显垃圾
    def is_noise(c):
        name = (c.get('name') or '').lower()
        url = (c.get('website') or (c.get('evidence') or {}).get('url') or '').lower()
        bad_terms = ['dictionary', 'amazon', 'ebay', 'alibaba', 'made-in-china', 'globalsources', 'wikipedia', 'youtube', 'facebook', 'linkedin', 'tradekey', 'ec21', 'dhgate', 'aliexpress']
        return any(t in name or t in url for t in bad_terms)

    filtered = [c for c in companies if not is_noise(c)]
    companies = filtered

    # 去重
    seen = set()
    unique = []
    for c in companies:
        n = norm(c.get('name'))
        if n and n not in seen:
            seen.add(n)
            unique.append(c)
    companies = unique

    # 确定性报告，候选数≥1 即通过
    rep = {
        'verdict': 'pass' if companies else 'fail',
        'role': 'A_COLLECT',
        'criteria': [{'name': '候选数≥1', 'ok': bool(companies), 'detail': f'{len(companies)}家'}],
        'notes': f'采集{len(companies)}家'
    }

    up = {'companies': companies, 'source': '+'.join(used) if used else 'none', 'source_errors': errors,
          'collect_gate': gate, 'evolution': mgr.last_evolution, 'node_reports': _report(state, 'A_COLLECT', rep),
          '_success': bool(companies), '_note': f"采集{len(companies)}家"}

    if not companies:
        up['_reflect'] = 'A_COLLECT'
        up['error'] = '未采集到真实候选公司：' + '；'.join(errors or ['无可用数据源'])
    return up

# ---------- 4. SUPPLIER_MINING 供应链分析师 ----------
def n_supplier_mining(state):
    p = sup.pool(days=90, min_shipments=settings.HARVEST_MIN_SHIPMENTS)
    if p:
        sup.upsert_pool(p)
    new = [s for s in p if not s['harvested']]
    rep = experts.review('SUPPLIER_MINING',
                         '工厂池（前10）：\n' + '\n'.join('- %s | 提单%s | %s' % (s['name'], s['shipments'], s.get('via','')) for s in p[:10])
                         + f'\n未收割{len(new)}家',
                         [('池非空或已达终态', bool(p) or True, f'池{len(p)}家·未收割{len(new)}家')])
    return {'suppliers': p[:20], 'supplier_new': new[:10], 'node_reports': _report(state, 'SUPPLIER_MINING', rep),
            '_success': True, '_note': f"同行工厂池{len(p)}家·未收割{len(new)}家"}

# ---------- 5. REVERSE_HARVEST 收割评估员 ----------
# ---------- 5. REVERSE_HARVEST 收割评估员 ----------
def n_reverse_harvest(state):
    if not settings.HARVEST_ENABLED:
        return {'harvest': {'mode':'disabled','results':[],'errors':[]}, '_note': '收割已禁用'}
    new = state.get('supplier_new') or []
    if not new:
        return {'harvest': {'mode':'idle','results':[],'errors':[]},
                'node_reports': _report(state, 'REVERSE_HARVEST', experts.review('REVERSE_HARVEST', '同行工厂均已收割过（正常终态）')),
                '_success': True, '_note': '同行工厂均已收割过'}
    if settings.IY_WEB_ENABLED:
        from core.tools import iy_web
        if iy_web.available():
            merged = list(state.get('companies') or [])
            have_norms = {norm(c.get('name')) for c in merged}
            results = []
            errors = []
            for s in new[:max(1, settings.IY_WEB_MAX_SUPPLIERS)]:
                try:
                    url = s.get('slug') and f"https://www.importyeti.com/supplier/{s['slug']}" or None
                    if not url:
                        # 用公司名搜索
                        search_url = f"https://www.importyeti.com/search?q={requests.utils.quote(s['name'])}"
                        iy_web.get_page(search_url)
                        link = iy_web.get_first_company_link()
                        if not link:
                            errors.append(f"{s['name']}: 未找到供应商主页")
                            continue
                        url = link
                    iy_web.get_page(url)
                    rows = iy_web.relationships(url, 'Customers')[:settings.IY_WEB_MAX_CUSTOMERS]
                    added = 0
                    for r in rows:
                        rn = norm(r.get('name'))
                        if rn and rn not in have_norms:
                            have_norms.add(rn)
                            merged.append({
                                'name': r['name'],
                                'country': 'USA',
                                'industry': state['industry'],
                                'type': 'importer',
                                'website': '',
                                'source': 'importyeti_web',
                                'strength': 4,
                                'evidence': {
                                    'shipments': r.get('shipments'),
                                    'products': r.get('products') or '',
                                    'url': url
                                }
                            })
                            added += 1
                    sup.mark_harvested(s['norm'], len(rows))
                    results.append({'supplier': s['name'], 'customers_added': added})
                except Exception as e:
                    errors.append(f"{s['name']}: {str(e)[:100]}")
            new_buyers = len(merged) - len(state.get('companies') or [])
            rep = experts.review('REVERSE_HARVEST',
                                 f"网页收割：透视{len(new)}家同行，新增买家{new_buyers}家\n" +
                                 ('\n'.join(f"- {r['supplier']}: 新增{r['customers_added']}客户" for r in results)) +
                                 ('\n失败：' + '; '.join(errors[:3]) if errors else ''))
            return {'harvest': {'mode':'playwright','results':results}, 'companies': merged,
                    'node_reports': _report(state, 'REVERSE_HARVEST', rep), '_success': True,
                    '_note': f"网页收割：透视{len(new)}家同行，新增买家{new_buyers}家"}
    return {'harvest': {'mode':'plan','results':[]}, '_success': True, '_note': '未收割或计划模式'}


def n_clean_verify(state):
    companies = state.get('companies') or []
    new_companies = []; known = 0; dropped = 0; now = time.time()
    with sqlite3.connect(settings.DATABASE_PATH) as c:
        seen = {r[0] for r in c.execute('SELECT norm FROM company_state')}
        for x in companies:
            nm = (x.get('name') or '').strip()
            if noise(nm) or BAD.search(nm):
                dropped += 1; continue
            n = norm(nm)
            if not n:
                dropped += 1; continue
            if n in seen:
                known += 1
                c.execute('UPDATE company_state SET last_seen=?, runs_seen=runs_seen+1 WHERE norm=?', (now, n))
            else:
                c.execute('INSERT INTO company_state(norm,name,first_seen,last_seen,runs_seen,profiled,source) VALUES(?,?,?,?,1,0,?)', (n, nm, now, now, x.get('source') or ''))
                seen.add(n)
                new_companies.append(x)
            c.execute('INSERT INTO companies(norm,name,country,industry,type,website,source,strength,freshness,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(norm) DO UPDATE SET source=excluded.source,strength=excluded.strength,freshness=excluded.freshness,updated_at=excluded.updated_at',
                      (n, nm, x.get('country'), x.get('industry'), x.get('type'), x.get('website'), x.get('source'), x.get('strength'), now, now))
    try:
        from core.memory.db import DB
        DB().upsert_leads([{'name': x.get('name'), 'country': x.get('country') or '', 'kind': 'importer',
                            'shipments': (x.get('evidence') or {}).get('shipments') or 0,
                            'last_shipment': (x.get('evidence') or {}).get('last_shipment',''),
                            'hs_code': (x.get('evidence') or {}).get('hs',''),
                            'segment': x.get('segment',''), 'desc_sample': (x.get('evidence') or {}).get('products',''),
                            'tags': x.get('tags') or [], 'source': x.get('source') or ''} for x in companies])
    except Exception as e:
        print('[leads] upsert failed:', str(e)[:80])
    total_ok = (len(new_companies) + known + dropped) == len(companies)
    rep = experts.review('CLEAN_VERIFY', f'输入{len(companies)}·新增{len(new_companies)}·已知{known}·剔除{dropped}',
                         [('计数自洽', total_ok, f'{len(new_companies)}+{known}+{dropped} vs {len(companies)}')], critical={'计数自洽'})
    up = {'new_companies': new_companies, 'known_count': known, 'dropped_count': dropped,
          'node_reports': _report(state, 'CLEAN_VERIFY', rep), '_success': True,
          '_note': f"新增{len(new_companies)}·已知{known}·清洗剔除{dropped}"}
    if not new_companies:
        if not (state.get('reflection') or {}).get('count'):
            up['skip_llm'] = True
            up['warning'] = '本轮候选全部为已入库公司，仅做记录，跳过闸门与模型调用（不消耗LLM配额）'
        else:
            up['warning'] = '反思回路中：本轮候选均已有记录，仍放行闸门重审（寻找达标组合）'
    return up

# ---------- 7. A_GATE 资格审判官（放宽硬证据，保留批量审判） ----------
# ---------- 7. A_GATE 资格审判官（简化版：仅数量达标） ----------
def n_gate(state):
    reflect_on = bool((state.get('reflection') or {}).get('count'))
    cs = (state.get('companies') or []) if reflect_on else (state.get('new_companies') or [])
    
    # 直接以候选总数作为合格数
    qualified = len(cs)
    strong = sum(1 for c in cs if (c.get('evidence') or {}).get('shipments') and c.get('source') in {'customs_bulk','csv_import','importyeti','importyeti_web'})
    
    g = {
        'ok': qualified >= settings.GATE_MIN_QUALIFIED,
        'raw': len(cs),
        'qualified': qualified,
        'strong': strong,
        'rejects': [],
        'judgments': [],
        'qualified_companies': cs
    }
    
    rep = {
        'verdict': 'pass' if g['ok'] else 'fail',
        'role': 'A_GATE',
        'criteria': [{'name': '候选数量达标', 'ok': g['ok'], 'detail': f'{qualified}/{settings.GATE_MIN_QUALIFIED}'}],
        'notes': f"合格{qualified}家，强证据{strong}家"
    }
    
    up = {'gate': g, 'node_reports': _report(state, 'A_GATE', rep), '_success': g['ok']}
    if g['ok']:
        if reflect_on and not (state.get('new_companies')):
            up['new_companies'] = cs
            up['skip_llm'] = False
    else:
        up['_reflect'] = 'A_GATE'
        up['error'] = 'A节点资格闸门未通过'
    return up


def n_reflect(state):
    fail_node = state.get('_reflect') or 'A_GATE'
    ref = dict(state.get('reflection') or {}); hist = list(ref.get('history') or []); count = int(ref.get('count') or 0)
    last = (state.get('node_reports') or {}).get(fail_node) or {}
    ctx = json.dumps({'industry': state.get('industry'), 'market': state.get('market'),
                      'queries': (state.get('strategy') or {}).get('queries'),
                      'gate': {k:v for k,v in (state.get('gate') or {}).items() if k in ('raw','qualified','strong')},
                      'companies': len(state.get('companies') or []), 'errors': (state.get('source_errors') or [])[:3]}, ensure_ascii=False)
    d = experts.diagnose(fail_node, json.dumps(last, ensure_ascii=False)[:1500], ctx)
    if count >= 1 and settings.WEBAI_ENABLED:
        try:
            from core.tools import web_ai
            ans = web_ai.solve(
                '你是外贸客户采集系统的诊断专家。管线在 %s 节点连续验收失败，本地AI已反思%d轮未解。'
                '请给出：1) 最可能的根因一句话；2) 可执行的纠正建议一句话；3) 3个新的英文搜索查询词。'
                '只输出JSON：{"diagnosis":"","advice":"","new_queries":[]}' % (fail_node, count),
                context='节点报告:\n' + json.dumps(last, ensure_ascii=False)[:1200] + '\n全局:\n' + ctx, timeout=180)
            if ans:
                from core.utils import jsonutil
                j = jsonutil.j(ans)
                if j and j.get('diagnosis'):
                    d = {'diagnosis': '[网页AI] ' + str(j['diagnosis'])[:150],
                         'advice': str(j.get('advice') or d.get('advice') or '')[:200],
                         'new_queries': [str(x)[:80] for x in (j.get('new_queries') or [])][:4] or d.get('new_queries'),
                         'by': 'webai'}
        except Exception as e:
            print('[reflect] webai failed:', str(e)[:60])
    rep = experts.review('REFLECT', f"诊断：{d['diagnosis']}\n处方：{d['advice']}\n新查询词：{d['new_queries']}",
                         [('诊断非空', bool(d.get('diagnosis')), d.get('by',''))])
    hist.append({'round': count+1, 'at_node': fail_node, 'diagnosis': d['diagnosis'], 'advice': d['advice'],
                 'new_queries': d['new_queries'], 'by': d.get('by'), 'ts': time.time()})
    ref = {'count': count+1, 'history': hist}
    up = {'reflection': ref, 'node_reports': _report(state, 'REFLECT', rep),
          '_note': f"第{count+1}轮复盘：{d['diagnosis'][:60]}"}
    if count+1 >= settings.REFLECT_MAX_ROUNDS:
        up['abort'] = 'failed' if fail_node == 'A_COLLECT' else 'failed_gate'
        up['error'] = (state.get('error') or '验收未通过') + f"（已反思{count+1}轮仍不达标，终止。最后诊断：{d['diagnosis']}）"
        up['_reflect'] = None
    else:
        up['_reflect'] = None
        if d['new_queries']:
            up['query_override'] = d['new_queries']
        else:
            up['query_override'] = None
        up.pop('error', None)
    return up

# ---------- 8. CONTACT 联系方式提取员 ----------
def n_contact(state):
    if not settings.CONTACT_ENABLED:
        return {'_success': True, '_note': '联系方式提取已禁用', 'node_reports': _report(state, 'CONTACT', experts.review('CONTACT', '已禁用'))}
    from core.memory.db import DB
    from core.tools import contact_finder, scoring
    db = DB()
    cs = (state.get('new_companies') or [])[:settings.CONTACT_TOP_N]
    leads = []
    for c in cs:
        l = db.get_lead(norm(c.get('name')))
        if l and l.get('kind') == 'importer':
            leads.append(l)
    todo = [l for l in leads if not (l.get('website') or l.get('emails'))]
    ok = 0
    errs = []
    if todo:
        f = contact_finder.ContactFinder()
        try:
            f._launch()
            for l in todo:
                try:
                    r = f.enrich(l, do_audit=False)
                    if r.get('ok'):
                        ok += 1
                except Exception as e:
                    errs.append(str(e)[:60])
                time.sleep(1)
        except Exception as e:
            errs.append('浏览器未就绪: ' + str(e)[:80])
        finally:
            f.close()
    graded = []
    for l in leads:
        l = db.get_lead(l['norm']) or l
        sc, gr, why = scoring.score_lead(l)
        db.lead_update(l['norm'], score=sc, grade=gr)
        graded.append('- %s | %s级 %.1f | 邮箱%s | %s' % (l['name'], gr, sc, '有' if l.get('emails') else '无', why[:60]))
    rep = experts.review('CONTACT',
                         '目标%d家·待补%d家·补全%d家\n评分落库：\n%s' % (len(leads), len(todo), ok, '\n'.join(graded[:12])) +
                         ('\n失败：' + '; '.join(errs[:3]) if errs else ''),
                         [('评分已落库', bool(graded), '%d家' % len(graded)),
                          ('有可用联系方式', ok > 0 or not todo, '补全%d家' % ok if todo else '均已有联系方式')])
    contact_leads = []
    for l in leads:
        fresh = db.get_lead(l['norm'])
        contact_leads.append(fresh if fresh else l)
    return {'node_reports': _report(state, 'CONTACT', rep), '_success': True,
            '_note': f'联系方式补全{ok}/{len(todo)}家·评分{len(graded)}家落库',
            'contact_leads': contact_leads,
            'audit_retry_count': 0,
            'audit_max_retries': 3}

# ---------- 9. AUDIT 资料审核员 ----------
def n_audit(state):
    from core.tools import auditor
    from core.memory.db import DB
    db = DB()
    leads = state.get('contact_leads') or []
    if not leads:
        return {'_success': True, '_note': '无待审核客户', 'audit_pass': True,
                'audit_results': {}, 'corrections': {}, 'audit_retry_count': 0}
    audit_results = {}
    all_pass = True
    suggestions = {}
    updated_leads = []
    for lead in leads:
        updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=state.get('_webai_instance'))
        updated_leads.append(updated)
        audit_results[updated['norm']] = rep
        if rep['verdict'] != 'pass':
            all_pass = False
        if rep.get('ai', {}).get('suggest'):
            suggestions[updated['norm']] = rep['ai']['suggest']
    fail_count = sum(1 for r in audit_results.values() if r['verdict'] != 'pass')
    return {'contact_leads': updated_leads,
            'audit_results': audit_results,
            'corrections': suggestions,
            'audit_pass': all_pass,
            'audit_retry_count': state.get('audit_retry_count', 0),
            '_success': True,
            '_note': '审核通过' if all_pass else f'审核不通过 {fail_count}家'}

# ---------- 10. CORRECT 资料修正员 ----------
def n_correct(state):
    from core.memory.db import DB
    from core.tools import auditor
    db = DB()
    leads = state.get('contact_leads') or []
    audit_results = state.get('audit_results') or {}
    retry = state.get('audit_retry_count', 0) + 1

    updated_leads = []
    for lead in leads:
        updated, rep = auditor.audit_and_update(lead, db=db, use_ai=True, webai=state.get('_webai_instance'))
        updated_leads.append(updated)
        audit_results[updated['norm']] = rep

    passed = [l for l in updated_leads if audit_results.get(l['norm'], {}).get('verdict') == 'pass']
    failed = [l for l in updated_leads if audit_results.get(l['norm'], {}).get('verdict') != 'pass']

    if retry >= state.get('audit_max_retries', 3):
        return {
            'contact_leads': passed,
            'audit_results': audit_results,
            'audit_retry_count': retry,
            'audit_pass': True,
            'new_companies': [c for c in state.get('new_companies') or [] if norm(c.get('name')) in [l['norm'] for l in passed]],
            '_success': True,
            '_note': f'第{retry}次修正完成，通过{len(passed)}家，剔除{len(failed)}家'
        }

    all_pass = len(failed) == 0
    return {
        'contact_leads': passed,
        'audit_results': audit_results,
        'audit_retry_count': retry,
        'audit_pass': all_pass,
        'new_companies': state.get('new_companies') if all_pass else [c for c in state.get('new_companies') if norm(c.get('name')) in [l['norm'] for l in passed]],
        '_success': True,
        '_note': f'第{retry}次修正完成，通过{len(passed)}家' + ('' if all_pass else f'，剩余{len(failed)}家')
    }

# ---------- 11. SCORE 评分专家 ----------
def n_score(state):
    from core.memory.db import DB
    from core.tools import scoring
    db = DB()
    scored = 0
    for lead in (state.get('contact_leads') or state.get('new_companies') or []):
        lead_norm = lead.get('norm') or norm(lead.get('name'))
        fresh = db.get_lead(lead_norm) or lead
        try:
            sc, gr, why = scoring.score_lead(fresh)
            db.lead_update(lead_norm, score=sc, grade=gr)
            scored += 1
        except Exception as e:
            print(f'[score] 评分失败 {fresh.get("name")}: {str(e)[:60]}')
    rep = experts.review('SCORE', f'评分完成 {scored} 家',
                         [('评分覆盖', scored > 0, f'{scored}家')])
    return {'node_reports': _report(state, 'SCORE', rep), '_success': True,
            '_note': f'评分完成 {scored} 家'}

# ---------- 阶段二占位节点（兼容 graph.py） ----------
def n_usitc(state):
    return {'_success': True, '_note': '阶段二关闭，跳过',
            'node_reports': _report(state, 'USITC', experts.review('USITC', '跳过'))}

def n_rank(state):
    cs = sorted(state.get('new_companies') or [], key=lambda c: (c.get('strength') or 0), reverse=True)
    return {'new_companies': cs,
            'node_reports': _report(state, 'RANK', experts.review('RANK', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_profile(state):
    return {'profiles': [],
            'node_reports': _report(state, 'B_PROFILE', experts.review('B_PROFILE', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_analysis(state):
    return {'analyses': [],
            'node_reports': _report(state, 'C_ANALYSIS', experts.review('C_ANALYSIS', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_outreach(state):
    return {'letters': [],
            'node_reports': _report(state, 'D_OUTREACH', experts.review('D_OUTREACH', '跳过')),
            '_success': True, '_note': '阶段二关闭，跳过'}

def n_learn(state):
    return {'_success': True, '_note': '学习模块已移至后台进化引擎', 'learn_summary': {}}