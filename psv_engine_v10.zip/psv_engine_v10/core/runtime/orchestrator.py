# -*- coding: utf-8 -*-
"""v14 编排入口：组装初始状态 → 跑状态图 → 每节点快照 → 终态落库。结果结构与 v13 兼容，前端无需大改。"""
import time,uuid
from core.memory.db import DB
from core.runtime import graph
class Orchestrator:
    def __init__(self): self.db=DB()
    def run(self,request,market='USA',industry='birthday candles',quantity=20,task_id=None):
        tid=task_id or uuid.uuid4().hex[:8]; t0=time.time()
        state={'task_id':tid,'request':request,'market':market,'industry':industry,
               'quantity':int(quantity or 20),'nodes':[],'companies':[],'profiles':[],
               'analyses':[],'letters':[],'success':False,
               'node_reports':{},'reflection':{'count':0,'history':[]},'strategy':{},'query_override':None}
        def persist(st):
            res={k:v for k,v in st.items() if k!='traceback'}
            self.db.save_task(tid,request,'running',res)
        persist(state)
        state=graph.run_graph(state,persist)
        abort=state.get('abort')
        status={'failed':'failed','failed_gate':'failed_gate','done_degraded':'done_degraded','error':'error'}.get(abort,'done')
        state['success']=status in ('done','done_degraded')
        state['duration_sec']=round(time.time()-t0,2)
        res={k:v for k,v in state.items() if k!='traceback'}
        self.db.save_task(tid,request,status,res)
        return res
