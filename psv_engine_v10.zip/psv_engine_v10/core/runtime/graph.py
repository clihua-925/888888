# -*- coding: utf-8 -*-
"""v15 ExpertGraph 编排层：LangGraph 状态图（SqliteSaver 检查点 + 反思循环边）。
图拓扑：ICP→STRATEGY→A_COLLECT⇢(验收失败→REFLECT→A_COLLECT)→MINING→HARVEST→CLEAN→A_GATE⇢(→REFLECT)→USITC→RANK→CONTACT→AUDIT⇢(审核不过→CORRECT→AUDIT)→PROFILE→ANALYSIS→OUTREACH
A_COLLECT / A_GATE 验收不过时走条件边到 REFLECT，诊断开方后回到 A_COLLECT 重跑，≤REFLECT_MAX_ROUNDS 轮。
CONTACT 后新增 AUDIT 节点，审核不通过时进入 CORRECT 修正节点，修正后重新审核，直到通过或达到最大重试次数。
langgraph 缺失时自动降级为等价的手写循环执行器，共享同一套节点函数与逐节点落盘快照。"""
import time,sqlite3,traceback
from pathlib import Path
from typing import TypedDict
from core.config import settings
from core.runtime import nodes as N
class S(TypedDict,total=False):
    task_id:str; request:str; market:str; industry:str; quantity:int
    icp:dict; strategy:dict; query_override:list
    companies:list; new_companies:list; suppliers:list; supplier_new:list
    harvest:dict; usitc:dict; gate:dict; collect_gate:dict; evolution:dict
    profiles:list; analyses:list; letters:list; nodes:list
    node_reports:dict; reflection:dict
    source:str; source_errors:list; known_count:int; dropped_count:int
    abort:str; skip_llm:bool; error:str; warning:str; success:bool; duration_sec:float
    engine:str; traceback:str
    _reflect:str  # 反思触发标记：A_COLLECT/A_GATE 验收失败时置位，路由到 REFLECT
    # v2 新增：联系方式审核与修正
    contact_leads:list          # 补全后的 lead 列表
    audit_results:dict          # {norm: audit_report}
    corrections:dict            # {norm: suggest_dict}
    audit_retry_count:int       # 当前修正循环次数
    audit_max_retries:int       # 最大修正次数，默认 3
    audit_pass:bool             # 本轮审核是否通过
ORDER=['ICP','STRATEGY','A_COLLECT','SUPPLIER_MINING','REVERSE_HARVEST','CLEAN_VERIFY',
       'A_GATE','USITC','RANK','CONTACT','B_PROFILE','C_ANALYSIS','D_OUTREACH','LEARN']
FN={'ICP':N.n_icp,'STRATEGY':N.n_strategy,'A_COLLECT':N.n_collect,'SUPPLIER_MINING':N.n_supplier_mining,
    'REVERSE_HARVEST':N.n_reverse_harvest,'CLEAN_VERIFY':N.n_clean_verify,'A_GATE':N.n_gate,
    'REFLECT':N.n_reflect,'USITC':N.n_usitc,'RANK':N.n_rank,'CONTACT':N.n_contact,
    'AUDIT':N.n_audit,'CORRECT':N.n_correct,
    'B_PROFILE':N.n_profile,'C_ANALYSIS':N.n_analysis,'D_OUTREACH':N.n_outreach,'LEARN':N.n_learn}
REFLECT_AFTER={'A_COLLECT','A_GATE'}  # 这两个节点验收失败可触发反思回路
CONTRACTS={'STRATEGY':('icp',),'A_COLLECT':('market','industry','quantity'),'REVERSE_HARVEST':('task_id',),
           'CLEAN_VERIFY':('companies',),'A_GATE':('new_companies',),'RANK':('new_companies',),
           'B_PROFILE':('new_companies','icp'),'C_ANALYSIS':('new_companies',),'D_OUTREACH':('new_companies',),
           'REFLECT':('_reflect',)}
SKIP_ON_KNOWN={'A_GATE','USITC','RANK','CONTACT','B_PROFILE','C_ANALYSIS','D_OUTREACH'}  # 全部已知公司时跳过
def _entry(name,ok,note='',dur=0.0,skipped=False):
    e={'node':name,'success':ok}
    if skipped: e['skipped']=True
    if note: e['note']=note
    if dur: e['duration']=round(dur,2)
    return e
def _exec(state,name,fn,persist):
    """节点包装器：abort 短路 → 已知跳段 → 契约校验 → 执行 → 快照落盘。任何异常不外溢。"""
    if state.get('abort'):
        state['nodes']=state.get('nodes',[])+[_entry(name,True,'已中止，跳过',skipped=True)]; return state
    if state.get('skip_llm') and name in SKIP_ON_KNOWN:
        state['nodes']=state.get('nodes',[])+[_entry(name,True,'候选均已入库，跳过',skipped=True)]
        persist(state); return state
    missing=[k for k in CONTRACTS.get(name,()) if state.get(k) is None]
    if missing:
        state['nodes']=state.get('nodes',[])+[_entry(name,False,'契约校验失败: 缺输入 '+','.join(missing))]
        state['abort']='error'; state['error']=f'{name} 契约校验失败：缺输入 {missing}（上游节点未产出）'
        persist(state); return state
    t0=time.time()
    try:
        up=fn(state) or {}
        state.update(up)
        ok=up.get('_success',True); note=up.get('_note','')
        state.pop('_success',None); state.pop('_note',None)
        state['nodes']=state.get('nodes',[])+[_entry(name,ok,note,time.time()-t0)]
    except Exception as e:
        state['nodes']=state.get('nodes',[])+[_entry(name,False,str(e)[:120],time.time()-t0)]
        state['abort']='error'; state['error']=f'{name} 节点异常: {str(e)[:300]}'
        state['traceback']=traceback.format_exc()[-800:]
    persist(state); return state
# ---------- LangGraph 路径（带反思循环边）----------
def _lg_available():
    try:
        import langgraph.graph  # noqa
        return True
    except Exception:
        return False
def _checkpointer():
    try:
        from langgraph.checkpoint.sqlite import SqliteSaver
        fp=str(Path(settings.DATABASE_PATH).parent/'lg_checkpoints.db')
        conn=sqlite3.connect(fp,check_same_thread=False)
        saver=SqliteSaver(conn)
        try: saver.setup()
        except Exception: pass
        return saver
    except Exception:
        return None
def _route_after(st,nxt):
    """条件路由：abort→收尾；_reflect 置位→REFLECT；否则顺序向下"""
    if st.get('abort'): return 'END'
    if st.get('_reflect'): return 'REFLECT'
    return nxt
def _route_after_audit(st):
    """审核后路由：abort→收尾；审核通过或达到最大重试→B_PROFILE；否则→CORRECT"""
    if st.get('abort'): return 'END'
    if st.get('audit_pass') or st.get('audit_retry_count',0) >= st.get('audit_max_retries',3):
        return 'B_PROFILE'
    return 'CORRECT'
def run_graph(state,persist):
    """优先 LangGraph；任何环节装不上/编译失败都回退手写循环，功能等价。"""
    if _lg_available():
        try:
            from langgraph.graph import StateGraph,END
            g=StateGraph(S)
            channels=set(S.__annotations__)
            for name in ORDER+['REFLECT','AUDIT','CORRECT']:
                def make(nm):
                    def call(st):
                        out=_exec(dict(st),nm,FN[nm],persist)
                        return {k:v for k,v in out.items() if k in channels}  # 只回传声明过的通道
                    return call
                g.add_node(name,make(name))
            g.set_entry_point('ICP')
            g.add_edge('ICP','STRATEGY'); g.add_edge('STRATEGY','A_COLLECT')
            g.add_conditional_edges('A_COLLECT',lambda st:_route_after(st,'SUPPLIER_MINING'),
                {'SUPPLIER_MINING':'SUPPLIER_MINING','REFLECT':'REFLECT','END':END})
            g.add_edge('SUPPLIER_MINING','REVERSE_HARVEST'); g.add_edge('REVERSE_HARVEST','CLEAN_VERIFY')
            g.add_edge('CLEAN_VERIFY','A_GATE')
            g.add_conditional_edges('A_GATE',lambda st:_route_after(st,'USITC'),
                {'USITC':'USITC','REFLECT':'REFLECT','END':END})
            g.add_edge('REFLECT','A_COLLECT')  # 反思回路：带着处方重跑采集
            g.add_edge('USITC','RANK'); g.add_edge('RANK','CONTACT')
            # 新增审核与修正闭环
            g.add_edge('CONTACT','AUDIT')
            g.add_conditional_edges('AUDIT',_route_after_audit,
                {'B_PROFILE':'B_PROFILE','CORRECT':'CORRECT','END':END})
            g.add_edge('CORRECT','AUDIT')  # 修正后重新审核
            g.add_edge('B_PROFILE','C_ANALYSIS'); g.add_edge('C_ANALYSIS','D_OUTREACH')
            g.add_edge('D_OUTREACH','LEARN')
            g.add_edge('LEARN','END')
            saver=_checkpointer()
            app=g.compile(checkpointer=saver)
            cfg={'configurable':{'thread_id':state['task_id']},'recursion_limit':150}
            out=app.invoke(state,cfg)
            state.update(out or {}); state['engine']='langgraph'
            return state
        except Exception as e:
            state['nodes']=state.get('nodes',[])+[_entry('ENGINE',False,'LangGraph失败，回退循环执行器: '+str(e)[:120])]
            persist(state)
    # ---- 手写循环执行器（与状态图等价，支持反思回路）----
    done={e.get('node') for e in state.get('nodes',[]) if e.get('success')}
    reflected=False; i=0
    while i<len(ORDER):
        name=ORDER[i]
        if not reflected and name in done: i+=1; continue  # 崩溃恢复：已成功的节点不重跑
        state=_exec(state,name,FN[name],persist)
        if name in REFLECT_AFTER and state.get('_reflect') and not state.get('abort'):
            state=_exec(state,'REFLECT',FN['REFLECT'],persist); reflected=True
            i=ORDER.index('A_COLLECT'); continue  # 带着处方回到采集重跑
        # 手写循环特殊处理 CONTACT 后的审核与修正
        if name=='CONTACT' and not state.get('abort'):
            # 执行审核
            state=_exec(state,'AUDIT',FN['AUDIT'],persist)
            # 若不通过且未达重试上限，执行修正并重新审核
            while not state.get('audit_pass') and state.get('audit_retry_count',0) < state.get('audit_max_retries',3) and not state.get('abort'):
                state=_exec(state,'CORRECT',FN['CORRECT'],persist)
                state=_exec(state,'AUDIT',FN['AUDIT'],persist)
        i+=1
    state.setdefault('engine','sequential')
    return state