import json, sqlite3, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from core.config import settings
from core.system import PSVSystem
from core.config.industry import list_industries

SYS = PSVSystem()

HTML = """<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PSV</title>
<style>
body { font-family: Arial; margin: 0; display: flex; height: 100vh; }
#sidebar { width: 180px; background: #222; color: white; padding: 10px; }
#sidebar button { display: block; width: 100%; background: none; border: none; color: white; padding: 10px; text-align: left; cursor: pointer; }
#sidebar button:hover { background: #444; }
#main { flex: 1; padding: 20px; overflow: auto; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #ccc; padding: 5px; font-size: 12px; }
</style>
</head>
<body>
<div id="sidebar">
  <button data-page="dash">Dashboard</button>
  <button data-page="workbench">Workbench</button>
  <button data-page="leads">Leads</button>
  <button data-page="comm">Comm</button>
</div>
<div id="main">
  <div id="page-dash">
    <h2>Dashboard</h2>
    <div id="dash_data">Loading...</div>
  </div>
  <div id="page-workbench" style="display:none">
    <h2>Workbench</h2>
    <div>
      <input id="req" value="Find US birthday candle importers" size="30">
      <select id="market"><option>USA</option><option>CAN</option></select>
      <select id="ind"></select>
      <input id="qty" value="20" size="3">
      <button id="run_btn">RUN</button>
      <span id="hint"></span>
    </div>
    <div id="task_detail"></div>
    <h3>Recent Tasks</h3>
    <div id="tasks_data"></div>
  </div>
  <div id="page-leads" style="display:none">
    <h2>Leads</h2>
    <div id="leads_data"></div>
  </div>
  <div id="page-comm" style="display:none">
    <h2>Comm</h2>
    <div id="comm_data"></div>
  </div>
</div>
<script>
function showPage(page) {
  var pages = ['dash', 'workbench', 'leads', 'comm'];
  for (var i = 0; i < pages.length; i++) {
    document.getElementById('page-' + pages[i]).style.display = 'none';
  }
  document.getElementById('page-' + page).style.display = 'block';
  if (page === 'dash') loadDash();
  if (page === 'workbench') { loadIndustries(); loadTasks(); }
  if (page === 'leads') loadLeads();
  if (page === 'comm') loadComm();
}

function fetchJSON(url) {
  return fetch(url).then(function(r) { return r.json(); });
}

function loadDash() {
  fetchJSON('/api/stats').then(function(d) {
    var el = document.getElementById('dash_data');
    el.innerHTML = '';
    var parts = [
      ['Companies', d.companies_total],
      ['Suppliers', d.suppliers_total],
      ['Harvest', d.harvest_items],
      ['Runs', d.runs_total]
    ];
    for (var i = 0; i < parts.length; i++) {
      var p = document.createElement('p');
      p.textContent = parts[i][0] + ': ' + parts[i][1];
      el.appendChild(p);
    }
  }).catch(function(e) {
    document.getElementById('dash_data').textContent = 'Error: ' + e;
  });
}

function loadIndustries() {
  fetchJSON('/api/industries').then(function(d) {
    var sel = document.getElementById('ind');
    sel.innerHTML = '';
    var list = d.industries || [];
    for (var i = 0; i < list.length; i++) {
      var opt = document.createElement('option');
      opt.value = list[i].key;
      opt.textContent = list[i].name;
      sel.appendChild(opt);
    }
  }).catch(function(e) {});
}

function loadTasks() {
  fetchJSON('/api/tasks').then(function(d) {
    var container = document.getElementById('tasks_data');
    container.innerHTML = '';
    var tasks = d.tasks || [];
    var table = document.createElement('table');
    var header = table.insertRow();
    var h1 = header.insertCell(0); h1.textContent = 'ID';
    var h2 = header.insertCell(1); h2.textContent = 'Status';
    var h3 = header.insertCell(2); h3.textContent = 'Request';
    for (var i = 0; i < tasks.length; i++) {
      var row = table.insertRow();
      var c1 = row.insertCell(0);
      var a = document.createElement('a');
      a.href = 'javascript:void(0)';
      a.textContent = tasks[i].task_id;
      a.onclick = (function(id) { return function() { loadTaskDetail(id); }; })(tasks[i].task_id);
      c1.appendChild(a);
      row.insertCell(1).textContent = tasks[i].status;
      row.insertCell(2).textContent = tasks[i].request;
    }
    container.appendChild(table);
  }).catch(function(e) {
    document.getElementById('tasks_data').textContent = 'Error: ' + e;
  });
}

function loadTaskDetail(id) {
  fetchJSON('/api/task/' + id).then(function(d) {
    var r = d.result || {};
    var nodes = r.nodes || [];
    var container = document.getElementById('task_detail');
    container.innerHTML = '';
    var h = document.createElement('h4');
    h.textContent = 'Task ' + id;
    container.appendChild(h);
    var table = document.createElement('table');
    var header = table.insertRow();
    var h1 = header.insertCell(0); h1.textContent = 'Node';
    var h2 = header.insertCell(1); h2.textContent = 'Success';
    var h3 = header.insertCell(2); h3.textContent = 'Note';
    for (var i = 0; i < nodes.length; i++) {
      var row = table.insertRow();
      row.insertCell(0).textContent = nodes[i].node;
      row.insertCell(1).textContent = nodes[i].success ? 'Yes' : 'No';
      row.insertCell(2).textContent = nodes[i].note || '';
    }
    container.appendChild(table);
  }).catch(function(e) {
    document.getElementById('task_detail').textContent = 'Error: ' + e;
  });
}

function loadLeads() {
  fetchJSON('/api/leads?limit=50').then(function(d) {
    var container = document.getElementById('leads_data');
    container.innerHTML = '';
    var rows = d.leads || [];
    var table = document.createElement('table');
    var header = table.insertRow();
    var h1 = header.insertCell(0); h1.textContent = 'Company';
    var h2 = header.insertCell(1); h2.textContent = 'Country';
    var h3 = header.insertCell(2); h3.textContent = 'Kind';
    var h4 = header.insertCell(3); h4.textContent = 'Industry';
    for (var i = 0; i < rows.length; i++) {
      var row = table.insertRow();
      row.insertCell(0).textContent = rows[i].name;
      row.insertCell(1).textContent = rows[i].country;
      row.insertCell(2).textContent = rows[i].kind;
      row.insertCell(3).textContent = rows[i].industry || '-';
    }
    container.appendChild(table);
  }).catch(function(e) {
    document.getElementById('leads_data').textContent = 'Error: ' + e;
  });
}

function loadComm() {
  fetchJSON('/api/leads?zone=dev&kind=importer').then(function(d) {
    var container = document.getElementById('comm_data');
    container.innerHTML = '';
    var rows = d.leads || [];
    var ul = document.createElement('ul');
    for (var i = 0; i < rows.length; i++) {
      var li = document.createElement('li');
      li.textContent = rows[i].name;
      ul.appendChild(li);
    }
    container.appendChild(ul);
  }).catch(function(e) {
    document.getElementById('comm_data').textContent = 'Error: ' + e;
  });
}

document.addEventListener('DOMContentLoaded', function() {
  var buttons = document.querySelectorAll('#sidebar button');
  for (var i = 0; i < buttons.length; i++) {
    buttons[i].addEventListener('click', function() {
      showPage(this.getAttribute('data-page'));
    });
  }
  document.getElementById('run_btn').addEventListener('click', function() {
    var req = document.getElementById('req').value;
    var market = document.getElementById('market').value;
    var industry = document.getElementById('ind').value;
    var qty = document.getElementById('qty').value;
    document.getElementById('hint').textContent = 'Starting...';
    fetch('/api/task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ request: req, market: market, industry: industry, quantity: +qty })
    }).then(function(r) { return r.json(); }).then(function(d) {
      document.getElementById('hint').textContent = 'Task ID: ' + d.task_id;
      loadTasks();
    }).catch(function(e) {
      document.getElementById('hint').textContent = 'Error: ' + e;
    });
  });
  loadDash();
});
</script>
</body>
</html>"""

def _stats():
    out = {'companies_total': 0, 'suppliers_total': 0, 'suppliers_unharvested': 0, 'harvest_items': 0, 'runs_total': 0}
    try:
        conn = sqlite3.connect(settings.DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        out['companies_total'] = conn.execute('SELECT COUNT(*) FROM company_state').fetchone()[0]
        out['suppliers_total'] = conn.execute('SELECT COUNT(*) FROM suppliers').fetchone()[0]
        out['suppliers_unharvested'] = conn.execute('SELECT COUNT(*) FROM suppliers WHERE harvested_at IS NULL').fetchone()[0]
        out['harvest_items'] = conn.execute("SELECT COALESCE(SUM(items),0) FROM harvest_log WHERE status='ok'").fetchone()[0]
        out['runs_total'] = conn.execute('SELECT COUNT(*) FROM search_runs').fetchone()[0]
        conn.close()
    except Exception:
        pass
    return out

class H(BaseHTTPRequestHandler):
    def _s(self, o, code=200, html=False):
        b = o.encode() if html else json.dumps(o, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'text/html; charset=utf-8' if html else 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path == '/':
            return self._s(HTML, html=True)
        if self.path == '/api/stats':
            return self._s(_stats())
        if self.path == '/api/industries':
            return self._s({'industries': list_industries()})
        if self.path == '/api/leads':
            from core.memory.db import DB
            db = DB()
            rows = db.list_leads(limit=50)
            return self._s({'leads': rows})
        if self.path == '/api/tasks':
            from core.memory.db import DB
            db = DB()
            with db.c() as conn:
                conn.row_factory = sqlite3.Row
                tasks = [dict(r) for r in conn.execute('SELECT task_id,request,status FROM tasks ORDER BY updated_at DESC LIMIT 10')]
            return self._s({'tasks': tasks})
        import re
        m = re.match(r'/api/task/(\w+)', self.path)
        if m:
            x = SYS.get(m.group(1))
            return self._s(x or {'error':'not found'}, 200 if x else 404)
        return self._s({'error':'not found'}, 404)

    def do_POST(self):
        if self.path == '/api/task':
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length).decode() or '{}')
            tid = SYS.start(body.get('request',''), body.get('market','USA'), body.get('industry','candle'), int(body.get('quantity',20)))
            return self._s({'task_id': tid})
        return self._s({'error':'not found'}, 404)

    def log_message(self, *a):
        pass

def run():
    srv = ThreadingHTTPServer((settings.WEB_HOST, settings.WEB_PORT), H)
    print('Server running at http://localhost:' + str(settings.WEB_PORT))
    srv.serve_forever()
