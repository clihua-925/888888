# -*- coding: utf-8 -*-
"""Contact Discovery Agent — 联系人发现智能体

负责：寻找联系人、职位、邮箱、销售入口
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import get_llm


class ContactDiscoveryAgent(BaseAgent):
    """联系人发现 Agent。"""

    def __init__(self):
        super().__init__("contact_discovery")
        self.llm = get_llm()

    def execute(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()
        company_pool = request.input_data.get("company_pool", [])

        try:
            contacts = []
            for company in company_pool[:15]:
                name = company.get("name", "")
                website = company.get("website", "")
                industry = company.get("industry", "")

                prompt = f"""请为以下企业推测关键联系人信息：

企业：{name}
行业：{industry}
网站：{website}

请输出 1-3 个关键联系人：
[
  {{
    "name": "姓名（如无法确定可写'Unknown'）",
    "title": "职位（如 Purchasing Manager, CEO, Import Director）",
    "email": "推测邮箱格式（如 info@company.com 或 first.last@company.com）",
    "department": "部门",
    "is_decision_maker": true/false,
    "confidence": 0.0-1.0,
    "discovery_method": "llm_inference"
  }}
]

注意：只输出 JSON 数组。如果信息不足，请降低 confidence。"""

                llm_result = self.llm.chat(prompt=prompt, temperature=0.5, max_tokens=2000)
                contact_list = llm_result.get("parsed_json") or []

                if isinstance(contact_list, list):
                    for c in contact_list:
                        contacts.append({
                            "id": f"ctc-{name.replace(' ', '-')[:20]}-{c.get('name', 'unknown')[:10]}",
                            "company_id": company.get("id", ""),
                            "company_name": name,
                            "name": c.get("name", "Unknown"),
                            "title": c.get("title", ""),
                            "email": c.get("email", ""),
                            "department": c.get("department", ""),
                            "is_decision_maker": c.get("is_decision_maker", False),
                            "confidence": c.get("confidence", 0.3),
                            "discovery_method": c.get("discovery_method", "llm"),
                        })

            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                result={"contacts": contacts, "total_found": len(contacts)},
                confidence=ConfidenceLevel.MEDIUM,
                evidence=[f"发现 {len(contacts)} 个联系人"],
                next_action="lead_scoring",
                status=AgentStatus.SUCCESS,
                duration_ms=int((time.time() - t0) * 1000),
            )
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
