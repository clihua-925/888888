# -*- coding: utf-8 -*-
"""Lead Scoring Agent — 客户评分智能体

负责：客户评分
评分维度：企业实力、采购可能、匹配程度、成交概率
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import get_llm


class LeadScoringAgent(BaseAgent):
    """客户评分 Agent。"""

    def __init__(self):
        super().__init__("lead_scoring")
        self.llm = get_llm()

    def execute(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()
        company_pool = request.input_data.get("company_pool", [])
        contacts = request.input_data.get("contacts", [])

        try:
            scored_customers = []
            for company in company_pool[:20]:
                company_id = company.get("id", "")
                company_contacts = [c for c in contacts if c.get("company_id") == company_id]
                has_decision_maker = any(c.get("is_decision_maker") for c in company_contacts)
                contact_count = len(company_contacts)

                # 多维度评分算法
                credibility = company.get("credibility_score", 0.5)
                procurement = company.get("procurement_probability", 0.0)
                match = company.get("match_score", 0.0)
                website_score = 0.3 if company.get("website") else 0.0
                enriched_score = 0.2 if company.get("enriched") else 0.0
                contact_score = min(contact_count * 0.1, 0.3)
                decision_maker_score = 0.2 if has_decision_maker else 0.0

                # 综合评分
                company_strength = min(credibility + website_score + enriched_score, 1.0)
                purchase_likelihood = min(procurement + match * 0.5, 1.0)
                match_degree = match
                deal_probability = min(
                    (company_strength * 0.3 + purchase_likelihood * 0.3 + match_degree * 0.2 +
                     contact_score * 0.1 + decision_maker_score * 0.1),
                    1.0
                )

                # 客户等级
                if deal_probability >= 0.8:
                    tier = "S"
                elif deal_probability >= 0.6:
                    tier = "A"
                elif deal_probability >= 0.4:
                    tier = "B"
                elif deal_probability >= 0.2:
                    tier = "C"
                else:
                    tier = "D"

                # 开发优先级 (1-10)
                priority = max(1, min(10, int((1 - deal_probability) * 10)))

                scored_customers.append({
                    "id": f"cus-{company_id}",
                    "company_id": company_id,
                    "company_name": company.get("name", ""),
                    "customer_level": tier,
                    "customer_value": round(company_strength, 2),
                    "match_score": round(match_degree, 2),
                    "deal_probability": round(deal_probability, 2),
                    "development_priority": priority,
                    "follow_up_status": "new",
                    "tags": [company.get("supply_chain_role", ""), company.get("industry", "")],
                    "notes": f"企业实力: {company_strength:.2f}, 采购可能: {purchase_likelihood:.2f}, 联系人: {contact_count}",
                    "scoring_details": {
                        "company_strength": round(company_strength, 2),
                        "purchase_likelihood": round(purchase_likelihood, 2),
                        "match_degree": round(match_degree, 2),
                        "contact_score": round(contact_score, 2),
                        "decision_maker_score": round(decision_maker_score, 2),
                    },
                })

            # 按成交概率排序
            scored_customers.sort(key=lambda x: x["deal_probability"], reverse=True)

            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                result={"customers": scored_customers, "scored_count": len(scored_customers)},
                confidence=ConfidenceLevel.HIGH,
                evidence=[f"评分 {len(scored_customers)} 家客户", "多维度算法: 企业实力×0.3 + 采购可能×0.3 + 匹配度×0.2 + 联系人×0.1 + 决策人×0.1"],
                next_action="sales_strategy",
                status=AgentStatus.SUCCESS,
                duration_ms=int((time.time() - t0) * 1000),
            )
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
