# -*- coding: utf-8 -*-
"""Market Research Agent — 市场研究智能体

负责：国家市场分析、产品趋势、行业分析、市场机会
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import get_llm
from tools.data_source_manager import DataSourceManager


class MarketResearchAgent(BaseAgent):
    """市场研究 Agent。"""

    def __init__(self):
        super().__init__("market_research")
        self.llm = get_llm()
        self.data_manager = DataSourceManager()

    def execute(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")

        try:
            # 1. 使用工具层获取市场数据
            tool_result = self.data_manager.get_market_data(product, market)
            market_data = tool_result.data if tool_result.is_success() else {}

            # 2. LLM 深度分析
            prompt = f"""作为外贸市场分析专家，请分析以下产品的目标市场：

产品：{product}
目标市场：{market}
已知数据：{market_data}

请输出结构化分析：
{{
  "market_size": "市场规模估算",
  "growth_rate": "年增长率",
  "key_trends": ["趋势1", "趋势2", "趋势3"],
  "competitive_landscape": "竞争格局描述",
  "entry_barriers": ["壁垒1", "壁垒2"],
  "opportunities": ["机会1", "机会2"],
  "risks": ["风险1", "风险2"],
  "recommendation": "进入市场建议"
}}

只输出 JSON。"""

            llm_result = self.llm.chat(prompt=prompt, temperature=0.5, json_mode=True)
            analysis = llm_result.get("parsed_json") or {}

            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                result={
                    "market": market,
                    "product": product,
                    "analysis": analysis,
                    "data_sources": tool_result.source if tool_result.is_success() else "llm_only",
                },
                confidence=ConfidenceLevel.HIGH if tool_result.is_success() else ConfidenceLevel.MEDIUM,
                evidence=["LLM市场分析", f"数据源: {tool_result.source if tool_result.is_success() else 'llm_fallback'}"],
                next_action="company_discovery",
                status=AgentStatus.SUCCESS,
                duration_ms=int((time.time() - t0) * 1000),
            )
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
