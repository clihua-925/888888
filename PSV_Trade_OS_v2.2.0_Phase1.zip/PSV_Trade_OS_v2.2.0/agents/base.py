# -*- coding: utf-8 -*-
"""Base Agent — 所有 Agent 的基类

强制规范：
- 所有 Agent 必须继承此类
- 所有 Agent 必须通过 execute(request: AgentRequest) -> AgentResponse 执行
- 禁止直接调用内部变量
"""
from abc import ABC, abstractmethod
from contracts.agent_contract import AgentRequest, AgentResponse


class BaseAgent(ABC):
    """Agent 基类。"""

    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    def execute(self, request: AgentRequest) -> AgentResponse:
        """执行 Agent 逻辑。

        Args:
            request: AgentRequest 输入契约

        Returns:
            AgentResponse 输出契约
        """
        pass
