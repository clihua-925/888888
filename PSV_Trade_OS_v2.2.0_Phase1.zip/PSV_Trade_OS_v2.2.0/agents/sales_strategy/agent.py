# -*- coding: utf-8 -*-
"""Sales Strategy Agent — 销售策略智能体

负责：生成开发策略、邮件方向、跟进建议
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import get_llm


class SalesStrategyAgent(BaseAgent):
    """销售策略 Agent。"""

    def __init__(self):
        super().__init__("sales_strategy")
        self.llm = get_llm()

    def execute(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()
        customer_pool = request.input_data.get("customer_pool", [])
        company_profiles = request.input_data.get("company_profiles", {})
        market_analysis = request.input_data.get("market_analysis", {})

        try:
            opportunities = []
            for customer in customer_pool[:10]:
                company_id = customer.get("company_id", "")
                company_name = customer.get("company_name", "")
                tier = customer.get("customer_level", "C")
                deal_prob = customer.get("deal_probability", 0.0)

                prompt = f"""请为以下高潜力客户生成开发策略：

客户：{company_name}
客户等级：{tier}
成交概率：{deal_prob}
市场分析：{market_analysis.get('analysis', {})}

请输出：
{{
  "strategy": "具体开发策略（200字以内）",
  "email_subject": "开发邮件主题",
  "email_body": "开发邮件正文（300字以内，专业、简洁、有针对性）",
  "follow_up_plan": [
    {{"day": 3, "action": "发送跟进邮件", "content": "..."}},
    {{"day": 7, "action": "LinkedIn连接", "content": "..."}},
    {{"day": 14, "action": "电话/视频会议", "content": "..."}}
  ],
  "value_proposition": "核心价值主张",
  "objection_handling": ["常见异议1: 回应", "常见异议2: 回应"]
}}

只输出 JSON。"""

                llm_result = self.llm.chat(prompt=prompt, temperature=0.6, max_tokens=3000)
                strategy = llm_result.get("parsed_json") or {}

                opportunities.append({
                    "id": f"opp-{company_id}-{int(time.time())}",
                    "company_id": company_id,
                    "title": f"开发 {company_name} — {tier}级客户",
                    "description": strategy.get("strategy", ""),
                    "estimated_value": round(deal_prob * 100000, 2),  # 假设客单价10万
                    "probability": round(deal_prob, 2),
                    "strategy": strategy.get("strategy", ""),
                    "email_template": {
                        "subject": strategy.get("email_subject", ""),
                        "body": strategy.get("email_body", ""),
                    },
                    "follow_up_plan": strategy.get("follow_up_plan", []),
                    "value_proposition": strategy.get("value_proposition", ""),
                    "objection_handling": strategy.get("objection_handling", []),
                    "status": "open",
                })

            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                result={"opportunities": opportunities, "strategy_count": len(opportunities)},
                confidence=ConfidenceLevel.HIGH,
                evidence=[f"生成 {len(opportunities)} 个开发策略", "基于客户等级和成交概率个性化生成"],
                next_action="report",
                status=AgentStatus.SUCCESS,
                duration_ms=int((time.time() - t0) * 1000),
            )
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
