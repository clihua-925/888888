# -*- coding: utf-8 -*-
"""Company Discovery Agent — 企业发现智能体

负责：寻找进口商、买家、经销商、渠道商
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from tools.data_source_manager import DataSourceManager


class CompanyDiscoveryAgent(BaseAgent):
    """企业发现 Agent。"""

    def __init__(self):
        super().__init__("company_discovery")
        self.data_manager = DataSourceManager()

    def execute(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()
        product = request.input_data.get("product", "")
        market = request.input_data.get("market", "")
        target_customer = request.input_data.get("target_customer", "importer")

        try:
            # 通过工具层发现企业（非直接LLM）
            tool_result = self.data_manager.discover_companies(product, market, target_customer)
            companies = tool_result.data.get("companies", []) if tool_result.is_success() else []

            # 去重与标准化
            seen = set()
            unique_companies = []
            for c in companies:
                key = c.get("name", "").lower().strip()
                if key and key not in seen:
                    seen.add(key)
                    unique_companies.append({
                        "id": f"cmp-{key.replace(' ', '-').replace('.', '')[:30]}",
                        "name": c.get("name", ""),
                        "country": c.get("country", market),
                        "website": c.get("website", ""),
                        "industry": c.get("industry", ""),
                        "main_products": c.get("main_products", []),
                        "company_size": c.get("company_size", "unknown"),
                        "supply_chain_role": target_customer,
                        "data_source": tool_result.source,
                        "credibility_score": c.get("credibility_score", 0.5),
                    })

            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                result={"companies": unique_companies, "total_found": len(unique_companies)},
                confidence=ConfidenceLevel.HIGH if len(unique_companies) > 0 else ConfidenceLevel.LOW,
                evidence=[f"发现 {len(unique_companies)} 家企业", f"数据源: {tool_result.source}"],
                next_action="company_enrichment",
                status=AgentStatus.SUCCESS,
                duration_ms=int((time.time() - t0) * 1000),
            )
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
