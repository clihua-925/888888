# -*- coding: utf-8 -*-
"""Company Enrichment Agent — 企业信息补全智能体

负责：企业信息补全、网站分析、供应链关系挖掘
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import get_llm
from tools.data_source_manager import DataSourceManager


class CompanyEnrichmentAgent(BaseAgent):
    """企业补全 Agent。"""

    def __init__(self):
        super().__init__("company_enrichment")
        self.llm = get_llm()
        self.data_manager = DataSourceManager()

    def execute(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()
        company_pool = request.input_data.get("company_pool", [])

        try:
            enriched = []
            for company in company_pool[:20]:  # 限制每次处理数量
                name = company.get("name", "")
                website = company.get("website", "")

                # 1. 尝试网站抓取
                web_data = {}
                if website:
                    tool_result = self.data_manager.scrape_website(website)
                    if tool_result.is_success():
                        web_data = tool_result.data

                # 2. LLM 补全分析
                prompt = f"""请基于以下企业信息，补全企业画像：

企业名称：{name}
网站：{website}
网站抓取数据：{web_data}
已知信息：{company}

请输出：
{{
  "industry": "行业分类",
  "main_products": ["产品1", "产品2"],
  "procurement_direction": ["采购方向1"],
  "company_size": "small|medium|large|enterprise",
  "supply_chain_relations": {{"suppliers": [], "customers": [], "competitors": []}},
  "credibility_score": 0.0-1.0,
  "procurement_probability": 0.0-1.0,
  "match_score": 0.0-1.0,
  "enrichment_notes": "补全说明"
}}

只输出 JSON。"""

                llm_result = self.llm.chat(prompt=prompt, temperature=0.4, max_tokens=2000)
                enrichment = llm_result.get("parsed_json") or {}

                company.update({
                    "industry": enrichment.get("industry", company.get("industry", "")),
                    "main_products": enrichment.get("main_products", company.get("main_products", [])),
                    "procurement_direction": enrichment.get("procurement_direction", company.get("procurement_direction", [])),
                    "company_size": enrichment.get("company_size", company.get("company_size", "unknown")),
                    "supply_chain_relations": enrichment.get("supply_chain_relations", company.get("supply_chain_relations", {})),
                    "credibility_score": enrichment.get("credibility_score", company.get("credibility_score", 0.5)),
                    "procurement_probability": enrichment.get("procurement_probability", 0.0),
                    "match_score": enrichment.get("match_score", 0.0),
                    "enriched": True,
                    "enrichment_source": "llm+web" if web_data else "llm",
                })
                enriched.append(company)

            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                result={"companies": enriched, "enriched_count": len(enriched)},
                confidence=ConfidenceLevel.HIGH,
                evidence=[f"补全 {len(enriched)} 家企业信息"],
                next_action="contact_discovery",
                status=AgentStatus.SUCCESS,
                duration_ms=int((time.time() - t0) * 1000),
            )
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
