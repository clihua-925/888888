# -*- coding: utf-8 -*-
"""Trade Planner Agent — 贸易规划智能体

职责：理解外贸目标，生成执行计划。
注意：orchestrator/planner.py 是编排层的 Planner，
此文件是 Agent 层的 Planner，用于独立调用场景。
"""
from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel


class TradePlannerAgent(BaseAgent):
    """贸易规划 Agent。"""

    def __init__(self):
        super().__init__("trade_planner")

    def execute(self, request: AgentRequest) -> AgentResponse:
        from orchestrator.planner import TradePlannerAgent as Planner
        from contracts.task_contract import TaskContract

        planner = Planner()
        task = TaskContract(
            objective=request.input_data.get("objective", ""),
            product=request.input_data.get("product", ""),
            market=request.input_data.get("market", ""),
            target_customer=request.input_data.get("target_customer", "importer"),
            constraints=request.input_data.get("constraints", []),
        )
        return planner.plan(task)
