# -*- coding: utf-8 -*-
"""Report Agent — 报告生成智能体

负责：
- 汇总所有 Agent 结果
- 生成最终外贸开发报告
- 输出可执行的行动清单

修复 v2.1.0：接入 LLM 生成智能分析报告
"""
import time
from typing import Dict, List, Any

from agents.base import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import get_llm


class ReportAgent(BaseAgent):
    """报告生成 Agent。"""

    def __init__(self):
        super().__init__("report")
        self.llm = get_llm()

    def execute(self, request: AgentRequest) -> AgentResponse:
        t0 = time.time()
        market_analysis = request.input_data.get("market_analysis", {})
        company_pool = request.input_data.get("company_pool", [])
        company_profiles = request.input_data.get("company_profiles", {})
        customer_pool = request.input_data.get("customer_pool", [])
        contacts = request.input_data.get("contacts", [])
        opportunities = request.input_data.get("opportunities", [])
        agent_results = request.input_data.get("agent_results", {})

        try:
            # 构建报告上下文
            summary = {
                "market": market_analysis.get("market", ""),
                "product": market_analysis.get("product", ""),
                "companies_count": len(company_pool),
                "customers_count": len(customer_pool),
                "contacts_count": len(contacts),
                "opportunities_count": len(opportunities),
                "top_customers": [c.get("company_name", "") for c in customer_pool[:5]],
                "agent_status": {k: v.get("status") for k, v in agent_results.items()},
            }

            # LLM 生成智能报告
            prompt = f"""你是一位资深外贸总监，请基于以下数据生成一份专业的外贸开发报告：

【任务摘要】
{summary}

【市场分析】
{market_analysis.get('analysis', {})}

【客户池 TOP 10】
{customer_pool[:10]}

【商业机会】
{opportunities[:5]}

请生成结构化报告：
{{
  "executive_summary": "执行摘要（300字）",
  "market_overview": "市场概况",
  "target_customers": ["重点客户1", "重点客户2"],
  "competitive_analysis": "竞争分析",
  "action_plan": [
    {{"priority": 1, "action": "立即行动", "target": "客户名", "deadline": "3天内"}},
    {{"priority": 2, "action": "本周完成", "target": "客户名", "deadline": "7天内"}},
    {{"priority": 3, "action": "持续跟进", "target": "客户名", "deadline": "30天内"}}
  ],
  "risk_assessment": "风险评估",
  "recommendations": "战略建议",
  "expected_outcome": "预期成果"
}}

报告要求：
1. 数据驱动，引用具体数字
2. 行动清单可执行
3. 语言专业、简洁
4. 只输出 JSON"""

            llm_result = self.llm.chat(prompt=prompt, temperature=0.5, max_tokens=4000)
            report_data = llm_result.get("parsed_json") or {}

            # 补充统计信息
            report_data["statistics"] = {
                "companies_discovered": len(company_pool),
                "contacts_found": len(contacts),
                "customers_scored": len(customer_pool),
                "opportunities_generated": len(opportunities),
                "s_tier_customers": len([c for c in customer_pool if c.get("customer_level") == "S"]),
                "a_tier_customers": len([c for c in customer_pool if c.get("customer_level") == "A"]),
            }
            report_data["agent_execution_summary"] = summary["agent_status"]
            report_data["generated_at"] = time.time()

            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                result={"report": report_data},
                confidence=ConfidenceLevel.HIGH,
                evidence=["LLM智能报告生成", f"覆盖 {len(company_pool)} 家企业, {len(customer_pool)} 个客户"],
                next_action="end",
                status=AgentStatus.SUCCESS,
                duration_ms=int((time.time() - t0) * 1000),
            )
        except Exception as e:
            return AgentResponse(
                task_id=request.task_id,
                agent_name=self.name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )
