# -*- coding: utf-8 -*-
"""Database Connection — 数据库连接管理
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from shared.config.settings import settings

_engine = None
_SessionFactory = None


def get_engine():
    global _engine
    if _engine is None:
        import os
        os.makedirs(settings.DATA_DIR, exist_ok=True)
        _engine = create_engine(f"sqlite:///{settings.DATABASE_PATH}", echo=False)
    return _engine


def get_session() -> Session:
    global _SessionFactory
    if _SessionFactory is None:
        _SessionFactory = sessionmaker(bind=get_engine())
    return _SessionFactory()


class DatabaseConnection:
    def __init__(self):
        self.engine = get_engine()

    def get_session(self) -> Session:
        return get_session()
