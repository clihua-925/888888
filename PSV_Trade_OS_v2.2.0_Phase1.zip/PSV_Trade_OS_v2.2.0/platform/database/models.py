# -*- coding: utf-8 -*-
"""Database Models — 外贸业务核心数据模型

围绕外贸业务设计，非采集任务设计。
"""
import os
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

from sqlalchemy import (
    create_engine, Column, String, Text, Float, Integer,
    DateTime, JSON, Boolean, ForeignKey, Table, Index
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, Session

from shared.config.settings import settings


Base = declarative_base()

company_product = Table(
    'company_product', Base.metadata,
    Column('company_id', String(64), ForeignKey('trade_company.id')),
    Column('product_id', String(64), ForeignKey('trade_product.id'))
)


class TradeCompany(Base):
    __tablename__ = 'trade_company'
    id = Column(String(64), primary_key=True)
    name = Column(String(255), nullable=False, index=True)
    country = Column(String(100), index=True)
    website = Column(String(500))
    industry = Column(String(200))
    main_products = Column(Text)
    procurement_direction = Column(Text)
    company_size = Column(String(50))
    supply_chain_relations = Column(JSON)
    credibility_score = Column(Float, default=0.0)
    procurement_probability = Column(Float, default=0.0)
    match_score = Column(Float, default=0.0)
    data_source = Column(String(100))
    raw_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    contacts = relationship("TradeContact", back_populates="company")
    opportunities = relationship("TradeOpportunity", back_populates="company")


class TradeContact(Base):
    __tablename__ = 'trade_contact'
    id = Column(String(64), primary_key=True)
    company_id = Column(String(64), ForeignKey('trade_company.id'), index=True)
    name = Column(String(200))
    title = Column(String(200))
    email = Column(String(300))
    phone = Column(String(100))
    linkedin = Column(String(500))
    department = Column(String(100))
    is_decision_maker = Column(Boolean, default=False)
    confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)
    company = relationship("TradeCompany", back_populates="contacts")


class TradeProduct(Base):
    __tablename__ = 'trade_product'
    id = Column(String(64), primary_key=True)
    name = Column(String(255), nullable=False, index=True)
    category = Column(String(200))
    hs_code = Column(String(50))
    description = Column(Text)
    target_markets = Column(JSON)
    competitive_landscape = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)


class TradeMarket(Base):
    __tablename__ = 'trade_market'
    id = Column(String(64), primary_key=True)
    country = Column(String(100), index=True)
    region = Column(String(100))
    market_size = Column(Float)
    growth_rate = Column(Float)
    key_trends = Column(JSON)
    competitive_analysis = Column(JSON)
    entry_barriers = Column(JSON)
    updated_at = Column(DateTime, default=datetime.utcnow)


class TradeCustomerPool(Base):
    __tablename__ = 'trade_customer_pool'
    id = Column(String(64), primary_key=True)
    company_id = Column(String(64), ForeignKey('trade_company.id'), index=True)
    customer_level = Column(String(20), default="C")
    customer_value = Column(Float, default=0.0)
    match_score = Column(Float, default=0.0)
    deal_probability = Column(Float, default=0.0)
    development_priority = Column(Integer, default=5)
    follow_up_status = Column(String(50), default="new")
    assigned_to = Column(String(100))
    tags = Column(JSON)
    notes = Column(Text)
    last_contact = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class TradeOpportunity(Base):
    __tablename__ = 'trade_opportunity'
    id = Column(String(64), primary_key=True)
    company_id = Column(String(64), ForeignKey('trade_company.id'), index=True)
    title = Column(String(500))
    description = Column(Text)
    estimated_value = Column(Float)
    probability = Column(Float)
    expected_close_date = Column(DateTime)
    strategy = Column(Text)
    email_template = Column(Text)
    follow_up_plan = Column(JSON)
    status = Column(String(50), default="open")
    created_at = Column(DateTime, default=datetime.utcnow)
    company = relationship("TradeCompany", back_populates="opportunities")


class TradeTask(Base):
    __tablename__ = 'trade_task'
    id = Column(String(64), primary_key=True)
    objective = Column(Text)
    product = Column(String(255))
    market = Column(String(255))
    target_customer = Column(String(255))
    status = Column(String(50), default="pending")
    execution_plan = Column(JSON)
    final_report = Column(JSON)
    routing_path = Column(JSON)
    error_log = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = Column(DateTime)


class TradeWorkflow(Base):
    __tablename__ = 'trade_workflow'
    id = Column(String(64), primary_key=True)
    task_id = Column(String(64), ForeignKey('trade_task.id'), index=True)
    workflow_type = Column(String(50))
    current_node = Column(String(100))
    current_agent = Column(String(100))
    status = Column(String(50))
    state_snapshot = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AgentExecutionLog(Base):
    __tablename__ = 'agent_execution_log'
    id = Column(String(64), primary_key=True)
    task_id = Column(String(64), index=True)
    workflow_id = Column(String(64), index=True)
    agent_name = Column(String(100), index=True)
    node_name = Column(String(100))
    input_data = Column(JSON)
    output_data = Column(JSON)
    confidence = Column(String(20))
    evidence = Column(JSON)
    duration_ms = Column(Integer)
    status = Column(String(50))
    error = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    __table_args__ = (Index('idx_agent_task', 'task_id', 'agent_name'),)


class AuditEvent(Base):
    __tablename__ = 'audit_event'
    id = Column(String(64), primary_key=True)
    task_id = Column(String(64), index=True)
    workflow_id = Column(String(64), index=True)
    agent_id = Column(String(100))
    node = Column(String(100))
    event_type = Column(String(100), index=True)
    input_data = Column(JSON)
    output_data = Column(JSON)
    tool_call = Column(JSON)
    duration_ms = Column(Integer)
    status = Column(String(50))
    error = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    __table_args__ = (Index('idx_audit_time', 'timestamp', 'task_id'),)


class MemoryStore(Base):
    __tablename__ = 'memory_store'
    id = Column(String(64), primary_key=True)
    memory_type = Column(String(50), index=True)
    category = Column(String(100))
    key = Column(String(500), index=True)
    value = Column(JSON)
    embedding = Column(Text)
    source_task_id = Column(String(64))
    confidence = Column(Float, default=1.0)
    access_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class TradeGraphEdge(Base):
    __tablename__ = 'trade_graph_edge'
    id = Column(String(64), primary_key=True)
    source_id = Column(String(64), index=True)
    source_type = Column(String(50))
    target_id = Column(String(64), index=True)
    target_type = Column(String(50))
    relation_type = Column(String(50), index=True)
    weight = Column(Float, default=1.0)
    evidence = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


_engine = None
_SessionFactory = None


def get_engine():
    global _engine
    if _engine is None:
        db_path = settings.DATABASE_PATH
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        _engine = create_engine(f"sqlite:///{db_path}", echo=False)
    return _engine


def init_database():
    engine = get_engine()
    Base.metadata.create_all(engine)


def get_session() -> Session:
    global _SessionFactory
    if _SessionFactory is None:
        _SessionFactory = sessionmaker(bind=get_engine())
    return _SessionFactory()


class PSVDatabase:
    def __init__(self):
        self.engine = get_engine()
        init_database()

    def upsert_company(self, session: Session, data: Dict[str, Any]):
        from sqlalchemy.dialects.sqlite import insert
        stmt = insert(TradeCompany).values(**data)
        stmt = stmt.on_conflict_do_update(
            index_elements=['id'],
            set_={k: v for k, v in data.items() if k != 'id'}
        )
        session.execute(stmt)

    def upsert_customer_pool(self, session: Session, data: Dict[str, Any]):
        from sqlalchemy.dialects.sqlite import insert
        stmt = insert(TradeCustomerPool).values(**data)
        stmt = stmt.on_conflict_do_update(
            index_elements=['id'],
            set_={k: v for k, v in data.items() if k != 'id'}
        )
        session.execute(stmt)

    def upsert_opportunity(self, session: Session, data: Dict[str, Any]):
        from sqlalchemy.dialects.sqlite import insert
        stmt = insert(TradeOpportunity).values(**data)
        stmt = stmt.on_conflict_do_update(
            index_elements=['id'],
            set_={k: v for k, v in data.items() if k != 'id'}
        )
        session.execute(stmt)

    def upsert_task(self, session: Session, data: Dict[str, Any]):
        from sqlalchemy.dialects.sqlite import insert
        stmt = insert(TradeTask).values(**data)
        stmt = stmt.on_conflict_do_update(
            index_elements=['id'],
            set_={k: v for k, v in data.items() if k != 'id'}
        )
        session.execute(stmt)

    def upsert_market(self, session: Session, data: Dict[str, Any]):
        from sqlalchemy.dialects.sqlite import insert
        stmt = insert(TradeMarket).values(**data)
        stmt = stmt.on_conflict_do_update(
            index_elements=['id'],
            set_={k: v for k, v in data.items() if k != 'id'}
        )
        session.execute(stmt)

    def upsert_graph_edge(self, session: Session, data: Dict[str, Any]):
        from sqlalchemy.dialects.sqlite import insert
        stmt = insert(TradeGraphEdge).values(**data)
        stmt = stmt.on_conflict_do_update(
            index_elements=['id'],
            set_={k: v for k, v in data.items() if k != 'id'}
        )
        session.execute(stmt)
