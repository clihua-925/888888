# -*- coding: utf-8 -*-
"""Audit Logger — 审计日志记录器

所有智能行为必须可追踪。
必须能够回答：
- 哪个Agent执行？
- 为什么执行？
- 调用什么工具？
- 产生什么结果？
- 哪里失败？
"""
import time
import uuid
from typing import Dict, List, Any, Optional

from platform.database.models import AuditEvent, get_session
from shared.config.settings import settings


class AuditLogger:
    """审计日志记录器。"""

    def __init__(self):
        self.enabled = settings.AUDIT_ENABLED

    def log(
        self,
        task_id: str = "",
        workflow_id: str = "",
        agent_id: str = "",
        node: str = "",
        event_type: str = "",
        input_data: Dict = None,
        output_data: Dict = None,
        tool_call: Dict = None,
        duration_ms: int = 0,
        status: str = "",
        error: str = "",
    ) -> str:
        if not self.enabled:
            return ""

        event_id = f"aud-{uuid.uuid4().hex[:12]}"
        try:
            session = get_session()
            event = AuditEvent(
                id=event_id,
                task_id=task_id,
                workflow_id=workflow_id,
                agent_id=agent_id,
                node=node,
                event_type=event_type,
                input_data=input_data or {},
                output_data=output_data or {},
                tool_call=tool_call or {},
                duration_ms=duration_ms,
                status=status,
                error=error,
            )
            session.add(event)
            session.commit()
            session.close()
        except Exception as e:
            # 审计失败不应阻塞主流程
            pass
        return event_id

    def query(
        self,
        task_id: str = "",
        agent_id: str = "",
        event_type: str = "",
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        session = get_session()
        query = session.query(AuditEvent)
        if task_id:
            query = query.filter(AuditEvent.task_id == task_id)
        if agent_id:
            query = query.filter(AuditEvent.agent_id == agent_id)
        if event_type:
            query = query.filter(AuditEvent.event_type == event_type)
        events = query.order_by(AuditEvent.timestamp.desc()).limit(limit).all()
        result = []
        for e in events:
            result.append({
                "id": e.id,
                "task_id": e.task_id,
                "workflow_id": e.workflow_id,
                "agent_id": e.agent_id,
                "node": e.node,
                "event_type": e.event_type,
                "status": e.status,
                "duration_ms": e.duration_ms,
                "timestamp": e.timestamp.isoformat() if e.timestamp else None,
                "error": e.error,
            })
        session.close()
        return result
