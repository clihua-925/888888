# -*- coding: utf-8 -*-
"""Tracer — 执行链路追踪

用于追踪单个任务在 LangGraph 中的完整执行路径。
"""
from typing import Dict, List, Any
import time


class Tracer:
    """执行链路追踪器。"""

    def __init__(self, task_id: str = ""):
        self.task_id = task_id
        self.spans: List[Dict[str, Any]] = []

    def start_span(self, name: str, metadata: Dict = None) -> str:
        span_id = f"{self.task_id}-{name}-{time.time()}"
        self.spans.append({
            "span_id": span_id,
            "name": name,
            "start_time": time.time(),
            "end_time": None,
            "duration_ms": 0,
            "metadata": metadata or {},
            "children": [],
        })
        return span_id

    def end_span(self, span_id: str, status: str = "ok", error: str = ""):
        for span in self.spans:
            if span["span_id"] == span_id:
                span["end_time"] = time.time()
                span["duration_ms"] = int((span["end_time"] - span["start_time"]) * 1000)
                span["status"] = status
                span["error"] = error
                break

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "spans": self.spans,
            "total_duration_ms": sum(s.get("duration_ms", 0) for s in self.spans),
        }
