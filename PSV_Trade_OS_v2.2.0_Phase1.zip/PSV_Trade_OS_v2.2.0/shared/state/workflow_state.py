# -*- coding: utf-8 -*-
"""Workflow State — LangGraph workflow 状态辅助管理

支持：暂停 / 恢复 / 继续执行
"""
from typing import Dict, Any, Optional
import json
from pathlib import Path

from shared.config.settings import settings


class WorkflowStateManager:
    """工作流状态管理器。"""

    def __init__(self):
        self._dir = Path(settings.CHECKPOINT_DIR)
        self._dir.mkdir(parents=True, exist_ok=True)

    def save_state(self, workflow_id: str, state: Dict[str, Any]) -> str:
        path = self._dir / f"{workflow_id}_state.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, default=str)
        return str(path)

    def load_state(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        path = self._dir / f"{workflow_id}_state.json"
        if not path.exists():
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def list_saved_states(self) -> list:
        return [f.stem.replace("_state", "") for f in self._dir.glob("*_state.json")]
