# -*- coding: utf-8 -*-
"""Long-term Memory — 历史任务、行业知识、客户数据、执行经验

持久化存储，支持向量化检索（Phase 3 接入向量数据库）。
"""
import json
import time
import uuid
from typing import Dict, List, Any, Optional
from pathlib import Path

from contracts.memory_contract import MemoryEntry, MemoryType, MemoryCategory
from shared.config.settings import settings


class LongTermMemory:
    """长期记忆管理器。"""

    def __init__(self):
        self._store: Dict[str, MemoryEntry] = {}
        self._disk_dir = Path(settings.DATA_DIR) / "memory"
        self._disk_dir.mkdir(parents=True, exist_ok=True)
        self._load_from_disk()

    def _disk_path(self, memory_id: str) -> Path:
        return self._disk_dir / f"{memory_id}.json"

    def _load_from_disk(self) -> None:
        for f in self._disk_dir.glob("*.json"):
            try:
                with open(f, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                entry = MemoryEntry(**data)
                self._store[entry.memory_id] = entry
            except Exception:
                pass

    def save(
        self,
        category: MemoryCategory,
        key: str,
        value: Dict[str, Any],
        memory_type: MemoryType = MemoryType.LONG_TERM,
        source_task_id: str = "",
        confidence: float = 1.0,
    ) -> str:
        memory_id = f"mem-{uuid.uuid4().hex[:12]}"
        entry = MemoryEntry(
            memory_id=memory_id,
            memory_type=memory_type,
            category=category,
            key=key,
            value=value,
            source_task_id=source_task_id,
            confidence=confidence,
        )
        self._store[memory_id] = entry
        self._persist(entry)
        return memory_id

    def _persist(self, entry: MemoryEntry) -> None:
        disk_path = self._disk_path(entry.memory_id)
        try:
            with open(disk_path, "w", encoding="utf-8") as f:
                json.dump(entry.__dict__, f, ensure_ascii=False, default=str)
        except Exception:
            pass

    def query(
        self,
        category: Optional[MemoryCategory] = None,
        key_prefix: str = "",
        limit: int = 50,
    ) -> List[MemoryEntry]:
        results = []
        for entry in self._store.values():
            if category and entry.category != category:
                continue
            if key_prefix and not entry.key.startswith(key_prefix):
                continue
            results.append(entry)
        results.sort(key=lambda x: x.updated_at, reverse=True)
        return results[:limit]

    def get(self, memory_id: str) -> Optional[MemoryEntry]:
        return self._store.get(memory_id)

    def delete(self, memory_id: str) -> bool:
        if memory_id in self._store:
            del self._store[memory_id]
            disk_path = self._disk_path(memory_id)
            if disk_path.exists():
                disk_path.unlink()
            return True
        return False
