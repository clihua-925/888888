# -*- coding: utf-8 -*-
"""Short-term Memory — 当前任务状态管理

保存当前任务上下文，支持暂停/恢复。
"""
from typing import Dict, List, Any, Optional
import time


class ShortTermMemory:
    """短期记忆管理器。"""

    def __init__(self, task_id: str = ""):
        self.task_id = task_id
        self._store: Dict[str, Any] = {}
        self._history: List[Dict[str, Any]] = []

    def set(self, key: str, value: Any, ttl_seconds: int = 3600) -> None:
        self._store[key] = {
            "value": value,
            "created_at": time.time(),
            "ttl": ttl_seconds,
        }

    def get(self, key: str) -> Any:
        entry = self._store.get(key)
        if not entry:
            return None
        if time.time() - entry["created_at"] > entry["ttl"]:
            del self._store[key]
            return None
        return entry["value"]

    def append_history(self, event: Dict[str, Any]) -> None:
        event["timestamp"] = time.time()
        self._history.append(event)

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        return self._history[-limit:]

    def snapshot(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "store": {k: v["value"] for k, v in self._store.items()},
            "history": self._history,
        }

    def restore(self, snapshot: Dict[str, Any]) -> None:
        self.task_id = snapshot.get("task_id", "")
        self._store = {k: {"value": v, "created_at": time.time(), "ttl": 3600}
                       for k, v in snapshot.get("store", {}).items()}
        self._history = snapshot.get("history", [])
