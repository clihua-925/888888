# -*- coding: utf-8 -*-
"""PSV Trade Intelligence OS — 统一配置中心

原则：
- 所有模块通过此配置中心读取配置
- 禁止模块直接读取环境变量
- 禁止模块直接读取文件路径
"""
import os
from pathlib import Path
from dotenv import load_dotenv

ENV_PATH = Path(__file__).parent.parent.parent / ".env"
load_dotenv(ENV_PATH, override=True)

BASE_DIR = Path(__file__).parent.parent.parent


class Settings:
    """统一配置类。所有配置项集中在此，外部模块禁止直接访问 os.environ。"""

    SYSTEM_NAME: str = "PSV Trade Intelligence OS"
    SYSTEM_VERSION: str = "2.2.0"
    SYSTEM_CODENAME: str = "orchestrator-first"

    # Data & Database
    DATA_DIR: str = os.getenv("PSV_DATA_DIR", str(BASE_DIR / "data"))
    DATABASE_PATH: str = os.getenv("PSV_DB_PATH", str(BASE_DIR / "data" / "psv_trade_os.db"))
    CHECKPOINT_DIR: str = os.getenv("PSV_CHECKPOINT_DIR", str(BASE_DIR / "data" / "checkpoints"))

    # LLM Providers
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_BASE_URL: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    DEFAULT_LLM_MODEL: str = os.getenv("DEFAULT_LLM_MODEL", "gpt-4o")

    DEEPSEEK_API_KEY: str = os.getenv("DEEPSEEK_API_KEY", "")
    DEEPSEEK_BASE_URL: str = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

    QWEN_API_KEY: str = os.getenv("QWEN_API_KEY", "")
    QWEN_BASE_URL: str = os.getenv("QWEN_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")

    # Data Source APIs (Phase 2)
    CUSTOMS_API_KEY: str = os.getenv("CUSTOMS_API_KEY", "")
    CUSTOMS_API_URL: str = os.getenv("CUSTOMS_API_URL", "")
    SERP_API_KEY: str = os.getenv("SERP_API_KEY", "")
    B2B_PLATFORM_KEY: str = os.getenv("B2B_PLATFORM_KEY", "")

    # Execution
    MAX_AGENT_RETRIES: int = int(os.getenv("PSV_MAX_AGENT_RETRIES", "3"))
    TASK_TIMEOUT_SECONDS: int = int(os.getenv("PSV_TASK_TIMEOUT", "3600"))
    MAX_COMPANY_POOL_SIZE: int = int(os.getenv("PSV_MAX_POOL_SIZE", "500"))

    # Defaults
    DEFAULT_MARKET: str = os.getenv("PSV_DEFAULT_MARKET", "USA")
    DEFAULT_PRODUCT: str = os.getenv("PSV_DEFAULT_PRODUCT", "birthday candles")

    # Audit
    AUDIT_ENABLED: bool = os.getenv("PSV_AUDIT_ENABLED", "true").lower() == "true"
    AUDIT_RETENTION_DAYS: int = int(os.getenv("PSV_AUDIT_RETENTION", "90"))

    # WebUI
    WEBUI_HOST: str = os.getenv("PSV_WEBUI_HOST", "0.0.0.0")
    WEBUI_PORT: int = int(os.getenv("PSV_WEBUI_PORT", "5000"))

    # Cache
    CACHE_TTL_SECONDS: int = int(os.getenv("PSV_CACHE_TTL", "86400"))

    @property
    def has_llm_config(self) -> bool:
        return bool(self.OPENAI_API_KEY or self.DEEPSEEK_API_KEY or self.QWEN_API_KEY)

    def get_llm_preference(self) -> list:
        """返回 LLM 提供商优先级列表。"""
        preference = []
        if self.DEEPSEEK_API_KEY:
            preference.append("deepseek")
        if self.QWEN_API_KEY:
            preference.append("qwen")
        if self.OPENAI_API_KEY:
            preference.append("openai")
        return preference if preference else ["openai"]


settings = Settings()
