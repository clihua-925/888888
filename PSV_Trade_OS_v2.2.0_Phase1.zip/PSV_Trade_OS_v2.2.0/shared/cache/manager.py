# -*- coding: utf-8 -*-
"""Cache Manager — 统一缓存层

支持内存缓存 + 磁盘持久化。
Phase 3 可扩展为 Redis 后端。
"""
import json
import os
import time
import hashlib
from typing import Dict, Any, Optional
from pathlib import Path

from shared.config.settings import settings


class CacheManager:
    """缓存管理器。"""

    def __init__(self, ttl_seconds: int = None):
        self.ttl = ttl_seconds or settings.CACHE_TTL_SECONDS
        self._memory: Dict[str, Dict[str, Any]] = {}
        self._disk_dir = Path(settings.DATA_DIR) / "cache"
        self._disk_dir.mkdir(parents=True, exist_ok=True)

    def _key(self, namespace: str, key: str) -> str:
        return f"{namespace}:{hashlib.md5(key.encode()).hexdigest()}"

    def _disk_path(self, full_key: str) -> Path:
        return self._disk_dir / f"{full_key}.json"

    def get(self, namespace: str, key: str) -> Optional[Any]:
        full_key = self._key(namespace, key)

        # 1. 内存缓存
        if full_key in self._memory:
            entry = self._memory[full_key]
            if time.time() - entry["ts"] < self.ttl:
                return entry["data"]
            del self._memory[full_key]

        # 2. 磁盘缓存
        disk_path = self._disk_path(full_key)
        if disk_path.exists():
            try:
                with open(disk_path, "r", encoding="utf-8") as f:
                    entry = json.load(f)
                if time.time() - entry["ts"] < self.ttl:
                    self._memory[full_key] = entry
                    return entry["data"]
                else:
                    disk_path.unlink()
            except Exception:
                pass

        return None

    def set(self, namespace: str, key: str, data: Any) -> None:
        full_key = self._key(namespace, key)
        entry = {"ts": time.time(), "data": data}
        self._memory[full_key] = entry

        disk_path = self._disk_path(full_key)
        try:
            with open(disk_path, "w", encoding="utf-8") as f:
                json.dump(entry, f, ensure_ascii=False, default=str)
        except Exception:
            pass

    def invalidate(self, namespace: str = None) -> int:
        """清除缓存。返回清除条目数。"""
        count = 0
        if namespace:
            keys_to_remove = [k for k in self._memory if k.startswith(f"{namespace}:")]
            for k in keys_to_remove:
                del self._memory[k]
                disk_path = self._disk_path(k)
                if disk_path.exists():
                    disk_path.unlink()
                count += 1
        else:
            count = len(self._memory)
            self._memory.clear()
            for f in self._disk_dir.glob("*.json"):
                f.unlink()
        return count
