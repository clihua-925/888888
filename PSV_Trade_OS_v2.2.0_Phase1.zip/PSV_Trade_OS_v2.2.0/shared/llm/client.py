# -*- coding: utf-8 -*-
"""LLM Client — 统一大语言模型调用层

支持多模型自动降级：DeepSeek → Qwen → OpenAI
所有 Agent 必须通过此客户端调用 LLM，禁止直接实例化 OpenAI 客户端。
"""
import os
import json
import time
from typing import Dict, List, Any, Optional

from shared.config.settings import settings


class LLMClient:
    """统一 LLM 客户端。"""

    def __init__(self):
        self._clients: Dict[str, Any] = {}
        self._init_clients()

    def _init_clients(self):
        """延迟初始化各提供商客户端。"""
        try:
            from openai import OpenAI
            if settings.OPENAI_API_KEY:
                self._clients["openai"] = OpenAI(
                    api_key=settings.OPENAI_API_KEY,
                    base_url=settings.OPENAI_BASE_URL,
                )
            if settings.DEEPSEEK_API_KEY:
                self._clients["deepseek"] = OpenAI(
                    api_key=settings.DEEPSEEK_API_KEY,
                    base_url=settings.DEEPSEEK_BASE_URL,
                )
            if settings.QWEN_API_KEY:
                self._clients["qwen"] = OpenAI(
                    api_key=settings.QWEN_API_KEY,
                    base_url=settings.QWEN_BASE_URL,
                )
        except ImportError:
            pass

    def chat(
        self,
        prompt: str,
        system_prompt: str = "You are a helpful assistant.",
        model_preference: Optional[List[str]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4000,
        json_mode: bool = False,
    ) -> Dict[str, Any]:
        """统一聊天接口。

        Returns:
            {
                "success": bool,
                "content": str,
                "parsed_json": Any,
                "model": str,
                "provider": str,
                "tokens": int,
                "error": str,
            }
        """
        preference = model_preference or settings.get_llm_preference()

        for provider in preference:
            client = self._clients.get(provider)
            if not client:
                continue

            model_map = {
                "openai": settings.DEFAULT_LLM_MODEL,
                "deepseek": "deepseek-chat",
                "qwen": "qwen-max",
            }
            model = model_map.get(provider, settings.DEFAULT_LLM_MODEL)

            try:
                t0 = time.time()
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt},
                ]

                kwargs = {
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                }
                if json_mode and provider == "openai":
                    kwargs["response_format"] = {"type": "json_object"}

                response = client.chat.completions.create(**kwargs)
                content = response.choices[0].message.content or ""
                tokens = response.usage.total_tokens if response.usage else 0

                parsed = None
                if json_mode or (content.strip().startswith("[") or content.strip().startswith("{")):
                    try:
                        parsed = json.loads(content)
                    except json.JSONDecodeError:
                        pass

                return {
                    "success": True,
                    "content": content,
                    "parsed_json": parsed,
                    "model": model,
                    "provider": provider,
                    "tokens": tokens,
                    "error": "",
                    "duration_ms": int((time.time() - t0) * 1000),
                }

            except Exception as e:
                continue  # 降级到下一个提供商

        return {
            "success": False,
            "content": "",
            "parsed_json": None,
            "model": "",
            "provider": "",
            "tokens": 0,
            "error": f"All LLM providers failed. Last error: {str(e)}",
            "duration_ms": 0,
        }


# 全局单例
_llm_client: Optional[LLMClient] = None


def get_llm() -> LLMClient:
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client
