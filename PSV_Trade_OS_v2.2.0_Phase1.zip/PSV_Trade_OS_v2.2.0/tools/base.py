# -*- coding: utf-8 -*-
"""Tool Base — 所有数据工具的基类

职责：
- 统一工具接口
- 错误处理与降级
- 结果标准化
"""
from abc import ABC, abstractmethod
from typing import Dict, Any
from contracts.tool_contract import ToolRequest, ToolResponse, ToolStatus


class BaseTool(ABC):
    """工具基类。"""

    def __init__(self, name: str, tool_type: str):
        self.name = name
        self.tool_type = tool_type
        self.enabled = True

    @abstractmethod
    def execute(self, request: ToolRequest) -> ToolResponse:
        pass

    def _error_response(self, error: str) -> ToolResponse:
        return ToolResponse(
            tool_name=self.name,
            status=ToolStatus.ERROR,
            error=error,
        )

    def _success_response(self, data: Dict[str, Any], source: str = "", confidence: float = 1.0) -> ToolResponse:
        return ToolResponse(
            tool_name=self.name,
            data=data,
            status=ToolStatus.AVAILABLE,
            source=source,
            confidence=confidence,
        )
