# -*- coding: utf-8 -*-
"""Data Source Manager — 数据源统一管理层

职责：
- 聚合多个数据源的结果
- 自动降级（真实 API → LLM 模拟）
- 去重与交叉验证
- 统一输出格式

禁止 Agent 直接调用单个工具，必须通过此管理器。
"""
import time
from typing import Dict, List, Any

from contracts.tool_contract import ToolRequest, ToolResponse, ToolStatus
from tools.customs_api import CustomsAPITool
from tools.search_engine import SearchEngineTool
from tools.b2b_platform import B2BPlatformTool
from tools.website_scraper import WebsiteScraperTool


class DataSourceManager:
    """数据源管理器。"""

    SOURCES = ["customs", "search", "b2b"]

    def __init__(self):
        self.customs = CustomsAPITool()
        self.search = SearchEngineTool()
        self.b2b = B2BPlatformTool()
        self.scraper = WebsiteScraperTool()

    def discover_companies(self, product: str, market: str, customer_type: str) -> ToolResponse:
        """多源企业发现。"""
        all_companies = []
        sources_used = []

        for source_name in self.SOURCES:
            tool = getattr(self, source_name)
            request = ToolRequest(
                tool_name=tool.name,
                operation="discover",
                params={"product": product, "market": market, "customer_type": customer_type},
            )
            response = tool.execute(request)

            if response.is_success():
                companies = response.data.get("companies", [])
                for c in companies:
                    c["_source"] = response.source
                    c["_confidence"] = response.confidence
                all_companies.extend(companies)
                sources_used.append(response.source)

        # 去重
        seen = set()
        unique = []
        for c in all_companies:
            key = c.get("name", "").lower().strip()
            if key and key not in seen:
                seen.add(key)
                # 取最高可信度
                existing = [x for x in unique if x.get("name", "").lower().strip() == key]
                if existing:
                    if c.get("_confidence", 0) > existing[0].get("_confidence", 0):
                        existing[0].update(c)
                else:
                    unique.append(c)

        # 计算聚合可信度
        avg_confidence = sum(c.get("_confidence", 0.5) for c in unique) / max(len(unique), 1)

        return ToolResponse(
            tool_name="data_source_manager",
            operation="discover_companies",
            data={"companies": unique, "total": len(unique), "sources": sources_used},
            status=ToolStatus.AVAILABLE,
            source=f"multi_source({','.join(sources_used)})" if sources_used else "none",
            confidence=round(avg_confidence, 2),
        )

    def get_market_data(self, product: str, market: str) -> ToolResponse:
        """获取市场数据。"""
        # 优先使用海关数据
        request = ToolRequest(
            tool_name=self.customs.name,
            operation="market_summary",
            params={"product": product, "market": market},
        )
        response = self.customs.execute(request)
        if response.is_success():
            return response

        # 降级到搜索
        request = ToolRequest(
            tool_name=self.search.name,
            operation="market_research",
            params={"query": f"{product} market {market}", "product": product, "market": market},
        )
        return self.search.execute(request)

    def scrape_website(self, url: str) -> ToolResponse:
        """抓取网站。"""
        request = ToolRequest(
            tool_name=self.scraper.name,
            operation="scrape",
            params={"url": url},
        )
        return self.scraper.execute(request)
