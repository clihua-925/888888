# -*- coding: utf-8 -*-
"""Search Engine Tool — 搜索引擎接口

Phase 1：基于 LLM 模拟搜索结果（保证流程跑通）
Phase 2：接入 SerpAPI / Google Custom Search / Bing API
"""
import time
from typing import Dict, List, Any

from tools.base import BaseTool
from contracts.tool_contract import ToolRequest, ToolResponse, ToolStatus
from shared.config.settings import settings
from shared.llm.client import get_llm
from shared.cache.manager import CacheManager


class SearchEngineTool(BaseTool):
    """搜索引擎工具。"""

    def __init__(self):
        super().__init__("search_engine", "search")
        self.llm = get_llm()
        self.cache = CacheManager(ttl_seconds=86400)
        self.serp_api_key = settings.SERP_API_KEY
        self.enabled = bool(self.serp_api_key)

    def execute(self, request: ToolRequest) -> ToolResponse:
        query = request.params.get("query", "")
        product = request.params.get("product", "")
        market = request.params.get("market", "")

        cache_key = f"{query}:{market}"
        cached = self.cache.get("search", cache_key)
        if cached:
            return self._success_response(cached, source="search_cache", confidence=0.85)

        if not self.enabled:
            # Phase 1：LLM 模拟搜索
            search_data = self._llm_search(query, product, market)
            self.cache.set("search", cache_key, search_data)
            return self._success_response(
                search_data,
                source="search_llm_simulated",
                confidence=0.6,
            )

        # Phase 2：真实搜索 API
        try:
            # import requests
            # response = requests.get("https://serpapi.com/search", params={...})
            pass
        except Exception as e:
            return self._error_response(f"Search API error: {e}")

    def _llm_search(self, query: str, product: str, market: str) -> Dict[str, Any]:
        """使用 LLM 模拟搜索结果。"""
        prompt = f"""请模拟搜索引擎结果，列出在 {market} 市场从事 {product} 进口/分销的企业：

搜索词：{query}

请输出 5-8 家企业的结构化信息：
{{
  "results": [
    {{
      "name": "公司全称",
      "website": "www.example.com",
      "country": "{market}",
      "industry": "行业",
      "description": "公司简介（50字）",
      "source_url": "https://example.com"
    }}
  ]
}}

只输出 JSON。"""

        result = self.llm.chat(prompt=prompt, temperature=0.5, max_tokens=3000)
        data = result.get("parsed_json") or {"results": []}
        return data
