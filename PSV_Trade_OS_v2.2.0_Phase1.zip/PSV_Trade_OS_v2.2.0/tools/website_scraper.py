# -*- coding: utf-8 -*-
"""Website Scraper Tool — 网站信息抓取

使用 requests + BeautifulSoup 抓取企业网站信息。
"""
import time
from typing import Dict, Any

from tools.base import BaseTool
from contracts.tool_contract import ToolRequest, ToolResponse, ToolStatus
from shared.cache.manager import CacheManager


class WebsiteScraperTool(BaseTool):
    """网站抓取工具。"""

    def __init__(self):
        super().__init__("website_scraper", "scraper")
        self.cache = CacheManager(ttl_seconds=86400 * 7)

    def execute(self, request: ToolRequest) -> ToolResponse:
        url = request.params.get("url", "")
        if not url:
            return self._error_response("URL is required")

        if not url.startswith("http"):
            url = f"https://{url}"

        cache_key = url
        cached = self.cache.get("web", cache_key)
        if cached:
            return self._success_response(cached, source="web_cache", confidence=0.9)

        try:
            import requests
            from bs4 import BeautifulSoup

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
            response.raise_for_status()

            soup = BeautifulSoup(response.text, "lxml")

            # 提取信息
            title = soup.title.string if soup.title else ""
            description = ""
            meta_desc = soup.find("meta", attrs={"name": "description"})
            if meta_desc:
                description = meta_desc.get("content", "")

            # 提取邮箱
            import re
            emails = list(set(re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', response.text)))

            # 提取关于我们页面链接
            about_links = []
            for a in soup.find_all("a", href=True):
                href = a["href"].lower()
                if "about" in href or "company" in href:
                    about_links.append(a["href"])

            data = {
                "url": url,
                "title": title,
                "description": description,
                "emails": emails[:5],
                "about_links": about_links[:3],
                "text_preview": soup.get_text(separator=" ", strip=True)[:500],
                "status_code": response.status_code,
            }

            self.cache.set("web", cache_key, data)
            return self._success_response(data, source="website_scraper", confidence=0.85)

        except Exception as e:
            # 降级：返回基础信息
            data = {
                "url": url,
                "title": "",
                "description": "",
                "emails": [],
                "about_links": [],
                "text_preview": "",
                "error": str(e),
                "status_code": 0,
            }
            self.cache.set("web", cache_key, data)
            return self._success_response(data, source="website_scraper_fallback", confidence=0.3)
