# -*- coding: utf-8 -*-
"""B2B Platform Tool — B2B平台数据接口

Phase 1：返回模拟数据
Phase 2：接入 Alibaba / Made-in-China / Global Sources API
"""
from typing import Dict, List, Any

from tools.base import BaseTool
from contracts.tool_contract import ToolRequest, ToolResponse, ToolStatus
from shared.config.settings import settings
from shared.cache.manager import CacheManager


class B2BPlatformTool(BaseTool):
    """B2B 平台工具。"""

    def __init__(self):
        super().__init__("b2b_platform", "data_source")
        self.cache = CacheManager(ttl_seconds=86400 * 3)
        self.api_key = settings.B2B_PLATFORM_KEY
        self.enabled = bool(self.api_key)

    def execute(self, request: ToolRequest) -> ToolResponse:
        product = request.params.get("product", "")
        market = request.params.get("market", "")

        cache_key = f"{product}:{market}"
        cached = self.cache.get("b2b", cache_key)
        if cached:
            return self._success_response(cached, source="b2b_cache", confidence=0.85)

        if not self.enabled:
            mock_data = {
                "companies": [
                    {
                        "name": f"{market} B2B {product.title()} Buyer",
                        "country": market,
                        "platform": "Alibaba",
                        "buyer_type": "wholesaler",
                        "annual_purchase_volume": "500K-1M USD",
                        "data_source": "b2b_mock",
                    }
                ],
                "platform": "mock_b2b",
            }
            self.cache.set("b2b", cache_key, mock_data)
            return self._success_response(mock_data, source="b2b_mock", confidence=0.5)

        return self._error_response("B2B platform API not configured")
