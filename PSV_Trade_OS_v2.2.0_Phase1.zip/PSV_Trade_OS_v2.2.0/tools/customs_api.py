# -*- coding: utf-8 -*-
"""Customs API Tool — 海关数据接口

Phase 1：基于配置返回模拟数据（保证流程跑通）
Phase 2：接入真实海关数据 API
"""
import time
from typing import Dict, List, Any

from tools.base import BaseTool
from contracts.tool_contract import ToolRequest, ToolResponse, ToolStatus
from shared.config.settings import settings
from shared.cache.manager import CacheManager


class CustomsAPITool(BaseTool):
    """海关数据工具。"""

    def __init__(self):
        super().__init__("customs_api", "data_source")
        self.cache = CacheManager(ttl_seconds=86400 * 7)
        self.api_key = settings.CUSTOMS_API_KEY
        self.api_url = settings.CUSTOMS_API_URL
        self.enabled = bool(self.api_key and self.api_url)

    def execute(self, request: ToolRequest) -> ToolResponse:
        product = request.params.get("product", "")
        market = request.params.get("market", "")
        customer_type = request.params.get("customer_type", "importer")

        cache_key = f"{product}:{market}:{customer_type}"
        cached = self.cache.get("customs", cache_key)
        if cached:
            return self._success_response(cached, source="customs_api_cache", confidence=0.9)

        if not self.enabled:
            # Phase 1：返回模拟数据，但标记为 mock
            mock_data = self._generate_mock_data(product, market, customer_type)
            self.cache.set("customs", cache_key, mock_data)
            return self._success_response(
                mock_data,
                source="customs_api_mock",
                confidence=0.5,  # mock 数据可信度较低
            )

        # Phase 2：真实 API 调用（预留）
        try:
            # import requests
            # response = requests.get(...)
            # data = response.json()
            # self.cache.set(...)
            # return self._success_response(data, source="customs_api", confidence=0.95)
            pass
        except Exception as e:
            return self._error_response(f"Customs API error: {e}")

    def _generate_mock_data(self, product: str, market: str, customer_type: str) -> Dict[str, Any]:
        """生成模拟海关数据。"""
        return {
            "companies": [
                {
                    "name": f"{market} {product.title()} Import Co.",
                    "country": market,
                    "import_volume_usd": 2500000,
                    "main_products": [product],
                    "hs_codes": ["9999.99.99"],  # 占位
                    "trade_frequency": "monthly",
                    "data_source": "customs_mock",
                },
                {
                    "name": f"Global {product.title()} Distributors Ltd",
                    "country": market,
                    "import_volume_usd": 1800000,
                    "main_products": [product, "related products"],
                    "hs_codes": ["9999.99.99"],
                    "trade_frequency": "quarterly",
                    "data_source": "customs_mock",
                },
            ],
            "market_summary": {
                "total_import_value_usd": 50000000,
                "top_origin_countries": ["China", "India", "Vietnam"],
                "growth_rate": 0.12,
            },
            "query_params": {"product": product, "market": market, "customer_type": customer_type},
        }
