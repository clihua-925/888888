# -*- coding: utf-8 -*-
"""Company Profile Builder — 企业画像构建器

负责：
- 多维度企业画像生成
- 画像标准化
- 画像更新
"""
from typing import Dict, Any, List
from contracts.data_contract import CompanyProfile, CompanySize


class CompanyProfileBuilder:
    """企业画像构建器。"""

    def build(self, raw_data: Dict[str, Any]) -> CompanyProfile:
        """从原始数据构建标准化企业画像。"""
        size_str = raw_data.get("company_size", "unknown").lower()
        try:
            size = CompanySize(size_str)
        except ValueError:
            size = CompanySize.UNKNOWN

        return CompanyProfile(
            company_id=raw_data.get("id", ""),
            name=raw_data.get("name", ""),
            country=raw_data.get("country", ""),
            website=raw_data.get("website", ""),
            industry=raw_data.get("industry", ""),
            main_products=raw_data.get("main_products", []),
            procurement_direction=raw_data.get("procurement_direction", []),
            company_size=size,
            supply_chain_relations=raw_data.get("supply_chain_relations", {}),
            contacts=raw_data.get("contacts", []),
            credibility_score=raw_data.get("credibility_score", 0.0),
            procurement_probability=raw_data.get("procurement_probability", 0.0),
            match_score=raw_data.get("match_score", 0.0),
            data_sources=[raw_data.get("data_source", "")],
            raw_data=raw_data,
            enriched=raw_data.get("enriched", False),
        )

    def batch_build(self, raw_data_list: List[Dict[str, Any]]) -> List[CompanyProfile]:
        return [self.build(d) for d in raw_data_list]
