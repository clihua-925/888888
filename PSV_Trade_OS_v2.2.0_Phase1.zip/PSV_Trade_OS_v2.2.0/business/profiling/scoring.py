# -*- coding: utf-8 -*-
"""Scoring Engine — 企业评分引擎

负责：
- 可信度评分
- 采购可能性评分
- 匹配度评分
- 综合评分
"""
from typing import Dict, Any


class ScoringEngine:
    """评分引擎。"""

    def score_credibility(self, company: Dict[str, Any]) -> float:
        """可信度评分（0-1）。"""
        score = 0.0
        if company.get("website"):
            score += 0.3
        if company.get("industry"):
            score += 0.2
        if company.get("main_products"):
            score += 0.2
        if company.get("enriched"):
            score += 0.2
        if company.get("data_source") not in ["llm", "mock"]:
            score += 0.1
        return min(score, 1.0)

    def score_procurement_probability(self, company: Dict[str, Any], product: str = "") -> float:
        """采购可能性评分。"""
        score = 0.0
        role = company.get("supply_chain_role", "")
        if role in ["importer", "distributor", "wholesaler"]:
            score += 0.4
        if product.lower() in str(company.get("main_products", [])).lower():
            score += 0.3
        if company.get("company_size") in ["medium", "large", "enterprise"]:
            score += 0.2
        score += company.get("credibility_score", 0) * 0.1
        return min(score, 1.0)

    def score_match(self, company: Dict[str, Any], target_product: str = "", target_market: str = "") -> float:
        """匹配度评分。"""
        score = 0.0
        if target_market and company.get("country", "").lower() == target_market.lower():
            score += 0.4
        if target_product and target_product.lower() in str(company.get("main_products", [])).lower():
            score += 0.4
        if company.get("supply_chain_role") == "importer":
            score += 0.2
        return min(score, 1.0)
