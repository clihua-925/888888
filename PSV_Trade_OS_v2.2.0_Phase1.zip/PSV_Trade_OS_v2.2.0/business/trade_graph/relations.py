# -*- coding: utf-8 -*-
"""Trade Relations — 贸易关系分析

负责：
- 供应链关系识别
- 贸易流向分析
- 关系强度计算
"""
from typing import Dict, List, Any


class TradeRelations:
    """贸易关系分析器。"""

    RELATION_TYPES = [
        "supplies",        # 供应
        "manufactures",    # 制造
        "distributes",     # 分销
        "sells_to",        # 销售给
        "competes_with",   # 竞争
        "partners_with",   # 合作
        "owns",            # 拥有
        "subsidiary_of",   # 子公司
    ]

    def classify_relation(self, source_role: str, target_role: str) -> str:
        """根据角色分类关系。"""
        if source_role == "supplier" and target_role in ["manufacturer", "importer"]:
            return "supplies"
        if source_role == "manufacturer" and target_role in ["distributor", "importer"]:
            return "sells_to"
        if source_role == "distributor" and target_role == "retailer":
            return "distributes"
        return "partners_with"

    def calculate_relation_strength(self, evidence_count: int, data_sources: int) -> float:
        """计算关系强度。"""
        base = min(evidence_count * 0.2, 0.6)
        source_bonus = min(data_sources * 0.1, 0.4)
        return min(base + source_bonus, 1.0)
