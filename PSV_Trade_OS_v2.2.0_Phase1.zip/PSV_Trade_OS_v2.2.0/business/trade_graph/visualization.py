# -*- coding: utf-8 -*-
"""Graph Visualization — 图谱可视化

负责：
- 生成图谱可视化数据（D3.js / Cytoscape 格式）
- 子图提取
- 路径分析
"""
from typing import Dict, Any


class GraphVisualization:
    """图谱可视化器。"""

    def to_d3_format(self, graph_data: Dict[str, Any]) -> Dict[str, Any]:
        """转换为 D3.js 力导向图格式。"""
        nodes = []
        links = []

        for n in graph_data.get("nodes", []):
            nodes.append({
                "id": n.get("id"),
                "name": n.get("name", n.get("id")),
                "group": n.get("type", "unknown"),
                "country": n.get("country", ""),
                "size": 10 if n.get("type") == "company" else 5,
            })

        for e in graph_data.get("edges", []):
            links.append({
                "source": e.get("source"),
                "target": e.get("target"),
                "value": e.get("weight", 1.0),
                "relation": e.get("relation", ""),
            })

        return {"nodes": nodes, "links": links}

    def to_cytoscape_format(self, graph_data: Dict[str, Any]) -> list:
        """转换为 Cytoscape.js 格式。"""
        elements = []
        for n in graph_data.get("nodes", []):
            elements.append({
                "data": {
                    "id": n.get("id"),
                    "label": n.get("name", n.get("id")),
                    "type": n.get("type", "unknown"),
                }
            })
        for e in graph_data.get("edges", []):
            elements.append({
                "data": {
                    "id": f"{e.get('source')}-{e.get('target')}",
                    "source": e.get("source"),
                    "target": e.get("target"),
                    "label": e.get("relation", ""),
                    "weight": e.get("weight", 1.0),
                }
            })
        return elements
