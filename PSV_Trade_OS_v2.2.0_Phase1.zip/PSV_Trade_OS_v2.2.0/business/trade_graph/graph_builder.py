# -*- coding: utf-8 -*-
"""Trade Graph Builder — 商业关系图谱构建器

负责：
- 构建产品-企业-国家-供应链关系图谱
- 图数据持久化
- 图查询接口

Phase 1：使用 NetworkX 内存图 + SQLite 持久化
Phase 4：视数据量迁移 Neo4j
"""
import time
from typing import Dict, List, Any, Optional

import networkx as nx

from platform.database.models import get_session, TradeGraphEdge, PSVDatabase


class TradeGraphBuilder:
    """Trade Graph 构建器。"""

    def __init__(self):
        self.graph = nx.DiGraph()
        self.db = PSVDatabase()

    def add_company(self, company: Dict[str, Any]) -> None:
        """添加企业节点。"""
        node_id = company.get("id", "")
        self.graph.add_node(
            node_id,
            type="company",
            name=company.get("name", ""),
            country=company.get("country", ""),
            industry=company.get("industry", ""),
            size=company.get("company_size", "unknown"),
        )

    def add_product(self, product: Dict[str, Any]) -> None:
        """添加产品节点。"""
        node_id = product.get("id", "")
        self.graph.add_node(
            node_id,
            type="product",
            name=product.get("name", ""),
            category=product.get("category", ""),
        )

    def add_relation(self, source_id: str, target_id: str, relation_type: str, weight: float = 1.0, evidence: str = "") -> None:
        """添加关系边。"""
        self.graph.add_edge(
            source_id, target_id,
            relation=relation_type,
            weight=weight,
            evidence=evidence,
            created_at=time.time(),
        )
        # 持久化到数据库
        try:
            session = get_session()
            edge_data = {
                "id": f"edge-{source_id}-{target_id}-{relation_type}",
                "source_id": source_id,
                "source_type": self.graph.nodes[source_id].get("type", ""),
                "target_id": target_id,
                "target_type": self.graph.nodes[target_id].get("type", ""),
                "relation_type": relation_type,
                "weight": weight,
                "evidence": evidence,
            }
            self.db.upsert_graph_edge(session, edge_data)
            session.commit()
            session.close()
        except Exception:
            pass

    def find_suppliers(self, company_id: str, depth: int = 1) -> List[Dict[str, Any]]:
        """查找供应商（上游）。"""
        if company_id not in self.graph:
            return []
        suppliers = []
        for pred in self.graph.predecessors(company_id):
            edge = self.graph.edges[pred, company_id]
            if edge.get("relation") in ["supplies", "manufactures"]:
                suppliers.append({
                    "company_id": pred,
                    "name": self.graph.nodes[pred].get("name", ""),
                    "relation": edge.get("relation"),
                    "weight": edge.get("weight", 1.0),
                })
        return suppliers

    def find_customers(self, company_id: str) -> List[Dict[str, Any]]:
        """查找客户（下游）。"""
        if company_id not in self.graph:
            return []
        customers = []
        for succ in self.graph.successors(company_id):
            edge = self.graph.edges[company_id, succ]
            if edge.get("relation") in ["sells_to", "distributes_to"]:
                customers.append({
                    "company_id": succ,
                    "name": self.graph.nodes[succ].get("name", ""),
                    "relation": edge.get("relation"),
                    "weight": edge.get("weight", 1.0),
                })
        return customers

    def find_competitors(self, company_id: str) -> List[Dict[str, Any]]:
        """查找竞争对手。"""
        if company_id not in self.graph:
            return []
        company = self.graph.nodes[company_id]
        industry = company.get("industry", "")
        country = company.get("country", "")

        competitors = []
        for node_id, attrs in self.graph.nodes(data=True):
            if node_id == company_id:
                continue
            if attrs.get("type") == "company" and attrs.get("industry") == industry:
                competitors.append({
                    "company_id": node_id,
                    "name": attrs.get("name", ""),
                    "country": attrs.get("country", ""),
                })
        return competitors

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [{"id": n, **attrs} for n, attrs in self.graph.nodes(data=True)],
            "edges": [{"source": u, "target": v, **attrs} for u, v, attrs in self.graph.edges(data=True)],
            "node_count": self.graph.number_of_nodes(),
            "edge_count": self.graph.number_of_edges(),
        }
