# -*- coding: utf-8 -*-
"""Market Analyzer — 市场分析引擎

负责：
- 市场趋势分析
- 需求预测
- 价格分析
"""
from typing import Dict, Any, List
import statistics


class MarketAnalyzer:
    """市场分析器。"""

    def analyze_trends(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """分析市场趋势。"""
        trends = market_data.get("key_trends", [])
        growth = market_data.get("growth_rate", 0)

        sentiment = "positive" if growth > 0.1 else "stable" if growth > 0 else "negative"

        return {
            "market_sentiment": sentiment,
            "growth_assessment": "high" if growth > 0.15 else "moderate" if growth > 0.05 else "low",
            "key_drivers": trends[:3],
            "risk_level": "high" if growth < 0 else "medium" if growth < 0.05 else "low",
        }

    def compare_markets(self, markets: List[Dict[str, Any]]) -> Dict[str, Any]:
        """多市场对比。"""
        if not markets:
            return {}

        sizes = [m.get("market_size", 0) for m in markets]
        growths = [m.get("growth_rate", 0) for m in markets]

        return {
            "largest_market": max(markets, key=lambda x: x.get("market_size", 0)).get("country", ""),
            "fastest_growing": max(markets, key=lambda x: x.get("growth_rate", 0)).get("country", ""),
            "avg_market_size": statistics.mean(sizes) if sizes else 0,
            "avg_growth_rate": statistics.mean(growths) if growths else 0,
        }
