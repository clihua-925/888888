# -*- coding: utf-8 -*-
"""Competitive Analyzer — 竞争分析引擎

负责：
- 竞争对手识别
- 竞争优势分析
- 市场定位建议
"""
from typing import Dict, Any, List


class CompetitiveAnalyzer:
    """竞争分析器。"""

    def analyze(self, company_pool: List[Dict[str, Any]], product: str) -> Dict[str, Any]:
        """分析竞争格局。"""
        competitors = [c for c in company_pool if c.get("supply_chain_role") in ["distributor", "wholesaler"]]
        importers = [c for c in company_pool if c.get("supply_chain_role") == "importer"]

        return {
            "competitor_count": len(competitors),
            "importer_count": len(importers),
            "market_concentration": "high" if len(competitors) < 5 else "medium" if len(competitors) < 15 else "low",
            "top_competitors": sorted(competitors, key=lambda x: x.get("credibility_score", 0), reverse=True)[:5],
            "market_gap_opportunities": self._identify_gaps(importers, competitors),
        }

    def _identify_gaps(self, importers: List[Dict], competitors: List[Dict]) -> List[str]:
        gaps = []
        if len(importers) > len(competitors) * 2:
            gaps.append("进口商数量远超分销商，分销渠道存在缺口")
        if not any(c.get("company_size") == "enterprise" for c in competitors):
            gaps.append("缺乏大型企业级竞争对手，高端市场机会")
        return gaps
