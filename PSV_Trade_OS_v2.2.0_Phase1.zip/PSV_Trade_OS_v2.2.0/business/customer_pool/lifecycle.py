# -*- coding: utf-8 -*-
"""Customer Lifecycle — 客户生命周期管理

状态流转：
new → contacted → qualified → proposal → negotiation → deal → lost
"""
from typing import Dict, Any
from enum import Enum


class LifecycleStage(Enum):
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    DEAL = "deal"
    LOST = "lost"


class CustomerLifecycle:
    """客户生命周期管理器。"""

    VALID_TRANSITIONS = {
        "new": ["contacted", "lost"],
        "contacted": ["qualified", "lost"],
        "qualified": ["proposal", "lost"],
        "proposal": ["negotiation", "lost"],
        "negotiation": ["deal", "lost"],
        "deal": [],
        "lost": ["new"],  # 可重新激活
    }

    def can_transition(self, current: str, target: str) -> bool:
        return target in self.VALID_TRANSITIONS.get(current, [])

    def get_next_stages(self, current: str) -> list:
        return self.VALID_TRANSITIONS.get(current, [])

    def get_stage_description(self, stage: str) -> str:
        descriptions = {
            "new": "新客户，尚未联系",
            "contacted": "已建立初步联系",
            "qualified": "已确认采购意向",
            "proposal": "已发送报价/方案",
            "negotiation": "正在谈判条款",
            "deal": "已成交",
            "lost": "已流失",
        }
        return descriptions.get(stage, "未知状态")
