# -*- coding: utf-8 -*-
"""Customer Pool Manager — 客户池管理器

负责：
- 客户入池
- 客户分级
- 客户查询
- 客户状态更新
"""
from typing import Dict, List, Any, Optional
from platform.database.models import get_session, TradeCustomerPool, TradeCompany


class CustomerPoolManager:
    """客户池管理器。"""

    def __init__(self):
        pass

    def add_customer(self, customer_data: Dict[str, Any]) -> str:
        """添加客户到池。"""
        session = get_session()
        try:
            entry = TradeCustomerPool(
                id=customer_data.get("id", ""),
                company_id=customer_data.get("company_id", ""),
                customer_level=customer_data.get("customer_level", "C"),
                customer_value=customer_data.get("customer_value", 0.0),
                match_score=customer_data.get("match_score", 0.0),
                deal_probability=customer_data.get("deal_probability", 0.0),
                development_priority=customer_data.get("development_priority", 5),
                follow_up_status=customer_data.get("follow_up_status", "new"),
                assigned_to=customer_data.get("assigned_to", ""),
                tags=customer_data.get("tags", []),
                notes=customer_data.get("notes", ""),
            )
            session.merge(entry)
            session.commit()
            return entry.id
        finally:
            session.close()

    def query(self, tier: str = None, limit: int = 100) -> List[Dict[str, Any]]:
        """查询客户池。"""
        session = get_session()
        try:
            query = session.query(TradeCustomerPool)
            if tier:
                query = query.filter(TradeCustomerPool.customer_level == tier)
            entries = query.order_by(TradeCustomerPool.deal_probability.desc()).limit(limit).all()
            result = []
            for e in entries:
                company = session.query(TradeCompany).filter(TradeCompany.id == e.company_id).first()
                result.append({
                    "id": e.id,
                    "company_id": e.company_id,
                    "company_name": company.name if company else "",
                    "customer_level": e.customer_level,
                    "customer_value": e.customer_value,
                    "match_score": e.match_score,
                    "deal_probability": e.deal_probability,
                    "development_priority": e.development_priority,
                    "follow_up_status": e.follow_up_status,
                    "tags": e.tags,
                    "notes": e.notes,
                })
            return result
        finally:
            session.close()

    def update_status(self, customer_id: str, status: str, notes: str = "") -> bool:
        """更新客户状态。"""
        session = get_session()
        try:
            entry = session.query(TradeCustomerPool).filter(TradeCustomerPool.id == customer_id).first()
            if entry:
                entry.follow_up_status = status
                if notes:
                    entry.notes = (entry.notes or "") + f"\n[{status}] {notes}"
                session.commit()
                return True
            return False
        finally:
            session.close()
