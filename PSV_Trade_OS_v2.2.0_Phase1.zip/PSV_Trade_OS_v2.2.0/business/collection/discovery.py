# -*- coding: utf-8 -*-
"""Company Discovery — 全球企业/买家/进口商/经销商/供应商发现

修复 v2.1.0：
- 不再直接调用 LLM 生成企业列表
- 通过 tools.data_source_manager 获取真实/模拟数据
- 支持多源聚合与交叉验证
"""
import time
from typing import Dict, List, Any

from tools.data_source_manager import DataSourceManager
from shared.cache.manager import CacheManager


class DiscoveryEngine:
    """企业发现引擎。"""

    def __init__(self):
        self.data_manager = DataSourceManager()
        self.cache = CacheManager(ttl_seconds=86400)

    def discover(self, product: str, market: str, customer_type: str) -> List[Dict[str, Any]]:
        """发现目标企业。"""
        cache_key = f"{product}:{market}:{customer_type}"
        cached = self.cache.get("discovery", cache_key)
        if cached:
            return cached

        # 通过数据源管理器获取（非直接LLM）
        result = self.data_manager.discover_companies(product, market, customer_type)
        companies = result.data.get("companies", []) if result.is_success() else []

        # 标准化输出
        normalized = []
        for c in companies:
            normalized.append({
                "id": c.get("id") or f"cmp-{c.get('name', '').replace(' ', '-')[:30]}",
                "name": c.get("name", ""),
                "country": c.get("country", market),
                "website": c.get("website", ""),
                "industry": c.get("industry", ""),
                "main_products": c.get("main_products", []),
                "company_size": c.get("company_size", "unknown"),
                "supply_chain_role": customer_type,
                "data_source": c.get("_source", "unknown"),
                "data_confidence": c.get("_confidence", 0.5),
                "discovered_at": time.time(),
            })

        self.cache.set("discovery", cache_key, normalized)
        return normalized
