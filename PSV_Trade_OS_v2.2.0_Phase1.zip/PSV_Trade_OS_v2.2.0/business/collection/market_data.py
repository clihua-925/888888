# -*- coding: utf-8 -*-
"""Market Data Collector — 市场数据采集

负责：
- 市场规模数据
- 增长率
- 关键趋势
- 竞争格局
"""
from typing import Dict, Any
from tools.data_source_manager import DataSourceManager


class MarketDataCollector:
    """市场数据采集器。"""

    def __init__(self):
        self.data_manager = DataSourceManager()

    def collect(self, product: str, market: str) -> Dict[str, Any]:
        """采集市场数据。"""
        result = self.data_manager.get_market_data(product, market)
        if result.is_success():
            return result.data
        return {"error": "No market data available", "product": product, "market": market}
