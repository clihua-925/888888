# -*- coding: utf-8 -*-
"""Orchestrator State — LangGraph 统一状态定义

这是整个系统的核心状态机。
所有 Agent、所有节点共享此状态。
支持：暂停 / 恢复 / 继续执行。
"""
from typing import TypedDict, Annotated, List, Dict, Any, Optional
from operator import add
import time


def merge_dicts(a: Dict, b: Dict) -> Dict:
    result = a.copy()
    result.update(b)
    return result


def append_unique(a: List, b: List) -> List:
    result = list(a)
    for item in b:
        if item not in result:
            result.append(item)
    return result


class PSVGraphState(TypedDict):
    """PSV Trade Intelligence OS — LangGraph 统一状态。"""

    # 身份标识
    task_id: str
    workflow_id: str
    user_id: Optional[str]

    # 输入层
    trade_intent: Dict[str, Any]
    task_contract: Dict[str, Any]

    # 计划层
    execution_plan: Dict[str, Any]
    plan_version: int
    replan_count: int

    # 执行层
    current_agent: str
    current_node: str
    agent_history: Annotated[List[Dict], add]
    agent_results: Annotated[Dict[str, Any], merge_dicts]

    # 业务数据层
    market_analysis: Dict[str, Any]
    company_pool: Annotated[List[Dict], append_unique]
    company_profiles: Annotated[Dict[str, Any], merge_dicts]
    customer_pool: Annotated[List[Dict], append_unique]
    contacts: Annotated[List[Dict], append_unique]
    trade_graph: Dict[str, Any]
    opportunities: Annotated[List[Dict], add]

    # 控制层
    supervisor_decisions: Annotated[List[Dict], add]
    routing_path: Annotated[List[str], add]
    checkpoint_history: Annotated[List[str], add]

    # 输出层
    final_report: Dict[str, Any]
    output_delivered: bool

    # 系统层
    status: str  # pending / planning / executing / paused / completed / failed / recovering
    retry_count: int
    checkpoint_id: str
    error_log: Annotated[List[Dict], add]
    audit_trail: Annotated[List[Dict], add]
    memory_refs: Annotated[List[str], add]

    # 时间戳
    created_at: float
    updated_at: float


def create_initial_state(task_contract: Dict[str, Any]) -> PSVGraphState:
    """从任务契约创建初始状态。"""
    now = time.time()
    return {
        "task_id": task_contract.get("task_id", ""),
        "workflow_id": f"wf-{task_contract.get('task_id', '')}",
        "user_id": task_contract.get("user_id"),
        "trade_intent": {
            "objective": task_contract.get("objective", ""),
            "product": task_contract.get("product", ""),
            "market": task_contract.get("market", ""),
            "target_customer": task_contract.get("target_customer", ""),
            "constraints": task_contract.get("constraints", []),
        },
        "task_contract": task_contract,
        "execution_plan": {},
        "plan_version": 1,
        "replan_count": 0,
        "current_agent": "",
        "current_node": "init",
        "agent_history": [],
        "agent_results": {},
        "market_analysis": {},
        "company_pool": [],
        "company_profiles": {},
        "customer_pool": [],
        "contacts": [],
        "trade_graph": {"nodes": [], "edges": [], "metadata": {}},
        "opportunities": [],
        "supervisor_decisions": [],
        "routing_path": [],
        "checkpoint_history": [],
        "final_report": {},
        "output_delivered": False,
        "status": "pending",
        "retry_count": 0,
        "checkpoint_id": "",
        "error_log": [],
        "audit_trail": [],
        "memory_refs": [],
        "created_at": now,
        "updated_at": now,
    }
