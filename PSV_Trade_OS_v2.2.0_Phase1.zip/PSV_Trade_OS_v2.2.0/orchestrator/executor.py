# -*- coding: utf-8 -*-
"""Executor — Agent 执行器

负责：
- 调用具体 Agent
- 包装为 AgentRequest / AgentResponse
- 记录执行日志
- 异常捕获与重试
"""
import time
from typing import Dict, Any

from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from platform.database.models import get_session, AgentExecutionLog
import uuid


class AgentExecutor:
    """Agent 执行器。"""

    def execute(self, agent, agent_name: str, state: Dict[str, Any]) -> Dict[str, Any]:
        """执行单个 Agent，返回更新后的 state。"""
        task_id = state.get("task_id", "")
        workflow_id = state.get("workflow_id", "")

        request = AgentRequest(
            task_id=task_id,
            agent_name=agent_name,
            input_data=self._build_input(state, agent_name),
            context={
                "workflow_id": workflow_id,
                "execution_plan": state.get("execution_plan", {}),
                "market_analysis": state.get("market_analysis", {}),
                "company_pool": state.get("company_pool", []),
            },
        )

        t0 = time.time()
        try:
            response = agent.execute(request)
        except Exception as e:
            response = AgentResponse(
                task_id=task_id,
                agent_name=agent_name,
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - t0) * 1000),
            )

        # 记录执行日志
        self._log_execution(task_id, workflow_id, agent_name, request, response)

        # 更新 state
        state["agent_results"] = state.get("agent_results", {})
        state["agent_results"][agent_name] = response.to_dict()
        state["agent_history"] = state.get("agent_history", []) + [{
            "agent": agent_name,
            "status": response.status.value,
            "duration_ms": response.duration_ms,
            "timestamp": time.time(),
        }]
        state["current_agent"] = agent_name
        state["updated_at"] = time.time()

        return state

    def _build_input(self, state: Dict[str, Any], agent_name: str) -> Dict[str, Any]:
        """根据 Agent 类型构建输入数据。"""
        base = {
            "trade_intent": state.get("trade_intent", {}),
            "execution_plan": state.get("execution_plan", {}),
        }
        if agent_name == "market_research":
            base["product"] = state["trade_intent"].get("product", "")
            base["market"] = state["trade_intent"].get("market", "")
        elif agent_name in ["company_discovery", "company_enrichment"]:
            base["product"] = state["trade_intent"].get("product", "")
            base["market"] = state["trade_intent"].get("market", "")
            base["target_customer"] = state["trade_intent"].get("target_customer", "")
            base["market_analysis"] = state.get("market_analysis", {})
        elif agent_name == "contact_discovery":
            base["company_pool"] = state.get("company_pool", [])
            base["company_profiles"] = state.get("company_profiles", {})
        elif agent_name == "lead_scoring":
            base["company_pool"] = state.get("company_pool", [])
            base["contacts"] = state.get("contacts", [])
            base["company_profiles"] = state.get("company_profiles", {})
        elif agent_name == "sales_strategy":
            base["customer_pool"] = state.get("customer_pool", [])
            base["company_profiles"] = state.get("company_profiles", {})
            base["market_analysis"] = state.get("market_analysis", {})
        elif agent_name == "report":
            base["market_analysis"] = state.get("market_analysis", {})
            base["company_pool"] = state.get("company_pool", [])
            base["company_profiles"] = state.get("company_profiles", {})
            base["customer_pool"] = state.get("customer_pool", [])
            base["contacts"] = state.get("contacts", [])
            base["opportunities"] = state.get("opportunities", [])
            base["agent_results"] = state.get("agent_results", {})
        return base

    def _log_execution(self, task_id: str, workflow_id: str, agent_name: str,
                       request: AgentRequest, response: AgentResponse):
        try:
            session = get_session()
            log = AgentExecutionLog(
                id=f"ael-{uuid.uuid4().hex[:12]}",
                task_id=task_id,
                workflow_id=workflow_id,
                agent_name=agent_name,
                node_name=agent_name,
                input_data=request.to_dict(),
                output_data=response.to_dict(),
                confidence=response.confidence.name if response.confidence else "NONE",
                evidence=response.evidence,
                duration_ms=response.duration_ms,
                status=response.status.value,
                error=response.error,
            )
            session.add(log)
            session.commit()
            session.close()
        except Exception:
            pass
