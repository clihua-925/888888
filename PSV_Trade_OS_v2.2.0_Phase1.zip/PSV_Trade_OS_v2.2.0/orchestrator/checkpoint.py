# -*- coding: utf-8 -*-
"""Checkpoint — 状态检查点持久化

完整实现 LangGraph BaseCheckpointSaver 接口。
支持：
- 自动保存每个节点的状态
- 任务中断后恢复
- 多版本状态历史
- SQLite 后端（生产级）
"""
import json
import os
import time
import uuid
import pickle
import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from contextlib import contextmanager

from langgraph.checkpoint.base import BaseCheckpointSaver

from shared.config.settings import settings


class PSVCheckpointBackend:
    """Checkpoint 底层存储（SQLite）。"""

    def __init__(self, db_path: str = None):
        self.db_path = db_path or os.path.join(settings.CHECKPOINT_DIR, "checkpoints.db")
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS checkpoints (
                    thread_id TEXT NOT NULL,
                    checkpoint_ns TEXT NOT NULL DEFAULT '',
                    checkpoint_id TEXT NOT NULL,
                    parent_checkpoint_id TEXT,
                    type TEXT,
                    checkpoint BLOB,
                    metadata BLOB,
                    PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id)
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_thread ON checkpoints(thread_id, checkpoint_ns)
            """)
            conn.commit()

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        try:
            yield conn
        finally:
            conn.close()

    def put(self, thread_id: str, checkpoint_ns: str, checkpoint_id: str,
            parent_checkpoint_id: Optional[str], checkpoint: bytes, metadata: bytes) -> None:
        with self._conn() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO checkpoints
                   (thread_id, checkpoint_ns, checkpoint_id, parent_checkpoint_id, type, checkpoint, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (thread_id, checkpoint_ns, checkpoint_id, parent_checkpoint_id, "psv", checkpoint, metadata)
            )
            conn.commit()

    def get(self, thread_id: str, checkpoint_ns: str, checkpoint_id: str) -> Optional[Tuple[bytes, bytes]]:
        with self._conn() as conn:
            row = conn.execute(
                """SELECT checkpoint, metadata FROM checkpoints
                   WHERE thread_id = ? AND checkpoint_ns = ? AND checkpoint_id = ?""",
                (thread_id, checkpoint_ns, checkpoint_id)
            ).fetchone()
            return (row[0], row[1]) if row else None

    def list(self, thread_id: str, checkpoint_ns: str) -> List[Tuple[str, bytes, bytes]]:
        with self._conn() as conn:
            rows = conn.execute(
                """SELECT checkpoint_id, checkpoint, metadata FROM checkpoints
                   WHERE thread_id = ? AND checkpoint_ns = ?
                   ORDER BY checkpoint_id DESC""",
                (thread_id, checkpoint_ns)
            ).fetchall()
            return [(r[0], r[1], r[2]) for r in rows]


class PSVCheckpointer(BaseCheckpointSaver):
    """PSV 检查点管理器 — 兼容 LangGraph。"""

    def __init__(self):
        super().__init__()
        self.backend = PSVCheckpointBackend()

    def put(self, config, checkpoint, metadata, new_versions):
        thread_id = config.get("configurable", {}).get("thread_id", "default")
        checkpoint_ns = config.get("configurable", {}).get("checkpoint_ns", "")
        checkpoint_id = checkpoint.get("id", str(uuid.uuid4()))
        parent_id = checkpoint.get("parent_id")

        pickled = pickle.dumps(checkpoint)
        meta_pickled = pickle.dumps(metadata)

        self.backend.put(thread_id, checkpoint_ns, checkpoint_id, parent_id, pickled, meta_pickled)
        return {"configurable": {"thread_id": thread_id, "checkpoint_ns": checkpoint_ns, "checkpoint_id": checkpoint_id}}

    def get_tuple(self, config):
        thread_id = config.get("configurable", {}).get("thread_id", "default")
        checkpoint_ns = config.get("configurable", {}).get("checkpoint_ns", "")
        checkpoint_id = config.get("configurable", {}).get("checkpoint_id")

        if checkpoint_id:
            row = self.backend.get(thread_id, checkpoint_ns, checkpoint_id)
            if row:
                return self._deserialize(row)

        rows = self.backend.list(thread_id, checkpoint_ns)
        if rows:
            return self._deserialize(rows[0])
        return None

    def _deserialize(self, row):
        checkpoint_id, checkpoint_bytes, metadata_bytes = row
        checkpoint = pickle.loads(checkpoint_bytes)
        metadata = pickle.loads(metadata_bytes)
        return (checkpoint, metadata)

    def list(self, config, *, before=None, limit=None, filter=None):
        thread_id = config.get("configurable", {}).get("thread_id", "default")
        checkpoint_ns = config.get("configurable", {}).get("checkpoint_ns", "")
        rows = self.backend.list(thread_id, checkpoint_ns)
        results = []
        for checkpoint_id, checkpoint_bytes, metadata_bytes in rows:
            checkpoint = pickle.loads(checkpoint_bytes)
            metadata = pickle.loads(metadata_bytes)
            results.append((checkpoint, metadata))
        return results
