# -*- coding: utf-8 -*-
"""Trade Planner Agent — 贸易规划智能体

职责：
- 理解外贸目标（自然语言）
- 生成：任务目标、执行计划、Agent 调用顺序
- 输出标准化 execution_plan
"""
import time
from typing import Dict, List, Any

from contracts.task_contract import TaskContract, TaskType
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.config.settings import settings


class TradePlannerAgent:
    """Trade Planner Agent。"""

    WORKFLOW_TEMPLATES = {
        "full_development": [
            "market_research",
            "company_discovery",
            "company_enrichment",
            "contact_discovery",
            "lead_scoring",
            "sales_strategy",
            "report",
        ],
        "market_only": [
            "market_research",
            "report",
        ],
        "discovery_only": [
            "company_discovery",
            "company_enrichment",
            "report",
        ],
        "enrichment_only": [
            "company_enrichment",
            "contact_discovery",
            "report",
        ],
    }

    def __init__(self):
        self.agent_name = "trade_planner"

    def plan(self, task: TaskContract) -> AgentResponse:
        t0 = time.time()

        valid, errors = task.validate()
        if not valid:
            return AgentResponse(
                task_id=task.task_id,
                agent_name=self.agent_name,
                status=AgentStatus.FAILED,
                error=f"Task validation failed: {'; '.join(errors)}",
                duration_ms=int((time.time() - t0) * 1000),
            )

        workflow = self._select_workflow(task)
        plan = self._build_plan(task, workflow)

        return AgentResponse(
            task_id=task.task_id,
            agent_name=self.agent_name,
            result={
                "execution_plan": plan,
                "workflow_type": workflow,
                "estimated_steps": len(plan.get("agent_sequence", [])),
            },
            confidence=ConfidenceLevel.STRONG,
            evidence=["基于任务类型和目标客户自动选择工作流模板", "计划包含明确的 Agent 调用顺序和依赖关系"],
            next_action="supervisor_execute",
            status=AgentStatus.SUCCESS,
            duration_ms=int((time.time() - t0) * 1000),
        )

    def _select_workflow(self, task: TaskContract) -> str:
        objective = task.objective.lower()

        if any(k in objective for k in ["开发", "develop", "开发客户", "客户开发", "full"]):
            return "full_development"
        if any(k in objective for k in ["市场", "market", "分析", "analysis", "趋势", "trend"]):
            return "market_only"
        if any(k in objective for k in ["发现", "discover", "寻找", "find", "搜索", "search"]):
            return "discovery_only"
        if any(k in objective for k in ["补全", "enrich", "完善", "补充", "contact"]):
            return "enrichment_only"

        return "full_development"

    def _build_plan(self, task: TaskContract, workflow_type: str) -> Dict[str, Any]:
        agent_sequence = self.WORKFLOW_TEMPLATES.get(workflow_type, self.WORKFLOW_TEMPLATES["full_development"])

        dependencies = {}
        for i, agent in enumerate(agent_sequence):
            deps = []
            if i > 0:
                deps.append(agent_sequence[i - 1])
            dependencies[agent] = deps

        return {
            "version": 1,
            "workflow_type": workflow_type,
            "agent_sequence": agent_sequence,
            "dependencies": dependencies,
            "fallback_strategy": {
                "on_agent_failure": "skip_and_continue",
                "on_replan_limit": "abort",
            },
            "constraints": {
                "max_replan": 3,
                "max_retries_per_agent": settings.MAX_AGENT_RETRIES,
                "timeout_seconds": settings.TASK_TIMEOUT_SECONDS,
            },
            "objective_summary": f"{task.objective} | 产品: {task.product} | 市场: {task.market} | 目标客户: {task.target_customer}",
        }
