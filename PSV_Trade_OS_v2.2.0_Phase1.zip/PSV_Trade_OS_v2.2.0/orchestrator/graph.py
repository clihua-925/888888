# -*- coding: utf-8 -*-
"""Graph — LangGraph 主编排图

PSV Trade Intelligence OS 的核心运行引擎。
修复：消除死循环，统一审计，规范数据流。

流程：
    INIT → PLANNER → SUPERVISOR → [AGENT LOOP] → REPORT → PERSIST → END
                     ↑____________↓
    AGENT → CHECKPOINT → SUPERVISOR (循环)
"""
import time
from typing import Dict, Any
from langgraph.graph import StateGraph, END

from orchestrator.state import PSVGraphState, create_initial_state
from orchestrator.planner import TradePlannerAgent
from orchestrator.supervisor import SupervisorAgent
from orchestrator.router import PSVRouter
from orchestrator.checkpoint import PSVCheckpointer
from orchestrator.executor import AgentExecutor
from orchestrator.recovery import RecoveryManager
from contracts.task_contract import TaskContract
from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus
from shared.config.settings import settings

from agents.market_research.agent import MarketResearchAgent
from agents.company_discovery.agent import CompanyDiscoveryAgent
from agents.company_enrichment.agent import CompanyEnrichmentAgent
from agents.contact_discovery.agent import ContactDiscoveryAgent
from agents.lead_scoring.agent import LeadScoringAgent
from agents.sales_strategy.agent import SalesStrategyAgent
from agents.report.agent import ReportAgent

from platform.database.models import PSVDatabase, get_session, TradeTask, init_database
from platform.audit.logger import AuditLogger


class PSVGraphBuilder:
    """PSV 主图构建器 —— 外贸智能操作系统核心引擎。"""

    def __init__(self):
        self.planner = TradePlannerAgent()
        self.supervisor = SupervisorAgent()
        self.router = PSVRouter(supervisor=self.supervisor)
        self.checkpointer = PSVCheckpointer()
        self.executor = AgentExecutor()
        self.recovery = RecoveryManager()
        self.db = PSVDatabase()
        self.audit = AuditLogger()

        self.agents = {
            "market_research": MarketResearchAgent(),
            "company_discovery": CompanyDiscoveryAgent(),
            "company_enrichment": CompanyEnrichmentAgent(),
            "contact_discovery": ContactDiscoveryAgent(),
            "lead_scoring": LeadScoringAgent(),
            "sales_strategy": SalesStrategyAgent(),
            "report": ReportAgent(),
        }

    def build(self) -> StateGraph:
        builder = StateGraph(PSVGraphState)

        builder.add_node("init", self._node_init)
        builder.add_node("planner", self._node_planner)
        builder.add_node("supervisor", self._node_supervisor)
        builder.add_node("market_research", self._make_agent_node("market_research"))
        builder.add_node("company_discovery", self._make_agent_node("company_discovery"))
        builder.add_node("company_enrichment", self._make_agent_node("company_enrichment"))
        builder.add_node("contact_discovery", self._make_agent_node("contact_discovery"))
        builder.add_node("lead_scoring", self._make_agent_node("lead_scoring"))
        builder.add_node("sales_strategy", self._make_agent_node("sales_strategy"))
        builder.add_node("report", self._node_report)
        builder.add_node("checkpoint", self._node_checkpoint)
        builder.add_node("persist", self._node_persist)

        builder.set_entry_point("init")
        builder.add_edge("init", "planner")

        builder.add_conditional_edges(
            "planner",
            self.router.route_after_planner,
            {"supervisor": "supervisor", "end": END}
        )

        builder.add_conditional_edges(
            "supervisor",
            self.router.route_after_supervisor,
            {
                "market_research": "market_research",
                "company_discovery": "company_discovery",
                "company_enrichment": "company_enrichment",
                "contact_discovery": "contact_discovery",
                "lead_scoring": "lead_scoring",
                "sales_strategy": "sales_strategy",
                "report": "report",
                "planner": "planner",
                "end": END,
            }
        )

        for agent_node in [
            "market_research", "company_discovery", "company_enrichment",
            "contact_discovery", "lead_scoring", "sales_strategy",
        ]:
            builder.add_edge(agent_node, "checkpoint")

        builder.add_conditional_edges("checkpoint", self.router.route_after_checkpoint, {"supervisor": "supervisor"})

        builder.add_edge("report", "persist")
        builder.add_edge("persist", END)

        graph = builder.compile(checkpointer=self.checkpointer)
        return graph

    def _audit(self, state: PSVGraphState, event_type: str, details: Dict = None):
        """统一审计记录。"""
        entry = {
            "task_id": state.get("task_id"),
            "workflow_id": state.get("workflow_id"),
            "node": state.get("current_node"),
            "agent": state.get("current_agent"),
            "event_type": event_type,
            "details": details or {},
            "timestamp": time.time(),
            "status": state.get("status"),
        }
        state["audit_trail"] = state.get("audit_trail", []) + [entry]
        self.audit.log(
            task_id=state.get("task_id", ""),
            workflow_id=state.get("workflow_id", ""),
            agent_id=state.get("current_agent", ""),
            node=state.get("current_node", ""),
            event_type=event_type,
            input_data=state.get("trade_intent", {}),
            output_data=details or {},
            status=state.get("status", ""),
        )

    def _node_init(self, state: PSVGraphState) -> Dict[str, Any]:
        state["status"] = "planning"
        state["current_node"] = "init"
        state["routing_path"] = state.get("routing_path", []) + ["init"]
        self._audit(state, "task_initialized", {"intent": state.get("trade_intent")})
        return state

    def _node_planner(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "planner"
        state["current_agent"] = "trade_planner"

        task_contract = state.get("task_contract", {})
        task = TaskContract.from_dict(task_contract)
        response = self.planner.plan(task)

        if response.is_success():
            state["execution_plan"] = response.result.get("execution_plan", {})
            state["plan_version"] = response.result.get("execution_plan", {}).get("version", 1)
            state["status"] = "executing"
            self._audit(state, "plan_generated", {
                "workflow_type": response.result.get("workflow_type"),
                "agent_sequence": response.result.get("execution_plan", {}).get("agent_sequence"),
            })
        else:
            state["status"] = "failed"
            state["error_log"] = state.get("error_log", []) + [{
                "node": "planner",
                "error": response.error,
                "timestamp": time.time(),
            }]
            self._audit(state, "plan_failed", {"error": response.error})
        return state

    def _node_supervisor(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "supervisor"
        state["current_agent"] = "supervisor"
        self._audit(state, "supervisor_check", {
            "completed_agents": [k for k, v in state.get("agent_results", {}).items() if v.get("status") == "success"],
        })
        return state

    def _make_agent_node(self, agent_name: str):
        """创建 Agent 节点函数（闭包）。"""
        def _node(state: PSVGraphState) -> Dict[str, Any]:
            state["current_node"] = agent_name
            state["current_agent"] = agent_name
            state["status"] = "executing"

            agent = self.agents.get(agent_name)
            if not agent:
                state["error_log"] = state.get("error_log", []) + [{
                    "node": agent_name,
                    "error": f"Agent {agent_name} not found",
                    "timestamp": time.time(),
                }]
                return state

            state = self.executor.execute(agent, agent_name, state)
            self._audit(state, f"agent_{agent_name}_executed", {
                "status": state.get("agent_results", {}).get(agent_name, {}).get("status"),
            })
            return state
        return _node

    def _node_report(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "report"
        state["current_agent"] = "report"

        agent = self.agents.get("report")
        if agent:
            state = self.executor.execute(agent, "report", state)
            report_data = state.get("agent_results", {}).get("report", {})
            state["final_report"] = report_data.get("result", {})
            state["output_delivered"] = True

        state["status"] = "completed"
        self._audit(state, "report_generated", {"report_size": len(str(state.get("final_report", {})))})
        return state

    def _node_checkpoint(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "checkpoint"
        state["checkpoint_history"] = state.get("checkpoint_history", []) + [f"{state.get('current_agent')}-{time.time()}"]
        self._audit(state, "checkpoint_saved", {"checkpoint_id": state.get("checkpoint_id", "")})
        return state

    def _node_persist(self, state: PSVGraphState) -> Dict[str, Any]:
        state["current_node"] = "persist"
        try:
            self._persist_to_db(state)
            self._audit(state, "data_persisted", {"companies": len(state.get("company_pool", [])),
                                                   "customers": len(state.get("customer_pool", [])),
                                                   "opportunities": len(state.get("opportunities", []))})
        except Exception as e:
            state["error_log"] = state.get("error_log", []) + [{
                "node": "persist",
                "error": str(e),
                "timestamp": time.time(),
            }]
        return state

    def _persist_to_db(self, state: PSVGraphState):
        """将业务数据持久化到数据库。"""
        session = get_session()
        try:
            # 保存任务
            task_data = {
                "id": state["task_id"],
                "objective": state["trade_intent"].get("objective", ""),
                "product": state["trade_intent"].get("product", ""),
                "market": state["trade_intent"].get("market", ""),
                "target_customer": state["trade_intent"].get("target_customer", ""),
                "status": state["status"],
                "execution_plan": state.get("execution_plan", {}),
                "final_report": state.get("final_report", {}),
                "routing_path": state.get("routing_path", []),
                "error_log": state.get("error_log", []),
            }
            self.db.upsert_task(session, task_data)

            # 保存企业
            for company in state.get("company_pool", []):
                company_data = {
                    "id": company.get("id") or f"cmp-{company.get('name', '')[:20]}",
                    "name": company.get("name", ""),
                    "country": company.get("country", ""),
                    "website": company.get("website", ""),
                    "industry": company.get("industry", ""),
                    "main_products": json.dumps(company.get("main_products", [])),
                    "procurement_direction": json.dumps(company.get("procurement_direction", [])),
                    "company_size": company.get("company_size", "unknown"),
                    "supply_chain_relations": company.get("supply_chain_relations", {}),
                    "credibility_score": company.get("credibility_score", 0.0),
                    "procurement_probability": company.get("procurement_probability", 0.0),
                    "match_score": company.get("match_score", 0.0),
                    "data_source": company.get("data_source", "llm"),
                    "raw_data": company,
                }
                self.db.upsert_company(session, company_data)

            # 保存客户池
            for customer in state.get("customer_pool", []):
                customer_data = {
                    "id": customer.get("id") or f"cus-{customer.get('company_id', '')}",
                    "company_id": customer.get("company_id", ""),
                    "customer_level": customer.get("customer_level", "C"),
                    "customer_value": customer.get("customer_value", 0.0),
                    "match_score": customer.get("match_score", 0.0),
                    "deal_probability": customer.get("deal_probability", 0.0),
                    "development_priority": customer.get("development_priority", 5),
                    "follow_up_status": customer.get("follow_up_status", "new"),
                    "tags": customer.get("tags", []),
                    "notes": customer.get("notes", ""),
                }
                self.db.upsert_customer_pool(session, customer_data)

            # 保存机会
            for opp in state.get("opportunities", []):
                opp_data = {
                    "id": opp.get("id") or f"opp-{opp.get('company_id', '')}-{int(time.time())}",
                    "company_id": opp.get("company_id", ""),
                    "title": opp.get("title", ""),
                    "description": opp.get("description", ""),
                    "estimated_value": opp.get("estimated_value", 0.0),
                    "probability": opp.get("probability", 0.0),
                    "strategy": opp.get("strategy", ""),
                    "email_template": opp.get("email_template", ""),
                    "follow_up_plan": opp.get("follow_up_plan", {}),
                    "status": opp.get("status", "open"),
                }
                self.db.upsert_opportunity(session, opp_data)

            session.commit()
        except Exception as e:
            session.rollback()
            raise
        finally:
            session.close()


def run_trade_task(task_contract: Dict[str, Any]) -> Dict[str, Any]:
    """运行外贸任务（入口函数）。"""
    init_database()
    builder = PSVGraphBuilder()
    graph = builder.build()

    initial_state = create_initial_state(task_contract)
    config = {"configurable": {"thread_id": initial_state["workflow_id"]}}

    result = graph.invoke(initial_state, config=config)
    return dict(result)


def resume_trade_task(workflow_id: str, task_contract: Dict[str, Any] = None) -> Dict[str, Any]:
    """恢复中断任务。"""
    init_database()
    builder = PSVGraphBuilder()
    recovered = builder.recovery.recover(workflow_id)
    if not recovered:
        if task_contract:
            return run_trade_task(task_contract)
        return {"error": "No recovery point found and no task contract provided"}

    graph = builder.build()
    config = {"configurable": {"thread_id": workflow_id}}
    result = graph.invoke(recovered, config=config)
    return dict(result)
