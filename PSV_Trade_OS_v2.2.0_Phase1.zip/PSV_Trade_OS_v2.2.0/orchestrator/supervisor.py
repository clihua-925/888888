# -*- coding: utf-8 -*-
"""Supervisor Agent — 监督智能体

职责：
- 接收 Trade Planner 的执行计划
- 按顺序调用不同业务 Agent
- 监控每个 Agent 的执行结果
- 决定：继续 / 重试 / 跳过 / 重规划 / 终止
- 集成 LLM 进行复杂决策
"""
import time
import json
from typing import Dict, List, Any, Optional

from contracts.agent_contract import AgentRequest, AgentResponse, AgentStatus, ConfidenceLevel
from shared.llm.client import LLMClient
from shared.config.settings import settings


class SupervisorAgent:
    """Supervisor Agent — 智能监督中心。"""

    def __init__(self):
        self.agent_name = "supervisor"
        self.decision_history: List[Dict] = []
        self.llm = LLMClient()

    def supervise(self, state: Dict[str, Any], agent_results: Dict[str, AgentResponse]) -> Dict[str, Any]:
        plan = state.get("execution_plan", {})
        sequence = plan.get("agent_sequence", [])
        current = state.get("current_agent", "")
        retry_count = state.get("retry_count", 0)

        completed = [a for a in sequence if a in agent_results and agent_results[a].is_success()]
        if len(completed) == len(sequence) and sequence:
            return self._decision("complete", "report", "所有 Agent 执行成功，进入报告生成")

        next_agent = self._get_next_agent(sequence, completed, current)

        if current and current in agent_results and current != "supervisor":
            result = agent_results[current]
            if not result.is_success():
                if retry_count < settings.MAX_AGENT_RETRIES:
                    return self._decision(
                        "retry", current,
                        f"Agent [{current}] 失败（{result.error}），第 {retry_count + 1} 次重试"
                    )

                fallback = plan.get("fallback_strategy", {}).get("on_agent_failure", "skip_and_continue")

                if current in ["market_research", "company_discovery"]:
                    llm_decision = self._llm_decide(state, current, result)
                    if llm_decision:
                        return llm_decision

                if fallback == "skip_and_continue":
                    return self._decision("skip", next_agent, f"Agent [{current}] 超过最大重试次数，跳过并继续")
                elif fallback == "abort":
                    return self._decision("abort", "", f"Agent [{current}] 失败且策略为 abort，终止任务")
                else:
                    return self._decision("replan", "planner", f"Agent [{current}] 失败，触发重规划")

        if next_agent:
            return self._decision("continue", next_agent, f"执行下一个 Agent: [{next_agent}]")

        if sequence:
            return self._decision("complete", "report", "所有 Agent 已执行（部分可能失败），进入报告生成")

        return self._decision("complete", "", "无执行计划，直接完成")

    def _llm_decide(self, state: Dict, failed_agent: str, response: AgentResponse) -> Optional[Dict]:
        """使用 LLM 对关键失败进行智能决策。"""
        try:
            prompt = f"""你是 PSV Trade Intelligence OS 的监督智能体。
当前任务状态：
- 失败 Agent: {failed_agent}
- 错误信息: {response.error}
- 已重试次数: {state.get('retry_count', 0)}
- 当前计划版本: {state.get('plan_version', 1)}
- 已执行 Agent: {list(state.get('agent_results', {}).keys())}

请从以下选项中选择最合适的决策：
1. retry — 继续重试该 Agent
2. skip — 跳过该 Agent，继续执行后续
3. replan — 触发重规划，调整执行计划
4. abort — 终止整个任务

只输出 JSON：{{"decision": "retry|skip|replan|abort", "reason": "..."}}"""

            result = self.llm.chat(prompt=prompt, temperature=0.3, max_tokens=500)
            if result["success"] and result["parsed_json"]:
                decision = result["parsed_json"]
                action = decision.get("decision", "skip")
                reason = decision.get("reason", "LLM 决策")
                if action == "retry":
                    return self._decision("retry", failed_agent, reason)
                elif action == "replan":
                    return self._decision("replan", "planner", reason)
                elif action == "abort":
                    return self._decision("abort", "", reason)
        except Exception:
            pass
        return None

    def _get_next_agent(self, sequence: List[str], completed: List[str], current: str) -> Optional[str]:
        if not current:
            return sequence[0] if sequence else None
        try:
            idx = sequence.index(current)
            if idx + 1 < len(sequence):
                return sequence[idx + 1]
        except ValueError:
            pass
        for agent in sequence:
            if agent not in completed:
                return agent
        return None

    def _decision(self, action: str, next_agent: str, reason: str) -> Dict[str, Any]:
        decision = {
            "decision": action,
            "next_agent": next_agent,
            "reason": reason,
            "timestamp": time.time(),
        }
        self.decision_history.append(decision)
        return decision
