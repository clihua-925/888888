# -*- coding: utf-8 -*-
"""Recovery — 任务中断恢复机制

必须支持：
- 任务中断恢复
- 读取 checkpoint
- 恢复 workflow state
- 继续执行（不能重新开始整个任务）
"""
import time
from typing import Dict, Any, Optional

from orchestrator.checkpoint import PSVCheckpointer
from orchestrator.state import PSVGraphState, create_initial_state
from shared.config.settings import settings


class RecoveryManager:
    """恢复管理器。"""

    def __init__(self):
        self.checkpointer = PSVCheckpointer()

    def save_recovery_point(self, workflow_id: str, state: PSVGraphState) -> str:
        """保存恢复点。"""
        recovery_id = f"rec-{workflow_id}-{int(time.time())}"
        # 通过 checkpointer 的底层存储保存
        config = {"configurable": {"thread_id": workflow_id, "checkpoint_ns": "recovery"}}
        checkpoint = {"id": recovery_id, "state": dict(state), "timestamp": time.time()}
        metadata = {"recovery": True, "workflow_id": workflow_id}
        self.checkpointer.backend.put(
            workflow_id, "recovery", recovery_id, None,
            __import__("pickle").dumps(checkpoint),
            __import__("pickle").dumps(metadata)
        )
        return recovery_id

    def list_interrupted(self) -> list:
        """列出所有中断任务。"""
        # 简化为查询数据库中 status = paused 的任务
        from platform.database.models import get_session, TradeTask
        session = get_session()
        tasks = session.query(TradeTask).filter(
            TradeTask.status.in_(["paused", "executing"])
        ).order_by(TradeTask.updated_at.desc()).all()
        result = []
        for t in tasks:
            result.append({
                "task_id": t.id,
                "objective": t.objective,
                "status": t.status,
                "updated_at": t.updated_at.isoformat() if t.updated_at else None,
            })
        session.close()
        return result

    def recover(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        """恢复指定 workflow 的状态。

        Returns:
            恢复后的 state dict，或 None（如果无恢复点）
        """
        rows = self.checkpointer.backend.list(workflow_id, "recovery")
        if not rows:
            return None

        # 取最新的恢复点
        checkpoint_id, checkpoint_bytes, metadata_bytes = rows[0]
        checkpoint = __import__("pickle").loads(checkpoint_bytes)
        state = checkpoint.get("state", {})
        state["status"] = "recovering"
        state["checkpoint_id"] = checkpoint_id
        state["updated_at"] = time.time()
        return state
