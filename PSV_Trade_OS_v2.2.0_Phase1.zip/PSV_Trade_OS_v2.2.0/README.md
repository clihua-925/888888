# PSV Trade Intelligence OS v2.2.0

> 以 LangGraph 多智能体编排系统为核心，以外贸客户开发为业务目标的外贸智能操作系统。

## 架构概览

```
用户外贸目标
    ↓
Trade Intent 输入层
    ↓
LangGraph Orchestrator 编排智能体
    ↓
Agent 工作流系统
    ↓
外贸业务 Agent 集群 + Tools 数据源层
    ↓
数据采集 → 分析 → 评分 → 决策
    ↓
客户池 / 企业画像 / 商业机会 / Trade Graph
    ↓
数据库持久化 + 审计追踪
```

## 快速开始

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env，填入至少一个 LLM API Key

# 3. 运行系统
python -m app.main

# 4. 访问 WebUI
open http://localhost:5000
```

## 核心模块

| 模块 | 职责 |
|------|------|
| `orchestrator/` | LangGraph 核心编排引擎 |
| `agents/` | 8大外贸专业智能体 |
| `tools/` | 数据源抽象层（海关/搜索/B2B/网站抓取） |
| `business/` | 外贸业务逻辑（采集/画像/客户池/图谱） |
| `contracts/` | 模块间契约通信层 |
| `shared/` | 共享能力（记忆/知识/配置/缓存/LLM） |
| `platform/` | 基础设施（数据库/审计/恢复） |
| `tests/` | 测试基线（单元+集成） |

## 测试

```bash
# 运行全部测试
pytest tests/ -v --cov=.

# 运行单元测试
pytest tests/unit/ -v

# 运行集成测试（需要配置 LLM API Key）
pytest tests/integration/ -v
```

## Docker 部署

```bash
docker-compose up -d
```

## 版本历史

- **v2.2.0** — Phase 1 完成：架构加固、测试基线、Tools层、空壳修复
- **v2.1.0** — 初始重构版本
