# -*- coding: utf-8 -*-
"""WebUI — PSV Trade Intelligence OS 外贸业务界面

禁止展示：Node1, Node2, Runtime, Queue
应该展示：市场分析, 客户池, 企业画像, 开发任务, 商业机会, 供应链关系, 智能报告
"""
import os
from flask import Flask, render_template, jsonify, request
from sqlalchemy import func

from platform.database.models import (
    get_session, init_database, TradeCompany, TradeCustomerPool,
    TradeOpportunity, TradeTask, TradeMarket, AuditEvent
)
from orchestrator.graph import run_trade_task, resume_trade_task
from contracts.task_contract import TaskContract

app = Flask(__name__)
app.secret_key = os.urandom(24)


@app.route("/")
def dashboard():
    session = get_session()
    stats = {
        "total_companies": session.query(func.count(TradeCompany.id)).scalar() or 0,
        "total_contacts": session.query(func.count(TradeCustomerPool.id)).scalar() or 0,
        "active_opportunities": session.query(func.count(TradeOpportunity.id)).filter(
            TradeOpportunity.status == "open"
        ).scalar() or 0,
        "completed_tasks": session.query(func.count(TradeTask.id)).filter(
            TradeTask.status == "completed"
        ).scalar() or 0,
    }
    recent_tasks = session.query(TradeTask).order_by(TradeTask.created_at.desc()).limit(5).all()
    top_opportunities = session.query(TradeOpportunity).filter(
        TradeOpportunity.status == "open"
    ).order_by(TradeOpportunity.probability.desc()).limit(10).all()
    session.close()
    return render_template("dashboard.html",
                         stats=stats,
                         recent_tasks=recent_tasks,
                         opportunities=top_opportunities)


@app.route("/market")
def market_analysis():
    session = get_session()
    markets = session.query(TradeMarket).all()
    session.close()
    return render_template("market.html", markets=markets)


@app.route("/customers")
def customer_pool():
    session = get_session()
    page = request.args.get("page", 1, type=int)
    per_page = 20
    query = session.query(TradeCustomerPool).order_by(
        TradeCustomerPool.development_priority.asc(),
        TradeCustomerPool.match_score.desc()
    )
    total = query.count()
    customers = query.offset((page - 1) * per_page).limit(per_page).all()
    session.close()
    return render_template("customers.html",
                         customers=customers,
                         page=page,
                         total=total,
                         per_page=per_page)


@app.route("/companies/<company_id>")
def company_profile(company_id: str):
    session = get_session()
    company = session.query(TradeCompany).filter(TradeCompany.id == company_id).first()
    if not company:
        session.close()
        return "Company not found", 404
    contacts = company.contacts
    opportunities = company.opportunities
    session.close()
    return render_template("company_profile.html",
                         company=company,
                         contacts=contacts,
                         opportunities=opportunities)


@app.route("/tasks")
def tasks():
    session = get_session()
    page = request.args.get("page", 1, type=int)
    per_page = 20
    query = session.query(TradeTask).order_by(TradeTask.created_at.desc())
    total = query.count()
    tasks = query.offset((page - 1) * per_page).limit(per_page).all()
    session.close()
    return render_template("tasks.html", tasks=tasks, page=page, total=total, per_page=per_page)


@app.route("/opportunities")
def opportunities():
    session = get_session()
    opps = session.query(TradeOpportunity).filter(
        TradeOpportunity.status == "open"
    ).order_by(TradeOpportunity.probability.desc()).all()
    session.close()
    return render_template("opportunities.html", opportunities=opps)


@app.route("/report/<task_id>")
def report(task_id: str):
    session = get_session()
    task = session.query(TradeTask).filter(TradeTask.id == task_id).first()
    session.close()
    if not task:
        return "Report not found", 404
    return render_template("report.html", task=task)


@app.route("/api/task", methods=["POST"])
def api_create_task():
    data = request.get_json() or {}
    task = TaskContract(
        objective=data.get("objective", ""),
        product=data.get("product", ""),
        market=data.get("market", ""),
        target_customer=data.get("target_customer", "importer"),
        constraints=data.get("constraints", []),
    )
    result = run_trade_task(task.to_dict())
    return jsonify({
        "task_id": task.task_id,
        "status": result.get("status"),
        "companies": len(result.get("company_pool", [])),
        "customers": len(result.get("customer_pool", [])),
    })


if __name__ == "__main__":
    init_database()
    app.run(host="0.0.0.0", port=5000, debug=True)
