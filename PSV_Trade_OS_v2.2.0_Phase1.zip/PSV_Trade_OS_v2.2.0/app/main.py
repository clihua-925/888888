# -*- coding: utf-8 -*-
"""Main Entry — PSV Trade Intelligence OS 主入口

一个系统。一个入口。一个数据库模型。一个Agent编排体系。
"""
import os
import sys
import json
from typing import Dict, Any, Optional

from contracts.task_contract import TaskContract, TaskPriority
from orchestrator.graph import run_trade_task, resume_trade_task
from platform.database.models import init_database, get_session, TradeTask, TradeCompany, TradeCustomerPool
from platform.database.connection import DatabaseConnection
from shared.config.settings import settings


class PSVTradeOS:
    """PSV 外贸智能操作系统主类。"""

    def __init__(self):
        self.db = DatabaseConnection()
        init_database()

    def execute(
        self,
        objective: str,
        product: str,
        market: str,
        target_customer: str = "importer",
        constraints: Dict = None,
        priority: str = "normal",
    ) -> Dict[str, Any]:
        """执行外贸任务。"""
        priority_map = {
            "low": TaskPriority.LOW,
            "normal": TaskPriority.NORMAL,
            "high": TaskPriority.HIGH,
            "urgent": TaskPriority.URGENT,
        }
        task = TaskContract(
            objective=objective,
            product=product,
            market=market,
            target_customer=target_customer,
            constraints=constraints or {},
            priority=priority_map.get(priority, TaskPriority.NORMAL),
        )
        result = run_trade_task(task.to_dict())
        return {
            "task_id": task.task_id,
            "status": result.get("status", "unknown"),
            "final_report": result.get("final_report", {}),
            "routing_path": result.get("routing_path", []),
            "companies_found": len(result.get("company_pool", [])),
            "customers_scored": len(result.get("customer_pool", [])),
            "opportunities": len(result.get("opportunities", [])),
        }

    def recover(self, task_id: str) -> Dict[str, Any]:
        """恢复中断任务。"""
        session = get_session()
        task = session.query(TradeTask).filter(TradeTask.id == task_id).first()
        session.close()

        if not task:
            return {"error": "Task not found", "task_id": task_id}

        workflow_id = f"wf-{task_id}"
        result = resume_trade_task(workflow_id, task_contract={
            "task_id": task_id,
            "objective": task.objective,
            "product": task.product,
            "market": task.market,
            "target_customer": task.target_customer,
        })
        return {
            "task_id": task_id,
            "status": result.get("status", "unknown"),
            "recovered": True,
        }

    def list_interrupted(self) -> list:
        """列出中断任务。"""
        from orchestrator.recovery import RecoveryManager
        recovery = RecoveryManager()
        return recovery.list_interrupted()

    def get_task_report(self, task_id: str) -> Dict[str, Any]:
        """获取任务报告。"""
        session = get_session()
        task = session.query(TradeTask).filter(TradeTask.id == task_id).first()
        session.close()
        if not task:
            return {"error": "Task not found"}
        return {
            "task_id": task.id,
            "objective": task.objective,
            "status": task.status,
            "report": task.final_report,
            "created_at": task.created_at.isoformat() if task.created_at else None,
            "completed_at": task.completed_at.isoformat() if task.completed_at else None,
        }

    def query_customer_pool(self, tier: str = None, limit: int = 100) -> list:
        """查询客户池。"""
        session = get_session()
        query = session.query(TradeCustomerPool)
        if tier:
            query = query.filter(TradeCustomerPool.customer_level == tier)
        entries = query.order_by(TradeCustomerPool.deal_probability.desc()).limit(limit).all()
        result = []
        for e in entries:
            company = session.query(TradeCompany).filter(TradeCompany.id == e.company_id).first()
            result.append({
                "id": e.id,
                "company_name": company.name if company else "",
                "customer_level": e.customer_level,
                "deal_probability": e.deal_probability,
                "follow_up_status": e.follow_up_status,
            })
        session.close()
        return result

    def query_companies(self, country: str = None, industry: str = None, limit: int = 100) -> list:
        """查询企业。"""
        session = get_session()
        query = session.query(TradeCompany)
        if country:
            query = query.filter(TradeCompany.country == country)
        if industry:
            query = query.filter(TradeCompany.industry == industry)
        companies = query.limit(limit).all()
        result = [{"id": c.id, "name": c.name, "country": c.country, "industry": c.industry} for c in companies]
        session.close()
        return result


def main():
    """CLI 入口。"""
    import argparse
    parser = argparse.ArgumentParser(description="PSV Trade Intelligence OS")
    parser.add_argument("--objective", required=True, help="外贸目标")
    parser.add_argument("--product", required=True, help="产品")
    parser.add_argument("--market", required=True, help="目标市场")
    parser.add_argument("--target", default="importer", help="目标客户类型")
    args = parser.parse_args()

    psv = PSVTradeOS()
    result = psv.execute(
        objective=args.objective,
        product=args.product,
        market=args.market,
        target_customer=args.target,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
