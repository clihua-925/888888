# -*- coding: utf-8 -*-
"""API Layer — 对外 API 层

提供 RESTful API 接口供外部调用。
"""
from flask import Flask, request, jsonify
from app.main import PSVTradeOS

app = Flask(__name__)
psv = PSVTradeOS()


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "system": "PSV Trade Intelligence OS",
        "version": "2.2.0",
        "engine": "LangGraph Orchestrator",
    })


@app.route("/task", methods=["POST"])
def create_task():
    """提交外贸任务。"""
    data = request.get_json() or {}
    result = psv.execute(
        objective=data.get("objective", ""),
        product=data.get("product", ""),
        market=data.get("market", ""),
        target_customer=data.get("target_customer", "importer"),
        constraints=data.get("constraints", {}),
        priority=data.get("priority", "normal"),
    )
    return jsonify(result)


@app.route("/task/<task_id>/recover", methods=["POST"])
def recover_task(task_id: str):
    """恢复中断任务。"""
    result = psv.recover(task_id)
    return jsonify(result)


@app.route("/tasks/interrupted", methods=["GET"])
def list_interrupted():
    """列出中断任务。"""
    return jsonify({"tasks": psv.list_interrupted()})


@app.route("/task/<task_id>/report", methods=["GET"])
def get_report(task_id: str):
    """获取任务报告。"""
    return jsonify(psv.get_task_report(task_id))


@app.route("/customers", methods=["GET"])
def list_customers():
    """查询客户池。"""
    tier = request.args.get("tier")
    limit = int(request.args.get("limit", 100))
    return jsonify({"customers": psv.query_customer_pool(tier=tier, limit=limit)})


@app.route("/companies", methods=["GET"])
def list_companies():
    """查询企业。"""
    filters = {}
    if request.args.get("country"):
        filters["country"] = request.args.get("country")
    if request.args.get("industry"):
        filters["industry"] = request.args.get("industry")
    limit = int(request.args.get("limit", 100))
    return jsonify({"companies": psv.query_companies(**filters, limit=limit)})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
