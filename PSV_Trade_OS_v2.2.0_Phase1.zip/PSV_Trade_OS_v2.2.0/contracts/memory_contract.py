# -*- coding: utf-8 -*-
"""Memory Contract — 记忆存储标准

短期记忆：当前任务状态
长期记忆：历史任务、行业知识、客户数据、执行经验
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import time


class MemoryType(Enum):
    SHORT_TERM = "short_term"
    LONG_TERM = "long_term"


class MemoryCategory(Enum):
    TASK_CONTEXT = "task_context"
    INDUSTRY_KNOWLEDGE = "industry_knowledge"
    MARKET_KNOWLEDGE = "market_knowledge"
    PRODUCT_KNOWLEDGE = "product_knowledge"
    COMPANY_DATA = "company_data"
    EXECUTION_EXPERIENCE = "execution_experience"
    USER_PREFERENCE = "user_preference"


@dataclass
class MemoryEntry:
    """记忆条目。"""
    memory_id: str = ""
    memory_type: MemoryType = MemoryType.SHORT_TERM
    category: MemoryCategory = MemoryCategory.TASK_CONTEXT
    key: str = ""
    value: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    source_task_id: str = ""
    confidence: float = 1.0
    access_count: int = 0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    ttl_seconds: Optional[int] = None  # 短期记忆可设置过期时间
