# -*- coding: utf-8 -*-
"""Task Contract — 统一任务格式

所有任务必须通过此契约定义。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import uuid
import time


class TaskType(Enum):
    FULL_DEVELOPMENT = "full_development"
    MARKET_ONLY = "market_only"
    DISCOVERY_ONLY = "discovery_only"
    ENRICHMENT_ONLY = "enrichment_only"
    CUSTOM = "custom"


class TaskPriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    URGENT = 4


@dataclass
class TaskContract:
    """统一任务契约。"""
    task_id: str = field(default_factory=lambda: f"task-{uuid.uuid4().hex[:12]}")
    objective: str = ""
    product: str = ""
    market: str = ""
    target_customer: str = "importer"
    constraints: List[str] = field(default_factory=list)
    workflow: Optional[str] = None
    priority: TaskPriority = TaskPriority.NORMAL
    user_id: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> tuple:
        """返回 (is_valid, error_messages)。"""
        errors = []
        if not self.objective:
            errors.append("objective is required")
        if not self.product:
            errors.append("product is required")
        if not self.market:
            errors.append("market is required")
        return (len(errors) == 0, errors)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "objective": self.objective,
            "product": self.product,
            "market": self.market,
            "target_customer": self.target_customer,
            "constraints": self.constraints,
            "workflow": self.workflow,
            "priority": self.priority.value,
            "user_id": self.user_id,
            "created_at": self.created_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TaskContract":
        priority = data.get("priority", 2)
        if isinstance(priority, int):
            priority = TaskPriority(priority)
        return cls(
            task_id=data.get("task_id", ""),
            objective=data.get("objective", ""),
            product=data.get("product", ""),
            market=data.get("market", ""),
            target_customer=data.get("target_customer", "importer"),
            constraints=data.get("constraints", []),
            workflow=data.get("workflow"),
            priority=priority,
            user_id=data.get("user_id"),
            created_at=data.get("created_at", time.time()),
            metadata=data.get("metadata", {}),
        )
