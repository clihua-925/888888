# -*- coding: utf-8 -*-
"""Agent Contract — 所有Agent输入输出标准

禁止模块直接调用内部变量，必须通过此契约通信。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import time


class AgentStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    PARTIAL = "partial"


class ConfidenceLevel(Enum):
    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    STRONG = 4


@dataclass
class AgentRequest:
    """Agent 统一输入。"""
    task_id: str = ""
    agent_name: str = ""
    input_data: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    memory_refs: List[str] = field(default_factory=list)
    timeout_seconds: int = 300

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "agent_name": self.agent_name,
            "input_data": self.input_data,
            "context": self.context,
            "memory_refs": self.memory_refs,
            "timeout_seconds": self.timeout_seconds,
        }


@dataclass
class AgentResponse:
    """Agent 统一输出。

    必须包含：result, confidence, evidence, next_action, status, error
    """
    task_id: str = ""
    agent_name: str = ""
    result: Dict[str, Any] = field(default_factory=dict)
    confidence: ConfidenceLevel = ConfidenceLevel.NONE
    evidence: List[str] = field(default_factory=list)
    next_action: str = ""
    status: AgentStatus = AgentStatus.PENDING
    error: str = ""
    duration_ms: int = 0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_success(self) -> bool:
        return self.status in (AgentStatus.SUCCESS, AgentStatus.PARTIAL)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "agent_name": self.agent_name,
            "result": self.result,
            "confidence": self.confidence.value,
            "evidence": self.evidence,
            "next_action": self.next_action,
            "status": self.status.value,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentResponse":
        return cls(
            task_id=data.get("task_id", ""),
            agent_name=data.get("agent_name", ""),
            result=data.get("result", {}),
            confidence=ConfidenceLevel(data.get("confidence", 0)),
            evidence=data.get("evidence", []),
            next_action=data.get("next_action", ""),
            status=AgentStatus(data.get("status", "pending")),
            error=data.get("error", ""),
            duration_ms=data.get("duration_ms", 0),
            timestamp=data.get("timestamp", time.time()),
            metadata=data.get("metadata", {}),
        )
