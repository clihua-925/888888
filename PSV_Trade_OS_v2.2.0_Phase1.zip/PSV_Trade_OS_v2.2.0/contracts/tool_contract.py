# -*- coding: utf-8 -*-
"""Tool Contract — 工具调用标准

所有外部工具（数据源、API、爬虫）必须通过此契约封装。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import time


class ToolType(Enum):
    DATA_SOURCE = "data_source"
    API_CLIENT = "api_client"
    SCRAPER = "scraper"
    ANALYZER = "analyzer"
    SEARCH = "search"


class ToolStatus(Enum):
    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"
    RATE_LIMITED = "rate_limited"
    ERROR = "error"


@dataclass
class ToolRequest:
    """工具统一输入。"""
    tool_name: str = ""
    operation: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    timeout_seconds: int = 60


@dataclass
class ToolResponse:
    """工具统一输出。"""
    tool_name: str = ""
    operation: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    raw_output: Any = None
    status: ToolStatus = ToolStatus.AVAILABLE
    error: str = ""
    duration_ms: int = 0
    timestamp: float = field(default_factory=time.time)
    source: str = ""  # 数据来源标识
    confidence: float = 1.0  # 数据可信度

    def is_success(self) -> bool:
        return self.status == ToolStatus.AVAILABLE and not self.error
