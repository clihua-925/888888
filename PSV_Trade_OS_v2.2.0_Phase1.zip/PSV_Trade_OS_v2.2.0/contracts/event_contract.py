# -*- coding: utf-8 -*-
"""Event Contract — 事件通信标准

用于模块间异步事件通知。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import time
import uuid


class EventType(Enum):
    TASK_CREATED = "task_created"
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    TASK_RECOVERED = "task_recovered"
    AGENT_STARTED = "agent_started"
    AGENT_COMPLETED = "agent_completed"
    AGENT_FAILED = "agent_failed"
    DATA_PERSISTED = "data_persisted"
    CHECKPOINT_SAVED = "checkpoint_saved"
    CHECKPOINT_RESTORED = "checkpoint_restored"
    AUDIT_LOGGED = "audit_logged"


@dataclass
class EventContract:
    """事件契约。"""
    event_id: str = field(default_factory=lambda: f"evt-{uuid.uuid4().hex[:12]}")
    event_type: EventType = EventType.TASK_CREATED
    task_id: str = ""
    workflow_id: str = ""
    agent_id: str = ""
    node: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    priority: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "task_id": self.task_id,
            "workflow_id": self.workflow_id,
            "agent_id": self.agent_id,
            "node": self.node,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "priority": self.priority,
        }
