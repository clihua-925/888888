# -*- coding: utf-8 -*-
"""Data Contract — 外贸业务数据结构标准

定义所有业务实体的标准数据结构。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum


class CompanySize(Enum):
    MICRO = "micro"       # < 10人
    SMALL = "small"       # 10-50人
    MEDIUM = "medium"     # 50-200人
    LARGE = "large"       # 200-1000人
    ENTERPRISE = "enterprise"  # > 1000人
    UNKNOWN = "unknown"


class CustomerTier(Enum):
    S = "S"  # 战略客户
    A = "A"  # 高价值
    B = "B"  # 潜力客户
    C = "C"  # 普通客户
    D = "D"  # 低优先级


@dataclass
class CompanyProfile:
    """企业画像标准结构。"""
    company_id: str = ""
    name: str = ""
    country: str = ""
    website: str = ""
    industry: str = ""
    main_products: List[str] = field(default_factory=list)
    procurement_direction: List[str] = field(default_factory=list)
    company_size: CompanySize = CompanySize.UNKNOWN
    supply_chain_relations: Dict[str, Any] = field(default_factory=dict)
    contacts: List[Dict[str, Any]] = field(default_factory=list)
    credibility_score: float = 0.0
    procurement_probability: float = 0.0
    match_score: float = 0.0
    data_sources: List[str] = field(default_factory=list)
    raw_data: Dict[str, Any] = field(default_factory=dict)
    enriched: bool = False
    created_at: float = 0.0
    updated_at: float = 0.0


@dataclass
class CustomerPoolEntry:
    """客户池条目标准结构。"""
    entry_id: str = ""
    company_id: str = ""
    company_name: str = ""
    customer_level: CustomerTier = CustomerTier.C
    customer_value: float = 0.0
    match_score: float = 0.0
    deal_probability: float = 0.0
    development_priority: int = 5
    follow_up_status: str = "new"
    assigned_to: str = ""
    tags: List[str] = field(default_factory=list)
    notes: str = ""
    last_contact: Optional[float] = None
    created_at: float = 0.0
    updated_at: float = 0.0
