# PSV Trade Intelligence OS v4.0.0

## 系统定位
PSV = 外贸智能业务系统
LangGraph 编排智能体 = 系统核心运行引擎

## 架构
```
PSV Trade Intelligence OS
├── app/              # 统一入口
├── business/         # 外贸业务核心
│   ├── collection/   # 外贸采集系统
│   ├── profiling/    # 企业画像系统
│   ├── customer_pool/# 客户池系统
│   ├── trade_graph/  # 商业关系图谱
│   └── analysis/     # 外贸智能分析
├── orchestrator/     # LangGraph编排核心
│   ├── graph.py      # 核心运行引擎
│   ├── state.py      # 状态定义
│   ├── planner.py    # 任务规划
│   ├── supervisor.py # 监督调度
│   ├── checkpoint.py # 状态持久化
│   └── recovery.py   # 中断恢复
├── agents/           # 8个专业Agent
├── contracts/        # 契约层（6个契约）
├── shared/           # 共享层
│   ├── memory/       # 记忆管理
│   ├── state/        # 状态管理
│   ├── knowledge/    # 知识库
│   ├── config/       # 配置
│   └── cache/        # 缓存
├── platform/         # 基础设施
│   ├── audit/        # 审计追踪
│   └── recovery/     # 恢复服务
├── database/         # 数据库（11张核心表）
└── webui/            # 外贸业务界面
```

## 快速启动
```bash
pip install -r requirements.txt
python app/main.py
```

## 验收标准
1. 用户输入外贸目标，系统自动执行全流程
2. 全过程 LangGraph 驱动
3. 所有Agent有输入/输出/状态/日志
4. 任务失败可恢复
5. 所有数据进入数据库
6. 所有行为可审计
