"""
Base Agent - 所有Agent的抽象基类
"""
from abc import ABC, abstractmethod
from contracts.agent_contract import AgentRequest, AgentResponse
from typing import Dict, Any

class BaseAgent(ABC):
    def __init__(self, agent_type: str, tools: list = None):
        self.agent_type = agent_type
        self.tools = tools or []

    @abstractmethod
    def execute(self, request: AgentRequest) -> AgentResponse:
        pass

    def validate_input(self, request: AgentRequest) -> bool:
        return request.agent_type == self.agent_type
