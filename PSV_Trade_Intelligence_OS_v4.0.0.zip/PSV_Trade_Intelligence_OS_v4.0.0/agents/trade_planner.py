"""
Trade Planner Agent
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
import time

class TradePlannerAgent(BaseAgent):
    def __init__(self):
        super().__init__("trade_planner")

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()
        objective = request.input_data.get("objective", "")
        plan = self._generate_plan(objective)
        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"plan": plan, "objective_parsed": True},
            confidence=0.95,
            evidence=[{"type": "plan_generated", "detail": plan}],
            next_action="market_research",
            status="success",
            duration_seconds=time.time() - start,
            tools_used=[]
        )

    def _generate_plan(self, objective: str) -> list:
        return [
            "market_research",
            "company_discovery",
            "company_enrichment",
            "contact_discovery",
            "lead_scoring",
            "sales_strategy",
            "report_generation"
        ]
