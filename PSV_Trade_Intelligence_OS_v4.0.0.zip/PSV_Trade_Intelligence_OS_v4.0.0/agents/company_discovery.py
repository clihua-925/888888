"""
Company Discovery Agent - 寻找进口商、买家、经销商、渠道商
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from contracts.data_contract import CompanyProfile
import time

class CompanyDiscoveryAgent(BaseAgent):
    def __init__(self):
        super().__init__("company_discovery")

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()
        market = request.input_data.get("market", "")
        target = request.input_data.get("target", "importer")
        discovered = [
            CompanyProfile(
                name=f"ABC Trading Co. ({market})",
                country=market,
                website=f"https://abc-trading-{market.lower()}.com",
                industry="Import/Export",
                main_products=["Candles", "Home Decor"],
                procurement_direction=["Birthday Candles", "Scented Candles"],
                company_size="50-200 employees"
            ),
            CompanyProfile(
                name=f"Global Distributors Ltd. ({market})",
                country=market,
                website=f"https://global-dist-{market.lower()}.com",
                industry="Distribution",
                main_products=["Party Supplies", "Gift Items"],
                procurement_direction=["Birthday Supplies"],
                company_size="200-1000 employees"
            )
        ]
        companies = [c.to_dict() for c in discovered]
        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"companies": companies, "count": len(companies), "market": market},
            confidence=0.80,
            evidence=[{"source": "trade_database", "query": f"{target} in {market}"}],
            next_action="company_enrichment",
            status="success",
            duration_seconds=time.time() - start,
            tools_used=["trade_db_search", "web_scraper"]
        )
