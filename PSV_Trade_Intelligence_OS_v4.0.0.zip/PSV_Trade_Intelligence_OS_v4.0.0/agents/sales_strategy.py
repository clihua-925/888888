"""
Sales Strategy Agent - 生成开发策略、邮件方向、跟进建议
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
import time

class SalesStrategyAgent(BaseAgent):
    def __init__(self):
        super().__init__("sales_strategy")

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()
        leads = request.input_data.get("scored_leads", [])
        strategies = []
        for lead in leads:
            comp = lead.get("company", {})
            scores = lead.get("scores", {})
            strategy = {
                "company": comp.get("name"),
                "approach": "Direct email to Purchasing Manager",
                "email_subject": f"Premium Candle Supply Partnership - {comp.get('name')}",
                "email_template": self._generate_email(comp, scores),
                "follow_up_schedule": ["Day 3", "Day 7", "Day 14"],
                "key_points": [
                    "Highlight OEM capability",
                    "Mention FDA/CE certification",
                    "Offer sample program"
                ],
                "risk_mitigation": "Start with small trial order"
            }
            strategies.append(strategy)
        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"strategies": strategies, "count": len(strategies)},
            confidence=0.78,
            evidence=[{"type": "strategy_generation", "template_used": "B2B_introduction"}],
            next_action="report_generation",
            status="success",
            duration_seconds=time.time() - start,
            tools_used=["strategy_template_db", "email_optimizer"]
        )

    def _generate_email(self, comp: dict, scores: dict) -> str:
        contact = comp.get("contacts", [{}])[0]
        return f"""Subject: Partnership Opportunity - Premium Candle Manufacturing

Dear {contact.get('name', 'Manager')},

I noticed {comp.get('name')} is a leading {comp.get('industry')} in {comp.get('country')}.
We specialize in premium birthday candles with OEM capabilities.

Would you be open to a 15-minute call to explore a potential partnership?

Best regards,
PSV Trade Team"""
