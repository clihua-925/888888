"""
Lead Scoring Agent - 客户评分
评分：企业实力、采购可能、匹配程度、成交概率
"""
from agents.base_agent import BaseAgent
from contracts.agent_contract import AgentRequest, AgentResponse
from contracts.data_contract import CustomerIntelligence
import time

class LeadScoringAgent(BaseAgent):
    def __init__(self):
        super().__init__("lead_scoring")

    def execute(self, request: AgentRequest) -> AgentResponse:
        start = time.time()
        companies = request.input_data.get("companies", [])
        scored_leads = []
        for comp in companies:
            company_strength = min(100, comp.get("credibility_score", 0) + 10)
            procurement_prob = comp.get("procurement_probability", 0)
            match_score = 85.0 if "Candle" in str(comp.get("procurement_direction", [])) else 50.0
            deal_prob = (company_strength + procurement_prob + match_score) / 3
            customer = CustomerIntelligence(
                company_id=comp.get("company_id", ""),
                customer_level="A" if deal_prob > 75 else "B" if deal_prob > 50 else "C",
                customer_value=company_strength,
                match_score=match_score,
                deal_probability=deal_prob,
                development_priority=int(deal_prob / 10),
                follow_up_status="new",
                next_action="Send introduction email"
            )
            scored_leads.append({
                "company": comp,
                "customer": customer.to_dict(),
                "scores": {
                    "company_strength": company_strength,
                    "procurement_probability": procurement_prob,
                    "match_score": match_score,
                    "deal_probability": deal_prob
                }
            })
        scored_leads.sort(key=lambda x: x["scores"]["deal_probability"], reverse=True)
        return AgentResponse(
            request_id=request.request_id,
            task_id=request.task_id,
            agent_type=self.agent_type,
            result={"scored_leads": scored_leads, "total": len(scored_leads)},
            confidence=0.82,
            evidence=[{"type": "scoring", "algorithm": "weighted_average"}],
            next_action="sales_strategy",
            status="success",
            duration_seconds=time.time() - start,
            tools_used=["scoring_model"]
        )
