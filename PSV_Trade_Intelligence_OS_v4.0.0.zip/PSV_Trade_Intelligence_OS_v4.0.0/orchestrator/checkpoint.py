"""
Checkpoint Manager - 状态持久化
"""
from typing import Dict, Optional, Any
from database.models import TradeWorkflow

class CheckpointManager:
    def __init__(self, db_session):
        self.db = db_session

    def save(self, task_id: str, state: Dict[str, Any]) -> str:
        checkpoint_id = f"chk_{task_id}_{state.get('current_step', 0)}"
        wf = self.db.query(TradeWorkflow).filter_by(task_id=task_id).first()
        if not wf:
            wf = TradeWorkflow(task_id=task_id)
            self.db.add(wf)
        wf.checkpoint_id = checkpoint_id
        wf.state_data = state
        wf.current_node = state.get("plan", [""])[state.get("current_step", 0)] if state.get("plan") else ""
        self.db.commit()
        return checkpoint_id

    def load(self, checkpoint_id: str) -> Optional[Dict[str, Any]]:
        wf = self.db.query(TradeWorkflow).filter_by(checkpoint_id=checkpoint_id).first()
        if wf and wf.state_data:
            return wf.state_data
        return None

    def list_checkpoints(self, task_id: str) -> list:
        wfs = self.db.query(TradeWorkflow).filter_by(task_id=task_id).all()
        return [(w.checkpoint_id, w.current_node, w.updated_at) for w in wfs if w.checkpoint_id]
