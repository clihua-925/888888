"""
LangGraph State Definition
"""
from typing import Dict, List, Optional, Any, TypedDict, Annotated
import operator

class TradeGraphState(TypedDict):
    task: Dict[str, Any]
    plan: List[str]
    current_step: int
    agent_outputs: Annotated[List[Dict], operator.add]
    company_pool: Annotated[List[Dict], operator.add]
    customer_pool: Annotated[List[Dict], operator.add]
    analysis_results: Dict[str, Any]
    final_report: str
    errors: Annotated[List[str], operator.add]
    checkpoint_id: Optional[str]
    should_continue: bool
    next_agent: str
