"""
Recovery Manager - 任务中断恢复
"""
from typing import Dict, Any, Optional

class RecoveryManager:
    def __init__(self, checkpoint_mgr, orchestrator):
        self.checkpoints = checkpoint_mgr
        self.orchestrator = orchestrator

    def recover(self, checkpoint_id: str) -> Dict[str, Any]:
        state = self.checkpoints.load(checkpoint_id)
        if not state:
            raise ValueError(f"Checkpoint {checkpoint_id} not found")
        state["should_continue"] = True
        state["errors"] = []
        result = self.orchestrator.graph.invoke(state)
        return dict(result)

    def auto_recover(self, task_id: str) -> Optional[Dict[str, Any]]:
        checkpoints = self.checkpoints.list_checkpoints(task_id)
        if checkpoints:
            latest = sorted(checkpoints, key=lambda x: x[2])[-1]
            return self.recover(latest[0])
        return None
