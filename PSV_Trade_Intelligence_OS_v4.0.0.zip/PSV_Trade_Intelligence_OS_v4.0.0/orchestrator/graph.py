"""
LangGraph Orchestrator - 核心运行引擎
"""
from langgraph.graph import StateGraph, END
from orchestrator.state import TradeGraphState
from orchestrator.planner import TradePlanner
from orchestrator.supervisor import Supervisor
from typing import Dict, Any

class TradeOrchestrator:
    def __init__(self, planner: TradePlanner, supervisor: Supervisor):
        self.planner = planner
        self.supervisor = supervisor
        self.graph = self._build_graph()

    def _build_graph(self):
        workflow = StateGraph(TradeGraphState)

        workflow.add_node("planner", self._node_planner)
        workflow.add_node("supervisor", self._node_supervisor)
        workflow.add_node("execute_agent", self._node_execute)
        workflow.add_node("validate", self._node_validate)
        workflow.add_node("checkpoint", self._node_checkpoint)
        workflow.add_node("finalize", self._node_finalize)

        workflow.set_entry_point("planner")
        workflow.add_edge("planner", "supervisor")
        workflow.add_edge("supervisor", "execute_agent")
        workflow.add_conditional_edges(
            "execute_agent",
            self._router,
            {"continue": "validate", "retry": "supervisor", "fail": "checkpoint"}
        )
        workflow.add_conditional_edges(
            "validate",
            self._validate_router,
            {"valid": "checkpoint", "invalid": "supervisor"}
        )
        workflow.add_conditional_edges(
            "checkpoint",
            self._checkpoint_router,
            {"continue": "supervisor", "complete": "finalize"}
        )
        workflow.add_edge("finalize", END)

        return workflow.compile()

    def _node_planner(self, state: TradeGraphState) -> TradeGraphState:
        task_input = state.get("task", {})
        plan = self.planner.plan(
            objective=task_input.get("objective", ""),
            product=task_input.get("product", ""),
            market=task_input.get("market", ""),
            target_customer=task_input.get("target_customer", "")
        )
        state["plan"] = plan.workflow
        state["task"]["task_id"] = plan.task_id
        state["current_step"] = 0
        state["should_continue"] = True
        return state

    def _node_supervisor(self, state: TradeGraphState) -> TradeGraphState:
        return self.supervisor.supervise(state["task"], state)

    def _node_execute(self, state: TradeGraphState) -> TradeGraphState:
        return state

    def _node_validate(self, state: TradeGraphState) -> TradeGraphState:
        outputs = state.get("agent_outputs", [])
        if outputs:
            last = outputs[-1]
            if last.get("confidence", 0) < 0.3:
                state["errors"].append(f"Low confidence output from {last.get('agent_type')}")
        return state

    def _node_checkpoint(self, state: TradeGraphState) -> TradeGraphState:
        state["checkpoint_id"] = f"chk_{state['task']['task_id']}_{state['current_step']}"
        return state

    def _node_finalize(self, state: TradeGraphState) -> TradeGraphState:
        state["should_continue"] = False
        state["final_report"] = self._generate_report(state)
        return state

    def _router(self, state: TradeGraphState) -> str:
        if state.get("errors") and len(state.get("errors", [])) > 3:
            return "fail"
        if state.get("should_continue", False):
            return "continue"
        return "fail"

    def _validate_router(self, state: TradeGraphState) -> str:
        if state.get("errors") and state.get("errors", [])[-1:] and "Low confidence" in str(state["errors"][-1]):
            return "invalid"
        return "valid"

    def _checkpoint_router(self, state: TradeGraphState) -> str:
        if state.get("should_continue", False):
            return "continue"
        return "complete"

    def _generate_report(self, state: TradeGraphState) -> str:
        sections = []
        sections.append("# PSV 外贸智能开发报告\n")
        sections.append(f"## 任务目标：{state['task'].get('objective', '')}\n")
        for out in state.get("agent_outputs", []):
            agent = out.get("agent_type", "unknown")
            sections.append(f"### {agent}\n")
            sections.append(f"- 状态：{out.get('status')}\n")
            sections.append(f"- 置信度：{out.get('confidence', 0):.2f}\n")
        return "\n".join(sections)

    def run(self, task_input: Dict[str, Any]) -> Dict[str, Any]:
        initial_state: TradeGraphState = {
            "task": task_input,
            "plan": [],
            "current_step": 0,
            "agent_outputs": [],
            "company_pool": [],
            "customer_pool": [],
            "analysis_results": {},
            "final_report": "",
            "errors": [],
            "checkpoint_id": None,
            "should_continue": True,
            "next_agent": ""
        }
        result = self.graph.invoke(initial_state)
        return dict(result)
