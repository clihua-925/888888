"""
Trade Planner Agent - 理解外贸目标，生成执行计划
"""
from contracts.task_contract import TaskContract
from contracts.agent_contract import AgentRequest, AgentResponse
from typing import List, Dict, Any

class TradePlanner:
    def __init__(self, llm_client=None):
        self.llm = llm_client

    def plan(self, objective: str, product: str, market: str, target_customer: str) -> TaskContract:
        workflow = [
            "market_research",
            "company_discovery",
            "company_enrichment",
            "contact_discovery",
            "lead_scoring",
            "sales_strategy",
            "report_generation"
        ]
        task = TaskContract(
            objective=objective,
            product=product,
            market=market,
            target_customer=target_customer,
            workflow=workflow,
            status="planned"
        )
        return task

    def replan(self, task: TaskContract, failure_reason: str) -> TaskContract:
        task.workflow.append("recovery_action")
        task.status = "replanned"
        return task
