"""
Supervisor Agent - 监督调度所有业务Agent
"""
from typing import Dict, List, Any, Optional
from contracts.agent_contract import AgentRequest, AgentResponse
from contracts.event_contract import EventContract

class Supervisor:
    def __init__(self, agent_registry: Dict[str, Any], audit_logger=None):
        self.agents = agent_registry
        self.audit = audit_logger
        self.max_retries = 3

    def supervise(self, task: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        plan = task.get("workflow", [])
        current = state.get("current_step", 0)

        if current >= len(plan):
            state["should_continue"] = False
            return state

        agent_name = plan[current]
        agent = self.agents.get(agent_name)

        if not agent:
            state["errors"].append(f"Agent {agent_name} not found")
            state["should_continue"] = False
            return state

        request = AgentRequest(
            task_id=task.get("task_id"),
            agent_type=agent_name,
            input_data=self._build_input(agent_name, state),
            context=state.get("context", {})
        )

        if self.audit:
            self.audit.log_event(EventContract(
                event_type="agent_started",
                source="supervisor",
                task_id=task.get("task_id"),
                agent_id=agent_name,
                payload={"step": current, "input": request.to_dict()}
            ))

        try:
            response = agent.execute(request)
            state["agent_outputs"].append(response.to_dict())
            state["current_step"] = current + 1
            state["context"].update(response.result)

            if self.audit:
                self.audit.log_event(EventContract(
                    event_type="agent_completed",
                    source="supervisor",
                    task_id=task.get("task_id"),
                    agent_id=agent_name,
                    payload={"response": response.to_dict()}
                ))

            if response.status == "failed" and state.get("retry_count", 0) < self.max_retries:
                state["retry_count"] = state.get("retry_count", 0) + 1
                state["should_continue"] = True
            else:
                state["should_continue"] = current + 1 < len(plan)
        except Exception as e:
            state["errors"].append(str(e))
            state["should_continue"] = False
        return state

    def _build_input(self, agent_name: str, state: Dict[str, Any]) -> Dict[str, Any]:
        if agent_name == "market_research":
            return {"market": state.get("task", {}).get("market"), "product": state.get("task", {}).get("product")}
        elif agent_name == "company_discovery":
            return {"market": state.get("task", {}).get("market"), "target": state.get("task", {}).get("target_customer")}
        elif agent_name in ["company_enrichment", "contact_discovery", "lead_scoring"]:
            companies = []
            for out in state.get("agent_outputs", []):
                if out.get("agent_type") in ["company_discovery", "company_enrichment"]:
                    companies.extend(out.get("result", {}).get("companies", []))
            return {"companies": companies}
        elif agent_name == "sales_strategy":
            return {"scored_leads": state.get("context", {}).get("scored_leads", [])}
        return {}
