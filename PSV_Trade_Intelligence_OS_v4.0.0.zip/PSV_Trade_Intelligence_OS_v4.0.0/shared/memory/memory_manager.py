"""
Memory Manager - 短期/长期记忆统一管理
"""
from typing import Dict, List, Optional, Any
from contracts.memory_contract import MemoryContract
import heapq
from datetime import datetime, timedelta

class MemoryManager:
    def __init__(self, db_session):
        self.db = db_session
        self._short_term: Dict[str, MemoryContract] = {}
        self._long_term_cache: Dict[str, MemoryContract] = {}

    def save_short_term(self, task_id: str, content: Dict[str, Any], category: str = "task_state"):
        mem = MemoryContract(
            memory_type="short_term",
            category=category,
            task_id=task_id,
            content=content,
            ttl_seconds=3600
        )
        self._short_term[mem.memory_id] = mem
        self._persist_to_db(mem)
        return mem.memory_id

    def save_long_term(self, content: Dict[str, Any], category: str, tags: List[str] = None):
        mem = MemoryContract(
            memory_type="long_term",
            category=category,
            content=content,
            tags=tags or []
        )
        self._long_term_cache[mem.memory_id] = mem
        self._persist_to_db(mem)
        return mem.memory_id

    def recall(self, query: str, task_id: Optional[str] = None, limit: int = 10) -> List[MemoryContract]:
        results = []
        if task_id:
            for mem in self._short_term.values():
                if mem.task_id == task_id:
                    results.append(mem)
        for mem in self._long_term_cache.values():
            if query.lower() in str(mem.content).lower():
                results.append(mem)
        results.sort(key=lambda x: x.importance_score, reverse=True)
        return results[:limit]

    def _persist_to_db(self, mem: MemoryContract):
        from database.models import MemoryStore
        db_mem = MemoryStore(
            memory_id=mem.memory_id,
            memory_type=mem.memory_type,
            category=mem.category,
            task_id=mem.task_id,
            content=mem.content,
            importance_score=mem.importance_score,
            ttl_seconds=mem.ttl_seconds,
            tags=mem.tags
        )
        self.db.merge(db_mem)
        self.db.commit()
