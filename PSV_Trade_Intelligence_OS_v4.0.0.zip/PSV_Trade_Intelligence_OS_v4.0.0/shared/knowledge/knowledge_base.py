"""
Knowledge Base - 行业/市场/产品/企业知识库
"""
from typing import Dict, List, Any

class KnowledgeBase:
    def __init__(self):
        self._industry: Dict[str, Any] = {}
        self._market: Dict[str, Any] = {}
        self._product: Dict[str, Any] = {}
        self._company: Dict[str, Any] = {}

    def load_industry_knowledge(self, data: Dict[str, Any]):
        self._industry.update(data)

    def get_market_insight(self, country: str, product: str) -> Dict[str, Any]:
        key = f"{country}_{product}"
        return self._market.get(key, {})

    def add_product_knowledge(self, product: str, knowledge: Dict[str, Any]):
        self._product[product] = knowledge

    def query(self, domain: str, query: str) -> Any:
        if domain == "industry":
            return self._industry.get(query, {})
        elif domain == "market":
            return self._market.get(query, {})
        elif domain == "product":
            return self._product.get(query, {})
        return {}
