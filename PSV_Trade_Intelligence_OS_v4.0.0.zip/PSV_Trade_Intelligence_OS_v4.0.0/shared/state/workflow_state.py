"""
LangGraph Workflow State 管理
支持：暂停、恢复、继续执行
"""
from typing import Dict, List, Optional, Any, TypedDict
from dataclasses import dataclass, field
import json

class WorkflowState(TypedDict):
    task_id: str
    current_agent: str
    execution_plan: List[str]
    completed_steps: List[str]
    pending_steps: List[str]
    context: Dict[str, Any]
    results: Dict[str, Any]
    errors: List[str]
    checkpoint_id: Optional[str]
    status: str

class StateManager:
    def __init__(self, db_session):
        self.db = db_session
        self._active_states: Dict[str, WorkflowState] = {}

    def create_state(self, task_id: str, plan: List[str]) -> WorkflowState:
        state: WorkflowState = {
            "task_id": task_id,
            "current_agent": "",
            "execution_plan": plan,
            "completed_steps": [],
            "pending_steps": plan.copy(),
            "context": {},
            "results": {},
            "errors": [],
            "checkpoint_id": None,
            "status": "running"
        }
        self._active_states[task_id] = state
        return state

    def get_state(self, task_id: str) -> Optional[WorkflowState]:
        return self._active_states.get(task_id)

    def update_state(self, task_id: str, updates: Dict[str, Any]) -> WorkflowState:
        state = self._active_states.get(task_id)
        if state:
            for k, v in updates.items():
                state[k] = v
        return state

    def pause(self, task_id: str) -> str:
        state = self._active_states.get(task_id)
        if state:
            state["status"] = "paused"
            checkpoint_id = f"chk_{task_id}_{len(state['completed_steps'])}"
            state["checkpoint_id"] = checkpoint_id
            self._persist_checkpoint(task_id, checkpoint_id, dict(state))
            return checkpoint_id
        return ""

    def resume(self, task_id: str, checkpoint_id: str) -> Optional[WorkflowState]:
        restored = self._load_checkpoint(checkpoint_id)
        if restored:
            restored["status"] = "running"
            self._active_states[task_id] = restored
            return restored
        return None

    def _persist_checkpoint(self, task_id: str, chk_id: str, state_dict: Dict):
        from database.models import TradeWorkflow
        wf = self.db.query(TradeWorkflow).filter_by(task_id=task_id).first()
        if wf:
            wf.checkpoint_id = chk_id
            wf.state_data = state_dict
            self.db.commit()

    def _load_checkpoint(self, chk_id: str) -> Optional[WorkflowState]:
        from database.models import TradeWorkflow
        wf = self.db.query(TradeWorkflow).filter_by(checkpoint_id=chk_id).first()
        if wf and wf.state_data:
            return wf.state_data
        return None
