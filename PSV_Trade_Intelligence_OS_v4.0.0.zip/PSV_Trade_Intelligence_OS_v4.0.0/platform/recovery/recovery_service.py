"""
Recovery Service - 任务中断恢复
"""
from typing import Dict, Any, Optional

class RecoveryService:
    def __init__(self, recovery_mgr):
        self.recovery = recovery_mgr

    def recover_task(self, checkpoint_id: str) -> Dict[str, Any]:
        return self.recovery.recover(checkpoint_id)

    def auto_recover_latest(self, task_id: str) -> Optional[Dict[str, Any]]:
        return self.recovery.auto_recover(task_id)
