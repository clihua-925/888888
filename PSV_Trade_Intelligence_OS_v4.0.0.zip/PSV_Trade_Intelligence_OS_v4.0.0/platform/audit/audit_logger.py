"""
Audit 审计层 - 所有智能行为必须可追踪
"""
from typing import Dict, Any, Optional
from contracts.event_contract import EventContract
from database.models import AuditEvent, AgentExecutionLog
from datetime import datetime

class AuditLogger:
    def __init__(self, db_session):
        self.db = db_session

    def log_event(self, event: EventContract):
        pass

    def log_agent_execution(self, task_id: str, workflow_id: str, agent_id: str,
                           agent_type: str, input_data: Dict, output_data: Dict,
                           tool_calls: list, duration: float, status: str, error: Optional[str] = None):
        log = AgentExecutionLog(
            task_id=task_id, workflow_id=workflow_id, agent_id=agent_id,
            agent_type=agent_type, input_data=input_data, output_data=output_data,
            tool_calls=tool_calls, duration_seconds=duration, status=status, error=error
        )
        self.db.add(log)
        self.db.commit()

    def log_audit_event(self, task_id: str, workflow_id: str, agent_id: str,
                       event_type: str, input_summary: str, output_summary: str,
                       tool_call_summary: str, duration: float, status: str,
                       error_details: Optional[str] = None):
        audit = AuditEvent(
            task_id=task_id, workflow_id=workflow_id, agent_id=agent_id,
            event_type=event_type, input_summary=input_summary,
            output_summary=output_summary, tool_call_summary=tool_call_summary,
            duration=duration, status=status, error_details=error_details
        )
        self.db.add(audit)
        self.db.commit()

    def get_task_trace(self, task_id: str) -> list:
        logs = self.db.query(AuditEvent).filter_by(task_id=task_id).order_by(AuditEvent.timestamp).all()
        return [{
            "timestamp": l.timestamp.isoformat(),
            "agent": l.agent_id,
            "event": l.event_type,
            "status": l.status,
            "duration": l.duration
        } for l in logs]
