"""
企业画像系统 - 每家公司形成 Company Profile
"""
from contracts.data_contract import CompanyProfile
from typing import Dict, Any

class CompanyProfiler:
    def create_profile(self, raw_data: Dict[str, Any]) -> CompanyProfile:
        return CompanyProfile(
            name=raw_data.get("name", ""),
            country=raw_data.get("country", ""),
            website=raw_data.get("website", ""),
            industry=raw_data.get("industry", ""),
            main_products=raw_data.get("main_products", []),
            procurement_direction=raw_data.get("procurement_direction", []),
            company_size=raw_data.get("company_size", ""),
            credibility_score=raw_data.get("credibility_score", 0.0),
            procurement_probability=raw_data.get("procurement_probability", 0.0)
        )

    def enrich_profile(self, profile: CompanyProfile, additional_data: Dict) -> CompanyProfile:
        if not profile.industry and additional_data.get("industry"):
            profile.industry = additional_data["industry"]
        if not profile.company_size and additional_data.get("size"):
            profile.company_size = additional_data["size"]
        profile.enrichment_level += 1
        return profile
