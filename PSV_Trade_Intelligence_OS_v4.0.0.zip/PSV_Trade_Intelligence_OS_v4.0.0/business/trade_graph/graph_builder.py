"""
Trade Graph - 商业关系图谱
产品、企业、国家、供应链、市场、客户关系
"""
from typing import Dict, List, Set, Tuple
import networkx as nx

class TradeGraphBuilder:
    def __init__(self):
        self.graph = nx.DiGraph()

    def add_company(self, company: Dict):
        node_id = company.get("company_id", company.get("name"))
        self.graph.add_node(node_id, type="company", **company)

    def add_product(self, product: Dict):
        node_id = product.get("product_id", product.get("name"))
        self.graph.add_node(node_id, type="product", **product)

    def add_relation(self, source: str, target: str, relation_type: str, attrs: Dict = None):
        self.graph.add_edge(source, target, relation=relation_type, **(attrs or {}))

    def find_opportunities(self, product: str, market: str) -> List[Dict]:
        opportunities = []
        for node, data in self.graph.nodes(data=True):
            if data.get("type") == "company" and data.get("country") == market:
                opportunities.append({"company": node, "data": data, "path_length": 1})
        return opportunities

    def export(self) -> Dict:
        return {
            "nodes": [{"id": n, **d} for n, d in self.graph.nodes(data=True)],
            "edges": [{"source": u, "target": v, **d} for u, v, d in self.graph.edges(data=True)]
        }
