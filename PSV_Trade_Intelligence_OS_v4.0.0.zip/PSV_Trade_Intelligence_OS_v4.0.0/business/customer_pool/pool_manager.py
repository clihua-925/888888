"""
客户池系统 - Customer Intelligence Pool
"""
from typing import List, Dict
from contracts.data_contract import CustomerIntelligence
from database.models import TradeCustomerPool

class CustomerPoolManager:
    def __init__(self, db_session):
        self.db = db_session

    def add_customer(self, customer: CustomerIntelligence):
        db_cust = TradeCustomerPool(
            customer_id=customer.customer_id,
            company_id=customer.company_id,
            customer_level=customer.customer_level,
            customer_value=customer.customer_value,
            match_score=customer.match_score,
            deal_probability=customer.deal_probability,
            development_priority=customer.development_priority,
            follow_up_status=customer.follow_up_status,
            next_action=customer.next_action,
            tags=customer.tags
        )
        self.db.merge(db_cust)
        self.db.commit()

    def get_pool(self, filters: Dict = None) -> List[Dict]:
        query = self.db.query(TradeCustomerPool)
        if filters:
            if "level" in filters:
                query = query.filter_by(customer_level=filters["level"])
            if "status" in filters:
                query = query.filter_by(follow_up_status=filters["status"])
        return [c.__dict__ for c in query.all()]
