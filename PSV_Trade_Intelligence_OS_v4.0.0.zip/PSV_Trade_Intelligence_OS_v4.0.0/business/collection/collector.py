"""
外贸采集系统 - 全球企业发现、买家发现、进口商发现
"""
from typing import List, Dict, Any
from contracts.data_contract import CompanyProfile

class TradeCollector:
    def __init__(self, tool_registry=None):
        self.tools = tool_registry or {}

    def discover(self, product: str, country: str, customer_type: str = "importer") -> List[CompanyProfile]:
        results = []
        if "customs_db" in self.tools:
            results.extend(self.tools["customs_db"].query(product, country, customer_type))
        if "web_scraper" in self.tools:
            results.extend(self.tools["web_scraper"].search(product, country))
        if "company_db" in self.tools:
            results.extend(self.tools["company_db"].search(product, country, customer_type))
        return results
