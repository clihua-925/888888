"""
PSV Trade Intelligence OS - Database Models
核心表：围绕外贸业务设计，非采集任务
"""
from sqlalchemy import create_engine, Column, String, Float, Integer, Text, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import uuid

Base = declarative_base()

def generate_uuid():
    return str(uuid.uuid4())

class TradeCompany(Base):
    __tablename__ = "trade_company"
    company_id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(255), nullable=False, index=True)
    country = Column(String(100), index=True)
    website = Column(String(500))
    industry = Column(String(200))
    main_products = Column(JSON)
    procurement_direction = Column(JSON)
    company_size = Column(String(50))
    supply_chain_relations = Column(JSON)
    credibility_score = Column(Float, default=0.0)
    procurement_probability = Column(Float, default=0.0)
    enrichment_level = Column(Integer, default=0)
    source_references = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    metadata_json = Column("metadata", JSON)

class TradeContact(Base):
    __tablename__ = "trade_contact"
    contact_id = Column(String(36), primary_key=True, default=generate_uuid)
    company_id = Column(String(36), ForeignKey("trade_company.company_id"), index=True)
    name = Column(String(200))
    title = Column(String(200))
    email = Column(String(300))
    phone = Column(String(100))
    linkedin = Column(String(500))
    is_decision_maker = Column(Integer, default=0)
    verified = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class TradeProduct(Base):
    __tablename__ = "trade_product"
    product_id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(255), index=True)
    category = Column(String(200))
    hs_code = Column(String(50))
    target_markets = Column(JSON)
    related_companies = Column(JSON)
    market_trend = Column(JSON)

class TradeMarket(Base):
    __tablename__ = "trade_market"
    market_id = Column(String(36), primary_key=True, default=generate_uuid)
    country = Column(String(100), index=True)
    product_category = Column(String(200))
    market_size = Column(Float)
    growth_rate = Column(Float)
    competition_level = Column(String(50))
    trade_policies = Column(JSON)
    analysis_report = Column(Text)

class TradeCustomerPool(Base):
    __tablename__ = "trade_customer_pool"
    customer_id = Column(String(36), primary_key=True, default=generate_uuid)
    company_id = Column(String(36), ForeignKey("trade_company.company_id"))
    customer_level = Column(String(10), default="C")
    customer_value = Column(Float, default=0.0)
    match_score = Column(Float, default=0.0)
    deal_probability = Column(Float, default=0.0)
    development_priority = Column(Integer, default=0)
    follow_up_status = Column(String(50), default="new")
    assigned_sales = Column(String(200))
    last_contact_date = Column(DateTime)
    next_action = Column(Text)
    notes = Column(Text)
    tags = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class TradeOpportunity(Base):
    __tablename__ = "trade_opportunity"
    opportunity_id = Column(String(36), primary_key=True, default=generate_uuid)
    customer_id = Column(String(36), ForeignKey("trade_customer_pool.customer_id"))
    product_id = Column(String(36), ForeignKey("trade_product.product_id"))
    estimated_value = Column(Float)
    probability = Column(Float)
    expected_close_date = Column(DateTime)
    stage = Column(String(50), default="prospecting")
    strategy = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class TradeTask(Base):
    __tablename__ = "trade_task"
    task_id = Column(String(36), primary_key=True, default=generate_uuid)
    objective = Column(Text)
    product = Column(String(255))
    market = Column(String(200))
    target_customer = Column(String(200))
    workflow = Column(JSON)
    status = Column(String(50), default="pending")
    priority = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class TradeWorkflow(Base):
    __tablename__ = "trade_workflow"
    workflow_id = Column(String(36), primary_key=True, default=generate_uuid)
    task_id = Column(String(36), ForeignKey("trade_task.task_id"))
    current_node = Column(String(100))
    state_data = Column(JSON)
    checkpoint_id = Column(String(36))
    status = Column(String(50), default="running")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AgentExecutionLog(Base):
    __tablename__ = "agent_execution_log"
    log_id = Column(String(36), primary_key=True, default=generate_uuid)
    task_id = Column(String(36), index=True)
    workflow_id = Column(String(36), index=True)
    agent_id = Column(String(100))
    agent_type = Column(String(100))
    input_data = Column(JSON)
    output_data = Column(JSON)
    tool_calls = Column(JSON)
    duration_seconds = Column(Float)
    status = Column(String(50))
    error = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)

class AuditEvent(Base):
    __tablename__ = "audit_event"
    audit_id = Column(String(36), primary_key=True, default=generate_uuid)
    task_id = Column(String(36), index=True)
    workflow_id = Column(String(36), index=True)
    agent_id = Column(String(100))
    event_type = Column(String(100))
    input_summary = Column(Text)
    output_summary = Column(Text)
    tool_call_summary = Column(Text)
    duration = Column(Float)
    status = Column(String(50))
    error_details = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)

class MemoryStore(Base):
    __tablename__ = "memory_store"
    memory_id = Column(String(36), primary_key=True, default=generate_uuid)
    memory_type = Column(String(50))
    category = Column(String(100))
    task_id = Column(String(36))
    content = Column(JSON)
    importance_score = Column(Float, default=0.5)
    access_count = Column(Integer, default=0)
    last_accessed = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    ttl_seconds = Column(Integer)
    tags = Column(JSON)

def init_db(db_url="sqlite:///psv_trade_os.db"):
    engine = create_engine(db_url, echo=False)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)
