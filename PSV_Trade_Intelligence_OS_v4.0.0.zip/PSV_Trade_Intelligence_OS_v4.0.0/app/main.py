"""
PSV Trade Intelligence OS - 统一入口
一个系统、一个入口、一个数据库模型、一个Agent编排体系
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.models import init_db
from orchestrator.graph import TradeOrchestrator
from orchestrator.planner import TradePlanner
from orchestrator.supervisor import Supervisor
from orchestrator.checkpoint import CheckpointManager
from orchestrator.recovery import RecoveryManager
from platform.audit.audit_logger import AuditLogger
from shared.state.workflow_state import StateManager
from shared.memory.memory_manager import MemoryManager
from shared.knowledge.knowledge_base import KnowledgeBase

from agents.trade_planner import TradePlannerAgent
from agents.market_research import MarketResearchAgent
from agents.company_discovery import CompanyDiscoveryAgent
from agents.company_enrichment import CompanyEnrichmentAgent
from agents.contact_discovery import ContactDiscoveryAgent
from agents.lead_scoring import LeadScoringAgent
from agents.sales_strategy import SalesStrategyAgent
from agents.report import ReportAgent

class PSVTradeOS:
    """
    PSV 外贸智能操作系统 - 统一入口
    用户外贸目标 -> Trade Intent -> LangGraph Orchestrator -> Agent工作流
    """
    def __init__(self, db_url="sqlite:///psv_trade_os.db"):
        self.Session = init_db(db_url)
        self.db = self.Session()

        self.state_mgr = StateManager(self.db)
        self.memory_mgr = MemoryManager(self.db)
        self.knowledge = KnowledgeBase()
        self.audit = AuditLogger(self.db)

        self.agent_registry = {
            "trade_planner": TradePlannerAgent(),
            "market_research": MarketResearchAgent(),
            "company_discovery": CompanyDiscoveryAgent(),
            "company_enrichment": CompanyEnrichmentAgent(),
            "contact_discovery": ContactDiscoveryAgent(),
            "lead_scoring": LeadScoringAgent(),
            "sales_strategy": SalesStrategyAgent(),
            "report_generation": ReportAgent()
        }

        self.planner = TradePlanner()
        self.supervisor = Supervisor(self.agent_registry, self.audit)
        self.orchestrator = TradeOrchestrator(self.planner, self.supervisor)

        self.checkpoint_mgr = CheckpointManager(self.db)
        self.recovery_mgr = RecoveryManager(self.checkpoint_mgr, self.orchestrator)

    def execute(self, objective: str, product: str, market: str, target_customer: str) -> dict:
        """
        核心入口：用户输入外贸目标，系统自动执行完整流程
        市场分析 -> 客户发现 -> 企业画像 -> 联系人寻找 -> 客户评分 -> 开发建议 -> 生成报告
        """
        task_input = {
            "objective": objective,
            "product": product,
            "market": market,
            "target_customer": target_customer
        }
        self.audit.log_audit_event(
            task_id="", workflow_id="", agent_id="system",
            event_type="task_started", input_summary=str(task_input),
            output_summary="", tool_call_summary="", duration=0, status="running"
        )
        result = self.orchestrator.run(task_input)
        self.memory_mgr.save_long_term(
            content={"task": task_input, "result_summary": result.get("final_report", "")[:500]},
            category="execution_experience", tags=[product, market, "completed"]
        )
        return result

    def recover(self, checkpoint_id: str) -> dict:
        """任务中断恢复 - 从checkpoint继续执行，不重新开始"""
        return self.recovery_mgr.recover(checkpoint_id)

    def get_audit_trace(self, task_id: str) -> list:
        """获取完整审计追踪"""
        return self.audit.get_task_trace(task_id)

if __name__ == "__main__":
    os = PSVTradeOS()
    result = os.execute(
        objective="开发美国生日蜡烛进口商",
        product="Birthday Candles",
        market="USA",
        target_customer="Importer"
    )
    print("=" * 60)
    print("FINAL REPORT")
    print("=" * 60)
    print(result.get("final_report", "No report generated"))
    print("\nExecution complete. Check database for full audit trail.")
