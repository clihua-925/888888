"""
Agent Contract - 智能体输入输出统一契约
所有Agent必须通过AgentRequest/AgentResponse通信
"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime
import uuid

@dataclass
class AgentRequest:
    """Agent输入请求契约"""
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str = ""                     # 关联任务ID
    agent_type: str = ""                  # Agent类型标识
    input_data: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)      # 上下文记忆
    tools_available: List[str] = field(default_factory=list)   # 可用工具列表
    timeout_seconds: int = 300
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "task_id": self.task_id,
            "agent_type": self.agent_type,
            "input_data": self.input_data,
            "context": self.context,
            "tools_available": self.tools_available,
            "timeout_seconds": self.timeout_seconds,
            "timestamp": self.timestamp
        }

@dataclass
class AgentResponse:
    """Agent输出响应契约 - 必须包含完整可追溯信息"""
    response_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    request_id: str = ""                  # 对应请求ID
    task_id: str = ""                     # 关联任务ID
    agent_type: str = ""
    result: Dict[str, Any] = field(default_factory=dict)       # 执行结果
    confidence: float = 0.0               # 置信度 0.0-1.0
    evidence: List[Dict[str, Any]] = field(default_factory=list)  # 证据链
    next_action: str = ""                 # 建议下一步动作
    status: str = "success"               # success/partial/failed
    error: Optional[str] = None           # 错误信息
    duration_seconds: float = 0.0         # 执行耗时
    tools_used: List[str] = field(default_factory=list)        # 使用的工具
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "response_id": self.response_id,
            "request_id": self.request_id,
            "task_id": self.task_id,
            "agent_type": self.agent_type,
            "result": self.result,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "next_action": self.next_action,
            "status": self.status,
            "error": self.error,
            "duration_seconds": self.duration_seconds,
            "tools_used": self.tools_used,
            "timestamp": self.timestamp
        }
