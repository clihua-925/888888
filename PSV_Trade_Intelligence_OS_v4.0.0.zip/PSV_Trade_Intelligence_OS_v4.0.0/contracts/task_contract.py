"""
Task Contract - 统一任务格式契约
所有外贸任务必须通过此契约定义
"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime
import uuid

@dataclass
class TaskContract:
    """统一任务契约"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    objective: str = ""                    # 任务目标：如"开发美国生日蜡烛进口商"
    product: str = ""                      # 目标产品
    market: str = ""                       # 目标市场/国家
    target_customer: str = ""              # 目标客户类型
    constraints: Dict[str, Any] = field(default_factory=dict)  # 约束条件
    workflow: List[str] = field(default_factory=list)           # 工作流步骤
    status: str = "pending"                # pending/running/completed/failed/recovered
    priority: int = 1                      # 优先级 1-5
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    parent_task_id: Optional[str] = None   # 父任务ID（支持子任务）
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "objective": self.objective,
            "product": self.product,
            "market": self.market,
            "target_customer": self.target_customer,
            "constraints": self.constraints,
            "workflow": self.workflow,
            "status": self.status,
            "priority": self.priority,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "parent_task_id": self.parent_task_id,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TaskContract":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
