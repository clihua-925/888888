"""
Memory Contract - 记忆存储统一契约
短期记忆和长期记忆的数据格式
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
import uuid

@dataclass
class MemoryContract:
    """记忆存储契约"""
    memory_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    memory_type: str = ""                 # short_term/long_term
    category: str = ""                    # task_state/industry_knowledge/customer_data/experience
    task_id: Optional[str] = None
    content: Dict[str, Any] = field(default_factory=dict)
    importance_score: float = 0.5         # 重要性评分 0-1
    access_count: int = 0               # 访问次数
    last_accessed: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    ttl_seconds: Optional[int] = None   # 生存时间（短期记忆）
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id": self.memory_id,
            "memory_type": self.memory_type,
            "category": self.category,
            "task_id": self.task_id,
            "content": self.content,
            "importance_score": self.importance_score,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed,
            "created_at": self.created_at,
            "ttl_seconds": self.ttl_seconds,
            "tags": self.tags
        }
