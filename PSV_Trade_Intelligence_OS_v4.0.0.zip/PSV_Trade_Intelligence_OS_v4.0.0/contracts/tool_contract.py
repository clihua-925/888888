"""
Tool Contract - 工具调用统一契约
所有外部工具/API必须通过此契约封装
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
import uuid

@dataclass
class ToolContract:
    """工具调用契约"""
    tool_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tool_name: str = ""                   # 工具名称
    tool_type: str = ""                   # search/enrichment/validation/etc
    parameters: Dict[str, Any] = field(default_factory=dict)   # 调用参数
    result: Dict[str, Any] = field(default_factory=dict)       # 返回结果
    status: str = "pending"               # pending/success/failed
    error_message: Optional[str] = None
    execution_time_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    retry_count: int = 0                  # 重试次数

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_id": self.tool_id,
            "tool_name": self.tool_name,
            "tool_type": self.tool_type,
            "parameters": self.parameters,
            "result": self.result,
            "status": self.status,
            "error_message": self.error_message,
            "execution_time_ms": self.execution_time_ms,
            "timestamp": self.timestamp,
            "retry_count": self.retry_count
        }
