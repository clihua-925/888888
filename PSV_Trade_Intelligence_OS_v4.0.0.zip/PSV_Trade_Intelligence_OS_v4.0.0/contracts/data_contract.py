"""
Data Contract - 数据交换统一契约
所有业务数据流转必须通过此契约
"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime
import uuid

@dataclass
class CompanyProfile:
    """企业画像数据契约"""
    company_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    country: str = ""
    website: str = ""
    industry: str = ""
    main_products: List[str] = field(default_factory=list)
    procurement_direction: List[str] = field(default_factory=list)
    company_size: str = ""                # 企业规模
    supply_chain_relations: List[Dict] = field(default_factory=list)
    contacts: List[Dict] = field(default_factory=list)
    contact_methods: List[Dict] = field(default_factory=list)
    credibility_score: float = 0.0        # 可信度评分 0-100
    procurement_probability: float = 0.0  # 采购可能性 0-100
    enrichment_level: int = 0             # 信息补全等级 0-5
    source_references: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "company_id": self.company_id,
            "name": self.name,
            "country": self.country,
            "website": self.website,
            "industry": self.industry,
            "main_products": self.main_products,
            "procurement_direction": self.procurement_direction,
            "company_size": self.company_size,
            "supply_chain_relations": self.supply_chain_relations,
            "contacts": self.contacts,
            "contact_methods": self.contact_methods,
            "credibility_score": self.credibility_score,
            "procurement_probability": self.procurement_probability,
            "enrichment_level": self.enrichment_level,
            "source_references": self.source_references,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata
        }

@dataclass
class CustomerIntelligence:
    """客户智能池数据契约"""
    customer_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    company_id: str = ""
    customer_level: str = "C"             # A/B/C/D等级
    customer_value: float = 0.0           # 客户价值评分
    match_score: float = 0.0              # 匹配程度 0-100
    deal_probability: float = 0.0         # 成交概率 0-100
    development_priority: int = 0         # 开发优先级 1-10
    follow_up_status: str = "new"         # new/contacted/quoted/negotiated/closed/lost
    assigned_sales: str = ""              # 分配的销售人员
    last_contact_date: Optional[str] = None
    next_action: str = ""
    notes: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "customer_id": self.customer_id,
            "company_id": self.company_id,
            "customer_level": self.customer_level,
            "customer_value": self.customer_value,
            "match_score": self.match_score,
            "deal_probability": self.deal_probability,
            "development_priority": self.development_priority,
            "follow_up_status": self.follow_up_status,
            "assigned_sales": self.assigned_sales,
            "last_contact_date": self.last_contact_date,
            "next_action": self.next_action,
            "notes": self.notes,
            "tags": self.tags,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
