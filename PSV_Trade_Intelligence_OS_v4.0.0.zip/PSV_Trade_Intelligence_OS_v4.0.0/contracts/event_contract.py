"""
Event Contract - 事件通信统一契约
系统内所有事件通知必须通过此契约
"""
from dataclasses import dataclass, field
from typing import Dict, Optional, Any
from datetime import datetime
import uuid

@dataclass
class EventContract:
    """系统事件契约"""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: str = ""                  # task_started/agent_completed/checkpoint_saved/etc
    source: str = ""                      # 事件来源模块
    task_id: Optional[str] = None
    workflow_id: Optional[str] = None
    agent_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)
    severity: str = "info"                # debug/info/warning/error/critical
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "source": self.source,
            "task_id": self.task_id,
            "workflow_id": self.workflow_id,
            "agent_id": self.agent_id,
            "payload": self.payload,
            "severity": self.severity,
            "timestamp": self.timestamp
        }
