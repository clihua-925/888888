"""
WebUI - 围绕外贸业务
展示：市场分析、客户池、企业画像、开发任务、商业机会、供应链关系、智能报告
禁止展示：Node1/Node2/Runtime/Queue
"""
from flask import Flask, render_template, jsonify, request
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.models import init_db, TradeCompany, TradeCustomerPool, TradeTask, TradeOpportunity

app = Flask(__name__)
Session = init_db("sqlite:///psv_trade_os.db")

@app.route("/")
def dashboard():
    db = Session()
    stats = {
        "total_companies": db.query(TradeCompany).count(),
        "total_customers": db.query(TradeCustomerPool).count(),
        "active_tasks": db.query(TradeTask).filter_by(status="running").count(),
        "opportunities": db.query(TradeOpportunity).count(),
        "a_level_customers": db.query(TradeCustomerPool).filter_by(customer_level="A").count()
    }
    db.close()
    return render_template("dashboard.html", stats=stats)

@app.route("/api/market-analysis")
def market_analysis():
    return jsonify({
        "markets": [
            {"country": "USA", "product": "Birthday Candles", "growth": 12.5, "opportunity_score": 85},
            {"country": "Germany", "product": "Scented Candles", "growth": 8.3, "opportunity_score": 72}
        ]
    })

@app.route("/api/customer-pool")
def customer_pool():
    db = Session()
    customers = db.query(TradeCustomerPool).all()
    result = [{
        "customer_id": c.customer_id,
        "level": c.customer_level,
        "value": c.customer_value,
        "match_score": c.match_score,
        "deal_probability": c.deal_probability,
        "priority": c.development_priority,
        "status": c.follow_up_status,
        "next_action": c.next_action
    } for c in customers]
    db.close()
    return jsonify({"customers": result})

@app.route("/api/company-profiles")
def company_profiles():
    db = Session()
    companies = db.query(TradeCompany).limit(50).all()
    result = [{
        "company_id": c.company_id,
        "name": c.name,
        "country": c.country,
        "website": c.website,
        "industry": c.industry,
        "credibility_score": c.credibility_score,
        "procurement_probability": c.procurement_probability
    } for c in companies]
    db.close()
    return jsonify({"companies": result})

@app.route("/api/tasks", methods=["POST"])
def create_task():
    data = request.json
    return jsonify({"task_id": "new-task-id", "status": "started"})

@app.route("/api/reports/<task_id>")
def get_report(task_id):
    return jsonify({
        "task_id": task_id,
        "report": "Full trade development report...",
        "generated_at": "2026-01-01T00:00:00Z"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
